if (typeof (AccountRibbon) === "undefined") {
    AccountRibbon = {
        __namespace: true
    };
}
var serviceReqCreateRolesWithKnowledgeRoles="System Administrator,NIQ Global Helpline Agent,NIQ Global Helpline Manager,NIQ Ops Solution Provider,NIQ Analytics Agent,NIQ Analytics Manager,NIQ Ops Submitter,"
+"NIQ Knowledge Contributor,NIQ Knowledge Publisher,NIQ Delegate Agent,NIQ Delegate Manager,NIQ Delegate Submitter,NIQ Client Response Agent,NIQ Client Response Manager";
var secondaryContactVisibilityRoles = "System Administrator , NIQ Analytics Manager, NIQ Client Response Manager , NIQ Analytics Agent , NIQ Client Response Agent , NIQ Customer Service , NIQ CS Lead Generation";
AccountRibbon.Events = {
    OnClickNewApprovalRequest: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var AccountId = formContext.data.entity.getId();
        var AccountName = formContext.getAttribute("name").getValue();
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_financeapprovalrequests";
        var formParameters = {};
        formParameters["niq_approvaltype"] = "100000002";
        formParameters["niq_relatedaccount"] = AccountId;
        formParameters["niq_relatedaccountname"] = AccountName;
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );
    },
    AccountPlanVisibility: function (executionContext) {
        var formContext = executionContext;
        var CurrentUser = Xrm.Utility.getGlobalContext().userSettings.userName;
        var AccountOwner = formContext.getAttribute("ownerid").getValue();
        if (AccountOwner !== null) {
            var OwnerName = AccountOwner[0].name;
            if (OwnerName === CurrentUser) {
                return true;
            }
            else {
                return false;
            }
        }
    },
    AcivateButtonVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckValueExists(formContext, "niq_accounttype"))
        {
           var accounttype = formContext.getAttribute("niq_accounttype").getValue();
           
           if(accounttype === 2)
           {
              return false;
           }
           else
           {
              return true;
           }
        }

    },
    OnClickOpenNewAccountPlan: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var lookupValue = new Array();
        lookupValue[0] = new Object();
        lookupValue[0].id = formContext.data.entity.getId(); // GUID of the lookup id
        lookupValue[0].name = formContext.getAttribute("name").getValue(); // Name of the lookup
        lookupValue[0].entityType = "account"; //Entity Type of the lookup entity        
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_accountplan";
        var formParameters = {};
        formParameters["niq_accountname"] = lookupValue;
        formParameters["niq_name"] = formContext.getAttribute("name").getValue();
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );
    },
    OnClickOfNewSAPChangeRequest: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var accountData = new Array();
        accountData[0] = new Object();
        accountData[0].id = formContext.data.entity.getId();
        accountData[0].name = formContext.getAttribute("name").getValue();
        accountData[0].entityType = "account";
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_financeapprovalrequests";
        var formParameters = {};
        formParameters["niq_approvaltype"] = "100000001";
        formParameters["niq_relatedaccount"] = accountData;
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );
    },
    OnClickOfNewSAPAccountRequest: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var accountData = new Array();
        accountData[0] = new Object();
        accountData[0].id = formContext.data.entity.getId();
        accountData[0].name = formContext.getAttribute("name").getValue();
        accountData[0].entityType = "account";
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_sapaccountrequest";
        entityFormOptions["useQuickCreateForm"] = true;
        var formParameters = {};

        formParameters["niq_customeraccountid"] = accountData;
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );
    },
    NewSAPAccountRequestButtonVisibility:function(executionContext){
        'use strict';
        var formContext=executionContext;
        if(CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User,System Administrator,System Customizer")){
            return true;
        }else{
            return false;
        }
    },
    ShowHideCopyLinkBtn: function (primaryctrl)
    {
        "use strict";
 
        if (primaryctrl.ui.getFormType() !== 1 && CommonForm.Events.CheckIfLoggedInUserRoles(serviceReqCreateRolesWithKnowledgeRoles))
        {
            return true;
        }
        else
        {
            return false;
        }
    },
    copyRecordUrl: function (primaryCtrl)
    {        
        var url = primaryCtrl.getUrl();
        var tempTag = document.createElement('textarea');
        tempTag.value = url;
        tempTag.setAttribute('readonly', '');
        tempTag.style = {
            position: 'absolute',
            left: '-9999px'
        };
        document.body.appendChild(tempTag);
        tempTag.select();
        document.execCommand('copy');
        document.body.removeChild(tempTag);
        //Xrm.Utility.alertDialog("Link copied to clipboard");
        if (url !== null || url !== undefined)
        {
            alert("Link copied to clipboard");
        }
    },
   SecondaryAccountVisibilty: function (primaryctrl)
    {
        "use strict";
        var entityType = Xrm.Page.getControl("SecondaryAccountsGrid").getGrid().getTotalRecordCount();  //Entity which you want to hide the button of subgrid
        if (entityType == null || entityType <=0 || entityType >=0 )
        {
            if(CommonForm.Events.CheckIfLoggedInUserRoles(secondaryContactVisibilityRoles))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    },
    NewAccountAndExistingButtonVisibility: function(executionContext) {
    'use strict';
     
      var formContext = executionContext;
     
       if(CommonForm.Events.CheckValueExists(formContext, "niq_accounttype"))
       {
         var accounttype = formContext.getAttribute("niq_accounttype").getValue();
       if(accounttype === 2)
       {
         return false;
       }
       else
       {
       return true;
       }
      }
    },

    openLookupAndValidateAccount:function(selectedEntityTypeName, selectedControl, firstPrimaryItemId, primarycontrol) {
    debugger;
    if (selectedControl._controlName=== "SecondaryAccounts"||selectedControl._controlName==="SecondaryAccountsGrid"){
    //(selectedControl.getRelationship().name === "niq_account_contact_SecondaryAccount") {

            var options = {
                allowMultiSelect: true,
                defaultEntityType: "account",
                entityTypes: ["account"]
            };

            AccountRibbon.Events.lookupAddExistingRecords("niq_Relatedaccounts_contact", "contact", "contact", firstPrimaryItemId, selectedControl, options, primarycontrol);

        }
        else {
            // Any other contact relationship (N:N or 1:N) - use default behaviour
            XrmCore.Commands.AddFromSubGrid.addExistingFromSubGridAssociated(selectedEntityTypeName, selectedControl);
        }
    },
    validateAccountType: async function (relatedId,isCustType,contactType) {
                var Select = "?$select=niq_accounttype";
                let GUID=relatedId.toLowerCase();
           await Xrm.WebApi.retrieveRecord("account", GUID, Select).then(
                function success(result) {
                        let accountType = result.niq_accounttype;
                        if (accountType === 1) {
                            isCustType=true;
                        } else if(accountType === 2&& contactType== false ||contactType== true) {
                            isCustType=false;  
                        }
                },
                function (error) {
                    console.log(error.message);
                }
            );
            return isCustType;
        },

    lookupAddExistingRecords: async function (relationshipName, primaryEntity, relatedEntity, parentRecordId, gridControl, lookupOptions, primarycontrol) {
        debugger;
        Xrm.Utility.lookupObjects(lookupOptions).then(function (results) {
            // Get the entitySet name for the primary entity
            Xrm.Utility.getEntityMetadata(primaryEntity).then(function (primaryEntityData) {
                var primaryEntitySetName = primaryEntityData.EntitySetName;
                // Get the entitySet name for the related entity
                Xrm.Utility.getEntityMetadata(relatedEntity).then(async function(relatedEntityData) {
                    var relatedEntitySetName = relatedEntityData.EntitySetName;
                    // Call the associate web api for each result (recursive)
                    AccountRibbon.Events.associateAddExistingResults(relationshipName, primarycontrol, primaryEntitySetName, relatedEntitySetName, relatedEntity, parentRecordId.replace("{", "").replace("}", ""), gridControl, results, 0)
                });
            });
        });
    },
    associateAddExistingResults: async function (relationshipName, primarycontrol, primaryEntitySetName, relatedEntitySetName, relatedEntity, parentRecordId, gridControl, results, index) {
        debugger;
        var formContext = primarycontrol;
        let isCustType;
        try {
            if (index >= results.length) {
                // Refresh the grid once completed
                if (gridControl) { gridControl.refresh(); }
                return;
            }
            var lookupId = results[index].id.replace("{", "").replace("}", "");
            var primaryId = parentRecordId;
            var relatedId = lookupId;
            let contactType= formContext.getAttribute("niq_contactrecordtype").getValue();
            isCustType= await AccountRibbon.Events.validateAccountType(relatedId,isCustType,contactType)
            if( await isCustType == true){
                var association = { '@odata.id': formContext.context.getClientUrl() + "/api/data/v9.0/" + relatedEntitySetName + "(" + relatedId + ")" };
                var req = new XMLHttpRequest();
                req.open("POST", formContext.context.getClientUrl() + "/api/data/v9.0/" + primaryEntitySetName + "(" + primaryId + ")/" + relationshipName + "/$ref", true);
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        index++;
                        if (this.status === 204 || this.status === 1223) {
                            // Success
                            // Process the next item in the list
                            AccountRibbon.Events.associateAddExistingResults(relationshipName, primarycontrol, primaryEntitySetName, relatedEntitySetName, relatedEntity, parentRecordId, gridControl, results, index);
                        }
                        else {
                            // Error
                            var error = JSON.parse(this.response).error.message;
                            if (error === "A record with matching key values already exists.") {
                                // Process the next item in the list
                                AccountRibbon.Events.associateAddExistingResults(relationshipName, primarycontrol, primaryEntitySetName, relatedEntitySetName, relatedEntity, parentRecordId, gridControl, results, index);
                            }
                            else {
                                Xrm.Navigation.openAlertDialog(error);
                                if (gridControl) { gridControl.refresh(); }
                            }
                        }
                    }
                };
                req.send(JSON.stringify(association));
            }else if( isCustType== false) {
                // Show an error message and stop the association
                Xrm.Utility.alertDialog("You have selected an SAP account.Only a customer account can be selected as primary/secondary account.");
            }
        } catch (error) {
            console.log(error);
        }
    },
//DYNCRM-24401 - Create Customer Account Request creation
OnClick_NewCustomerAccount: function(executionContext)
{
            var entityFormOptions = {};
            entityFormOptions["entityName"] = "account";
             entityFormOptions["formId"] = "fbb2da7d-3df0-ef11-9341-7c1e5227eb56".toUpperCase();
            Xrm.Navigation.openForm(entityFormOptions).then(
                function (success) { },
                function (error) { }
            );
},
    //DYNCRM-24401 - Create SAP Account Request creation
    OnClick_NewSAPAccountRequest: async function (executionContext)
    {
       
            var accountId = formContext.data.entity.getId();
            var AccountId = accountId.replace("{", "").replace("}", "");
            var Country = await Xrm.WebApi.retrieveRecord("account", AccountId, "?$select=_niq_countryid_value,_niq_invoicelanguage_value,_niq_industrycode_value,_niq_ultimateparentid_value,address1_line1,address1_line2");
            var CountryId = Country["_niq_countryid_value"];
            var countryLookup = {
                id:CountryId,
                name:Country["_niq_countryid_value@OData.Community.Display.V1.FormattedValue"],
                entityType: "niq_country"
            };
            var invoiceLanguageId = Country["_niq_invoicelanguage_value"];
            var invoiceLanguageLookup = {
                id: invoiceLanguageId,
                name: Country["_niq_invoicelanguage_value@OData.Community.Display.V1.FormattedValue"],
                entityType: "niq_sapaccountmastersupportdata"
            };
            var industryCodeId = Country["_niq_industrycode_value"];
            var invoiceCodeLookup = {
                id: industryCodeId,
                name: Country["_niq_industrycode_value@OData.Community.Display.V1.FormattedValue"],
                entityType: "niq_sapaccountmastersupportdata"
            };
            var accountName = formContext.getAttribute("name").getValue();
            var accountLookup = {
                id:AccountId,
                name:accountName,
                entityType:"account"
            };
            var ultimateAccountId = Country["_niq_ultimateparentid_value"];
            var ultimateAccountLookup = {
                id:ultimateAccountId,
                name:Country["_niq_ultimateparentid_value@OData.Community.Display.V1.FormattedValue"],
                entityType:"account"
            };
            var address1 = Country["address1_line1"] || "";
            var address2 = Country["address1_line2"] || "";
            var fullAddress = (address1 + " " + address2).trim();
            var maxStreet = 60;
            var maxStreet1 = 40;
            var maxStreet2 = 40;
            var maxStreet3 = 40;
            var street = fullAddress.substring(0, maxStreet);
            var street1 = fullAddress.length > maxStreet ? fullAddress.substring(maxStreet, maxStreet + maxStreet1) : "";
            var street2 = fullAddress.length > (maxStreet + maxStreet1) ? fullAddress.substring(maxStreet + maxStreet1, maxStreet + maxStreet1 + maxStreet2) : "";
            var street3 = fullAddress.length > (maxStreet + maxStreet1 + maxStreet2) ? fullAddress.substring(maxStreet + maxStreet1 + maxStreet2, maxStreet + maxStreet1 + maxStreet2 + maxStreet3) : "";

            var formParameters = {};
            formParameters["niq_requesttype"] = 610570000;
            formParameters["niq_customeraccount"] = accountLookup;
            formParameters["niq_country"] = countryLookup;
            formParameters["niq_ultimateparentaccount"] = ultimateAccountLookup;
            formParameters["niq_industrycode"] = invoiceCodeLookup;
            formParameters["niq_language"] = invoiceLanguageLookup;
            formParameters["niq_street"] = street;
            formParameters["niq_street1"] = street1;
            formParameters["niq_street2"] = street2;
            formParameters["niq_street3"] = street3;

            var entityFormOptions = {};
            entityFormOptions["entityName"] = "niq_accountrequest";
            entityFormOptions["formId"] = "c614d23a-c5cd-ef11-8ee9-00224889984b".toUpperCase();
            Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                function (success) { },
                function (error) { }
            );
        

    },

    //DYNCRM-24405 - Create Customer account request - account modification
    OnClick_ModifyCustomerAccountRequest: function (executionContext) {
        
        var accountId = formContext.data.entity.getId();
        var AccountId = accountId.replace("{", "").replace("}", "");
        var accountName = formContext.getAttribute("name").getValue();
        var accountLookup = {
            id:AccountId,
            name:accountName,
            entityType:"account"
        };
        var formParameters = {};
        formParameters["niq_requesttype"] = 610570001;
        formParameters["niq_customeraccount"] = accountLookup;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_accountrequest";
        entityFormOptions["formId"] = "00f94f3f-18cf-ef11-b8e8-7c1e524e097b".toUpperCase();
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );

    },
//DYNCRM-24405 - Create SAP account request - account modification
    OnClick_ModifySAPAccountRequest: async function (executionContext) 
    {
       var userId = Xrm.Utility.getGlobalContext().userSettings.userId;
        var teamid = "047aaf19-7bce-ef11-b8e8-7c1e524e097b"; //mdm team
        var isUserInTeam = false;
        var query = "?$filter=systemuserid eq " + userId + " and teamid eq " + teamid;
        var response = await Xrm.WebApi.retrieveMultipleRecords("teammembership",query);
        if (response.entities.length > 0) 
        {
            isUserInTeam = true;
        }
        if(CommonForm.Events.CheckIfLoggedInUserRole("NIQ Sales User") || isUserInTeam)
        {
            var accountId = formContext.data.entity.getId();
            var AccountId = accountId.replace("{", "").replace("}", "");
            var UltimateParentAccount = formContext.getAttribute("niq_ultimateparentid")?.getValue();
            var parentId = UltimateParentAccount[0].id;
            var customerAccountName = await Xrm.WebApi.retrieveRecord("account", parentId, "?$select=name");
            var accountName = customerAccountName["name"];
            var accountLookup = {
                id:parentId,
                name:accountName,
                entityType:"account"
            };
            var formParameters = {};
            formParameters["niq_requesttype"] = 610570001;
            formParameters["niq_customeraccount"] = accountLookup;
            var entityFormOptions = {};
            entityFormOptions["entityName"] = "niq_accountrequest";
            entityFormOptions["formId"] = "00f94f3f-18cf-ef11-b8e8-7c1e524e097b".toUpperCase();
            Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                function (success) { },
                function (error) { }
            );
        }
        else
        {
            var alertStrings = {
                confirmButtonLabel: "OK",
                text:"User does not have proper roles to initiate this request",
                title:"Warning!"
            };
            var alertOptions = {
                height: 120,
                width:260
            };
            Xrm.Navigation.openAlertDialog(alertStrings,alertOptions);
            
        }

    },

    OnClick_ExtendSAPAccountRequest: function (executionContext) {
        
        var accountId = formContext.data.entity.getId();
        var AccountId = accountId.replace("{", "").replace("}", "");
        var accountName = formContext.getAttribute("name").getValue();
        var accountLookup = {
            id:AccountId,
            name:accountName,
            entityType:"account"
        };
        var formParameters = {};
        formParameters["niq_requesttype"] = 610570002;
        formParameters["niq_customeraccount"] = accountLookup;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_accountrequest";
        entityFormOptions["formId"] = "e69afa5a-1dcf-ef11-b8e9-6045bdf50c47".toUpperCase();
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );

    },

    OnClick_UnblockSAPAccountRequest: function (executionContext) {
        
        var accountId = formContext.data.entity.getId();
        var AccountId = accountId.replace("{", "").replace("}", "");
        var accountName = formContext.getAttribute("name").getValue();
        var accountLookup = {
            id:AccountId,
            name:accountName,
            entityType:"account"
        };
        var formParameters = {};
        formParameters["niq_requesttype"] = 610570003;
        formParameters["niq_customeraccount"] = accountLookup;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_accountrequest";
        entityFormOptions["formId"] = "97eea200-1ecf-ef11-b8e9-6045bd9791de".toUpperCase();
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );

    },

    OnClick_BlockSAPAccountRequest: function (executionContext) {
        
        var accountId = formContext.data.entity.getId();
        var AccountId = accountId.replace("{", "").replace("}", "");
        var accountName = formContext.getAttribute("name").getValue();
        var accountLookup = {
            id:AccountId,
            name:accountName,
            entityType:"account"
        };
        var formParameters = {};
        formParameters["niq_requesttype"] = 610570004;
        formParameters["niq_customeraccount"] = accountLookup;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_accountrequest";
        entityFormOptions["formId"] = "92b7a785-1ecf-ef11-b8e9-6045bdf50c47".toUpperCase();
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );

    },

    //DYNCRM-24405 - Hide-Show Customer Account Request creation
    EnableRule_AccountRequestCustomerFlyout: async function (formContext) {
        'use strict';
        if(await CommonForm.Events.ShowNIQGFKAugRelease()) {
            if (CommonForm.Events.CheckValueExists(formContext, "niq_accounttype") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User,System Administrator,System Customizer")) {
                var accountType = formContext.getAttribute("niq_accounttype").getValue();
                if (accountType === 1) //Customer
                {
                    return true;
                }
            }
            return false;
        }
        return false;
    },

    //24401 Given security roles will able to initiate the New SAP Account Request Creation
    EnableRule_NewSAPAccountRequestCustomer: async function (formContext) 
    {
        if(CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User, NIQ Finance User, NIQ Add-On Finance Gatekeeper, NIQ Add On Sales Ops Approver, System Administrator, NIQ Business Admin"))
        {
            var accountStatus = formContext.getAttribute("statecode").getValue();
            var complianceStatus = formContext.getAttribute("niq_compliancefinancialstatus")?.getValue();
            var tab = formContext.ui.tabs.get("tab_related_sap_accounts");
            var subgridName = "Subgrid_new_1";
            if (tab) 
            {
                var section = tab.sections.get("tab_15_section_1");
                var subgrid = section.controls.get(subgridName);
                var selectedRows = subgrid.getGrid().getSelectedRows();
                //var rowId = selectedRows.get(0).getData().getEntity().getId();
                if(selectedRows.getLength() == 0)
                {
                    if(accountStatus == 1 || complianceStatus == 610570001 || complianceStatus == 610570004 || complianceStatus == 610570000 || complianceStatus == 610570003)
                    {
                        return false;
                    }
                    else 
                    {
                        var AccountId = formContext.data.entity.getId();
                        AccountId = AccountId.replace("{", "").replace("}", "");
                        var fetch = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='false'>" +
                            "<entity name='account'>" +
                            "<attribute name='niq_accounttype'/>" +
                            "<attribute name='accountid'/>" +
                            "<filter type='and'>" +
                            "<condition attribute='statecode' operator='eq' value='0'/>" +
                            "<condition attribute='niq_accounttype' operator='eq' value='2'/>" +
                            "<condition attribute='niq_ultimateparentid' operator='eq' value='" + AccountId + "'/>" +
                            "</filter>" +
                            "</entity>" +
                            "</fetch>";
                        var results = await Xrm.WebApi.retrieveMultipleRecords("account", "?fetchXml=" + encodeURIComponent(fetch));
                        if (results.entities.length === 1) {
                            return false;
                        }
                        return true;
                    }
                    
                }
                return false;
            }
            return false;
        }
    },
    //DYNCRM-24401 - Hide-Show SAP Account Request creation
    EnableRule_AccountRequestSAPFlyout: async function (formContext) {
        'use strict';
        if(await CommonForm.Events.ShowNIQGFKAugRelease()) {
            if (CommonForm.Events.CheckValueExists(formContext, "niq_accounttype") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User,System Administrator,System Customizer")) {
                var accountType = formContext.getAttribute("niq_accounttype").getValue();
                if (accountType === 2)
                    return true;
            }
            return false;
        }
        return false;
    },
    EnableRule_HideButtonsForRelatedSAPAccountSubgrid: function (selectedControl) {
        var gridContext = selectedControl;
        var subgridName = gridContext.getName(); // Retrieve the subgrid name
        console.log(subgridName); // Output the subgrid name
        if (subgridName == "Subgrid_new_1") {
            return false;
        } else {
            return true;
        }
    },
    EnableRule_AddExixtingAccountButton: function (primaryControl) {
        var gridContext = primaryControl;
        var subgridName = gridContext.getName(); // Retrieve the subgrid name
        console.log(subgridName); // Output the subgrid name
        if (subgridName == "Subgrid_new_1") {
            return false;
        } else {
            return true;
        }
    },

    // Visibilty rule of compliance/Revenue button in All Sap accounts homegrid
    EnableRule_HomeGridComplianceFinanceButton: async function(primaryControl)
    {
        if(await CommonForm.Events.ShowNIQGFKAugRelease()) {
            if(CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User, NIQ Finance User, NIQ Add-On Finance Gatekeeper, NIQ Add On Sales Ops Approver, System Administrator, NIQ Business Admin"))
            {
            var userId = Xrm.Utility.getGlobalContext().userSettings.userId;
            var teamId = 'ec841307-7bce-ef11-b8e8-7c1e524e097b';
            var gridName = " All SAP Accounts"
            var formContext = primaryControl;
            var viewSelector = formContext.getViewSelector();
            var currentView = viewSelector.getCurrentView();
            if(currentView.name === gridName)
            {
                try 
                {
                        var query = "?$filter=systemuserid eq " + userId + " and teamid eq " + teamId;
                        var response = await Xrm.WebApi.retrieveMultipleRecords("teammembership", query);
                        if (response.entities.length === 0) 
                        {
                            return false;
                        }
                        
                    return true;
                }
                catch (error) 
                {
                    console.log("Error fetching user in team: " + error.message);
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        }
        return false;
    },

    //Visibilty rule of compliance/Revenue flyout button in SAP Form
    EnableRule_SAPAccountFormComplianceFinanceButton: async function(primaryControl)
    {
        if(await CommonForm.Events.ShowNIQGFKAugRelease()) {
            var formContext = primaryControl;
            var accountType = formContext.getAttribute("niq_accounttype")?.getValue();
            if(accountType === 2)
            {
                var userId = Xrm.Utility.getGlobalContext().userSettings.userId;
                var teamId = 'ec841307-7bce-ef11-b8e8-7c1e524e097b';
                try 
                {
                    var query = "?$filter=systemuserid eq " + userId + " and teamid eq " + teamId;
                    var response = await Xrm.WebApi.retrieveMultipleRecords("teammembership", query);
                    if (response.entities.length === 0) 
                    {
                        return false;
                    }
                                
                    return true;
                }
                catch (error) 
                {
                    console.log("Error fetching user in team: " + error.message);
                    return false;
                }
            }
        }
        return false;
    },

    //Enable rule for the flyout button in sap accounts subgrid
    EnableRule_SAPAccountSubgridComplianceFinanceButton: async function(primaryControl)
    {
        if(await CommonForm.Events.ShowNIQGFKAugRelease()) {
            var formContext = primaryControl;
            var userId = Xrm.Utility.getGlobalContext().userSettings.userId;
            var teamId = 'ec841307-7bce-ef11-b8e8-7c1e524e097b';
            try 
            {
                var query = "?$filter=systemuserid eq " + userId + " and teamid eq " + teamId;
                var response = await Xrm.WebApi.retrieveMultipleRecords("teammembership", query);
                if (response.entities.length === 0) 
                {
                    return false;
                }
                            
                return true;
            }
            catch (error) 
            {
                console.log("Error fetching user in team: " + error.message);
                return false;
            }
        }
        return false;
    },

    //OnClick SAP Form ComplianceBlock
    OnClickOfSAPFormComplianceBlock: async function(executionContext)
    {
        var formContext = executionContext;
        var loggedInUserId = Xrm.Utility.getGlobalContext().userSettings.userId;
        loggedInUserId = loggedInUserId.replace("{","").replace("}","");
        var accountId = formContext.data.entity.getId();
        accountId = accountId.replace("{", "").replace("}", "");

        var complianceStatus = formContext.getAttribute("niq_compliancefinancialstatus")?.getValue();
        if(complianceStatus === 610570000 || complianceStatus === 610570001)
        {
            var alertStrings = { confirmButtonLabel: "OK", text: "This account is already Compliance Blocked. Please select a different record.",title: "Warning!"};
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        }
        else
        {
            try
                {
                    // var results = await Xrm.WebApi.retrieveMultipleRecords("canvasapp", "?$select=canvasappid,name,displayname&$filter=contains(displayname,'" + canvasAppName + "')");
                    // if(results.entities.length > 0)
                    // {
                    //     var result =  results.entities[0];
                    //     var appId = result["canvasappid"];
                    // }
                    var appId = "";
                    var canvasAppName = "Blocking of SAP Account Canvas App";
                    var results = await Xrm.WebApi.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_name,niq_to&$filter=niq_name eq '"+canvasAppName +"'");
                    if (results.entities.length > 0) {
                    var result = results.entities[0]; // Access the first result directly
                    // Columns
                    appId = result["niq_to"]; // Guid
                    }
                    // Request Type = "SAP Account Compliance Block" - 610570003
                    // Request Status = MDM-Pending Review - 610570007
                    // Owner = Requester - loggedInUserId
                    // Compliance / Financial Status = Compliance Blocked in MSD - 610570001
                    var appUrl = "https://apps.powerapps.com/play/" + appId + "?accountids=" +accountId + "&requesttype=610570003&requeststatus=610570007&compliancefinancialstatus=610570001&requestowner="+ loggedInUserId  + ""; 
                    var windowFeatures = "width=1100,height=900,resizable=yes,scrollbars=yes,status=yes";
                    var popupWindow = window.open(appUrl, "CanvasAppPopup", windowFeatures);
                    if(popupWindow) 
                    {
                        popupWindow.focus();
                    }
                    else
                    {
                        alert("Popup blocked. Please allow popups for this site.");
                    }
                }
                catch (error)
                {
                    console.log("process has stopped" +error.message);
                }
            
        }
    },

    //on click of compliance restrict button in sap form
    OnClickOfSAPFormComplianceRestrict: async function(executionContext)
    {
    var formContext = executionContext;
    
    var loggedInUserId = Xrm.Utility.getGlobalContext().userSettings.userId;
    loggedInUserId = loggedInUserId.replace("{","").replace("}","");
    var accountId = formContext.data.entity.getId();
    accountId = accountId.replace("{", "").replace("}", "");
    var complianceStatus = formContext.getAttribute("niq_compliancefinancialstatus")?.getValue();
    if(complianceStatus === 610570002)
    {
        var alertStrings = { confirmButtonLabel: "OK", text: "This account is already Compliance Restricted. Please select a different record.",title: "Warning!" };
        var alertOptions = { height: 120, width: 260 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
    }
    else
    {
        //logic to navigate to canvas app
        try
        {
                    var appId = "";
                    var canvasAppName = "Blocking of SAP Account Canvas App";
                    var results = await Xrm.WebApi.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_name,niq_to&$filter=niq_name eq '"+canvasAppName +"'");
                    if (results.entities.length > 0) 
                    {
                    var result = results.entities[0]; // Access the first result directly
                    // Columns
                    appId = result["niq_to"]; // Guid
                    }
                    // Request Type = "SAP account compliance restrict" - 610570005
                    // Request Status = Approved by Compliance - 610570004
                    // Owner = Requester - loggedInUserId
                    // Compliance / Financial Status = Compliance Restricted - 610570002
                    var appUrl = "https://apps.powerapps.com/play/" + appId + "?accountids=" + accountId + "&requesttype=610570005&requeststatus=610570004&compliancefinancialstatus=610570002&requestowner="+ loggedInUserId  + "";
                    var windowFeatures = "width=1100,height=900,resizable=yes,scrollbars=yes,status=yes";
                    var popupWindow = window.open(appUrl, "CanvasAppPopup", windowFeatures);
                    if(popupWindow) 
                    {
                        popupWindow.focus();
                    }
                    else
                    {
                        alert("Popup blocked. Please allow popups for this site.");
                    }
                }
                catch (error)
                {
                    console.log("process has stopped" +error.message);
                }
            
        }
    
    },

    //OnClick SAP Form Financial Block

    OnClickOfSAPFormFinancialBlock: async function(executionContext)
    {
        var formContext = executionContext;
        
        var loggedInUserId = Xrm.Utility.getGlobalContext().userSettings.userId;
        loggedInUserId = loggedInUserId.replace("{","").replace("}","");
        var accountId = formContext.data.entity.getId();
        accountId = accountId.replace("{", "").replace("}", "");
        
        var complianceStatus = formContext.getAttribute("niq_compliancefinancialstatus")?.getValue();
        
        if(complianceStatus === 610570003 || complianceStatus === 610570004)
        {
            var alertStrings = { confirmButtonLabel: "OK", text: "This account is already Financial Blocked. Please select a different record.",title: "Warning!" };
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        }
        else if(complianceStatus === 610570000)
        {
            var alertStrings = { confirmButtonLabel: "OK", text: "This account is already Compliance Blocked. Please select a different record.",title: "Warning!" };
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        }
        else
        {
            try
            {
                    var appId = "";
                    var canvasAppName = "Blocking of SAP Account Canvas App";
                    var results = await Xrm.WebApi.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_name,niq_to&$filter=niq_name eq '"+canvasAppName +"'");
                    if (results.entities.length > 0) {
                    var result = results.entities[0]; // Access the first result directly
                    // Columns
                    appId = result["niq_to"]; // Guid
                    }
                    // Request Type = "SAP Account Financial Block" - 610570004
                    // Request Status = MDM pending Review - 610570007
                    // Owner = Requester - loggedInUserId
                    // Compliance / Financial Status = Financial Blocked in MSD - 610570004
                    var appUrl = "https://apps.powerapps.com/play/" + appId + "?accountids=" +accountId + "&requesttype=610570004&requeststatus=610570007&compliancefinancialstatus=610570004&requestowner="+ loggedInUserId  + "";
                    var windowFeatures = "width=1100,height=900,resizable=yes,scrollbars=yes,status=yes";
                    var popupWindow = window.open(appUrl, "CanvasAppPopup", windowFeatures);
                    if(popupWindow) 
                    {
                        popupWindow.focus();
                    }
                    else
                    {
                        alert("Popup blocked. Please allow popups for this site.");
                    }
            }
                catch (error)
                {
                    console.log("process has stopped" +error.message);
                }
            
        }
        
    },

    OnClickOfSAPFormComplianceFinancialUnBlock: async function(executionContext)
    {
    var formContext = executionContext;
    var loggedInUserId = Xrm.Utility.getGlobalContext().userSettings.userId;
    loggedInUserId = loggedInUserId.replace("{","").replace("}","");
    var accountId = formContext.data.entity.getId();
    accountId = accountId.replace("{", "").replace("}", "");
    var complianceStatus = formContext.getAttribute("niq_compliancefinancialstatus")?.getValue();
    if(complianceStatus === 610570002)// compliance restrict
    {
        var alertStrings = { confirmButtonLabel: "OK", text: "This account is already Compliance Restricted. Please select a different record.",title: "Warning!" };
        var alertOptions = { height: 120, width: 260 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);

    }
    else if (complianceStatus === 610570005) //active
    {
        var alertStrings = { confirmButtonLabel: "OK", text: "This account is already Active. Please select a different record.",title: "Warning!" };
        var alertOptions = { height: 120, width: 260 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
    }
    else
    {
            try
            {
                var requestStatus;
                if(complianceStatus === 610570000 || complianceStatus === 610570003)
                {
                    requestStatus = 610570008; //approved by MDM
                }
                else
                {
                    requestStatus = 610570004; //approved by Compliance
                }
                var appId = "";
                    var canvasAppName = "Blocking of SAP Account Canvas App";
                    var results = await Xrm.WebApi.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_name,niq_to&$filter=niq_name eq '"+canvasAppName +"'");
                    if (results.entities.length > 0) {
                    var result = results.entities[0]; // Access the first result directly
                    // Columns
                    appId = result["niq_to"]; // Guid
                    }
                // Request Type = "SAP account compliance UnBlocking" - 610570006
                // Request Status = Approved by Compliance - 610570004
                // Owner = Requester - loggedInUserId
                // Compliance / Financial Status = Active - 610570005
                var appUrl = "https://apps.powerapps.com/play/" + appId + "?accountids=" +accountId + "&requesttype=610570006&requeststatus=" + requestStatus + "&compliancefinancialstatus=610570005&requestowner="+ loggedInUserId  + "";
                var windowFeatures = "width=1100,height=900,resizable=yes,scrollbars=yes,status=yes";
                var popupWindow = window.open(appUrl, "CanvasAppPopup", windowFeatures);
                if(popupWindow) 
                {
                    popupWindow.focus();
                }
                else
                {
                    alert("Popup blocked. Please allow popups for this site.");
                }
            }
            catch (error)
            {
                    console.log("process has stopped" +error.message);
            }
    }
            
    },

        //OnClick SAP Form ComplianceUnRestrict

OnClickOfSAPFormComplianceUnRestrict: async function(executionContext)
{
    var formContext = executionContext;
    var accountId = formContext.data.entity.getId();
    
    var loggedInUserId = Xrm.Utility.getGlobalContext().userSettings.userId;
    loggedInUserId = loggedInUserId.replace("{","").replace("}","");
    accountId = accountId.replace("{", "").replace("}", "");
    var formContext = executionContext;
    var complianceStatus = formContext.getAttribute("niq_compliancefinancialstatus")?.getValue();
    if(complianceStatus === 610570000 || complianceStatus === 610570001)
    {
        var alertStrings = { confirmButtonLabel: "OK", text: "This account is already Compliance Blocked. Please select a different record.",title: "Warning!" };
        var alertOptions = { height: 120, width: 260 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
    }
    else if(complianceStatus === 610570003 || complianceStatus === 610570004)
    {
        var alertStrings = { confirmButtonLabel: "OK", text: "This account is already Financial Blocked. Please select a different record.",title: "Warning!" };
        var alertOptions = { height: 120, width: 260 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
    }
    else if(complianceStatus === 610570005)
    {
        var alertStrings = { confirmButtonLabel: "OK", text: "This account is already Active. Please select a different record.",title: "Warning!" };
        var alertOptions = { height: 120, width: 260 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
    }
    else
    {
    try
            {
                var appId = "";
                    var canvasAppName = "Blocking of SAP Account Canvas App";
                    var results = await Xrm.WebApi.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_name,niq_to&$filter=niq_name eq '"+canvasAppName +"'");
                    if (results.entities.length > 0) {
                    var result = results.entities[0]; // Access the first result directly
                    // Columns
                    appId = result["niq_to"]; // Guid
                    }
                // Request Type = "SAP account compliance Unrestrict" - 610570007
                // Request Status = Approved by Compliance - 610570004
                // Owner = Requester - loggedInUserId
                // Compliance / Financial Status = Active - 610570005
                var appUrl = "https://apps.powerapps.com/play/" + appId + "?accountids=" +accountId + "&requesttype=610570007&requeststatus=610570004&compliancefinancialstatus=610570005&requestowner="+ loggedInUserId  + "";
                var windowFeatures = "width=1100,height=900,resizable=yes,scrollbars=yes,status=yes";
                var popupWindow = window.open(appUrl, "CanvasAppPopup", windowFeatures);
                if(popupWindow) 
                {
                    popupWindow.focus();
                }
                else
                {
                    alert("Popup blocked. Please allow popups for this site.");
                }
            }
            catch (error)
                {
                    console.log("process has stopped" +error.message);
                }
            }
    },

    // onclick of compliance block button in home grid
    OnClickOfGridComplianceBlock: async function(primaryControl, selectedControl)
    {
        var formContext = primaryControl;
        
        var loggedInUserId = Xrm.Utility.getGlobalContext().userSettings.userId;
        loggedInUserId = loggedInUserId.replace("{","").replace("}","");
        var selectedRows = selectedControl.getGrid().getSelectedRows();
        if(selectedRows.getLength() === 0)
        {
            var alertStrings = { confirmButtonLabel: "OK", text: "Please select atleast one row" ,title: "Warning!"};
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);   
        }
        else if(selectedRows.getLength() > 30)
        {
            var alertStrings = { confirmButtonLabel: "OK", text: "Maximum of 30 SAP Accounts can be selected" ,title: "Warning!"};
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        }
        else
        {
        var compliancefield = [];
        var accountGuids = [];
        for (let i = 0; i < selectedRows.getLength(); i++)
            {
                var row = selectedRows.get(i);
                var accountId = row.getData().getEntity().getId();
                accountGuids.push(accountId.replace(/[{}]/g, ""));
                var entity = row.getData().getEntity();
                var entityName = entity.getEntityName();
                var record = await Xrm.WebApi.retrieveRecord(entityName, accountId, "?$select=niq_compliancefinancialstatus");
                var complianceStatus = record["niq_compliancefinancialstatus"];
                compliancefield.push(complianceStatus);

            }
            const complianceBlocked = compliancefield.some(Status => Status === 610570000 || Status === 610570001);
            const uniqueStatuses = new Set(compliancefield).size > 1; 
            if(uniqueStatuses)
            {
                var alertStrings = { confirmButtonLabel: "OK", text: "Please select records with the same Compliance/Financial status",title: "Warning!" };
                var alertOptions = { height: 120, width: 260 };
                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            }
            else if(complianceBlocked)
            {
                var alertStrings = { confirmButtonLabel: "OK", text: "This account is already Compliance Blocked. Please select a different record.",title: "Warning!" };
                var alertOptions = { height: 120, width: 260 };
                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            }
            else
            {
                //logic to navigate to canvas app
                try
                {
                    var appId = "";
                    var canvasAppName = "Blocking of SAP Account Canvas App";
                    var results = await Xrm.WebApi.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_name,niq_to&$filter=niq_name eq '"+canvasAppName +"'");
                    if (results.entities.length > 0) {
                    var result = results.entities[0]; // Access the first result directly
                    // Columns
                    appId = result["niq_to"]; // Guid
                    }
                    // Request Type = "SAP Account Compliance Block" - 610570003
                    // Request Status = MDM-Pending Review - 610570007
                    // Owner = Requester - loggedInUserId
                    // Compliance / Financial Status = Compliance Blocked in MSD - 610570001
                    var appUrl = "https://apps.powerapps.com/play/" + appId + "?accountids=" +accountGuids.join(',') + "&requesttype=610570003&requeststatus=610570007&compliancefinancialstatus=610570001&requestowner="+ loggedInUserId  + "";
                    var windowFeatures = "width=1100,height=900,resizable=yes,scrollbars=yes,status=yes";
                    var popupWindow = window.open(appUrl, "CanvasAppPopup", windowFeatures);
                    if(popupWindow) 
                    {
                        popupWindow.focus();
                    }
                    else
                    {
                        alert("Popup blocked. Please allow popups for this site.");
                    }
                }
                catch (error)
                {
                    console.log("process has stopped" +error.message);
                }
                
            }
        }
    },
    //Onclick on compliance Restrict
OnClickOfGridComplianceRestrict: async function(primaryControl, selectedControl)
{
        var formContext = primaryControl;
        var loggedInUserId = Xrm.Utility.getGlobalContext().userSettings.userId;
        loggedInUserId = loggedInUserId.replace("{","").replace("}","");
        var selectedRows = selectedControl.getGrid().getSelectedRows();
        if(selectedRows.getLength() === 0)
        {
            var alertStrings = { confirmButtonLabel: "OK", text: "Please select atleast one row" ,title: "Warning!"};
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);   
        }
        else if(selectedRows.getLength() > 30)
        {
            var alertStrings = { confirmButtonLabel: "OK", text: "Maximum of 30 SAP Accounts can be selected" ,title: "Warning!"};
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        }
        else
        {
        var compliancefield = [];
        var accountGuids = [];
        for (let i = 0; i < selectedRows.getLength(); i++)
            {
                var row = selectedRows.get(i);
                var accountId = row.getData().getEntity().getId();
                accountGuids.push(accountId.replace(/[{}]/g, ""));
                var entity = row.getData().getEntity();
                var entityName = entity.getEntityName();
                var record = await Xrm.WebApi.retrieveRecord(entityName, accountId, "?$select=niq_compliancefinancialstatus");
                var complianceStatus = record["niq_compliancefinancialstatus"];
                compliancefield.push(complianceStatus);
            }
            const complianceRestricted = compliancefield.some(Status => Status === 610570002); //status = restrict
            const uniqueStatuses = new Set(compliancefield).size > 1; 
            if(uniqueStatuses)
            {
                var alertStrings = { confirmButtonLabel: "OK", text: "Please select records with the same Compliance/Financial status",title: "Warning!" };
                var alertOptions = { height: 120, width: 260 };
                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            }
            else if(complianceRestricted)
            {
                var alertStrings = { confirmButtonLabel: "OK", text: "This account is already Compliance Restricted. Please select a different record.",title: "Warning!" };
                var alertOptions = { height: 120, width: 260 };
                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            }
            else
            {
                try
                {
                    var appId = "";
                    var canvasAppName = "Blocking of SAP Account Canvas App";
                    var results = await Xrm.WebApi.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_name,niq_to&$filter=niq_name eq '"+canvasAppName +"'");
                    if (results.entities.length > 0) {
                    var result = results.entities[0]; // Access the first result directly
                    // Columns
                    appId = result["niq_to"]; // Guid
                    }
                    // Request Type = "SAP account compliance restrict" - 610570005
                    // Request Status = Approved by Compliance - 610570004
                    // Owner = Requester - loggedInUserId
                    // Compliance / Financial Status = Compliance Restricted - 610570002
                    var appUrl = "https://apps.powerapps.com/play/" + appId + "?accountids=" +accountGuids.join(',') + "&requesttype=610570005&requeststatus=610570004&compliancefinancialstatus=610570002&requestowner="+ loggedInUserId  + "";
                    var windowFeatures = "width=1100,height=900,resizable=yes,scrollbars=yes,status=yes";
                    var popupWindow = window.open(appUrl, "CanvasAppPopup", windowFeatures);
                    if(popupWindow) 
                    {
                        popupWindow.focus();
                    }
                    else
                    {
                        alert("Popup blocked. Please allow popups for this site.");
                    }
                }
                catch (error)
                {
                    console.log("process has stopped" +error.message);
                }
            }
        }
    },
    //onclick financial block
OnClickOfGridFinancialBlock: async function(primaryControl, selectedControl)
{
    var formContext = primaryControl;
        
        var loggedInUserId = Xrm.Utility.getGlobalContext().userSettings.userId;
        loggedInUserId = loggedInUserId.replace("{","").replace("}","");
        var selectedRows = selectedControl.getGrid().getSelectedRows();
        if(selectedRows.getLength() === 0)
        {
            var alertStrings = { confirmButtonLabel: "OK", text: "Please select atleast one row" ,title: "Alert"};
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);   
        }
        else if(selectedRows.getLength() > 30)
        {
            var alertStrings = { confirmButtonLabel: "OK", text: "Maximum of 30 SAP Accounts can be selected" ,title: "Alert"};
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        }
        else
        {
        var compliancefield = [];
        var accountGuids = [];
        for (let i = 0; i < selectedRows.getLength(); i++)
            {
                var row = selectedRows.get(i);
                var accountId = row.getData().getEntity().getId();
                accountGuids.push(accountId.replace(/[{}]/g, ""));
                var entity = row.getData().getEntity();
                var entityName = entity.getEntityName();
                var record = await Xrm.WebApi.retrieveRecord(entityName, accountId, "?$select=niq_compliancefinancialstatus");
                var complianceStatus = record["niq_compliancefinancialstatus"];
                compliancefield.push(complianceStatus);
            }
            const financialBlock = compliancefield.some(Status => Status === 610570003 || Status === 610570004); //status = financial block, financial block in msd
            const complianceBlock = compliancefield.some(Status => Status === 610570000)
            const uniqueStatuses = new Set(compliancefield).size > 1; 
            if(uniqueStatuses)
            {
                var alertStrings = { confirmButtonLabel: "OK", text: "Please select records with the same Compliance/Financial status",title: "Warning!" };
                var alertOptions = { height: 120, width: 260 };
                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            }
            else if(financialBlock)
            {
                var alertStrings = { confirmButtonLabel: "OK", text: "This Account is already Financial Blocked. Please select a different record." ,title: "Warning!"};
                var alertOptions = { height: 120, width: 260 };
                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            }
            else if(complianceBlock)
            {
                var alertStrings = { confirmButtonLabel: "OK", text: "This Account is already Compliance Blocked. Please select a different record.",title: "Warning!" };
                var alertOptions = { height: 120, width: 260 };
                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            }
            else
            {
                try
                {
                    var appId = "";
                    var canvasAppName = "Blocking of SAP Account Canvas App";
                    var results = await Xrm.WebApi.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_name,niq_to&$filter=niq_name eq '"+canvasAppName +"'");
                    if (results.entities.length > 0) {
                    var result = results.entities[0]; // Access the first result directly
                    // Columns
                    appId = result["niq_to"]; // Guid
                    }
                    // Request Type = "SAP Account Financial Block" - 610570004
                    // Request Status = MDM Pending Review - 610570007
                    // Owner = Requester - loggedInUserId
                    // Compliance / Financial Status = Financial Blocked in MSD - 610570004
                    var appUrl = "https://apps.powerapps.com/play/" + appId + "?accountids=" +accountGuids.join(',') + "&requesttype=610570004&requeststatus=610570007&compliancefinancialstatus=610570004&requestowner="+ loggedInUserId  + "";
                    var windowFeatures = "width=1100,height=900,resizable=yes,scrollbars=yes,status=yes";
                    var popupWindow = window.open(appUrl, "CanvasAppPopup", windowFeatures);
                    if(popupWindow) 
                    {
                        popupWindow.focus();
                    }
                    else
                    {
                        alert("Popup blocked. Please allow popups for this site.");
                    }
                }
                catch (error)
                {
                    console.log("process has stopped" +error.message);
                }
                
            }
        }

    },
    //onclick Compliance/Financial unblock

OnClickOfGridComplianceFinancialUnBlock: async function(primaryControl, selectedControl)
{
    var formContext = primaryControl;
        
        var loggedInUserId = Xrm.Utility.getGlobalContext().userSettings.userId;
        loggedInUserId = loggedInUserId.replace("{","").replace("}","");
        var selectedRows = selectedControl.getGrid().getSelectedRows();
        if(selectedRows.getLength() === 0)
        {
            var alertStrings = { confirmButtonLabel: "OK", text: "Please select atleast one row" ,title: "Alert"};
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);   
        }
        else if(selectedRows.getLength() > 30)
        {
            var alertStrings = { confirmButtonLabel: "OK", text: "Maximum of 30 SAP Accounts can be selected" ,title: "Alert"};
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        }
        else
        {
        var compliancefield = [];
        var accountGuids = [];
        for (let i = 0; i < selectedRows.getLength(); i++)
            {
                var row = selectedRows.get(i);
                var accountId = row.getData().getEntity().getId();
                accountGuids.push(accountId.replace(/[{}]/g, ""));
                var entity = row.getData().getEntity();
                var entityName = entity.getEntityName();
                var record = await Xrm.WebApi.retrieveRecord(entityName, accountId, "?$select=niq_compliancefinancialstatus");
                var complianceStatus = record["niq_compliancefinancialstatus"];
                compliancefield.push(complianceStatus);
            }
            
            
            const uniqueStatuses = new Set(compliancefield).size > 1; 
            const complianceRestricted = compliancefield.some(Status => Status === 610570002); // compliance restricted
            const complianceFinancialBlocked = compliancefield.some(Status => Status === 610570000 || Status === 610570003) //compliance blocked, financial blocked
            const Active = compliancefield.some(Status => Status === 610570005); //active
            if(uniqueStatuses)
            {
                var alertStrings = { confirmButtonLabel: "OK", text: "Please select records with the same Compliance/Financial status",title: "Warning!" };
                var alertOptions = { height: 120, width: 260 };
                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            }
            else if(complianceRestricted)
            {
                var alertStrings = { confirmButtonLabel: "OK", text: "This Account is already Compliance Restricted. Please select a different record.",title: "Warning!" };
                var alertOptions = { height: 120, width: 260 };
                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            }
            else if(Active)
            {
                var alertStrings = { confirmButtonLabel: "OK", text: "This Account is already Active. Please select a different record.",title: "Warning!" };
                var alertOptions = { height: 120, width: 260 };
                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            }
            else
            {
                try
                {
                    var requestStatus;
                    if(complianceFinancialBlocked)
                    {
                        requestStatus = 610570008; //approved by MDM
                    }
                    else
                    {
                        requestStatus = 610570004; //approved by Compliance
                    }
                    var appId = "";
                    var canvasAppName = "Blocking of SAP Account Canvas App";
                    var results = await Xrm.WebApi.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_name,niq_to&$filter=niq_name eq '"+canvasAppName +"'");
                    if (results.entities.length > 0) {
                    var result = results.entities[0]; // Access the first result directly
                    // Columns
                    appId = result["niq_to"]; // Guid
                    }
                    // Request Type = "SAP account compliance UnBlocking" - 610570006
                    // Request Status = Approved by Compliance - 610570004
                    // Owner = Requester - loggedInUserId
                    // Compliance / Financial Status = Active - 610570005
                    var appUrl = "https://apps.powerapps.com/play/" + appId + "?accountids=" +accountGuids.join(',') + "&requesttype=610570006&requeststatus=" + requestStatus + "&compliancefinancialstatus=610570005&requestowner="+ loggedInUserId  + "" ;
                    var windowFeatures = "width=1100,height=900,resizable=yes,scrollbars=yes,status=yes";
                    var popupWindow = window.open(appUrl, "CanvasAppPopup", windowFeatures);
                    if(popupWindow) 
                    {
                        popupWindow.focus();
                    }
                    else
                    {
                        alert("Popup blocked. Please allow popups for this site.");
                    }
                }
                catch (error)
                {
                    console.log("process has stopped" +error.message);
                }
                
            }
        }

    },
    //onclick compliance unrestrict

OnClickOfGridComplianceUnRestrict: async function(primaryControl, selectedControl)
{
    var formContext = primaryControl;
    
    var loggedInUserId = Xrm.Utility.getGlobalContext().userSettings.userId;
    loggedInUserId = loggedInUserId.replace("{","").replace("}","");
    var selectedRows = selectedControl.getGrid().getSelectedRows();
    if(selectedRows.getLength() === 0)
    {
        var alertStrings = { confirmButtonLabel: "OK", text: "Please select atleast one row" ,title: "Alert"};
        var alertOptions = { height: 120, width: 260 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);   
    }
    else if(selectedRows.getLength() > 30)
    {
        var alertStrings = { confirmButtonLabel: "OK", text: "Maximum of 30 SAP Accounts can be selected" ,title: "Alert"};
        var alertOptions = { height: 120, width: 260 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
    }
    else
    {
    var compliancefield = [];
    var accountGuids = [];
    for (let i = 0; i < selectedRows.getLength(); i++)
        {
            var row = selectedRows.get(i);
            var accountId = row.getData().getEntity().getId();
            accountGuids.push(accountId.replace(/[{}]/g, ""));
            var entity = row.getData().getEntity();
            var entityName = entity.getEntityName();
            var record = await Xrm.WebApi.retrieveRecord(entityName, accountId, "?$select=niq_compliancefinancialstatus");
            var complianceStatus = record["niq_compliancefinancialstatus"];
            compliancefield.push(complianceStatus);
        }
        //const complianceUnRestrict = compliancefield.some(Status => Status === 610570002);
        const uniqueStatuses = new Set(compliancefield).size > 1; 
        const complianceBlock = compliancefield.some(Status => Status === 610570000 || Status === 610570001); //compliance block
        const FinancialBlock = compliancefield.some(Status => Status === 610570003 || Status === 610570004); //Financial Block
        const Active = compliancefield.some(Status => Status === 610570005) //active
        if(uniqueStatuses)
        {
            var alertStrings = { confirmButtonLabel: "OK", text: "Please select records with the same Compliance/Financial status",title: "Warning!" };
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        }
        else if(complianceBlock)
        {
            var alertStrings = { confirmButtonLabel: "OK", text: "This account is already Compliance Blocked. Please select a different record.",title: "Warning!" };
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        }
        else if(FinancialBlock)
        {
            var alertStrings = { confirmButtonLabel: "OK", text: "This account is already Financial Blocked. Please select a different record.",title: "Warning!" };
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        }
        else if(Active)
        {
            var alertStrings = { confirmButtonLabel: "OK", text: "This account is already Active. Please select a different record.",title: "Warning!" };
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        }
        else
        {
            try
            {
                var appId = "";
                    var canvasAppName = "Blocking of SAP Account Canvas App";
                    var results = await Xrm.WebApi.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_name,niq_to&$filter=niq_name eq '"+canvasAppName +"'");
                    if (results.entities.length > 0) {
                    var result = results.entities[0]; // Access the first result directly
                    // Columns
                    appId = result["niq_to"]; // Guid
                    }
                // Request Type = "SAP account compliance Unrestrict" - 610570007
                // Request Status = Approved by Compliance - 610570004
                // Owner = Requester - loggedInUserId
                // Compliance / Financial Status = Active - 610570005
                var appUrl = "https://apps.powerapps.com/play/" + appId + "?accountids=" +accountGuids.join(',') + "&requesttype=610570007&requeststatus=610570004&compliancefinancialstatus=610570005&requestowner="+ loggedInUserId  + "";
                var windowFeatures = "width=1100,height=900,resizable=yes,scrollbars=yes,status=yes";
                var popupWindow = window.open(appUrl, "CanvasAppPopup", windowFeatures);
                if(popupWindow) 
                {
                    popupWindow.focus();
                }
                else
                {
                    alert("Popup blocked. Please allow popups for this site.");
                }
            }
            catch (error)
            {
                console.log("process has stopped" +error.message);
            }
            
        }
    }

    },

    // visibility of sap account extension request button for SAP Accounts Grid
    EnableRule_SAPAccountExtensionRequest: async function(formContext, selectedControl)
    {
        if(CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User, NIQ Finance User, NIQ Add-On Finance Gatekeeper, NIQ Add On Sales Ops Approver, System Administrator, NIQ Business Admin"))
        {
            //var formContext = primaryControl;
            var compliancefield = [];
            var accountGuids = [];
            var selectedRows = selectedControl.getGrid().getSelectedRows();
            for (let i = 0; i < selectedRows.getLength(); i++)
            {
                var row = selectedRows.get(i);
                var accountId = row.getData().getEntity().getId();
                accountGuids.push(accountId.replace(/[{}]/g, ""));
                var entity = row.getData().getEntity();
                var entityName = entity.getEntityName();
                var record = await Xrm.WebApi.retrieveRecord(entityName, accountId, "?$select=niq_compliancefinancialstatus");
                var complianceStatus = record["niq_compliancefinancialstatus"];
                compliancefield.push(complianceStatus);
                if(complianceStatus == 610570000 || complianceStatus == 610570001 || complianceStatus == 610570003 || complianceStatus == 610570004) 
                {
                    return false;
                }
            }
            
            return true;
        }

    },

    //Visibility of SAP Account Request Flyout Button
    EnableRule_SAPAccountGridSAPAccountRequestsButton: async function(primaryControl)
    {
        if(await CommonForm.Events.ShowNIQGFKAugRelease()) {
            var gridName = " All SAP Accounts"
            var formContext = primaryControl;
            var viewSelector = formContext.getViewSelector();
            var currentView = viewSelector.getCurrentView();
            if(currentView.name === gridName)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        return false;
    },

    //Enable rule for Customer Account customer flyout sub button SAP Account Extension Request
    EnableRule_CustomerAccountSAPAccountExtensionRequest: async function(primaryControl)
    {
        var formContext = primaryControl;
        var tab = formContext.ui.tabs.get("tab_related_sap_accounts");
        var subgridName = "Subgrid_new_1";
        if (tab) 
        {
            var section = tab.sections.get("tab_15_section_1");
            var subgrid = section.controls.get(subgridName);
            var selectedRows = subgrid.getGrid().getSelectedRows();
            var rowId = selectedRows.get(0).getData().getEntity().getId();
            //retrieving sap account's compliance financial status 
            var record = await Xrm.WebApi.retrieveRecord("account", rowId, "?$select=niq_compliancefinancialstatus");
            var complianceStatus = record["niq_compliancefinancialstatus"];
            if(selectedRows.getLength() === 1)
            {
                if(complianceStatus == 610570000 || complianceStatus == 610570001 || complianceStatus == 610570003 || complianceStatus == 610570004)
                {
                    return false;
                }  
                return true;
                
            }
            return false;
        }
        return false;

    },

    //Enable rule for Customer Account Customer flyout sub button New SAP Account Creation Request
    EnableRule_CustomerAccountNewSAPAccountCreationRequest: function(primaryControl)
    {
        var formContext = primaryControl;
        var accountStatus = formContext.getAttribute("status").getValue();
        var complianceStatus = formContext.getAttribute("niq_compliancefinancialstatus")?.getValue();
        var tab = formContext.ui.tabs.get("tab_related_sap_accounts");
        var subgridName = "Subgrid_new_1";
        if (tab) 
        {
            var section = tab.sections.get("tab_15_section_1");
            var subgrid = section.controls.get(subgridName);
            var selectedRows = subgrid.getGrid().getSelectedRows();
            var rowId = selectedRows.get(0).getData().getEntity().getId();
            if(selectedRows.getLength() == 0)
            {
                if(accountStatus == 1 || complianceStatus == 610570001 || complianceStatus == 610570004)
                {
                    return false;
                }
                return true;
            }
            return false;  
        }
        return false; 
    },

    //Enable rule for customer account flyout sap account modification request button
    EnableRule_CustomerAccountSAPAccountModificationRequest: function(formContext, selectedControl)
    {
        if(CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User, NIQ Finance User, NIQ Add-On Finance Gatekeeper, NIQ Add On Sales Ops Approver, System Administrator, NIQ Business Admin"))
        {
            var tab = formContext.ui.tabs.get("tab_related_sap_accounts");
            var subgridName = "Subgrid_new_1";
            if (tab) 
            {
                var section = tab.sections.get("tab_15_section_1");
                var subgrid = section.controls.get(subgridName);
                var selectedRows = subgrid.getGrid().getSelectedRows();
                if(selectedRows.getLength() === 1)
                {
                    return true;
                }
                return false;
            }
            return false;
        }
    },

    //SAP Accounts SAP Account Extesnion Request Button Visiblity on SAP form
    EnableRule_SAPAccountFormExtensionRequest: function(primaryControl)
    {
        if(CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User, NIQ Finance User, NIQ Add-On Finance Gatekeeper, NIQ Add On Sales Ops Approver, System Administrator, NIQ Business Admin"))
        {
            var formContext = primaryControl;
            var complianceStatus = formContext.getAttribute("niq_compliancefinancialstatus")?.getValue();
            if(complianceStatus == 610570000 || complianceStatus == 610570001 || complianceStatus == 610570003 || complianceStatus == 610570004)
            {
                return false;
            }
            return true;
        }
    },

    //onclick of New SAP Account Creation Request Button from ALL SAP Accounts list View in Account
    onclickofSAPGridNewSAPAccountCreationRequest: async function(formContext)
    {
        if(CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User, NIQ Finance User, NIQ Add-On Finance Gatekeeper, NIQ Add On Sales Ops Approver, System Administrator, NIQ Business Admin"))
        {
            var formParameters = {};
            formParameters["niq_requesttype"] = 610570000;
            var entityFormOptions = {};
            entityFormOptions["entityName"] = "niq_accountrequest";
            entityFormOptions["formId"] = "c614d23a-c5cd-ef11-8ee9-00224889984b".toUpperCase();
            Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                function (success) { },
                function (error) { }
            );
        }

    },

    //onclick of SAP Account Modification Request Button from All SAP Accounts List view in Account
    onclickofSAPGridSAPAccountModificationRequest: async function(formContext, selectedControl)
    {
        var selectedRows = selectedControl.getGrid().getSelectedRows();
        var row = selectedRows.get(0);
        var userId = Xrm.Utility.getGlobalContext().userSettings.userId;
        var teamid = "047aaf19-7bce-ef11-b8e8-7c1e524e097b"; //mdm team
        var isUserInTeam = false;
        var query = "?$filter=systemuserid eq " + userId + " and teamid eq " + teamid;
        var response = await Xrm.WebApi.retrieveMultipleRecords("teammembership",query);
        if (response.entities.length > 0) 
        {
            isUserInTeam = true;
        }
        if(CommonForm.Events.CheckIfLoggedInUserRole("NIQ Sales User") || isUserInTeam)
        {
            var accountId = row.getData().getEntity().getId();
            accountId = accountId.replace("{", "").replace("}", "");
            var record = await Xrm.WebApi.retrieveRecord("account", accountId, "?$select=name,_niq_ultimateparentid_value");
            var ultimateParent = record["_niq_ultimateparentid_value"];
            var accountLookup = {
                name: record["_niq_ultimateparentid_value@OData.Community.Display.V1.FormattedValue"],
                id: record["_niq_ultimateparentid_value"],
                entityType: "account"
            };

            var formParameters = {};
            formParameters["niq_requesttype"] = 610570001;
            formParameters["niq_customeraccount"] = accountLookup;
            var entityFormOptions = {};
            entityFormOptions["entityName"] = "niq_accountrequest";
            entityFormOptions["formId"] = "00f94f3f-18cf-ef11-b8e8-7c1e524e097b".toUpperCase();
            Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                function (success) { },
                function (error) { }
            );
        }
        else
        {
            var alertStrings = {
                confirmButtonLabel: "OK",
                text:"User does not have proper roles to initiate this request",
                title:"Warning!"
            };
            var alertOptions = {
                height: 120,
                width:260
            };
            Xrm.Navigation.openAlertDialog(alertStrings,alertOptions);
        }

    },

    //onclick of SAP Account extension Request Button from ALL SAP Accounts List view in Account
    onclickofSAPGridSAPAccountExtensionRequest: async function(formContext, selectedControl)
    {
        var selectedRows = selectedControl.getGrid().getSelectedRows();
        var row = selectedRows.get(0);
        var accountId = row.getData().getEntity().getId();
        accountId = accountId.replace("{", "").replace("}", "");
        var record = await Xrm.WebApi.retrieveRecord("account", accountId, "?$select=name");
        var accountName = record["name"];
        var accountLookup = {
            name: accountName,
            id: accountId,
            entityType: "account"
        };

        var formParameters = {};
        formParameters["niq_requesttype"] = 610570002;
        formParameters["niq_customeraccount"] = accountLookup;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_accountrequest";
        entityFormOptions["formId"] = "e69afa5a-1dcf-ef11-b8e9-6045bdf50c47".toUpperCase();
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );

    },

    //onclick of SAP Account Modification Request Button in customer Account form
    OnClick_ModifyCustomerAccountSAPAccountModificationRequest: async function(formContext)
    {
        var tab = formContext.ui.tabs.get("tab_related_sap_accounts");
        var subgridName = "Subgrid_new_1";
        if (tab) 
        {
            var section = tab.sections.get("tab_15_section_1");
            var subgrid = section.controls.get(subgridName);
            var selectedRows = subgrid.getGrid().getSelectedRows();
            var accountId = selectedRows.get(0).getData().getEntity().getId();
            var record = await Xrm.WebApi.retrieveRecord("account", accountId, "?$select=name");
            var accountName = record["name"];
            var accountLookup = {
                id: accountId,
                name: accountName,
                entityType:"account"
            };
            var formParameters = {};
            formParameters["niq_requesttype"] = 610570001;
            formParameters["niq_customeraccount"] = accountLookup;
            var entityFormOptions = {};
            entityFormOptions["entityName"] = "niq_accountrequest";
            entityFormOptions["formId"] = "00f94f3f-18cf-ef11-b8e8-7c1e524e097b".toUpperCase();
            Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );}

    },

    //onclick of SAP Account Extension Request Button in customer Account form
    onclickofCustomerAccountSAPAccountExtensionRequest: async function(formContext)
    {
        var tab = formContext.ui.tabs.get("tab_related_sap_accounts");
        var subgridName = "Subgrid_new_1";
        if (tab) 
        {
            var section = tab.sections.get("tab_15_section_1");
            var subgrid = section.controls.get(subgridName);
            var selectedRows = subgrid.getGrid().getSelectedRows();
            var accountId = selectedRows.get(0).getData().getEntity().getId();
            var record = await Xrm.WebApi.retrieveRecord("account", accountId, "?$select=name");
            var accountName = record["name"];
            var accountLookup = {
                id: accountId,
                name: accountName,
                entityType:"account"
            };
            var formParameters = {};
            formParameters["niq_requesttype"] = 610570002;
            formParameters["niq_customeraccount"] = accountLookup;
            var entityFormOptions = {};
            entityFormOptions["entityName"] = "niq_accountrequest";
            entityFormOptions["formId"] = "e69afa5a-1dcf-ef11-b8e9-6045bdf50c47".toUpperCase();
            Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );}
    },
    //DYNCRM-24892
    NewCustomerAccountCreationRequestButtonVisibility: async function(executionContext){
        'use strict';
        var formContext=executionContext;
        if(await CommonForm.Events.ShowNIQGFKAugRelease() && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User,NIQ Add On Sales Ops Approver,NIQ Business Admin,System Administrator")){
            return true;
        }else{
            return false;
        }
    },
    OnClickOfNewAccountRequest: function (executionContext) {
        "use strict";
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_accountrequest";
        entityFormOptions["formId"] = "279dd486-0e36-f011-8c4e-7c1e528418ea";

        Xrm.Navigation.openForm(entityFormOptions).then(
            function (success) { },
            function (error) { }
        );
    },

    OnClickOfModifyCustomerAccount: async function(SelectedControlSelectedItemIds, executionContext, selectedControl){
        "use strict";
        var formContext = executionContext;
        var name = "";
        var entityName = "";
        var entityId = "";
        var selectedItem = SelectedControlSelectedItemIds[0];
        var selectedControlId = selectedControl;
        var selectedRows = selectedControl.getGrid().getSelectedRows();
        if (selectedRows.getLength() == 1) {
            selectedRows.forEach(function (row) {
                var attributes = row.data.entity.attributes._collection;
                var entity = row.getData().getEntity();
                entityName = row.getData().getEntity().getEntityName();
                entityId = row.getData().getEntity().getId().replace('{', '').replace('}', '');
                name = attributes.name.getValue() ? attributes.name.getValue() : "";
            });
            var results = await Xrm.WebApi.retrieveMultipleRecords("niq_accountrequest", "?$select=niq_requeststatus&$filter=(_niq_customeraccount_value eq '"+entityId+ "' and niq_requesttype eq 610570009 and niq_accounttype eq 1)");
            if (results.entities.length > 0) {
                var counter = 0;
                for (var i = 0; i < results.entities.length; i++){
                    var result = results.entities[i];
                    var requestStatus = result["niq_requeststatus"];
                    if(requestStatus != 610570008 && requestStatus != 610570009 && requestStatus != 610570017 ){
                        counter++;
                        break;
                    }
                }
                if(counter == 0){
                    var lookupAccount = new Array();
                    lookupAccount[0] = new Object();
                    lookupAccount[0].id = entityId;
                    lookupAccount[0].name = name;
                    lookupAccount[0].entityType = "account";

                    var entityFormOptions = {};
                    entityFormOptions["entityName"] = "niq_accountrequest";
                    entityFormOptions["formId"] = "296036e3-0e36-f011-8c4d-6045bd9e6513";

                    var formParameters = {};
                    formParameters["niq_customeraccount"] = lookupAccount;

                    Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                        function (success) { },
                        function (error) { }
                    );
                }
                else{
                    Xrm.Navigation.openAlertDialog({ title: "Warning!", text: "A Modification request already exists for this Customer Account. Only one request can be open at the same time for the same Customer Account." });
                }
                
            }
            else{
                var lookupAccount = new Array();
                    lookupAccount[0] = new Object();
                    lookupAccount[0].id = entityId;
                    lookupAccount[0].name = name;
                    lookupAccount[0].entityType = "account";

                    var entityFormOptions = {};
                    entityFormOptions["entityName"] = "niq_accountrequest";
                    entityFormOptions["formId"] = "296036e3-0e36-f011-8c4d-6045bd9e6513";

                    var formParameters = {};
                    formParameters["niq_customeraccount"] = lookupAccount;

                    Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                        function (success) { },
                        function (error) { }
                    );
            }  
        }
    },
    ModifyCustomerAccountRequestVisibility: function(primaryControl){
        "use strict";
        
        var gridName = " All SAP Accounts"
        var formContext = primaryControl;
        var viewSelector = formContext.getViewSelector();
        var currentView = viewSelector.getCurrentView();
        if (currentView.name != gridName && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User,NIQ MDM Reviewers")) {
            return true;
        } else {
            return false;
        }
        
    },
    ModifyCustomerAccountRequestVisibilityMainForm: function(executionContext){
        "use strict";
        var formContext = executionContext;
        var accountType = formContext.getAttribute("niq_accounttype").getValue();
        if (accountType == 1 && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User,NIQ MDM Reviewers")) {
            return true;
        } else {
            return false;
        }
        
    },

    OnclickModifyCustomerAccountRequestMainForm: async function (executionContext) {
        "use strict";
        var formContext = executionContext;
        
        var customerAccountId = Xrm.Page.data.entity.getId().replace('{', '').replace('}', '');
        var results = await Xrm.WebApi.retrieveMultipleRecords("niq_accountrequest", "?$select=niq_requeststatus&$filter=(_niq_customeraccount_value eq '"+customerAccountId+ "' and niq_requesttype eq 610570009 and niq_accounttype eq 1)");
        
        if (results.entities.length > 0) {
            var counter = 0;
            for (var i = 0; i < results.entities.length; i++){
                var result = results.entities[i];
                var requestStatus = result["niq_requeststatus"];
                if(requestStatus != 610570008 && requestStatus != 610570009 && requestStatus != 610570017 ){
                    counter++;
                    break;
                }
            }
            if(counter == 0){
                var AccountID = formContext.data.entity.getId().replace("{", "").replace("}", "");;

                var lookupAccount = new Array();
                lookupAccount[0] = new Object();
                lookupAccount[0].id = AccountID;
                lookupAccount[0].name = formContext.getAttribute("name").getValue();
                lookupAccount[0].entityType = "account";

                var entityFormOptions = {};
                entityFormOptions["entityName"] = "niq_accountrequest";
                entityFormOptions["formId"] = "296036e3-0e36-f011-8c4d-6045bd9e6513";

                var formParameters = {};
                formParameters["niq_customeraccount"] = lookupAccount;

                    Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                        function (success) { },
                        function (error) { }
                    );
            }
            else{
                Xrm.Navigation.openAlertDialog({ title: "Warning!", text: "A Modification request already exists for this Customer Account. Only one request can be open at the same time for the same Customer Account." });
            }
            
        }
        else{
            var AccountID = formContext.data.entity.getId().replace("{", "").replace("}", "");;

                var lookupAccount = new Array();
                lookupAccount[0] = new Object();
                lookupAccount[0].id = AccountID;
                lookupAccount[0].name = formContext.getAttribute("name").getValue();
                lookupAccount[0].entityType = "account";

                var entityFormOptions = {};
                entityFormOptions["entityName"] = "niq_accountrequest";
                entityFormOptions["formId"] = "296036e3-0e36-f011-8c4d-6045bd9e6513";

                var formParameters = {};
                formParameters["niq_customeraccount"] = lookupAccount;

                    Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                        function (success) { },
                        function (error) { }
                    );
        }  
    }

}