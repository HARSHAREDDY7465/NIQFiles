if (typeof (SalesOrgExtensionRequestForm) === "undefined") {
    SalesOrgExtensionRequestForm = {
        __namespace: true
    };
}

SalesOrgExtensionRequestForm.Events = {

    FormOnload:async function (executionContext) {
        var formContext = executionContext.getFormContext();

        this.OnChange_InvoiceDispatchMethod(executionContext);
        this.OnChange_PortalSelection(executionContext);
        this.lockPaymentTermsForSalesUser(executionContext);
        this.OnLoadFieldVisibilityForMDMTeam(executionContext);
        this.OnLoadFieldVisibilityForSellers(executionContext);
        SalesOrgExtensionRequestForm.Events.AutoPopulatePaymentTerm(executionContext);

        formContext.getAttribute("niq_invoicedispatchmethod").addOnChange(SalesOrgExtensionRequestForm.Events.OnChange_InvoiceDispatchMethod);
        formContext.getAttribute("niq_portalselection").addOnChange(SalesOrgExtensionRequestForm.Events.OnChange_PortalSelection);

    },

    // DYNCRM-22760 - Hide Show PortalSelection based on InvoiceDispatchMethod
    OnChange_InvoiceDispatchMethod: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        let invoiceDispatchMethod = formContext.getAttribute("niq_invoicedispatchmethod").getValue();
        if (invoiceDispatchMethod === 3) { //UPLOAD TO PORTAL
            formContext.getControl("niq_portalselection").setVisible(true);
        } else {
            formContext.getAttribute("niq_portalselection").setValue(null);
            formContext.getControl("niq_portalselection").setVisible(false);
        }

        SalesOrgExtensionRequestForm.Events.OnChange_PortalSelection(executionContext);
    },

    // DYNCRM-22760 - Hide Show UploadToPortalURL based on PortalSelection
    OnChange_PortalSelection: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        let portalSelectionLookup = formContext.getAttribute("niq_portalselection").getValue();
        let masterValue = "";
        if (portalSelectionLookup != undefined && portalSelectionLookup.length > 0) {
            var portalSelectionId = portalSelectionLookup[0].id;
            portalSelectionId = portalSelectionId.replace("{", "").replace("}", "");

            const accountMasterEntity = await Xrm.WebApi.retrieveRecord("niq_sapaccountmastersupportdata", portalSelectionId, "?$select=niq_name,niq_mastervalue");
            if (accountMasterEntity && accountMasterEntity["niq_mastervalue"]) {
                masterValue = accountMasterEntity["niq_mastervalue"].toLowerCase(); 
            }
        }

        if (masterValue === "other") {
            formContext.getControl("niq_uploadtoportalurl").setVisible(true);
        } else {
            formContext.getAttribute("niq_uploadtoportalurl").setValue(null);
            formContext.getControl("niq_uploadtoportalurl").setVisible(false);
        }
    },

    // US-24403 - Child 5 : 2nd Duplicate Check for SAP Accounts
    lockPaymentTermsForSalesUser: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var accountrequest = formContext.getAttribute("niq_accountrequest").getValue()[0].id.replace("{", "").replace("}", "");
        results = await Xrm.WebApi.retrieveMultipleRecords("niq_accountrequest", "?$select=niq_accounttype&$filter=niq_accountrequestid eq " + accountrequest);
        if (results.entities.length > 0) {
            var accountType = results.entities[0]["niq_accounttype"];
            if (accountType === 2) {
                if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User")) {
                    arrFields =["niq_accountpayableapcontact", "niq_Language","niq_paymenttermsid","niq_paymenttermsid"];
                    for (var i = 0; i < arrFields.length; i++) {
                        if (CommonForm.Events.CheckFieldExists(formContext, arrFields[i])) {
                            formContext.getAttribute(arrFields[i]).setRequiredLevel("required");
                        }
                    }
                    formContext.getControl("niq_paymenttermsid").setDisabled(true);
                    formContext.getControl("niq_paymenttermsdescription").setDisabled(true);
                }
            }
        }
        
    },

    //24401 Auto populate payment term based on sales org and ultimate parent account
    AutoPopulatePaymentTerm: async function(executionContext)
    {
        var formContext = executionContext.getFormContext();
        var salesOrg = formContext.getAttribute("niq_salesorg")?.getValue()[0].id.replace("{", "").replace("}", "");
        var accountRequest = formContext.getAttribute("niq_accountrequest")?.getValue()[0].id.replace("{","").replace("}","");
        var results = await Xrm.WebApi.retrieveRecord("niq_accountrequest", accountRequest, "?$select=_niq_customeraccount_value");
        var ultimateAccount = results["_niq_customeraccount_value"];
        try
        {
        var query = `?$select=_niq_paymenttermsmsaid_value&$filter=_niq_salesorgid_value eq ${salesOrg} and _niq_ultimateparentaccountid_value eq ${ultimateAccount} &$orderby=createdon desc &$top=1`;
        var fetch = await Xrm.WebApi.retrieveMultipleRecords("niq_msapaymentterm", query);
        if(fetch.entities.length > 0)
        {
            var res = fetch.entities[0];
            //var account = res["_niq_ultimateparentaccountid_value"];
            var paymentTermLookup = {
                id: res["_niq_paymenttermsmsaid_value"],
                name: res["_niq_paymenttermsmsaid_value@OData.Community.Display.V1.FormattedValue"],
                entityType: "niq_paymentterm"

                };
                var paymentTerm = formContext.getAttribute("niq_paymenttermsid").setValue([paymentTermLookup]);
                var result = await Xrm.WebApi.retrieveMultipleRecords("niq_paymentterm","?$select=niq_paymenttermname");
                var paymentTermDescription = result["niq_paymenttermname"];
                var paymentDescription = formContext.getAttribute("niq_paymenttermsdescription").setValue(paymentTermDescription);
        }
        else if(fetch.entities.length == 0)
        {
            var paymentTermFetch = await Xrm.WebApi.retrieveMultipleRecords("niq_paymentterm", "?$select=niq_paymenttermid,niq_paymenttermcode,niq_paymenttermname&$filter=niq_paymenttermcode eq 'NM01'");
            if(paymentTermFetch.entities.length > 0)
            {
                var payment = paymentTermFetch.entities[0];
                var paymentTermLookup = 
                {
                    id: payment["niq_paymenttermid"],
                    name: payment["niq_paymenttermcode"],
                    entityType: "niq_paymentterm"

                };
                var paymentTerm = formContext.getAttribute("niq_paymenttermsid").setValue([paymentTermLookup]);
                var paymentTermDescription = payment["niq_paymenttermname"];
                var paymentDescription = formContext.getAttribute("niq_paymenttermsdescription").setValue(paymentTermDescription);
            }

        }
        }
        catch (error)
        {
            console.error("Fetch failed:", error.message);
        }
            
        
    },
    
    OnLoadFieldVisibilityForSellers: async function(executionContext){
        var formContext = executionContext.getFormContext();
        var accountrequest = formContext.getAttribute("niq_accountrequest").getValue()[0].id.replace("{", "").replace("}", "");
        results = await Xrm.WebApi.retrieveMultipleRecords("niq_accountrequest", "?$select=niq_requesttype&$filter=niq_accountrequestid eq " + accountrequest);
        if (results.entities.length > 0) {
            var requestType = results.entities[0]["niq_requesttype"];
        }
        
        var arrFields =[]
        if(requestType == 610570000 || requestType == 610570001){
            if(requestType == 610570000){
                arrFields = ["niq_companycode", "niq_invoicedispatchmethod", "niq_malaysiatinnumber", "niq_paymentterms"];
            }
            else if(requestType == 610570001){
                arrFields = ["niq_accountpayableapcontact", "niq_companycode", "niq_malaysiatinnumber"];               
            }
            try {
                if (CommonForm.Events.CheckIfLoggedInUserRole("NIQ Sales User")) {
                    let formControls = formContext.ui.controls;
                    formControls.forEach(control => {
                        if (control.getName() != "" && control.getName() != null) {
                            control.setDisabled(true);
                        }
                    });
                    for (var i = 0; i < arrFields.length; i++) {
                        if (CommonForm.Events.CheckFieldExists(formContext, arrFields[i])) {
                            formContext.getControl(arrFields[i]).setDisabled(false);
                        }
                    }
                }
                
            }
            catch (exception) {
                console.log("Error : " + exception);
            }
        }
    },

    OnLoadFieldVisibilityForMDMTeam: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var accountrequest = formContext.getAttribute("niq_accountrequest").getValue()[0].id.replace("{", "").replace("}", "");
        results = await Xrm.WebApi.retrieveMultipleRecords("niq_accountrequest", "?$select=niq_requesttype&$filter=niq_accountrequestid eq " + accountrequest);
        if (results.entities.length > 0) {
            var requestType = results.entities[0]["niq_requesttype"];
        }
        var arrFields =[]
        if(requestType == 610570000 || requestType == 610570001){
            try {
                var userId = Xrm.Utility.getGlobalContext().userSettings.userId;
                var teamid = "047aaf19-7bce-ef11-b8e8-7c1e524e097b";//MDM Team ID
                var isMDMTeamMember = false;
                var query = "?$filter=systemuserid eq " + userId + " and teamid eq " + teamid;
                var response = await Xrm.WebApi.retrieveMultipleRecords("teammembership", query);
                if (response.entities.length > 0) {
                    isMDMTeamMember = true;
                }

                var complianceTeamId ="ec841307-7bce-ef11-b8e8-7c1e524e097b"; //Compliance Team ID
                var isComplianceTeamMember = false;
                var compliancequery = "?$filter=systemuserid eq " + userId + " and teamid eq " + complianceTeamId
                var complianceResponse = await Xrm.WebApi.retrieveMultipleRecords("teammembership", compliancequery);
                if (complianceResponse.entities.length > 0) {
                    isComplianceTeamMember = true;
                }

                if(requestType == 610570000){
                    arrFields = ["niq_accountingclerk", "niq_accountassigngroup", "niq_arpledging", "niq_companycode", "niq_customergroup1", "niq_customergroup2", "niq_customergroup3", "niq_customergroup4", "niq_customergroup5", "niq_deliveringplant",
                        "niq_district", "niq_housebank", "niq_lockboxkey", "niq_malaysiatinnumber", "niq_partnerfunction", "niq_paymentterms", "niq_periodicacctstatements", "niq_previousnumber", "niq_glaccount", "niq_salesgroup", "niq_salesoffice",
                        "niq_shipperaccountno", "niq_withholdingtaxagent", "niq_withholdingtaxcode", "niq_withholdingtaxtype", "niq_withholdtaxvalidfrom", "niq_withholdtaxvalidto"];
                }
                else if(requestType == 610570001){
                    arrFields = ["niq_accountpayableapcontact", "niq_accountingclerk", "niq_accountassigngroup", "niq_arpledging", "niq_companycode", "niq_customergroup1", "niq_customergroup2", "niq_customergroup3", "niq_customergroup4", "niq_customergroup5",
                        "niq_deliveringplant", "niq_district", "niq_housebank", "niq_lockboxkey", "niq_malaysiatinnumber", "niq_partnerfunction", "niq_paymentterms", "niq_periodicacctstatements", "niq_previousnumber", "niq_glaccount", "niq_salesgroup",
                        "niq_salesoffice", "niq_shipperaccountno", "niq_withholdingtaxagent", "niq_withholdingtaxcode", "niq_withholdingtaxtype", "niq_withholdtaxvalidfrom", "niq_withholdtaxvalidto"];
                }

                if (isMDMTeamMember || isComplianceTeamMember) {
                    let formControls = formContext.ui.controls;
                    formControls.forEach(control => {
                        if (control.getName() != "" && control.getName() != null) {
                            control.setDisabled(true);
                        }
                    });
                    for (var i = 0; i < arrFields.length; i++) {
                        if (CommonForm.Events.CheckFieldExists(formContext, arrFields[i])) {
                            formContext.getControl(arrFields[i]).setDisabled(false);
                        }
                    }
                }
            }
            catch (exception) {
                console.log("Error : " + exception);
            }
        }
    }
}