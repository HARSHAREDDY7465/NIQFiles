  function showSidePane() {
debugger
    //Create the side pane with the icon of choice, agent title etc.
    Xrm.App.sidePanes.createPane({
        title: "SERVA",
        imageSrc: "WebResources/niq_ew_customboticon",
        hideHeader: true,
        canClose: true,
        width:400        
    }).then((pane) => {
        //In the side pane, populate the space with a record view of a specific customer record
        pane.navigate({
               pageType: "webresource",
            webresourceName: "niq_LRAHTML"
        })
    });
}
