if (typeof (JiraRequestForm) === "undefined") {
    JiraRequestForm = {
        __namespace: true
    };
}
var country = [106981,106982,106983,106984,106985,106986,106987,106988,106989,106990,106991,106992,106993,106994,106995,106996,106997,106998,106999,107000,107001,107002,107003,107004,107005,107006,107007,107008,107009,107010,107011,107012,107013,107014,107015,107016,107017,107018,107019,107020,107021,107022,107023,107024,107025,107026,107027,107028,107029,107030,107031,107032,107033,107034,107035,107036,107037,107038,107039,107040,107041,107042,107043,107044,107045,107046,107047,107048,107049,107050,107051,107052,107053,107054,107055,107056,107057,107058,107059,107060,107061,107062];
var category = [107386,107387,107388,107389,107390,107391,107392,107393,107394,107395,107396,107397,107398,107399,107400,107401,107402,107403,107404,107220,107405,107102,109001,107406,107407,107408];
var countryinitialoptions = null;
var categoryinitialoptions = null;
JiraRequestForm.Events = {
    FormOnload: function (executionContext) {
         formContext = executionContext.getFormContext();
         countryinitialoptions = formContext.getControl("niq_country").getOptions();
         categoryinitialoptions = formContext.getControl("niq_category").getOptions();
    },
    ShowHideCountry: function(executionContext,options,IsShow)
    {
        if(!IsShow)
        {
        options.forEach(function (item) {
            formContext.getControl("niq_country").removeOption(item);
          });
        }
    },
    ShowHideCategory: function(executionContext,options,IsShow)
    {
        if(!IsShow)
        {
        options.forEach(function (item) {
            formContext.getControl("niq_category").removeOption(item);
          });
        }
    },
    RegionOnChange: function (executionContext)
    {
        "use strict";
        formContext = executionContext.getFormContext();
        var Region = formContext.getAttribute("niq_region").getText();
        var countryoptions = formContext.getControl("niq_country");

        if(Region != null &&  Region == "ALL")
        {
            formContext.getControl("niq_country").setVisible(false);
            formContext.getAttribute("niq_country").setValue(null);
            formContext.getAttribute("niq_country").setRequiredLevel("none");
        }
        else if(Region != null &&  Region == "EMEA")
        {
            formContext.getControl("niq_country").setVisible(true);
            formContext.getAttribute("niq_country").setRequiredLevel("required");
            var countryforEMEA = [106981,106982,106983,106984,106985,106986,106987,106988,106989,106990,106991,106992,106993,106994,106995,106996,106997,106998,106999,107000,107001,107002,107003,107004,107005,107006,107007,107008,107009,107010,107011,107012,107013,107014,107015,107016,107017,107018,107019,107020,107021,107022,107023,107024,107025,107026,107027,107028,107029,107030,107031];
            JiraRequestForm.Events.ShowHideCountry(executionContext,  country, false);
            formContext.getAttribute("niq_country").setValue(null);
            for (var k = 0; k < countryinitialoptions.length; k++) {
                if (countryforEMEA.indexOf(countryinitialoptions[k].value) > -1) countryoptions.addOption(countryinitialoptions[k]);
            }
            // formContext.getControl("niq_country").addOption(
            // {
            //     value: 106981,
            //     text: "Algeria"
            // },1);
            // formContext.getControl("niq_country").addOption(
            // {
            //         value: 106982,
            //         text: "Austria"
            // },2);
            // formContext.getControl("niq_country").addOption(
            // {
            //             value: 106983,
            //             text: "Baltics"
            // },3);
            // formContext.getControl("niq_country").addOption(
            // {
            //             value: 106984,
            //             text: "Belarus"
            // },4);
            // formContext.getControl("niq_country").addOption(
            // {
            //             value: 106985,
            //             text: "Belgium"
            // },5);
            // formContext.getControl("niq_country").addOption(
            // {
            //         value: 106986,
            //         text: "Bosnia"
            // },6);
            // formContext.getControl("niq_country").addOption(
            // {
            //             value: 106987,
            //             text: "Bulgaria"
            // },7);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 106988,
            //                 text: "Croatia"
            // },8);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 106989,
            //                 text: "Czech Republic"
            // },9);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 106990,
            //                 text: "Denmark"
            // },10);
            // formContext.getControl("niq_country").addOption(
            // {
            //         value: 106991,
            //         text: "Egypt"
            // },11);
            // formContext.getControl("niq_country").addOption(
            // {
            //             value: 106992,
            //             text: "Estonia"
            // },12);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 106993,
            //                 text: "Finland"
            // },13);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 106994,
            //                 text: "France"
            // },14);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 106995,
            //                 text: "Germany"
            // },15);
            // formContext.getControl("niq_country").addOption(
            // {
            //             value: 106996,
            //             text: "Greece"
            // },16);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 106997,
            //                 text: "Hungary"
            // },17);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 106998,
            //                     text: "Iceland"
            // },18);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 106999,
            //                     text: "Ireland"
            // },19);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107000,
            //                     text: "Italy"
            // },20);
            // formContext.getControl("niq_country").addOption(
            // {
            //         value: 107001,
            //         text: "Jordan"
            // },21);
            // formContext.getControl("niq_country").addOption(
            // {
            //             value: 107002,
            //             text: "Kazakhstan"
            // },22);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107003,
            //                 text: "Kenya"
            // },23);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107004,
            //                 text: "Kosovo"
            // },24);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107005,
            //                 text: "Saudi Arabia"
            // },25);
            // formContext.getControl("niq_country").addOption(
            // {
            //             value: 107006,
            //             text: "Kuwait"
            // },26);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107007,
            //                 text: "Latvia"
            // },27);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107008,
            //                     text: "Lebanon"
            // },28);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107009,
            //                     text: "Lithuania"
            // },29);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107010,
            //                     text: "Macedonia"
            // },30);
            // formContext.getControl("niq_country").addOption(
            // {
            //             value: 107011,
            //             text: "Morocco"
            // },31);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107012,
            //                 text: "Netherlands"
            // },32);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107013,
            //                     text: "Nigeria"
            // },33);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107014,
            //                     text: "Norway	"
            // },34);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107015,
            //                     text: "Oman"
            // },35);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107016,
            //                 text: "Poland"
            // },36);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107017,
            //                     text: "Portugal"
            // },37);
            // formContext.getControl("niq_country").addOption(
            // {
            //                         value: 107018,
            //                         text: "Qatar"
            // },38);
            // formContext.getControl("niq_country").addOption(
            // {
            //                         value: 107019,
            //                         text: "Romania"
            // },39);
            // formContext.getControl("niq_country").addOption(
            // {
            //                         value: 107020,
            //                         text: "Russia"
            // },40);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107021,
            //                 text: "Serbia"
            // },41);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107022,
            //                     text: "Slovakia"
            // },42);
            // formContext.getControl("niq_country").addOption(
            // {
            //                         value: 107023,
            //                         text: "Slovenia"
            // },43);
            // formContext.getControl("niq_country").addOption(
            // {
            //                         value: 107024,
            //                         text: "South Africa"
            // },44);
            // formContext.getControl("niq_country").addOption(
            // {
            //                         value: 107025,
            //                         text: "Spain"
            // },45);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107026,
            //                     text: "Sweden"
            // },46);
            // formContext.getControl("niq_country").addOption(
            // {
            //                         value: 107027,
            //                         text: "Switzerland"
            // },47);
            // formContext.getControl("niq_country").addOption(
            // {
            //                             value: 107028,
            //                             text: "Turkey"
            // },48);
            // formContext.getControl("niq_country").addOption(
            // {
            //                             value: 107029,
            //                             text: "United Arab Emirates"
            // },49);
            // formContext.getControl("niq_country").addOption(
            // {
            //                             value: 107030,
            //                             text: "Ukraine"
            // },50);
            // formContext.getControl("niq_country").addOption(
            // {
            //                                 value: 107031,
            //                                 text: "United Kingdom"
            // },51);
        }
        else if(Region != null &&  Region == "APAC")
        {
            formContext.getControl("niq_country").setVisible(true);
            formContext.getAttribute("niq_country").setRequiredLevel("required");
            JiraRequestForm.Events.ShowHideCountry(executionContext,  country, false);
            formContext.getAttribute("niq_country").setValue(null);
            var countryforAPAC = [107032,107033,107034,107035,107036,107037,107038,107039,107040,107041,107042,107043,107044,107045,107046];
            for (var k = 0; k < countryinitialoptions.length; k++) {
                if (countryforAPAC.indexOf(countryinitialoptions[k].value) > -1) countryoptions.addOption(countryinitialoptions[k]);
            }
            // formContext.getControl("niq_country").addOption(
            // {
            //         value: 107032,
            //         text: "Australia"
            // },1);
            // formContext.getControl("niq_country").addOption(
            // {
            //             value: 107033,
            //             text: "China"
            // },2);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107034,
            //                 text: "Hong kong"
            // },3);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107035,
            //                 text: "India"
            // },4);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107036,
            //                 text: "Indonesia"
            // },5);
            // formContext.getControl("niq_country").addOption(
            // {
            //             value: 107037,
            //             text: "Malaysia"
            // },6);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107038,
            //                 text: "Myanmar"
            // },7);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107039,
            //                     text: "New Zealand"
            // },8);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107040,
            //                     text: "Pakistan"
            // },9);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107041,
            //                     text: "Philippines"
            // },10);
            // formContext.getControl("niq_country").addOption(
            // {
            //             value: 107042,
            //             text: "Singapore"
            // },11);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107043,
            //                 text: "South Korea"
            // },12);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107044,
            //                     text: "Taiwan"
            // },13);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107045,
            //                     text: "Thailand"
            // },14);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107046,
            //                     text: "Vietnam"
            // },15);
        }
        else if(Region != null &&  Region == "LATAM")
        {
            formContext.getControl("niq_country").setVisible(true);
            formContext.getAttribute("niq_country").setRequiredLevel("required");
            JiraRequestForm.Events.ShowHideCountry(executionContext,  country, false);
            formContext.getAttribute("niq_country").setValue(null);
            var countryforLATAM = [107047,107048,107049,107050,107051,107052,107053,107054,107055,107056,107057,107058,107059,107060,107061];
            for (var k = 0; k < countryinitialoptions.length; k++) {
                if (countryforLATAM.indexOf(countryinitialoptions[k].value) > -1) countryoptions.addOption(countryinitialoptions[k]);
            }
            // formContext.getControl("niq_country").addOption(
            // {
            //         value: 107047,
            //         text: "Argentina"
            // },1);
            // formContext.getControl("niq_country").addOption(
            // {
            //             value: 107048,
            //             text: "Bolivia"
            // },2);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107049,
            //                 text: "Brazil"
            // },3);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107050,
            //                 text: "Central America"
            // },4);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107051,
            //                 text: "Chile"
            // },5);
            // formContext.getControl("niq_country").addOption(
            // {
            //             value: 107052,
            //             text: "Colombia"
            // },6);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107053,
            //                 text: "Dominican Republic"
            // },7);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107054,
            //                     text: "Ecuador"
            // },8);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107055,
            //                     text: "Mexico"
            // },9);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107056,
            //                     text: "Paraguay"
            // },10);
            // formContext.getControl("niq_country").addOption(
            // {
            //             value: 107057,
            //             text: "Peru"
            // },11);
            // formContext.getControl("niq_country").addOption(
            // {
            //                 value: 107058,
            //                 text: "Puerto Rico"
            // },12);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107059,
            //                     text: "Uruguay"
            // },13);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107060,
            //                     text: "Venezuela"
            // },14);
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107061,
            //                     text: "Canada"
            // },15);
        }
        else if(Region != null &&  Region == "North America")
        {
            formContext.getControl("niq_country").setVisible(true);
            formContext.getAttribute("niq_country").setRequiredLevel("required");
            JiraRequestForm.Events.ShowHideCountry(executionContext,  country, false);
            formContext.getAttribute("niq_country").setValue(null);
            var countryforNA = [107062];
            for (var k = 0; k < countryinitialoptions.length; k++) {
                if (countryforNA.indexOf(countryinitialoptions[k].value) > -1) countryoptions.addOption(countryinitialoptions[k]);
            }
            // formContext.getControl("niq_country").addOption(
            // {
            //                     value: 107062,
            //                     text: "United States of America"
            // },1);
        }
        else
        {
            formContext.getControl("niq_country").setVisible(false);
            formContext.getAttribute("niq_country").setValue(null);
        }
    },
    ApplicationNameOnChange: function (executionContext)
    {
        "use strict";
        formContext = executionContext.getFormContext();
        var AppName = formContext.getAttribute("niq_applicationname").getText();
        var categoryoptions = formContext.getControl("niq_category");
        if(AppName != null &&  AppName == "Discover FrontEnd")
        {
            JiraRequestForm.Events.ShowHideCategory(executionContext,  category, false);
            formContext.getAttribute("niq_category").setValue(null);
            var categoryforDiscoverFrontEnd = [107386,107387,107388,107389,107390,107391,107392,107393,107394,107395,107396,107397,107398,107399,107400,107401,107402,107403,107404,107220];
            for (var k = 0; k < categoryinitialoptions.length; k++) {
                if (categoryforDiscoverFrontEnd.indexOf(categoryinitialoptions[k].value) > -1) categoryoptions.addOption(categoryinitialoptions[k]);
            }
            // formContext.getControl("niq_category").addOption(
            // {
            //         value: 107386,
            //         text: "Application Error"
            // },1);
            // formContext.getControl("niq_category").addOption(
            // {
            //             value: 107387,
            //             text: "Browser issue"
            // },2);
            // formContext.getControl("niq_category").addOption(
            // {
            //                 value: 107388,
            //                 text: "Client Side Issue"
            // },3);
            // formContext.getControl("niq_category").addOption(
            // {
            //                 value: 107389,
            //                 text: "Enhancement Request"
            // },4);
            // formContext.getControl("niq_category").addOption(
            // {
            //                 value: 107390,
            //                 text: "Entitlements Issues"
            // },5);
            // formContext.getControl("niq_category").addOption(
            // {
            //             value: 107391,
            //             text: "Client Functional Inquiry"
            // },6);
            // formContext.getControl("niq_category").addOption(
            // {
            //                 value: 107392,
            //                 text: "Performance Issue"
            // },7);
            // formContext.getControl("niq_category").addOption(
            // {
            //                     value: 107393,
            //                     text: "Report Sharing issue"
            // },8);
            // formContext.getControl("niq_category").addOption(
            // {
            //                     value: 107394,
            //                     text: "Reports not loading"
            // },9);
            // formContext.getControl("niq_category").addOption(
            // {
            //                     value: 107395,
            //                     text: "Data Selector"
            // },10);
            // formContext.getControl("niq_category").addOption(
            // {
            //             value: 107396,
            //             text: "Monitor my Business"
            // },11);
            // formContext.getControl("niq_category").addOption(
            // {
            //                 value: 107397,
            //                 text: "Report Builder"
            // },12);
            // formContext.getControl("niq_category").addOption(
            // {
            //                     value: 107398,
            //                     text: "Find my stuff"
            // },13);
            // formContext.getControl("niq_category").addOption(
            // {
            //                     value: 107399,
            //                     text: "Job Manager"
            // },14);
            // formContext.getControl("niq_category").addOption(
            // {
            //                     value: 	107400,
            //                     text: "Pre Run"
            // },15);
            // formContext.getControl("niq_category").addOption(
            // {
            //                 value: 	107401,
            //                 text: "PAPI"
            // },16);
            // formContext.getControl("niq_category").addOption(
            // {
            //                     value: 	107402,
            //                     text: "BI"
            // },17);
            // formContext.getControl("niq_category").addOption(
            // {
            //                         value: 	107403,
            //                         text: "Code Issue"
            // },18);
            // formContext.getControl("niq_category").addOption(
            // {
            //                         value: 	107404,
            //                         text: "Configuration Change"
            // },19);
            // formContext.getControl("niq_category").addOption(
            // {
            //                         value: 107220,
            //                         text: "Others"
            // },20);
        }
        else if(AppName != null &&  AppName == "Discover BackEnd")
        {
            JiraRequestForm.Events.ShowHideCategory(executionContext,  category, false);
            formContext.getAttribute("niq_category").setValue(null);
            var categoryforDiscoverBackEnd = [107405,107102];
            for (var k = 0; k < categoryinitialoptions.length; k++) {
                if (categoryforDiscoverBackEnd.indexOf(categoryinitialoptions[k].value) > -1) categoryoptions.addOption(categoryinitialoptions[k]);
            }
            // formContext.getControl("niq_category").addOption(
            // {
            //                         value: 	107404,
            //                         text: "DB - Snowflake"
            // },1);
            // formContext.getControl("niq_category").addOption(
            // {
            //                         value: 107220,
            //                         text: "Data Issue"
            // },2);
        }
        else if(AppName != null &&  AppName == "Discover CASE")
        {
            JiraRequestForm.Events.ShowHideCategory(executionContext,  category, false);
            formContext.getAttribute("niq_category").setValue(null);
            var categoryforDiscoverCASE = [109001];
            for (var k = 0; k < categoryinitialoptions.length; k++) {
                if (categoryforDiscoverCASE.indexOf(categoryinitialoptions[k].value) > -1) categoryoptions.addOption(categoryinitialoptions[k]);
            }
            // formContext.getControl("niq_category").addOption(
            // {
            //                             value: 	109001,
            //                             text: "All Issue"
            // },1);
        }
        else if(AppName != null &&  AppName == "OSA")
        {
            JiraRequestForm.Events.ShowHideCategory(executionContext,  category, false);
            formContext.getAttribute("niq_category").setValue(null);
            var categoryforOSA = [107406,107407,107408];
            for (var k = 0; k < categoryinitialoptions.length; k++) {
                if (categoryforOSA.indexOf(categoryinitialoptions[k].value) > -1) categoryoptions.addOption(categoryinitialoptions[k]);
            }
            // formContext.getControl("niq_category").addOption(
            // {
            //                             value: 	107406,
            //                             text: "Airflow Issue"
            // },1);
            // formContext.getControl("niq_category").addOption(
            // {
            //                             value: 	107407,
            //                             text: "CDM Issue"
            // },2);
            // formContext.getControl("niq_category").addOption(
            // {
            //                             value: 	107408,
            //                             text: "NDM Issue"
            // },3);
        }
        else
        {
            formContext.getAttribute("niq_category").setValue(null);
        }
    },
    OnLoadOpenTDRequest: async function (executionContext) 
    {
        "use strict";
		formContext = executionContext.getFormContext();
		var requestid = formContext.getAttribute("niq_request_ref_number")?.getValue()[0].id;
		requestid = requestid.replace("{", "").replace("}", "");
		var request = await Xrm.WebApi.retrieveRecord("incident", requestid, "?$select=niq_istechdurables,niq_recordtype,title");
		var td= request["niq_istechdurables"];
		var recordtype = request["niq_recordtype"];
		var name = request["title"];
		
		if(td && (recordtype == 100000000 || recordtype == 100000001 || recordtype == 100000003))
		{
            var entityFormOptions = {};
            var formParameters = {};
			var refid = new Array();
            refid[0] = new Object();
            refid[0].id = requestid;
            refid[0].name = name;
            refid[0].entityType ="incident" ; 
			formParameters["niq_request_ref_number"]=refid;

            entityFormOptions["entityName"] = "niq_jiraequest";
			entityFormOptions["useQuickCreateForm"] = true;
            entityFormOptions["formId"]="8579B076-0A0A-F011-BAE3-7C1E528418EA";
										 	
			// Open the form.
        Xrm.Navigation.openForm(entityFormOptions,formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });
        formContext.ui.close();
        }
    },

    OnLoadAssignValues : async function(executionContext) 
    {
        "use strict";
		var formContext = executionContext.getFormContext();

        JiraRequestForm.Events.ProjectTypeOnChange(executionContext);

		var requestid = formContext.getAttribute("niq_request_ref_number")?.getValue()[0].id;
		requestid = requestid.replace("{", "").replace("}", "");
		var result = await Xrm.WebApi.retrieveRecord("incident", requestid, "?$select=_customerid_value,niq_countryofwork,niq_geographicalscope,niq_industry,_niq_niqnghsolution_value,_niq_nsssubtopic_value,_niq_nsstopic_value,niq_plannedenddate,prioritycode,ticketnumber,title,createdon");

		var incidentid = result["incidentid"]; 
		var customerid = result["_customerid_value"]; 
		var customerid_name = result["_customerid_value@OData.Community.Display.V1.FormattedValue"];
		var customerid_entityType = result["_customerid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
		
		var countryofwork = result["niq_countryofwork"]; 
        var niq_countryofwork_formatted = result["niq_countryofwork@OData.Community.Display.V1.FormattedValue"];

		var geographicscope = result["niq_geographicalscope"]; 
		var industry = result["niq_industry"]; 
		
		var niqnghsolution = result["_niq_niqnghsolution_value"];
		var niqnghsolution_name= result["_niq_niqnghsolution_value@OData.Community.Display.V1.FormattedValue"];
		var niqnghsolution_entityType = result["_niq_niqnghsolution_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
		
		var nsssubtopic = result["_niq_nsssubtopic_value"];
		var nsssubtopic_name = result["_niq_nsssubtopic_value@OData.Community.Display.V1.FormattedValue"];
		var nsssubtopic_entityType = result["_niq_nsssubtopic_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
		
		var nsstopic = result["_niq_nsstopic_value"];
		var nsstopic_name = result["_niq_nsstopic_value@OData.Community.Display.V1.FormattedValue"];
		var nsstopic_entityType = result["_niq_nsstopic_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
		
		var plannedenddate = result["niq_plannedenddate"]; 
		var prioritycode = result["prioritycode"];
		var ticketnumber = result["ticketnumber"];
		var title = result["title"];
		var createdondatetime = new Date(result["createdon"]);
        
        if(title != null )
        {
		formContext.getAttribute("niq_name").setValue(title);
        }   

        if(ticketnumber != null){
            formContext.getAttribute("niq_jiraticket").setValue(ticketnumber);
        }

        var customer = new Array();
        customer[0] = new Object();
        customer[0].id = customerid;
        customer[0].name = customerid_name;
        customer[0].entityType = customerid_entityType;

        if(customerid != null){
            formContext.getAttribute("niq_customerid").setValue(customer);
        }
        

        var NIQSolution = new Array();
        NIQSolution[0] = new Object();
        NIQSolution[0].id = niqnghsolution;
        NIQSolution[0].name = niqnghsolution_name;
        NIQSolution[0].entityType = niqnghsolution_entityType;

        if(niqnghsolution != null){
            formContext.getAttribute("niq_niqnghsolution").setValue(NIQSolution);
        }

        var NSSSubTopic = new Array();
        NSSSubTopic[0] = new Object();
        NSSSubTopic[0].id = nsssubtopic;
        NSSSubTopic[0].name = nsssubtopic_name;
        NSSSubTopic[0].entityType = nsssubtopic_entityType;

        if(nsssubtopic != null){
            formContext.getAttribute("niq_nsssubtopic").setValue(NSSSubTopic);
        }
        

        var NSSTopic = new Array();
        NSSTopic[0] = new Object();
        NSSTopic[0].id = nsstopic;
        NSSTopic[0].name = nsstopic_name;
        NSSTopic[0].entityType = nsstopic_entityType;

        if(nsstopic != null){
            formContext.getAttribute("niq_nsstopic").setValue(NSSTopic);
        }
        
        if(geographicscope !=null){
            formContext.getAttribute("niq_geographicscope").setValue(geographicscope);
        }
        
        if(industry != null)
        {
            formContext.getAttribute("niq_industry").setValue(industry);
        }
        
        if(plannedenddate != null)
        {
            formContext.getAttribute("niq_plannedenddate").setValue(new Date(plannedenddate));
        }   

        if(prioritycode != null)
        {
            formContext.getAttribute("niq_prioritycode").setValue(prioritycode);
        }

        if(countryofwork != null)
        {
            let countryArray = countryofwork.split(",").map(value => parseInt(value.trim()));

            // let countryArray = Array.isArray(countryofwork) ? countryofwork.map(Number) : [parseInt(countryofwork)];
            console.log(countryofwork);
            console.log(countryArray);
            // formContext.getAttribute("niq_countryofwork").setValue([countryofwork]);
            formContext.getAttribute("niq_countryofwork").setValue(countryArray);
        }

		if(createdondatetime != null){
			formContext.getAttribute("niq_jira_createdondatetime").setValue(createdondatetime);
		}
    },
    //DYNCRM-21831
    ProjectTypeOnChange: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var projectTypeAttribute = formContext.getAttribute("niq_projecttype");
        var countryControl = formContext.getControl("niq_country");
        var countryAttribute = formContext.getAttribute("niq_country");
    
        if (projectTypeAttribute && countryControl && countryAttribute) {
            var projectTypeValue = projectTypeAttribute.getValue();
    
            if (projectTypeValue && projectTypeValue.length > 0) {
                var projectTypeName = projectTypeValue[0].name;
                countryControl.setVisible(projectTypeName === "POS Operations (MIOPS)");
            }
            else {
                countryAttribute.setValue(null);
                countryControl.setVisible(false);
            }
        }
    }
}