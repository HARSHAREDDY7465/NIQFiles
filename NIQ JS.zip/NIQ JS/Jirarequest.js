if (typeof (JiraRequest) === "undefined") {
    JiraRequest = {
        __namespace: true
    };
}

JiraRequest.Events = {

    OnLoadAssignValues : async function(executionContext) 
    {
        "use strict";
		var formContext = executionContext.getFormContext();

		var requestid = formContext.getAttribute("niq_request_ref_number")?.getValue()[0].id;
		requestid = requestid.replace("{", "").replace("}", "");
		var result = await Xrm.WebApi.retrieveRecord("incident", requestid, "?$select=_customerid_value,niq_countryofwork,niq_geographicalscope,niq_industry,_niq_niqnghsolution_value,_niq_nsssubtopic_value,_niq_nsstopic_value,niq_plannedenddate,prioritycode,ticketnumber,title");

		var incidentid = result["incidentid"]; 
		var customerid = result["_customerid_value"]; 
		var customerid_name = result["_customerid_value@OData.Community.Display.V1.FormattedValue"];
		var customerid_entityType = result["_customerid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
		
		var countryofwork = result["niq_countryofwork"]; 
		var geographicscope = result["niq_geographicalscope"]; 
		var industry = result["niq_industry"]; 
		
		var niqnghsolution = result["_niq_niqnghsolution_value"];
		var niqnghsolution_name= result["_niq_niqnghsolution_value@OData.Community.Display.V1.FormattedValue"];
		var niqnghsolution_entityType = result["_niq_niqnghsolution_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
		
		var nsssubtopic = result["_niq_nsssubtopic_value"];
		var nsssubtopic_name = result["_niq_nsssubtopic_value@OData.Community.Display.V1.FormattedValue"];
		var nsssubtopic_entityType = result["_niq_nsssubtopic_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
		
		var nsstopic = result["_niq_nsstopic_value"];
		var nsstopic_name = result["_niq_nsstopic_value@OData.Community.Display.V1.FormattedValue"];
		var nsstopic_entityType = result["_niq_nsstopic_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
		
		var plannedenddate = result["niq_plannedenddate"]; 
		var prioritycode = result["prioritycode"];
		var ticketnumber = result["ticketnumber"];
		var title = result["title"];
        
        if(title != null )
        {
		formContext.getAttribute("niq_name").setValue(title);
        }   

        if(ticketnumber != null){
            formContext.getAttribute("niq_jiraticket").setValue(ticketnumber);
        }

        var customer = new Array();
        customer[0] = new Object();
        customer[0].id = customerid;
        customer[0].name = customerid_name;
        customer[0].entityType = customerid_entityType;

        if(customerid != null){
            formContext.getAttribute("niq_customerid").setValue(customer);
        }
        

        var NIQSolution = new Array();
        NIQSolution[0] = new Object();
        NIQSolution[0].id = niqnghsolution;
        NIQSolution[0].name = niqnghsolution_name;
        NIQSolution[0].entityType = niqnghsolution_entityType;

        if(niqnghsolution != null){
            formContext.getAttribute("niq_niqnghsolution").setValue(NIQSolution);
        }

        var NSSSubTopic = new Array();
        NSSSubTopic[0] = new Object();
        NSSSubTopic[0].id = nsssubtopic;
        NSSSubTopic[0].name = nsssubtopic_name;
        NSSSubTopic[0].entityType = nsssubtopic_entityType;

        if(nsssubtopic != null){
            formContext.getAttribute("niq_nsssubtopic").setValue(NSSSubTopic);
        }
        

        var NSSTopic = new Array();
        NSSTopic[0] = new Object();
        NSSTopic[0].id = nsstopic;
        NSSTopic[0].name = nsstopic_name;
        NSSTopic[0].entityType = nsstopic_entityType;

        if(nsstopic != null){
            formContext.getAttribute("niq_nsstopic").setValue(NSSTopic);
        }
        
        if(geographicscope !=null){
            formContext.getAttribute("niq_geographicscope").setValue(geographicscope);
        }
        
        if(industry != null)
        {
            formContext.getAttribute("niq_industry").setValue(industry);
        }
        
        if(plannedenddate != null)
        {
            formContext.getAttribute("niq_plannedenddate").setValue(plannedenddate);
        }   

        if(prioritycode != null)
        {
            formContext.getAttribute("niq_prioritycode").setValue(prioritycode);
        }

        if(countryofwork != null)
        {
            formContext.getAttribute("niq_countryofwork").setValue([countryofwork]);
        }

        if(createdondatetime != null){
			formContext.getAttribute("niq_jira_createdondatetime").setValue(createdondatetime);
		}
    }
}