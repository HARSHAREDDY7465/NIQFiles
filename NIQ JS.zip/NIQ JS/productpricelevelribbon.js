if (typeof (productpricelevelribbonevents) === "undefined") {
    productpricelevelribbonevents = {
        __namespace: true
    };
}
productpricelevelribbonevents.Events = {
    OnClickOfExtendProductRequest: function (SelectedControlSelectedItemIds, formContext) {
        "use strict";
        var productID = formContext.data.entity.getId().replace("{", "").replace("}", "");;
        
        var lookupSalesrefproduct = new Array();
        lookupSalesrefproduct[0] = new Object();
        lookupSalesrefproduct[0].id = productID;
        lookupSalesrefproduct[0].name = formContext.getAttribute("name").getValue();
        lookupSalesrefproduct[0].entityType = "product";
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_productrequest";
        entityFormOptions["formId"] = "cbd7548f-9e13-f011-9989-000d3a28780f";// Extend Product Request

        var formParameters = {};
        formParameters["niq_requesttype"] = 610570002;
        formParameters["niq_approvalstatus"] = 610570000;
        formParameters["niq_referencedproduct"] = lookupSalesrefproduct;
        // Open the form.
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });

    },

    OnClickOfBlockProductRequest: function (SelectedControlSelectedItemIds, formContext, SelectedControl) {
        "use strict";
        var productID = formContext.data.entity.getId().replace("{", "").replace("}", "");

        var gridControl = SelectedControl;
        
        var arrBlockValues = [];
        var arrSelectedguid = [];
        var lookupSalesrefproduct = new Array();
        lookupSalesrefproduct[0] = new Object();
        lookupSalesrefproduct[0].id = productID;
        lookupSalesrefproduct[0].name = formContext.getAttribute("name").getValue();
        lookupSalesrefproduct[0].entityType = "product";

        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_productrequest";
        entityFormOptions["useQuickCreateForm"] = true;
        
        entityFormOptions["formId"] = "fa389d40-7339-4597-be0b-8324285bceee"; // Block/Unblock Products

        var formParameters = {};
        formParameters["niq_requesttype"] = 610570003;
        
        formParameters["niq_referencedproduct"] = lookupSalesrefproduct;

        var selectedRows = gridControl.getGrid().getSelectedRows();
        selectedRows.forEach(function (selectedRow) {
            var attributes = selectedRow.data.entity.attributes._collection;
            var selectedGuid = selectedRow.data.entity.getId().replace("{", "").replace("}", "");
            var blockValues = attributes.niq_blocked.getValue();
            arrSelectedguid.push(selectedGuid);
            arrBlockValues.push(blockValues);
        });
        if (arrBlockValues.includes(true)) {
            Xrm.Navigation.openAlertDialog({ title: "Warning!", text: "Product is blocked for the selected price list item(s). Please select the correct price list item to continue blocking" });
        } else {
            
            formParameters["niq_selectedpricelistitemguid"] = arrSelectedguid.join(",");
            Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                function (success) {
                    console.log(success);
                },
                function (error) {
                    console.log(error);
                });
        }

    },

    OnClickOfUnblockProductRequest: function (SelectedControlSelectedItemIds, formContext, SelectedControl) {
        "use strict";
        var productID = formContext.data.entity.getId().replace("{", "").replace("}", "");

        var gridControl = SelectedControl;
        
        var arrBlockValues = [];
        var arrSelectedguid = [];
        
        var lookupSalesrefproduct = new Array();
        lookupSalesrefproduct[0] = new Object();
        lookupSalesrefproduct[0].id = productID;
        lookupSalesrefproduct[0].name = formContext.getAttribute("name").getValue();
        lookupSalesrefproduct[0].entityType = "product";

        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_productrequest";
        entityFormOptions["useQuickCreateForm"] = true;
        
        entityFormOptions["formId"] = "fa389d40-7339-4597-be0b-8324285bceee"; // Block/Unblock Product

        var formParameters = {};
        formParameters["niq_requesttype"] = 610570004;
        
        formParameters["niq_referencedproduct"] = lookupSalesrefproduct;

        var selectedRows = gridControl.getGrid().getSelectedRows();
        selectedRows.forEach(function (selectedRow) {
            var attributes = selectedRow.data.entity.attributes._collection;
            var selectedGuid = selectedRow.data.entity.getId().replace("{", "").replace("}", "");
            var blockValues = attributes.niq_blocked.getValue();
            arrSelectedguid.push(selectedGuid);
            arrBlockValues.push(blockValues);
        });
        if (arrBlockValues.includes(false)) {
            Xrm.Navigation.openAlertDialog({ title: "Warning!", text: "Product is unblocked for the selected price list item(s). Please select the correct price list item to continue unblocking" });
        } else {
            
            formParameters["niq_selectedpricelistitemguid"] = arrSelectedguid.join(",");
            // Open the form.
            Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                function (success) {
                    console.log(success);
                },
                function (error) {
                    console.log(error);
                });
        }

    }
}