const AssetStatus = {
    Active: 1001,
    Inactive: 1002,
    Future: 1003
};

// Helper function to retrieve asset names for valid statuses
async function getAssetNamesForStatus(SelectedControlSelectedItemIds, validStatuses) {
    const assetNames = [];
    for (const item of SelectedControlSelectedItemIds) {
        // Retrieve the asset status and asset name for each item
        const asset = await Xrm.WebApi.retrieveRecord("niq_assetconfig", item, "?$select=niq_assetstatus,_niq_originatingopportunity_value,&$expand=niq_asset($select=niq_assetname)");

        // Check if the asset status matches any of the valid statuses
        if (validStatuses.includes(asset.niq_assetstatus)) {
            assetNames.push(asset["niq_asset"]["niq_assetname"]);
        }
    }
    return assetNames;
}

// Helper function to show error dialogs
async function showErrorDialog(action, assetNames) {
    if (assetNames.length > 0) {
        const errorOptions = {
            errorCode: 1234,
            details: `These assets ${assetNames.join(", ")} are not eligible for ${action}`,
            message: `These assets ${assetNames.join(", ")} are not eligible for ${action}`
        };
        await Xrm.Navigation.openErrorDialog(errorOptions);
    }
}

// Generalized Show/Hide Button Logic for Asset Config Subgrid
async function ShowHideAssetConfigSubgridButton(SelectedControlSelectedItemIds, validStatuses) {
    Xrm.Utility.showProgressIndicator();
    try {
        const assetNames = await getAssetNamesForStatus(SelectedControlSelectedItemIds, validStatuses);
        return assetNames.length > 0;
    } finally {
        Xrm.Utility.closeProgressIndicator();
    }
}

// OnClick Handlers (Amend, Apply COLA, Apply PE, Renew)
async function OnClick_Action(SelectedControlSelectedItemIds, actionName, validStatuses) {
    Xrm.Utility.showProgressIndicator();
    try {
        const assetNames = await getAssetNamesForStatus(SelectedControlSelectedItemIds, validStatuses);
        if (assetNames.length > 0) {
            await showErrorDialog(actionName, assetNames);
        }
    } finally {
        Xrm.Utility.closeProgressIndicator();
    }
}

//DYNCRM-22990 Helper function to check if all assets belong to the same opportunity
async function checkIfSameOpportunity(SelectedControlSelectedItemIds) {
    let opportunityId = null;

    for (const item of SelectedControlSelectedItemIds) {
        const asset = await Xrm.WebApi.retrieveRecord("niq_assetconfig", item, "?$select=_niq_originatingopportunity_value");

        if (opportunityId === null) {
            opportunityId = asset["_niq_originatingopportunity_value"];
        } else if (opportunityId !== asset["_niq_originatingopportunity_value"]) {
            return false; // If opportunities are different, return false
        }
    }

    return true; // If all opportunities match
}


//DYNCRM-22990 Individual Action Handlers
// async function OnClick_Amend(SelectedControlSelectedItemIds) {
//     await OnClick_Action(SelectedControlSelectedItemIds, "Amend", [1002]);
// }

async function OnClick_Amend(SelectedControlSelectedItemIds) {

    if (SelectedControlSelectedItemIds && SelectedControlSelectedItemIds !== "") {
        const strIds = SelectedControlSelectedItemIds.toString();
        const arrIds = strIds.split(",");

        for (const assetconfigid of arrIds) {
            try {
                const oppo = await Xrm.WebApi.retrieveMultipleRecords("opportunity", `?$filter=(contains(niq_assetconfigidinput,'${assetconfigid}') and niq_opportunitytype eq 2 and statecode eq 0)`);

                if (oppo.entities.length > 0) {
                    const opportunityLinks = oppo.entities.map(opportunity => {
                        const opportunityId = opportunity["opportunityid"];
                        const opportunityNumber = opportunity["niq_opportunitynumber"];
                        return `<a href="/main.aspx?etn=opportunity&id=${opportunityId}&pagetype=entityrecord">${opportunityNumber}</a>`;
                    });

                    const webResourceUrl = "/WebResources/niq_amendrenewalwarning.html";
                    const windowOptions = {
                        openInNewWindow: true,
                        height: 300,
                        width: 500
                    };

                    Xrm.Navigation.openWebResource(webResourceUrl, windowOptions).then(function (window) {
                        window.displayWarning(opportunityLinks);
                    });

                    saveEvent.preventDefault();
                    return; // Exit the function after showing the alert
                }
            } catch (error) {
                console.error(error.message);
            }
        }
    }


    Xrm.Utility.showProgressIndicator();
    try {
        //DYNCRM-22990 Check if all assets belong to the same opportunity
        const sameOpportunity = await checkIfSameOpportunity(SelectedControlSelectedItemIds);

        if (!sameOpportunity) {
            // Show error if different opportunities are selected
            const errorOptions = {
                errorCode: 1235,
                details: "Please select assets that belong to the same opportunity for amendments.",
                message: "Please select assets that belong to the same opportunity for amendments."
            };
            Xrm.Utility.closeProgressIndicator();
            await Xrm.Navigation.openErrorDialog(errorOptions);
            return; // Exit early
        }

       
        // Proceed with the existing logic (checking status and showing error dialog if necessary)
        const assetNames = await getAssetNamesForStatus(SelectedControlSelectedItemIds, [1002]);
        if (assetNames.length > 0) {
            Xrm.Utility.closeProgressIndicator();
            await showErrorDialog("Amend", assetNames);
        }
        else {
            //DYNCRM-22277 - Create Amended Opportunity
            Xrm.Utility.showProgressIndicator("Creating Amendment Opportunity.");
            var Opportunity = await Xrm.WebApi.retrieveRecord("niq_assetconfig", SelectedControlSelectedItemIds[0], "?$select=_niq_originatingopportunity_value");
            var OpportunityId = Opportunity["_niq_originatingopportunity_value"];
            var result = await Xrm.WebApi.retrieveRecord("niq_configurationsetting", "58679c7b-56c3-ef11-b8e9-0022488795c2", "?$select=niq_to");
            let commaSeparatedGuids = "";
            //DYNCRM-24098 populate amendment values
            SelectedControlSelectedItemIds.forEach((guid, index) => {
                commaSeparatedGuids += guid;
                if (index < SelectedControlSelectedItemIds.length - 1) {
                    commaSeparatedGuids += ",";
                }
            });
            var flowUrl = result["niq_to"];
            const requestData = {
                opportunityId: OpportunityId,
                AssetIds: commaSeparatedGuids
            };

            // Make the HTTP POST request
            fetch(flowUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(requestData)
            })
                .then(response => {
                    if (response.ok) {
                        return response.json();
                    } else {
                        throw new Error("HTTP request failed with status " + response.status);
                    }
                })
                .then(data => {
                    if (data.IsSuccess) {
                        var OppId = data.OpportunityGUID;
                        Xrm.Utility.openEntityForm("opportunity", OppId);
                        Xrm.Utility.closeProgressIndicator();
                    }
                    else {

                    }
                })
                .catch(error => {
                    console.error("Error triggering Power Automate:", error);
                    Xrm.Utility.closeProgressIndicator();
                });
        }
    }
    catch {
        console.error("Error triggering Power Automate:");
    }
}

async function OnClick_HCAmendment(SelectedControlSelectedItemIds) {
    debugger;
    let assetIds = SelectedControlSelectedItemIds.toString();
    Xrm.Utility.showProgressIndicator("Amending Asset.");
    // let assetIds = "8bdf9f7a-a5fa-ef11-bae2-6045bda1abcd,e2955ac0-a7fa-ef11-bae2-6045bda1abcd,8fdf9f7a-a5fa-ef11-bae2-6045bda1abcd,e4955ac0-a7fa-ef11-bae2-6045bda1abcd,";
    let hostOpprtunityId = "18684fe3-5385-4389-b144-19826a22cc75";

    let body = {
        "assetIds": assetIds,
        "hostOpprtunityId": hostOpprtunityId
    };

    let req = new XMLHttpRequest();
    req.open("POST", "https://prod-53.northeurope.logic.azure.com:443/workflows/31dc6395fc2043149e83d221eb2b4cfd/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=YDbR60gDV46VB8ehxV8f5GjPwVDfEVn2Fpdrk2tKabk", true);
    req.setRequestHeader("Content-Type", "application/json");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                debugger;
                // this.response = this.response.replace(/'/g, '"').replace(/,\s*$/, '');
                let resultJson = JSON.parse(this.response);
                console.log(resultJson);
                Xrm.Utility.openEntityForm("opportunity", resultJson.HostOpportunityId);
                Xrm.Utility.closeProgressIndicator();
            } else {
                console.log(this.statusText);
                Xrm.Utility.closeProgressIndicator();
            }
        }
    };
    req.send(JSON.stringify(body));
}


async function OnClick_HCRenewal(SelectedControlSelectedItemIds) {
    debugger;
    Xrm.Utility.showProgressIndicator("Renewing Assets.");
    let assetConfigIds = "8bdf9f7a-a5fa-ef11-bae2-6045bda1abcd,e2955ac0-a7fa-ef11-bae2-6045bda1abcd,19a5cc41-a8fa-ef11-bae2-7c1e528418ea";

    let body = {
        "AssetConfigIdInput": assetConfigIds
        
    };

    let req = new XMLHttpRequest();
    req.open("POST", "https://prod-47.northeurope.logic.azure.com:443/workflows/8ff8b9bfc3a34c7c8154286f7e93a25e/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=aDrkb3e3eQo5yTD7CHv8nTh6tovzd6hvticBo9l5pLo", true);
    req.setRequestHeader("Content-Type", "application/json");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                debugger;
                // this.response = this.response.replace(/'/g, '"').replace(/,\s*$/, '');
                let resultJson = JSON.parse(this.response);
                console.log(resultJson);
                Xrm.Utility.openEntityForm("opportunity", resultJson.HostOpportunityID);
                Xrm.Utility.closeProgressIndicator();
            } else {
                console.log(this.statusText);
                Xrm.Utility.closeProgressIndicator();
            }
        }
    };
    req.send(JSON.stringify(body));
}

async function OnClick_ApplyCOLA(SelectedControlSelectedItemIds) {
    const sameOpportunity = await checkIfSameOpportunity(SelectedControlSelectedItemIds);

    if (!sameOpportunity) {
        // Show error if different opportunities are selected
        const errorOptions = {
            errorCode: 1235,
            details: "Please select assets that belong to the same opportunity for COLA & PE application",
            message: "Please select assets that belong to the same opportunity for COLA & PE application"
        };
        Xrm.Utility.closeProgressIndicator();
        await Xrm.Navigation.openErrorDialog(errorOptions);
        return; // Exit early
    }
    await OnClick_Action(SelectedControlSelectedItemIds, "Apply COLA", [1002]);
    var id = Xrm.Page.ui.formSelector.getCurrentItem().getId();
    Xrm.App.sidePanes.createPane({
        title: "Apply COLA/PE",
        imageSrc: "WebResources/carl_accounticon.svg",
        hideHeader: false,
        canClose: true,
        width: 600
    }).then((pane) => {
        pane.navigate({
            pageType: "webresource",
            webresourceName: "niq_ColaPEDailogue",
        })
    });

    // var entityFormOptions = {};
    //     entityFormOptions["entityName"] = "account";
    //     entityFormOptions["useQuickCreateForm"] = true;
    //     entityFormOptions["formId"] = "a4d72b34-50f4-ef11-be1f-6045bda1abcd";
    //     var formParameters = {};
    //     Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
    //         function (success) {
    //             console.log("Quick Create form opened successfully.");
    //         },
    //         function (error) {
    //             console.log("Error opening Quick Create form: " + error.message);
    //         }
    //     );
}

async function OnClick_ApplyPE(SelectedControlSelectedItemIds) {
    await OnClick_Action(SelectedControlSelectedItemIds, "Apply PE", [1002]);
}

//DYNCRM-22767 - Create Renewal Opportunity
async function OnClick_Renew(SelectedControlSelectedItemIds) {

    if (SelectedControlSelectedItemIds != null && SelectedControlSelectedItemIds != "") {
        var strIds = SelectedControlSelectedItemIds.toString();
        var arrIds = strIds.split(",");
        for (var i = 0; i < arrIds.length; i++) {
            var assetconfigid = arrIds[i];

            var oppo = await Xrm.WebApi.retrieveMultipleRecords("opportunity", "?$select=niq_opportunitynumber&$filter=(contains(niq_assetconfigidinput,'" + assetconfigid + "') and niq_opportunitytype eq 2 and statecode eq 0)");
            if (oppo.entities.length > 0) {


                
                if (oppo.entities.length > 1) {
                    var opportunityNumbers = [];
                    for (var i = 0; i < oppo.entities.length; i++) {
                        opportunityNumbers.push(oppo.entities[i]["niq_opportunitynumber"]);
                    }
                    var numbersString = opportunityNumbers.join(", ");
                    var message = "Other amendment/ renewal opportunity <" + numbersString + "> are currently open for this asset and must be closed before a new renew/ amendment can be initiated. Please review and close existing opportunity before proceeding";
                    
                    await Xrm.Navigation.openAlertDialog({title: "Warning!", text: message });
                }
                else{
                    var opportunityNumbers = [];
                    for (var i = 0; i < oppo.entities.length; i++) {
                        opportunityNumbers.push(oppo.entities[i]["niq_opportunitynumber"]);
                    }
                    var numbersString = opportunityNumbers
                    var message = "Other amendment/ renewal opportunity <" + numbersString + "> is currently open for this asset and must be closed before a new renew/ amendment can be initiated. Please review and close existing opportunity before proceeding";
                    
                    await Xrm.Navigation.openAlertDialog({title: "Warning!", text: message });
                }


                // for (var i = 0; i < oppo.entities.length; i++) {
                //     var opportunityid = oppo.entities[i]["opportunityid"]; // Guid
                //     var opportunitynumber = oppo.entities[i]["niq_opportunitynumber"]; // Text

                //     await Xrm.Navigation.openErrorDialog({ errorCode: "ABC7123", details: "Another amendment/ renewal opportunity <" + opportunitynumber + "> is currently open for this asset and must be closed before a new renew/ amendment can be initiated. Please review and close existing opportunity before proceeding", message: "Another amendment/ renewal opportunity <" + opportunitynumber + "> is currently open for this asset and must be closed before a new renew/ amendment can be initiated. Please review and close existing opportunity before proceeding" });
                // }
                saveEvent.preventDefault();
            }
        }
    }

    if (SelectedControlSelectedItemIds.length > 0) {
        Xrm.Utility.showProgressIndicator("Creating Renewal Opportunity.");

        let invalidStatuses = [1003];
        let isFutureAssetFound = false;
        for (const item of SelectedControlSelectedItemIds) {
            const asset = await Xrm.WebApi.retrieveRecord("niq_assetconfig", item, "?$select=niq_assetstatus,_niq_originatingopportunity_value");

            if (invalidStatuses.includes(asset.niq_assetstatus)) {
                isFutureAssetFound = true;
            }
        }

        if (isFutureAssetFound) {
            const errorOptions = {
                errorCode: 1235,
                details: "You can not create renewal opportunity from Future Assets.",
                message: "You can not create renewal opportunity from Future Assets."
            };
            Xrm.Utility.closeProgressIndicator();
            await Xrm.Navigation.openErrorDialog(errorOptions);
        } else {
            //Retrieve Renewal Opportunity Flow Url Configuration Settings
            var result = await Xrm.WebApi.retrieveRecord("niq_configurationsetting", "f4c5233b-32e5-ef11-8eea-6045bdf50c47", "?$select=niq_to");
            var flowUrl = result["niq_to"];
            const requestData = {
                AssetConfigIdInput: SelectedControlSelectedItemIds.join(",")
            };

            // Make the HTTP POST request
            fetch(flowUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(requestData)
            })
                .then(response => {
                    if (response.ok) {
                        return response.json();
                    } else {
                        throw new Error("HTTP request failed with status " + response.status);
                    }
                })
                .then(data => {
                    if (data.IsSuccess) {
                        var OppId = data.OpportunityGUID;
                        Xrm.Utility.openEntityForm("opportunity", OppId);
                        Xrm.Utility.closeProgressIndicator();
                    }
                    else {

                    }
                })
                .catch(error => {
                    console.error("Error triggering Power Automate:", error);
                    Xrm.Utility.closeProgressIndicator();
                });
        }
    }
}


// Button Visibility Handlers
async function ShowHideAssetConfigSubgridbuttonRenew(SelectedControlSelectedItemIds) {
    var statusFlag = await ShowHideAssetConfigSubgridButton(SelectedControlSelectedItemIds, [AssetStatus.Active, AssetStatus.Inactive]);
    var roleFlag = await checkUserRole(["NIQ Sales User", "System Administrator"]);
    return statusFlag && roleFlag;
}

async function ShowHideAssetConfigSubgridbuttonAmend(SelectedControlSelectedItemIds) {
    var statusFlag = await ShowHideAssetConfigSubgridButton(SelectedControlSelectedItemIds, [AssetStatus.Active, AssetStatus.Future]);
    var roleFlag = await checkUserRole(["NIQ Sales User", "System Administrator"]);
    return statusFlag && roleFlag;
}

async function ShowHideAssetConfigSubgridbuttonApplyCola(SelectedControlSelectedItemIds) {
    return await ShowHideAssetConfigSubgridButton(SelectedControlSelectedItemIds, [AssetStatus.Active, AssetStatus.Future]);
}

async function ShowHideAssetConfigSubgridbuttonApplyPE(SelectedControlSelectedItemIds) {
    return await ShowHideAssetConfigSubgridButton(SelectedControlSelectedItemIds, [AssetStatus.Active, AssetStatus.Future]);
}


async function checkUserRole(rolesToCheck) {
    var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
    if (roles === null) return false;
    var hasRole = false;
    rolesToCheck.forEach(function (role) {
        roles.forEach(function (item) {
            if (item.name.toLowerCase() === role.toLowerCase()) {
                hasRole = true;
            }
        });
    });
    return hasRole;
}



