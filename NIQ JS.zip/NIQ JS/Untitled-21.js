if (typeof (ProductRequestRibbon) === "undefined") {
    ProductRequestRibbon = {
        __namespace: true
    };
}

ProductRequestRibbon.Events = {

    OnClickOfNewProductRequest: function (executionContext) {
        "use strict";
        
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_productrequest";
        entityFormOptions["formId"]="bf8befbc-aa1d-4c0e-97d6-b13a1929a9b2";
        var formParameters = {};
        formParameters["niq_requesttype"] = 610570000;
            // Open the form.
        Xrm.Navigation.openForm(entityFormOptions,formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });

    },

     OnClickOfModifyProductRequest: function (SelectedControlSelectedItemIds, executionContext) 
    {
        "use strict";
    
        var selectedItem = SelectedControlSelectedItemIds[0];
        var lookupSalesrefproduct = new Array();
        lookupSalesrefproduct[0] = new Object();
        lookupSalesrefproduct[0].id = selectedItem.Id;
        lookupSalesrefproduct[0].name = selectedItem.Name;
        lookupSalesrefproduct[0].entityType = selectedItem.TypeName;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_productrequest";
        entityFormOptions["formId"]="dcfc744a-4efe-ef11-bae3-000d3a233456";
    
        var formParameters = {};
        formParameters["niq_requesttype"] = 610570001;
        formParameters["niq_approvalstatus"] = 610570000;
        formParameters["niq_referencedproduct"]=lookupSalesrefproduct;
            // Open the form.
        Xrm.Navigation.openForm(entityFormOptions,formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });
    
    },
    OnClickOfExtendProductRequest: function (SelectedControlSelectedItemIds, executionContext) 
    {
        "use strict";
        
        var selectedItem = SelectedControlSelectedItemIds[0];
        var lookupSalesrefproduct = new Array();
        lookupSalesrefproduct[0] = new Object();
        lookupSalesrefproduct[0].id = selectedItem.Id;
        lookupSalesrefproduct[0].name = selectedItem.Name;
        lookupSalesrefproduct[0].entityType = selectedItem.TypeName;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_productrequest";
        entityFormOptions["formId"]="cb0169e1-f3ff-ef11-bae3-6045bda1abcd";
    
        var formParameters = {};
        formParameters["niq_requesttype"] = 610570002;
        formParameters["niq_approvalstatus"] = 610570000;
        formParameters["niq_referencedproduct"]=lookupSalesrefproduct;
            // Open the form.
        Xrm.Navigation.openForm(entityFormOptions,formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });
        
    },

    OnClickOfBlockProductRequest:  function (SelectedControlSelectedItemIds, executionContext) 
    {
        "use strict";
        
        for(var i=0; i<SelectedControlSelectedItemIds.length; i++){
            var selectedItem = SelectedControlSelectedItemIds[i];
            
            var lookupSalesrefproduct = new Array();
            lookupSalesrefproduct[0] = new Object();
            lookupSalesrefproduct[0].id = selectedItem.Id;
            lookupSalesrefproduct[0].name = selectedItem.Name;
            lookupSalesrefproduct[0].entityType = selectedItem.TypeName;           
 
            var entityFormOptions = {};
            entityFormOptions["entityName"] = "niq_productrequest";
            entityFormOptions["openInNewWindow"] = true;
            entityFormOptions["formId"]="8599148a-f202-f011-bae3-000d3a233456";

            var formParameters = {};
            formParameters["niq_requesttype"] = 610570003;
            formParameters["niq_approvalstatus"] = 610570000;
            formParameters["niq_referencedproduct"]=lookupSalesrefproduct;
			// Open the form.
        Xrm.Navigation.openForm(entityFormOptions,formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });
        }
    },

    OnClickOfUnblockProductRequest: function (SelectedControlSelectedItemIds, executionContext) 
    {
        "use strict";
        for(var i=0; i<SelectedControlSelectedItemIds.length; i++){
            var selectedItem = SelectedControlSelectedItemIds[i];
            
            var lookupSalesrefproduct = new Array();
            lookupSalesrefproduct[0] = new Object();
            lookupSalesrefproduct[0].id = selectedItem.Id;
            lookupSalesrefproduct[0].name = selectedItem.Name;
            lookupSalesrefproduct[0].entityType = selectedItem.TypeName;
        
            var entityFormOptions = {};
            entityFormOptions["entityName"] = "niq_productrequest";
            entityFormOptions["openInNewWindow"] = true;
            entityFormOptions["formId"]="faf01358-87f2-ef11-be1f-7c1e525fbcd7";
        
            var formParameters = {};
            formParameters["niq_requesttype"] = 610570004;
            formParameters["niq_approvalstatus"] = 610570000;
            formParameters["niq_referencedproduct"]=lookupSalesrefproduct;
            // Open the form.
        Xrm.Navigation.openForm(entityFormOptions,formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });
        }
    },

    OnClickOfBulkProductRequest: function (executionContext) 
    {
        "use strict";
        debugger;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_productrequest";
        entityFormOptions["formId"]="9c141e68-87f2-ef11-be1f-7c1e5274157c";
    
        var formParameters = {};
        formParameters["niq_requesttype"] = 610570005;
            // Open the form.
        Xrm.Navigation.openForm(entityFormOptions,formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });
    
    },

    ProductRequestButtonsVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckIfLoggedInUserRoles("Finance Business Partner,System Administrator")) {
            return true;
        }
        else {
            return false;
        }
    },
	ProductRequestModifyButtonVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckIfLoggedInUserRoles("Finance Business Partner,System Administrator,Material Master")) {
            return true;
        }
        else {
            return false;
        }
    },


   OnSelectOfModifyProductRequest: function(executionContext){
    "use strict";
    var formContext = executionContext;
    
    var product = new Array();
    product[0] = new Object();
    product[0].id = formContext.data.entity.getId();
    product[0].name = formContext.getAttribute("name").getValue();
    product[0].entityType = "product";

    var formParameters = {};
    formParameters['niq_referencedproduct']= product;
    formParameters['niq_requesttype'] = 610570001;
    formParameters['niq_approvalstatus'] = 	610570000;

    var entityFormOptions = {};
    entityFormOptions["entityName"] = "niq_productrequest";
    // entityFormOptions["createFromEntity"]= product[0];
    entityFormOptions["formId"]="dcfc744a-4efe-ef11-bae3-000d3a233456";
    
        // Open the form.
    Xrm.Navigation.openForm(entityFormOptions,formParameters).then(
        function (success) {
            console.log(success);
        },
        function (error) {
            console.log(error);
        });

   },


   OnSelectOfExtendProductRequest: function(executionContext){
    "use strict";
    var formContext = executionContext;
    
    var product = new Array();
    product[0] = new Object();
    product[0].id = formContext.data.entity.getId();
    product[0].name = formContext.getAttribute("name").getValue();
    product[0].entityType = "product";

    var formParameters = {};
    formParameters['niq_referencedproduct']= product;
    formParameters['niq_requesttype'] = 610570002;
    formParameters['niq_approvalstatus'] = 	610570000;

    var entityFormOptions = {};
    entityFormOptions["entityName"] = "niq_productrequest";
    //entityFormOptions["createFromEntity"]= product[0];
    entityFormOptions["formId"]="cb0169e1-f3ff-ef11-bae3-6045bda1abcd";
    
        // Open the form.
    Xrm.Navigation.openForm(entityFormOptions,formParameters).then(
        function (success) {
            console.log(success);
        },
        function (error) {
            console.log(error);
        });

   }
    

}

