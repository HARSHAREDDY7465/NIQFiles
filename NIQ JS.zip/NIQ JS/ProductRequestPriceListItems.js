if (typeof (ProductRequestPriceListItems) === "undefined") {
    ProductRequestPriceListItems = {
        __namespace: true
    };
}
ProductRequestPriceListItems.Events = {
    FormOnloadBlock: function(executionContext){
        "use strict";
        var formContext = executionContext.getFormContext();
        this.showHideFieldForMMProductRequestPriceListItem(executionContext);
        this.hideBlockCode(executionContext);
        this.setMandatoryfields(executionContext);
        this.MethodOnChangeEvent(executionContext);
        
    },
    MethodOnChangeEvent: function(executionContext){
        var formContext = executionContext.getFormContext();
        formContext.getAttribute("niq_pricelist").addOnChange(this.setMandatoryfields);
    },
    FormOnload: function (executionContext) {

        "use strict";
        var formContext = executionContext.getFormContext();
        this.fetchAndDisplayRelatedRecords(executionContext);
       
    },
    fetchAndDisplayRelatedRecords(executionContext) {
        var formContext = executionContext.getFormContext();
        var productRequestId = formContext.getAttribute("niq_productrequest");
        var priceList = formContext.getAttribute("niq_pricelist");

        if (productRequestId) {
            productRequestIdValue= productRequestId.getValue();
            productRequestIdValue = productRequestIdValue[0].id.replace("{", "").replace("}", ""); // Assuming it's a lookup field
            priceList= priceList.getValue();
            priceList= priceList[0].id.replace("{", "").replace("}", "");
            const fetchXml = `
                            <fetch version="1.0" output-format="xml-platform" mapping="logical">
                                <entity name="niq_productrequestmaterialtaxcategory">
                                    <attribute name="niq_name" />
                                    <attribute name="createdon" />
                                    <attribute name="niq_taxcategoryoption" />
                                    <attribute name="niq_productrequestmaterialtaxcategoryid" />
                                    <order attribute="niq_name" descending="false" />
                                    <filter type="and">
                                        <condition attribute="statecode" operator="eq" value="0" />
                                        <condition attribute="niq_productrequest" operator="eq" value="${productRequestIdValue}" />
                                        <condition attribute="niq_pricelist" operator="eq" value="${priceList}" />
                                    </filter>
                                </entity>
                            </fetch>
                            `;
            var gridControl = formContext.getControl("productrequestmaterialtaxcategory");
            gridControl.setFilterXml(fetchXml);
            gridControl.refresh();
        } 
    },

    showHideFieldForMMProductRequestPriceListItem: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var fieldsList = ["niq_discontinuereason"];
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master, NIQ Finance Business Partner")) {
            formContext.data.entity.attributes.forEach(function (attr) {
                var fld = attr.getName();
                if (!fieldsList.includes(fld)) {
                    attr.controls.forEach(function (control) {
                        control.setDisabled(true);
                    });
                }
            });
        }
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner")){
            formContext.getControl("niq_itemcategorygroups").setDisabled(true);
        }
        
    },
    // US-21707
    hideBlockCode: async function(executionContext){
        var formContext = executionContext.getFormContext();
        var reqproduct =formContext.getAttribute("niq_productrequest").getValue();
        if(reqproduct!=null){
            var requestproductId= reqproduct[0].id.replace("{", "").replace("}","");
            var result= await Xrm.WebApi.retrieveRecord("niq_productrequest", requestproductId , "?$select=niq_requesttype");
            var reqtype = result["niq_requesttype"];
            console.log(reqtype);
            if(reqtype == 610570003 || reqtype == 610570004){
                formContext.getControl("niq_discontinuereason").setVisible(true);
                formContext.getAttribute("niq_discontinuereason").setRequiredLevel("required");
                formContext.getAttribute("niq_materialgroup4").setRequiredLevel("none");
            }
            else{
                formContext.getControl("niq_discontinuereason").setVisible(false);
                formContext.getAttribute("niq_discontinuereason").setRequiredLevel("none");
                formContext.getAttribute("niq_materialgroup4").setRequiredLevel("required");
                if(reqtype == 610570000){
                formContext.getAttribute("niq_glaccount_aagcode").setRequiredLevel("required");
                }
            }
        }  
    },
    //US- 21707
    setMandatoryfields: async function(executionContext) {
        var formContext = executionContext.getFormContext();
        var pricelist = formContext.getAttribute("niq_pricelist").getValue();
        if (pricelist != null) {
            var pricelistitem = pricelist[0].id.replace("{", "").replace("}", "");
            var result = await Xrm.WebApi.retrieveRecord("pricelevel", pricelistitem, "?$select=_niq_salesorg_value&$expand=niq_SalesOrg($select=_niq_operatingcountryid_value)");
            if (result.hasOwnProperty("niq_SalesOrg") && result["niq_SalesOrg"] !== null) {
                var countryId = result["niq_SalesOrg"]["_niq_operatingcountryid_value"];
                var country = await Xrm.WebApi.retrieveRecord("niq_country", countryId, "?$select=niq_name");
                console.log(country["niq_name"])
                if (country["niq_name"] == 'India') {
                    formContext.getAttribute("niq_controlcode").setRequiredLevel("required");
                }
                else if (country["niq_name"] == 'Brazil') {
                    formContext.getAttribute("niq_valuationclass").setRequiredLevel("required");
                    formContext.getAttribute("niq_pricecontrolindicator").setRequiredLevel("required");
                }              
            }
        }
        else{
                formContext.getAttribute("niq_controlcode").setRequiredLevel("none");
                formContext.getAttribute("niq_valuationclass").setRequiredLevel("none");
                formContext.getAttribute("niq_pricecontrolindicator").setRequiredLevel("none");
            }
    },

    onSaveFieldsBlock: function (executionContext){
        var formContext = executionContext.getFormContext();
        if (!CommonForm.Events.CheckValueExists(formContext, "niq_defaultunit")) {
            var lookupSalesGroupOrgValue = new Array();
            lookupSalesGroupOrgValue[0] = new Object();
            lookupSalesGroupOrgValue[0].id = "{f454f101-780e-ed11-82e4-6045bd8e1d19}";
            lookupSalesGroupOrgValue[0].name = "Each";
            lookupSalesGroupOrgValue[0].entityType = "uom";
            formContext.getAttribute("niq_defaultunit").setValue(lookupSalesGroupOrgValue);
        }
    },
       
}