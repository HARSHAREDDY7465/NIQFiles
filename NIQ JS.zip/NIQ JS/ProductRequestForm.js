if (typeof (ProductRequestForm) === "undefined") {
    ProductRequestForm = {
        __namespace: true
    };
}
ProductRequestForm.Events = {

    FormOnloadBlock: function (executionContext) {

        "use strict";
        var formContext = executionContext.getFormContext();
        this.OpenFormBasedOnRecordType(executionContext);
        this.enableApproverCommentsField(executionContext);
        this.removeApprovedStatusOptionsBasedonRole(executionContext);
        this.enableRequestorCommentsField(executionContext);
    },
    FormOnload: function (executionContext) {

        "use strict";
        var formContext = executionContext.getFormContext();
        this.OpenFormBasedOnRecordType(executionContext);
        this.enableApproverCommentsField(executionContext);
        this.showHideTabAndFieldForMM(executionContext);
        this.removeApprovedStatusOptionsBasedonRole(executionContext);
        this.mandatoryFieldsBasedOnEnabledForUS(executionContext);
        this.setFieldsMandatory(executionContext);
        this.setproductIdMandatory(executionContext);
    },
    setproductIdMandatory: function(executionContext){
        var formContext = executionContext.getFormContext();
        var reqtype= formContext.getAttribute("niq_requesttype").getValue();
        if(reqtype==610570000){
            formContext.getAttribute("niq_productid").setRequiredLevel("required");
            formContext.getAttribute("niq_productdescription").setRequiredLevel("required");
        }
    },
    enableApproverCommentsField: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var reqtype= formContext.getAttribute("niq_requesttype").getValue();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")) {
            if(reqtype == 610570000 || reqtype == 610570002) //New and Extend requests
            {
                formContext.getControl("niq_approvercomment").setDisabled(false);
                formContext.getAttribute("niq_approvercomment").setRequiredLevel("required");
            }
            else if(reqtype == 610570003 || reqtype == 610570004) // Block or Unblock requests
            {
                formContext.getControl("niq_approvercomment").setDisabled(false);
                formContext.getAttribute("niq_approvercomment").setRequiredLevel("required");
                formContext.getControl("niq_approvalstatus").setDisabled(false);
                formContext.getControl("niq_requestorcomment").setDisabled(true);
                formContext.getControl("niq_distributionchannel").setDisabled(true);
            } 
        }
        else if(CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner")){
            formContext.getControl("niq_approvercomment").setDisabled(true); 
        }
    },
    enableRequestorCommentsField: function (executionContext) {
        var formContext = executionContext.getFormContext();

        if (CommonForm.Events.CheckIfLoggedInUserRoles("System Administrator,NIQ Finance Business Partner,System Customizer")) {
            formContext.getControl("niq_requestorcomment").setDisabled(false);
        }
        else {
            formContext.getControl("niq_requestorcomment").setDisabled(true);
        }
    },
    showHideTabAndFieldForMM: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var fieldsList = ["niq_approvalstatus", "niq_externalmaterialgrouptaxcode"];
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")) {
            formContext.data.entity.attributes.forEach(function (attr) {
                var fld = attr.getName();
                if (!fieldsList.includes(fld)) {
                    attr.controls.forEach(function (control) {
                        control.setDisabled(true);
                    });
                }
            });
        }
    },
    removeApprovedStatusOptionsBasedonRole: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")) {
            formContext.getControl("niq_approvalstatus").removeOption(610570000);
            formContext.getControl("niq_approvalstatus").removeOption(610570004);
        }
        else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner")) {
            var approvalstatus = formContext.getAttribute("niq_approvalstatus").getValue();
            if(approvalstatus == 610570002 || approvalstatus == 610570003 || approvalstatus ==610570004){
                formContext.getControl("niq_approvalstatus").setDisabled(true);
            }
            else{
                formContext.getControl("niq_approvalstatus").removeOption(610570002);
                formContext.getControl("niq_approvalstatus").removeOption(610570004);
                formContext.getControl("niq_approvalstatus").removeOption(610570003);
            }
        }
    },
    mandatoryFieldsBasedOnEnabledForUS: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var enabledforus = formContext.getAttribute("niq_enabledforus").getValue();
        if (!enabledforus) {
            formContext.getAttribute("niq_deliverymethod").setRequiredLevel("none");
            formContext.getAttribute("niq_deliveryfrequency").setRequiredLevel("none");
            formContext.getAttribute("niq_datatype").setRequiredLevel("none");
            formContext.getAttribute("niq_productdeliverytype").setRequiredLevel("none");
            formContext.getAttribute("niq_subscriptionaccessmode").setRequiredLevel("none");
            formContext.getAttribute("niq_chargetype").setRequiredLevel("none");
            formContext.getAttribute("niq_licensingoptionavailable").setRequiredLevel("none");
            formContext.getAttribute("niq_periodicupdatesavailable").setRequiredLevel("none");
            formContext.getAttribute("niq_externalmaterialgrouptaxcode").setRequiredLevel("none");
        }
        else {
            formContext.getAttribute("niq_deliverymethod").setRequiredLevel("required");
            formContext.getAttribute("niq_deliveryfrequency").setRequiredLevel("required");
            formContext.getAttribute("niq_datatype").setRequiredLevel("required");
            formContext.getAttribute("niq_productdeliverytype").setRequiredLevel("required");
            formContext.getAttribute("niq_subscriptionaccessmode").setRequiredLevel("required");
            formContext.getAttribute("niq_chargetype").setRequiredLevel("required");
            formContext.getAttribute("niq_licensingoptionavailable").setRequiredLevel("required");
            formContext.getAttribute("niq_periodicupdatesavailable").setRequiredLevel("required");
            formContext.getAttribute("niq_externalmaterialgrouptaxcode").setRequiredLevel("required");
        }
    },
    onSaveFieldsBlock: function (executionContext){
        var formContext = executionContext.getFormContext();
        if (!CommonForm.Events.CheckValueExists(formContext, "niq_distributionchannel")) {
            var lookupSalesGroupOrgValue = new Array();
            lookupSalesGroupOrgValue[0] = new Object();
            lookupSalesGroupOrgValue[0].id = "{58c3ff5d-bff2-ef11-be20-7c1e52519bcf}";
            lookupSalesGroupOrgValue[0].name = "Nielsen Dist. Channel";
            lookupSalesGroupOrgValue[0].entityType = "niq_sapproductmastersupportdata";
            formContext.getAttribute("niq_distributionchannel").setValue(lookupSalesGroupOrgValue);
        }
    },
    setFieldsMandatory: function(executionContext)
    {
        var formContext = executionContext.getFormContext();
        var reqtype= formContext.getAttribute("niq_requesttype").getValue();
        if(reqtype == 610570000) // New type
        {
            formContext.getAttribute("niq_brandlevel1").setRequiredLevel("required");
            formContext.getAttribute("niq_brandlevel2").setRequiredLevel("required");
            formContext.getAttribute("niq_brandlevel3").setRequiredLevel("required");
            formContext.getAttribute("niq_brandlevel4").setRequiredLevel("required");
            formContext.getAttribute("niq_defaultpricelist").setRequiredLevel("required");
            formContext.getAttribute("niq_enabledforus").setRequiredLevel("required");
            formContext.getAttribute("niq_materialgroup").setRequiredLevel("required");
        }
    },

    MethodOnChangeEvent: function(executionContext){
        var formContext = executionContext.getFormContext();
        formContext.getAttribute("niq_productid").addOnChange(this.checkProductIdValid);
    },
    onSaveFields: function (executionContext) {
        
        formContext.getAttribute("niq_brandlevel1").setRequiredLevel("required");
        formContext.getAttribute("niq_brandlevel2").setRequiredLevel("required");
        formContext.getAttribute("niq_brandlevel3").setRequiredLevel("required");
        formContext.getAttribute("niq_brandlevel4").setRequiredLevel("required");
        formContext.getAttribute("niq_defaultpricelist").setRequiredLevel("required");
        formContext.getAttribute("niq_enabledforus").setRequiredLevel("required");
        formContext.getAttribute("niq_materialgroup").setRequiredLevel("required");
        if (!CommonForm.Events.CheckValueExists(formContext, "niq_statisticsgroup")) {
            var statisticGroup = new Array();
            statisticGroup[0] = new Object();
            statisticGroup[0].id = "{4ac3ff5d-bff2-ef11-be20-7c1e52519bcf}";
            statisticGroup[0].name = "MI SD Materials";
            statisticGroup[0].entityType = "niq_sapproductmastersupportdata";
            formContext.getAttribute("niq_statisticsgroup").setValue(statisticGroup);
        }
        if (!CommonForm.Events.CheckValueExists(formContext, "niq_industry")) {
            var lookupSalesGroupOrgValue = new Array();
            lookupSalesGroupOrgValue[0] = new Object();
            lookupSalesGroupOrgValue[0].id = "{54c3ff5d-bff2-ef11-be20-7c1e52519bcf}";
            lookupSalesGroupOrgValue[0].name = "TNC Services";
            lookupSalesGroupOrgValue[0].entityType = "niq_sapproductmastersupportdata";
            formContext.getAttribute("niq_industry").setValue(lookupSalesGroupOrgValue);
        }
        if (!CommonForm.Events.CheckValueExists(formContext, "niq_materialtype")) {
            var lookupSalesGroupOrgValue = new Array();
            lookupSalesGroupOrgValue[0] = new Object();
            lookupSalesGroupOrgValue[0].id = "{56c3ff5d-bff2-ef11-be20-7c1e52519bcf}";
            lookupSalesGroupOrgValue[0].name = "TNC Service Material Type";
            lookupSalesGroupOrgValue[0].entityType = "niq_sapproductmastersupportdata";
            formContext.getAttribute("niq_materialtype").setValue(lookupSalesGroupOrgValue);
        }
        if (!CommonForm.Events.CheckValueExists(formContext, "niq_distributionchannel")) {
            var lookupSalesGroupOrgValue = new Array();
            lookupSalesGroupOrgValue[0] = new Object();
            lookupSalesGroupOrgValue[0].id = "{58c3ff5d-bff2-ef11-be20-7c1e52519bcf}";
            lookupSalesGroupOrgValue[0].name = "Nielsen Dist. Channel";
            lookupSalesGroupOrgValue[0].entityType = "niq_sapproductmastersupportdata";
            formContext.getAttribute("niq_distributionchannel").setValue(lookupSalesGroupOrgValue);
        }
        if (!CommonForm.Events.CheckValueExists(formContext, "niq_defaultunit")) {
            var lookupSalesGroupOrgValue = new Array();
            lookupSalesGroupOrgValue[0] = new Object();
            lookupSalesGroupOrgValue[0].id = "{f454f101-780e-ed11-82e4-6045bd8e1d19}";
            lookupSalesGroupOrgValue[0].name = "Each";
            lookupSalesGroupOrgValue[0].entityType = "uom";
            formContext.getAttribute("niq_defaultunit").setValue(lookupSalesGroupOrgValue);
        }

        
    },
    OpenCreateSalesOrgExtensionLookupObjects: async function (formContext) {
        const productRequestId = formContext.data.entity.getId();
        var refProductID = formContext.getAttribute("niq_referencedproduct");
        let recordsList = [];    
        var lookupOptions={};
        if (refProductID && refProductID.getValue() && refProductID.getValue().length>0) {
            refProductID = refProductID.getValue()[0].id.replace("{", "").replace("}", "");;
            const fetchXml = `
                <fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
                <entity name="productpricelevel">
                    <filter type="and">
                    <condition attribute="productid" operator="eq" value="${refProductID}" />
                    </filter>
                    <link-entity name="pricelevel" from="pricelevelid" to="pricelevelid" visible="false" link-type="outer" alias="pricelist">
                    <attribute name="pricelevelid" />
                    </link-entity>
                </entity>
                </fetch>
                `;
 
                var productPriceLevelResult = await Xrm.WebApi.retrieveMultipleRecords("productpricelevel", "?fetchXml=" + encodeURIComponent(fetchXml));
    
                if (productPriceLevelResult.entities.length > 0) {
                    productPriceLevelResult.entities.forEach(record => {
                        recordsList.push({
                            priceListCode: record["pricelist.pricelevelid"]
                        });
                    });
            
                    const valueConditions = recordsList.map(value => `<value>${value.priceListCode}</value>`).join("");
                    var lookupOptions =
                    {
                        defaultEntityType: "pricelevel",
                        entityTypes: ["pricelevel"],
                        allowMultiSelect: true,
                        defaultViewId: "71378653-4929-4d8b-a2ed-6172c4318220",
                        viewIds: ["71378653-4929-4d8b-a2ed-6172c4318220"],
                        searchText: "",
                        filters: [
                            {
                                entityLogicalName: "pricelevel", // Logical name of the entity
                                filterXml: `
                                    <filter type="and">
                                        <condition attribute="niq_pricelistcode" operator="not-in">
                                            ${valueConditions}
                                        </condition>
                                    </filter>
                                `
                            }
                        ]
                    };
                } 
               
        } else{
            var lookupOptions =
            {
                defaultEntityType: "pricelevel",
                entityTypes: ["pricelevel"],
                allowMultiSelect: true,
                defaultViewId: "71378653-4929-4d8b-a2ed-6172c4318220",
                viewIds: ["71378653-4929-4d8b-a2ed-6172c4318220"],
                searchText: "",
                filters: []
            };
        }
       

        Xrm.Utility.lookupObjects(lookupOptions).then(
            function (success) {
                console.log(success);
                if (success.length > 0) {
                    for (let i = 0; i < success.length; i++) {
                        ProductRequestForm.Events.CreateSalesOrgExtensionRecord(formContext, success[i]);
                    }
                }


            },
            function (error) {
                console.log(error);
            });
    },

    CreateSalesOrgExtensionRecord: async function (formContext, salesOrgObj) {
        let productRequestId = formContext.data.entity.getId();
        productRequestId = productRequestId.replace("{", "").replace("}", "");

        let salesOrgId = salesOrgObj.id;
        salesOrgId = salesOrgId.replace("{", "").replace("}", "");
        var record = {};
        record["niq_PriceList@odata.bind"] = "/pricelevels(" + salesOrgId + ")";
        record["niq_ProductRequest@odata.bind"] = "/niq_productrequests(" + productRequestId + ")";

        Xrm.WebApi.createRecord("niq_productrequestpricelistitems", record).then(
            function success(result) {
                console.log("Product created with ID: " + result.id);

                formContext.getControl("productrequestpricelistitems").refresh();
            },
            function (error) {
                console.log(error.message);
            }

        );
    },
    OpenFormBasedOnRecordType: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var recordtype = formContext.getAttribute("niq_requesttype").getValue();
        var currentFormId = formContext.ui.formSelector.getCurrentItem().getId();

        var formMap = {
            610570000: "bf8befbc-aa1d-4c0e-97d6-b13a1929a9b2", // New Product Request
            610570001: "dcfc744a-4efe-ef11-bae3-000d3a233456", // Product Request - Modify
            610570002: "cbd7548f-9e13-f011-9989-000d3a28780f", // Extend Product Request
            610570003: "fdefabea-3f11-f011-9989-6045bd91605b", // Block/Unblock Products
            610570004: "fdefabea-3f11-f011-9989-6045bd91605b", // Block/Unblock Products
        };

        var targetFormId = formMap[recordtype];

        if (targetFormId && currentFormId !== targetFormId) {
            var availableForms = formContext.ui.formSelector.items.get();
            var navigateTo = availableForms.find(function (form) {
                return form.getId() === targetFormId;
            });

            if (navigateTo) {
                navigateTo.navigate();
            }
        }
    },
    OpenTheRecordSidePane: async function (executionContext) {
        const paneId = "SalesOrgExtensionSidePane";
        const formContext = executionContext.getFormContext();
        const entityName = formContext.data.entity.getEntityName();
        const recordId = formContext.data.entity.getId();
        const productRequest = formContext.getAttribute("niq_productrequest").getValue();

        if (recordId == null) {
            return;
        }

        const pane = Xrm.App.sidePanes.getPane(paneId) ?? await Xrm.App.sidePanes.createPane({
            paneId: paneId,
            canClose: true
        });
        pane.width = 600;  //you can decide what's the width of the side pane.
        //you could change the width for each record, in case you want to
        pane.navigate({
            pageType: "entityrecord",
            entityName: entityName,
            entityId: recordId,
            formId: "14674e81-a61a-f011-9989-6045bda1abcd"
        });

        Xrm.WebApi.retrieveMultipleRecords("niq_productrequestmaterialtaxcategory", "?$filter=_niq_productrequest_value eq " + productRequest[0].id.replace("{", "").replace("}", "")).then(
            function success(result) {
                if (result.entities.length > 0) {
                    // Assuming you have a function to update the grid
                    //var gridControl = formContext.getControl("productrequestmaterialtaxcategory");\
                    var sidepanegridnew = formContext.getControl("productrequestmaterialtaxcategory");
                    var sidePaneGrid = Xrm.Page.getControl("productrequestmaterialtaxcategory");
                    sidePaneGrid.clear();
                    result.entities.forEach(function (record) {
                        sidePaneGrid.addRow(record);
                    });
                    sidePaneGrid.refresh();
                } else {
                    console.log("No related records found.");
                }
            },
            function (error) {
                console.log(error.message);
            }
        );
    },

    checkProductIdValid: function(executionContext) {
        var formContext = executionContext.getFormContext();
        var Regexp = /^[a-zA-Z0-9-_]+$/;  // This will allow only numbers, alphabets, dashes, and underscores
        var reqtype = formContext.getAttribute("niq_productid").getValue();
    
        if (!Regexp.test(reqtype)) {
            Xrm.Navigation.openAlertDialog({ title: "Warning!", text: "Product ID should contain valid characters." });
        }
    }
    

}