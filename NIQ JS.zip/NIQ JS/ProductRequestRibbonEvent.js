if (typeof (ProductRequestRibbon) === "undefined") {
    ProductRequestRibbon = {
        __namespace: true
    };
}

ProductRequestRibbon.Events = {

    OnClickOfNewProductRequest: function (executionContext) {
        "use strict";
        
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_productrequest";
        entityFormOptions["formId"]="bf8befbc-aa1d-4c0e-97d6-b13a1929a9b2";// New Product Request
        var formParameters = {};
        formParameters["niq_requesttype"] = 610570000;
        Xrm.Navigation.openForm(entityFormOptions,formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });

    },

     OnClickOfModifyProductRequest: function (SelectedControlSelectedItemIds, executionContext) 
    {
        "use strict";
    
        var selectedItem = SelectedControlSelectedItemIds[0];
        var lookupSalesrefproduct = new Array();
        lookupSalesrefproduct[0] = new Object();
        lookupSalesrefproduct[0].id = selectedItem.Id;
        lookupSalesrefproduct[0].name = selectedItem.Name;
        lookupSalesrefproduct[0].entityType = selectedItem.TypeName;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_productrequest";
        entityFormOptions["formId"]="dcfc744a-4efe-ef11-bae3-000d3a233456";// Product Request - Modify
    
        var formParameters = {};
        formParameters["niq_requesttype"] = 610570001;
        formParameters["niq_approvalstatus"] = 610570000;
        formParameters["niq_referencedproduct"]=lookupSalesrefproduct;
            // Open the form.
        Xrm.Navigation.openForm(entityFormOptions,formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });
    
    },
    OnClickOfExtendProductRequest: function (formContext) {
        "use strict";
        var productID = formContext.data.entity.getId().replace("{", "").replace("}", "");;
        
        var lookupSalesrefproduct = new Array();
        lookupSalesrefproduct[0] = new Object();
        lookupSalesrefproduct[0].id = productID;
        lookupSalesrefproduct[0].name = formContext.getAttribute("name").getValue();
        lookupSalesrefproduct[0].entityType = "product";
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_productrequest";
        entityFormOptions["formId"] = "cbd7548f-9e13-f011-9989-000d3a28780f"; // Extend product Request

        var formParameters = {};
        formParameters["niq_requesttype"] = 610570002;
        formParameters["niq_approvalstatus"] = 610570000;
        formParameters["niq_referencedproduct"] = lookupSalesrefproduct;
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });

    },

    OnClickOfBulkProductRequest: function (executionContext) 
    {
        "use strict";
        debugger;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_productrequest";
        entityFormOptions["formId"]="9c141e68-87f2-ef11-be1f-7c1e5274157c"; // Bulk product request
    
        var formParameters = {};
        formParameters["niq_requesttype"] = 610570005;
            // Open the form.
        Xrm.Navigation.openForm(entityFormOptions,formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });
    
    },

    ProductRequestButtonsVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner,System Administrator")) {
            return true;
        }
        else {
            return false;
        }
    },
	ProductRequestModifyButtonVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner,System Administrator,NIQ Material Master")) {
            return true;
        }
        else {
            return false;
        }
    },


   OnSelectOfModifyProductRequest: function(executionContext){
    "use strict";
    var formContext = executionContext;
    
    var product = new Array();
    product[0] = new Object();
    product[0].id = formContext.data.entity.getId();
    product[0].name = formContext.getAttribute("name").getValue();
    product[0].entityType = "product";

    var formParameters = {};
    formParameters['niq_referencedproduct']= product;
    formParameters['niq_requesttype'] = 610570001;
    formParameters['niq_approvalstatus'] = 	610570000;

    var entityFormOptions = {};
    entityFormOptions["entityName"] = "niq_productrequest";
    entityFormOptions["formId"]="dcfc744a-4efe-ef11-bae3-000d3a233456"; // Modify product request
    
        // Open the form.
    Xrm.Navigation.openForm(entityFormOptions,formParameters).then(
        function (success) {
            console.log(success);
        },
        function (error) {
            console.log(error);
        });

   },


   OnSelectOfExtendProductRequest: function(executionContext){
    "use strict";
    var formContext = executionContext;
    
    var product = new Array();
    product[0] = new Object();
    product[0].id = formContext.data.entity.getId();
    product[0].name = formContext.getAttribute("name").getValue();
    product[0].entityType = "product";

    var formParameters = {};
    formParameters['niq_referencedproduct']= product;
    formParameters['niq_requesttype'] = 610570002;
    formParameters['niq_approvalstatus'] = 	610570000;

    var entityFormOptions = {};
    entityFormOptions["entityName"] = "niq_productrequest";
    entityFormOptions["formId"]="cb0169e1-f3ff-ef11-bae3-6045bda1abcd"; // Extend product request
    
        // Open the form.
    Xrm.Navigation.openForm(entityFormOptions,formParameters).then(
        function (success) {
            console.log(success);
        },
        function (error) {
            console.log(error);
        });

   },
   ProductButtonVisibility: function (executionContext) {
    'use strict';
    var formContext = executionContext;
    if (CommonForm.Events.CheckIfLoggedInUserRoles("System Administrator")) {
        return true;
    }
    else {
        return false;
    }
},
NewObjectButtonVisibility: function (executionContext) {
    'use strict';
    var formContext = executionContext;
    var requestType= formContext.getAttribute("niq_requesttype").getValue();
    if(requestType===610570002){
        return true;
    }else{
        return false
    }
},

HideNewProductRequestPriceListButton: function (executionContext) {
    'use strict';
    var formContext = executionContext;
    var requestType= formContext.getAttribute("niq_requesttype").getValue();
    if(requestType==610570003 || requestType == 610570004 || CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")){
        return false;
    }else{
        return true;
    }
},
HideExtendProductRequestButton: function (executionContext) {
    'use strict';
    var formContext = executionContext;
    var productStructure= formContext.getAttribute("productstructure").getValue();
    if(productStructure===1){
        return true;
    }else{
        return false
    }
}
    

}