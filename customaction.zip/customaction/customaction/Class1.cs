﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Xrm.Sdk;

namespace customaction
{
    public class Class1 : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context =(IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            string requestParameter = (string)context.InputParameters["RequestParameter"];
            string responseParameter = requestParameter + DateTime.Now.ToString();
            context.OutputParameters["ResponseParameter"] = responseParameter;

        }
    }
}