﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace NIQ.D365.Int.ProductMasteringSAPIntegration.Utilities
{
    public static class Common
    {
        public static string GetValue(Entity productRequest, string fieldLogicalName, string refFieldLogicalName, IOrganizationService service)
        {
            string result = string.Empty;

            if (productRequest.Attributes.Contains(fieldLogicalName))
            {
                EntityReference attributeValue = productRequest.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity entity = service.Retrieve(attributeValue.LogicalName, attributeValue.Id, new ColumnSet(refFieldLogicalName));

                if (entity != null && entity.Attributes.Contains(refFieldLogicalName))
                {
                    result = entity.GetAttributeValue<string>(refFieldLogicalName);
                }
            }

            return result;
        }

        public static List<string> GetClassValue(string productRequestId, IOrganizationService service)
        {
            List<string> classValues = new List<string>();
            string fetchXml = $@"
                <fetch version='1.0' output-format='xml-platform'>
                    <entity name='niq_materialcharacteristic'>
                        <attribute name='niq_classtype' />
                        <link-entity name='niq_productrequestconfigurablecharacteristi' from='niq_characteristics' to='niq_materialcharacteristicid' link-type='inner' alias='al'>
                            <link-entity name='niq_productrequest' from='niq_productrequestid' to='niq_productrequest' link-type='inner' alias='am'>
                                <filter type='and'>
                                    <condition attribute='niq_productrequestid' operator='eq' value='{new Guid(productRequestId)}' />
                                </filter>
                            </link-entity>
                        </link-entity>
                    </entity>
                </fetch>";

            foreach (Entity entity in service.RetrieveMultiple(new FetchExpression(fetchXml)).Entities)
            {
                if (entity.Contains("niq_classtype"))
                {
                    classValues.Add(entity["niq_classtype"].ToString());
                }
            }

            return classValues;
        }

        public static List<string> GetLanguages(string productRequestId, IOrganizationService service)
        {
            Guid guid = new Guid(productRequestId);
            List<string> languages = new List<string>();

            QueryExpression query = new QueryExpression("niq_productrequestlocallanguagematerialdesc")
            {
                ColumnSet = new ColumnSet("niq_language", "niq_materialdescriptionlocal"),
                Criteria = new FilterExpression
                {
                    Conditions = { new ConditionExpression("niq_productrequest", ConditionOperator.Equal, guid) }
                }
            };

            foreach (Entity entity in service.RetrieveMultiple(query).Entities)
            {
                if (entity.Contains("niq_language"))
                {
                    string attributeValue = entity.GetAttributeValue<string>("niq_materialdescriptionlocal");

                    if (entity["niq_language"] is EntityReference languageRef)
                    {
                        string localeCode = service.Retrieve(languageRef.LogicalName, languageRef.Id, new ColumnSet("msdyn_localecode"))
                            .GetAttributeValue<string>("msdyn_localecode")
                            .Substring(0, 2).ToUpper();

                        if (!string.IsNullOrEmpty(localeCode))
                        {
                            languages.Add(localeCode);
                            languages.Add(attributeValue);
                        }
                    }
                }
            }

            return languages;
        }

        public static List<string> GetTaxItems(string productRequestId,string priceListGuid, IOrganizationService service, ITracingService tracing)
        {
            tracing.Trace($"Check3");
            Guid guid = new Guid(productRequestId);
            Guid priceListGuid1 = new Guid(priceListGuid);
            tracing.Trace($"Check2");
            string fetchXml = $@"
                <fetch version='1.0' output-format='xml-platform'>
                    <entity name='niq_taxoptionsapmaster'>
                        <attribute name='niq_taxsapcode' />
                        <attribute name='niq_taxcategory' />
                        <link-entity name='niq_countrytaxcategorysapmaster' from='niq_countrytaxcategorysapmasterid' to='niq_taxcategory' link-type='outer' alias='TaxCountry'>
                            <attribute name='niq_country' />
                        </link-entity>
                        <link-entity name='niq_productrequestmaterialtaxcategory' from='niq_taxcategoryoption' to='niq_taxoptionsapmasterid' link-type='inner' alias='af'>
                                <filter type='and'>
                            <condition attribute='niq_pricelist' operator='eq' value='{priceListGuid1}' />
                        </filter>
                            <link-entity name='niq_productrequest' from='niq_productrequestid' to='niq_productrequest' link-type='inner' alias='ag'>
                                <filter type='and'>
                                    <condition attribute='niq_productrequestid' operator='eq' value='{productRequestId}' />
                                </filter>
                            </link-entity>
                        </link-entity>
                    </entity>
                </fetch>";
            tracing.Trace($"FETCH xml : {fetchXml}");

            List<string> taxItems = new List<string>();

            foreach (Entity entity in service.RetrieveMultiple(new FetchExpression(fetchXml)).Entities)
            {
                string taxCode = entity.GetAttributeValue<string>("niq_taxsapcode");
                EntityReference taxCategory = entity.GetAttributeValue<EntityReference>("niq_taxcategory");
                AliasedValue country = entity.GetAttributeValue<AliasedValue>("TaxCountry.niq_country");

                if (country?.Value is EntityReference countryRef)
                {
                    string countryCode = service.Retrieve(countryRef.LogicalName, countryRef.Id, new ColumnSet("niq_countrycode"))
                        .GetAttributeValue<string>("niq_countrycode");
                    tracing.Trace($"Country Code: {countryCode}");
                    taxItems.Add(countryCode ?? string.Empty);
                }

                taxItems.Add(taxCode ?? string.Empty);
                taxItems.Add(taxCategory?.Name ?? string.Empty);
            }

            return taxItems;
        }

        public static List<Dictionary<string, string>> GetPriceListItemsList(
    string productRequestId,
    IOrganizationService service,
    ITracingService tracing)
        {
            List<Dictionary<string, string>> priceListItemsList = new List<Dictionary<string, string>>();
            string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                        <entity name='niq_productrequestpricelistitems'>
                            <attribute name='createdon' />
                            <attribute name='niq_itemcategorygroup' />
                            <attribute name='niq_profitcentrecode' />
                            <attribute name='niq_productid' />
                            <attribute name='niq_pricelist' />
                            <attribute name='niq_glaccount_aagcode' />
                            <attribute name='niq_discontinueeffectivefrom' />
                            <order attribute='niq_name' descending='false' />
                            <filter type='and'>
                                <condition attribute='niq_productrequest' operator='eq' value='{productRequestId}' />
                                <condition attribute='statecode' operator='eq' value='0' />
                            </filter>
                            <link-entity name='niq_glaccountaagcode' from='niq_glaccountaagcodeid' to='niq_glaccount_aagcode' visible='false' link-type='outer' alias='glaccount'>
                                <attribute name='niq_name' />
                                <attribute name='niq_aag' />
                            </link-entity>
                            <link-entity name='niq_sapproductmastersupportdata' from='niq_sapproductmastersupportdataid' to='niq_materialgroup4' visible='false' link-type='outer' alias='materialgroup4'>
                                <attribute name='niq_masterfieldsapcode' />
                            </link-entity>
                            <link-entity name='niq_sapproductmastersupportdata' from='niq_sapproductmastersupportdataid' to='niq_controlcode' visible='false' link-type='outer' alias='controlcode'>
                                <attribute name='niq_masterfieldsapcode' />
                            </link-entity>
                            <link-entity name='niq_sapproductmastersupportdata' from='niq_sapproductmastersupportdataid' to='niq_valuationclass' visible='false' link-type='outer' alias='valuationclass'>
                                <attribute name='niq_masterfieldsapcode' />
                            </link-entity>
                            <link-entity name='niq_sapproductmastersupportdata' from='niq_sapproductmastersupportdataid' to='niq_pricecontrolindicator' visible='false' link-type='outer' alias='pricecontrolindicator'>
                                <attribute name='niq_masterfieldsapcode' />
                            </link-entity>
                            <link-entity name='niq_profitcentre' from='niq_profitcentreid' to='niq_profitcenter' visible='false' link-type='outer' alias='profitcentre'>
                                <attribute name='niq_profitcentrecode' />
                            </link-entity>
                            <link-entity name='niq_itemcategorygroupmetadata' from='niq_itemcategorygroupmetadataid' to='niq_itemcategorygroups' visible='false' link-type='outer' alias='itemcategory'>
                                <attribute name='niq_name' />
                            </link-entity>
                            <link-entity name='niq_sapproductmastersupportdata'
                                         from='niq_sapproductmastersupportdataid'
                                         to='niq_discontinuereason'
                                         visible='false'
                                         link-type='outer'
                                         alias='discontinuereason'>
                                        <attribute name='niq_masterfieldsapcode' />
                                        </link-entity>
                        </entity>
                    </fetch>";
            tracing.Trace($"FETCH xml : {fetchXml}");
            foreach (Entity entity in service.RetrieveMultiple(new FetchExpression(fetchXml)).Entities)
            {
                string valuationClass = entity.GetAttributeValue<AliasedValue>("valuationclass.niq_masterfieldsapcode")?.Value?.ToString();
                string priceControlIndicator = entity.GetAttributeValue<AliasedValue>("pricecontrolindicator.niq_masterfieldsapcode")?.Value?.ToString();
                string priceUnit = (!string.IsNullOrEmpty(valuationClass) && !string.IsNullOrEmpty(priceControlIndicator)) ? "1" : "";
                Dictionary<string, string> dictionary = new Dictionary<string, string>()
                {
                    ["niq_itemcategorygroup"] = entity.GetAttributeValue<AliasedValue>("itemcategory.niq_name")?.Value?.ToString(),
                    ["niq_profitcentrecode"] = entity.GetAttributeValue<AliasedValue>("profitcentre.niq_profitcentrecode")?.Value?.ToString(),
                    ["niq_glaccount_aagcode"] = Common.GetAagNames(service, entity.GetAttributeValue<EntityReference>("niq_glaccount_aagcode")),
                    ["niq_materialgroup4"] = entity.GetAttributeValue<AliasedValue>("materialgroup4.niq_masterfieldsapcode")?.Value?.ToString(),
                    ["niq_controlcode"] = entity.GetAttributeValue<AliasedValue>("controlcode.niq_masterfieldsapcode")?.Value?.ToString(),
                    ["niq_valuationclass"] = entity.GetAttributeValue<AliasedValue>("valuationclass.niq_masterfieldsapcode")?.Value?.ToString(),
                    ["niq_pricecontrolindicator"] = entity.GetAttributeValue<AliasedValue>("pricecontrolindicator.niq_masterfieldsapcode")?.Value?.ToString(),
                    ["niq_productid"] = entity.GetAttributeValue<string>("niq_productid"),
                    ["niq_pricelist"] = Common.GetSalesOrgCode(service, tracing, entity.GetAttributeValue<EntityReference>("niq_pricelist")),
                    ["niq_discontinuereason"] = entity.GetAttributeValue<AliasedValue>("discontinuereason.niq_masterfieldsapcode")?.Value?.ToString(),
                    ["niq_discontinueeffectivefrom"] = entity.GetAttributeValue<DateTime?>("niq_discontinueeffectivefrom").HasValue
                    ? entity.GetAttributeValue<DateTime?>("niq_discontinueeffectivefrom").Value.ToString("dd.MM.yyyy")
                    : null,
                    ["niq_pricelistGuid"] = entity.GetAttributeValue<EntityReference>("niq_pricelist")?.Id.ToString(),
                    ["niq_priceunit"] = priceUnit,
            };
                priceListItemsList.Add(dictionary);
            }
            tracing.Trace($"Check");
            return priceListItemsList;
        }

        public static string GetSalesOrgCode(IOrganizationService service, ITracingService tracing, EntityReference priceLevelId)
        {
            string fetchXml = $@"
                <fetch version='1.0' output-format='xml-platform'>
                    <entity name='niq_salesorg'>
                        <attribute name='niq_salesorgcode' />
                        <link-entity name='pricelevel' from='niq_salesorg' to='niq_salesorgid' link-type='inner' alias='ac'>
                            <filter type='and'>
                                <condition attribute='pricelevelid' operator='eq' value='{{{priceLevelId.Id}}}' />
                            </filter>
                        </link-entity>
                    </entity>
                </fetch>";

            EntityCollection results = service.RetrieveMultiple(new FetchExpression(fetchXml));

            if (results.Entities.Any())
            {
                return results.Entities.First().GetAttributeValue<string>("niq_salesorgcode");
            }

            return null;
        }

        public static string GetAagNames(IOrganizationService service, EntityReference glAccountAagCodeId)
        {
            string fetchXml = $@"
                <fetch version='1.0' output-format='xml-platform'>
                    <entity name='niq_aag'>
                        <attribute name='niq_name' />
                        <link-entity name='niq_glaccountaagcode' from='niq_aag' to='niq_aagid' link-type='inner' alias='ab'>
                            <filter type='and'>
                                <condition attribute='niq_glaccountaagcodeid' operator='eq' value='{glAccountAagCodeId.Id}' />
                            </filter>
                        </link-entity>
                    </entity>
                </fetch>";

            EntityCollection results = service.RetrieveMultiple(new FetchExpression(fetchXml));

            if (results.Entities.Any())
            {
                return results.Entities.First().GetAttributeValue<string>("niq_name");
            }

            return null;
        }

        public static List<Dictionary<string, string>> GetProductInfoList(string productRequestId, IOrganizationService service, ITracingService tracing)
        {
            List<Dictionary<string, string>> productInfoList = new List<Dictionary<string, string>>();
            string fetchXml = $@"
            <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            <entity name='niq_productrequestpricelistitems'>
            <attribute name='niq_productid' />
            <attribute name='niq_pricelist' />
            <attribute name='niq_discontinueeffectivefrom' />
            <order attribute='niq_name' descending='false' />
            <filter type='and'>
            <condition attribute='niq_productrequest' operator='eq' value='{productRequestId}' />
            <condition attribute='statecode' operator='eq' value='0' />
            </filter>
            <link-entity name='niq_sapproductmastersupportdata'
                                         from='niq_sapproductmastersupportdataid'
                                         to='niq_discontinuereason'
                                         visible='false'
                                         link-type='outer'
                                         alias='discontinuereason'>
            <attribute name='niq_masterfieldsapcode' />
            </link-entity>
            </entity>
            </fetch>";
            tracing.Trace($"FETCH xml : {fetchXml}");
            EntityCollection entityCollection = service.RetrieveMultiple(new FetchExpression(fetchXml));

            foreach (Entity entity in entityCollection.Entities)
            {
                Dictionary<string, string> productInfo = new Dictionary<string, string>();
                productInfo["niq_discontinuereason"] = entity.GetAttributeValue<AliasedValue>("discontinuereason.niq_masterfieldsapcode")?.Value?.ToString();
                DateTime? discontinueDate = entity.GetAttributeValue<DateTime?>("niq_discontinueeffectivefrom");
                productInfo["niq_discontinueeffectivefrom"] = discontinueDate.HasValue
                    ? discontinueDate.Value.ToString("dd.MM.yyyy")
                    : null;
                productInfo["niq_productid"] = entity.GetAttributeValue<string>("niq_productid");
                productInfo["niq_pricelist"] = Common.GetSalesOrgCode(service, tracing, entity.GetAttributeValue<EntityReference>("niq_pricelist"));
                productInfoList.Add(productInfo);
            }
            return productInfoList;
        }
        public static Dictionary<string, string> GetProductDetails(string productRequestId, IOrganizationService service, ITracingService tracing)
        {
            tracing.Trace($"Inside Product details");
            // Define the FetchXML query dynamically
            string fetchXml = $@"
            <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                <entity name='product'>
                    <attribute name='description' />
                    <link-entity name='niq_productrequest' from='niq_referencedproduct' to='productid' link-type='inner' alias='ac'>
                        <filter type='and'>
                            <condition attribute='niq_productrequestid' operator='eq' value='{productRequestId}' />
                        </filter>
                    </link-entity>
                    <link-entity name='niq_sapproductmastersupportdata' from='niq_sapproductmastersupportdataid' to='niq_industry' visible='false' link-type='outer' alias='industry'>
                        <attribute name='niq_masterfieldsapcode' />
                    </link-entity>
                    <link-entity name='niq_materialgroupmaster' from='niq_materialgroupmasterid' to='niq_materialgroup' visible='false' link-type='outer' alias='materialgroup'>
                        <attribute name='niq_materialgroupsapcode' />
                    </link-entity>
                    <link-entity name='niq_sapproductmastersupportdata' from='niq_sapproductmastersupportdataid' to='niq_materialtype' visible='false' link-type='outer' alias='niq_materialtype'>
                        <attribute name='niq_masterfieldsapcode' />
                    </link-entity>
                </entity>
            </fetch>";
            tracing.Trace($"Fetch XML:"+ fetchXml);
            // Execute FetchXML
            EntityCollection entityCollection = service.RetrieveMultiple(new FetchExpression(fetchXml));

            // Process the first record
            if (entityCollection.Entities.Count > 0)
            {
                var entity = entityCollection.Entities[0];
                var productDetails = new Dictionary<string, string>
                {
                    ["description"] = entity.GetAttributeValue<string>("description") ?? string.Empty,
                    ["industry"] = entity.GetAttributeValue<AliasedValue>("industry.niq_masterfieldsapcode")?.Value?.ToString() ?? string.Empty,
                    ["materialType"] = entity.GetAttributeValue<AliasedValue>("niq_materialtype.niq_masterfieldsapcode")?.Value?.ToString() ?? string.Empty,
                    ["materialGroup"] = entity.GetAttributeValue<AliasedValue>("materialgroup.niq_materialgroupsapcode")?.Value?.ToString() ?? string.Empty
                };

                return productDetails;
            }

            // Return an empty dictionary if no results
            return new Dictionary<string, string>();
        }
    }
}