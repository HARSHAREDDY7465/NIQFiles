﻿using System;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;


namespace NIQ.D365.Int.ProductMasteringSAPIntegration
{
    public class ProductMasteringSAPIntegrationAction : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = factory.CreateOrganizationService(context.UserId);
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            try
            {
                string productRequestId = (string)context.InputParameters["ProductRequestId"];
                tracing.Trace($@"ProductRequestId: {productRequestId}");

                Entity ProductRequestEntity = service.Retrieve("niq_productrequest", new Guid(productRequestId), new ColumnSet(true));

                int requestType = 1;
                if (ProductRequestEntity.Attributes.Contains("niq_requesttype"))
                    requestType = ProductRequestEntity.GetAttributeValue<OptionSetValue>("niq_requesttype").Value;
                tracing.Trace($@"requestType: {requestType}");
                string payloadData = string.Empty;
                switch (requestType)
                {
                    case 610570000: //Product Creation
                        payloadData = CreationPayload.CreationPayload.SetRequestModel(ProductRequestEntity,productRequestId, service, tracing);
                        break;
                    case 610570001: //Product Modification
                        payloadData = ModicationPayload.ModicationPayload.SetRequestModel(ProductRequestEntity, productRequestId, service, tracing);
                        break;
                    case 610570002:  //Product Extension
                        payloadData = ExtensionPayload.ExtensionPayload.SetRequestModel(ProductRequestEntity, productRequestId, service, tracing);
                        break;
                    case 610570003: //Product Blocking
                        payloadData = BlockingPayload.BlockingPayloads.SetRequestModel(ProductRequestEntity, productRequestId, service, tracing);
                        break;
                    case 610570004:  //Product Unblocking
                        payloadData = UnblockingPayload.UnblockingPayload.SetRequestModel(ProductRequestEntity, productRequestId, service, tracing);
                        break;
                    default:
                        break;
                }

                context.OutputParameters["Payload"] = payloadData;
                context.OutputParameters["IsSuccess"] = true;
                context.OutputParameters["ErrorMessage"] = "";

            }
            catch (Exception ex)
            {
                context.OutputParameters["Payload"] = "";
                context.OutputParameters["IsSuccess"] = false;
                context.OutputParameters["ErrorMessage"] = ex.Message;
            }
        }
    }
}
