﻿using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using NIQ.D365.Int.ProductMasteringSAPIntegration.UnblockingModel;
using NIQ.D365.Int.ProductMasteringSAPIntegration.Utilities;
using System;
using System.Collections.Generic;


namespace NIQ.D365.Int.ProductMasteringSAPIntegration.UnblockingPayload
{
    public static class UnblockingPayload
    {
        public static string SetRequestModel(Entity productEntity, string productRequestId, IOrganizationService service, ITracingService tracing)
        {
            try
            {
                // Initialize the root object
                Root root = new Root
                {
                    n0InputTab = new n0InputTab
                    {
                        MaterialPairs = new List<MaterialPairs>()
                    }
                };

                // Fetch required data
                List<Dictionary<string, string>> productInfoList = Common.GetProductInfoList(productRequestId, service, tracing);
                var productDetails = Common.GetProductDetails(productRequestId, service, tracing);
                // Loop through product info and construct MaterialPairs
                foreach (var dictionary in productInfoList)
                {
                    MaterialPairs materialPairs = new MaterialPairs
                    {
                        MaterialId = dictionary["niq_productid"],
                        Industry = productDetails["industry"] ?? "",
                        MaterialType = productDetails["materialType"] ?? "",
                        UpdateIndicator = "U",
                        OrgData = new OrgData
                        {
                            Plant = dictionary["niq_pricelist"],
                            SalesOrg = dictionary["niq_pricelist"],
                            DistributionChannel = Common.GetValue(productEntity, "niq_distributionchannel", "niq_masterfieldsapcode", service)
                        },
                        SalesOrg1 = new SalesOrg1
                        {
                            DChainspecstatus = dictionary.ContainsKey("niq_discontinuereason") ? dictionary["niq_discontinuereason"] : null,
                            ValidfromDate = dictionary.ContainsKey("niq_discontinueeffectivefrom") ? dictionary["niq_discontinueeffectivefrom"] : null
                        },
                        DeliveringPlant = dictionary["niq_pricelist"]
                    };

                    root.n0InputTab.MaterialPairs.Add(materialPairs);
                }

                // Serialize the object to JSON and replace namespace prefix if required
                return JsonConvert.SerializeObject(root, Formatting.Indented)
                    .Replace("n0InputTab", "n0:InputTab");
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("An error occurred while setting the request model.", ex);
            }
        }
    }
}