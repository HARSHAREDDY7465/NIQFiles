﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using NIQ.D365.Int.ProductMasteringSAPIntegration.ExtensionModel;
using NIQ.D365.Int.ProductMasteringSAPIntegration.Utilities;

namespace NIQ.D365.Int.ProductMasteringSAPIntegration.ExtensionPayload
{
    public static class ExtensionPayload
    {
        public static string SetRequestModel(Entity productEntity, string productRequestId, IOrganizationService service, ITracingService tracing)
        {
            try
            {
                // Initialize the root object
                var root = new Root
                {
                    n0InputTab = new n0InputTab()
                    {
                        MaterialPairs = new List<MaterialPairs>()
                    }
                };

                // Fetch required data
                var priceListItemsList = Common.GetPriceListItemsList(productRequestId, service, tracing);
                var classValues = Common.GetClassValue(productRequestId, service);
                var languages = Common.GetLanguages(productRequestId, service);
                

                // Fetch product details (single record)
                var productDetails = Common.GetProductDetails(productRequestId, service, tracing);

                // Loop through price list items and construct MaterialPairs
                foreach (var dictionary in priceListItemsList)
                {
                    var taxItems = Common.GetTaxItems(productRequestId, dictionary["niq_pricelistGuid"], service, tracing);
                    var materialPairs = new MaterialPairs
                    {
                        MaterialId = dictionary["niq_productid"],
                        Industry = productDetails["industry"] ?? "",
                        MaterialType = productDetails["materialType"] ?? "",
                        UpdateIndicator = "I",
                        OrgData = new OrgData
                        {
                            Plant = dictionary["niq_pricelist"] ?? "",
                            SalesOrg = dictionary["niq_pricelist"] ?? "",
                            DistributionChannel = Common.GetValue(productEntity, "niq_distributionchannel", "niq_masterfieldsapcode", service) ?? ""
                        },
                        BasicData1 = new BasicData1
                        {
                            MaterialId = dictionary["niq_productid"] ?? "",
                            Materialdescription = productDetails["description"] ?? "",
                            BaseUnitofMeasure = "EA",
                            MaterialGroup = productDetails["materialGroup"] ?? "",
                            OldMaterialNumber = productEntity.Attributes.Contains("niq_oldmaterialnumber")
                                ? productEntity.Attributes["niq_oldmaterialnumber"].ToString()
                                : "",
                            ExtMatlGroup = Common.GetValue(productEntity, "niq_externalmaterialgrouptaxcode", "niq_externalmaterialsapcode", service) ?? "",
                            ProdHierarchyL4 = Common.GetValue(productEntity, "niq_brandlevel4", "productnumber", service) ?? ""
                        },
                        DeliveringPlant = dictionary["niq_pricelist"] ?? "",
                        SalesOrg1Tax = new SalesOrg1Tax
                        {
                            item2 = taxItems.Select((value, index) => new { value, index })
                                .GroupBy(x => x.index / 3)
                                .Select(g => new item2
                                {
                                    TaxCountry = g.ElementAtOrDefault(0)?.value ?? "",
                                    TaxClassification = g.ElementAtOrDefault(1)?.value ?? "",
                                    TaxCategory = g.ElementAtOrDefault(2)?.value ?? ""
                                }).ToList()
                        },
                        SalesOrg2 = new SalesOrg2
                        {
                            Matlstatisticsgrp = Common.GetValue(productEntity, "niq_statisticsgroup", "niq_masterfieldsapcode", service) ?? "",
                            Acctassignmentgrp = dictionary["niq_glaccount_aagcode"] ?? "",
                            Itemcategorygroup = dictionary["niq_itemcategorygroup"] ?? "",
                            Materialgroup1 = "",
                            Materialgroup2 = "",
                            Materialgroup3 = "",
                            Materialgroup4 = dictionary["niq_materialgroup4"] ?? "",
                            Materialgroup5 = ""
                        },
                        ProfitCenter = dictionary["niq_profitcentrecode"] ?? "",
                        Controlcode = dictionary["niq_controlcode"] ?? "",
                        Accounting1 = new Accounting1
                        {
                            ValuationClass = dictionary["niq_valuationclass"] ?? "",
                            Pricecontrol = dictionary["niq_pricecontrolindicator"] ?? "",
                            Priceunit = dictionary["niq_priceunit"] ?? ""
                        }
                    };

                    if (classValues != null && classValues.Any())
                    {
                        materialPairs.Materialisconfigurable = "X"; // Add this only if classValues has data
                        materialPairs.ClassType = "300";
                        materialPairs.Class = new Class
                        {
                            item1 = classValues.Select(classValue => new item1 { Class = classValue ?? "" }).ToList()
                        };
                    }

                    if (languages != null && languages.Any())
                    {
                        materialPairs.Language = new Language
                        {
                            item = languages.Select((value, index) => new { value, index })
                                .GroupBy(x => x.index / 2)
                                .Select(language => new ItemLanguage
                                {
                                    Language = language.ElementAtOrDefault(0)?.value ?? "",
                                    MaterialDescription = language.ElementAtOrDefault(1)?.value ?? ""
                                }).ToList()
                        };
                    }
                    if (dictionary["niq_discontinuereason"] != null && dictionary["niq_discontinuereason"] != "")
                    {
                        materialPairs.SalesOrg1 = new SalesOrg1
                        {
                            DChainspecstatus = dictionary["niq_discontinuereason"],
                            ValidfromDate = dictionary["niq_discontinueeffectivefrom"] ?? ""
                        };
                    }
                    root.n0InputTab.MaterialPairs.Add(materialPairs);
                }

                // Serialize with null handling
                var jsonSettings = new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore // Ignore null properties
                };
                return JsonConvert.SerializeObject(root, Formatting.Indented, jsonSettings)
                    .Replace("n0InputTab", "n0:InputTab");
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("An error occurred while setting the request model.", ex);
                //throw ex;
            }
        }
    }
}