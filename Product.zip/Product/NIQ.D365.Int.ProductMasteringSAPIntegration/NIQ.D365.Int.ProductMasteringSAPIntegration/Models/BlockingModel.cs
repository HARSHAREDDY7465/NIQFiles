﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NIQ.D365.Int.ProductMasteringSAPIntegration.BlockingModel
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class Root
    {
        public n0InputTab n0InputTab { get; set; }
    }
    public class n0InputTab
    {
        public List<MaterialPairs> MaterialPairs { get; set; }
    }
    public class MaterialPairs
    {
        public string MaterialId { get; set; }
        public string Industry { get; set; }
        public string MaterialType { get; set; }
        public string UpdateIndicator { get; set; }
        public OrgData OrgData { get; set; }
        public SalesOrg1 SalesOrg1 { get; set; }
        public string DeliveringPlant { get; set; }
    }
    public class OrgData
    {
        public string Plant { get; set; }
        public string SalesOrg { get; set; }
        public string DistributionChannel { get; set; }
    }

    public class SalesOrg1
    {
        public string DChainspecstatus { get; set; }
        public string ValidfromDate { get; set; }
    }
}