﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NIQ.D365.Int.ProductMasteringSAPIntegration.CreationModel
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class Root
    {
        public n0InputTab n0InputTab { get; set; }
    }
    public class n0InputTab
    {
        public List<MaterialPairs> MaterialPairs { get; set; }
    }

    public class MaterialPairs
    {
        public string MaterialId { get; set; }
        public string Industry { get; set; }
        public string MaterialType { get; set; }
        public string UpdateIndicator { get; set; }
        public OrgData OrgData { get; set; }
        public BasicData1 BasicData1 { get; set; }
        public string Materialisconfigurable { get; set; }
        public string ClassType { get; set; }
        public Class Class { get; set; }
        public SalesOrg1 SalesOrg1 { get; set; }
        public string DeliveringPlant { get; set; }
        public SalesOrg1Tax SalesOrg1Tax { get; set; }
        public SalesOrg2 SalesOrg2 { get; set; }
        public string ProfitCenter { get; set; }
        public string Controlcode { get; set; }
        public Accounting1 Accounting1 { get; set; }
        public Language Language { get; set; }
    }

    public class OrgData
    {
        public string Plant { get; set; }
        public string SalesOrg { get; set; }
        public string DistributionChannel { get; set; }
    }

    public class BasicData1
    {
        public string MaterialId { get; set; }
        public string Materialdescription { get; set; }
        public string BaseUnitofMeasure { get; set; }
        public string MaterialGroup { get; set; }
        public string OldMaterialNumber { get; set; }
        public string ExtMatlGroup { get; set; }
        public string ProdHierarchyL4 { get; set; }
    }

    public class Class
    {
        public List<item1> item1 { get; set; }
    }

    public class item1
    {
        public string Class { get; set; }
    }

    public class SalesOrg1
    {
        public string DChainspecstatus { get; set; }
        public string ValidfromDate { get; set; }
    }

    public class SalesOrg1Tax
    {
        public List<item2> item2 { get; set; }
    }

    public class item2
    {
        public string TaxCountry { get; set; }
        public string TaxCategory { get; set; }
        public string TaxClassification { get; set; }
    }

    public class SalesOrg2
    {
        public string Matlstatisticsgrp { get; set; }
        public string Acctassignmentgrp { get; set; }
        public string Itemcategorygroup { get; set; }
        public string Materialgroup1 { get; set; }
        public string Materialgroup2 { get; set; }
        public string Materialgroup3 { get; set; }
        public string Materialgroup4 { get; set; }
        public string Materialgroup5 { get; set; }
    }

    public class Accounting1
    {
        public string ValuationClass { get; set; }
        public string Pricecontrol { get; set; }
        public string Priceunit { get; set; }
    }

    public class Language
    {
        public List<ItemLanguage> item { get; set; }
    }

    public class ItemLanguage
    {
        public string Language { get; set; }
        public string MaterialDescription { get; set; }
    }

}