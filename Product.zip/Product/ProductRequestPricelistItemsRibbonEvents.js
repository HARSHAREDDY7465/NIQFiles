if (typeof (productrequestpricelistitemsribbonevent) === "undefined") {
    productrequestpricelistitemsribbonevent = {
        __namespace: true
    };
}
productrequestpricelistitemsribbonevent.Events = {
    //US-21681
    //Hide Add/Delete button from subgrid in Modify-product request form
    HideAddDeleteButton: function (primaryControl) {
        var formContext = primaryControl;
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        if (requestType != null && requestType == 610570001 && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner,NIQ Material Master")) {
            return false;
        } else {
            return true;
        }
    },
    //US-21681
    //Hide Add/Delete button in Modify-product request form
    HideAddDeleteButtonForm: async function (primaryControl) {
        var formContext = primaryControl;
        var productRequest = formContext.getAttribute("niq_productrequest").getValue();
        if(productRequest != null){
            var productRequestGuid = productRequest[0].id.replace("{","").replace("}","");
            var result = await Xrm.WebApi.retrieveRecord("niq_productrequest", productRequestGuid, "?$select=niq_requesttype");
            var requestType = result["niq_requesttype"];
            if (requestType != null && requestType == 610570001 && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner,NIQ Material Master")) {
                return false;
            } else {
                return true;
            }
        }
    },

    HideShowNewButtonmaterialTaxCategoryToMM:async function(executionContext)
    {
        var formContext = primaryControl;
        var productRequest = formContext.getAttribute("niq_productrequest").getValue();
        if(productRequest != null){
            var productRequestGuid = productRequest[0].id.replace("{","").replace("}","");
            var result = await Xrm.WebApi.retrieveRecord("niq_productrequest", productRequestGuid, "?$select=niq_requesttype");
            var requestType = result["niq_requesttype"];
            if(requestType==610570001){    
                if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master, System Administrator")) {
                    return false;
                }
                else {
                    return true;
                }
            }
        }
    }
}