if (typeof (ProductRequestPriceListItems) === "undefined") {
    ProductRequestPriceListItems = {
        __namespace: true
    };
}
var PreProfitCenter = null;
var PreGLAccountAAGCode = null;
var PreItemCategoryGroup = null;
ProductRequestPriceListItems.Events = {
    FormOnloadBlock: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        this.showHideFieldForMMProductRequestPriceListItem(executionContext);
        this.hideBlockCode(executionContext);
        this.OpenFormBasedOnRecordType(executionContext);
        this.lockBlockCodeForMM(executionContext);
        this.lockAllFieldsAfterApprovalSubgrids(executionContext);

    },
    FormOnload: function (executionContext) {
        var formContext = executionContext.getFormContext();
        this.showHideFieldForMMProductRequestPriceListItemNew(executionContext);
        this.hideBlockCode(executionContext);
        this.setMandatoryfields(executionContext);
        this.MethodOnChangeEvent(executionContext);
        this.OpenFormBasedOnRecordType(executionContext);
        this.setDefaultValueForUnit(executionContext);
        formContext.getAttribute("niq_profitcenter").setRequiredLevel("required");
        formContext.getAttribute("niq_glaccount_aagcode").setRequiredLevel("required");
        this.lockAllFieldsAfterApprovalSubgrids(executionContext);
        this.onProfitCenterChange(executionContext);
        this.copyCurrencyFromPriceLevel(executionContext);
    },
    MethodOnChangeEvent: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.getAttribute("niq_pricelist").addOnChange(this.setMandatoryfields);
        formContext.getAttribute("niq_pricelist").addOnChange(this.onProfitCenterChange);
        formContext.getAttribute("niq_pricelist").addOnChange(this.copyCurrencyFromPriceLevel);
        formContext.getAttribute("niq_pricelist").addOnChange(this.populateNameField);
    },
    FormOnloadExtend: function (executionContext) {

        "use strict";
        var formContext = executionContext.getFormContext();
        this.OpenFormBasedOnRecordType(executionContext);
        this.fetchAndDisplayRelatedRecords(executionContext);
        this.MethodOnChangeEvent(executionContext);
        this.showHideFieldForMMProductRequestPriceListItem_Extend(executionContext);
        this.hideBlockCode(executionContext);
        this.setFieldValues(executionContext);
        this.setMandatoryfields(executionContext);
        this.setDefaultValueForUnit(executionContext);
        this.onProfitCenterChange(executionContext);
        formContext.getAttribute("niq_profitcenter").setRequiredLevel("required");
        formContext.getAttribute("niq_glaccount_aagcode").setRequiredLevel("required");
        this.lockAllFieldsAfterApprovalSubgrids(executionContext);
    },
    FormOnloadModify: function (executionContext) {
        var formContext = executionContext.getFormContext();
        this.enableDisableFieldsModify(executionContext);
        this.OpenFormBasedOnRecordType(executionContext);
        this.setDefaultValueForUnit(executionContext);
        this.setMandatoryfields(executionContext);
        formContext.getAttribute("niq_profitcenter").setRequiredLevel("required");
        formContext.getAttribute("niq_itemcategorygroups").setRequiredLevel("required");
        formContext.getAttribute("niq_glaccount_aagcode").setRequiredLevel("required");
        this.lockAllFieldsAfterApprovalSubgrids(executionContext);
        this.onProfitCenterChange(executionContext);
    },
    onSaveMethod: function (executionContext) {
        var formContext = executionContext.getFormContext();
        this.OnSaveProfileCenter(executionContext);
    },
    fetchAndDisplayRelatedRecords(executionContext) {
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_pricelist") && CommonForm.Events.CheckValueExists(formContext, "niq_productrequest")) {
            var productRequestId = formContext.getAttribute("niq_productrequest");
            var priceList = formContext.getAttribute("niq_pricelist");

            if (productRequestId) {
                productRequestIdValue = productRequestId.getValue();
                productRequestIdValue = productRequestIdValue[0].id.replace("{", "").replace("}", ""); // Assuming it's a lookup field
                priceList = priceList.getValue();
                priceList = priceList[0].id.replace("{", "").replace("}", "");
                const fetchXml = `
                                <fetch version="1.0" output-format="xml-platform" mapping="logical">
                                    <entity name="niq_productrequestmaterialtaxcategory">
                                        <attribute name="niq_name" />
                                        <attribute name="createdon" />
                                        <attribute name="niq_taxcategoryoption" />
                                        <attribute name="niq_productrequestmaterialtaxcategoryid" />
                                        <order attribute="niq_name" descending="false" />
                                        <filter type="and">
                                            <condition attribute="statecode" operator="eq" value="0" />
                                            <condition attribute="niq_productrequest" operator="eq" value="${productRequestIdValue}" />
                                            <condition attribute="niq_pricelist" operator="eq" value="${priceList}" />
                                        </filter>
                                    </entity>
                                </fetch>
                                `;
                var gridControl = formContext.getControl("productrequestmaterialtaxcategory");
                gridControl.setFilterXml(fetchXml);
                gridControl.refresh();
            }
        }
    },

    showHideFieldForMMProductRequestPriceListItem: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var fieldsList = ["niq_discontinuereason"];
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")) {
            formContext.data.entity.attributes.forEach(function (attr) {
                var fld = attr.getName();
                if (!fieldsList.includes(fld)) {
                    attr.controls.forEach(function (control) {
                        control.setDisabled(true);
                    });
                }
            });
            formContext.getControl("niq_glaccount_aagcode").setDisabled(false);
        }

    },
    showHideFieldForMMProductRequestPriceListItemNew: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var fieldsList = ["niq_itemcategorygroups"];
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")) {
            formContext.getAttribute("niq_itemcategorygroups").setRequiredLevel("required");
            formContext.data.entity.attributes.forEach(function (attr) {
                var fld = attr.getName();
                if (!fieldsList.includes(fld)) {
                    attr.controls.forEach(function (control) {
                        control.setDisabled(true);
                    });
                }
            });
            formContext.getControl("niq_glaccount_aagcode").setDisabled(false);
        }
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner")) {
            formContext.getAttribute("niq_itemcategorygroups").setRequiredLevel("required");
        }

    },
    showHideFieldForMMProductRequestPriceListItem_Extend: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var fieldsList = ["niq_itemcategorygroups", "niq_quantitysellingoption", "niq_taxclassification", "niq_lagrevenuerecognition", "niq_unit"];
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")) {
            formContext.getAttribute("niq_itemcategorygroups").setRequiredLevel("required");
            formContext.data.entity.attributes.forEach(function (attr) {
                var fld = attr.getName();
                if (!fieldsList.includes(fld)) {
                    attr.controls.forEach(function (control) {
                        control.setDisabled(true);
                    });
                }
            });
            formContext.getAttribute("niq_itemcategorygroups").setRequiredLevel("required");
            formContext.getControl("niq_glaccount_aagcode").setDisabled(false);
        }
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner")) {
            formContext.getControl("niq_productrequest").setDisabled(true);
            formContext.getControl("niq_productid").setDisabled(true);
            formContext.getControl("niq_pricelist").setDisabled(true);
            formContext.getControl("niq_quantitysellingoption").setDisabled(true);
            formContext.getAttribute("niq_itemcategorygroups").setRequiredLevel("required");
        }
    },
    // US-21707
    hideBlockCode: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var reqproduct = formContext.getAttribute("niq_productrequest").getValue();
        if (reqproduct != null) {
            var requestproductId = reqproduct[0].id.replace("{", "").replace("}", "");
            var result = await Xrm.WebApi.retrieveRecord("niq_productrequest", requestproductId, "?$select=niq_requesttype");
            var reqtype = result["niq_requesttype"];
            console.log(reqtype);
            if (reqtype == 610570003 || reqtype == 610570004) {
                formContext.getControl("niq_discontinuereason").setVisible(true);
                formContext.getAttribute("niq_discontinuereason").setRequiredLevel("required");
                formContext.getAttribute("niq_materialgroup4").setRequiredLevel("none");
            }
            else {
                if (reqtype == 610570002) {
                    formContext.getAttribute("niq_materialgroup4").setRequiredLevel("required");
                    formContext.getAttribute("niq_glaccount_aagcode").setRequiredLevel("required");
                    var blockCode = new Array();
                    blockCode[0] = new Object();
                    blockCode[0].id = "{81c477ad-abf5-ef11-be1f-6045bd8ae7f5}";
                    blockCode[0].name = "Unblocked";
                    blockCode[0].entityType = "niq_sapproductmastersupportdata";
                    formContext.getAttribute("niq_discontinuereason").setValue(blockCode);
                    formContext.getControl("niq_discontinuereason").setVisible(false);
                    if (!CommonForm.Events.CheckValueExists(formContext, "niq_unit")) {
                        var results = await Xrm.WebApi.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_name,niq_to&$filter=niq_name eq 'Each'");
                        var result = results.entities[0];
                        var uomGuid = result["niq_to"];
                        var lookupSalesGroupOrgValue = new Array();
                        lookupSalesGroupOrgValue[0] = new Object();
                        lookupSalesGroupOrgValue[0].id = uomGuid;
                        lookupSalesGroupOrgValue[0].name = "Each";
                        lookupSalesGroupOrgValue[0].entityType = "uom";
                        formContext.getAttribute("niq_unit").setValue(lookupSalesGroupOrgValue);
                    }
                }
                else {
                    formContext.getControl("niq_discontinuereason").setVisible(false);
                    formContext.getAttribute("niq_discontinuereason").setRequiredLevel("none");
                    formContext.getAttribute("niq_materialgroup4").setRequiredLevel("required");
                    if (reqtype == 610570000) {
                        formContext.getAttribute("niq_glaccount_aagcode").setRequiredLevel("required");
                    }
                }
            }
        }
    },
    //US- 21707
    setMandatoryfields: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var pricelist = formContext.getAttribute("niq_pricelist").getValue();
        if (pricelist != null) {
            var pricelistitem = pricelist[0].id.replace("{", "").replace("}", "");
            var result = await Xrm.WebApi.retrieveRecord("pricelevel", pricelistitem, "?$select=_niq_salesorg_value&$expand=niq_SalesOrg($select=_niq_operatingcountryid_value)");
            if (result.hasOwnProperty("niq_SalesOrg") && result["niq_SalesOrg"] !== null) {
                var countryId = result["niq_SalesOrg"]["_niq_operatingcountryid_value"];
                var country = await Xrm.WebApi.retrieveRecord("niq_country", countryId, "?$select=niq_name");
                console.log(country["niq_name"])
                if (country["niq_name"] == 'India') {
                    formContext.getAttribute("niq_controlcode").setRequiredLevel("required");
                    formContext.getControl("niq_controlcode").setDisabled(false);
                    formContext.getControl("niq_pricecontrolindicator").setDisabled(true);
                }
                else if (country["niq_name"] == 'Brazil') {
                    formContext.getAttribute("niq_valuationclass").setRequiredLevel("required");
                    if (!CommonForm.Events.CheckValueExists(formContext, "niq_valuationclass")) {
                        var lookupSalesGroupOrgValue = new Array();
                        lookupSalesGroupOrgValue[0] = new Object();
                        lookupSalesGroupOrgValue[0].id = "{4cc3ff5d-bff2-ef11-be20-7c1e52519bcf}";
                        lookupSalesGroupOrgValue[0].name = "Miscellaneous Val.Cl.";
                        lookupSalesGroupOrgValue[0].entityType = "niq_sapproductmastersupportdata";
                        formContext.getAttribute("niq_valuationclass").setValue(lookupSalesGroupOrgValue);
                        formContext.getControl("niq_valuationclass").setDisabled(true);
                        formContext.getControl("niq_controlcode").setDisabled(true);
                    }
                    formContext.getAttribute("niq_pricecontrolindicator").setRequiredLevel("required");
                    formContext.getControl("niq_pricecontrolindicator").setDisabled(false);
                }
            }
        }
        else {
            formContext.getAttribute("niq_controlcode").setRequiredLevel("none");
            formContext.getAttribute("niq_valuationclass").setRequiredLevel("none");
            formContext.getAttribute("niq_pricecontrolindicator").setRequiredLevel("none");
            formContext.getAttribute("niq_valuationclass").setValue(null);
            formContext.getControl("niq_pricecontrolindicator").setDisabled(true);
            formContext.getControl("niq_controlcode").setDisabled(true);
            formContext.getControl("niq_valuationclass").setDisabled(true);
        }
    },
    //21681
    setFieldValues: function (executionContext) {
        var formContext = executionContext.getFormContext();
        PreGLAccountAAGCode = formContext.getAttribute("niq_glaccount_aagcode").getValue();
        PreItemCategoryGroup = formContext.getAttribute("niq_itemcategorygroups").getValue();
        PreProfitCenter = formContext.getAttribute("niq_profitcenter").getValue();
    },
    //DYNCRM-21681 check Profit Center, GLAccountAAGCode, Item Category Group change or not
    OnSaveProfileCenter: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var saveMode = executionContext.getEventArgs().getSaveMode();
        if (saveMode == 1 || saveMode == 2 || saveMode == 59) {
            var PreProfitCenterId = null;
            var PreGLAccountAAGCodeId = null;
            var PreItemCategoryGroupId = null;
            var PostProfitCenterId = null;
            var PostGLAccountAAGCodeId = null;
            var PostItemCategoryGroupId = null;
            var ProductRequest = formContext.getAttribute("niq_productrequest").getValue();
            if (ProductRequest != null) {
                var ProductRequestId = ProductRequest[0].id.replace("{", "").replace("}", "");
                var result = await Xrm.WebApi.retrieveRecord("niq_productrequest", ProductRequestId, "?$select=niq_approvalstatus,niq_requesttype");
                var approvalStatus = result["niq_approvalstatus"];
                var requestType = result["niq_requesttype"];
                if (requestType == 610570001) {
                    var record = {};
                    record.niq_approvalstatus = 610570002;
                    var PostGLAccountAAGCode = formContext.getAttribute("niq_glaccount_aagcode").getValue();
                    var PostItemCategoryGroup = formContext.getAttribute("niq_itemcategorygroups").getValue();
                    var PostProfitCenter = formContext.getAttribute("niq_profitcenter").getValue();
                    //For Profile Center
                    if (PreProfitCenter !== null) {
                        PreProfitCenterId = PreProfitCenter[0].id;
                    } else {
                        PreProfitCenterId = null;
                    }
                    if (PostProfitCenter != null) {
                        PostProfitCenterId = PostProfitCenter[0].id;
                    }
                    if (PreProfitCenterId == PostProfitCenterId) {
                        if (approvalStatus == 610570000 || approvalStatus == 610570001) {
                            await Xrm.WebApi.updateRecord("niq_productrequest", ProductRequestId, record);
                        }
                    } else {
                        PreProfitCenter = PostProfitCenter;
                    }
                    //For GLAccount-AAGCode
                    if (PreGLAccountAAGCode !== null) {
                        PreGLAccountAAGCodeId = PreGLAccountAAGCode[0].id;
                    } else {
                        PreGLAccountAAGCodeId = null;
                    }
                    if (PostGLAccountAAGCode != null) {
                        PostGLAccountAAGCodeId = PostGLAccountAAGCode[0].id;
                    }
                    if (PreGLAccountAAGCodeId == PostGLAccountAAGCodeId) {
                        if (approvalStatus == 610570000 || approvalStatus == 610570001) {
                            await Xrm.WebApi.updateRecord("niq_productrequest", ProductRequestId, record);
                        }
                    } else {
                        PreGLAccountAAGCode = PostGLAccountAAGCode;
                    }
                    //Item Category Group
                    if (PreItemCategoryGroup !== null) {
                        PreItemCategoryGroupId = PreItemCategoryGroup[0].id;
                    } else {
                        PreItemCategoryGroupId = null;
                    }
                    if (PostItemCategoryGroup != null) {
                        PostItemCategoryGroupId = PostItemCategoryGroup[0].id;
                    }
                    if (PreItemCategoryGroupId == PostItemCategoryGroupId) {
                        if (approvalStatus == 610570000 || approvalStatus == 610570001) {
                            await Xrm.WebApi.updateRecord("niq_productrequest", ProductRequestId, record);
                        }
                    } else {
                        PreItemCategoryGroup = PostItemCategoryGroup;
                    }
                }
            }
        }
    },
    OpenFormBasedOnRecordType: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var productRequest = formContext.getAttribute("niq_productrequest").getValue();
        if (productRequest != null) {
            var productRequestGuid = productRequest[0].id.replace("{", "").replace("}", "");
            var result = await Xrm.WebApi.retrieveRecord("niq_productrequest", productRequestGuid, "?$select=niq_requesttype");
            var recordtype = result["niq_requesttype"];
            var currentFormId = formContext.ui.formSelector.getCurrentItem().getId();

            var formMap = {
                610570000: "e1f2589c-0900-f011-bae2-7c1e5282b62b", // New Product Request
                610570001: "c53dde41-0121-f011-998a-7c1e528418ea", // Product Request - Modify
                610570002: "14674e81-a61a-f011-9989-6045bda1abcd", // Extend Product Request
                610570003: "b35e2853-082c-f011-8c4d-6045bd9c5fdb", // Block/Unblock Products
                610570004: "b35e2853-082c-f011-8c4d-6045bd9c5fdb", // Block/Unblock Products
            };

            var targetFormId = formMap[recordtype];

            if (targetFormId && currentFormId !== targetFormId) {
                var availableForms = formContext.ui.formSelector.items.get();
                var navigateTo = availableForms.find(function (form) {
                    return form.getId() === targetFormId;
                });

                if (navigateTo) {
                    navigateTo.navigate();
                }
            }
        }
    },
    enableDisableFieldsModify: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var reqproduct = formContext.getAttribute("niq_productrequest").getValue();
        var user = Xrm.Page.context.getUserId().replace("{", "").replace("}", "").toLowerCase();

        if (reqproduct != null) {
            var requestproductId = reqproduct[0].id.replace("{", "").replace("}", "");
            var result = await Xrm.WebApi.retrieveRecord("niq_productrequest", requestproductId, "?$select=niq_approvalstatus,_ownerid_value");
            var owner = result["_ownerid_value"];
        }
        if (user != owner) {
            var arrLockFields = ["niq_itemcategorygroups"];
            var formControls = formContext.ui.controls;
            var productRequest = formContext.getAttribute("niq_productrequest").getValue();
            if (productRequest != null && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")) {
                var productRequestGuid = productRequest[0].id.replace("{", "").replace("}", "");
                var result = await Xrm.WebApi.retrieveRecord("niq_productrequest", productRequestGuid, "?$select=niq_requesttype");
                var requestType = result["niq_requesttype"];
                if (requestType == 610570001) {
                    formControls.forEach(control => {
                        if (control.getName() != "" && control.getName() != null && !arrLockFields.includes(control.getName())) {
                            control.setDisabled(true);
                        }
                    });
                }
                formContext.getControl("niq_glaccount_aagcode").setDisabled(false);
            }
        }
    },


    lockBlockCodeForMM: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var productRequest = formContext.getAttribute("niq_productrequest").getValue();
        if (productRequest != null) {
            var productRequestGuid = productRequest[0].id.replace("{", "").replace("}", "");
            var result = await Xrm.WebApi.retrieveRecord("niq_productrequest", productRequestGuid, "?$select=_ownerid_value,niq_requesttype");
            var owner = result["_ownerid_value"];
            var user = Xrm.Page.context.getUserId().replace("{", "").replace("}", "");
            var requestType = result["niq_requesttype"];
            if (requestType == 610570004) {
                formContext.getControl("niq_discontinuereason").setDisabled(true);
            }
            else if ((owner == user.toLowerCase()) && (requestType == 610570003)) {
                formContext.getControl("niq_discontinuereason").setDisabled(false);
            }
            else {
                formContext.getControl("niq_discontinuereason").setDisabled(true);
            }
        }
    },
    setDefaultValueForUnit: async function (ExecutionContext) {
        var formContext = ExecutionContext.getFormContext();
        if (!CommonForm.Events.CheckValueExists(formContext, "niq_unit")) {
            var results = await Xrm.WebApi.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_name,niq_to&$filter=niq_name eq 'Each'");
            var result = results.entities[0];
            var uomGuid = result["niq_to"];
            var lookupSalesGroupOrgValue = new Array();
            lookupSalesGroupOrgValue[0] = new Object();
            lookupSalesGroupOrgValue[0].id = uomGuid;
            lookupSalesGroupOrgValue[0].name = "Each";
            lookupSalesGroupOrgValue[0].entityType = "uom";
            formContext.getAttribute("niq_unit").setValue(lookupSalesGroupOrgValue);
        }
    },
    lockAllFieldsAfterApprovalSubgrids: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var reqproduct = formContext.getAttribute("niq_productrequest").getValue();
        if (reqproduct != null) {
            var requestproductId = reqproduct[0].id.replace("{", "").replace("}", "");
            var result = await Xrm.WebApi.retrieveRecord("niq_productrequest", requestproductId, "?$select=niq_approvalstatus");
            var approvalStatus = result["niq_approvalstatus"];
            console.log(approvalStatus);
            if (approvalStatus == 610570002 || approvalStatus == 610570003 || approvalStatus == 610570004) {
                var allControls = formContext.ui.controls.get();
                for (var i in allControls) {
                    var control = allControls[i];
                    if (control && control.setDisabled) {
                        control.setDisabled(true);
                    }
                }
            }
        }
    },
    onProfitCenterChange: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var priceList = formContext.getAttribute("niq_pricelist").getValue();

        if (priceList != null) {
            formContext.getControl("niq_profitcenter").setDisabled(false);
            var priceListId = priceList[0].id;

            Xrm.WebApi.retrieveRecord("pricelevel", priceListId.replace("{", "").replace("}", ""), "?$select=_niq_salesorg_value").then(
                function success(result) {
                    var salesOrgId = result["_niq_salesorg_value"];
                    var control = formContext.getControl("niq_profitcenter");
                    if (!ProductRequestPriceListItems.Events._profitCenterPreSearchHandler || ProductRequestPriceListItems.Events._lastSalesOrgId !== salesOrgId) {
                        if (ProductRequestPriceListItems.Events._profitCenterPreSearchHandler) {
                            control.removePreSearch(ProductRequestPriceListItems.Events._profitCenterPreSearchHandler);
                        }
                        ProductRequestPriceListItems.Events._profitCenterPreSearchHandler = function () {
                            var filter = `<filter type="and">
                                            <condition attribute="niq_salesorgid" operator="eq" value="${salesOrgId}" />
                                          </filter>`;
                            control.addCustomFilter(filter);
                        };
                        ProductRequestPriceListItems.Events._lastSalesOrgId = salesOrgId;
                        control.addPreSearch(ProductRequestPriceListItems.Events._profitCenterPreSearchHandler);
                    }
                },
                function (error) {
                    console.error("Error retrieving Price List Sales Org: " + error.message);
                }
            );
        }
        else {
            formContext.getAttribute("niq_profitcenter").setValue(null);
            formContext.getControl("niq_profitcenter").setDisabled(true);
        }
    },
    copyCurrencyFromPriceLevel: function (executionContext) {
        var formContext = executionContext.getFormContext();

        var priceLevel = formContext.getAttribute("niq_pricelist")?.getValue();

        if (priceLevel && priceLevel.length > 0) {
            var priceLevelId = priceLevel[0].id.replace("{", "").replace("}", "");
            Xrm.WebApi.retrieveRecord("pricelevel", priceLevelId, "?$select=_transactioncurrencyid_value&$expand=transactioncurrencyid($select=currencyname)").then(
                function success(result) {
                    if (result.transactioncurrencyid) {
                        formContext.getAttribute("transactioncurrencyid").setValue([
                            {
                                id: result._transactioncurrencyid_value,
                                name: result.transactioncurrencyid.currencyname,
                                entityType: "transactioncurrency"
                            }
                        ]);
                    }
                },
            );
        } else {
            formContext.getAttribute("transactioncurrencyid").setValue(null);
        }
    },
    populateNameField: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var productID = formContext.getAttribute("niq_productid").getValue();
        var priceLevel = formContext.getAttribute("niq_pricelist").getValue();
        if (productID && priceLevel && priceLevel.length > 0) {
            var priceListname = priceLevel[0].name;
            var name = productID + "-" + priceListname;
            formContext.getAttribute("niq_name").setValue(name);
        }
    }
}
