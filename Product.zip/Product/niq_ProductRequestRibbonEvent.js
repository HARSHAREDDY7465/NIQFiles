if (typeof (ProductRequestRibbon) === "undefined") {
    ProductRequestRibbon = {
        __namespace: true
    };
}

ProductRequestRibbon.Events = {

    OnClickOfNewProductRequest: function (executionContext) {
        "use strict";

        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_productrequest";
        entityFormOptions["formId"] = "bf8befbc-aa1d-4c0e-97d6-b13a1929a9b2";// New Product Request
        var formParameters = {};
        formParameters["niq_requesttype"] = 610570000;
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });

    },

    OnClickOfModifyProductRequest: async function (SelectedControlSelectedItemIds, executionContext, selectedControl) {
        "use strict";
        var formContext = executionContext;
        var name = "";
        var entityName = "";
        var entityId = "";
        var appId = "";
        var CanvasAppName = "Product PriceList Picker";
        var selectedItem = SelectedControlSelectedItemIds[0];
        var selectedControlId = selectedControl;
        var selectedRows = selectedControl.getGrid().getSelectedRows();
        if (selectedRows.getLength() == 1) {
            selectedRows.forEach(function (row) {
                var attributes = row.data.entity.attributes._collection;
                var entity = row.getData().getEntity();
                entityName = row.getData().getEntity().getEntityName();
                entityId = row.getData().getEntity().getId().replace('{', '').replace('}', '');
                name = attributes.name.getValue() ? attributes.name.getValue() : "";
            });
            var results = await Xrm.WebApi.retrieveMultipleRecords("productpricelevel", "?$select=_productid_value&$filter=_productid_value eq '" + entityId + "'&$top=1");
            if (results.entities.length > 0) {
                var globalContext = Xrm.Utility.getGlobalContext();
                var clientUrl = globalContext.getCurrentAppUrl() + "&pagetype=entityrecord&etn=niq_productrequest&id=";
                var results = await Xrm.WebApi.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_name,niq_to&$filter=niq_name eq '" + CanvasAppName + "'");
                if (results.entities.length > 0) {
                    var result = results.entities[0]; // Access the first result directly
                    // Columns
                    appId = result["niq_to"]; // Guid
                }
                var appUrl = "https://apps.powerapps.com/play/" + appId + "?ProductId=" + encodeURIComponent(entityId) + "&ClientUrl=" + encodeURIComponent(clientUrl);

                // Open the Canvas app in a popup window
                var windowFeatures = "width=1100,height=900,resizable=yes,scrollbars=yes,status=yes";
                var popupWindow = window.open(appUrl, "CanvasAppPopup", windowFeatures);

                if (popupWindow) {
                    popupWindow.focus();
                } else {
                    alert("Popup blocked. Please allow popups for this site.");
                }
            } else {
                Xrm.Navigation.openAlertDialog({ title: "Warning!", text: "Selected Product does not have any price list item." });
            }
        } else {
            Xrm.Navigation.openAlertDialog({ title: "Warning!", text: "Please Select One Product for modification." });
        }

    },
    OnClickOfExtendProductRequest: function (formContext) {
        "use strict";
        var productID = formContext.data.entity.getId().replace("{", "").replace("}", "");;

        var lookupSalesrefproduct = new Array();
        lookupSalesrefproduct[0] = new Object();
        lookupSalesrefproduct[0].id = productID;
        lookupSalesrefproduct[0].name = formContext.getAttribute("name").getValue();
        lookupSalesrefproduct[0].entityType = "product";
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_productrequest";
        entityFormOptions["formId"] = "cbd7548f-9e13-f011-9989-000d3a28780f"; // Extend product Request

        var formParameters = {};
        formParameters["niq_requesttype"] = 610570002;
        formParameters["niq_approvalstatus"] = 610570000;
        formParameters["niq_referencedproduct"] = lookupSalesrefproduct;
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });

    },

    OnClickOfBulkProductRequest: function (executionContext) {
        "use strict";
        debugger;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_productrequest";
        entityFormOptions["formId"] = "9c141e68-87f2-ef11-be1f-7c1e5274157c"; // Bulk product request

        var formParameters = {};
        formParameters["niq_requesttype"] = 610570005;
        // Open the form.
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });

    },

    ProductRequestButtonsVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner,System Administrator")) {
            return true;
        }
        else {
            return false;
        }
    },
    ProductRequestModifyButtonVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner,System Administrator,NIQ Material Master")) {
            return true;
        }
        else {
            return false;
        }
    },


    OnSelectOfModifyProductRequest: function (executionContext) {
        "use strict";
        var formContext = executionContext;

        var product = new Array();
        product[0] = new Object();
        product[0].id = formContext.data.entity.getId();
        product[0].name = formContext.getAttribute("name").getValue();
        product[0].entityType = "product";

        var formParameters = {};
        formParameters['niq_referencedproduct'] = product;
        formParameters['niq_requesttype'] = 610570001;
        formParameters['niq_approvalstatus'] = 610570000;

        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_productrequest";
        entityFormOptions["formId"] = "bb8a4d1e-881b-f011-998a-6045bd8aacde"; // Modify product request //dcfc744a-4efe-ef11-bae3-000d3a233456

        // Open the form.
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });

    },


    OnSelectOfExtendProductRequest: function (executionContext) {
        "use strict";
        var formContext = executionContext;

        var product = new Array();
        product[0] = new Object();
        product[0].id = formContext.data.entity.getId();
        product[0].name = formContext.getAttribute("name").getValue();
        product[0].entityType = "product";

        var formParameters = {};
        formParameters['niq_referencedproduct'] = product;
        formParameters['niq_requesttype'] = 610570002;
        formParameters['niq_approvalstatus'] = 610570000;

        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_productrequest";
        entityFormOptions["formId"] = "cb0169e1-f3ff-ef11-bae3-6045bda1abcd"; // Extend product request

        // Open the form.
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });

    },
    ProductButtonVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckIfLoggedInUserRoles("System Administrator")) {
            return true;
        }
        else {
            return false;
        }
    },
    NewObjectButtonVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        var approvalStatus = formContext.getAttribute("niq_approvalstatus").getValue();
        //Request Type Extend or Modify
        if (requestType === 610570002 && (approvalStatus == 610570000 || approvalStatus == 610570001 )) {
            return true;
        } else {
            return false
        }
    },
    NewButtonVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        //Request Type Extend or Modify
        if (requestType == 610570002 || requestType == 610570001) {
            return false;
        } else {
            return true
        }
    },

    HideNewProductRequestPriceListButton: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        var approvalStatus = formContext.getAttribute("niq_approvalstatus").getValue();
        if ((requestType == 610570003 || requestType == 610570004 || requestType == 610570001 || requestType == 610570002) || (approvalStatus == 610570002 || approvalStatus == 610570003 || approvalStatus == 610570004) ) {
            return false;
        } else {
            return true
        }
    },
    HideExtendProductRequestButton: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        var productStructure = formContext.getAttribute("productstructure").getValue();
        var brandL1 = formContext.getAttribute("niq_brandlevel1").getValue();
        var brandL2 = formContext.getAttribute("niq_brandlevel2").getValue();
        var brandL3 = formContext.getAttribute("niq_brandlevel3").getValue();
        var brandL4 = formContext.getAttribute("niq_brandlevel4").getValue();
        var status = formContext.getAttribute("statecode").getValue();
        if (productStructure === 1 && brandL1 && brandL2 && brandL3 && brandL4 && status == 0)  {
            return true;
        } else {
            return false
        }
    },
    HideShowUploadButtonProductRequest: function (primaryControl) {
        var formContext = primaryControl;
        var EntityId = formContext.data.entity.getId();
        var EntityName = formContext.data.entity.getEntityName();
        if (EntityName === "niq_productrequest") {
            var owner = formContext.getAttribute("ownerid").getValue()[0].id;
            var user = Xrm.Page.context.getUserId();
            if ((owner != user)) {
                return false;
            }
            else {
                return true;
            }
        }
        return true;
    },
    HideShowNewDeleteButtonProductRequest: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        var approvalStatus = formContext.getAttribute("niq_approvalstatus").getValue();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master") || (approvalStatus == 610570002 || approvalStatus == 610570003 || approvalStatus == 610570004)) {
            return true;
        }
        else {
            return true;
        }
    },
    HideShowNewButtonmaterialTaxCategoryToMM: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        if (requestType == 610570001) {
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")) {
                return false;
            }
            else {
                return true;
            }
        }
    }
}