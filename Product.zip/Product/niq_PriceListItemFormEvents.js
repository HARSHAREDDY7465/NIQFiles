if (typeof (PriceListItemForm) === "undefined") {
    PriceListItemForm = {
        _namespace: true
    };
}
PriceListItemForm.Events = {
    EnableDeliveriesCreationForSystemAdmin: function(executionContext) {
    let formContext = executionContext.getFormContext();
    if(CommonForm.Events.CheckIfLoggedInUserRole("System Administrator"))
    {
          formContext.getControl("niq_excludefrommanualpriceentry").setDisabled(false);
           formContext.getControl("niq_deliveriescreationenabled").setDisabled(false);
      }
     else{
	   formContext.getControl("niq_excludefrommanualpriceentry").setDisabled(true);
           formContext.getControl("niq_deliveriescreationenabled").setDisabled(true);
     }
          
    }
}