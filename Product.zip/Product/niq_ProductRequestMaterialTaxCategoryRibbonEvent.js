if (typeof (ProductRequestMaterialTaxCategoryribbonevent) === "undefined") {
    ProductRequestMaterialTaxCategoryribbonevent = {
        __namespace: true
    };
}
ProductRequestMaterialTaxCategoryribbonevent.Events = {
    //US-21681
    //Hide Add/Delete button from subgrid in Modify-product request form
    HideAddDeleteButton: function (primaryControl) {
        debugger;
        var formContext = primaryControl;
        var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
        if (roles === null) return false;

        var hasRole = false;
        roles.forEach(function (item) {
            if (item.name === "NIQ Finance Business Partner" || item.name === "NIQ Material Master") {
                hasRole = true;
            }
        });
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        if (requestType != null && requestType == 610570001 && hasRole) {
            return false;
        } else {
            return true;
        }
    },
    //US-21681
    //Hide Add/Delete button in Modify-product request form
    HideAddDeleteButtonForm: async function (primaryControl) {
        var formContext = primaryControl;
        var productRequest = formContext.getAttribute("niq_productrequest").getValue();
        var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
        if (roles === null) return false;

        var hasRole = false;
        roles.forEach(function (item) {
            if (item.name === "NIQ Finance Business Partner" || item.name === "NIQ Material Master") {
                hasRole = true;
            }
        });
        if(productRequest != null){
            var productRequestGuid = productRequest[0].id.replace("{","").replace("}","");
            var result = await Xrm.WebApi.retrieveRecord("niq_productrequest", productRequestGuid, "?$select=niq_requesttype");
            var requestType = result["niq_requesttype"];
            //CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner,NIQ Material Master,System Administrator")
            if (requestType != null && requestType == 610570001 && hasRole) {
                return false;
            } else {
                return true;
            }
        }
    }
}