if (typeof (ProductRequestForm) === "undefined") {
    ProductRequestForm = {
        __namespace: true
    };
}
var ExternalMaterialGroupTaxCode = null;
ProductRequestForm.Events = {

    FormOnloadBlock: function (executionContext) {

        "use strict";
        var formContext = executionContext.getFormContext();
        this.OpenFormBasedOnRecordType(executionContext);
        this.enableApproverCommentsField(executionContext);
        this.removeApprovedStatusOptionsBasedonRole(executionContext);
        this.enableRequestorCommentsField(executionContext);
        if (!CommonForm.Events.CheckValueExists(formContext, "niq_distributionchannel")) {
            var lookupSalesGroupOrgValue = new Array();
            lookupSalesGroupOrgValue[0] = new Object();
            lookupSalesGroupOrgValue[0].id = "{58c3ff5d-bff2-ef11-be20-7c1e52519bcf}";
            lookupSalesGroupOrgValue[0].name = "Nielsen Dist. Channel";
            lookupSalesGroupOrgValue[0].entityType = "niq_sapproductmastersupportdata";
            formContext.getAttribute("niq_distributionchannel").setValue(lookupSalesGroupOrgValue);
            formContext.getControl("niq_distributionchannel").setDisabled(true);
        }
        this.enableAssignedMaterialMasterField(executionContext);
        this.lockProductRequestForm(executionContext);
    },
    FormOnload: function (executionContext) {

        "use strict";
        var formContext = executionContext.getFormContext();
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        this.OpenFormBasedOnRecordType(executionContext);
        this.enableApproverCommentsField(executionContext);
        this.showHideTabAndFieldForMM(executionContext);
        this.removeApprovedStatusOptionsBasedonRole(executionContext);
        this.mandatoryFieldsBasedOnEnabledForUS(executionContext);
        this.setFieldsMandatory(executionContext);
        this.setproductIdMandatory(executionContext);
        this.FilterApprovalStatusModify(executionContext);
        this.OnChangeMethod(executionContext);
        this.onLoadSetDefaultValues(executionContext);
        this.showxternalmaterialgrouptaxcodeValue(executionContext);
        this.enableAssignedMaterialMasterField(executionContext);



        formContext.getAttribute("niq_productid") ? formContext.getAttribute("niq_productid").addOnChange(this.checkProductIdValid) : null;
        //Request type Modification
        if (requestType != null && requestType == 610570000) {
            this.lockBrandLevels(executionContext);
            this.MethodOnChangeEvent(executionContext);
            this.Setunitgroupdefaultvalue(executionContext);
            this.setDefaultUnitValue(executionContext);

            var subgridControl = formContext.getControl("Subgrid_new_1");

            if (subgridControl) {
                subgridControl.addOnLoad(function () {
                    // Grid is now loaded ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â you can safely access its data
                    console.log("Subgrid loaded and ready.");
                });
            }

        }
        if (requestType != null && requestType == 610570001) {
            this.setFieldValues(executionContext);
            this.enableDisableFields(executionContext);
            this.lockBrandLevels(executionContext);
            this.MethodOnChangeEvent(executionContext);
            this.setDefaultUnitValue(executionContext);
        }
        formContext.data.saveMode;
        //formContext.getAttribute("niq_approvalstatus").addOnChange(this.lockProductRequestForm);
        this.lockProductRequestForm(executionContext);

    },
    Setunitgroupdefaultvalue: function (executionContext) {
        var lookupValue = [{
            id: "0774b360-b698-4600-a9db-78016cb838b2",
            name: "Each",
            entityType: "uomschedule"
        }];
        Xrm.Page.getAttribute("niq_unitgroup").setValue(lookupValue);
    },
    setDefaultUnitValue: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (!CommonForm.Events.CheckValueExists(formContext, "niq_defaultunit")) {
            var results = await Xrm.WebApi.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_name,niq_to&$filter=niq_name eq 'Each'");
            var result = results.entities[0];
            var uomGuid = result["niq_to"];
            var lookupSalesGroupOrgValue = new Array();
            lookupSalesGroupOrgValue[0] = new Object();
            lookupSalesGroupOrgValue[0].id = uomGuid;
            lookupSalesGroupOrgValue[0].name = "Each";
            lookupSalesGroupOrgValue[0].entityType = "uom";
            formContext.getAttribute("niq_defaultunit").setValue(lookupSalesGroupOrgValue);
        }
    },
    MethodOnChangeEvent: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.getAttribute("niq_brandlevel1").addOnChange(this.lockBrandLevels);
        formContext.getAttribute("niq_brandlevel2").addOnChange(this.lockBrandLevels);
        formContext.getAttribute("niq_brandlevel3").addOnChange(this.lockBrandLevels);
        formContext.getAttribute("niq_brandlevel4").addOnChange(this.lockBrandLevels);
    },
    lockBrandLevels: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var user = Xrm.Page.context.getUserId();
        var owner = formContext.getAttribute("ownerid").getValue()[0].id;
        if ((user == owner) || owner == null || owner == "") {
            var brandL1 = formContext.getAttribute("niq_brandlevel1").getValue();
            var requestType = formContext.getAttribute("niq_requesttype").getValue();
            if (requestType == 610570000 /*&& CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner")*/) {

                if (brandL1 != null && brandL1 != "") {
                    formContext.getControl("niq_brandlevel2").setDisabled(false);

                }
                else {
                    formContext.getAttribute("niq_brandlevel2").setValue(null);
                    formContext.getAttribute("niq_brandlevel3").setValue(null);
                    formContext.getAttribute("niq_brandlevel4").setValue(null);
                    formContext.getControl("niq_brandlevel2").setDisabled(true);
                    formContext.getControl("niq_brandlevel3").setDisabled(true);
                    formContext.getControl("niq_brandlevel4").setDisabled(true);
                }
                var brandL2 = formContext.getAttribute("niq_brandlevel2").getValue();
                if (brandL2 != null && brandL2 != "") {
                    formContext.getControl("niq_brandlevel3").setDisabled(false);
                }
                else {
                    formContext.getAttribute("niq_brandlevel3").setValue(null);
                    formContext.getAttribute("niq_brandlevel4").setValue(null);
                    formContext.getControl("niq_brandlevel3").setDisabled(true);
                    formContext.getControl("niq_brandlevel4").setDisabled(true);
                }
                var brandL3 = formContext.getAttribute("niq_brandlevel3").getValue();
                if (brandL3 != null && brandL3 != "") {
                    formContext.getControl("niq_brandlevel4").setDisabled(false);
                }
                else {
                    formContext.getAttribute("niq_brandlevel4").setValue(null);
                    formContext.getControl("niq_brandlevel4").setDisabled(true);
                }
            }
            if (requestType == 610570001) {
                if (brandL1 != null && brandL1 != "") {
                    formContext.getControl("niq_brandlevel2").setDisabled(false);

                }
                else {
                    formContext.getAttribute("niq_brandlevel2").setValue(null);
                    formContext.getAttribute("niq_brandlevel3").setValue(null);
                    formContext.getAttribute("niq_brandlevel4").setValue(null);
                    formContext.getControl("niq_brandlevel2").setDisabled(true);
                    formContext.getControl("niq_brandlevel3").setDisabled(true);
                    formContext.getControl("niq_brandlevel4").setDisabled(true);
                }
                var brandL2 = formContext.getAttribute("niq_brandlevel2").getValue();
                if (brandL2 != null && brandL2 != "") {
                    formContext.getControl("niq_brandlevel3").setDisabled(false);
                }
                else {
                    formContext.getAttribute("niq_brandlevel3").setValue(null);
                    formContext.getAttribute("niq_brandlevel4").setValue(null);
                    formContext.getControl("niq_brandlevel3").setDisabled(true);
                    formContext.getControl("niq_brandlevel4").setDisabled(true);
                }
                var brandL3 = formContext.getAttribute("niq_brandlevel3").getValue();
                if (brandL3 != null && brandL3 != "") {
                    formContext.getControl("niq_brandlevel4").setDisabled(false);
                }
                else {
                    formContext.getAttribute("niq_brandlevel4").setValue(null);
                    formContext.getControl("niq_brandlevel4").setDisabled(true);
                }
            }
        }
    },
    enableAssignedMaterialMasterField: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_assignedmaterialmaster")) {
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")) {
                formContext.getControl("header_niq_assignedmaterialmaster").setDisabled(false);
            }
            else {
                formContext.getControl("header_niq_assignedmaterialmaster").setDisabled(true);
            }
        }
    },
    onLoadSetDefaultValues: function (executionContext) {

        var formContext = executionContext.getFormContext();
        var reqtype = formContext.getAttribute("niq_requesttype").getValue();
        if (reqtype == 610570000) // New type
        {
            //formContext.getAttribute("niq_brandlevel1").setRequiredLevel("required");
            //formContext.getAttribute("niq_brandlevel2").setRequiredLevel("required");
            //formContext.getAttribute("niq_brandlevel3").setRequiredLevel("required");
            //formContext.getAttribute("niq_brandlevel4").setRequiredLevel("required");
            formContext.getAttribute("niq_defaultpricelist").setRequiredLevel("required");
            formContext.getAttribute("niq_enabledforus").setRequiredLevel("required");
            formContext.getAttribute("niq_materialgroup").setRequiredLevel("required");

            if (!CommonForm.Events.CheckValueExists(formContext, "niq_statisticsgroup")) {
                var statisticGroup = new Array();
                statisticGroup[0] = new Object();
                statisticGroup[0].id = "{4ac3ff5d-bff2-ef11-be20-7c1e52519bcf}";
                statisticGroup[0].name = "MI SD Materials";
                statisticGroup[0].entityType = "niq_sapproductmastersupportdata";
                formContext.getAttribute("niq_statisticsgroup").setValue(statisticGroup);
            }
            if (!CommonForm.Events.CheckValueExists(formContext, "niq_industry")) {
                var lookupSalesGroupOrgValue = new Array();
                lookupSalesGroupOrgValue[0] = new Object();
                lookupSalesGroupOrgValue[0].id = "{54c3ff5d-bff2-ef11-be20-7c1e52519bcf}";
                lookupSalesGroupOrgValue[0].name = "TNC Services";
                lookupSalesGroupOrgValue[0].entityType = "niq_sapproductmastersupportdata";
                formContext.getAttribute("niq_industry").setValue(lookupSalesGroupOrgValue);
            }
            if (!CommonForm.Events.CheckValueExists(formContext, "niq_materialtype")) {
                var lookupSalesGroupOrgValue = new Array();
                lookupSalesGroupOrgValue[0] = new Object();
                lookupSalesGroupOrgValue[0].id = "{56c3ff5d-bff2-ef11-be20-7c1e52519bcf}";
                lookupSalesGroupOrgValue[0].name = "TNC Service Material Type";
                lookupSalesGroupOrgValue[0].entityType = "niq_sapproductmastersupportdata";
                formContext.getAttribute("niq_materialtype").setValue(lookupSalesGroupOrgValue);
            }
            if (!CommonForm.Events.CheckValueExists(formContext, "niq_distributionchannel")) {
                var lookupSalesGroupOrgValue = new Array();
                lookupSalesGroupOrgValue[0] = new Object();
                lookupSalesGroupOrgValue[0].id = "{58c3ff5d-bff2-ef11-be20-7c1e52519bcf}";
                lookupSalesGroupOrgValue[0].name = "Nielsen Dist. Channel";
                lookupSalesGroupOrgValue[0].entityType = "niq_sapproductmastersupportdata";
                formContext.getAttribute("niq_distributionchannel").setValue(lookupSalesGroupOrgValue);
            }

        }
        if (reqtype == 610570002) // Extend
        {
            if (!CommonForm.Events.CheckValueExists(formContext, "niq_distributionchannel")) {
                var lookupSalesGroupOrgValue = new Array();
                lookupSalesGroupOrgValue[0] = new Object();
                lookupSalesGroupOrgValue[0].id = "{58c3ff5d-bff2-ef11-be20-7c1e52519bcf}";
                lookupSalesGroupOrgValue[0].name = "Nielsen Dist. Channel";
                lookupSalesGroupOrgValue[0].entityType = "niq_sapproductmastersupportdata";
                formContext.getAttribute("niq_distributionchannel").setValue(lookupSalesGroupOrgValue);
            }
            if (!CommonForm.Events.CheckValueExists(formContext, "niq_statisticsgroup")) {
                var statisticGroup = new Array();
                statisticGroup[0] = new Object();
                statisticGroup[0].id = "{4ac3ff5d-bff2-ef11-be20-7c1e52519bcf}";
                statisticGroup[0].name = "MI SD Materials";
                statisticGroup[0].entityType = "niq_sapproductmastersupportdata";
                formContext.getAttribute("niq_statisticsgroup").setValue(statisticGroup);
            }
        }
    },
    OnChangeMethod: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        //Request type Modification
        if (requestType == requestType != null && requestType == 610570001) {
            formContext.getAttribute("niq_enabledforus").addOnChange(this.enableDisableFields);
            formContext.getAttribute("niq_enabledforus").addOnChange(this.mandatoryFieldsBasedOnEnabledForUS);
        }
    },
    setproductIdMandatory: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var reqtype = formContext.getAttribute("niq_requesttype").getValue();
        if (reqtype == 610570000) {
            formContext.getAttribute("niq_productid").setRequiredLevel("required");
            formContext.getAttribute("niq_productdescription").setRequiredLevel("required");
        }
    },
    enableApproverCommentsField: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var reqtype = formContext.getAttribute("niq_requesttype").getValue();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")) {
            if (reqtype == 610570000 || reqtype == 610570002 || reqtype == 610570001) //New or Extend requests or Modification
            {
                formContext.getControl("niq_approvercomment").setDisabled(false);
                formContext.getAttribute("niq_approvercomment").setRequiredLevel("required");
            }
            else if (reqtype == 610570003 || reqtype == 610570004) // Block or Unblock requests
            {
                formContext.getControl("niq_approvercomment").setDisabled(false);
                formContext.getAttribute("niq_approvercomment").setRequiredLevel("required");
                formContext.getControl("niq_approvalstatus").setDisabled(false);
                formContext.getControl("niq_requestorcomment").setDisabled(true);
                formContext.getControl("niq_distributionchannel").setDisabled(true);
            }
        }
        else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner")) {
            formContext.getControl("niq_approvercomment").setDisabled(true);
        }
    },
    enableRequestorCommentsField: function (executionContext) {
        var formContext = executionContext.getFormContext();

        if (CommonForm.Events.CheckIfLoggedInUserRoles("System Administrator,NIQ Finance Business Partner,System Customizer")) {
            formContext.getControl("niq_requestorcomment").setDisabled(false);
        }
        else {
            formContext.getControl("niq_requestorcomment").setDisabled(true);
        }
    },
    showHideTabAndFieldForMM: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var fieldsList = ["niq_approvalstatus", "niq_externalmaterialgrouptaxcode", "niq_approvercomment"];
        var user = Xrm.Page.context.getUserId();
        var owner = formContext.getAttribute("ownerid").getValue()[0].id;
        if (user != owner) {
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")) {
                formContext.data.entity.attributes.forEach(function (attr) {
                    var fld = attr.getName();
                    if (!fieldsList.includes(fld)) {
                        attr.controls.forEach(function (control) {
                            control.setDisabled(true);
                        });
                    }

                });
            }
        }
    },
    removeApprovedStatusOptionsBasedonRole: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var reqtype = formContext.getAttribute("niq_requesttype").getValue();
        var createdInSAP = formContext.getAttribute("niq_createdinsap").getValue();
        if(!createdInSAP){
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")) {
                formContext.getControl("niq_approvalstatus").removeOption(610570000);
                formContext.getControl("niq_approvalstatus").removeOption(610570004);
            }
            else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner")) {
                var approvalstatus = formContext.getAttribute("niq_approvalstatus").getValue();
                if (approvalstatus == 610570002 || approvalstatus == 610570003 || approvalstatus == 610570004) {
                    formContext.getControl("niq_approvalstatus").setDisabled(true);
                }
                else {
                    formContext.getControl("niq_approvalstatus").removeOption(610570002);
                    formContext.getControl("niq_approvalstatus").removeOption(610570004);
                    formContext.getControl("niq_approvalstatus").removeOption(610570003);
                }
            }
        }
    },
   mandatoryFieldsBasedOnEnabledForUS: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var enabledforus = formContext.getAttribute("niq_enabledforus").getValue();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner,System Administrator, NIQ Material Master")) {
            if (!enabledforus) {
                formContext.getAttribute("niq_deliverymethod").setRequiredLevel("none");
                formContext.getAttribute("niq_deliveryfrequency").setRequiredLevel("none");
                formContext.getAttribute("niq_datatype").setRequiredLevel("none");
                formContext.getAttribute("niq_productdeliverytype").setRequiredLevel("none");
                formContext.getAttribute("niq_subscriptionaccessmode").setRequiredLevel("none");
                formContext.getAttribute("niq_chargetype").setRequiredLevel("none");
                formContext.getAttribute("niq_licensingoptionavailable").setRequiredLevel("none");
                formContext.getAttribute("niq_periodicupdatesavailable").setRequiredLevel("none");
                formContext.getAttribute("niq_externalmaterialgrouptaxcode").setRequiredLevel("none");
                formContext.getControl("niq_deliverymethod").setVisible(false);
                formContext.getControl("niq_deliveryfrequency").setVisible(false);
                formContext.getControl("niq_datatype").setVisible(false);
                formContext.getControl("niq_productdeliverytype").setVisible(false);
                formContext.getControl("niq_subscriptionaccessmode").setVisible(false);
                formContext.getControl("niq_chargetype").setVisible(false);
                formContext.getControl("niq_licensingoptionavailable").setVisible(false);
                formContext.getControl("niq_periodicupdatesavailable").setVisible(false);
                formContext.getControl("niq_externalmaterialgrouptaxcode").setVisible(false);
            }
            else {
                formContext.getControl("niq_deliverymethod").setVisible(true);
                formContext.getControl("niq_deliveryfrequency").setVisible(true);
                formContext.getControl("niq_datatype").setVisible(true);
                formContext.getControl("niq_productdeliverytype").setVisible(true);
                formContext.getControl("niq_subscriptionaccessmode").setVisible(true);
                formContext.getControl("niq_chargetype").setVisible(true);
                formContext.getControl("niq_licensingoptionavailable").setVisible(true);
                formContext.getControl("niq_periodicupdatesavailable").setVisible(true);
                formContext.getControl("niq_externalmaterialgrouptaxcode").setVisible(true);
                formContext.getAttribute("niq_deliverymethod").setRequiredLevel("required");
                formContext.getAttribute("niq_deliveryfrequency").setRequiredLevel("required");
                formContext.getAttribute("niq_datatype").setRequiredLevel("required");
                formContext.getAttribute("niq_productdeliverytype").setRequiredLevel("required");
                formContext.getAttribute("niq_subscriptionaccessmode").setRequiredLevel("required");
                formContext.getAttribute("niq_chargetype").setRequiredLevel("required");
                formContext.getAttribute("niq_licensingoptionavailable").setRequiredLevel("required");
                formContext.getAttribute("niq_periodicupdatesavailable").setRequiredLevel("required");
                if(!(CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner")))
                {
                    formContext.getAttribute("niq_externalmaterialgrouptaxcode").setRequiredLevel("required");
                }
                
            }
        }
        else {
            formContext.getControl("niq_deliverymethod").setVisible(true);
            formContext.getControl("niq_deliveryfrequency").setVisible(true);
            formContext.getControl("niq_datatype").setVisible(true);
            formContext.getControl("niq_productdeliverytype").setVisible(true);
            formContext.getControl("niq_subscriptionaccessmode").setVisible(true);
            formContext.getControl("niq_chargetype").setVisible(true);
            formContext.getControl("niq_licensingoptionavailable").setVisible(true);
            formContext.getControl("niq_periodicupdatesavailable").setVisible(true);
            formContext.getControl("niq_externalmaterialgrouptaxcode").setVisible(true);
        }
    },
    onSaveFieldsBlock: function (executionContext) {
        this.AutoApproveBlockUnblockForMM(executionContext);
    },
    setFieldsMandatory: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var reqtype = formContext.getAttribute("niq_requesttype").getValue();
        if (reqtype == 610570000 || reqtype == 610570001) // New type and Modification
        {
            //formContext.getAttribute("niq_brandlevel1").setRequiredLevel("required");
            //formContext.getAttribute("niq_brandlevel2").setRequiredLevel("required");
            //formContext.getAttribute("niq_brandlevel3").setRequiredLevel("required");
            //formContext.getAttribute("niq_brandlevel4").setRequiredLevel("required");
            formContext.getAttribute("niq_defaultpricelist").setRequiredLevel("required");
            formContext.getAttribute("niq_enabledforus").setRequiredLevel("required");
            formContext.getAttribute("niq_materialgroup").setRequiredLevel("required");
            formContext.getAttribute("niq_statisticsgroup").setRequiredLevel("required");
            formContext.getAttribute("niq_industry").setRequiredLevel("required");
            formContext.getAttribute("niq_materialtype").setRequiredLevel("required");
            formContext.getAttribute("niq_distributionchannel").setRequiredLevel("required");
            formContext.getAttribute("niq_defaultunit").setRequiredLevel("required");
            formContext.getAttribute("niq_unitgroup").setRequiredLevel("required");

        }
    },
    onSaveFields: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.ui.clearFormNotification("Error_ProductRequest");
        const productRequestId = formContext.data.entity.getId();
        var reqtype = formContext.getAttribute("niq_requesttype").getValue();
        var approvalStatus = formContext.getAttribute("niq_approvalstatus").getValue();
        var args = executionContext.getEventArgs();

        if (reqtype == 610570000) //new type
        {
            var productID = formContext.getAttribute("niq_productid").getValue();
            var pricelist = formContext.getAttribute("niq_defaultpricelist").getValue();
            var names = productID + "-" + pricelist[0].name;
            console.log(names);
            formContext.getAttribute("niq_names").setValue(String(names));
        }
        else if (reqtype == 610570001) //modify
        {
            this.OnSaveExternalMaterialGroup(executionContext);
        }
        else if (reqtype == 610570002) // extend
        {
            if (approvalStatus == 610570001 || approvalStatus == 610570002) {
                var gridCount = formContext.getControl("productrequestpricelistitems").getGrid().getRows().getLength();
                if (gridCount <= 0) {
                    args.preventDefault();
                    formContext.ui.setFormNotification(
                        "Please add the record in Price List Item grid for extension to continue processing this request.",
                        "ERROR",
                        "Error_ProductRequest"
                    );
                }
            }
        }
    },

    getProductRequestPricelistitems: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        const productRequestId = formContext.data.entity.getId();
        if (productRequestId != null && productRequestId != "") {
            var results = await Xrm.WebApi.retrieveMultipleRecords("niq_productrequestpricelistitems", "?$expand=niq_PriceList($select=name),niq_ProductRequest($select=niq_productrequestid)&$filter=(niq_ProductRequest/niq_productrequestid eq " + productRequestId + ")");
            if (results.entities.count > 0) {
                var result = results.entities[0];
                if (result.hasOwnProperty("niq_PriceList") && result["niq_PriceList"] !== null) {
                    var pricelistitem = result["niq_PriceList"]["name"]; //price list name
                }
                var prodid = formContext.getAttribute("niq_productid").getValue();
                var name = prodid + "-" + pricelistitem;
                formContext.getAttribute("niq_names").setValue(name);
            }
        }
    },
    OpenCreateSalesOrgExtensionLookupObjects: async function (formContext) {
        var gridCount = formContext.getControl("productrequestpricelistitems").getGrid().getRows().getLength();
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        const productRequestId = formContext.data.entity.getId();
        var refProductID = formContext.getAttribute("niq_referencedproduct");
        let recordsList = [];
        var lookupOptions = {};
        if (refProductID && refProductID.getValue() && refProductID.getValue().length > 0 && requestType != null) {
            refProductID = refProductID.getValue()[0].id.replace("{", "").replace("}", "");
            let productRequestId = formContext.data.entity.getId();
            productRequestId = productRequestId.replace("{", "").replace("}", "");
            const fetchXml = `
            <fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
            <entity name="productpricelevel">
                <filter type="and">
                <condition attribute="productid" operator="eq" value="${refProductID}" />
                </filter>
                <link-entity name="pricelevel" from="pricelevelid" to="pricelevelid" visible="false" link-type="outer" alias="pricelist">
                <attribute name="pricelevelid" />
                </link-entity>
            </entity>
            </fetch>
        `;

            var result = await Xrm.WebApi.retrieveMultipleRecords("productpricelevel", "?fetchXml=" + encodeURIComponent(fetchXml));

            const fetchXml_2 = `
            <fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
            <entity name="niq_productrequestpricelistitems">
                <filter type="and">
                <condition attribute="niq_productrequest" operator="eq" value="${productRequestId}" />
                </filter>
                <link-entity name="pricelevel" from="pricelevelid" to="niq_pricelist" visible="false" link-type="outer" alias="Productrequestpricelist">
                <attribute name="pricelevelid" />
                </link-entity>
            </entity>
            </fetch>
        `;

            var result2 = await Xrm.WebApi.retrieveMultipleRecords("niq_productrequestpricelistitems", "?fetchXml=" + encodeURIComponent(fetchXml_2));

            if (result.entities.length > 0) {
                let recordsList = result.entities.map(record => record["pricelist.pricelevelid"]);
                if (result2.entities.length > 0) {
                    let recordsList2 = result2.entities.map(record => record["Productrequestpricelist.pricelevelid"]);
                    recordsList = recordsList.concat(recordsList2);
                }

                var fetchXmlFilter = "";
                //Request Type eq Extend
                if (requestType === 610570002) {
                    fetchXmlFilter = `
                    <filter type="and">
                        <condition attribute="pricelevelid" operator="not-in">
                            ${recordsList.map(value => `<value>${value}</value>`).join("")}
                        </condition>
                    </filter>
                `;
                } else if (requestType === 610570001) //Request Type eq Modify
                {
                    fetchXmlFilter = `
                    <filter type="and">
                        <condition attribute="pricelevelid" operator="in">
                            ${recordsList.map(value => `<value>${value}</value>`).join("")}
                        </condition>
                    </filter>
                `;
                }
                lookupOptions =
                {
                    defaultEntityType: "pricelevel",
                    entityTypes: ["pricelevel"],
                    allowMultiSelect: true,
                    defaultViewId: "2261e01b-b7e6-433a-8d6d-f1fd6ac9f70f",
                    viewIds: ["2261e01b-b7e6-433a-8d6d-f1fd6ac9f70f"],
                    searchText: "",
                    filters: [{ entityLogicalName: "pricelevel", filterXml: fetchXmlFilter }]
                };
            }

        } else {
            lookupOptions =
            {
                defaultEntityType: "pricelevel",
                entityTypes: ["pricelevel"],
                allowMultiSelect: true,
                defaultViewId: "2261e01b-b7e6-433a-8d6d-f1fd6ac9f70f",
                viewIds: ["2261e01b-b7e6-433a-8d6d-f1fd6ac9f70f"],
                searchText: "",
                filters: []
            };
        }

        Xrm.Utility.lookupObjects(lookupOptions).then(
            async function (selectedSalesOrgs) {
                if (selectedSalesOrgs.length > 0) {
                    let createPromises = [];
                    for (let i = 0; i < selectedSalesOrgs.length; i++) {
                        createPromises.push(ProductRequestForm.Events.CreateSalesOrgExtensionRecord(formContext, selectedSalesOrgs[i]));
                    }

                    const results = await Promise.allSettled(createPromises);

                    let errorMessages = results
                        .filter(r => r.status === "rejected")
                        .map(r => {
                            if (typeof r.reason === "string") {
                                return r.reason.replace(/^Plugin Exception:\s*/i, "");
                            }
                            return r.reason;
                        });

                    if (errorMessages.length > 0) {
                        // Add your additional message at the end
                        errorMessages.push("Above record(s) cannot be added to this extension Request.");
                        Xrm.Navigation.openAlertDialog({
                            title: "Validation Errors",
                            text: errorMessages.join('\n\n')
                        });
                    }
                }
            },
            function (error) {
                console.log(error);
            });
    },

    CreateSalesOrgExtensionRecord: async function (formContext, salesOrgObj) {
        return new Promise(async (resolve, reject) => {
            let productRequestId = formContext.data.entity.getId();
            var refProductID = "";
            productRequestId = productRequestId.replace("{", "").replace("}", "");
            var refProduct = formContext.getAttribute("niq_referencedproduct").getValue();
            if (refProduct != null) {
                var result = await Xrm.WebApi.retrieveRecord("product", refProduct[0].id.replace("{", "").replace("}", ""), "?$select=productnumber");
                refProductID = result["productnumber"];
            }

            let salesOrgId = salesOrgObj.id;
            salesOrgId = salesOrgId.replace("{", "").replace("}", "");
            var record = {};
            record["niq_PriceList@odata.bind"] = "/pricelevels(" + salesOrgId + ")";
            record["niq_ProductRequest@odata.bind"] = "/niq_productrequests(" + productRequestId + ")";
            record.niq_productid = refProductID;

            Xrm.WebApi.createRecord("niq_productrequestpricelistitems", record).then(
                function success(result) {
                    console.log("Product created with ID: " + result.id);
                    formContext.getControl("productrequestpricelistitems").refresh();
                    resolve(result);
                },
                function (error) {
                    reject(error.message);
                }
            );
        });
    },
    OpenFormBasedOnRecordType: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var recordtype = formContext.getAttribute("niq_requesttype").getValue();
        var currentFormId = formContext.ui.formSelector.getCurrentItem().getId();

        var formMap = {
            610570000: "bf8befbc-aa1d-4c0e-97d6-b13a1929a9b2", // New Product Request
            610570001: "bb8a4d1e-881b-f011-998a-6045bd8aacde", // Product Request - Modify
            610570002: "cbd7548f-9e13-f011-9989-000d3a28780f", // Extend Product Request
            610570003: "fdefabea-3f11-f011-9989-6045bd91605b", // Block/Unblock Products
            610570004: "fdefabea-3f11-f011-9989-6045bd91605b", // Block/Unblock Products
        };

        var targetFormId = formMap[recordtype];

        if (targetFormId && currentFormId !== targetFormId) {
            var availableForms = formContext.ui.formSelector.items.get();
            var navigateTo = availableForms.find(function (form) {
                return form.getId() === targetFormId;
            });

            if (navigateTo) {
                navigateTo.navigate();
            }
        }
    },
    OpenTheRecordSidePane: async function (executionContext) {
        const paneId = "SalesOrgExtensionSidePane";
        const formContext = executionContext.getFormContext();
        const entityName = formContext.data.entity.getEntityName();
        const recordId = formContext.data.entity.getId();
        const productRequest = formContext.getAttribute("niq_productrequest").getValue();

        if (recordId == null) {
            return;
        }

        const pane = Xrm.App.sidePanes.getPane(paneId) ?? await Xrm.App.sidePanes.createPane({
            paneId: paneId,
            canClose: true
        });
        pane.width = 600;  //you can decide what's the width of the side pane.
        //you could change the width for each record, in case you want to
        pane.navigate({
            pageType: "entityrecord",
            entityName: entityName,
            entityId: recordId,
            formId: "14674e81-a61a-f011-9989-6045bda1abcd"
        });

        Xrm.WebApi.retrieveMultipleRecords("niq_productrequestmaterialtaxcategory", "?$filter=_niq_productrequest_value eq " + productRequest[0].id.replace("{", "").replace("}", "")).then(
            function success(result) {
                if (result.entities.length > 0) {
                    // Assuming you have a function to update the grid
                    //var gridControl = formContext.getControl("productrequestmaterialtaxcategory");\
                    var sidepanegridnew = formContext.getControl("productrequestmaterialtaxcategory");
                    var sidePaneGrid = Xrm.Page.getControl("productrequestmaterialtaxcategory");
                    sidePaneGrid.clear();
                    result.entities.forEach(function (record) {
                        sidePaneGrid.addRow(record);
                    });
                    sidePaneGrid.refresh();
                } else {
                    console.log("No related records found.");
                }
            },
            function (error) {
                console.log(error.message);
            }
        );
    },
    //US-21681
    FilterApprovalStatusModify: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var approvalStatus = formContext.getControl("niq_approvalstatus");
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        var createdInSAP = formContext.getAttribute("niq_createdinsap").getValue();
        //Request Type eq Modification
        if(!createdInSAP){
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner") && requestType == 610570001) {
                approvalStatus.clearOptions();
                var arrFBPValues = [
                    { text: "Draft", value: 610570000 },
                    { text: "Pending Approval", value: 610570001 }
                ];
                var arrReadOnlyFields = ["niq_productid", "niq_priceunit", "niq_industry", "niq_materialtype", "niq_distributionchannel"]
                arrFBPValues.forEach(option => {
                    approvalStatus.addOption({ value: option.value, text: option.text }); // Add using text & value
                });
                for (var i = 0; i < arrReadOnlyFields.length; i++) {
                    formContext.getControl(arrReadOnlyFields[i]).setDisabled(true);
                }
            }
            else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")) {
                approvalStatus.clearOptions();
                var arrMMValues = [
                    { text: "Pending Approval", value: 610570001 },
                    { text: "Approved", value: 610570002 },
                    { text: "Rejected", value: 610570003 }
                ];
                arrMMValues.forEach(option => {
                    approvalStatus.addOption({ value: option.value, text: option.text }); // Add using text & value
                });
            }
        }
    },
    //DYNCRM-21681
    enableDisableFields: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var enabledForUs = formContext.getAttribute("niq_enabledforus").getValue();
        var arrLockFields = ["niq_deliverymethod", "niq_deliveryfrequency", "niq_datatype", "niq_productdeliverytype", "niq_subscriptionaccessmode",
            "niq_licensingoptionavailable", "niq_periodicupdatesavailable", "niq_chargetype"
        ];
        if (!enabledForUs && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance Business Partner,NIQ Material Master")) {
            for (var i = 0; i < arrLockFields.length; i++) {
                formContext.getControl(arrLockFields[i]).setDisabled(true);
            }
        } else {
            for (var i = 0; i < arrLockFields.length; i++) {
                formContext.getControl(arrLockFields[i]).setDisabled(false);
                formContext.getAttribute(arrLockFields[i]).setRequiredLevel("required");
            }
        }
    },

    checkProductIdValid: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var Regexp = /^[a-zA-Z0-9-_ /]+$/;  // This will allow only numbers, alphabets, dashes, and underscores
        var reqtype = formContext.getAttribute("niq_productid").getValue();

        if (!Regexp.test(reqtype)) {
            //Xrm.Navigation.openAlertDialog({ title: "Warning!", text: "Product ID should contain valid characters." });
            Xrm.Page.getControl("niq_productid").setNotification('Product id can only have Alpha numerics and special characters - and _');
        }
        else {
            if (reqtype != null && reqtype != "") {
                formContext.getControl("niq_productid").clearNotification();
                var productid = reqtype.toUpperCase();
                formContext.getAttribute("niq_productid").setValue(productid);
                console.log(productid);
            }
        }
    },

    showxternalmaterialgrouptaxcodeValue: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var reqtype = formContext.getAttribute("niq_requesttype").getValue();

        if (reqtype == 610570002) {
            var refProductID = formContext.getAttribute("niq_referencedproduct");

            if (refProductID && refProductID.getValue() && refProductID.getValue().length > 0) {
                refProductID = formContext.getAttribute("niq_referencedproduct").getValue()[0].id.replace("{", "").replace("}", "");
                Xrm.WebApi.retrieveRecord("product", refProductID, "?$select=_niq_externalmaterialgrouptaxcode_value").then(
                    function (result) {
                        var lookupExternal = new Array();
                        lookupExternal[0] = new Object();
                        lookupExternal[0].id = result["_niq_externalmaterialgrouptaxcode_value"];
                        lookupExternal[0].name = result["_niq_externalmaterialgrouptaxcode_value@OData.Community.Display.V1.FormattedValue"];
                        lookupExternal[0].entityType = result["_niq_externalmaterialgrouptaxcode_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        formContext.getAttribute("niq_externalmaterialgrouptaxcode").setValue(lookupExternal);
                    }
                );
            }
        }

    },
    //DYNCRM-21681
    setFieldValues: function (executionContext) {
        var formContext = executionContext.getFormContext();
        ExternalMaterialGroupTaxCode = formContext.getAttribute("niq_externalmaterialgrouptaxcode").getValue();
    },
    //DYNCRM-21681 check External Material Group Tax code field change or not
    OnSaveExternalMaterialGroup: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var saveMode = executionContext.getEventArgs().getSaveMode();
        if (saveMode == 1 || saveMode == 2 || saveMode == 59) {
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")) {
                var PostExternalMaterialGroup = formContext.getAttribute("niq_externalmaterialgrouptaxcode").getValue();
                var approvalStatus = formContext.getAttribute("niq_approvalstatus").getValue();
                var Characteristicsgrid = formContext.getControl("Subgrid_new_2");
                var PreExternalMaterialGroupTaxCodeId = null;
                var PostExternalMaterialGroupId = null;
                if (ExternalMaterialGroupTaxCode !== null) {
                    PreExternalMaterialGroupTaxCodeId = ExternalMaterialGroupTaxCode[0].id;
                } else {
                    PreExternalMaterialGroupTaxCodeId = null;
                }
                if (PostExternalMaterialGroup != null) {
                    PostExternalMaterialGroupId = PostExternalMaterialGroup[0].id;
                }
                if (PreExternalMaterialGroupTaxCodeId == PostExternalMaterialGroupId) {
                    if (approvalStatus == 610570000 || approvalStatus == 610570001) {
                        // formContext.getAttribute("niq_approvalstatus").setValue(610570002);
                    }
                } else {
                    ExternalMaterialGroupTaxCode = PostExternalMaterialGroup;
                }
                if (Characteristicsgrid.getGrid().getRows().getLength() > 0) {
                    if (approvalStatus == 610570000 || approvalStatus == 610570001) {
                        // formContext.getAttribute("niq_approvalstatus").setValue(610570002);
                    }
                }
            }
        }
    },
    AutoApproveBlockUnblockForMM: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var requestType = formContext.getAttribute("niq_requesttype").getValue()
        var owner = formContext.getAttribute("ownerid").getValue()[0].id;
        var user = Xrm.Page.context.getUserId();
        if ((owner == user) && (requestType == 610570003 || requestType == 610570004)) {
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")) {
                formContext.getAttribute("niq_approvalstatus").setValue(610570002);
            }
        }
    },
    showHideTabAndFieldForMMLanguage: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var fieldsList = [];
        var owner = formContext.getAttribute("ownerid").getValue()[0].id;
        var user = Xrm.Page.context.getUserId();
        if (owner != user) {
            formContext.data.entity.attributes.forEach(function (attr) {
                var fld = attr.getName();
                if (!fieldsList.includes(fld)) {
                    attr.controls.forEach(function (control) {
                        control.setDisabled(true);
                    });
                }
            });
        }
    },
    showHideTabAndFieldForMMChatacteristics: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var fieldsList = [];
        var productRequest = formContext.getAttribute("niq_productrequest").getValue();
        if (productRequest != null && productRequest != "") {
            var productRequestGuid = productRequest[0].id.replace("{", "").replace("}", "").toLowerCase();
            var prodResult = await Xrm.WebApi.retrieveRecord("niq_productrequest", productRequestGuid, "?$select=niq_requesttype");
            var prodReq = prodResult["niq_requesttype"];
            if ((prodReq != 610570001) && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Material Master")) {
                formContext.data.entity.attributes.forEach(function (attr) {
                    var fld = attr.getName();
                    if (!fieldsList.includes(fld)) {
                        attr.controls.forEach(function (control) {
                            control.setDisabled(true);
                        });
                    }
                });
            }
        }
    },
    populateCharacteristicsName: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var productRequest = formContext.getAttribute("niq_productrequest").getValue();
        var materailCharacteristics = formContext.getAttribute("niq_characteristics").getValue();
        if ((productRequest != null && productRequest != "") && (materailCharacteristics != null && materailCharacteristics != "")) {
            var productRequestGuid = productRequest[0].id.replace("{", "").replace("}", "");
            var prodResult = await Xrm.WebApi.retrieveRecord("niq_productrequest", productRequestGuid, "?$select=niq_name,niq_productid");
            var prodID = prodResult["niq_productid"];

            var materailCharacteristicsid = materailCharacteristics[0].id.replace("{", "").replace("}", "");
            var matResult = await Xrm.WebApi.retrieveRecord("niq_materialcharacteristic", materailCharacteristicsid, "?$select=niq_name");
            var matID = matResult["niq_name"];
            var charName = prodID + matID
            formContext.getAttribute("niq_name").setValue(charName);
        }
    },

    populateMaterialDescription: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var productRequest = formContext.getAttribute("niq_productrequest").getValue();
        var localLanguage = formContext.getAttribute("niq_language").getValue();
        if ((productRequest != null && productRequest != "") && (localLanguage != null && localLanguage != "")) {
            var productRequestGuid = productRequest[0].id.replace("{", "").replace("}", "");
            var prodResult = await Xrm.WebApi.retrieveRecord("niq_productrequest", productRequestGuid, "?$select=niq_name");
            var prodReqID = prodResult["niq_name"];

            var localLanguageid = localLanguage[0].id.replace("{", "").replace("}", "");
            var lanResult = await Xrm.WebApi.retrieveRecord("msdyn_oclanguage", localLanguageid, "?$select=msdyn_localecode");
            var matID = lanResult["msdyn_localecode"];
            var matDes = prodReqID + "-" + matID
            formContext.getAttribute("niq_name").setValue(matDes);
        }
    },
    lockProductRequestForm: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_approvalstatus")) {
            var approvalStatus = formContext.getAttribute("niq_approvalstatus").getValue();
            if (approvalStatus === 610570002 || approvalStatus == 610570003 || approvalStatus == 610570004) {
                CommonForm.Events.disableFormFields(true, formContext);
            }
        }
    },
    lockAllFieldsAfterApprovalSubgrids: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var reqproduct = formContext.getAttribute("niq_productrequest").getValue();
        if (reqproduct != null) {
            var requestproductId = reqproduct[0].id.replace("{", "").replace("}", "");
            var result = await Xrm.WebApi.retrieveRecord("niq_productrequest", requestproductId, "?$select=niq_approvalstatus");
            var approvalStatus = result["niq_approvalstatus"];
            console.log(approvalStatus);
            if (approvalStatus == 610570002 || approvalStatus == 610570003 || approvalStatus == 610570004) {
                var allControls = formContext.ui.controls.get();
                for (var i in allControls) {
                    var control = allControls[i];
                    if (control && control.setDisabled) {
                        control.setDisabled(true);
                    }
                }
            }
        }
    }
}
