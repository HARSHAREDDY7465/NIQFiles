if (typeof (ProductRequestMaterialTaxCategory) === "undefined") {
    ProductRequestMaterialTaxCategory = {
        __namespace: true
    };
}
ProductRequestMaterialTaxCategory.Events = {
    FormOnload: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        this.RegisterMethodsOnChangeEvents(formContext);
        this.lockAllFieldsAfterApprovalSubgrids(executionContext);
    },
    RegisterMethodsOnChangeEvents: function (formContext) {
        formContext.getAttribute("niq_pricelist").addOnChange(this.SetCountryBasedOnPriceList);
    },
    SetCountryBasedOnPriceList: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var priceListLookup = formContext.getAttribute("niq_pricelist").getValue();
        if (priceListLookup != null) {
            var priceListId = priceListLookup[0].id;
            var fetchXml = `<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
            <entity name="pricelevel">
                <attribute name="name" />
                <attribute name="pricelevelid" />
                <order attribute="name" descending="false" />
                <filter type="and">
                <condition attribute="pricelevelid" operator="eq" value="${priceListId}" />
                </filter>
                <link-entity name="niq_salesorg" from="niq_salesorgid" to="niq_salesorg" link-type="inner" alias="ac">
                <attribute name="niq_operatingcountryid" />
                <filter type="and">
                    <condition attribute="niq_salesorgid" operator="not-null" />
                    <condition attribute="niq_operatingcountryid" operator="not-null" />
                </filter>
                </link-entity>
            </entity>
            </fetch>`;
            var encodedFetchXml = encodeURIComponent(fetchXml);
            var result = await Xrm.WebApi.retrieveMultipleRecords("pricelevel", "?fetchXml=" + encodedFetchXml);
            if (result.entities.length > 0) {
                var entity = result.entities[0];
                var countryId = entity["ac.niq_operatingcountryid"];
                var countryName = entity["ac.niq_operatingcountryid@OData.Community.Display.V1.FormattedValue"];
                var countryEntityType = entity["ac.niq_operatingcountryid@Microsoft.Dynamics.CRM.lookuplogicalname"];

                var lookupValue = [{
                    id: countryId,
                    name: countryName,
                    entityType: countryEntityType
                }];
                formContext.getAttribute("niq_country").setValue(lookupValue);
            }
        }
        else {
            formContext.getAttribute("niq_country").setValue(null);
            formContext.getAttribute("niq_taxcategory").setValue(null);
            formContext.getAttribute("niq_taxcategoryoption").setValue(null);
        }
    },
    lockAllFieldsAfterApprovalSubgrids: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var reqproduct =formContext.getAttribute("niq_productrequest").getValue();
        if(reqproduct!=null){
            var requestproductId= reqproduct[0].id.replace("{", "").replace("}","");
            var result= await Xrm.WebApi.retrieveRecord("niq_productrequest", requestproductId , "?$select=niq_approvalstatus");
            var approvalStatus = result["niq_approvalstatus"];
            console.log(approvalStatus);
            if(approvalStatus == 610570002 || approvalStatus == 610570003 || approvalStatus == 610570004){
                var allControls = formContext.ui.controls.get();
                for (var i in allControls) {
                    var control = allControls[i];
                    if (control && control.setDisabled) {
                        control.setDisabled(true);
                    } 
                }
            }
        }
    }
}