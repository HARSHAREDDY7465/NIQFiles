if (typeof (ApprovalRequestForm) === "undefined") {
    ApprovalRequestForm = {
        __namespace: true
    };
}

ApprovalRequestForm.Events = {
    OnFormLoad: async function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        this.RemoveRecalledOption(executionContext);
        this.TradeAndBarterRequired(executionContext);
        //this.OnsalesOpsChange(executionContext);
        this.RemoveSAPDecisionOption(executionContext);
        this.ShowAndHideQuoteTAB(executionContext);
        this.HideOption(executionContext);
        this.ApprovalFieldsAccess(executionContext);
        var revShareDealVal = await this.IsRevShareDeal(executionContext);
        this.HideRelatedOppQuickView(executionContext, revShareDealVal);
        this.ManageToggleForOpportunityAndQuoteDetails(executionContext, revShareDealVal);
        this.ValidateTotalParentOpportunityValue(executionContext);
        this.unlockPOFields(executionContext);
this.displayWarningonRenewalforBackDatedEvergreenContractWithCustomSchedule(executionContext);
        if(await CommonForm.Events.ShowNIQGFKAugRelease()){
            this.checkComplianceAndShowWarningOnFARForm(executionContext);
        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_approvaltype")) {
            var formType = formContext.ui.getFormType();
            if (formType === 1) {
                if (formContext.getAttribute("niq_approvalstatus") !== null) {
                    formContext.getControl("niq_approvalstatus").setDisabled(true);
                }
                if (formContext.getAttribute("niq_subtype") !== null) {
                    formContext.getControl("niq_subtype").setDisabled(false);
                }
            }
            var farType = formContext.getAttribute("niq_approvaltype").getValue();
            if (farType === 100000000) {
                // FAR Type is Opportunty
                CommonForm.Events.ShowHideSections(formContext, "Summary", "Opportunity_Approval_Section1", true);
                CommonForm.Events.ShowHideSections(formContext, "Summary", "Opportunity_Approval_Section2", true);
                formContext.getControl("niq_createdinsalesforceby").setVisible(false);
            }
            else {
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_subtype")) {
                    formContext.getAttribute("niq_subtype").setRequiredLevel('required');
                    formContext.getControl("niq_subtype").setVisible(true);
                }
                if (formContext.getAttribute("niq_salesorg") !== null && formContext.getAttribute("niq_salesorg").getValue() === null) {
                    formContext.getControl("niq_salesorg").setDisabled(false);
                }
            }
            if (formContext.getAttribute("niq_relatedaccount") !== null && formContext.getAttribute("niq_relatedaccount").getValue() === null) {
                formContext.getControl("niq_relatedaccount").setDisabled(false);
            }
            if (farType === 100000001) {
                // FAR type is SAP Account Change request
                CommonForm.Events.ShowHideSections(formContext, "Summary", "SAPAccount_Approval_Section", true);
                formContext.getControl("niq_createdinsalesforceby").setVisible(true);
            } else {
                formContext.getControl("niq_createdinsalesforceby").setVisible(false);
            }

        }


        /*if (CommonForm.Events.CheckValueExists(formContext, "niq_salesopsreviewresult")) {
              var salesResult = formContext.getAttribute("niq_salesopsreviewresult").getValue();
              if (salesResult === 1) {
                  formContext.getAttribute("niq_rejectionreasonfar").setRequiredLevel("none");
                  formContext.getAttribute("niq_comments").setRequiredLevel("none");
                  formContext.getControl("niq_rejectionreasonfar").setVisible(false);
                  formContext.getAttribute("niq_rejectionreasonfar").setValue(null);
              } else if (salesResult === 2 || salesResult === 3) {
                  formContext.getAttribute("niq_rejectionreasonfar").setRequiredLevel("required");
                  formContext.getAttribute("niq_comments").setRequiredLevel("required");
                  formContext.getControl("niq_rejectionreasonfar").setVisible(true);
              }
          }*/
    },
    ApprovalFieldsAccess: function (executionContext) {
        'use strict';
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        if (formType != 4) {
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add On Sales Ops Approver")) {
                formContext.getControl("niq_approvalstatus").setDisabled(true);
                formContext.getControl("niq_salesopsreviewresult").setDisabled(false);
            }
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add-On Finance Gatekeeper")) {
                formContext.getControl("niq_approvalstatus").setDisabled(false);
                formContext.getControl("niq_salesopsreviewresult").setDisabled(true);
            }

            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer")) {
                formContext.getControl("niq_approvalstatus").setDisabled(false);
                formContext.getControl("niq_salesopsreviewresult").setDisabled(false);
            }
        }
    },
    HideOption: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        var Type = formContext.getAttribute("niq_approvaltype").getValue();
        var ApprovalStatus = formContext.getAttribute("niq_approvalstatus").getValue();

        if (Type === 100000000 || Type === 100000002) {
            formContext.getControl("niq_approvalstatus").removeOption(100000000);

        }
    },

    RemoveRecalledOption: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_approvaltype") && CommonForm.Events.CheckValueExists(formContext, "niq_approvalstatus")) {
            var requestType = formContext.getAttribute("niq_approvaltype").getValue();
            var approvalStatus = formContext.getAttribute("niq_approvalstatus").getValue();
            if (requestType === 100000001) {
                formContext.getControl("niq_approvalstatus").removeOption(100000004);
            }
            if (requestType === 100000000 && (approvalStatus === 100000003 || approvalStatus === 100000006 || approvalStatus === 100000007)) {
                formContext.getAttribute("niq_rejectionreasonfar").setRequiredLevel("required");
                formContext.getControl("niq_rejectionreasonfar").setVisible(true);
            }
            else {
                formContext.getAttribute("niq_rejectionreasonfar").setRequiredLevel("none");
                formContext.getControl("niq_rejectionreasonfar").setVisible(false);
                formContext.getAttribute("niq_rejectionreasonfar").setValue(null);
            }
        }
    },
    TradeAndBarterRequired: function (executionContext) {
        "use strict";
        //make Trade and Barter field required for valid Sales Org
        // get the form context
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_approvaltype") && (CommonForm.Events.CheckFieldExists(formContext, "niq_tradebarter"))) {
            var approvalRequestType = formContext.getAttribute("niq_approvaltype").getValue();
            formContext.getAttribute("niq_tradebarter").setRequiredLevel("none");
            if (CommonForm.Events.CheckValueExists(formContext, "niq_salesorg")) {
                var salesOrg = formContext.getAttribute("niq_salesorg").getValue();
                var salesOrg_id = salesOrg[0].id.replace('{', '').replace('}', '');
                // retrieve salesorgcode
                Xrm.WebApi.retrieveRecord("niq_salesorg", salesOrg_id, "?$select=niq_salesorgcode").then(
                    function success(result) {
                        if (result["niq_salesorgcode"] !== null) {
                            var salesOrgCode = result.niq_salesorgcode;
                            //retrieve Sales Org List_SAP Change Account Request configurationsetting
                            Xrm.WebApi.online.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_to&$filter=niq_name eq 'Sales%20Org%20List_SAP%20Account%20Change%20Request'").then(
                                function success(results) {
                                    var niq_to = results.entities[0]["niq_to"];
                                    if (niq_to !== null) {
                                        if ((niq_to.includes(salesOrgCode)) && (approvalRequestType === 100000001)) {
                                            formContext.getAttribute("niq_tradebarter").setRequiredLevel("required");
                                        }
                                    }
                                },
                                function (error) {

                                }
                            );
                        }
                    },
                    function (error) {

                    }
                );
            }
        }
    },
    SetSAPIntegrationDecision: function (executionContext) {
        "use strict";
        //Set SAP Integration Decision to send to SAP if Contract Decision in Opportunity is New Contract Will Be Signed
        //based SAP Integration Decision if existing sales documnet id in opportunity contains data set in salesdocumentidtobeupdated
        var formContext = executionContext.getFormContext();
        if ((CommonForm.Events.CheckFieldExists(formContext, "niq_sapintegrationdecision")) && (CommonForm.Events.CheckValueExists(formContext, "niq_approvaltype")) && (CommonForm.Events.CheckValueExists(formContext, "niq_approvalstatus")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_salesdocumentidtobeupdatedinsap"))) {
            var sapIntegrationDecision = formContext.getAttribute("niq_sapintegrationdecision").getValue();
            var approvalType = formContext.getAttribute("niq_approvaltype").getValue();
            var approvalStatus = formContext.getAttribute("niq_approvalstatus").getValue();
            if ((approvalType === 100000000) && (approvalStatus === 100000002)) {
                if (CommonForm.Events.CheckValueExists(formContext, "niq_relatedopportunity")) {
                    var opportunity = formContext.getAttribute("niq_relatedopportunity").getValue();
                    var opportunityid = opportunity[0].id.replace('{', '').replace('}', '');
                    Xrm.WebApi.retrieveRecord("opportunity", opportunityid, "?$select=niq_contractdecision,niq_existingsapsalesdocumentid").then(
                        function success(result) {
                            if ((result["niq_contractdecision"] !== null)) {
                                if ((result.niq_contractdecision === 100000001)) {
                                    formContext.getAttribute("niq_sapintegrationdecision").setValue(2);
                                    formContext.getAttribute("niq_salesdocumentidtobeupdatedinsap").setValue(null);
                                    formContext.getAttribute("niq_salesdocumentidtobeupdatedinsap").setRequiredLevel("none");
                                    formContext.getControl("niq_salesdocumentidtobeupdatedinsap").setVisible(false);
                                }
                                else {
                                    formContext.getAttribute("niq_sapintegrationdecision").setValue(1);
                                    formContext.getAttribute("niq_salesdocumentidtobeupdatedinsap").setRequiredLevel("required");
                                    formContext.getControl("niq_salesdocumentidtobeupdatedinsap").setVisible(true);
                                    if (result["niq_existingsapsalesdocumentid"] !== null) {
                                        var existingSapsalesdocumentid = result["niq_existingsapsalesdocumentid"];
                                        formContext.getAttribute("niq_salesdocumentidtobeupdatedinsap").setValue(existingSapsalesdocumentid);
                                    }
                                }
                            }
                            else {
                                formContext.getAttribute("niq_sapintegrationdecision").setValue(1);
                                formContext.getAttribute("niq_salesdocumentidtobeupdatedinsap").setRequiredLevel("required");
                                formContext.getControl("niq_salesdocumentidtobeupdatedinsap").setVisible(true);
                                if (result["niq_existingsapsalesdocumentid"] !== null) {
                                    var existingSapsalesdocumentid = result["niq_existingsapsalesdocumentid"];
                                    formContext.getAttribute("niq_salesdocumentidtobeupdatedinsap").setValue(existingSapsalesdocumentid);
                                }
                            }
                        },
                        function (error) {

                        }
                    );
                }
            }
        }
    },
    OnChangeOfSAPIntegrationDecision: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if ((CommonForm.Events.CheckValueExists(formContext, "niq_sapintegrationdecision")) && (CommonForm.Events.CheckValueExists(formContext, "niq_approvaltype"))) {

            var sapintegrationdecision = formContext.getAttribute("niq_sapintegrationdecision").getValue();
            var approvalType = formContext.getAttribute("niq_approvaltype").getValue();
            if (approvalType === 100000000) {
                if (CommonForm.Events.CheckValueExists(formContext, "niq_relatedopportunity")) {

                    var relOppo = formContext.getAttribute("niq_relatedopportunity").getValue();
                    var relOppoId = relOppo[0].id.replace('{', '').replace('}', '');
                    Xrm.WebApi.online.retrieveRecord("opportunity", relOppoId, "?$select=niq_existingsapsalesdocumentid").then(

                        function success(result) {
                            if (sapintegrationdecision === 1) {
                                if (CommonForm.Events.CheckFieldExists(formContext, "niq_salesdocumentidtobeupdatedinsap")) {
                                    var salesdocumentidtobeupdatedinSap = formContext.getAttribute("niq_salesdocumentidtobeupdatedinsap").getValue();
                                    if (salesdocumentidtobeupdatedinSap === null) {
                                        if (result["niq_existingsapsalesdocumentid"] !== null) {
                                            var existingSapsalesdocumentid = result["niq_existingsapsalesdocumentid"];
                                            if (existingSapsalesdocumentid !== null) {
                                                formContext.getAttribute("niq_salesdocumentidtobeupdatedinsap").setValue(existingSapsalesdocumentid);
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        function (error) { });
                }
            }
        }
    },
    /* OnsalesOpsChange: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_approvaltype") && (formContext.getAttribute("niq_approvaltype").getValue() === 100000000)) {
            formContext.getControl("niq_salesopsreviewrequired").setVisible(true);
            if ((formContext.getAttribute("niq_approvaltype").getValue() === 100000000) && CommonForm.Events.CheckValueExists(formContext, "niq_salesopsreviewrequired") && formContext.getAttribute("niq_salesopsreviewrequired").getValue() === true) {
                formContext.getControl("niq_salesopsreviewresult").setVisible(true);
            } else {
                formContext.getControl("niq_salesopsreviewresult").setVisible(false);
                formContext.getAttribute("niq_salesopsreviewresult").setValue(null);
            }
        } else {
            formContext.getControl("niq_salesopsreviewrequired").setVisible(false);
            formContext.getAttribute("niq_salesopsreviewrequired").setValue(null);
            formContext.getControl("niq_salesopsreviewresult").setVisible(false);
            formContext.getAttribute("niq_salesopsreviewresult").setValue(null);
        }
    }, */
    OnApprovalStatusChange: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_salesopsreviewresult")) {
            var salesResult = formContext.getAttribute("niq_salesopsreviewresult").getValue();
            if (salesResult === 1) {
                formContext.getAttribute("niq_approvalstatus").setValue(100000001);
                formContext.getAttribute("niq_rejectionreasonfar").setRequiredLevel("none");
                formContext.getAttribute("niq_comments").setRequiredLevel("none");
                formContext.getControl("niq_rejectionreasonfar").setVisible(false);
                formContext.getAttribute("niq_rejectionreasonfar").setValue(null);
                formContext.getControl("niq_approvalstatus").removeOption(100000007);
            } else if (salesResult === 2) {
                formContext.getAttribute("niq_approvalstatus").setValue(100000003);
                formContext.getAttribute("niq_rejectionreasonfar").setRequiredLevel("required");
                formContext.getAttribute("niq_comments").setRequiredLevel("required");
                formContext.getControl("niq_rejectionreasonfar").setVisible(true);
                formContext.getControl("niq_approvalstatus").removeOption(100000007);
            } else if (salesResult === 3) {
                formContext.getControl("niq_approvalstatus").removeOption(100000007);
                formContext.getControl("niq_approvalstatus").addOption({ value: 100000007, text: 'Sales Ops correction in progress' });
                formContext.getAttribute("niq_approvalstatus").setValue(100000007);
                formContext.getAttribute("niq_rejectionreasonfar").setRequiredLevel("required");
                formContext.getAttribute("niq_comments").setRequiredLevel("required");
                formContext.getControl("niq_rejectionreasonfar").setVisible(true);

            }
            else {
                formContext.getControl("niq_approvalstatus").removeOption(100000007);

            }


        }
        else {
            formContext.getControl("niq_approvalstatus").removeOption(100000007);
        }

    },
    ShowAndHideQuoteTAB: function (executionContext) {
        "use strict";

        var formContext = executionContext.getFormContext();
        if ((CommonForm.Events.CheckFieldExists(formContext, "niq_approvaltype")) && (CommonForm.Events.CheckValueExists(formContext, "niq_approvaltype"))) {
            var approvalRequestType = formContext.getAttribute("niq_approvaltype").getValue();
            if (approvalRequestType === 100000000) {
                CommonForm.Events.ShowHideTabs(formContext, "tab_2", true);
            }
            else {
                CommonForm.Events.ShowHideTabs(formContext, "tab_2", false);
            }
        }
    },
    RemoveSAPDecisionOption: async function (executionContext) {
                    "use strict";
                    var formContext = executionContext.getFormContext();
                    //Remove SAP Integration Decision Failed option for Non Admins
                    if ((CommonForm.Events.CheckFieldExists(formContext, "niq_sapintegrationdecision")) && (!(CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer")))) {
                        formContext.getControl("niq_sapintegrationdecision").removeOption(3);
                    }
                    var opportunity = formContext.getAttribute("niq_relatedopportunity").getValue();
                    var approvalStatus = formContext.getAttribute("niq_approvalstatus").getValue();
                    var opportunityid = opportunity[0].id.replace('{', '').replace('}', '');
                    var result = await Xrm.WebApi.retrieveRecord("opportunity", opportunityid, "?$select=niq_existingcontractaction");
                    if (result["niq_existingcontractaction"] !== null && (approvalStatus === 100000001 || approvalStatus === 100000005) &&(result.niq_existingcontractaction === 2 || result.niq_existingcontractaction === 3 || result.niq_existingcontractaction === 4))
                        formContext.getControl("niq_sapintegrationdecision").removeOption(2);
    },
    PreventAutosave: function (executionContext) {
        "use strict";
        var eventArgs = executionContext.getEventArgs();
        if (eventArgs.getSaveMode() == 70 || eventArgs.getSaveMode() == 2) {
            eventArgs.preventDefault();
        }
    },
    RestrictStageChangeToCloseWon: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        var approvalType = formContext.getAttribute("niq_approvaltype").getValue();
        var approvalStatus = formContext.getAttribute("niq_approvalstatus").getValue();
        if ((approvalType === 100000000) && (approvalStatus === 100000002)) {
            var opportunity = formContext.getAttribute("niq_relatedopportunity").getValue();
            var opportunityid = opportunity[0].id.replace('{', '').replace('}', '');
            var quote = formContext.getAttribute("niq_mainquoteid").getValue();
            var quoteId = quote[0].id.replace('{', '').replace('}', '');
            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'><entity name='quotedetail'><attribute name='niq_brandid' /><attribute name='quotedetailname' /><attribute name='quotedetailid' /><attribute name='niq_wbs' /><order attribute='niq_brandid' descending='false' /><filter type='and'><condition attribute='quoteid' operator='eq' uitype='quote' value='" + quoteId + "' /><condition attribute='niq_wbs' operator='null' /><condition attribute='niq_brandid' operator='in'><value uiname='BASES' uitype='product'>{FCABAF82-A13F-EC11-8C62-002248098DAF}</value><value uiname='BASES' uitype='product'>{E47CD76D-993F-EC11-8C60-0022480A4E68}</value><value uiname='CI' uitype='product'>{bb84a1a5-9c3f-ec11-8c60-0022480a48ee}</value><value uiname='CI' uitype='product'>{e27cd76d-993f-ec11-8c60-0022480a4e68}</value></condition></filter><link-entity name='product' from='productid' to='niq_brandid' visible='false' link-type='outer' alias='a_baebf37edc0ced1182e4002248830b23'><attribute name='name' /></link-entity></entity></fetch>";
            var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
            var result = GetCRMWebAPI.Methods.GetFetchRecords(clienturl, fetchXml, "quotedetails");

            var eventArgs = executionContext.getEventArgs();
            if (result != null && result.value.length > 0 && eventArgs.getSaveMode() == 1) {
                var alertStrings = { message: "ERROR:WBS# needs to be populated on every quote product for CI and BASES that is on the main quote. This is required before an opportunity can be moved to Closed Won - Approved ", details: "WBS# needs to be populated on every quote product for CI and BASES that is on the main quote. This is required before an opportunity can be moved to Closed Won - Approved" };
                var alertOptions = { height: 200, width: 300 };
                Xrm.Navigation.openErrorDialog(alertStrings).then(
                    function (sucess) {
                        console.log(success);
                    },
                    function (error) {
                        console.log(error);
                    });
                var eventArgs = executionContext.getEventArgs();
                if (eventArgs.getSaveMode() == 1) {
                    eventArgs.preventDefault();
                }

            }
            else if (eventArgs.getSaveMode() == 70 || eventArgs.getSaveMode() == 2) { eventArgs.preventDefault(); }

        }

    },
    //US-20398 
    //Hide/Show Quick View form below the Related Opportunity field for user having NIQ Sales User,NIQ Add-On Finance Gatekeeper,System Administrator
    HideRelatedOppQuickView: function (executionContext, revShareDealVal) {
        "use strict";
        let formContext = executionContext.getFormContext();
        let roles = Xrm.Utility.getGlobalContext().userSettings.roles;
        let relatedOppQuickView = formContext.ui.quickForms.get("QuickviewControlRelatedOpportunity");
        let approvalType = formContext.getAttribute("niq_approvaltype").getValue();

        if (roles === null) return false;
        let hasRole = false;
        roles.forEach(function (item) {
            //here we can also use item.id to compare role id
            if (item.name == "NIQ Sales User" || item.name == "NIQ Add-On Finance Gatekeeper" || item.name == "System Administrator") {
                hasRole = true;
            }
        });

        if (approvalType === 100000000 && approvalType !== null && revShareDealVal === true && hasRole == true) {
            relatedOppQuickView.setVisible(true);
        } else {
            relatedOppQuickView.setVisible(false);
        }

    },
    IsRevShareDeal: async function (executionContext) {
        let formContext = executionContext.getFormContext();
        let relatedOpportunity = formContext.getAttribute("niq_relatedopportunity").getValue();
        if (relatedOpportunity !== null) {
            let resultOpportunity = await Xrm.WebApi.retrieveRecord("opportunity", relatedOpportunity[0].id.replace("{", "").replace("}", ""), "?$select=niq_revenuesharedeal");
            return resultOpportunity["niq_revenuesharedeal"];
        }
    },
    ValidateTotalParentOpportunityValue: async function (executionContext) {
        var formContext = executionContext.getFormContext();

        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add-On Finance Gatekeeper,System Administrator")) {
            if (CommonForm.Events.CheckValueExists(formContext, "niq_relatedopportunity")) {
                var relatedOppLookup = formContext.getAttribute("niq_relatedopportunity").getValue();
                if (relatedOppLookup && relatedOppLookup.length > 0) {
                    var relatedOppId = relatedOppLookup[0].id.replace("{", "").replace("}", "");
                    var ParentOppEntity = await Xrm.WebApi.retrieveRecord("opportunity", relatedOppId, "?$select=totalamount,_niq_mainquoteid_value,niq_revenuesharedeal");

                    if (ParentOppEntity && ParentOppEntity["totalamount"] && ParentOppEntity["_niq_mainquoteid_value"] && ParentOppEntity["niq_revenuesharedeal"] === true) {
                        var hostTotalAmount = ParentOppEntity["totalamount"];
                        var mainQuoteId = ParentOppEntity["_niq_mainquoteid_value"];

                        var ChildOpp = await Xrm.WebApi.retrieveMultipleRecords("opportunity", "?$select=name&$filter=_niq_hostopportunity_value eq " + relatedOppId);
                        if (ChildOpp !== null && ChildOpp.entities.length > 0) {

                            var fetchXmlHostOppProducts = `<fetch distinct='false'>
                                    <entity name='quotedetail'>
                                        <attribute name='quotedetailname' />
                                        <attribute name='extendedamount' />
                                        <order attribute='niq_brandid' descending='false' />
                                        <filter type='and'>
                                        <condition attribute='quoteid' operator='eq' value='`+ mainQuoteId + `' />
                                        </filter>
                                        <link-entity name='product' from='productid' to='productid' link-type='inner' alias='ProductEntity'>
                                            <filter type='and'>
                                                <condition attribute='productnumber' operator='not-like' value='%Rev Share%' />
                                                <condition attribute='productnumber' operator='not-like' value='%RevShare%' />
                                                <condition attribute='productnumber' operator='not-like' value='%Rev-Share%' />
                                                <condition attribute='productnumber' operator='not-like' value='%REVSHR%' />
                                            </filter>
                                        </link-entity>
                                    </entity>
                                    </fetch>`;

                            var hostTotalAmountExcludedRevShare = 0;
                            var ResultParentOppProducts = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", "?fetchXml=" + fetchXmlHostOppProducts);
                            if (ResultParentOppProducts !== null && ResultParentOppProducts.entities.length > 0) {
                                for (var i = 0; i < ResultParentOppProducts.entities.length; i++) {
                                    hostTotalAmountExcludedRevShare += ResultParentOppProducts.entities[i]["extendedamount"];
                                }
                                hostTotalAmountExcludedRevShare = parseFloat(hostTotalAmountExcludedRevShare.toFixed(2));
                            }

                            var fetchXmlChildOppProducts = `<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
                                        <entity name="opportunity">
                                            <attribute name="totalamount" />
                                            <attribute name="opportunityid" />
                                            <filter type="and">
                                                <condition attribute="niq_hostopportunity" operator="eq" value='`+ relatedOppId + `' />
                                                  <condition attribute="statecode" operator="ne" value="2" />
                                            </filter>
                                        </entity>
                                    </fetch>`;

                            var childTotalAmount = 0;
                            var ResultChildOppProducts = await Xrm.WebApi.retrieveMultipleRecords("opportunity", "?fetchXml=" + fetchXmlChildOppProducts);
                            if (ResultChildOppProducts !== null && ResultChildOppProducts.entities.length > 0) {
                                for (var i = 0; i < ResultChildOppProducts.entities.length; i++) {
                                    childTotalAmount += ResultChildOppProducts.entities[i]["totalamount"];
                                }
                                childTotalAmount = parseFloat(childTotalAmount.toFixed(2));
                            }
                            if (!(hostTotalAmount == (hostTotalAmountExcludedRevShare + childTotalAmount))) {

                                formContext.ui.setFormNotification("There is an amount mismatch for this record", "ERROR", "1");
                            }
                            else {
                                formContext.ui.clearFormNotification("1");
                            }
                        }
                    }
                }
            }
        }


    },
    //US-20401
    //On change of field Show Host Opportunity Details hide/show the quick view form "Host Opportunity Details" 
    OnChangeShowHostOpportunityDetails: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var showHostDetails = formContext.getAttribute("niq_showhostopportunitydetails").getValue();
        if (showHostDetails) {
            formContext.ui.quickForms.get("HostOpportunityDetailsQuickview").setVisible(true);

            formContext.ui.tabs.get('All_Opportunity_Details_tab').sections.get('hostChild_Opportunity_section').controls.forEach(
                function (control) {
                    if (control.getName() == "niq_relatedopportunity" || control.getName() == "niq_relatedopportunity1") {
                        control.setVisible(true);
                    }
                }
            );

        } else {
            formContext.ui.quickForms.get("HostOpportunityDetailsQuickview").setVisible(false);

            formContext.ui.tabs.get('All_Opportunity_Details_tab').sections.get('hostChild_Opportunity_section').controls.forEach(
                function (control) {
                    if (control.getName() == "niq_relatedopportunity" || control.getName() == "niq_relatedopportunity1") {
                        control.setVisible(false);
                    }
                }
            );
        }
    },
    //US-20401
    //On change of field Show Host Main Quote Details hide/show the quick view form "Main Quote Details"
    OnChangeShowHostMainQuoteDetails: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var showHostDetails = formContext.getAttribute("niq_showhostmainquotedetails").getValue();
        if (showHostDetails) {
            formContext.ui.quickForms.get("HostMainQuoteDetailsQuickView").setVisible(true);
            formContext.ui.quickForms.get("HostMainQuoteDetailsStageQuickView").setVisible(true);

            formContext.ui.tabs.get('All_Main_Quote_Details_tab').sections.get('hostChild_Main_Quote_Details_section').controls.forEach(
                function (control) {
                    if (control.getName() == "niq_mainquoteid" || control.getName() == "niq_mainquoteid1") {
                        control.setVisible(true);
                    }
                }
            );

        } else {
            formContext.ui.quickForms.get("HostMainQuoteDetailsQuickView").setVisible(false);
            formContext.ui.quickForms.get("HostMainQuoteDetailsStageQuickView").setVisible(false);

            formContext.ui.tabs.get('All_Main_Quote_Details_tab').sections.get('hostChild_Main_Quote_Details_section').controls.forEach(
                function (control) {
                    if (control.getName() == "niq_mainquoteid" || control.getName() == "niq_mainquoteid1") {
                        control.setVisible(false);
                    }
                }
            );
        }
    },
    //US-20401
    //On load of FAR form display All opportunity Details Tab and All Main Quote Details Tab
    //On load of FAR form set Show Host Opportunity Details and Show Host Main Quote Details field as false.
    ManageToggleForOpportunityAndQuoteDetails: function (executionContext, revShareDealVal) {
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User,NIQ Add-On Finance Gatekeeper,System Administrator")) {
            var approvalType = formContext.getAttribute("niq_approvaltype").getValue();
            //Approval Type eq "Opportunity Approval Request"
            if (approvalType === 100000000 && approvalType !== null && revShareDealVal === true) {
                //if Show Host Opportunity Details field is true then set as false
                //if Show Host Main Quote Details field is true then set as false
                if ((formContext.getAttribute("niq_showhostmainquotedetails")?.getValue() === true || formContext.getAttribute("niq_showhostmainquotedetails")?.getValue() === null) ||
                    (formContext.getAttribute("niq_showhostopportunitydetails")?.getValue() === true || formContext.getAttribute("niq_showhostopportunitydetails")?.getValue() === null)) {
                    if (formContext.getAttribute("niq_showhostmainquotedetails")?.getValue() === true || formContext.getAttribute("niq_showhostmainquotedetails")?.getValue() === null) {
                        formContext.getAttribute("niq_showhostmainquotedetails")?.setValue(false);
                    }
                    if (formContext.getAttribute("niq_showhostopportunitydetails")?.getValue() === true || formContext.getAttribute("niq_showhostopportunitydetails")?.getValue() === null) {
                        formContext.getAttribute("niq_showhostopportunitydetails")?.setValue(false);
                    }
                    formContext.data.save();
                }
                formContext.ui.tabs.get("All_Opportunity_Details_tab").setVisible(true);
                formContext.ui.tabs.get("All_Main_Quote_Details_tab").setVisible(true);


                ApprovalRequestForm.Events.OnChangeShowHostOpportunityDetails(executionContext);
                ApprovalRequestForm.Events.OnChangeShowHostMainQuoteDetails(executionContext);
            }
        }
    },
    //DYNCRM-22321 - Enable CustomerPONumber and CustomerPODate fields for NIQ Finance User
    unlockPOFields: async function(executionContext){
        var formContext = executionContext.getFormContext();
        if(await CommonForm.Events.ShowNIQGFKAugRelease()){
            var opportunity = formContext.getAttribute("niq_relatedopportunity").getValue();
            if(opportunity != null && opportunity != undefined){
                var result = await Xrm.WebApi.retrieveRecord("opportunity",opportunity[0].id, "?$select=niq_podocumentationurl");
                var poDocumentationUrl = result["niq_podocumentationurl"];
                var checkRole = CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User");
                if(poDocumentationUrl != null && poDocumentationUrl != undefined && checkRole && formContext.ui.getFormType() == 2){
                    formContext.getControl("niq_customerponumber").setDisabled(false);
                    formContext.getControl("niq_customerpodate").setDisabled(false);
                }
            }
        }
        else{
            formContext.ui.tabs.get("Summary").sections.get("PoFields_section").setVisible(false);
        }
    },

    //DYNCRM-21871 - Check Compliance Status
    checkComplianceAndShowWarningOnFARForm: async function (executionContext) {
        var formContext = executionContext.getFormContext();

        // Get the related Opportunity lookup field value in FAR form
        var opportunityLookup = formContext.getAttribute("niq_relatedopportunity").getValue();
        if (!opportunityLookup) {
            return; // No Opportunity linked, so no need to proceed
        }
        var opportunityId = opportunityLookup[0].id;
    
        var opportunityRecord = await Xrm.WebApi.online.retrieveRecord("opportunity", opportunityId, "?$select=_niq_billtoparty_value,_niq_deliverytoparty_value,_niq_soldtoparty_value,_parentaccountid_value");
        var niqSoldToParty = opportunityRecord["_niq_soldtoparty_value"];
        var niqDeliveryToParty = opportunityRecord["_niq_deliverytoparty_value"];
        var niqBillToParty = opportunityRecord["_niq_billtoparty_value"];
        var parentAccount = opportunityRecord["_parentaccountid_value"];

        // Check for SAP accounts (niq_soldtoparty, niq_deliverytoparty, niq_billtoparty)
        if (niqSoldToParty) {

            let complianceStatus = await ApprovalRequestForm.Events.checkAccountCompliance(niqSoldToParty);
            if (complianceStatus === 610570001) {
                formContext.ui.setFormNotification("Sold to Party: Account(s) on this Opportunity have status Compliance Blocked. You can only proceed further with this Opportunity as long as Is Canceled field = Canceled.", "WARNING", "niqSoldToParty");
            }
            else if (complianceStatus === 610570002){
                formContext.ui.setFormNotification("Sold to Party: At least one of the Account(s) status of the related Opportunity is 'Compliance Restricted'. Please reject the FAR if  seller has not provided Ethics and Compliance written approval on Files SharePoint.", "WARNING", "niqSoldToParty02");
            }
        }

        if (niqDeliveryToParty) {
            let complianceStatus = await ApprovalRequestForm.Events.checkAccountCompliance(niqDeliveryToParty);
            if (complianceStatus === 610570001) {
                formContext.ui.setFormNotification("Deliver To Party: Account(s) on this Opportunity have status Compliance Blocked. You can only proceed further with this Opportunity as long as Is Canceled field = Canceled.", "WARNING", "niqDeliveryToParty");
            }
            else if (complianceStatus === 610570002){
                formContext.ui.setFormNotification("Deliver To Party: At least one of the Account(s) status of the related Opportunity is 'Compliance Restricted'. Please reject the FAR if  seller has not provided Ethics and Compliance written approval on Files SharePoint.", "WARNING", "niqDeliveryToParty02");
            }
        }

        if (niqBillToParty) {
            let complianceStatus = await ApprovalRequestForm.Events.checkAccountCompliance(niqBillToParty);
            if (complianceStatus === 610570001) {
                formContext.ui.setFormNotification("Bill to Party: Account(s) on this Opportunity have status Compliance Blocked. You can only proceed further with this Opportunity as long as Is Canceled field = Canceled.", "WARNING", "niqBillToParty");
            }
            else if (complianceStatus === 610570002){
                formContext.ui.setFormNotification("Bill to Party: At least one of the Account(s) status of the related Opportunity is 'Compliance Restricted'. Please reject the FAR if  seller has not provided Ethics and Compliance written approval on Files SharePoint.", "WARNING", "niqBillToParty02");
            }
        }

        // Check for the Customer Account (parentaccountid)
        if (parentAccount) {
            let complianceStatus = await ApprovalRequestForm.Events.checkAccountCompliance(parentAccount);
            if (complianceStatus === 610570001) {
                formContext.ui.setFormNotification("Customer Account:: Account(s) on this Opportunity have status Compliance Blocked. You can only proceed further with this Opportunity as long as Is Canceled field = Canceled.", "WARNING", "parentAccount");
            }
            else if (complianceStatus === 610570002){
                formContext.ui.setFormNotification("Customer Account: At least one of the Account(s) status of the related Opportunity is 'Compliance Restricted'. Please reject the FAR if  seller has not provided Ethics and Compliance written approval on Files SharePoint.", "WARNING", "parentAccount02");
            }
        }
    },

    //DYNCRM-21871 - Define the checkAccountCompliance function outside the main function
    checkAccountCompliance: async function (accountId) {

        if (!accountId) return;

        // Fetch the account record to get the niq_compliancestatus value
        var accountRecord = await Xrm.WebApi.retrieveRecord("account", accountId, "?$select=niq_compliancefinancialstatus");
        var complianceStatus = accountRecord.niq_compliancefinancialstatus;
        
        return complianceStatus;
    },
//DYNCRM-28057 - Display a warning message to review the schedule dates FAR approver if related opportunities upstream opportunity is a back-dated evergreen contract with custom schedule qupte product in current evergreen renewal opportunity
    displayWarningonRenewalforBackDatedEvergreenContractWithCustomSchedule: async function(executionContext){
        var formContext = executionContext.getFormContext();

        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add-On Finance Gatekeeper,System Administrator")) {
            if (CommonForm.Events.CheckValueExists(formContext, "niq_relatedopportunity")) {
                var relatedOppLookup = formContext.getAttribute("niq_relatedopportunity").getValue();
                if (relatedOppLookup && relatedOppLookup.length > 0) {
                    var relatedOppId = relatedOppLookup[0].id.replace("{", "").replace("}", "");
                    var OppEntity = await Xrm.WebApi.retrieveRecord("opportunity", relatedOppId, "?$select=niq_existingcontractaction,_niq_mainquoteid_value&$expand=niq_AmendedFromOpportunity($select=createdon,niq_contractstartdate)");
                    if (OppEntity && OppEntity["niq_existingcontractaction"] && OppEntity["niq_existingcontractaction"] === 3) // Evergreen Renewal opportunity
                    {
                        var contractStartDate;
                        var createdOnDate;
                        var mainQuoteId;
                        if(OppEntity["niq_AmendedFromOpportunity"] && OppEntity["niq_AmendedFromOpportunity"]["niq_contractstartdate"] && OppEntity["niq_AmendedFromOpportunity"]["createdon"] && OppEntity["_niq_mainquoteid_value"])
                        {
                            contractStartDate = new Date(OppEntity["niq_AmendedFromOpportunity"]["niq_contractstartdate"]);
                            createdOnDate = new Date(OppEntity["niq_AmendedFromOpportunity"]["createdon"]);
                            mainQuoteId = OppEntity["_niq_mainquoteid_value"];
                        }
                        if (contractStartDate && createdOnDate && contractStartDate < createdOnDate) //Amended from Opportunity is a back-dated evergreen contract
                        {
                            //Check if current opportunity have any Custom Schedule quote products, if yes show warning to FAR Approver
                            var fetchxmlCustomFrequencyQProducts = `<fetch distinct='false'>
                                    <entity name='quotedetail'>
                                        <attribute name="niq_deliveryfrequency" />
                                        <attribute name="productname" />
                                        <attribute name="quotedetailid" />
                                        <attribute name="quotedetailname" />
                                        <filter type='and'>
                                            <condition attribute="niq_deliveryfrequency" operator="eq" value="100000009" />
                                            <condition attribute='quoteid' operator='eq' value='${mainQuoteId}' />
                                        </filter>
                                    </entity>
                                </fetch>`;
                            var customScheduleQuoteProductCount = -1;
                            var resultScheduleQP = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", "?fetchXml=" + fetchxmlCustomFrequencyQProducts);
                            //Have some quote products with custom schedule
                            if (resultScheduleQP && resultScheduleQP['entities'] && resultScheduleQP['entities'].length > 0 )  {
                                formContext.ui.setFormNotification("This Evergreen Renewal opportunity is created from a backdated opportunity and contains the quote products with custom schedule, please validate the revenue schedule dates before approving the FAR", "WARNING", "101");
                            }
                            else {
                                formContext.ui.clearFormNotification("101");
                            }
                        }

                    }
                }
            }
        }
    }
}

function setAssignedGateKeeperNotRequired(executionContext) {
    var formContext = executionContext.getFormContext();
    var approvalType = formContext.getAttribute("niq_approvaltype").getValue();
    var assignedGatekeeper = formContext.getAttribute("niq_assignedtoid");
    var formType = formContext.ui.getFormType();
    if (formType == 1 && approvalType == 100000001) {
        formContext.getAttribute("niq_assignedtoid").setRequiredLevel("none");
    }
}