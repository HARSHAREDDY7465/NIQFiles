if (typeof (CommonForm) === "undefined") {
    CommonForm = {
        __namespace: true
    };
}
var gsCurrentUserRoles = []; //global variable to save user roles names - array
var delegateRoles = ['NIQ Delegate Agent', 'NIQ Delegate Manager', 'System Administrator'];
var nondelegateRoles = ['NIQ Global Helpline Agent', 'NIQ Global Helpline Manager', 'NIQ Analytics Agent', 'NIQ Client Response Agent', 'NIQ Client Response Manager', 'NIQ Analytics Manager', 'NIQ Ops Solution Provider', 'System Administrator', 'NIQ Ops Submitter', 'NIQ Customer Service'];
var showopsbuttonRoles = ['NIQ Global Helpline Agent', 'NIQ Global Helpline Manager', 'NIQ Analytics Agent', 'NIQ Client Response Agent', 'NIQ Client Response Manager', 'NIQ Analytics Manager',
    'NIQ Ops Solution Provider', 'System Administrator', 'NIQ Ops Submitter', 'NIQ Customer Service'];
var serviceReqCreateRoles = ['NIQ Delegate Agent', 'NIQ Delegate Manager', 'NIQ Global Helpline Agent', 'NIQ Global Helpline Manager', 'NIQ Analytics Agent', 'NIQ Client Response Agent', 'NIQ Client Response Manager', 'NIQ Analytics Manager',
    'NIQ Ops Solution Provider', 'System Administrator', 'NIQ Ops Submitter', 'NIQ Customer Service'];
var sysAdmin = ['System Administrator'];
    CommonForm.Events = {
    ShowHideTabs: function (formContext, tabName, isVisible) { // Hide a tab
        "use strict";
        if (formContext.ui.tabs.get(tabName) !== null) {
            formContext.ui.tabs.get(tabName).setVisible(isVisible);
        }
    },
    ShowHideFields: function (formContext, fields, isVisible) { //Show or Hide fields in the form
        "use strict";
        for (var i = 0; i < fields.length; i++) {
            if (formContext.getControl(fields[i]) !== null) {
                formContext.getControl(fields[i]).setVisible(isVisible);
            }
        }
    },
    SetRequiredFieldLevels: function (formContext, fields, reqlevel) { //Show or Hide fields in the form
        "use strict";
        for (var i = 0; i < fields.length; i++) {
            if (formContext.getControl(fields[i]) !== null) {
                formContext.getAttribute(fields[i]).setRequiredLevel(reqlevel);
            }
        }
    },
    SetFocusTabs: function (formContext, tabName) { //Set focus to a tab
        "use strict";
        if (formContext.ui.tabs.get(tabName) !== null) {
            formContext.ui.tabs.get(tabName).setFocus();
        }
    },
    ShowHideSections: function (formContext, tabName, sectionName, isVisible) { //show or hide a section in a tab
        "use strict";
        if (formContext.ui.tabs.get(tabName) !== null && formContext.ui.tabs.get(tabName).sections.get(sectionName) !== null) {
            formContext.ui.tabs.get(tabName).sections.get(sectionName).setVisible(isVisible);
        }
    },
    CheckFieldExists: function (formContext, fieldName) { // function to check if a field exists in a form
        "use strict";
        if (formContext.getAttribute(fieldName) !== null) return true;
        else return false;
    },
    CheckControlExists: function (formContext, fieldName) { // function to check if a field exists in a form	
        "use strict";
        if (formContext.getControl(fieldName) !== null) return true;
        else return false;
    },
    CheckValueExists: function (formContext, fieldName) { // Check if a value exists in a form
        "use strict";
        var isValueExists = false;
        if (formContext.getAttribute(fieldName) !== null && formContext.getAttribute(fieldName).getValue() !== null) {
            isValueExists = true;
        }
        return isValueExists;
    },
    GetFieldValue: function (formContext, fieldName) { // Get field value from a field
        "use strict";
        if (formContext.getAttribute(fieldName) !== null) {
            return formContext.getAttribute(fieldName).getValue();
        }
        else return null;
    },
    SetFieldValue: function (formContext, fieldName, val) { // set field value from a value
        "use strict";
        if (formContext.getAttribute(fieldName) !== null) {
            formContext.getAttribute(fieldName).setValue(val);
        }
    },
    GetUserRoleNames: function () {
        "use strict";
        // check if logged in user has a specific role
        if (gsCurrentUserRoles.length === 0) {
            var globalContext = Xrm.Utility.getGlobalContext();
            //Changes for DYNCRM-2723
            //var laRoles = globalContext.userSettings.securityRoles;     
            //this.getRole(laRoles); // get all role names in the gsCurrentUserRoles array object 
            var laRoles = globalContext.userSettings.roles;
            laRoles.forEach(function hasRoleName(item, index) {
                if (item != null) {
                    gsCurrentUserRoles.push(item.name);
                };
            });
        }
    },
    CheckIfLoggedInUserRole: function (rolename) { //Check if the current user role exists in the list of roles
        "use strict";
        var isRoleExists = false;
        this.GetUserRoleNames();
        // iterate through each role name
        for (var liCountI = 0; liCountI < gsCurrentUserRoles.length; liCountI++) {
            if (gsCurrentUserRoles[liCountI].toString().toLowerCase().indexOf(rolename.toLowerCase()) >= 0) {
                isRoleExists = true;
            }
        }
        return isRoleExists; // return true if role exists 
    },
    // check either of one role exists from the rolenames sent ,  rolenames will be string separated by comma
    CheckIfLoggedInUserRoles: function (rolenames) { // Check if multiple roles exists in currnet user roles
        "use strict";
        var isRoleExists = false;
        //check if global variable contains current user role names in array
        this.GetUserRoleNames();
        // check if the roles are available in rolenames string
        var found = gsCurrentUserRoles.some(r => rolenames.indexOf(r) >= 0);
        if (found) {
            return true;
        }
        else {
            return false;
        }
    },
    // get the rolename for the current user roles
    getRole: function (rolesid) { // parameter- get rolesid array of the current user 
        "use strict";
        var globalContext = Xrm.Utility.getGlobalContext();
        var serverUrl = globalContext.getClientUrl();
        var fetchRole = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
            "<entity name='role'>" +
            "<attribute name='name' />" +
            "<filter type='and'>" +
            "<condition attribute='roleid' operator='in'>";
        for (var i = 0; i < rolesid.length; i++) {
            fetchRole += "<value uiname='' uitype='role'>" + rolesid[i] + "</value>";
        }
        fetchRole += "</condition></filter>" + "</entity>" + "</fetch>";
        var fetchroleResults = this.GetFetchRecords(serverUrl, fetchRole, "roles");
        if (fetchroleResults != null && fetchroleResults.value.length > 0) {
            for (var j = 0; j < fetchroleResults.value.length; j++)
                gsCurrentUserRoles.push(fetchroleResults.value[j].name); // load the roles names to array
        }
    },
    // disable all the fields of the form 
    disableFormFields: function (lbOnOff, formContext) { // Disable all the fields in a form
        "use strict";
        var index = 0;
        formContext.ui.controls.forEach(function (control, index) {
            if (control && control.getDisabled && !control.getDisabled()) {
                control.setDisabled(lbOnOff);
            }
        });
    },
    // load dependent option set values 
    filteroptions: function (executionContext, optionAName, optionBName, optionSetBValues, dependecies) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var selectedAValue = formContext.getAttribute(optionAName).getValue();
        var optionSetBControl = formContext.getControl(optionBName);
        // check the global variable and load the values in the array
        if (optionSetBValues === null) optionSetBValues = optionSetBControl.getOptions();
        if (optionSetBValues.length > 1 && (optionSetBValues[0].text === "" || optionSetBValues[0].text === undefined)) {
            optionSetBValues.shift();
        }
        //  check if selected value is  not null
        if (selectedAValue !== null) {
            optionSetBControl.clearOptions();
            var dependeciesB = dependecies.find(d => d[0] === selectedAValue).slice(1);
            var filtredOptionB = optionSetBValues.filter(v => dependeciesB.includes(v.value));
            filtredOptionB.forEach(d => {
                optionSetBControl.addOption(d);
            })
        }
        else {
            optionSetBControl.clearOptions();
        }
    },
    EnableOrDisableSection: function (formContext, tabName, sectionName, status) { //Enable  or Disable fields of a section in a tab
        "use strict";
        if (formContext.ui.tabs.get(tabName).sections.get(sectionName) !== null && formContext.ui.tabs.get(tabName).sections.get(sectionName) !== undefined) {
            var controls = formContext.ui.tabs.get(tabName).sections.get(sectionName).controls.get();
            var numberOfControls = controls.length;
            for (var i = 0; i < numberOfControls; i++) {
                controls[i].setDisabled(status);
            }
        }
    },
    navigateToForm: function (entityName, entityFormId) {
        var entityFormOptions = {};
        entityFormOptions.entityName = entityName;
        entityFormOptions.formId = entityFormId;
        entityFormOptions.openInNewWindow = false;
        Xrm.Navigation.openForm(entityFormOptions);
    },
    navigateToEditForm: function (entityFormOptions) {
        Xrm.Navigation.openForm(entityFormOptions).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });
    },
    navigateToHnSForm: function (entityName, entityFormId) {
        var pageInput = {
            pageType: "entityrecord",
            entityName: entityName,
            formId: entityFormId
        };
        var navigationOptions = {
            target: 2,
            height: {
                value: 100,
                unit: "%"
            },
            width: {
                value: 50,
                unit: "%"
            },
            position: 1
        };
        Xrm.Navigation.navigateTo(pageInput, navigationOptions);
        //Xrm.Navigation.navigateTo({pageType:"entityrecord", entityName:entityName, formType:1,formId:entityFormId}, {target: 2, position: 1, width: {value: 50, unit:"%"}});
    },
    GetFieldText: function (formContext, fieldName) { // Get field value from a field
        "use strict";
        if (formContext.getAttribute(fieldName) !== null) {
            return formContext.getAttribute(fieldName).getText();
        }
        else return null;
    },
    LoadFormBasedOnRecordType: function (formContext, recordTypeText) {
        var currentForm = formContext.ui.formSelector.getCurrentItem();
        // Get all the forms accessible and filter the one which has to be loaded
        if (currentForm.getLabel().toLowerCase() !== recordTypeText.toLowerCase()) {
            // Get the Record's, record type text
            var availableForms = formContext.ui.formSelector.items.get();
            for (var i in availableForms) {
                var form = availableForms[i];
                var formname = form.getLabel();
                if (formname.toLowerCase() === recordTypeText.toLowerCase()) {
                    form.navigate();
                    return true;
                }
            }
            if (currentForm.getLabel().toLowerCase() !== availableForms[0].getLabel().toLowerCase()) {
                availableForms[0].navigate();
                return true;
            }
        }
    },
    ShowHideCreateNewbtn: async function (primaryctrl) {
        "use strict";
        let globalContext = Xrm.Utility.getGlobalContext();
        let flag;
        //DYNCRM-1815, Create New custom ribbon btn is hidden from Sales APP
        await globalContext.getCurrentAppName().then(function successCallback(appName) {
            if (appName === "Customer Service workspace" && CommonForm.Events.CheckIfLoggedInUserRoles(serviceReqCreateRoles)) {
                flag = true;
            }
            else flag = false;
        });
        return flag;

    },
    ShowHideOpsCreateNewbtn: function (primaryctrl) {
        "use strict";
        if (CommonForm.Events.CheckIfLoggedInUserRoles(showopsbuttonRoles)) {



            return true;

        }
        else return false;
    },
    ShowHideCreateNewDelegateBtn: function (primaryctrl) {
        "use strict";
        if (CommonForm.Events.CheckIfLoggedInUserRoles(delegateRoles)) {



            return true;

        }
        else return false;
    },
    ShowHideCreateNewNonDelegateBtn: function (primaryctrl) {
        "use strict";
        if (CommonForm.Events.CheckIfLoggedInUserRoles(nondelegateRoles)) {



            return true;

        }
        else return false;
    },
    ShowHideCreateNewNghAMBtn: function (primaryctrl) {
        "use strict";
        if (CommonForm.Events.CheckIfLoggedInUserRoles(sysAdmin)) {



            return true;

        }
        else return false;
    },


    //synchronous method to fetch record from the application
    GetFetchRecords: function (clientURL, fetchXmlQuery, ename) {
        "use strict";
        var req = new XMLHttpRequest();
        var resultVal = null;
        req.open(
            "GET",
            clientURL +
            "/api/data/v9.0/" + ename + "?fetchXml=" + encodeURIComponent(fetchXmlQuery),
            false);
        req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    resultVal = results;
                }
                else {
                    resultVal = null;
                }
            }
        };
        req.send();
        return resultVal;
    },
    OpenQuickCreate: function (primaryctrl) {
        var parameters = {};
        var accountid = primaryctrl.data.entity.attributes.getByName("customerid").getValue();
        var title = primaryctrl.data.entity.attributes.getByName("title").getValue();
        var description = primaryctrl.data.entity.attributes.getByName("description").getValue();
        var currentFormId = formContext.ui.formSelector.getCurrentItem().getId();
        parameters["title"] = title;
        parameters["description"] = description;


        if (accountid != null) 
        {
            var lkupaccount = new Array();
            lkupaccount[0] = new Object();
            lkupaccount[0].id = accountid[0].id;
            lkupaccount[0].name = accountid[0].name;
            lkupaccount[0].entityType = "account";
            parameters["customerid"] = lkupaccount;
        }
        if (title != null) 
        {
            var lkupparentcaseid = new Array();
            lkupparentcaseid [0] = new Object();
            lkupparentcaseid [0].id = "{" + primaryctrl._entityReference.id.guid.toUpperCase()+ "}";
            lkupparentcaseid [0].name = primaryctrl.data.entity.attributes.getByName("title").getValue();
            lkupparentcaseid [0].entityType = primaryctrl._entityName;
            parameters["parentcaseid"] = primaryctrl.data.entity.getEntityReference();
        }
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "incident";
        entityFormOptions["formId"] = currentFormId;
        Xrm.Navigation.openForm(entityFormOptions, parameters)
    },
    // Function to check if the user has any of the required roles
    UserHasRequiredRole: function (executionContext, requiredRoles) {
        var formContext = executionContext.getFormContext(); // Get the form context
        var userRoles = Xrm.Utility.getGlobalContext().userSettings.roles; // Get the current user's roles

        // Check if the user has any of the roles in the requiredRoles array
        for (var i = 0; i < userRoles.getLength(); i++) {
            var role = userRoles.getAll()[i].name;
            if (requiredRoles.includes(role)) {  // Check if the role is in the array
                return true; // User has one of the required roles
            }
        }
        return false; // User does not have any of the required roles
    },
    ///get sales org with Country and Company code
    GetSalesOrgWithCompanyCodeCountry: async function (saleOrgId) {
        let results = null;
        debugger;
        let fetchSalesOrg = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
            "  <entity name='niq_salesorg'>" +
            "    <attribute name='niq_salesorgid' />" +
            "    <attribute name='niq_name' />" +
            "    <order attribute='niq_name' descending='false' />" +
            "    <filter type='and'>" +
            "      <condition attribute='niq_salesorgid' operator='eq' value='{" + saleOrgId + "}' />" +
            "    </filter>" +
            "    <link-entity name='niq_companycode' from='niq_companycodeid' to='niq_companycode' link-type='inner' alias='aa'>" +
            "      <attribute name='niq_companycode' />" +
            "    </link-entity>" +
            "    <link-entity name='niq_country' from='niq_countryid' to='niq_operatingcountryid' link-type='inner' alias='ac'>" +
            "      <attribute name='niq_name' />" +
            "    </link-entity>" +
            "  </entity>" +
            "</fetch>";

        fetchSalesOrg = "?fetchXml=" + encodeURIComponent(fetchSalesOrg);

        results = await Xrm.WebApi.retrieveMultipleRecords("niq_salesorg", fetchSalesOrg);
        if (results.entities.length > 0) {
            return results;
        }
    },
    // get the EDICOM record from configuration entity
    GetEDICOMRecordFromConfigurationSetting: async function () {
        debugger;
        let fetchRecord = null;
        let results = null;
        fetchRecord = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
            "  <entity name='niq_configurationsetting'>" +
            "    <attribute name='niq_configurationsettingid' />" +
            "    <attribute name='niq_name' />" +
            "    <attribute name='niq_to' />" +
            "    <order attribute='niq_name' descending='false' />" +
            "    <filter type='and'>" +
            "      <condition attribute='niq_configurationsettingid' operator='eq' uiname='EDICOM' uitype='niq_configurationsetting' value='{E7908E6E-1B0B-F011-BAE3-7C1E528418EA}' />" +
            "    </filter>" +
            "  </entity>" +
            "</fetch>";

        fetchRecord = "?fetchXml=" + encodeURIComponent(fetchRecord);
        results = await Xrm.WebApi.retrieveMultipleRecords("niq_configurationsetting", fetchRecord);
        if (results.entities.length > 0) {
            return results;
        }
    },    // Set Invoice Dispatch Method field to EDICOM
    IsValidToSetInvoiceDispatchMethod: async function (executionContext, salesOrgLogicalName) {
        debugger;
        let jsonData = null;
        let niq_companycode = null;
        let niq_name = null;
        let isValid = false;
        let result = null;
        var formContext = executionContext.getFormContext(); // Get the form context
        let salesOrg = formContext.getAttribute(salesOrgLogicalName).getValue(); // get sales Org

        if (salesOrg === null) {
            isValid = false;
        } else {
            // get EDICOM record from configuration setting
            let getSalesOrgData = await CommonForm.Events.GetSalesOrgWithCompanyCodeCountry(salesOrg[0].id.replace(/[{}]/g, ''));
            if (getSalesOrgData != null) { // validate sales org
                niq_companycode = getSalesOrgData.entities[0]["aa.niq_companycode"]; // get comapanycode
                niq_name = getSalesOrgData.entities[0]["ac.niq_name"];// get name of country
            }
            // Get Configuration setting record 
            let configurationSettingData = await CommonForm.Events.GetEDICOMRecordFromConfigurationSetting();
            if (configurationSettingData != null) {
                jsonData = configurationSettingData.entities[0]["niq_to"];
                //Validate jsondata attribute
                if (CommonForm.Events.IsValid(jsonData)) {
                    result = JSON.parse(jsonData);
                }
            }
            //Validate attributes
            if (CommonForm.Events.IsValid(niq_companycode) && CommonForm.Events.IsValid(niq_name) && CommonForm.Events.IsValid(result)) {
                let found = result.find(item => item.Country === niq_name && item["Company Code"] === niq_companycode);
                if (found) {
                    isValid = true;
                } else {
                    isValid = false;
                }
            }
        }
        return isValid;
    },
    IsValid: function (attr) {
        // Check if the attribute is neither null, undefined, nor an empty string
        if (attr !== null && attr !== '' && attr !== undefined) {
            return true;  // Valid if the attribute exists and is not an empty string
        }
        return false;  // Invalid if the attribute is null, undefined, or an empty string
    },
    ShowNIQGFKAugRelease: async function(){
        var result = await Xrm.WebApi.retrieveRecord("niq_configurationsetting", "982a3707-594b-f011-877a-6045bda1abcd", "?$select=niq_name,niq_to");
     
        if(result && result["niq_to"] == "true") {
            return true;
        } else {
            return false;
        }
    }

}