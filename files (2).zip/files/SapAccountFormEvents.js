if (typeof (SAPAccountForm) === "undefined") {
	SAPAccountForm = {
		__namespace: true
	};
}
SAPAccountForm.Events = {
	OnFormLoad: function (executionContext) {
		"use strict";
		var formContext = executionContext.getFormContext();
                formContext.getControl("header_process_niq_iscreditcheckneeded").setDisabled(true); //making "is Credit check needed?" field read only on BPF
		var formType = formContext.ui.getFormType();
		if (formType === 1) {
			if (CommonForm.Events.CheckValueExists(formContext, "niq_opportunityid")) {
				formContext.getAttribute("niq_salesorgid").setRequiredLevel('none');
				formContext.getControl("niq_salesorgid").setDisabled(true);
				/*formContext.data.entity.addOnPostSave(function (executionContext){
						var entityFormOptions = {};
						entityFormOptions["entityName"] = "niq_sapaccountrequest";
						entityFormOptions["entityId"] = formContext.data.entity.getId().replace("{", "").replace("}","");
						// Open the form.
						Xrm.Navigation.openForm(entityFormOptions);
					});*/
			}
		}
		else if (formType === 2) {
			this.setAccountsFilter(executionContext);
			this.setSalesGroupFilter(executionContext);
		}
		this.setGLAccountsFilter(executionContext);
                formContext.data.process.addOnPreStageChange(this.PreventStageMovement);
	},
	setGLAccountsFilter: function (executionContext) {
		// get the form context
		var formContext = executionContext.getFormContext();
		if (formContext.getAttribute("niq_glaccountid") !== undefined && formContext.getAttribute("niq_glaccountid") !== null) {
			formContext.getAttribute("niq_glaccountid").controls.forEach(function (glAccountCTRL, i) {
				glAccountCTRL.addPreSearch(function () {
					SAPAccountForm.Events.filterGLAccounts(glAccountCTRL);
				});
				if ((glAccountCTRL.controlDescriptor.Parameters.DisableMru === undefined || glAccountCTRL.controlDescriptor.Parameters.DisableMru === null) || glAccountCTRL.controlDescriptor.Parameters.DisableMru === false) {
					glAccountCTRL.controlDescriptor.Parameters.DisableMru = true;
				}
			});
		}
	},
	filterGLAccounts: function (glAccountCTRL) {
		"use strict";
		// Only show accounts with the type 'GL Account Numbers'           
		var glAccountFilter = "<filter type='and'><condition attribute='niq_glaccountnumber' operator='in' >" + "<value>0001300000</value>" + "<value>0001300001</value>" + "<value>0001300002</value>" + "<value>0001300020</value>" + "<value>0001300130</value>" + "<value>0001300190</value>" + "<value>0005015020</value>" + "<value>0005015025</value>" + "<value>0005095020</value>" + "</condition></filter>";
		glAccountCTRL.addCustomFilter(glAccountFilter, "niq_glaccount");
	},

	setAccountsFilter: function (executionContext) {
		// get the form context
		formContext = executionContext.getFormContext();
		if (CommonForm.Events.CheckFieldExists(formContext, "niq_sapaccounttobeusedid")) {
			var resLayout = "<grid name='resultset' object='1' jump='name' select='1' icon='1' preview='1'><row name='result' id='accountid'><cell name='name' width='300'/><cell name='address1_city' width='100'/><cell name='niq_countryid' width='100'/><cell name='niq_industry' width='100'/><cell name='niq_ultimateparentid' width='100'/></row></grid>";
			var relAccResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
				"  <entity name='account'>" +
				"    <attribute name='name' />" +
				"    <attribute name='accountid' />" +
				"    <attribute name='niq_ultimateparentid' />" +
				"    <attribute name='niq_industry' />" +
				"    <attribute name='niq_countryid' />" +
				"    <attribute name='address1_city' />" +
				"    <order attribute='name' descending='false' />" +
				"    <filter type='and'>" +
				"      <condition attribute='statecode' operator='eq' value='0' />" +
				"      <condition attribute='niq_accounttype' operator='eq' value='2' />" +
				"    </filter>" +
				"  </entity>" +
				"</fetch>";
			var entName = "account";
			var vwRelAcc = "Active SAP Accounts";
			var vwRelAccId = "{00000000-0000-0000-0000-100000000002}";
			//formContext.getControl("niq_sapaccounttobeusedid").addCustomView(vwRelAccId, entName, vwRelAcc, relAccResult, resLayout, true);

			formContext.getAttribute("niq_sapaccounttobeusedid").controls.forEach(function (sapAccountCTRL, i) {

				SAPAccountForm.Events.filterSAPAccounts(sapAccountCTRL);
				sapAccountCTRL.addCustomView(vwRelAccId, entName, vwRelAcc, relAccResult, resLayout, true);
				if ((sapAccountCTRL.controlDescriptor.Parameters.DisableMru === undefined || sapAccountCTRL.controlDescriptor.Parameters.DisableMru === null) || sapAccountCTRL.controlDescriptor.Parameters.DisableMru === false) {
					sapAccountCTRL.controlDescriptor.Parameters.DisableMru = true;
				}
			});
		}

	},
	filterSAPAccounts: function (sapAccountCTRL) {
		"use strict";
		// Only show accounts with the type 'SAP Account'           
		var sapAccountFilter = "<filter type='and'>  <condition attribute='statecode' operator='eq' value='0' /> <condition attribute='niq_accounttype' operator='eq' value='2' /> </filter>";
		sapAccountCTRL.addCustomFilter(sapAccountFilter, "account");
	},
	setSalesGroupFilter: function (executionContext) {
		// get the form context
		formContext = executionContext.getFormContext();
		if (formContext.getControl("header_process_niq_salesgroupid")) {
			var account = formContext.getControl('header_process_niq_salesgroupid');
			formContext.getControl("header_process_niq_salesgroupid").addPreSearch(this.filterSalesGroup);
		}
	},
	filterSalesGroup: function () {
		"use strict";
		// Only show Sales Gropus with the related sales org      
		var salesOrgId = formContext.getAttribute("niq_salesorgid").getValue()[0].id;
		var salesOrgFilter = "<filter type='and'>  <condition attribute='niq_salesorgid' operator='eq' uitype='niq_salesorg' value='" + salesOrgId + "' /> </filter>";
		formContext.getControl("header_process_niq_salesgroupid").addCustomFilter(salesOrgFilter, "niq_salesgroup");
	},
	OnReviewResultChange: function (executionContext) {
		"use strict";
		// get the form context
		var formContext = executionContext.getFormContext();
		if (CommonForm.Events.CheckValueExists(formContext, "niq_reviewresult") && (CommonForm.Events.CheckFieldExists(formContext, "niq_arpledging"))) {
			var reviewResult = formContext.getAttribute("niq_reviewresult").getValue();
			formContext.getAttribute("niq_arpledging").setRequiredLevel("none");
			if (CommonForm.Events.CheckValueExists(formContext, "niq_salesorgid")) {
				var salesOrg = formContext.getAttribute("niq_salesorgid").getValue();
				var salesOrg_id = salesOrg[0].id.replace('{', '').replace('}', '');
				// retrieve salesorgcode
				Xrm.WebApi.retrieveRecord("niq_salesorg", salesOrg_id, "?$select=niq_salesorgcode").then(

					function success(result) {
						if (result["niq_salesorgcode"] !== null) {
							var salesOrgCode = result.niq_salesorgcode;
							//retrieve Sales Org List_SAP Account Request configurationsetting
							Xrm.WebApi.online.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_to&$filter=niq_name eq 'Sales%20Org%20List_SAP%20Account%20Request'").then(

								function success(results) {
									var niq_to = results.entities[0]["niq_to"];
									if (niq_to !== null) {
										if ((niq_to.includes(salesOrgCode)) && (reviewResult === 100000003)) {
											formContext.getAttribute("niq_arpledging").setRequiredLevel("required");
										}
									}
								},

								function (error) { });
						}
					},

					function (error) { });
			}
		}
	},
	SetARPledgingValue: function (executionContext) {
		"use strict";
		// getting formcontext
		var formContext = executionContext.getFormContext();
		//checking Gatekeeper Approval stage and niq_isgovernmnetaccount,niq_willaccountuseanttradebarter values
		if ((CommonForm.Events.CheckValueExists(formContext, "niq_isgovernmentaccount")) && (CommonForm.Events.CheckValueExists(formContext, "niq_willaccountuseanytradebarter")) && (CommonForm.Events.CheckValueExists(formContext, "niq_stage")) && (formContext.getAttribute("niq_stage").getValue() === "Gatekeeper Approval")) {
			var isGovtAccount = formContext.getAttribute("niq_isgovernmentaccount").getValue();
			var isTradeBarter = formContext.getAttribute("niq_willaccountuseanytradebarter").getValue();
			if (CommonForm.Events.CheckFieldExists(formContext, "niq_arpledging")) {
				if (isGovtAccount === true && isTradeBarter === true) {
					formContext.getAttribute("niq_arpledging").setValue(1);
				}
				else if (isGovtAccount === true && isTradeBarter === false) {
					formContext.getAttribute("niq_arpledging").setValue(1);
				}
				else if (isGovtAccount === false && isTradeBarter === true) {
					formContext.getAttribute("niq_arpledging").setValue(2);
				}
				else {
					formContext.getAttribute("niq_arpledging").setValue(null);
				}
			}
		}
	},
	PreventAutosave: function (executionContext) {
		"use strict";
		var eventArgs = executionContext.getEventArgs();
		if (eventArgs.getSaveMode() == 70 || eventArgs.getSaveMode() == 2) {
			eventArgs.preventDefault();
		}
	},
	PreventStageMovement(executionContext){
		"use strict";
		var formContext=executionContext.getFormContext();
		var activeProcess = (formContext.data.process.getActiveProcess() !== null) ? (formContext.data.process.getActiveProcess().getName()) : null;
        var activeStage = (formContext.data.process.getActiveStage() !== null) ? (formContext.data.process.getActiveStage().getName()) : null;
        var direction = executionContext.getEventArgs().getDirection();
        if ((activeProcess === "SAP Account request Process") && (direction === "Next") && (activeStage === "Gatekeeper Approval")) {
			if(CommonForm.Events.CheckValueExists(formContext,"niq_reviewresult")&&(formContext.getAttribute("niq_reviewresult").getValue()===100000001)){
                executionContext.getEventArgs().preventDefault();
                var alertStrings = { text: "Review Result field must be updated from Pending to either Send To BP Portal, Duplicate or Rejected in order to proceed."};
                Xrm.Navigation.openAlertDialog(alertStrings).then(
                    function (success) {
                    },
                    function (error) {
                    }
                );
			}
		}else if((activeProcess === "SAP Account request Process") && (direction === "Next") &&(activeStage==="Credit Check Assessment")){
			if(CommonForm.Events.CheckValueExists(formContext,"niq_creditcheckresult")&&(formContext.getAttribute("niq_creditcheckresult").getValue()===100000000)){
                executionContext.getEventArgs().preventDefault();
                var alertStrings = { text: "Credit Check Result must be updated from Pending to either Approved or Rejected in order to proceed."};
                Xrm.Navigation.openAlertDialog(alertStrings).then(
                    function (success) {
                    },
                    function (error) {
                    }
                );
			}        
		}
	}
};