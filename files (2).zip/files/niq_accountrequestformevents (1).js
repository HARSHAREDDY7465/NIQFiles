if (typeof AccountRequestForm === "undefined") {
    AccountRequestForm = {
        __namespace: true,
    };
}

AccountRequestForm.IsRegisteredOnBPF = false;
AccountRequestForm.IsRegisteredOnRequestType = false;
AccountRequestForm.IsRegisteredOnStateCode = false;
AccountRequestForm.IsValidateDuplicateAccountsOnSave = false;
AccountRequestForm.IsRegisteredOnFormLoad = false;

AccountRequestForm.RequestStatusFields = [
    "niq_requeststatus_new",
    "niq_requeststatus_db",
    "niq_requeststatus_compliancereview",
    "niq_requeststatus_mdmreview",
    "niq_requeststatus_closed",
    "header_process_niq_requeststatus_new",
    "header_process_niq_requeststatus_db",
    "header_process_niq_requeststatus_compliancereview",
    "header_process_niq_requeststatus_mdmreview",
    "header_process_niq_requeststatus_closed",
];

AccountRequestForm.StageRequestStatusFieldsMapping = {
    "new": ["niq_requeststatus_new", "header_process_niq_requeststatus_new"],
    "dnb match": ["niq_requeststatus_db", "header_process_niq_requeststatus_db"],
    "compliance review": ["niq_requeststatus_compliancereview", "header_process_niq_requeststatus_compliancereview"],
    "mdm review": ["niq_requeststatus_mdmreview", "header_process_niq_requeststatus_mdmreview"],
    "closed": ["niq_requeststatus_closed", "header_process_niq_requeststatus_closed", "niq_mdmclosingcomments", "header_process_niq_mdmclosingcomments"]
};

AccountRequestForm.RequestTypeFormGUIDMapping = {
    610570000: "c614d23a-c5cd-ef11-8ee9-00224889984b", // New SAP Account Request
    610570001: "00f94f3f-18cf-ef11-b8e8-7c1e524e097b", // Modify SAP Account Request
    610570002: "e69afa5a-1dcf-ef11-b8e9-6045bdf50c47", // Extend SAP Account Request
    610570003: "97eea200-1ecf-ef11-b8e9-6045bd9791de", // SAP Account Compliance Blocking
    610570004: "97eea200-1ecf-ef11-b8e9-6045bd9791de", // SAP Account Finance Blocking
    610570005: "97eea200-1ecf-ef11-b8e9-6045bd9791de", // SAP Account Compliance Restriction
    610570006: "97eea200-1ecf-ef11-b8e9-6045bd9791de", // SAP Account Compliance Unblock
    610570007: "97eea200-1ecf-ef11-b8e9-6045bd9791de", // SAP Account Compliance Unrestrict
    610570008: "279dd486-0e36-f011-8c4e-7c1e528418ea", // Customer Account Creation 
    610570009: "296036e3-0e36-f011-8c4d-6045bd9e6513" // Customer Account Modification
};

AccountRequestForm.Events = {
    FormOnload: function (executionContext) {
        try {
            const formContext = executionContext.getFormContext();
            const requestTypeAttribute = formContext.getAttribute("niq_requesttype");
            const statecodeAttribute = formContext.getAttribute("statecode");
   
            if (!AccountRequestForm.IsRegisteredOnBPF) {
                formContext.data.process.addOnStageChange(AccountRequestForm.Events.ValidateBPFStage);
                formContext.data.process.addOnStageChange(AccountRequestForm.Events.ValidateRequiredDocumentURLsForAccountRequest);
                formContext.data.process.addOnPreStageChange(AccountRequestForm.Events.BlockingBPFStageComplianceReview);
                formContext.data.process.addOnPreStageChange(AccountRequestForm.Events.fblockStageNavigationOnDuplicate);
                //formContext.data.process.addOnPreStageChange(AccountRequestForm.Events.PostDuplicateCheckCustomerAccountBPF);
                AccountRequestForm.Events.PostDuplicateCheckCustomerAccountBPF(executionContext);
                AccountRequestForm.IsRegisteredOnBPF = true;
            }

            if (requestTypeAttribute && !AccountRequestForm.IsRegisteredOnRequestType) {
                requestTypeAttribute.addOnChange(AccountRequestForm.Events.ValidateRequestType);
                AccountRequestForm.IsRegisteredOnRequestType = true;
            }

            if (statecodeAttribute && !AccountRequestForm.IsRegisteredOnStateCode) {
                statecodeAttribute.addOnChange(AccountRequestForm.Events.ValidateBPFStage);
                AccountRequestForm.IsRegisteredOnStateCode = true;
            }

            AccountRequestForm.Events.ValidateRequestType(executionContext);
            AccountRequestForm.Events.ValidateBPFStage(executionContext);
            AccountRequestForm.Events.showHideFields(executionContext);
            AccountRequestForm.Events.changeCustomerAccountToReadOnly(executionContext);
            AccountRequestForm.Events.ValidateRequiredDocumentURLsForAccountRequest(executionContext);
            AccountRequestForm.Events.filterRequestStatusOptions(executionContext);
            AccountRequestForm.Events.OnLoadOfCountryDetails(executionContext);
            AccountRequestForm.Events.LockFormComplianceReview(executionContext);
            formContext.getAttribute("niq_requeststatus").addOnChange(AccountRequestForm.Events.LockFormComplianceReview);
            formContext.getAttribute("niq_requesttype").addOnChange(AccountRequestForm.Events.LockFormComplianceReview);
            requestTypeAttribute.addOnChange(AccountRequestForm.Events.filterRequestStatusOptions);
            AccountRequestForm.Events.lockFieldsMDMapproved(executionContext);
            formContext.getAttribute("niq_requeststatus").addOnChange(AccountRequestForm.Events.lockFieldsMDMapproved);
            AccountRequestForm.Events.HideShowCustomerGroupFields(executionContext);
            AccountRequestForm.Events.MappingCustomerGroupFields(executionContext);
            if (formContext.getAttribute("niq_porequired")) {
                formContext.getAttribute("niq_porequired").addOnChange(AccountRequestForm.Events.MappingCustomerGroupFields);
            }
            if (!AccountRequestForm.IsRegisteredOnFormLoad) {
                formContext.data.process.addOnPreStageChange(this.restrictUserToMovePreviousStage);
                AccountRequestForm.IsRegisteredOnFormLoad = true;
            }
            if (requestTypeAttribute.getValue() == 610570001) {
                formContext.data.entity.addOnPostSave(AccountRequestForm.Events.onSaveModify);
            }
            AccountRequestForm.Events.DisplayNotificationNewBPFStage(executionContext);
            formContext.data.process.addOnStageChange(this.DisplayNotificationNewBPFStage);
            formContext.data.process.addOnStageChange(this.filterRequestStatusOptions);
            //Us-24965
            AccountRequestForm.Events.OnChangeRequestStatusMDMReview(executionContext);
            AccountRequestForm.Events.filterOwnerUserOnMDM(executionContext);
            formContext.getAttribute("niq_requeststatus_mdmreview").addOnChange(AccountRequestForm.Events.OnChangeRequestStatusMDMReview);
            formContext.getAttribute("niq_requeststatus_mdmreview").addOnChange(AccountRequestForm.Events.makeMDMCommentsRequiredWhenRejectedByMDM);
            AccountRequestForm.Events.OnLoadFieldVisibilityForSellers(executionContext);
            AccountRequestForm.Events.OnLoadFieldVisibilityForMDMTeam(executionContext);
            AccountRequestForm.Events.OnLoadFieldVisibilityForComplianceOnApprovedRequest(executionContext);
            AccountRequestForm.Events.OnLoadFieldVisibilityForMDMOnApprovedRequest(executionContext);
            AccountRequestForm.Events.OnLoadFieldVisibilityForSellersOnApprovedRequest(executionContext);
            if (requestTypeAttribute.getValue() == 610570009) { // Customer Account Modification
                AccountRequestForm.Events.makeMDMCommentsRequiredWhenRejectedByMDM(executionContext);
                var requestStatus= formContext.getAttribute("niq_requeststatus").getValue();
                if(requestStatus == null || requestStatus == "")
                {
                    formContext.getAttribute("niq_requeststatus").setValue(610570000);
                }
                formContext.getControl("niq_requesttype").setDisabled(true);
            }
            if (requestTypeAttribute.getValue() == 610570002) {
                formContext.getAttribute("niq_country").addOnChange(AccountRequestForm.Events.setInvoiceDispatchMethod);
            }
            //US-25488
            if (requestTypeAttribute.getValue() == 610570008) //Customer Account Creation
            {
                AccountRequestForm.Events.checkBpfActiveStage(executionContext);
                formContext.getAttribute("niq_geography").addOnChange(AccountRequestForm.Events.RequireAccountMarketCountry);
            }
            // US-25039
            AccountRequestForm.Events.makeMDMCommentsRequired(executionContext);
            AccountRequestForm.Events.makeFieldsReadOnlyForSalesUser(executionContext);
            // US-24109
            AccountRequestForm.Events.populateHFMClientCode(executionContext);
            AccountRequestForm.Events.populateFinanceIndustryMapping(executionContext);
            AccountRequestForm.Events.lockRequestStatusMDMUntilMDMReview(executionContext);
            AccountRequestForm.Events.checkDuplicateDUNS(executionContext);
            
            
            
        }
        catch (exception) {
            console.log("Error in FormOnload: " + exception);
        }
    },
    FormOnSavefunction:function (executionContext) {
        AccountRequestForm.Events.checkDuplicateDUNS(executionContext);  
    },
    FormOnSaveModify: function (executionContext) {
        AccountRequestForm.Events.makeMDMCommentsRequiredWhenRejectedByMDM(executionContext);
        AccountRequestForm.Events.ChangeBPFStageIfDunsHasValue(executionContext);
        AccountRequestForm.Events.PostDuplicateCheckCustomerAccountBPF(executionContext);
    },

    ValidateBPFStage: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const currentStage = formContext.data.process.getActiveStage();

        if (!currentStage) {
            console.log("No active stage found in BPF.");
            return;
        }

        const stageName = currentStage.getName().toLowerCase();
        const requestStatusFieldArray = AccountRequestForm.StageRequestStatusFieldsMapping[stageName];
        const formType = formContext.ui.getFormType();

        if (formType != 1) {
            AccountRequestForm.Events.ManageAccessiblity(formContext, "niq_requesttype", true);
            AccountRequestForm.Events.ManageAccessiblity(formContext, "header_process_niq_requesttype", true);
        }

        if (requestStatusFieldArray) {
            AccountRequestForm.Events.ManageRequestStatusFieldBehavior(formContext, requestStatusFieldArray);
            if (stageName == "sap account request") {
                requestStatusFieldArray.forEach((fieldLogicalName) => {
                    AccountRequestForm.Events.ManageAccessiblity(formContext, fieldLogicalName, true);
                });
            }
        }
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        if (requestType != null && requestType == 610570008 && stageName != "new") {
            formContext.getControl("niq_requestaccountname").setDisabled(true);
        }
    },

    //DYNCRM-23922 - Validate Sharepoint Document
    ValidateRequiredDocumentURLsForAccountRequest: async function (executionContext) {
        var warningMessage = null;
        var formContext = executionContext.getFormContext();
        if (formContext.data.process.getActiveStage().getName().toLowerCase() === "new") return; //old value sap account request

        var accountRequestId = Xrm.Page.data.entity.getId();
        if (!accountRequestId) return;

        const AccountRequestEntity = await Xrm.WebApi.online.retrieveRecord("niq_accountrequest", accountRequestId, "?$select=niq_letterheadurl, niq_lsaurl, niq_msaurl, niq_paymenttermsurl, niq_revenuecontrollersapprovalurl, niq_vattaxationdetailsurl");
        const requestTypeAttribute = formContext.getAttribute("niq_requesttype");

        if (requestTypeAttribute) {
            const requestTypeValue = requestTypeAttribute.getValue();

            switch (requestTypeValue) {
                case 610570000:
                    //New SAP Account Request
                    if (AccountRequestEntity.niq_msaurl == null || AccountRequestEntity.niq_lsaurl == null || AccountRequestEntity.niq_letterheadurl == null) {
                        warningMessage = "No attachment was included on this New SAP Account Request. Please, make sure you have the right DnB match and/or add any of the support documentation (MSA, LSA, Letterhead, etc) to avoid rejection of the request."
                    }
                    break;
                case 610570001:
                    //Modify SAP Account Request
                    if (AccountRequestEntity.niq_msaurl == null || AccountRequestEntity.niq_lsaurl == null || AccountRequestEntity.niq_vattaxationdetailsurl == null || AccountRequestEntity.niq_paymenttermsurl == null) {
                        warningMessage = "No attachment was included on this Modify SAP Account Request. Please, make sure you have the right DnB match and/or add any of the support documentation (MSA, LSA, Letterhead, etc) to avoid rejection of the request."
                    }
                    break;
            }

            if (warningMessage) {
                formContext.ui.setFormNotification(warningMessage, "WARNING", "Error_AccountRequest_File_Missing");
            }
            else {
                formContext.ui.clearFormNotification("Error_AccountRequest_File_Missing");
            }
        }
    },

    ValidateRequestType: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const formType = formContext.ui.getFormType();
        const requestTypeAttribute = formContext.getAttribute("niq_requesttype");

        if (requestTypeAttribute) {
            const requestTypeValue = requestTypeAttribute.getValue();
            //New or Modify or Extend or Creation or Modification
            if (requestTypeValue == 610570000 || requestTypeValue == 610570001 || requestTypeValue == 610570002 || requestTypeValue == 610570008 || requestTypeValue == 610570009) {
                formContext.ui.process.setVisible(true);
            } else {
                formContext.ui.process.setVisible(false);
            }
            const targetFormId = AccountRequestForm.RequestTypeFormGUIDMapping[requestTypeValue];

            if (targetFormId && targetFormId.toLowerCase() !== formContext.ui.formSelector.getCurrentItem().getId()) {
                if (formType !== 1) {
                    AccountRequestForm.Events.NavigateToExistingForm(formContext, targetFormId);
                }
                else {
                    AccountRequestForm.Events.NavigateToNewForm(formContext, targetFormId, requestTypeValue);
                }
            }
        }
    },

    NavigateToExistingForm: function (formContext, targetFormId) {
        if (formContext.ui.formSelector) {
            const availableForms = formContext.ui.formSelector.items.get();
            const targetForm = availableForms.find(form => form.getId().toLowerCase() === targetFormId.toLowerCase());
            if (targetForm) {
                targetForm.navigate();
            }
        }
    },

    NavigateToNewForm: function (formContext, targetFormId, requestTypeValue) {
        const opportunityAttribute = formContext.getAttribute("niq_relatedopportunity");
        const opportunityValue = opportunityAttribute ? opportunityAttribute.getValue() : null;
        var formParameters = {};
        formParameters["niq_relatedopportunity"] = opportunityValue ? opportunityValue : null;
        formParameters["niq_requesttype"] = requestTypeValue;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_accountrequest";
        entityFormOptions["createFromEntity"] = opportunityValue ? opportunityValue[0] : null;
        entityFormOptions["formId"] = targetFormId.toUpperCase();
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );
    },

    ManageRequestStatusFieldBehavior: function (formContext, requestStatusFieldArray) {
        const statecodeAttribute = formContext.getAttribute("statecode");
        AccountRequestForm.RequestStatusFields.forEach((fieldLogicalName) => {
            const isFieldMapped = requestStatusFieldArray.includes(fieldLogicalName);
            if (statecodeAttribute && statecodeAttribute.getValue() == 1) {
                AccountRequestForm.Events.ManageAccessiblity(formContext, fieldLogicalName, true);
            }
            else {
                AccountRequestForm.Events.ManageAccessiblity(formContext, fieldLogicalName, !isFieldMapped);
            }
            AccountRequestForm.Events.ManageRequiredLevel(formContext, fieldLogicalName, isFieldMapped ? "required" : "none");
            AccountRequestForm.Events.ManageVisiblity(formContext, fieldLogicalName, isFieldMapped);
        });
    },

    ManageVisiblity: function (formContext, controlName, isVisible) {
        if (!controlName.includes("header_process_")) {
            let attr = formContext.getAttribute(controlName);
            if (attr) {
                const controls = attr.controls;
                if (controls) {
                    for (let i = 0; i < controls.getLength(); i++) {
                        const control = controls.get(i);
                        if (!control.getName().includes("header_process_")) {
                            control.setVisible(isVisible);
                        }
                    }
                }
            }
        }
    },

    ManageRequiredLevel: function (formContext, attributeName, isRequired) {
        const attribute = formContext.getAttribute(attributeName);
        if (attribute) {
            attribute.setRequiredLevel(isRequired);
        }
    },

    ManageAccessiblity: function (formContext, controlName, isDisabled) {
        if (controlName.includes("header_process_")) {
            const control = formContext.getControl(controlName);
            if (control) {
                control.setDisabled(isDisabled);
            }
        }
        else {
            let attr = formContext.getAttribute(controlName);
            if (attr) {
                const controls = attr.controls;
                if (controls) {
                    for (let i = 0; i < controls.getLength(); i++) {
                        const control = controls.get(i);
                        control.setDisabled(isDisabled);
                    }
                }
            }
        }
    },

    showHideFields: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const country = formContext.getAttribute("niq_countryid")?.getValue()?.[0]?.name;

        if (formContext.getAttribute("niq_housenumber") && formContext.getAttribute("niq_salesgroupid")) {
            AccountRequestForm.Events.ManageVisiblity(formContext, "niq_housenumber", country === "Brazil");
            AccountRequestForm.Events.ManageVisiblity(formContext, "niq_salesgroupid", ["United States", "Canada"].includes(country));
        }
    },

    setValues: async function (executionContext) {
        const formContext = executionContext.getFormContext();
        const paymentterm = formContext.getAttribute("niq_paymentterms")?.getValue()?.[0]?.name;

        if (paymentterm) {
            const filterValue = paymentterm === "ND00" ? "GD01" : "GD02";
            try {
                await AccountRequestForm.Events.UpdateDunningProcedure(formContext, filterValue);
            }
            catch (error) {
                console.log("Error setting values: " + error.message);
                Xrm.Navigation.openErrorDialog({ message: "An error occurred while setting the Dunning Procedure." });
            }
        }
    },

    UpdateDunningProcedure: async function (formContext, masterValue) {
        try {
            const results = await Xrm.WebApi.retrieveMultipleRecords("niq_sapaccountmastersupportdata", `?$filter=niq_mastervalue eq '${masterValue}'`);

            if (results.entities.length > 0) {
                const lookupValue = [{
                    id: results.entities[0]["niq_sapaccountmastersupportdataid"],
                    name: results.entities[0]["niq_name"],
                    entityType: "niq_sapaccountmastersupportdata"
                }];
                formContext.getAttribute("niq_dunningprocedure").setValue(lookupValue);
            }
            else {
                console.log("No records found for the specified master value.");
            }
        }
        catch (error) {
            console.log("Error retrieving records: " + error.message);
            Xrm.Navigation.openErrorDialog({ message: "An error occurred while updating the Dunning Procedure." });
        }
    },

    //DYNCRM-21777 - Basic Duplicate Check
    EnableRule_ValidateButton: async function (formContext) {
        let formType = formContext.ui.getFormType();
        let currentFormId = formContext.ui.formSelector.getCurrentItem().getId();

        //Show button in CreateFormType and New SAP Account Request
        if (formType == 1 && currentFormId == AccountRequestForm.RequestTypeFormGUIDMapping[610570000]) {
            return true;
        } else {
            return false;
        }
    },

    OnClick_Validate: async function (formContext) {
        try {

            if (await AccountRequestForm.Events.IsDuplicateAccountFound(formContext)) {
                AccountRequestForm.Events.ShowCustomErrorMessage(formContext);

                var accountSubgrid = formContext.getControl("SG_DuplicateAccounts");
                accountSubgrid.setFilterXml(await AccountRequestForm.Events.GetFetchConditionForDuplicateAccount(formContext));
                accountSubgrid.refresh();
                formContext.ui.tabs.get("New SAP Account Details").sections.get("DuplicateAccounts").setVisible(true);
            } else {
                formContext.ui.tabs.get("New SAP Account Details").sections.get("DuplicateAccounts").setVisible(false);
                var accountSubgrid = formContext.getControl("SG_DuplicateAccounts");
                accountSubgrid.setFilterXml("<filter type='and'><condition attribute='accountid' operator='null' /></filter>");
                accountSubgrid.refresh();
            }
        }
        catch (error) {
            console.log("Error retrieving records: " + error.message);
            Xrm.Navigation.openErrorDialog({ message: "An error occurred from OnClick_Validate." });
        }
    },

    ShowCustomErrorMessage: async function (formContext) {
        formContext.ui.clearFormNotification("Error_DuplicateAccounts");
        var errorMsg = `This SAP account already exists. Creating a duplicate SAP account request is not permitted, but you can request a modification of the Account by changing the type of request to "Modification"`;
        formContext.ui.setFormNotification(errorMsg, "ERROR", "Error_DuplicateAccounts");
    },

    EnableRule_ModifyRequestButton: async function (formContext) {
        let formName = formContext.ui.formSelector.getCurrentItem().getLabel();
        let entityName = formContext.data.entity.getEntityName();
        if (formName == "New SAP Account Request" && entityName == "niq_accountrequest") {
            return true;
        } else {
            return false;
        }
    },

    OnClick_ModifyRequest: async function (selectedItemIds) {
        try {

            if (selectedItemIds.length == 1) {
                let accountId = selectedItemIds[0];
                const AccountEntity = await Xrm.WebApi.online.retrieveRecord("account", accountId, "?$select=name");

                var pageInput = {
                    pageType: "entityrecord",
                    entityName: "niq_accountrequest",
                    data: {
                        "niq_requesttype": 610570001,
                        "niq_customeraccount": accountId,
                        "niq_customeraccountname": AccountEntity["name"],
                        "niq_customeraccounttype": "account"
                    }
                };
                var navigationOptions = {
                    target: 2,
                    height: { value: 80, unit: "%" },
                    width: { value: 70, unit: "%" },
                    position: 1
                };
                Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
                    function success(result) {
                        console.log("Record created with ID: " + result.savedEntityReference[0].id +
                            " Name: " + result.savedEntityReference[0].name)
                        // Handle dialog closed
                    },
                    function error() {
                        // Handle errors
                    }
                );
            }
        }
        catch (error) {
            console.log("Error opening Form: " + error.message);
            Xrm.Navigation.openErrorDialog({ message: "An error occurred from OnClick_ModifyRequest." });
        }
    },

    FormOnSave: async function (executionContext) {
        var formContext = executionContext.getFormContext();

        if (!AccountRequestForm.IsValidateDuplicateAccountsOnSave) {
            executionContext.getEventArgs().preventDefault();

            if (await AccountRequestForm.Events.IsDuplicateAccountFound(formContext)) {
                AccountRequestForm.IsValidateDuplicateAccountsOnSave = false;
                AccountRequestForm.Events.ShowCustomErrorMessage(formContext);

                var accountSubgrid = formContext.getControl("SG_DuplicateAccounts");
                accountSubgrid.setFilterXml(await AccountRequestForm.Events.GetFetchConditionForDuplicateAccount(formContext));
                accountSubgrid.refresh();

                formContext.ui.tabs.get("New SAP Account Details").sections.get("DuplicateAccounts").setVisible(true);
            } else {
                formContext.ui.tabs.get("New SAP Account Details").sections.get("DuplicateAccounts").setVisible(false);
                var accountSubgrid = formContext.getControl("SG_DuplicateAccounts");
                accountSubgrid.setFilterXml("<filter type='and'><condition attribute='accountid' operator='null' /></filter>");
                accountSubgrid.refresh();

                formContext.ui.clearFormNotification("Error_DuplicateAccounts");
                AccountRequestForm.IsValidateDuplicateAccountsOnSave = true;
                formContext.data.entity.save();
            }
        }
    },

    IsDuplicateAccountFound: async function (formContext) {

        let accountLegalName = formContext.getAttribute("niq_sapaccountname").getValue();
        let dunsNumber = formContext.getAttribute("niq_dunsnumber").getValue();
        let vatTaxationNumber = formContext.getAttribute("niq_vattaxationnumber").getValue();

        if (accountLegalName == undefined || accountLegalName == null) {
            accountLegalName = "";
        }
        if (dunsNumber == undefined || dunsNumber == null) {
            dunsNumber = "";
        }
        if (vatTaxationNumber == undefined || vatTaxationNumber == null) {
            vatTaxationNumber = "";
        }

        if (accountLegalName != "" || dunsNumber != "" || vatTaxationNumber != "") {

            let fetchConditions = '<filter type="and">';
            fetchConditions += '<filter type="or">';

            if (accountLegalName != "") {
                fetchConditions += '<condition attribute="name" operator="eq" value="' + accountLegalName + '" />';
            }
            if (dunsNumber != "") {
                fetchConditions += '<condition attribute="niq_dunsnumber" operator="eq" value="' + dunsNumber + '" />';
            }
            if (vatTaxationNumber != "") {
                fetchConditions += '<condition attribute="niq_tax1" operator="eq" value="' + vatTaxationNumber + '" />';
                fetchConditions += '<condition attribute="niq_tax2" operator="eq" value="' + vatTaxationNumber + '" />';
                fetchConditions += '<condition attribute="niq_tax3" operator="eq" value="' + vatTaxationNumber + '" />';
                fetchConditions += '<condition attribute="niq_tax4" operator="eq" value="' + vatTaxationNumber + '" />';
                fetchConditions += '<condition attribute="niq_tax5" operator="eq" value="' + vatTaxationNumber + '" />';
            }
            fetchConditions += '</filter>';
            fetchConditions += '</filter>';

            let fetchAccount = `<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
                                    <entity name="account">
                                        <attribute name="name" />
                                        <attribute name="accountid" />
                                        <order attribute="name" descending="false" />
                                        ${fetchConditions}
                                    </entity>
                                </fetch>`;

            const AccountList = await Xrm.WebApi.retrieveMultipleRecords("account", `?fetchXml=${fetchAccount}`);
            if (AccountList.entities && AccountList.entities.length > 0) {
                return true;
            }
        }
        return false;
    },

    GetFetchConditionForDuplicateAccount: async function (formContext) {

        let accountLegalName = formContext.getAttribute("niq_sapaccountname").getValue();
        let dunsNumber = formContext.getAttribute("niq_dunsnumber").getValue();
        let vatTaxationNumber = formContext.getAttribute("niq_vattaxationnumber").getValue();

        if (accountLegalName == undefined || accountLegalName == null) {
            accountLegalName = "";
        }
        if (dunsNumber == undefined || dunsNumber == null) {
            dunsNumber = "";
        }
        if (vatTaxationNumber == undefined || vatTaxationNumber == null) {
            vatTaxationNumber = "";
        }

        let fetchConditions = '<filter type="and">';
        fetchConditions += '<filter type="or">';

        if (accountLegalName != "" || dunsNumber != "" || vatTaxationNumber != "") {
            if (accountLegalName != "") {
                fetchConditions += '<condition attribute="name" operator="eq" value="' + accountLegalName + '" />';
            }
            if (dunsNumber != "") {
                fetchConditions += '<condition attribute="niq_dunsnumber" operator="eq" value="' + dunsNumber + '" />';
            }
            if (vatTaxationNumber != "") {
                fetchConditions += '<condition attribute="niq_tax1" operator="eq" value="' + vatTaxationNumber + '" />';
                fetchConditions += '<condition attribute="niq_tax2" operator="eq" value="' + vatTaxationNumber + '" />';
                fetchConditions += '<condition attribute="niq_tax3" operator="eq" value="' + vatTaxationNumber + '" />';
                fetchConditions += '<condition attribute="niq_tax4" operator="eq" value="' + vatTaxationNumber + '" />';
                fetchConditions += '<condition attribute="niq_tax5" operator="eq" value="' + vatTaxationNumber + '" />';
            }
            fetchConditions += '</filter>';
            fetchConditions += '</filter>';
        }
        return fetchConditions;
    },
    //DYNCRM-24401 - Make Customer Account ReadOnly If CustomerAccount is not blank
    changeCustomerAccountToReadOnly: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var customerAccountControl = formContext.getAttribute("niq_customeraccount");
        if (customerAccountControl) {
            var customerAccount = formContext.getAttribute("niq_customeraccount").getValue();
            if (customerAccount !== undefined && customerAccount !== null) {
                formContext.getControl("niq_customeraccount").setDisabled(true);
            }
        }
    },
    //Funtion to call Side Pane
    OpenTheRecordSidePane: async function (executionContext) {
        const paneId = "SalesOrgExtensionSidePane";
        const formContext = executionContext.getFormContext();
        
            const entityName = formContext.data.entity.getEntityName();
            const recordId = formContext.data.entity.getId();
            if (recordId == null) {
                return;
            }
            const pane = Xrm.App.sidePanes.getPane(paneId) ?? await Xrm.App.sidePanes.createPane({
                paneId: paneId,
                canClose: true
            });
            pane.width = 600;  //you can decide what's the width of the side pane.
            //you could change the width for each record, in case you want to
            pane.navigate({
                pageType: "entityrecord",
                entityName: entityName,
                entityId: recordId,
                formId: "45e5fff6-8604-f011-bae3-6045bd91605b"
            });
        
    },

    EnableRule_NewSalesOrgExtension: function () {
        return true;
    },

    OpenCreateSalesOrgExtensionLookupObjects: async function (formContext) {
        const accountRequestId = formContext.data.entity.getId();

        //define data for lookupOptions
        var lookupOptions =
        {
            defaultEntityType: "niq_salesorg",
            entityTypes: ["niq_salesorg"],
            allowMultiSelect: true,
            defaultViewId: "57be3524-74fe-eb11-94ef-000d3a341bfb",
            viewIds: ["57be3524-74fe-eb11-94ef-000d3a341bfb"],
            searchText: "",
            filters: []
        };

        // Get account records based on the lookup Options
        Xrm.Utility.lookupObjects(lookupOptions).then(
            function (success) {
                console.log(success);
                if (success.length > 0) {
                    for (let i = 0; i < success.length; i++) {
                        AccountRequestForm.Events.CreateSalesOrgExtensionRecord(formContext, success[i]);
                    }
                }


            },
            function (error) {
                console.log(error);
            });
    },

    CreateSalesOrgExtensionRecord: async function (formContext, salesOrgObj) {
        let accountRequestId = formContext.data.entity.getId();
        accountRequestId = accountRequestId.replace("{", "").replace("}", "");
 
        let salesOrgId = salesOrgObj.id;
        var salesOrgName = salesOrgObj.name ? salesOrgObj.name : "";
        salesOrgId = salesOrgId.replace("{", "").replace("}", "");
 
        var data =
        {
            "niq_name": salesOrgName,
            "niq_SalesOrg@odata.bind": "/niq_salesorgs(" + salesOrgId + ")",
            "niq_accountrequest@odata.bind": "/niq_accountrequests(" + accountRequestId + ")"
        }
 
        // create account record
        Xrm.WebApi.createRecord("niq_salesorgextensionrequest", data).then(
            function success(result) {
                console.log("Account created with ID: " + result.id);
                // perform operations on record creation
 
                formContext.getControl("relatedsalesorgextensionrequests").refresh();
            },
            function (error) {
                console.log(error.message);
                // handle error conditions
            }
        );
    },

    //24721 - Lock all fields if request status is 'Approved by MDM'
    lockFieldsMDMapproved: async function (executionContext) {
        let formContext = executionContext.getFormContext();
        let formType = formContext.ui.getFormType();
        let requeststatus = formContext.getAttribute("niq_requeststatus").getValue();
        let requestType = formContext.getAttribute("niq_requesttype").getValue();

        if (requeststatus == 610570008) { //Approved by MDM
            let formControls = formContext.ui.controls;
            formControls.forEach(control => {
                if (control.getName() != "" && control.getName() != null) {
                    control.setDisabled(true);
                }
            });

            if (await AccountRequestForm.Events.IsLoggedInUserMDMReviewers()) {
                formContext.getControl("niq_requeststatus").setDisabled(false);
                //Extend
                if(requestType == 610570002)
                {
                    formContext.ui.tabs.get("General_tab").sections.get("ADS_section").setVisible(false); 
                }
            }
        } else {
            if(formType != 1 && 
                (requestType == 610570003 || 
                requestType == 610570004 ||
                requestType == 610570005 ||
                requestType == 610570006 ||
                requestType == 610570007)
            ) { 
                //SAP Account Compliance Block
                //SAP Account Financial Block
                //SAP Account Compliance Restrict
                //SAP Account Compliance / Financial Unblock
                //SAP Account Compliance Unrestrict
                if (await AccountRequestForm.Events.IsLoggedInUserMDMReviewers() && requeststatus != 610570008) {

                    formContext.getControl("ownerid").setDisabled(false);
                    formContext.getControl("niq_requeststatus").setDisabled(false);
                    formContext.getControl("niq_requestorscomment").setDisabled(false);

                } else {
                    let formControls = formContext.ui.controls;
                    formControls.forEach(control => {
                        if (control.getName() != "" && control.getName() != null) {
                            control.setDisabled(true);
                        }
                    });
                }
            }
        }
    },

    IsLoggedInUserMDMReviewers: async function () {
        let fetchUser = `<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">
                                    <entity name="systemuser">
                                        <attribute name="fullname" />
                                        <attribute name="systemuserid" />
                                        <order attribute="fullname" descending="false" />
                                        <filter type="and">
                                        <condition attribute="systemuserid" operator="eq-userid" />
                                        </filter>
                                        <link-entity name="teammembership" from="systemuserid" to="systemuserid" visible="false" intersect="true">
                                        <link-entity name="team" from="teamid" to="teamid" alias="team">
                                            <filter type="and">
                                            <condition attribute="name" operator="eq" value="MDM Reviewers" />
                                            </filter>
                                        </link-entity>
                                        </link-entity>
                                    </entity>
                                    </fetch>`;

        const UserList = await Xrm.WebApi.retrieveMultipleRecords("systemuser", `?fetchXml=${fetchUser}`);
        if (UserList && UserList.entities && UserList.entities.length > 0) {
            return true;
        } else {
            return false;
        }
    },

    //23122 preventing the bpf to move previous stage
    restrictUserToMovePreviousStage: function (executionContext) {
        const formContext = executionContext.getFormContext();
        let bpfArgs = executionContext.getEventArgs();
        let direction = bpfArgs.getDirection().toLowerCase();

        const currentStage = formContext.data.process.getActiveStage();
        const stageName = currentStage.getName().toLowerCase();

        if (direction == "previous") {
            bpfArgs.preventDefault();
            var alertStrings = {
                confirmButtonLabel: "OK",
                text: "Moving back to a previous stage is not allowed.",
                title: "Stage Navigation Blocked"
            };
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);

        }

        let requestType = formContext.getAttribute("niq_requesttype").getValue();
        var accountRequestId = formContext.data.entity.getId();
        accountRequestId = accountRequestId.replace("{", "").replace("}", "");

        if (!currentStage) {
            console.log("No active stage found in BPF.");
            return;
        }

        if (requestType == 610570002) { //Extend SAP Account Request
            if (direction == "next" && stageName == "new") {

                var req = new XMLHttpRequest();
                req.open("GET", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/niq_salesorgextensionrequests?$filter=_niq_accountrequest_value eq " + accountRequestId, false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Prefer", "odata.include-annotations=*");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var results = JSON.parse(this.response);
                            console.log(results);

                            if (results.value.length == 0) {
                                bpfArgs.preventDefault();

                                var alertStrings = {
                                    confirmButtonLabel: "OK",
                                    text: "Please select atleast one Sales Org.",
                                    title: "Error"
                                };
                                var alertOptions = { height: 120, width: 260 };
                                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                            }
                        } else {
                            console.log(this.responseText);
                        }
                    }
                };
                req.send();

            }
        }
    },
    // 23122-filtering request status options for request type compliance block, financial block, compliance restrict and unrestrict

    filterRequestStatusOptions: function (executionContext) {

        var formContext = executionContext.getFormContext();
        var requestTypeAttr = formContext.getAttribute("niq_requesttype");
        var requestStatusCtrl = formContext.getControl("niq_requeststatus");
        var requestStatusMDMReviewCtrl = formContext.getControl("header_process_niq_requeststatus_mdmreview");

        if (!requestTypeAttr || !requestStatusCtrl) {
            console.warn("Request Type or Request Status control not found.");
            return;
        }

        var requestType = requestTypeAttr.getValue();

        // Define all possible options
        var allOptions = [
            { text: "In Progress", value: 610570000 },
            { text: "Screening in Progress", value: 610570001 },
            { text: "Rejected by Compliance", value: 610570002 },
            { text: "Restricted by Compliance", value: 610570003 },
            { text: "Approved by Compliance", value: 610570004 },
            { text: "Compliance hold", value: 610570005 },
            { text: "Compliance-Pending Review", value: 610570006 },
            { text: "MDM-Pending Review", value: 610570007 },
            { text: "Approved by MDM", value: 610570008 },
            { text: "Rejected by MDM", value: 610570009 },
            { text: "Cancelled", value: 610570010 },
            { text: "Duplicate Found", value: 610570011 },
            { text: "Pending SAP Integration", value: 610570012 },
            { text: "Setup in SAP", value: 610570013 },
            { text: "MDM Review", value: 610570014 },
            { text: "On hold (Open transactions SAP)", value: 610570015 },
            { text: "Canceled - Not Blocked in SAP", value: 610570016 },
            { text: "Closed", value: 610570017 }

        ];

        var allOptionsMDMReview = [
            { text: "MDM-Pending Review", value: 610570007 },
            { text: "Approved by MDM", value: 610570008 },
            { text: "Rejected by MDM", value: 610570009 },
            { text: "On hold (Open transactions SAP)", value: 610570010 },
            { text: "Canceled - Not Blocked in SAP", value: 610570011 }
        ]

        var filteredOptions = [];
        var filteredOptionsMDMReview = [];
        if (requestType === 610570003 || requestType === 610570004) {
            filteredOptions = allOptions.filter(opt =>
                [610570000, 610570007, 610570008, 610570015, 610570016, 610570017].includes(opt.value)
            );
        }
        else if (requestType === 610570005 || requestType === 610570007) {
            filteredOptions = allOptions.filter(opt =>
                [610570000, 610570004].includes(opt.value)
            );
        }
        else {
            filteredOptions = allOptions;
        }

        if (formContext.data.process.getActiveStage().getName().toLowerCase() === "mdm review" && (requestType === 610570008 || requestType === 610570009)) {
            filteredOptionsMDMReview = allOptionsMDMReview.filter(opt =>
                [610570007, 610570008, 610570009].includes(opt.value)
            );

            requestStatusMDMReviewCtrl.clearOptions();
            filteredOptionsMDMReview.forEach(function (option) {
                requestStatusMDMReviewCtrl.addOption(option);
            });
        }

        requestStatusCtrl.clearOptions();
        filteredOptions.forEach(function (option) {
            requestStatusCtrl.addOption(option);
        });
    },

    //24646 Hiding customer group 1 and customer group 4 for sales user and showing it to only mdm team members
    HideShowCustomerGroupFields: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        try {
            var CustomerBillingSection = formContext.ui.tabs?.get("Review").sections?.get("Review_section_8");
            var userId = Xrm.Utility.getGlobalContext().userSettings.userId;
            var teamid = "047aaf19-7bce-ef11-b8e8-7c1e524e097b";
            var isUserInTeam = false;
            var query = "?$filter=systemuserid eq " + userId + " and teamid eq " + teamid;
            var response = await Xrm.WebApi.retrieveMultipleRecords("teammembership", query);
            if (response.entities.length > 0) {
                isUserInTeam = true;
            }
            if (!CommonForm.Events.CheckIfLoggedInUserRole("NIQ Sales User") && isUserInTeam) {
                CustomerBillingSection.setVisible(true);
            }
            else {
                CustomerBillingSection.setVisible(false);
            }
        }
        catch (exception) {
            console.log("Error : " + exception);
        }
    },

    // Mapping Po required with customer group 1 and invoice dispatch method with customer group 4
    MappingCustomerGroupFields: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var PoRequired = formContext.getAttribute("niq_porequired")?.getValue();
        //var InvoiceDispatchMethod = formContext.getAttribute("niq_invoicedispatchmethod")?.getValue();
        var CustomerGroup1 = formContext.getAttribute("niq_customergroup1");
        //var CustomerGroup4 = formContext.getAttribute("niq_customergroup4");
        if (PoRequired !== null && PoRequired == 1) {
            var MandatoryPo = "Mandatory PO";
            var record = await Xrm.WebApi.retrieveMultipleRecords("niq_sapaccountmastersupportdata", "?$select=niq_name&$filter=niq_name eq '" + MandatoryPo + "'");
            var result = record.entities[0];
            var lookupValue = [{
                id: result.niq_sapaccountmastersupportdataid,
                name: result.niq_name,
                entityType: "niq_sapaccountmastersupportdata"

            }];
            CustomerGroup1.setValue(lookupValue);

        }

    },

    //24405 - Displaying a notification when the record is in New BPF Stage
    DisplayNotificationNewBPFStage: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var requestType = formContext.getAttribute("niq_requesttype")?.getValue();
        var stage = formContext.data.process.getActiveStage();
        var stageName = stage.getName();
        if (stageName === "New" && requestType == 610570001) {
            formContext.ui.setFormNotification(
                "The fields modified for this SAP Account will apply to all Sales Orgs it is extended to. If your modification only applies to one Sales Org, please, specify it in Requestor Comment field.",
                "INFO",
                "stageNotification"
            );
        }
        else {
            formContext.ui.clearFormNotification("stageNotification");
        }

    },
    EnableRule_NewSalesOrgExtension: function () {
        return true;
    },
    onSaveCreateCustomerAccountRequest: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        AccountRequestForm.Events.ConcateAccountRequestName(executionContext);
        AccountRequestForm.Events.checkDuplicateAccountRequest(executionContext);
    },
    checkDuplicateAccountRequest: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var eventArgs = executionContext.getEventArgs();
        var formType = formContext.ui.getFormType();
        var saveMode = eventArgs.getSaveMode();
        var accountType = formContext.getAttribute("niq_accounttype")?.getValue();
        if(accountType != 1){
            
        
            if (formType !== 1 || saveMode === 70) {
                return;
            }

            var requestTypeAttr = formContext.getAttribute("niq_requesttype");
            var requestTypeText = requestTypeAttr?.getText();

            if (requestTypeText !== "Customer Account Creation") {
                return;
            }

            if (window.duplicateCheckInProgress) {
                window.duplicateCheckInProgress = false;
                return;
            }

            eventArgs.preventDefault();

            var customerName = formContext.getAttribute("niq_name")?.getValue();
            var country = formContext.getAttribute("niq_country")?.getValue();

            if (!customerName || !country) {
                console.log("Customer Name or Country is missing.");
                return;
            }

            var countryId = country[0].id.replace("{", "").replace("}", "");

            // Web API query to Account entity
            var query = `?$select=name,_niq_countryid_value&$filter=name eq '${customerName}' and _niq_countryid_value eq ${countryId}`;

            await Xrm.WebApi.retrieveMultipleRecords("account", query).then(
                function success(result) {
                    var accountSubgrid = formContext.getControl("Duplicate_Accounts");
                    var Tab = formContext.ui.tabs.get("General");
                    var duplicateSection = Tab?.sections.get("Duplicate Accounts");

                    if (result.entities.length > 0) {
                        formContext.ui.setFormNotification(
                            "An account with these details already exists. Duplicate account creation is not allowed. If you wish to change the account details, please submit a 'Modification' request.",
                            "ERROR",
                            "duplicate_account_warning"
                        );

                        if (Tab) {
                            Tab.setVisible(true);
                            Tab.setDisplayState("expanded");
                        }
                        if (duplicateSection) {
                            duplicateSection.setVisible(true);
                        }
                        if (accountSubgrid) {
                            accountSubgrid.setFilterXml(`
                                <filter type='and'>
                                    <condition attribute='name' operator='eq' value='${customerName}' />
                                    <condition attribute='niq_countryid' operator='eq' value='${countryId}' />
                                </filter>
                            `);
                            accountSubgrid.refresh();
                        }
                    } else {
                        window.duplicateCheckInProgress = true;
                        formContext.ui.clearFormNotification("duplicate_account_warning");

                        if (duplicateSection) {
                            duplicateSection.setVisible(false);
                        }
                        if (accountSubgrid) {
                            accountSubgrid.refresh();
                        }

                        formContext.data.entity.addOnPostSave(function () {
                            console.log("Post-save: moving to next BPF stage...");
                            formContext.data.process.moveNext();

                            setTimeout(() => {
                                formContext.data.refresh(false);
                            }, 1000);
                        });

                        formContext.data.save();
                    }
                },
                function (error) {
                    console.error("Error retrieving records: ", error.message);
                }
            );
        }
    },
    //US - 24965
    setInvoiceDispatchMethod: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var countryName = formContext.getAttribute("niq_country").getValue();
        var arrCountryName = ["Egypt", "Uganda", "Serbia", "Finland", "Italy", "Spain"]
        if (formContext.getAttribute("niq_country").getValue() != null) {
            if (arrCountryName.includes(countryName[0].name)) {
                formContext.getAttribute("niq_invoicedispatchmethod").setValue(4);
            } else {
                formContext.getAttribute("niq_invoicedispatchmethod").setValue(null);
            }
        }
    },
    //US - 24965
    OpenSalesOrgExtensionRequestRecordSidePane: async function (executionContext) {
        const paneId = "InformationExtension";
        const formContext = executionContext.getFormContext();
        if(!CommonForm.Events.CheckIfLoggedInUserRole("NIQ Sales User"))
        {
            const entityName = formContext.data.entity.getEntityName();
            const recordId = formContext.data.entity.getId();
            if (recordId == null) {
                return;
            }
            const pane = Xrm.App.sidePanes.getPane(paneId) ?? await Xrm.App.sidePanes.createPane({
                paneId: paneId,
                canClose: true
            });
            pane.width = 600;  //you can decide what's the width of the side pane.
            //you could change the width for each record, in case you want to
            pane.navigate({
                pageType: "entityrecord",
                entityName: entityName,
                entityId: recordId,
                formId: "71808eeb-3050-f011-877a-6045bdf317ec"
            });
        }
    },
    //US-25488
    RequireAccountMarketCountry: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var geographyValue = formContext.getAttribute("niq_geography").getValue();
        if (geographyValue == 100000002) //Local
        {
            formContext.getAttribute("niq_country").setRequiredLevel("required");
        } else {
            formContext.getAttribute("niq_country").setRequiredLevel("none");
        }
    },
    //US-25488
    //US-24895
    ConcateAccountRequestName : async function(executionContext)
    {
        var formContext = executionContext.getFormContext();
        var AccountName = formContext.getAttribute("niq_requestaccountname").getValue();
        var formType = formContext.ui.getFormType();
        var accountType = formContext.getAttribute("niq_accounttype").getValue();
        var accountNameNoCountry = formContext.getAttribute("niq_sapaccountname").getValue();
        var saveMode = executionContext.getEventArgs().getSaveMode();
        var eventArgs = executionContext.getEventArgs();
        var country = formContext.getAttribute("niq_country").getValue();
        var countryId = "";
        var countryName = ""
        if(AccountName != "" && country != null && accountType != null && accountType == 1)
        {
            countryId = country[0].id;
            countryName = country[0].name;
            // Check if AccountName already ends with (CountryName)
            var suffix = " (" + countryName + ")";
            if (AccountName.endsWith(suffix)) {
                return;
            }
            var results = await Xrm.WebApi.retrieveMultipleRecords("account", "?$select=accountid,name,_niq_countryid_value&$filter=(name eq '"+AccountName+"'and niq_accounttype eq 1 and _niq_countryid_value eq "+countryId+")");
            if(results.entities.length > 0)
            {
                if(saveMode == 1 || saveMode == 2 || saveMode == 70)
                {
                    eventArgs.preventDefault();
                    var alertStrings = { confirmButtonLabel: "Ok", text: "An account with these details already exists. Duplicate account creation is not allowed. If you wish to change the account details, please submit a 'Modification' request."};
                    var alertOptions = { height: 240, width: 260 };
                    Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                }
            }else{
                var currentValue = formContext.getAttribute("niq_requestaccountname").getValue();
                if(currentValue !== AccountName+suffix && accountNameNoCountry == null && formType == 1)
                {
                    formContext.getAttribute("niq_sapaccountname").setValue(AccountName);
                    formContext.getAttribute("niq_requestaccountname").setValue(AccountName+suffix);
                }else if(formType == 2){
                    var currentRecord = formContext.data.entity.getId();
                    var record = {};
                    record.niq_requestaccountname = accountNameNoCountry+suffix; // Text
                    await Xrm.WebApi.updateRecord("niq_accountrequest", currentRecord.replace("{","").replace("}",""), record);
                    formContext.data.refresh(true);
                }
            }
        }
    },
    checkBpfActiveStage: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var accountRequestId = formContext.data.entity.getId();
        if (accountRequestId != "") {
            var results = await Xrm.WebApi.retrieveMultipleRecords("niq_accountrequestprocessflow", "?$select=businessprocessflowinstanceid,_activestageid_value,_bpf_niq_accountrequestid_value&$filter=_bpf_niq_accountrequestid_value eq " + accountRequestId.replace("{", "").replace("}", "") + "");
            if (results.entities.length > 0) {
                var result = results.entities[0];
                var activeStageId = result["_activestageid_value"];
                var activeStageText = result["_activestageid_value@OData.Community.Display.V1.FormattedValue"];
                if (accountRequestId.toLowerCase() != "1bd15880-98bc-4b24-bbf6-cab683b90c58" && activeStageText != "New") {
                    formContext.getControl("niq_requestaccountname").setDisabled(true);
                } else {
                    formContext.getControl("niq_requestaccountname").setDisabled(false);
                }
            }
        }
    },
 
    // US-25039
    makeMDMCommentsRequired: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var rejectionReason = formContext.getAttribute("niq_rejectedreason").getValue();
        if (rejectionReason == 610570002) {
            formContext.getAttribute("niq_mdmclosingcomments").setRequiredLevel("required");
        } else {
            formContext.getAttribute("niq_mdmclosingcomments").setRequiredLevel("none");
        }
    },
    makeFieldsReadOnlyForSalesUser: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var accountRequestId = formContext.data.entity.getId();
        if (accountRequestId != "") {
            var results = await Xrm.WebApi.retrieveMultipleRecords("niq_accountrequestprocessflow", "?$select=businessprocessflowinstanceid,_activestageid_value,_bpf_niq_accountrequestid_value&$filter=_bpf_niq_accountrequestid_value eq " + accountRequestId.replace("{", "").replace("}", "") + "");
            if (results.entities.length > 0) {
                var result = results.entities[0];
                var activeStageText = result["_activestageid_value@OData.Community.Display.V1.FormattedValue"];
                if (activeStageText == "MDM Review" && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User")) {
                    CommonForm.Events.disableFormFields(true, formContext);
                }
                else {
                    CommonForm.Events.disableFormFields(false, formContext);
                }
            }
        }
    },
    // US-24109
    populateHFMClientCode: async function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var ultimateParentAccount = "";
        var hfmclient = formContext.getAttribute("niq_hfmclientcodeid").getValue();
        var reqstatus = formContext.getAttribute("niq_requeststatus_mdmreview").getValue();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_customeraccount")){
            var accountId = formContext.getAttribute("niq_customeraccount").getValue()[0].id.replace("{", "").replace("}", "");
        }
        if (reqstatus == 610570007)// MDM-Pending Review
        {
            if (hfmclient == null || hfmCode == "") {
                var res = await Xrm.WebApi.retrieveMultipleRecords("account", "?$select=_niq_ultimateparentid_value&$filter=(niq_accounttype eq 1 and accountid eq " + accountId + ")");
                if (res.entities.length > 0) {
                    var results = res.entities[0];
                    var ultimateParentAccount = results["_niq_ultimateparentid_value"];
                }
                if (ultimateParentAccount != null && ultimateParentAccount != undefined && ultimateParentAccount != "") {
                    try {
                        var result = await Xrm.WebApi.retrieveMultipleRecords("niq_hfmcode", "?$select=niq_hfmid&$filter=niq_isfinancialindustrymapping eq false and _niq_ultimateparentaccount_value eq " + ultimateParentAccount);
                        if (result.entities.length > 0) {
                            var Record = result.entities[0];
                            var hfmCode = Record["niq_hfmcodeid"];
                            var hfmCodeName = Record["niq_name"];
                            formContext.getAttribute("niq_hfmclientcodeid").setValue([
                                {
                                    id: hfmCode,
                                    name: hfmCodeName,
                                    entityType: "niq_hfmcode"
                                }
                            ]);
                        }
                        else {
                            AccountRequestForm.Events.populateHFMClientCodeifUltimateParentAccountIsEmpty(executionContext);
                        }
                    }
                    catch (error) {
                        console.error("Error retrieving finance industry mappings: " + error.message);
                    }
                }
                else {
                    AccountRequestForm.Events.populateHFMClientCodeifUltimateParentAccountIsEmpty(executionContext);
                }
            }
        }
    },
    // US-24109
    populateHFMClientCodeifUltimateParentAccountIsEmpty: async function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_customeraccount")){
            var accountId = formContext.getAttribute("niq_customeraccount").getValue()[0].id.replace("{", "").replace("}", "");
        }
        var res = await Xrm.WebApi.retrieveMultipleRecords("account", "?$select=niq_industry&$filter=(niq_accounttype eq 1 and accountid eq " + accountId + ")");
        if (res.entities.length > 0) {
            var results = res.entities[0];
            var industry = results["niq_industry"];
        }
        try {
            var result = await Xrm.WebApi.retrieveMultipleRecords("niq_hfmcode", "?$select=niq_name,niq_financeindustryl1mapping,niq_financeindustryl2mapping&$filter=niq_industry eq " + industry + " and niq_isfinancialindustrymapping eq false");
            if (result.entities.length > 0) {
                var Record = result.entities[0];
                var hfmCode = Record["niq_hfmcodeid"];
                var hfmCodeName = Record["niq_name"];
                formContext.getAttribute("niq_hfmclientcodeid").setValue([
                    {
                        id: hfmCode,
                        name: hfmCodeName,
                        entityType: "niq_hfmcode"
                    }
                ]);
            }
            else {
                formContext.getAttribute("niq_hfmclientcodeid").setValue(null);
            }
        }
        catch (error) {
            console.error("Error retrieving finance industry mappings: " + error.message);
        }
    },
    populateFinanceIndustryMapping: async function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var ultimateParentAccount = "";
        var reqstatus = formContext.getAttribute("niq_requeststatus_mdmreview").getValue();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_customeraccount")){
            var accountId = formContext.getAttribute("niq_customeraccount").getValue()[0].id.replace("{", "").replace("}", "");
        }
        if (accountId != null && accountId != undefined && accountId != "") {
            var res = await Xrm.WebApi.retrieveMultipleRecords("account", "?$select=_niq_ultimateparentid_value&$filter=(niq_accounttype eq 1 and accountid eq " + accountId + ")");
            if (res.entities.length > 0) {
                var results = res.entities[0];
                var ultimateParentAccount = results["_niq_ultimateparentid_value"];
            }
            var industry = formContext.getAttribute("niq_industry").getValue();

            if (ultimateParentAccount != null && ultimateParentAccount != undefined && ultimateParentAccount != "") {
                try {
                    var result = await Xrm.WebApi.retrieveMultipleRecords("niq_hfmcode", "?$select=niq_financeindustryl1mapping,niq_financeindustryl2mapping&$filter=niq_industry eq " + industry + " and niq_isfinancialindustrymapping eq true and _niq_ultimateparentaccount_value eq " + ultimateParentAccount);
                    if (result.entities.length > 0) {
                        var Record = result.entities[0];
                        var hfmCodeL1Mapping = Record.niq_financeindustryl1mapping;
                        var hfmCodeL2Mapping = Record.niq_financeindustryl2mapping;
                        if ((hfmCodeL1Mapping != null && hfmCodeL1Mapping != undefined && hfmCodeL1Mapping != "") || (hfmCodeL2Mapping != null && hfmCodeL2Mapping != undefined && hfmCodeL2Mapping != "")) {
                            formContext.getAttribute("niq_financereportingindustryl1").setValue(hfmCodeL1Mapping);
                            formContext.getAttribute("niq_financereportingindustryl2").setValue(hfmCodeL2Mapping);
                        }
                        else {
                            AccountRequestForm.Events.populateFinanceIndustryMappingifUltimateParentAccountIsEmpty(executionContext);
                        }
                    }
                    else {
                        AccountRequestForm.Events.populateFinanceIndustryMappingifUltimateParentAccountIsEmpty(executionContext);
                    }
                }
                catch (error) {
                    console.error("Error retrieving finance industry mappings: " + error.message);
                }
            }
            else {
                AccountRequestForm.Events.populateFinanceIndustryMappingifUltimateParentAccountIsEmpty(executionContext);
            }
        }
    },
    populateFinanceIndustryMappingifUltimateParentAccountIsEmpty: async function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_customeraccount")){
            var accountId = formContext.getAttribute("niq_customeraccount").getValue()[0].id.replace("{", "").replace("}", "");
        }
        var res = await Xrm.WebApi.retrieveMultipleRecords("account", "?$select=niq_industry&$filter=(niq_accounttype eq 1 and accountid eq " + accountId + ")");
        if (res.entities.length > 0) {
            var results = res.entities[0];
            var industry = results["niq_industry"];
        }
        try {
            var result = await Xrm.WebApi.retrieveMultipleRecords("niq_hfmcode", "?$select=niq_financeindustryl1mapping,niq_financeindustryl2mapping&$filter=niq_industry eq " + industry + " and niq_isfinancialindustrymapping eq true");
            if (result.entities.length > 0) {
                var Record = result.entities[0];
                var hfmCodeL1Mapping = Record.niq_financeindustryl1mapping;
                formContext.getAttribute("niq_financereportingindustryl1").setValue(hfmCodeL1Mapping);
                var hfmCodeL2Mapping = Record.niq_financeindustryl2mapping;
                formContext.getAttribute("niq_financereportingindustryl2").setValue(hfmCodeL2Mapping);
            }
            else {
                formContext.getAttribute("niq_financereportingindustryl1").setValue(null);
                formContext.getAttribute("niq_financereportingindustryl2").setValue(null);
            }
        }
        catch (error) {
            console.error("Error retrieving finance industry mappings: " + error.message);
        }
    },
    // US-24403
    checkDuplicateDUNS: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var eventArgs = executionContext.getEventArgs();
        var saveMode = eventArgs.getSaveMode();
        var dunsNumber = formContext.getAttribute("niq_dunsnumber").getValue();
        var accountType = formContext.getAttribute("niq_accounttype").getValue();
        var accountRequestId = formContext.data.entity.getId().replace("{", "").replace("}", "");
        var process = executionContext.getFormContext().data.process;
        var activeStage = formContext.data.process.getActiveStage();
        var currentStage = activeStage.getName().toLowerCase();
        if(currentStage == "d&b match" || currentStage == "dnb match" || currentStage == 'mdm review'){
            if (dunsNumber !== null) {
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_dunsnumber") &&
                    CommonForm.Events.CheckValueExists(formContext, "niq_dunsnumber")) {

                    // Synchronous XMLHttpRequest (deprecated)
                    var req1 = new XMLHttpRequest();
                    req1.open("GET", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/accounts?$filter=niq_dunsnumber eq '" + dunsNumber + "'", false);
                    req1.setRequestHeader("OData-MaxVersion", "4.0");
                    req1.setRequestHeader("OData-Version", "4.0");
                    req1.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req1.setRequestHeader("Accept", "application/json");
                    req1.setRequestHeader("Prefer", "odata.include-annotations=*");
                    req1.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req1.onreadystatechange = null;
                            if (this.status === 200) {
                                var results = JSON.parse(this.response);
                                console.log(results);
                                if (results.value.length > 0) {
                                    formContext.getAttribute("niq_requeststatus_db").setValue(610570011);
                                    var stageName = process.getActiveStage().getName();
                                    if (saveMode == 1 || saveMode == 2 || saveMode == 70) {
                                        eventArgs.preventDefault();
                                        
                                        formContext.ui.setFormNotification(
                                            "An account with these details already exists. Duplicate account creation is not allowed. If you wish to change the existing account details, please submit a 'Modification' request.",
                                            "ERROR",
                                            "duplicate_duns"
                                        );
                                    }
                                    
                                    var data =
                                        {
                                            "niq_requeststatus_db": 610570011,
                                            "niq_duplicatecheck":true
                                        }
                                    // update the record
                                    Xrm.WebApi.updateRecord("niq_accountrequest", accountRequestId, data).then(
                                        function success(result) {
                                            console.log("Account updated");
                                            
                                        },
                                        function (error) {
                                            console.log(error.message);
                                            
                                        }
                                    );
                                    
                                        formContext.data.process.moveNext(function (result) {
                                            if (result === "success") {
                                                console.log("BPF advanced to the next stage because the account was closed.");
                                            } else {
                                                console.error("Could not advance BPF stage.");
                                            }
                                        });
                                    AccountRequestForm.Events.filterMatchingAccountsGrid(formContext, dunsNumber, accountType);
                                    formContext.getAttribute("header_process_niq_requeststatus_mdmreview").setValue(610570007);
                                } else {
                                    formContext.ui.clearFormNotification("duplicate_duns");
                                    formContext.getAttribute("niq_requeststatus_db").setValue(610570000);
                                    if(accountType == 1){
                                        formContext.getControl("Duplicate_Accounts").setVisible(false);
                                        formContext.getAttribute("niq_duplicatecheck").setValue(false);
                                        var accountRef = formContext.getAttribute("niq_createdaccount").getValue();
                                        if (accountRef && accountRef.length > 0) {
                                            if (accountRef && accountRef.length > 0) {
                                                var accountId = accountRef[0].id.replace("{", "").replace("}", "");
                                                var entityFormOptions = {
                                                    entityName: "account",
                                                    entityId: accountId
                                                };
                                                Xrm.Navigation.openForm(entityFormOptions); 
                                            }
                                        }
                                        else{
                                            var accountData = {
                                                "name": formContext.getAttribute("niq_requestaccountname").getValue(),
                                                "niq_accounttype": 1,
                                                "niq_geography": formContext.getAttribute("niq_geography").getValue(),
                                            };
    
                                            Xrm.WebApi.createRecord("account", accountData).then(function (createResult) {
                                                var entityId = createResult.id;
                                                var entityFormOptions = {
                                                    entityName: "account",
                                                    entityId: entityId
                                                };
                                                formContext.getAttribute("niq_createdaccount").setValue([
                                                    {
                                                        id: entityId,
                                                        name: accountData.name,
                                                        entityType: "account"
                                                    }
                                                ]);
                                                formContext.getAttribute("header_process_niq_requeststatus_mdmreview").setValue(610570007);
                                                formContext.data.process.moveNext(function (result) {
                                                    if (result === "success") {
                                                        console.log("BPF advanced to the next stage because the account was closed.");
                                                    } else {
                                                        console.error("Could not advance BPF stage.");
                                                    }
                                                });
                                                Xrm.Navigation.openForm(entityFormOptions);
                                            });
                                        }                            
                                    }
                                    else{
                                        arrFields = ["niq_ultimateparentaccount", "niq_customeraccount", "header_ownerid", "niq_invoicedispatchmethod","niq_willsapaccountuseanytradebarter"]
                                        for (var i = 0; i < arrFields.length; i++) {
                                            if (CommonForm.Events.CheckFieldExists(formContext, arrFields[i])) {
                                                formContext.getAttribute(arrFields[i]).setRequiredLevel("required");
                                            }
                                        }
                                        formContext.getControl("SG_DuplicateAccounts").setVisible(false);
                                        formContext.ui.clearFormNotification("duplicate_duns");
                                        formContext.getAttribute("niq_requeststatus_db").setValue(610570000);
                                        formContext.getControl("niq_ultimateparentaccount").setDisabled(true);
                                    }
                                    
                                }
                            } else {
                                console.log(this.responseText);
                            }
                        }
                    };
                    req1.send();
                }
            }
        }             

    },

    filterMatchingAccountsGrid: function (formContext, dunsNumber, accountType) {
        var accountSubgrid =""
        if(accountType == 2){
            accountSubgrid = formContext.getControl("SG_DuplicateAccounts");
        }else if(accountType == 1){
            accountSubgrid = formContext.getControl("Duplicate_Accounts");
        }
        if (accountSubgrid) {
            var fetchXml = `
                <fetch>
                  <entity name="account">
                    <attribute name="name" />
                    <attribute name="niq_dunsnumber" />
                    <filter>
                      <condition attribute="niq_dunsnumber" operator="eq" value="${dunsNumber}" />
                    </filter>
                  </entity>
                </fetch>`;

            accountSubgrid.setFilterXml(fetchXml);
            accountSubgrid.setVisible(true);
            accountSubgrid.refresh();
        } else {
            accountSubgrid.setVisible(false);
            console.warn("Subgrid 'SG_DuplicateAccounts' not found on the form.");
        }
    },
    fblockStageNavigationOnDuplicate: function(executionContext) {
        var eventArgs = executionContext.getEventArgs();
        var formContext = executionContext.getFormContext();
        var requestStatus = formContext.getAttribute("niq_requeststatus_db").getValue();
        if(requestStatus == 610570011){
            if (eventArgs && typeof eventArgs.getDirection === "function") {
                var direction = eventArgs.getDirection();
                if (direction && direction.toLowerCase() === "next") {
                    var activeStage = formContext.data.process.getActiveStage();
                    if (activeStage && activeStage.getName().toLowerCase() === "d&b match") {
                        eventArgs.preventDefault();
                        var alertStrings = {
                            confirmButtonLabel: "OK",
                            text: "Moving to Next stage is not allowed.",
                            title: "Duplicate Account(s) found."
                        };
                        var alertOptions = { height: 120, width: 260 };
                        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                    }
                }
            }
        }
    },
    lockRequestStatusMDMUntilMDMReview: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var activeStage = formContext.data.process.getActiveStage();
        var currentStage = activeStage.getName().toLowerCase();
        if(currentStage == "mdm review"){
            formContext.getControl("niq_requeststatus_mdmreview").setDisabled(false);
            formContext.getAttribute("niq_requeststatus_mdmreview").setRequiredLevel("required");
        }
        else{
            formContext.getControl("niq_requeststatus_mdmreview").setDisabled(true);
            formContext.getAttribute("niq_requeststatus_mdmreview").setRequiredLevel("none");
        }
    },

    //24985 - Function to check for duplicate accounts based on SAP Legal Name, VAT/ABN, and address fields

    checkForDuplicateAccount: function (executionContext) {

        var formContext = executionContext.getFormContext();

        // Gather values from form
        var sapLegalName = formContext.getAttribute("niq_sapaccountname")?.getValue(); // Assuming 'name' is SAP Legal Name
        var vatNumber = formContext.getAttribute("niq_vatabncompanyregistrationnumber")?.getValue(); // Assuming 'vatnumber' field for VAT/ABN
        var city = formContext.getAttribute("niq_city")?.getValue();
        var postalCode = formContext.getAttribute("niq_zipcode")?.getValue();
        var street = formContext.getAttribute("niq_street")?.getValue();
        var state = formContext.getAttribute("niq_state")?.getValue();
        var country = formContext.getAttribute("niq_country")?.getValue();

        var saveMode = executionContext.getEventArgs().getSaveMode();
        var eventArgs = executionContext.getEventArgs();
        var formType = formContext.ui.getFormType();
        var requestType = formContext.getAttribute("niq_requesttype")?.getValue();


        var stateId = "";
        var stateName = ""
        var countryId = "";
        var countryName = ""
        if (state != null && country != null) {
            stateId = state[0].id.replace("{", "").replace("}", "");
            stateName = state[0].name;
            countryId = country[0].id.replace("{", "").replace("}", "");
            countryName = country[0].name;
        }

        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/accounts?$select=niq_sapaccountname&$filter=(niq_sapaccountname eq '" + sapLegalName + "' or (address1_city eq '" + city + "' and address1_line1 eq '" + street + "' and address1_postalcode eq '" + postalCode + "' and niq_vatabncompanyregistrationnumber eq '" + vatNumber + "'))", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Prefer", "odata.include-annotations=*");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    console.log(results);
                    if (results.value.length > 0) {
                        if (formType !== 2 && requestType === 610570000) {
                            if (saveMode == 1 || saveMode == 2 || saveMode == 70) {
                                console.log("Response received 5");
                                eventArgs.preventDefault();
                                console.log("prevent save");
                                var alertStrings = { confirmButtonLabel: "Ok", text: "An account with these details already exists. Duplicate account creation is not allowed. If you wish to change the account details, please submit a 'Modification' request." };
                                var alertOptions = { height: 240, width: 260 };
                                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);

                                formContext.ui.setFormNotification(
                                    "An account with these details already exists. Duplicate account creation is not allowed. If you wish to change the existing account details, please submit a 'Modification' request.",
                                    "ERROR",
                                    "duplicate_accounts"
                                );
                            }

                            AccountRequestForm.Events.ShowDuplicateAccountsGrid(formContext, sapLegalName, city, street, vatNumber, postalCode);
                        }
                    }
                } else {
                    console.log("Not Found");
                    formContext.ui.clearFormNotification("duplicate_accounts");
                    formContext.getControl("SG_DuplicateAccounts").setVisible(false);
                    console.log(this.responseText);
                }
            }
        };
        req.send();


    },
    ShowDuplicateAccountsGrid: function (formContext, sapLegalName, city, street, vatNumber, postalCode) {
        var accountSubgrid = formContext.getControl("SG_DuplicateAccounts");
        if (accountSubgrid) {
            var fetchXml = `
                <fetch>
	<!-- Table -->
	<entity name="account">
		<!-- Columns -->
		<attribute name="accountid" />
		<attribute name="address1_city" />
		<attribute name="niq_countryid" />
		<attribute name="niq_countryidname" />
		<attribute name="niq_sapaccountname" />
		<attribute name="niq_stateprovince" />
		<attribute name="niq_stateprovincename" />
		<attribute name="address1_line1" />
		<attribute name="niq_vatabncompanyregistrationnumber" />
		<attribute name="address1_postalcode" />
		<!-- Filter By -->
        <filter type="or">
			<condition attribute="niq_sapaccountname" operator="eq" value="${sapLegalName}" />
			<filter type="and">
				<condition attribute="address1_city" operator="eq" value="${city}" />
				<condition attribute="address1_line1" operator="eq" value="${street}" />
				<condition attribute="niq_vatabncompanyregistrationnumber" operator="eq" value="${vatNumber}" />
				<condition attribute="address2_postalcode" operator="eq" value="${postalCode}" />
			</filter>
		</filter>
	</entity>
</fetch>`;

            accountSubgrid.setFilterXml(fetchXml);
            accountSubgrid.setVisible(true);
            accountSubgrid.refresh();
        } else {
            accountSubgrid.setVisible(false);
            console.warn("Subgrid 'SG_DuplicateAccounts' not found on the form.");
        }
    },
    onSaveModify: function (executionContext) {

        var formContext = executionContext.getFormContext();;
        var requestType = formContext.getAttribute("niq_requesttype")?.getValue();
        var dunsNumber = formContext.getAttribute("niq_dunsnumber")?.getValue();

        // Get the current active stage
        var activeStage = formContext.data.process.getActiveStage();
        var activeStageName = activeStage ? activeStage.getName() : "";

        // Only continue if the current stage is "New"
        if (activeStageName === "New" && requestType === 610570001 && dunsNumber && dunsNumber.trim() !== "") {
            var processFlowId = formContext.data.process.getInstanceId();

            // Get the current process id
            var processId = formContext.data.process.getActiveProcess().getId();

            // Query for the "Closed" stage in this process
            Xrm.WebApi.retrieveMultipleRecords(
                "processstage",
                `?$select=processstageid,stagename&$filter=stagename eq 'MDM Review' and _processid_value eq ${processId}`
            ).then(function (result) {
                if (result.entities.length > 0) {
                    var closedStageId = result.entities[0].processstageid;

                    var record = {};
                    record["activestageid@odata.bind"] = "/processstages(" + closedStageId + ")";

                    Xrm.WebApi.updateRecord("niq_accountrequestprocessflow", processFlowId, record).then(
                        function success(result) {

                            formContext.getAttribute("niq_requeststatus").setValue(610570014);
                            formContext.data.save().then(function () {
                                // Now refresh the form without a popup
                                formContext.data.refresh(false);
                            });
                        },
                        function (error) {

                        }
                    );


                } else {

                }
            },
                function (error) {

                });
        }
    },
    //MDM Team User Filter on owner inSAP Account Request form
   filterOwnerUser: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        // Replace with your actual MDM Team GUID
        var results = await Xrm.WebApi.retrieveMultipleRecords("team", "?$select=teamid,name&$filter=name eq 'MDM Reviewers'");
        if (results.entities.length > 0) {
            var result = results.entities[0];
            var mdmTeamId = result["teamid"];
            // Filter to show only users who are members of the MDM team
            var fetchXmlFilter = `
            <filter type="and">
            <condition attribute="systemuserid" operator="in">
            <fetch mapping="logical">
            <entity name="teammembership">
            <attribute name="systemuserid" />
            <filter type="and">
            <condition attribute="teamid" operator="eq" value="`+mdmTeamId+`" />
            </filter>
            </entity>
            </fetch>
            </condition>
            </filter>
            `;
            formContext.getControl("header_ownerid").addCustomFilter(fetchXmlFilter, "systemuser");
        }
    },

  //DYNCRM-21779 locking the form for compliance review stage and status compliance on hold as part of Dow Jones Request
    LockFormComplianceReview: function(executionContext)
    {
        var formContext = executionContext.getFormContext();
        var requestType = formContext.getAttribute("niq_requesttype")?.getValue();
        var requestStatus = formContext.getAttribute("niq_requeststatus")?.getValue();
        var currentStage = formContext.data.process.getActiveStage();
        var currentStageName = currentStage.getName().toLowerCase();
        if(requestType == 610570000 || requestType == 610570008 || requestType == 610570009)
        {
            if(currentStageName == "compliance review" && requestStatus == 610570005)
            {
                if(CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User,NIQ Finance User,NIQ Add-On Finance Gatekeeper,NIQ Add On Sales Ops Approver"))
                {
                let formControls = formContext.ui.controls;
                formControls.forEach(control => {
                if (control.getName() != "" && control.getName() != null) 
                {
                    control.setDisabled(true);
                }
                });
            }

            }
        }

    },

    //DYNCRM-21779 blocking BPF stage from compliance review to mdm review if screening result is decline or null
    BlockingBPFStageComplianceReview: function(executionContext) 
    {
    var formContext = executionContext.getFormContext();
    let bpfArgs = executionContext.getEventArgs();
    let direction = bpfArgs.getDirection().toLowerCase();
    var screeningResult = formContext.getAttribute("niq_screeningresult")?.getValue();
    var activeStage = formContext.data.process.getActiveStage();
    var currentStage = activeStage.getName().toLowerCase();
    var stages = formContext.data.process.getActivePath();
    if(direction == "next")
    {
            if(currentStage == "compliance review" && !(CommonForm.Events.CheckIfLoggedInUserRole("System Administrator")))
            {
                if(screeningResult == null || screeningResult == "undefined")
                {
                    bpfArgs.preventDefault();
                    var alertStrings = {
                    confirmButtonLabel: "OK",
                    text: "Moving to Next stage is not allowed.",
                    title: "Stage Navigation Blocked"
                    };
                    var alertOptions = { height: 120, width: 260 };
                    Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                    }
                }

            }
            
        
    },

    //24401
    OnLoadOfCountryDetails: async function(executionContext)
    {
        var formContext = executionContext.getFormContext();
        var Country = formContext.getAttribute("niq_country")?.getValue()[0].id;
        if(Country != null || Country != "undefined")
        {   
            var CountryId = Country.replace("{","").replace("}","");
            var CountryDetails = await Xrm.WebApi.retrieveRecord("niq_country",CountryId,"?$select=niq_name,niq_isvatrequired");
            var IsVATRequired = CountryDetails["niq_isvatrequired"];
            if(IsVATRequired == 0)
            {
                var VatRequired = formContext.getAttribute("niq_vatabncompanyregistrationnumber").setRequiredLevel("required");
                formContext.getAttribute("niq_country").setRequiredLevel("none");
                var city = formContext.getAttribute("niq_city").setRequiredLevel("none");
                var zipcode = formContext.getAttribute("niq_zipcode").setRequiredLevel("none");
                var stateProvince = formContext.getAttribute("niq_stateprovince").setRequiredLevel("none");
                var street1 = formContext.getAttribute("niq_street1").setRequiredLevel("none");
                var street2 = formContext.getAttribute("niq_street2").setRequiredLevel("none");
                var street3 = formContext.getAttribute("niq_street3").setRequiredLevel("none");
                var street4 = formContext.getAttribute("niq_street").setRequiredLevel("none");

            }
            else if(IsVATRequired == 1)
            {
                var VatRequired = formContext.getAttribute("niq_vatabncompanyregistrationnumber").setRequiredLevel("none");
                formContext.getAttribute("niq_country").setRequiredLevel("required");
                var city = formContext.getAttribute("niq_city").setRequiredLevel("required");
                var zipcode = formContext.getAttribute("niq_zipcode").setRequiredLevel("required");
                var stateProvince = formContext.getAttribute("niq_stateprovince").setRequiredLevel("required");
                var street1 = formContext.getAttribute("niq_street1").setRequiredLevel("required");
                var street2 = formContext.getAttribute("niq_street2").setRequiredLevel("required");
                var street3 = formContext.getAttribute("niq_street3").setRequiredLevel("required");
                var street4 = formContext.getAttribute("niq_street").setRequiredLevel("required");

            }


        }
    },

    //DYNCRM-24405 Child 2 : Create SAP account request - account modification
    OnLoad_LockApplyForAllIfChecked: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_applyforallforuionly")) {
            var isApplyForAllChecked = formContext.getAttribute("niq_applyforallforuionly").getValue();
            //Disable if the record is being created or the record is being updated and the check box was checked previously
            if (isApplyForAllChecked || (formType == 1)) formContext.getControl("niq_applyforallforuionly").setDisabled(true);
        }
    },

    OnChangeRequestStatusMDMReview: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_requeststatus_mdmreview")) {
            var requestStatusMDMReview = formContext.getAttribute("niq_requeststatus_mdmreview").getValue();
            formContext.getAttribute("niq_requeststatus").setValue(requestStatusMDMReview);
        }
    },

    ChangeBPFStageIfDunsHasValue: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        var requestType = formContext.getAttribute("niq_requesttype")?.getValue();
        var activeStage = formContext.data.process.getActiveStage();
        var currentStage = activeStage.getName().toLowerCase();
        if(currentStage == "new"){
            if (formType !== 1 && requestType === 610570009) {
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_dunsnumber")) {
                    var dunsNumber = formContext.getAttribute("niq_dunsnumber")?.getValue();
        
                    if (dunsNumber && dunsNumber !== "undefined") {
                        formContext.getAttribute("niq_requeststatus_mdmreview").setValue(610570007);
                        formContext.data.process.moveNext(function (result) {
                            if (result === "success") {
                                console.log("BPF advanced to the next stage because the account was closed.");
                            } else {
                                console.error("Could not advance BPF stage.");
                            }
                        });
                    }
                }
            }
        }
    },     
    makeMDMCommentsRequiredWhenRejectedByMDM: function(executionContext){
        var formContext = executionContext.getFormContext();
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        var activeStage = formContext.data.process.getActiveStage();
        var currentStage = activeStage.getName().toLowerCase();
        var mdmcomments = formContext.getControl("niq_mdmclosingcomments");
        if(currentStage == "mdm review" && CommonForm.Events.CheckValueExists(formContext, "niq_requeststatus") && CommonForm.Events.CheckFieldExists(formContext, "niq_requeststatus") && mdmcomments){
            var reqstatus = formContext.getAttribute("niq_requeststatus").getValue();
            if (requestType == 610570009 && reqstatus == 610570009) {
                formContext.getControl("niq_mdmclosingcomments").setVisible(true);
                formContext.getAttribute("niq_mdmclosingcomments").setRequiredLevel("required");
            }
            else{
                formContext.getControl("niq_mdmclosingcomments").setVisible(false);
                formContext.getAttribute("niq_mdmclosingcomments").setRequiredLevel("none");
            }
        }
    },

    filterOwnerUserOnMDM: function(executionContext){
        var formContext = executionContext.getFormContext();
        var lookupControl = formContext.getControl("ownerid");
        var viewGuid = "{8a1b3b88-df63-f011-bec2-6045bd9e6513}";
        var activeStage = formContext.data.process.getActiveStage();
        var currentStage = activeStage.getName().toLowerCase();
        if(currentStage == "mdm review"){
            if (lookupControl) {
                lookupControl.setDefaultView(viewGuid);
            }
        }  
    },

    //DYNCRM-25137 Visibility & Validation Rules for 'Seller', 'MDM Team and Compliance Team' on SAP Account Creation & Modification forms
    OnLoadFieldVisibilityForSellers: function(executionContext){
        var formContext = executionContext.getFormContext();
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        var arrFields =[]
        var mdmstatus = formContext.getAttribute("niq_requeststatus_mdmreview").getValue();
        if(mdmstatus != 610570008){
            if(requestType == 610570000 || requestType == 610570001){
                if(requestType == 610570000){
                    arrFields = ["niq_city", "niq_country", "niq_customeraccount", "niq_customernumber", "niq_dunsnumber", "niq_housenumber", "niq_industrycode", "niq_isthisagovernmentaccount", "niq_language", "niq_sapaccountname", "niq_relatedopportunity",
                        "header_ownerid", "niq_porequired", "niq_zipcode", "niq_state", "niq_requeststatus", "niq_requesttype", "niq_requestorname", "niq_requestorscomment", "niq_accountrequestnumber", "niq_street", "niq_willsapaccountuseanytradebarter",
                        "niq_telnumber", "niq_ultimateparentaccount", "niq_vatabncompanyregistrationnumber"];
                }
                else if(requestType == 610570001){
                    arrFields = ["niq_city", "niq_country", "niq_customeraccount", "niq_customernumber", "niq_dunsnumber", "niq_housenumber", "niq_industrycode", "niq_invoicedispatchmethod", "niq_isthisagovernmentaccount", "niq_language", "niq_sapaccountname",
                        "niq_relatedopportunity", "header_ownerid", "niq_porequired", "niq_zipcode", "niq_requeststatus", "niq_requesttype", "niq_requestorname", "niq_requestorscomment", "niq_accountrequestnumber", "niq_street", "niq_willsapaccountuseanytradebarter",
                        "niq_telnumber", "niq_ultimateparentaccount", "niq_vatabncompanyregistrationnumber"]                
                }
                try {
                    if (CommonForm.Events.CheckIfLoggedInUserRole("NIQ Sales User")) {
                        let formControls = formContext.ui.controls;
                        formControls.forEach(control => {
                            if (control.getName() != "" && control.getName() != null) {
                                control.setDisabled(true);
                            }
                        });
                        for (var i = 0; i < arrFields.length; i++) {
                            if (CommonForm.Events.CheckFieldExists(formContext, arrFields[i])) {
                                formContext.getControl(arrFields[i]).setDisabled(false);
                            }
                        }
                    }
                    
                }
                catch (exception) {
                    console.log("Error : " + exception);
                }
            }
        }
    },

    OnLoadFieldVisibilityForMDMTeam: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        var arrFields =[]
        var mdmstatus = formContext.getAttribute("niq_requeststatus_mdmreview").getValue();
        if(mdmstatus != 610570008){
            if(requestType == 610570000 || requestType == 610570001){
                try {
                    var userId = Xrm.Utility.getGlobalContext().userSettings.userId;
                    var teamid = "047aaf19-7bce-ef11-b8e8-7c1e524e097b";//MDM Team ID
                    var isMDMTeamMember = false;
                    var query = "?$filter=systemuserid eq " + userId + " and teamid eq " + teamid;
                    var response = await Xrm.WebApi.retrieveMultipleRecords("teammembership", query);
                    if (response.entities.length > 0) {
                        isMDMTeamMember = true;
                    }

                    var complianceTeamId ="ec841307-7bce-ef11-b8e8-7c1e524e097b"; //Compliance Team ID
                    var isComplianceTeamMember = false;
                    var compliancequery = "?$filter=systemuserid eq " + userId + " and teamid eq " + complianceTeamId
                    var complianceResponse = await Xrm.WebApi.retrieveMultipleRecords("teammembership", compliancequery);
                    if (complianceResponse.entities.length > 0) {
                        isComplianceTeamMember = true;
                    }

                    if(requestType == 610570000){
                        arrFields = ["niq_bankaccountno", "niq_bankcontrolkey", "niq_bankcountrykey", "niq_banknumber", "niq_banktype", "niq_city", "niq_communicationmethod", "niq_country", "niq_customeraccount", "niq_customernumber", "niq_dunsnumber",
                            "niq_email", "niq_hfmclientcodeid", "niq_housenumber", "niq_industrycode", "niq_industrysector", "niq_isthisagovernmentaccount", "niq_language", "niq_mdmclosingcomments", "niq_sapaccountname", "niq_relatedopportunity",
                            "header_ownerid", "niq_legalsapaccountgroup", "niq_legalsapaccountgrouptype", "niq_legalsapaccounttype", "niq_porequired", "niq_zipcode", "niq_previousaccountnumber", "niq_requeststatus", "niq_requesttype", "niq_requestorname",
                            "niq_requestorscomment", "niq_accountrequestnumber", "niq_screeningresult", "niq_searchterm", "niq_street", "niq_willsapaccountuseanytradebarter", "niq_taxnumber1", "niq_taxnumber2", "niq_taxnumber3", "niq_taxnumber4", "niq_taxnumber5",
                            "niq_taxtype1", "niq_taxtype2", "niq_taxtype3", "niq_taxtype4", "niq_taxtype5", "niq_telnumber", "niq_ultimateparentaccount", "niq_vatregistrationnumber"];
                    }
                    else if(requestType == 610570001){
                        arrFields = ["niq_assignedmdmreviewer", "niq_bankaccountno", "niq_bankcontrolkey", "niq_bankcountrykey", "niq_banknumber", "niq_banktype", "niq_city", "niq_communicationmethod", "niq_country", "niq_customeraccount", "niq_customernumber",
                            "niq_dunsnumber", "niq_email", "niq_hfmclientcodeid", "niq_housenumber", "niq_industrycode", "niq_industrysector", "niq_isthisagovernmentaccount", "niq_language", "niq_mdmclosingcomments", "niq_sapaccountname", "niq_relatedopportunity",
                            "header_ownerid", "niq_legalsapaccountgroup", "niq_legalsapaccountgrouptype", "niq_legalsapaccounttype", "niq_porequired", "niq_zipcode", "niq_previousaccountnumber", "niq_requeststatus", "niq_requesttype", "niq_requestorname", "niq_requestorscomment",
                            "niq_accountrequestnumber", "niq_screeningresult", "niq_searchterm", "niq_street", "niq_willsapaccountuseanytradebarter", "niq_taxnumber1", "niq_taxnumber2", "niq_taxnumber3", "niq_taxnumber4", "niq_taxnumber5", "niq_taxtype1", "niq_taxtype2", "niq_taxtype3",
                            "niq_taxtype4", "niq_taxtype5", "niq_telnumber", "niq_ultimateparentaccount","niq_vattype", "niq_vatregistrationnumber"];
                    }

                    if (isMDMTeamMember || isComplianceTeamMember) {
                        let formControls = formContext.ui.controls;
                        formControls.forEach(control => {
                            if (control.getName() != "" && control.getName() != null) {
                                control.setDisabled(true);
                            }
                        });
                        for (var i = 0; i < arrFields.length; i++) {
                            if (CommonForm.Events.CheckFieldExists(formContext, arrFields[i])) {
                                formContext.getControl(arrFields[i]).setDisabled(false);
                            }
                        }
                    }
                }
                catch (exception) {
                    console.log("Error : " + exception);
                }
            }
        }
    },

    OnLoadFieldVisibilityForSellersOnApprovedRequest: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        var arrFields =[]
        var mdmstatus = formContext.getAttribute("niq_requeststatus_mdmreview").getValue();
        if(mdmstatus == 610570008){
            if(requestType == 610570000 || requestType == 610570001){
                arrFields = ["niq_accountingclerk", "niq_accountassigngroup", "niq_arpledging", "niq_customergroup1", "niq_customergroup2", "niq_customergroup3", "niq_customergroup4", "niq_customergroup5",
                    "niq_customerorderblock", "niq_deliveringplant", "niq_distributionchannel", "niq_district", "niq_division", "niq_housebank","niq_lockboxkey", "niq_periodicacctstatements", "niq_previousnumber",
                    "niq_salesoffice", "niq_withholdingtaxagent", "niq_withholdingtaxcode", "niq_withholdingtaxtype", "niq_withholdtaxvalidfrom", "niq_withholdtaxvalidto"];
                try {
                    
                    if (CommonForm.Events.CheckIfLoggedInUserRole("NIQ Sales User")) {
                        let formControls = formContext.ui.controls;
                        formControls.forEach(control => {
                            if (control.getName() != "" && control.getName() != null) {
                                control.setDisabled(true);
                            }
                        });
                        for (var i = 0; i < arrFields.length; i++) {
                            if (CommonForm.Events.CheckFieldExists(formContext, arrFields[i])) {
                                formContext.getControl(arrFields[i]).setVisible(false);
                            }
                        }
                    }
                    
                }
                catch (exception) {
                    console.log("Error : " + exception);
                }
            }
        }
    },

    OnLoadFieldVisibilityForMDMOnApprovedRequest: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        var arrFields =[]
        var mdmstatus = formContext.getAttribute("niq_requeststatus_mdmreview").getValue();
        if(mdmstatus == 610570008){
            if(requestType == 610570000 || requestType == 610570001){
                arrFields = ["niq_countrykey", "niq_iban", "niq_industrysector", "niq_relatedopportunity", "header_ownerid", "niq_recordpaymenthistory", "niq_taxjurcode"];
                try {

                    var userId = Xrm.Utility.getGlobalContext().userSettings.userId;
                    var teamid = "047aaf19-7bce-ef11-b8e8-7c1e524e097b";//MDM Team ID
                    var isMDMTeamMember = false;
                    var query = "?$filter=systemuserid eq " + userId + " and teamid eq " + teamid;
                    var response = await Xrm.WebApi.retrieveMultipleRecords("teammembership", query);
                    if (response.entities.length > 0) {
                        isMDMTeamMember = true;
                    }
                    if (isMDMTeamMember) {
                        let formControls = formContext.ui.controls;
                        formControls.forEach(control => {
                            if (control.getName() != "" && control.getName() != null) {
                                control.setDisabled(true);
                            }
                        });
                        for (var i = 0; i < arrFields.length; i++) {
                            if (CommonForm.Events.CheckFieldExists(formContext, arrFields[i])) {
                                formContext.getControl(arrFields[i]).setVisible(false);
                            }
                        }
                    }
                    
                }
                catch (exception) {
                    console.log("Error : " + exception);
                }
            }
        }
    },

    OnLoadFieldVisibilityForComplianceOnApprovedRequest: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var requestType = formContext.getAttribute("niq_requesttype").getValue();
        var arrFields =[]
        var mdmstatus = formContext.getAttribute("niq_requeststatus_mdmreview").getValue();
        if(mdmstatus == 610570008){
            if(requestType == 610570000 || requestType == 610570001){
                arrFields = ["niq_countrykey", "niq_iban", "niq_industrysector", "niq_relatedopportunity", "header_ownerid", "niq_recordpaymenthistory", "niq_taxjurcode"];
                try {
                    var userId = Xrm.Utility.getGlobalContext().userSettings.userId;
                    var complianceTeamId ="ec841307-7bce-ef11-b8e8-7c1e524e097b"; //Compliance Team ID
                    var isComplianceTeamMember = false;
                    var compliancequery = "?$filter=systemuserid eq " + userId + " and teamid eq " + complianceTeamId;
                    var complianceResponse = await Xrm.WebApi.retrieveMultipleRecords("teammembership", compliancequery);
                    if (complianceResponse.entities.length > 0) {
                        isComplianceTeamMember = true;
                    }
                    if (isComplianceTeamMember) {
                        let formControls = formContext.ui.controls;
                        formControls.forEach(control => {
                            if (control.getName() != "" && control.getName() != null) {
                                control.setDisabled(true);
                            }
                        });
                        for (var i = 0; i < arrFields.length; i++) {
                            if (CommonForm.Events.CheckFieldExists(formContext, arrFields[i])) {
                                formContext.getControl(arrFields[i]).setVisible(false);
                            }
                        }
                    }
                    
                }
                catch (exception) {
                    console.log("Error : " + exception);
                }
            }
        }
    },

    //DYNCRM-24673
    PostDuplicateCheckCustomerAccountBPF: async function(executionContext)
    {
        var formContext = executionContext.getFormContext();
        var currentStage = formContext.data.process.getActiveStage();
        var currentStageName = currentStage.getName().toLowerCase();
        var processId = formContext.data.process.getActiveProcess().getId();
        if((currentStageName == "dnb match" || currentStageName == "mdm review"))
        {
            var processFlowId = formContext.data.process.getInstanceId();
            var AccountId = formContext.getAttribute("niq_createdaccount")?.getValue();
            var createdAccount = AccountId[0].id;
            var Account = await Xrm.WebApi.retrieveRecord("account",createdAccount,"?$select=niq_compliancefinancialstatus");
            var complianceStatus = Account["niq_compliancefinancialstatus"];
            if(complianceStatus == 610570006)
            {
                var result = await Xrm.WebApi.retrieveMultipleRecords(
                        "processstage",
                        `?$select=processstageid,stagename&$filter=stagename eq 'Compliance Review' and _processid_value eq ${processId}`
                    );
                    var complianceReview = result.entities[1].processstageid;
                    var record = {};
                    record["activestageid@odata.bind"] = "/processstages(" + complianceReview + ")";
                    var recordUpdate = Xrm.WebApi.updateRecord("niq_accountrequestprocessflow", processFlowId, record);
                    var requestStatus = formContext.getAttribute("niq_requeststatus")?.setValue(610570005);
                
            }
        }
    }
    
}