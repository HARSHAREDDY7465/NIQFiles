var previousSelectedId = null;

function filterStatesSubgrid(executionContext) {
    var formContext = executionContext.getFormContext();
    setInterval(function () {
        var subgrid = formContext.getControl("Subgrid_new_1"); 
        var statesSubgrid = formContext.getControl("Subgrid_new_2"); 

        if (subgrid && subgrid.getGrid().getSelectedRows().getLength() == 1) {
            var selectedRow = subgrid.getGrid().getSelectedRows().get(0);
            var entityName = selectedRow.getData().getEntity().getEntityName();
            var selectedId = selectedRow.getData().getEntity().getId();
            statesSubgrid.setVisible(true);

            if (entityName === "mash_country") { 
                if (selectedId !== previousSelectedId) {
                    previousSelectedId = selectedId;
                    filterStates(formContext, selectedId);
                }
            } else {
                previousSelectedId = null;
                clearStatesSubgrid(statesSubgrid);
            }
        } else {
            
            previousSelectedId = null;
            clearStatesSubgrid(statesSubgrid);
        }
    }, 2000); 
}

function filterStates(formContext, countryId) {
    var statesSubgrid = formContext.getControl("Subgrid_new_2"); 
    statesSubgrid.setVisible(true);
    var fetchXml = `
        <fetch>
          <entity name='mash_state'> <!-- Replace with actual logical name -->
            <filter>
              <condition attribute='mash_country' operator='eq' value='${countryId}' />
            </filter>
          </entity>
        </fetch>`;
    statesSubgrid.setFilterXml(fetchXml);
    statesSubgrid.refresh();
    
}

function clearStatesSubgrid(statesSubgrid) {
    var emptyFetchXml = `
        <fetch>
          <entity name='mash_state'>
            <filter>
              <condition attribute='mash_stateid' operator='eq' value='00000000-0000-0000-0000-000000000000' />
            </filter>
          </entity>
        </fetch>`;
    statesSubgrid.setFilterXml(emptyFetchXml);
    statesSubgrid.refresh();
    statesSubgrid.setVisible(false);
}
