if (typeof (HFMForm) === "undefined") {
    HFMForm = {
        __namespace: true
    };
}

HFMForm.Events = {
    FormOnload: function (executionContext) {
        var formContext = executionContext.getFormContext();
        this.checkFinancialIndustry(executionContext);
        formContext.getAttribute("niq_isfinancialindustrymapping") ? formContext.getAttribute("niq_isfinancialindustrymapping").addOnChange(this.checkFinancialIndustry) : null;
    },
    checkFinancialIndustry: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (formContext.getAttribute("niq_isfinancialindustrymapping").getValue() == true) {
            formContext.getControl("niq_financeindustryl1mapping").setVisible(true);
            formContext.getControl("niq_financeindustryl2mapping").setVisible(true);
            formContext.getControl("niq_hfmid").setVisible(false);
        } else {
            formContext.getControl("niq_hfmid").setVisible(true);
            formContext.getControl("niq_financeindustryl1mapping").setVisible(false);
            formContext.getControl("niq_financeindustryl2mapping").setVisible(false);
        }
    }
}