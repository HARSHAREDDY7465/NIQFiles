if (typeof (OpportunityForm) === "undefined") {
    OpportunityForm = {
        __namespace: true
    };
}

OpportunityForm.Events = {

    FormOnload: async function (executionContext) {

        "use strict";
        this.ShowDeliveryNotification(executionContext);
        var formContext = executionContext.getFormContext(); // getting FormCOntext
        // Call the function to trigger the recalculation
        this.recalculateRollupField(executionContext);
        this.InvoiceInfoVerifiedFieldReadOnly(executionContext); //making Invoice info verified field read only
        this.CustomViewCommon(formContext, "niq_soldtoparty"); // Adding Custom Views for Sold To Party Views       
        this.CustomViewInvoiceReceipient(executionContext);
        this.CustomViewAccountGoals(formContext, "niq_accountgoalid");
        //this.PopulateDefaultFieldsFromDefaultSettings(executionContext);
        this.OnChangeContractAction(executionContext);
        this.OnChangeOpportunityTypeAndContractAction(executionContext);
        formContext.data.process.addOnStageChange(this.OnBpfStageChange);
        formContext.data.process.addOnPreStageChange(this.showErrorforRevenueSchedules);
        formContext.data.process.addOnPreStageChange(this.dealScoreStageRstrict);
        formContext.data.process.addOnPreStageChange(this.LocalcontributorStageRestrict);
        formContext.data.process.addOnPreStageChange(this.TothrowerrorforAgreementtype);
        formContext.data.process.addOnPreStageChange(this.TothrowerrorforHostOpportunity);
        formContext.data.process.addOnPreStageChange(this.validateScheduleDateWithinQuoteDates);
        formContext.data.process.addOnPreStageChange(this.BlockNegotiationStageDraftStatus);

        formContext.data.process.addOnPreStageChange(this.checkRevenueActionTaken);
        formContext.data.process.addOnPreStageChange(this.autopopulatePartiesSync);
        this.OnChangeOfStage(executionContext);
        // this.ExistingContractAnnualValueVisibility(executionContext);
        this.HideandShowOppoProductEnhancementTab(executionContext);
        this.OnChangeOfApprovalStatusShowNotification(executionContext);
        await this.SalesOrgSalesGroupRequired(executionContext);
        await this.TempOrFinallyExecutedURLValidation(executionContext);
        this.SetURLCheckboxNegotiationStage(executionContext);
        this.OnCreateofOpportunity(executionContext);
        this.ShowHideIsCanceledCancelationReason(executionContext);
        this.setDefaultAMView(executionContext);
        this.displayMessageBlockedQuoteProduct(executionContext);
        //this.checkActiveOPEsforOpportunity(executionContext);
        this.showNotificationforRevenueSchedules(executionContext);
        this.showNotificationforBillingSchedules(executionContext);
        this.ShowHideCompetitor1Field(executionContext);
        await this.checkforActiveOPERecords(executionContext);
        this.ShowhideProjectDetailSection(executionContext);
        this.PopulateEstCloseDateFromDefaultSettings(executionContext);
        this.ShowSectionsBasedOnPartyValues(executionContext);
        this.setVisibilityRevenueShareDealField(executionContext);
        this.Showhidecomepetitorstab(executionContext);
        this.ShowHideClosureSection(executionContext);
        this.LockForecastingdatapresenseOnBPF(executionContext);
        this.lockFieldsforABO(executionContext);
        this.PopulateClientAccountInMSAOpportunity(executionContext);
        this.ReadOnlyFields(executionContext);
        this.MakeFieldMandatory(executionContext);
        this.ToggleSubgridsByHostAndRevStatus(executionContext);
        formContext.getAttribute("niq_shouldclientbeinvoicedforthisopportunity").addOnChange(OpportunityForm.Events.MakeFieldMandatory);
        this.MakeEditableField(executionContext);
        formContext.getAttribute("niq_closeprobability").addOnChange(OpportunityForm.Events.MakeEditableField);
        this.SetNameOnInvoice(executionContext);
        formContext.getAttribute("niq_nameoninvoiceifdifffrominvoicerecipient").addOnChange(OpportunityForm.Events.SetNameOnInvoice);
        var formType = formContext.ui.getFormType();
        this.displayWarningonRenewalOpportunityWithCustomSchedule(executionContext);
        if (await CommonForm.Events.ShowNIQGFKAugRelease()) {

            formContext.data.process.addOnPreStageChange(this.validateCustomerAccountRequestsPendingOnAccountRequest);
            //commented for unblocking - 22194 epic
            formContext.data.process.addOnPreStageChange(this.checkAccountComplianceOnbpfChange);

            //commented for unblocking - 22194 epic
            this.checkAccountCompliance(executionContext);
            this.checkDataAvailabilityAndCompliance(formContext);
            this.HideInvoiceDispatchMethodField(executionContext);
            this.populateInvoiceRecepientAccountsPayable(executionContext);
            this.OnLoadFormPORequiredToMandatory(executionContext);
            formContext.getAttribute("niq_billtoparty").addOnChange(OpportunityForm.Events.OnChange_BilltoParty);
            this.OnChange_BilltoParty(executionContext);

            //commented for unblocking - 22194 epic
            formContext.getAttribute("niq_existingcontractaction").addOnChange(OpportunityForm.Events.checkAccountCompliance);
            formContext.getAttribute("niq_iscanceled").addOnChange(OpportunityForm.Events.checkAccountCompliance);

            formContext.getAttribute("niq_shouldclientbeinvoicedforthisopportunity").addOnChange(OpportunityForm.Events.HideInvoiceDispatchMethodField);

            if (formType !== 1 && formType !== 4) {
                this.RetrieveChildOpportunitiesForValidation(executionContext);
            }
        }

        if (formContext.getControl("quote") !== null)
            formContext.getControl("quote").setDisabled(true);

        if (formType !== 1 && formType !== 4) {

            this.setMainQuoteFilter(executionContext);
            if (CommonForm.Events.CheckValueExists(formContext, "niq_approvalstatus")) {
                var approvalStatus = formContext.getAttribute("niq_approvalstatus").getValue();
                var sapStatus = CommonForm.Events.CheckValueExists(formContext, "niq_sapintegrationstatus") ? formContext.getAttribute("niq_sapintegrationstatus").getValue() : 1;
                var stage = CommonForm.Events.CheckValueExists(formContext, "niq_stage") ? formContext.getAttribute("niq_stage").getValue() : "";
                if (approvalStatus === 100000000 || approvalStatus === 100000001 || (approvalStatus === 100000002 && sapStatus != 100000000 && stage === "Closed Won - In Review")) {
                    CommonForm.Events.disableFormFields(true, formContext);
                    this.RefreshRibbon(executionContext);
                }
            }

            formContext.data.entity.addOnSave(this.ValidateIsDirty);
            this.showNotification(executionContext);
            await this.ValidateSalesOrgAccounts(executionContext, "niq_soldtoparty", "Sold To Party"); // Validating Sold to Party SAP Account
            await this.ValidateSalesOrgAccounts(executionContext, "niq_deliverytoparty", "Delievery To Party"); // Validating Delievery to Party SAP Account
            await this.ValidateSalesOrgAccounts(executionContext, "niq_billtoparty", "Bill To Party");// Validating BIll To Party SAP Account
            //this.SetDefaultValueofPE(executionContext);
            //QCP Mandatory Char Value Added Check
            formContext.getControl("header_process_niq_mandatorycharvaluesadded").setDisabled(true);
            formContext.getControl("header_process_niq_signedagreementcreatedandexecutedfromquot").setDisabled(true);
            this.bPFStageErrorNotification(executionContext);
            formContext.data.entity.addOnSave(this.TothrowerrorforAgreementtypeandLanguage);
            //https://learn.microsoft.com/en-us/power-apps/developer/model-driven-apps/clientapi/reference/events/attribute-onchange
            //formContext.getAttribute("niq_billtoparty")?.fireOnChange() //fireonchange can be used in async function.
            //this.SetInvoiceDispatchMethod(executionContext);

        }
        formContext.getControl("header_process_niq_readyfornextstage")?.setDisabled(true); // pre-proposal stage
        formContext.getControl("header_process_niq_readyfornextstage_1")?.setDisabled(true); //proposal stage
        formContext.getControl("header_process_niq_readyfornextstage_2")?.setDisabled(true); //negotiation stage
        //revert-22194
        formContext.getControl("header_process_niq_readyfornextstage")?.setVisible(false); // pre-proposal stage
        formContext.getControl("header_process_niq_readyfornextstage_1")?.setVisible(false); //proposal stage
        formContext.getControl("header_process_niq_readyfornextstage_2")?.setVisible(false); //negotiation stage

        //await this.setReadyForNextStage(executionContext);
        //trigger after the save is completed.
        //formContext.data.entity.addOnPostSave(this.setReadyForNextStage);
        this.lockFieldsOnLoad(executionContext);
    },

    ///Trigger points
    ///Form onload
    ///stage change - implicitly this func: OnBpfStageChange, reload the page on stage till Negotiation stage.
    ///onSave
    setReadyForNextStage: async function (executionContext) {
        console.log("setReadyfornextStage");
        var formContext = executionContext.getFormContext();
        formContext.getControl("header_process_niq_readyfornextstage")?.setDisabled(true); // pre-proposal stage
        formContext.getControl("header_process_niq_readyfornextstage_1")?.setDisabled(true); //proposal stage
        formContext.getControl("header_process_niq_readyfornextstage_2")?.setDisabled(true); //negotiation stage

        var formType = formContext.ui.getFormType();
        if (formType === 2) {
            var stage = formContext.getAttribute("niq_stage")?.getValue();
            var readyfornextStage = true;
            // For BPF fields that are required by default, and no JavaScript function or business rule is running to set them as required or not required.
            var DefaultBPFRequiredFields = [];
            //These fields are set required and set visible by using either JS or BR.
            var conditionRequiredFields = [];

            if (stage === "Pre-Proposal") {
                DefaultBPFRequiredFields = [
                    "header_process_niq_salesorgid",
                    "header_process_niq_fieldingcountry",
                    "header_process_niq_primarycontactid"
                ]
                conditionRequiredFields = [
                    "ownerid",
                    "parentaccountid",
                    "estimatedclosedate",
                    "transactioncurrencyid",
                    "niq_opportunitytype",
                    "niq_existingcontractaction",
                    "niq_salesgroupsalesorgid",
                    "niq_fieldingcountryci",
                    "niq_mainquoteid",
                    "header_process_niq_forecastingdatapresence",//BPF
                    "niq_existingcontractexpirationdate",
                    "niq_localcontributor"

                ];

                readyfornextStage = await OpportunityForm.Events.CheckValueInFields(formContext, DefaultBPFRequiredFields, conditionRequiredFields);
            }
            else if (stage === "Proposal") {
                DefaultBPFRequiredFields = [
                    "header_process_niq_mainquotesdealdeskapprovalobtained"
                ]
                readyfornextStage = await OpportunityForm.Events.CheckValueInFields(formContext, DefaultBPFRequiredFields, conditionRequiredFields);
                if (readyfornextStage) {
                    readyfornextStage = await OpportunityForm.Events.showErrorforRevenueSchedulesForNextStage(executionContext);
                    if (readyfornextStage) {
                        readyfornextStage = await OpportunityForm.Events.dealScoreStageRstrictForNextStageFlag(executionContext);
                    }
                }
            }
            else if (stage === "Negotiation") {

                DefaultBPFRequiredFields = [
                    "header_process_niq_mainquotesdealdeskapprovalobtained",
                    "header_process_niq_contractdecision",
                    "header_process_niq_soldtopartyverified",
                    "header_process_niq_billtopartyverified",
                    "header_process_niq_delivertopartyverified",
                    "header_process_niq_mandatorycharvaluesadded",
                    "header_process_niq_invoiceinformationverified",
                    "header_process_niq_terminationclause", //required in bpf, visibility is set by BR_show_hide_Termination_clause
                    "header_process_niq_shouldclientbeinvoicedforthisopportunity",
                    "header_process_niq_competitor1"
                ]

                conditionRequiredFields = [
                    "header_process_niq_tempeoafinallyexecutedagreementprovided",
                    "header_process_niq_billinginstructions",
                    "header_process_parentcontactid",
                    "header_process_niq_signedagreementcreatedandexecutedfromquot",
                    "header_process_niq_product_enhancement_impact_provisions",
                    "header_process_niq_invoicedispatchmethod"
                ];

                readyfornextStage = await OpportunityForm.Events.CheckValueInFields(formContext, DefaultBPFRequiredFields, conditionRequiredFields);
                var functionstoCheck = [
                    OpportunityForm.Events.showErrorforRevenueSchedulesForNextStage,
                    OpportunityForm.Events.dealScoreStageRstrictForNextStageFlag,
                    OpportunityForm.Events.TothrowerrorforAgreementtypeToSetForNextStageField,
                    OpportunityForm.Events.validateScheduleDateWithinQuoteDatesForNextStage
                ];
                if (readyfornextStage) {
                    for (let func of functionstoCheck) {
                        readyfornextStage = await func.call(this, executionContext);
                        if (!readyfornextStage) {
                            break;
                        }
                    }
                }
                console.log(readyfornextStage);

            }
            else {
                readyfornextStage = false;
            }
            var currentReadyforNextStage = formContext.getAttribute("niq_readyfornextstage")?.getValue();
            if (currentReadyforNextStage != readyfornextStage) {
                var data =
                {
                    "niq_readyfornextstage": readyfornextStage
                }
                formContext.getAttribute("niq_readyfornextstage")?.setValue(readyfornextStage);
                formContext.getAttribute("niq_readyfornextstage")?.setSubmitMode("never");
                // update the record
                await Xrm.WebApi.updateRecord("opportunity", formContext.data.entity.getId().slice(1, -1), data);
            }
        }

    },
    CheckValueInFields: async function (formContext, DefaultBPFRequiredFields, conditionRequiredFields) {
        var calculatedFields = ["niq_forecastingdatapresence", "niq_mainquotesdealdeskapprovalobtained"];
        //for calculated fields, we need to retrieve via api.
        var result = await Xrm.WebApi.retrieveRecord("opportunity", formContext.data.entity.getId().slice(1, -1), "?$select=" + calculatedFields.join(","));

        var forecast = formContext.getControl("header_process_niq_forecastingdatapresence")?.getAttribute()?.getValue();
        var mainquote = formContext.getControl("header_process_niq_mainquotesdealdeskapprovalobtained")?.getAttribute()?.getValue();
        console.log(forecast);
        console.log(mainquote);
        console.log(result.niq_forecastingdatapresence);
        console.log(result.niq_mainquotesdealdeskapprovalobtained);

        // For BPF fields that are required by default, and no JavaScript function or business rule is running to set them as required or not required.
        for (let i = 0; i < DefaultBPFRequiredFields.length; i++) {
            var field = DefaultBPFRequiredFields[i];
            if (formContext.getControl(field)?.getVisible()) {
                var value = formContext.getControl(field)?.getAttribute()?.getValue();
                value = calculatedFields.includes(field.replace("header_process_", "")) ? result[field.replace("header_process_", "")] : value;
                if (value === null || value === false) {
                    return false;
                }
            }
        }
        //These fields are set required and set visible by using either JS or BR.
        for (let i = 0; i < conditionRequiredFields.length; i++) {
            var field = conditionRequiredFields[i];
            if (formContext.getControl(field)?.getAttribute().getRequiredLevel() == "required") {
                var value = formContext.getControl(field)?.getAttribute()?.getValue();
                value = calculatedFields.includes(field.replace("header_process_", "")) ? result[field.replace("header_process_", "")] : value;
                if (value === null || value === false) {
                    return false;
                }
            }
        }
        return true;
    },
    showErrorforRevenueSchedulesForNextStage: async function (executionContext) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var stage1 = CommonForm.Events.CheckValueExists(formContext, "niq_stage") ? formContext.getAttribute("niq_stage").getValue() : "";

            if ((stage1 == "Proposal" || stage1 == "Negotiation") && stage1 !== null) {
                var quote = formContext.getAttribute("niq_mainquoteid").getValue();
                var quoteId = quote[0].id;
                quoteId = quoteId.replace("{", "");
                quoteId = quoteId.replace("}", "");


                var result = await Xrm.WebApi.retrieveRecord("quote", quoteId, "?$select=niq_elrevenueschedulecomplete,niq_elbillingschedulecomplete,niq_contractstartdate,niq_nonstandardbillingterm");


                console.log("Retrieved values: Name: " + result["niq_contractstartdate"]);
                var date = result["niq_contractstartdate"];

                var fetchXML = `<fetch mapping="logical" distinct="false">
                            <entity name="quotedetail">
                              <attribute name="productdescription" />
                              <attribute name="quotedetailid" />
                              <attribute name="niq_revenueschedulestatus" />
                              <attribute name="niq_billingschedulestatus" />
                              <order attribute="niq_brandid" descending="false" />
                              <filter type="and">
                                <filter type="or">
                                  <condition attribute="niq_billingschedulestatus" operator="eq" value="610570001" />
                                  <condition attribute="niq_billingschedulestatus" operator="eq" value="610570000" />
                                  <condition attribute="niq_revenueschedulestatus" operator="eq" value="610570000" />
                                  <condition attribute="niq_revenueschedulestatus" operator="eq" value="610570001" />
                                </filter>
                                <condition attribute="quoteid" operator="eq" uitype="quote" value="${quoteId}" />
                              </filter>
                            </entity>
                          </fetch>`;
                //var fetchResults = GetCRMWebAPI.Methods.GetFetchRecords(Xrm.Utility.getGlobalContext().getClientUrl(), fetchXML, "quotedetails");
                //var fetchXml = "?fetchXml=<fetch mapping='logical'><entity name='account'><attribute name='accountid'/><attribute name='name'/></entity></fetch>";

                var fetchResults = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", `?fetchXml=${fetchXML}`);
                if (stage1 == "Proposal") {
                    if ((fetchResults !== null && fetchResults.entities.length > 0) && date !== null) {
                        return false;
                    }

                }
                else { //for negotiation stage
                    if ((fetchResults !== null && fetchResults.entities.length > 0) && date !== null) {
                        return false;
                    }
                }
                return true;
            }
        }
        catch (e) {
            throw e.message;
        }

    },
    dealScoreStageRstrictForNextStageFlag: async function (executionContext) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var existingContractAction = formContext.getAttribute("niq_existingcontractaction")?.getValue();
            var businessarea = formContext.getAttribute("niq_businessarea")?.getValue();
            var ishostoppo = formContext.getAttribute("niq_ishostopportunity")?.getValue();
            var hostoppo = formContext.getAttribute("niq_hostopportunity").getValue();
            var timestampopp = formContext.getAttribute("niq_dealguidanceerrortimestampopp").getValue();
            var stage1 = CommonForm.Events.CheckValueExists(formContext, "niq_stage") ? formContext.getAttribute("niq_stage").getValue() : "";
            var args = executionContext.getEventArgs();

            if ((stage1 === "Proposal" || stage1 === "Negotiation") && stage1 !== null) {
                if (!ishostoppo && !hostoppo && businessarea !== 100000000 && businessarea !== 100000001 && existingContractAction !== 3 && existingContractAction !== 2) {
                    var quote = formContext.getAttribute("niq_mainquoteid").getValue();
                    var quoteId = quote[0].id.replace("{", "").replace("}", "");

                    var fetchXML = `<fetch mapping="logical" distinct="false">
                                <entity name="quotedetail">
                                    <attribute name="niq_brandid" />
                                    <attribute name="quotedetailname" />
                                    <attribute name="quotedetailid" />
                                    <order attribute="niq_brandid" descending="false" />
                                    <filter type="and">
                                        <condition attribute="niq_brandid" operator="eq" uiname="RMS" uitype="product" value="{D87CD76D-993F-EC11-8C60-0022480A4E68}" />
                                        <condition attribute="quoteid" operator="eq" uitype="quote" value="${quoteId}" />
                                    </filter>
                                </entity>
                            </fetch>`;


                    var fetchResults = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", `?fetchXml=${fetchXML}`);

                    if (fetchResults === null || fetchResults.entities.length === 0) {
                        return true; //no validation needed so return true;
                    }


                    var result = await Xrm.WebApi.retrieveRecord("quote", quoteId, "?$select=niq_dealguidanceexecutedatleastonce,niq_overalldealscore,niq_dealscoringinprogress");
                    var niq_dealguidanceexecutedatleastonce = result["niq_dealguidanceexecutedatleastonce"];
                    var niq_dealscoringinprogress = result["niq_dealscoringinprogress"];
                    var niq_overalldealscore = result["niq_overalldealscore"];

                    if (niq_dealguidanceexecutedatleastonce === false) {
                        if (niq_dealscoringinprogress === true) {
                            return false;
                        } else {
                            return false;
                        }
                    } else if (niq_dealguidanceexecutedatleastonce === true && niq_dealscoringinprogress === true) {
                        return false;
                    } else if (niq_dealguidanceexecutedatleastonce === true && niq_dealscoringinprogress === false) {
                        if (!niq_overalldealscore && timestampopp !== null) {
                            return false;
                        }


                    }
                }
            }
            return true;
        } catch (e) {
            throw e.message;
        }
    },
    TothrowerrorforAgreementtypeToSetForNextStageField: async function (executionContext) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var stage2 = CommonForm.Events.CheckValueExists(formContext, "niq_stage") ? formContext.getAttribute("niq_stage").getValue() : "";

            if (stage2 === "Negotiation") {
                var quote = formContext.getAttribute("niq_mainquoteid").getValue();
                var quoteId = quote[0].id;
                quoteId = quoteId.replace("{", "");
                quoteId = quoteId.replace("}", "");

                var result = await Xrm.WebApi.retrieveRecord("quote", quoteId, "?$select=niq_agreementtype,niq_blockedproductdesc");
                var date = result["niq_contractstartdate"];
                var agreementType = result["niq_agreementtype"];

                if (agreementType === null) {
                    return false;
                }
                else {
                    return true;
                }

            }
            return true;

        }
        catch (e) {
            throw e.message;
        }
    },
    validateScheduleDateWithinQuoteDatesForNextStage: async function (executionContext) {
        "use strict";

        // Get the form context and event arguments
        var formContext = executionContext?.getFormContext();
        var activeStage = CommonForm.Events.CheckValueExists(formContext, "niq_stage") ? formContext.getAttribute("niq_stage").getValue() : "";

        // Check if the active process is "Opportunity Business Process Flow" and the active stage is "Negotiation"
        if (activeStage === "Negotiation") {
            var opportunityId = formContext.data.entity.getId();

            // Exit if Opportunity ID is not available
            if (!opportunityId) return false;

            // Remove curly braces from Opportunity ID
            var opportunityIdFormatted = opportunityId.replace("{", "").replace("}", "");

            // Get the main quote ID from the opportunity form, and check if it exists
            var quote = formContext.getAttribute("niq_mainquoteid")?.getValue();
            if (!quote?.length) return false; // Exit if no quote is available

            // Extract the quote ID from the value
            var quoteId = quote[0].id.replace("{", "").replace("}", "");

            // Fetch quote details related to the main quote
            var fetchQuoteDetailsXml = `
                <fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
                    <entity name="quotedetail">
                        <attribute name="quotedetailid" />
                        <attribute name="quoteid" />
                        <attribute name="niq_lineitemstartdate" />
                        <attribute name="niq_lineitemenddate" />
                        <filter type="and">
                            <condition attribute="quoteid" operator="eq" value="${quoteId}" />
                        </filter>
                    </entity>
                </fetch>`;

            // Execute the fetchXML query to get quote details
            var quoteDetailsResult = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", "?fetchXml=" + encodeURIComponent(fetchQuoteDetailsXml));

            // Iterate through the results (quote details)
            for (var quoteDetail of quoteDetailsResult.entities) {
                var startDate = quoteDetail?.niq_lineitemstartdate;
                var endDate = quoteDetail?.niq_lineitemenddate;

                // If any required fields are missing, skip this iteration
                if (!startDate || !endDate) return false;

                // Fetch schedules related to the quote detail
                var scheduleFetchXml = `
                    <fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
                                    <entity name="niq_schedule">
                                        <attribute name="niq_scheduleid" />
                                        <attribute name="niq_name" />
                                        <attribute name="createdon" />
                                        <attribute name="modifiedon" />
                                        <attribute name="niq_scheduledate" />
                                        <attribute name="niq_lineitemid" />
                                        <order attribute="niq_name" descending="false" />
                                        <filter type="and">
                                        <condition attribute="niq_lineitemid" operator="eq" uitype="quotedetail" value="${quoteDetail?.quotedetailid}" />
                                        <condition attribute="niq_scheduletype" operator="eq" value="100000001" />
                                        <filter type="or">
                                        <condition attribute="niq_scheduledate" operator="lt" value="${startDate}"  />
                                        <condition attribute="niq_scheduledate" operator="gt" value="${endDate}" />
                                        </filter>
                                        </filter>
                                        <link-entity name="quotedetail" from="quotedetailid" to="niq_lineitemid" link-type="inner" alias="ad">
                                        <attribute name="niq_deliveryfrequency" />
                                        <filter type="and">
                                            <condition attribute="quoteid" operator="eq" uitype="quote" value="${quoteId}" />
                                            <condition attribute="niq_deliveryfrequency" operator="eq" value="100000009" />
                                        </filter>
                                        </link-entity>
                                    </entity>
                                    </fetch>`;

                // Execute the FetchXML for niq_schedule
                var schedules = await Xrm.WebApi.retrieveMultipleRecords("niq_schedule", "?fetchXml=" + encodeURIComponent(scheduleFetchXml));

                // If schedules are found, show error and prevent stage progression
                if (schedules?.entities?.length > 0) {
                    return false;  // Exit early to prevent further processing
                }
            }

            return true;
        }
    },

    RemoveHostMappingWhenCloningForm: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        //formContext.getControl("niq_originalopportunityid").setVisible(false);
        //formContext.getControl("niq_ultimateoriginalopportunityid").setVisible(false);
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_iscloneform")) {
            if (formType === 1 && formContext.getAttribute("niq_iscloneform").getValue() === false && CommonForm.Events.CheckFieldExists(formContext, "niq_originalopportunityid") && CommonForm.Events.CheckFieldExists(formContext, "niq_ultimateoriginalopportunityid")) {
                formContext.getControl("niq_originalopportunityid").setVisible(false);
                formContext.getControl("niq_ultimateoriginalopportunityid").setVisible(false);
                formContext.getAttribute("niq_cloneopportunity").setValue(null);
                formContext.getAttribute("niq_originalopportunityid").setValue(null);
                formContext.getAttribute("niq_ultimateoriginalopportunityid").setValue(null);
                formContext.getControl("niq_salesorgid").setDisabled(false);
                formContext.getControl("transactioncurrencyid").setDisabled(false);
                formContext.getControl("niq_opportunitytype").setDisabled(false);
                formContext.getControl("niq_salesgroupsalesorgid").setDisabled(false);
            }
        }
    },


    // Function to trigger rollup field calculation
    recalculateRollupField: function (executionContext) {
        var Sdk = window.Sdk || {};

        // Define the CalculateRollupFieldRequest class
        Sdk.CalculateRollupFieldRequest = function (target, fieldName) {
            this.Target = target;
            this.FieldName = fieldName;
        };

        // Define the getMetadata function for the request
        Sdk.CalculateRollupFieldRequest.prototype.getMetadata = function () {
            return {
                boundParameter: null,
                parameterTypes: {
                    "Target": {
                        "typeName": "mscrm.crmbaseentity",
                        "structuralProperty": 5
                    },
                    "FieldName": {
                        "typeName": "Edm.String",
                        "structuralProperty": 1
                    }
                },
                operationType: 1,
                operationName: "CalculateRollupField"
            };
        };

        var formContext = executionContext.getFormContext();
        var oppoId = formContext.data.entity.getId().replace("{", "").replace("}", "");
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_hostopportunity") && formContext.getAttribute("niq_hostopportunity").getValue() === null && CommonForm.Events.CheckValueExists(formContext, "niq_approvalstatus") && formContext.getAttribute("niq_approvalstatus").getValue() === 100000001 && CommonForm.Events.CheckFieldExists(formContext, "niq_ishostopportunity") && formContext.getAttribute("niq_ishostopportunity").getValue() === true) {

            var opportunityId =
            {
                "@odata.type": "Microsoft.Dynamics.CRM.opportunity",
                "opportunityid": oppoId
            };
            var fieldName = "niq_sumoftotalamountforchildquotes";
            // Create a CalculateRollupFieldRequest object
            var calculateRollupFieldRequest = new Sdk.CalculateRollupFieldRequest(opportunityId, fieldName);

            // Execute the request using Xrm.WebApi
            Xrm.WebApi.online.execute(calculateRollupFieldRequest).then(
                function (result) {
                    if (result.ok) {
                        result.json().then(
                            function (response) {
                                console.log("Rollup field calculation response:", response);
                            }
                        );
                    }
                },
                function (error) {
                    console.error("Error calculating rollup field:", error.message);
                }
            );
            formContext.getControl("niq_sumoftotalamountforchildquotes").setVisible(true);
        }
        else {
            formContext.getControl("niq_sumoftotalamountforchildquotes").setVisible(false);
        }
    },



    setDefaultAMView: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.getControl("header_process_niq_primarycontactid");
        var defaultView = formContext.getControl("niq_primarycontactid").getDefaultView();
        formContext.getControl("header_process_niq_primarycontactid").setDefaultView(defaultView);
        formContext.getControl("header_process_niq_fieldingcountry");
        var defaultView1 = formContext.getControl("niq_fieldingcountry").getDefaultView();
        formContext.getControl("header_process_niq_fieldingcountry").setDefaultView(defaultView1);
    },
    setVisibilityRevenueShareDealField: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_revenuesharedeal") && CommonForm.Events.CheckFieldExists(formContext, "niq_ishostopportunity")) {
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator")) {
                var isHostOpportunity = formContext.getAttribute("niq_ishostopportunity").getValue();
                if (isHostOpportunity === true) {
                    formContext.getControl("niq_revenuesharedeal").setVisible(false);
                    //It should be true once ICPOC is live
                } else {
                    formContext.getControl("niq_revenuesharedeal").setVisible(false);
                }
            } else {
                formContext.getControl("niq_revenuesharedeal").setVisible(false);
            }
        }
    },

    dealScoreStageRstrict: function (executionContext) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var existingContractAction = formContext.getAttribute("niq_existingcontractaction")?.getValue();
            var businessarea = formContext.getAttribute("niq_businessarea")?.getValue();
            var ishostoppo = formContext.getAttribute("niq_ishostopportunity")?.getValue();
            var hostoppo = formContext.getAttribute("niq_hostopportunity").getValue();
            var timestampopp = formContext.getAttribute("niq_dealguidanceerrortimestampopp").getValue();
            var stage1 = CommonForm.Events.CheckValueExists(formContext, "niq_stage") ? formContext.getAttribute("niq_stage").getValue() : "";
            var args = executionContext.getEventArgs();

            if ((stage1 === "Proposal" || stage1 === "Negotiation") && stage1 !== null) {
                if (!ishostoppo && !hostoppo && businessarea !== 100000000 && businessarea !== 100000001 && existingContractAction !== 3 && existingContractAction !== 2) {
                    var quote = formContext.getAttribute("niq_mainquoteid").getValue();
                    var quoteId = quote[0].id.replace("{", "").replace("}", "");

                    var fetchXML = `<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
                                    <entity name="quotedetail">
                                        <attribute name="niq_brandid" />
                                        <attribute name="quotedetailname" />
                                        <attribute name="quotedetailid" />
                                        <order attribute="niq_brandid" descending="false" />
                                        <filter type="and">
                                            <condition attribute="niq_brandid" operator="eq" uiname="RMS" uitype="product" value="{D87CD76D-993F-EC11-8C60-0022480A4E68}" />
                                            <condition attribute="quoteid" operator="eq" uitype="quote" value="${quoteId}" />
                                        </filter>
                                    </entity>
                                </fetch>`;

                    var fetchResults = GetCRMWebAPI.Methods.GetFetchRecords(
                        Xrm.Utility.getGlobalContext().getClientUrl(),
                        fetchXML,
                        "quotedetails"
                    );

                    if (fetchResults === null || fetchResults.value.length === 0) {
                        return;
                    }

                    var req = new XMLHttpRequest();
                    req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/quotes(" + quoteId + ")?$select=niq_dealguidanceexecutedatleastonce,niq_overalldealscore,niq_dealscoringinprogress", false);
                    req.setRequestHeader("OData-MaxVersion", "4.0");
                    req.setRequestHeader("OData-Version", "4.0");
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req.onreadystatechange = null;
                            if (this.status === 200) {
                                var result = JSON.parse(this.response);
                                var niq_dealguidanceexecutedatleastonce = result["niq_dealguidanceexecutedatleastonce"];
                                var niq_dealscoringinprogress = result["niq_dealscoringinprogress"];
                                var niq_overalldealscore = result["niq_overalldealscore"];

                                if (niq_dealguidanceexecutedatleastonce === false) {
                                    if (niq_dealscoringinprogress === true) {
                                        if (args.getDirection() === "Next") {
                                            Xrm.Navigation.openAlertDialog({
                                                text: "A Deal Guidance flow is in progress. Please wait for the result to be available in MSD under the Deal Guidance tab of the Main Quote."
                                            });
                                            args.preventDefault();
                                        }
                                    } else {
                                        if (args.getDirection() === "Next") {
                                            Xrm.Navigation.openAlertDialog({
                                                text: "Deal Guidance result is required. Please go to your Main Quote and click on the Trigger Deal Guidance button."
                                            });
                                            args.preventDefault();
                                        }
                                    }
                                } else if (niq_dealguidanceexecutedatleastonce === true && niq_dealscoringinprogress === true) {
                                    if (args.getDirection() === "Next") {
                                        Xrm.Navigation.openAlertDialog({
                                            text: "A Deal Guidance flow is in progress. Please wait for the result to be available in MSD under the Deal Guidance tab of the Main Quote."
                                        });
                                        args.preventDefault();
                                    }
                                } else if (niq_dealguidanceexecutedatleastonce === true && niq_dealscoringinprogress === false) {
                                    if (args.getDirection() === "Next") {
                                        if (!niq_overalldealscore && timestampopp !== null) {
                                            Xrm.Navigation.openAlertDialog({
                                                text: "The last Deal Guidance flow failed. Please go to your Main Quote and retrigger the flow by clicking on the Trigger Deal Guidance button."
                                            });
                                            args.preventDefault();
                                        }

                                    }
                                }
                            } else {
                                Xrm.Utility.alertDialog(this.statusText);
                            }
                        }
                    };
                    req.send();
                }
            }
        } catch (e) {
            throw e.message;
        }
    },
    //24104
    /**
     * Restricts stage movement for child revenue share opportunities.
     * 
     * This function is triggered during the stage transition of an opportunity form.
     * It checks whether the current opportunity is a child in a revenue share deal,
     * and prevents moving past the "Negotiation" stage if conditions are met.
     * 
     * A form notification is shown if movement is restricted, and it is automatically
     * removed after 30 seconds.
     * 
     * @param {object} executionContext - The execution context provided by the form event.
     * @property {object} executionContext.getEventArgs - Contains information about the process stage transition.
     * @property {object} executionContext.getFormContext - Provides access to the form's data and UI elements.
    */
    LocalcontributorStageRestrict: function (executionContext) {
        const args = executionContext?.getEventArgs();
        const formContext = executionContext?.getFormContext();

        const isHost = formContext.getAttribute("niq_ishostopportunity")?.getValue();
        const hostOpp = formContext.getAttribute("niq_hostopportunity")?.getValue();
        var isRevShare = null;
        if (hostOpp == null) {
            isRevShare = formContext.getAttribute("niq_revenuesharedeal")?.getValue();
        }
        else {

            var fetchData = {
                "opportunityid": hostOpp[0].id.slice(1, -1)
            };
            var fetchXml = [
                "<fetch >",
                "  <entity name='opportunity'>",
                "    <attribute name='name'/>",
                "    <attribute name='niq_revenuesharedeal'/>",
                "    <filter>",
                "      <condition attribute='opportunityid' operator='eq' value='", fetchData.opportunityid/*38f6a0cb-d7bb-4299-adde-ec9862919b17*/, "'/>",
                "    </filter>",
                "  </entity>",
                "</fetch>"
            ].join("");

            var fetchResults = GetCRMWebAPI.Methods.GetFetchRecords(Xrm.Utility.getGlobalContext().getClientUrl(), fetchXml, "opportunities");
            if (fetchResults !== null && fetchResults.value.length > 0) {
                if (fetchResults.value.length > 0) {
                    isRevShare = fetchResults.value[0].niq_revenuesharedeal != null ? fetchResults.value[0].niq_revenuesharedeal : null;
                }
            }
        }
        const direction = args.getDirection(); // "Next" or "Previous"
        const currentStage = formContext.data.process.getActiveStage()?.getName();

        const isChild = !!hostOpp && !isHost;

        var localContributors = formContext.getAttribute("niq_localcontributor")?.getValue();
        var owner = formContext.getAttribute("ownerid")?.getValue();

        var localContributorID = localContributors ? localContributors[0].id : null;
        var ownerId = owner ? owner[0].id : null;
        var currentUser = Xrm.Utility.getGlobalContext().userSettings.userId;
        // Restrict if it's a revshare child opp and user tries to go next from Negotiation
        if (isChild && isRevShare === true && direction === "Next" && currentStage === "Negotiation" && localContributorID != ownerId && localContributorID == currentUser) {
            Xrm.Navigation.openErrorDialog({ message: "Local contributor can move the child opportunity of revenue share deal till negotiation stage" });
            args.preventDefault();
        }
    },

    OnSaveShowNotificationForCompetitorsTab: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        formContext.ui.setFormNotification("In case of a competitive deal indicate competitors on the Competitors tab of this opportunity", "INFO", "notification");
        setTimeout(
            function () {
                formContext.ui.clearFormNotification("notification");
            },
            10000
        );
    },
    ShowHideCompetitor1Field: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_competitor1")) {
            if (formContext.data.process.getActiveStage().getName().toLowerCase() === "pre-proposal" || formContext.data.process.getActiveStage().getName().toLowerCase() === "proposal") {
                formContext.getControl("header_process_niq_competitor1").setVisible(false);
            }
            else {

                formContext.getControl("header_process_niq_competitor1").setVisible(true);
            }
        }
    },
    ShowDeliveryNotification: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_businessarea") &&
            formContext.getAttribute("niq_businessarea").getValue() != 100000000 &&
            CommonForm.Events.CheckValueExists(formContext, "statecode") &&
            formContext.getAttribute("statecode").getValue() === 1) {
            var opportunityId = formContext.data.entity.getId().replace("{", "").replace("}", "");
            var req = new XMLHttpRequest();
            req.open("GET", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/niq_deliveries?$select=niq_deliveryid&$filter=(_niq_opportunityid_value eq " + opportunityId + ")", false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Prefer", "odata.include-annotations=*");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var results = JSON.parse(this.response);
                        console.log(results);
                        if (results.value.length > 0) {
                            formContext.ui.setFormNotification("By uploading an Evidence of Delivery (EOD) file to this Delivery you certify that this Evidence of Delivery is true, accurate & reflects the delivery requirements per the contractual terms and conditions. Falsification of evidence of delivery is subject to disciplinary action per NIQ's Code of Conduct", "INFO", "deliverystatusnotify");

                        }
                        else {
                            formContext.ui.clearFormNotification("deliverystatusnotify");
                        }
                    } else {
                        console.log(this.responseText);
                    }
                }
            };
            req.send();
            var formContext = executionContext.getFormContext();
            var statusField = formContext.getAttribute("statecode");
            var opportunityTypeField = formContext.getAttribute("niq_businessarea");
            if (statusField && opportunityTypeField) {
                var status = statusField?.getValue();
                var opportunityType = opportunityTypeField?.getValue();
                var CLOSED_WON_STATUS = 1;
                var BASES_OPPORTUNITY_TYPE = "100000000";
                if (status === CLOSED_WON_STATUS && opportunityType !== BASES_OPPORTUNITY_TYPE) {
                    var message = "Only users with edit access to a Delivery can change Forecasted Delivery Date or upload an EOD. In order to gain edit access you need to assign Delivery to yourself by clicking 'Assign Deliveries' button in the kebab menu in the related deliveries tab";
                    formContext.ui.setFormNotification(message, "INFO", "disclaimerNotification");
                }

            }
        }
        else {
            formContext.ui.clearFormNotification("deliverystatusnotify");
        }
    },



    showNotification: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_opportunitytype") && formContext.getAttribute("niq_opportunitytype").getValue() === 2 && CommonForm.Events.CheckValueExists(formContext, "niq_existingcontractaction") && (formContext.getAttribute("niq_existingcontractaction").getValue() === 2 || formContext.getAttribute("niq_existingcontractaction").getValue() === 4))
            formContext.ui.setFormNotification("The revenue for the existing contract that you are managing via this opportunity is accounted for in SAP. For accurate forecasting you need to reflect the revenue difference between this opportunity and revenue already present in SAP on the \"SAP Deferred Revenue reconciliation placeholder\"", "INFO", "DYNMSM-2138");
        else
            formContext.ui.clearFormNotification("DYNMSM-2138");
    },

    setMainQuoteFilter: function (executionContext) {
        // get the form context
        formContext = executionContext.getFormContext();
        if (formContext.getControl("niq_mainquoteid") !== null) {
            formContext.getControl("niq_mainquoteid").addPreSearch(this.filterQuotes);
        }
    },
    filterQuotes: function () {
        // Only show Draft or Active Quotes Related to Oportunity  
        var oppoId = formContext.data.entity.getId();
        var quoteFilter = "<filter type='and'> <condition attribute='opportunityid' operator='eq' uitype='opportunity' value='" + oppoId + "' /> <condition attribute='statecode' operator='in'> <value>1</value> <value>0</value></condition> </filter>";
        formContext.getControl("niq_mainquoteid").addCustomFilter(quoteFilter, "quote");
    },
    CustomViewBillToParty: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "parentaccountid") && CommonForm.Events.CheckFieldExists(formContext, "niq_billtoparty")) {

            var viewId2 = formContext.getControl("niq_billtoparty").getDefaultView();
            var entName = "account";
            var vwName = "Related SAP accounts inc. NIC";
            var resFetch = "";
            var viewId3 = "{00000000-0000-0000-0000-000000000003}";
            var vwNamebill = "Opportunity's Sales org SAP accounts";
            var resFetch1 = "";
            var noRecords = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                "<entity name='account'>" +
                "<attribute name='name' />" +
                "<attribute name='primarycontactid' />" +
                "<attribute name='telephone1' />" +
                "<attribute name='accountid' />" +
                "<order attribute='name' descending='false' />" +
                "<filter type='and'>" +
                "<condition attribute='niq_accounttype' operator='eq' value='21' />" +
                "</filter>" +
                "</entity>" +
                "</fetch>";
            var resLayout = "<grid name='resultset' object='10030' jump='mtctb_name' select='1' icon='1' preview='1'>" +
                "<row name='result' id='new_user'>" +
                "<cell name='name' width='200'/>" +
                "<cell name='niq_vatregistrationnumber' width='100'/>" +
                "<cell name='niq_sap_id__c' width='100'/>" +
                "<cell name='niq_countryid' width='125'/>" +
                "</row>" +
                "</grid>";
            if (CommonForm.Events.CheckValueExists(formContext, "parentaccountid")) {

                var parentAccountId = formContext.getAttribute("parentaccountid").getValue()[0].id;

                Xrm.WebApi.online.retrieveRecord("account", parentAccountId, "?$select=_niq_ultimateparentid_value").then(
                    function success(result) {
                        var ultimateParentId = result["_niq_ultimateparentid_value"];


                        if (ultimateParentId !== null) {
                            resFetch = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                "<entity name='account'>" +
                                "<attribute name='name' />" +
                                "<attribute name='accountid' />" +
                                "<attribute name='address1_line1' />" +
                                "<attribute name='niq_vatregistrationnumber' />" +
                                "<attribute name='niq_sap_id__c' />" +
                                "<attribute name='niq_countryid' />" +
                                "<attribute name='address1_city' />" +
                                "<order attribute='name' descending='false' />" +
                                "<filter type='and'>" +
                                "<filter type='or'>" +
                                "<filter type='and'>" +
                                "<condition attribute='niq_ultimateparentid' operator='eq' uitype='account' value='{" + ultimateParentId + "}' />" +
                                "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                "</filter>" +
                                "<filter type='and'>" +
                                "<condition attribute='niq_sap_id__c' operator='like' value='%NIC%' />" +
                                "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                "</filter>" +
                                "</filter>" +
                                "</filter>" +
                                "</entity>" +
                                "</fetch>"
                        }
                        else {
                            resFetch = noRecords
                        }




                        if (formContext.getAttribute("niq_salesorgid") !== null && formContext.getAttribute("niq_salesorgid").getValue() !== null) {
                            var salesOrgId = formContext.getAttribute("niq_salesorgid").getValue()[0].id;

                            resFetch1 = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                                "<entity name='account'>" +
                                "<attribute name='name' />" +
                                "<attribute name='accountid' />" +
                                "<attribute name='address1_line1' />" +
                                "<attribute name='niq_vatregistrationnumber' />" +
                                "<attribute name='niq_sap_id__c' />" +
                                "<attribute name='niq_countryid' />" +
                                "<attribute name='address1_city' />" +
                                "<order attribute='name' descending='false' />" +
                                "<filter type='and'>" +
                                "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                "<condition attribute='niq_ultimateparentid' operator='eq' uitype='account' value='{" + ultimateParentId + "}' />" +
                                "</filter>" +
                                "<link-entity name='niq_saleorgassignment' from='niq_account' to='accountid' link-type='inner' alias='ac'>" +
                                "<filter type='and'>" +
                                "<condition attribute='niq_salesorg' operator='eq' uitype='niq_salesorg' value='" + salesOrgId + "' />" +
                                "<condition attribute='niq_accountblocked' operator='eq' value='0' />" +
                                "</filter>" +
                                "</link-entity>" +
                                "</entity>" +
                                "</fetch>";


                        }
                        else {
                            resFetch1 = noRecords;
                        }

                        formContext.getControl("niq_billtoparty").addCustomView(viewId2, entName, vwName, resFetch, resLayout, true);
                        formContext.getControl("niq_billtoparty").addCustomView(viewId3, entName, vwNamebill, resFetch1, resLayout, false);




                    },
                    function (error) {
                        Xrm.Utility.alertDialog(error.message);
                    }
                );


            }
            if (!CommonForm.Events.CheckValueExists(formContext, "parentaccountid")) {

                formContext.getControl("niq_billtoparty").addCustomView(viewId2, entName, vwName, noRecords, resLayout, true);
                formContext.getControl("niq_billtoparty").addCustomView(viewId3, entName, vwNamebill, noRecords, resLayout, false);

            }
        }
    },
    InvoiceInfoVerifiedFieldReadOnly: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_invoiceinformationverified")) {
            formContext.getControl("header_process_niq_invoiceinformationverified").setDisabled(true);
        }
    },
    OnChangeofSoldtoParty: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_soldtoparty") && CommonForm.Events.CheckValueExists(formContext, "niq_soldtoparty")) {
            var soldToParty = formContext.getAttribute("niq_soldtoparty").getValue();

            if (CommonForm.Events.CheckFieldExists(formContext, "niq_billtoparty") && !CommonForm.Events.CheckValueExists(formContext, "niq_billtoparty")) {
                formContext.getAttribute("niq_billtoparty").setValue(soldToParty);
            }

            if (CommonForm.Events.CheckFieldExists(formContext, "niq_deliverytoparty") && !CommonForm.Events.CheckValueExists(formContext, "niq_deliverytoparty")) {
                formContext.getAttribute("niq_deliverytoparty").setValue(soldToParty);
            }


        }
    },
    ValidateContractEndDate: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_contractenddate") && CommonForm.Events.CheckFieldExists(formContext, "niq_contractstartdate")) {
            var contractEndDate = formContext.getAttribute("niq_contractenddate").getValue();
            var contractStartDate = formContext.getAttribute("niq_contractstartdate").getValue();

            if ((contractEndDate !== null) && (contractStartDate !== null) && (contractStartDate > contractEndDate)) {
                formContext.getControl("niq_contractenddate").setNotification("The Contract End Date cannot be before Contract Start Date.", "validateContractEndDate");
                formContext.getAttribute("niq_contractenddate").setValue(null);
            }
            else {
                formContext.getControl("niq_contractstartdate").clearNotification("validateContracStarttDate");
                formContext.getControl("niq_contractenddate").clearNotification("validateContractEndDate");
            }
        }
    },
    ValidateContractStartDate: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_contractenddate") && CommonForm.Events.CheckFieldExists(formContext, "niq_contractstartdate")) {
            var contractEndDate = formContext.getAttribute("niq_contractenddate").getValue();
            var contractStartDate = formContext.getAttribute("niq_contractstartdate").getValue();

            if (((contractStartDate !== null) && contractEndDate !== null) && (contractStartDate > contractEndDate)) {
                formContext.getControl("niq_contractstartdate").setNotification("The Contract Start Date cannot be after Contract End Date.", "validateContracStarttDate");
                formContext.getAttribute("niq_contractstartdate").setValue(null);
            }
            else {
                formContext.getControl("niq_contractenddate").clearNotification("validateContractEndDate");
                formContext.getControl("niq_contractstartdate").clearNotification("validateContracStarttDate");
            }
        }
    },
    CustomViewCommon: function (formContext, fieldName) {
        "use strict";
        var entName = "account";
        var vwNic = "NIC SAP Accounts(internal)";
        var vwNicId = "{00000000-0000-0000-0000-000000000023}";
        var resLayout = "<grid name='resultset' object='1' jump='name' select='1' icon='1' preview='1'>" +
            "<row name='result' id='accountid'>" +
            "<cell name='name' width='300'/>" +
            "<cell name='address1_line1' width='100'/>" +
            "<cell name='address1_city' width='100'/>" +
            "<cell name='niq_countryid' width='100'/>" +
            "<cell name='niq_sap_id__c' width='100'/>" +
            "<cell name='niq_vatregistrationnumber' width='100'/>" +
            "</row>" +
            "</grid>";
        var sapNicResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
            "<entity name='account'>" +
            "<attribute name='name' />" +
            "<attribute name='address1_line1' />" +
            "<attribute name='address1_city' />" +
            "<attribute name='niq_countryid' />" +
            "<attribute name='niq_sap_id__c' />" +
            "<attribute name='niq_vatregistrationnumber' />" +
            "<attribute name='accountid' />" +
            "<order attribute='name' descending='false' />" +
            "<filter type='and'>" +
            "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
            "<condition attribute='niq_sap_id__c' operator='like' value='%NIC%' />" +
            "</filter>" +
            "</entity>" +
            "</fetch>";
        if (CommonForm.Events.CheckFieldExists(formContext, "parentaccountid") && CommonForm.Events.CheckFieldExists(formContext, fieldName)) {
            var relSAPResult = "";
            var sapExtResult = "";
            var vwSAPExtId = "{00000000-0000-0000-0000-000000000001}";
            var vwSAPExt = "Related SAP Accounts ext to sales org";
            var vwRelSAPId = formContext.getControl(fieldName).getDefaultView();

            var vwRelSAP = "Related SAP Accounts";

            var noResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                "<entity name='account'>" +
                "<attribute name='name' />" +
                "<attribute name='primarycontactid' />" +
                "<attribute name='telephone1' />" +
                "<attribute name='accountid' />" +
                "<order attribute='name' descending='false' />" +
                "<filter type='and'>" +
                "<condition attribute='niq_accounttype' operator='eq' value='21' />" +
                "</filter>" +
                "</entity>" +
                "</fetch>";

            if (CommonForm.Events.CheckValueExists(formContext, "parentaccountid")) {

                var parentAccountId = formContext.getAttribute("parentaccountid").getValue()[0].id;

                Xrm.WebApi.online.retrieveRecord("account", parentAccountId, "?$select=_niq_ultimateparentid_value").then(
                    function success(result) {
                        var ultimateParentId = result["_niq_ultimateparentid_value"];

                        if (ultimateParentId !== null) {
                            relSAPResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                "<entity name='account'>" +
                                "<attribute name='name' />" +
                                "<attribute name='accountid' />" +
                                "<attribute name='address1_line1' />" +
                                "<attribute name='niq_vatregistrationnumber' />" +
                                "<attribute name='niq_sap_id__c' />" +
                                "<attribute name='niq_countryid' />" +
                                "<attribute name='address1_city' />" +
                                "<order attribute='name' descending='false' />" +
                                "<filter type='and'>" +
                                "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                "<condition attribute='niq_ultimateparentid' operator='eq'  uitype='account' value='{" + ultimateParentId + "}' />" +
                                "<condition attribute='statuscode' operator='eq' value='1'/>" +
                                "</filter>" +
                                "</entity>" +
                                "</fetch>";
                            if (formContext.getAttribute("niq_salesorgid") !== null && formContext.getAttribute("niq_salesorgid").getValue() !== null) {
                                var salesOrgId = formContext.getAttribute("niq_salesorgid").getValue()[0].id;

                                sapExtResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                                    "<entity name='account'>" +
                                    "<attribute name='name' />" +
                                    "<attribute name='accountid' />" +
                                    "<attribute name='address1_line1' />" +
                                    "<attribute name='niq_vatregistrationnumber' />" +
                                    "<attribute name='niq_sap_id__c' />" +
                                    "<attribute name='niq_countryid' />" +
                                    "<attribute name='address1_city' />" +
                                    "<order attribute='name' descending='false' />" +
                                    "<filter type='and'>" +
                                    "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                    "<condition attribute='niq_ultimateparentid' operator='eq' uitype='account' value='{" + ultimateParentId + "}' />" +
                                    "</filter>" +
                                    "<link-entity name='niq_saleorgassignment' from='niq_account' to='accountid' link-type='inner' alias='ac'>" +
                                    "<filter type='and'>" +
                                    "<condition attribute='niq_salesorg' operator='eq' uitype='niq_salesorg' value='" + salesOrgId + "' />" +
                                    "<condition attribute='niq_accountblocked' operator='eq' value='0' />" +
                                    "</filter>" +
                                    "</link-entity>" +
                                    "</entity>" +
                                    "</fetch>";


                            }
                        }
                        else {
                            relSAPResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                "<entity name='account'>" +
                                "<attribute name='name' />" +
                                "<attribute name='accountid' />" +
                                "<attribute name='address1_line1' />" +
                                "<attribute name='niq_vatregistrationnumber' />" +
                                "<attribute name='niq_sap_id__c' />" +
                                "<attribute name='niq_countryid' />" +
                                "<attribute name='address1_city' />" +
                                "<order attribute='name' descending='false' />" +
                                "<filter type='and'>" +
                                "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                "<condition attribute='niq_ultimateparentid' operator='eq'  uitype='account' value='" + parentAccountId + "' />" +
                                "<condition attribute='statuscode' operator='eq' value='1'/>" +
                                "</filter>" +
                                "</entity>" +
                                "</fetch>";
                            if (formContext.getAttribute("niq_salesorgid") !== null && formContext.getAttribute("niq_salesorgid").getValue() !== null) {
                                var salesOrgId = formContext.getAttribute("niq_salesorgid").getValue()[0].id;

                                sapExtResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                                    "<entity name='account'>" +
                                    "<attribute name='name' />" +
                                    "<attribute name='accountid' />" +
                                    "<attribute name='address1_line1' />" +
                                    "<attribute name='niq_vatregistrationnumber' />" +
                                    "<attribute name='niq_sap_id__c' />" +
                                    "<attribute name='niq_countryid' />" +
                                    "<attribute name='address1_city' />" +
                                    "<order attribute='name' descending='false' />" +
                                    "<filter type='and'>" +
                                    "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                    "<condition attribute='niq_ultimateparentid' operator='eq' uitype='account' value='" + parentAccountId + "' />" +
                                    "</filter>" +
                                    "<link-entity name='niq_saleorgassignment' from='niq_account' to='accountid' link-type='inner' alias='ac'>" +
                                    "<filter type='and'>" +
                                    "<condition attribute='niq_salesorg' operator='eq' uitype='niq_salesorg' value='" + salesOrgId + "' />" +
                                    "<condition attribute='niq_accountblocked' operator='eq' value='0' />" +
                                    "</filter>" +
                                    "</link-entity>" +
                                    "</entity>" +
                                    "</fetch>";


                            }
                        }


                        formContext.getControl(fieldName).addCustomView(vwRelSAPId, entName, vwRelSAP, relSAPResult, resLayout, false);
                        formContext.getControl(fieldName).addCustomView(vwSAPExtId, entName, vwSAPExt, sapExtResult, resLayout, false);




                    },
                    function (error) {
                        Xrm.Utility.alertDialog(error.message);
                    }
                );


            }
            else {

                formContext.getControl(fieldName).addCustomView(vwRelSAPId, entName, vwRelSAP, noResult, resLayout, false);
                formContext.getControl(fieldName).addCustomView(vwSAPExtId, entName, vwSAPExt, noResult, resLayout, false);

            }


        }
        formContext.getControl(fieldName).addCustomView(vwNicId, entName, vwNic, sapNicResult, resLayout, false);
    },
    CustomViewAccountGoals: function (formContext, fieldName) {
        var entName = "niq_niqaccountgoal";
        var vwRelAcc = "All NIQ Account Goals";
        var vwRelAccId = formContext.getControl(fieldName).getDefaultView();
        if (CommonForm.Events.CheckValueExists(formContext, "parentaccountid") && CommonForm.Events.CheckFieldExists(formContext, fieldName)) {

            var accountId = formContext.getAttribute("parentaccountid").getValue()[0].id;
            var resLayout = "<grid name='resultset' object='10910' jump='niq_niqaccountgoalname' select='1' icon='1' preview='1'>" +
                "<row name='result' id='niq_niqaccountgoalid'>" +
                "<cell name='niq_niqaccountgoalname' width='300'/>" +
                "<cell name='niq_clientobjective' width='100'/>" +
                "<cell name='niq_potentialrevenueassociated' width='100'/>" +
                "<cell name='statecode' width='100'/>" +
                "<cell name='createdon' width='125'/>" +
                "</row>" +
                "</grid>";
            var relAccResult = "";
            Xrm.WebApi.online.retrieveRecord("account", accountId, "?$select=_niq_ultimateparentid_value").then(
                function success(result) {
                    var ultimateParentId = result["_niq_ultimateparentid_value"];

                    if (ultimateParentId !== null) {
                        relAccResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                            "<entity name='niq_niqaccountgoal'>" +
                            "<attribute name='niq_niqaccountgoalid' />" +
                            "<attribute name='niq_niqaccountgoalname' />" +
                            "<attribute name='createdon' />" +
                            "<attribute name='statecode' />" +
                            "<attribute name='niq_potentialrevenueassociated' />" +
                            "<attribute name='niq_clientobjective' />" +
                            "<order attribute='niq_niqaccountgoalname' descending='false' />" +
                            "<link-entity name='account' from='accountid' to='niq_accountameid' link-type='inner' alias='ab'>" +
                            "<filter type='and'>" +
                            "<condition attribute='accountid' operator='eq-or-under' uitype='account' value='" + ultimateParentId + "' />" +
                            "</filter>" +
                            "</link-entity>" +
                            "</entity>" +
                            "</fetch>";


                    }
                    else {

                        relAccResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                            "<entity name='niq_niqaccountgoal'>" +
                            "<attribute name='niq_niqaccountgoalid' />" +
                            "<attribute name='niq_niqaccountgoalname' />" +
                            "<attribute name='createdon' />" +
                            "<attribute name='statecode' />" +
                            "<attribute name='niq_potentialrevenueassociated' />" +
                            "<attribute name='niq_clientobjective' />" +
                            "<order attribute='niq_niqaccountgoalname' descending='false' />" +
                            "<link-entity name='account' from='accountid' to='niq_accountameid' link-type='inner' alias='ab'>" +
                            "<filter type='and'>" +
                            "<condition attribute='accountid' operator='eq-or-under' uitype='account' value='" + accountId + "' />" +
                            "</filter>" +
                            "</link-entity>" +
                            "</entity>" +
                            "</fetch>";


                    }


                    formContext.getControl(fieldName).addCustomView(vwRelAccId, entName, vwRelAcc, relAccResult, resLayout, false);


                },
                function (error) {
                    Xrm.Utility.alertDialog(error.message);
                }
            );




        }
    },
    CustomViewInvoiceReceipient: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        if (CommonForm.Events.CheckFieldExists(formContext, "parentaccountid") &&
            CommonForm.Events.CheckValueExists(formContext, "parentaccountid")) {
            var parentaccountId = formContext.getAttribute("parentaccountid").getValue()[0].id;
            var viewId = formContext.getControl("parentcontactid").getDefaultView();
            var viewId2 = formContext.getControl("niq_invoicerecipient2").getDefaultView();
            var viewId3 = formContext.getControl("niq_invoicerecipient3").getDefaultView();
            var viewId4 = formContext.getControl("niq_invoicerecipient4").getDefaultView();
            //var viewId5 = formContext.getControl("niq_invoicerecipient5").getDefaultView();
            var viewId6 = formContext.getControl("niq_nameoninvoiceifdifffrominvoicerecipient").getDefaultView();

            var entity = "contact";
            var ViewDisplayName = "All Contacts";
            var layout = "<grid name='resultset' object='2' jump='lastname' select='1' icon='1' preview='1'>" +
                "<row name='result' id='contactid'>" +
                "<cell name='fullname' width='300'/>" +
                "<cell name='emailaddress1' width='100'/>" +
                "</row>" +
                "</grid>";

            var fetchXML = "";
            Xrm.WebApi.online.retrieveRecord("account", parentaccountId, "?$select=_niq_ultimateparentid_value").then(
                function success(result) {
                    var ultimateParentId = result["_niq_ultimateparentid_value"];

                    if (ultimateParentId !== null) {
                        fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                            "<entity name='contact'>" +
                            "<attribute name='fullname' />" +
                            "<attribute name='contactid' />" +
                            "<attribute name='emailaddress1' />" +
                            "<order attribute='fullname' descending='false' />" +
                            "<link-entity name='account' from='accountid' to='parentcustomerid' link-type='inner' alias='ac'>" +
                            "<filter type='and'>" +
                            "<condition attribute='accountid' operator='eq-or-under' uitype='account' value='{" + ultimateParentId + "}' />" +
                            "</filter>" +
                            "</link-entity>" +
                            "</entity>" +
                            "</fetch>";



                    }
                    else {

                        fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                            "<entity name='contact'>" +
                            "<attribute name='fullname' />" +
                            "<attribute name='contactid' />" +
                            "<attribute name='emailaddress1' />" +
                            "<order attribute='fullname' descending='false' />" +
                            "<link-entity name='account' from='accountid' to='parentcustomerid' link-type='inner' alias='ac'>" +
                            "<filter type='and'>" +
                            "<condition attribute='accountid' operator='eq-or-under' uitype='account' value='" + parentaccountId + "' />" +
                            "</filter>" +
                            "</link-entity>" +
                            "</entity>" +
                            "</fetch>";



                    }


                    formContext.getControl("parentcontactid").addCustomView(viewId, entity, ViewDisplayName, fetchXML, layout, false);
                    formContext.getControl("niq_invoicerecipient2").addCustomView(viewId2, entity, ViewDisplayName, fetchXML, layout, false);
                    formContext.getControl("niq_invoicerecipient3").addCustomView(viewId3, entity, ViewDisplayName, fetchXML, layout, false);
                    formContext.getControl("niq_invoicerecipient4").addCustomView(viewId4, entity, ViewDisplayName, fetchXML, layout, false);
                    //formContext.getControl("niq_invoicerecipient5").addCustomView(viewId5, entity, ViewDisplayName, fetchXML, layout, false);
                    formContext.getControl("niq_nameoninvoiceifdifffrominvoicerecipient").addCustomView(viewId6, entity, ViewDisplayName, fetchXML, layout, false);

                },
                function (error) {
                    Xrm.Utility.alertDialog(error.message);
                }
            );

        }
    },
    _LockApprovalStatusOnBPF: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.getControl("header_process_niq_approvalstatus").setDisabled(true);
        formContext.getControl("header_process_niq_submissiontime").setDisabled(true);
        formContext.getControl("header_process_statecode").setVisible(false);
    },
    ValidateIsDirty: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_approvalstatus")) {
            var isDirty = formContext.getAttribute("niq_approvalstatus").getIsDirty();
            if (isDirty) {
                formContext.data.entity.addOnPostSave(OpportunityForm.Events.OnApprovalStatusChange);
            }
        }

    },
    OnApprovalStatusChange: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_approvalstatus")) {
            var oppoId = formContext.data.entity.getId().replace("{", "").replace("}", "");
            formContext.data.refresh(true).then(function refreshOppo() {
                var entityFormOptions = {};
                entityFormOptions["entityName"] = "opportunity";
                entityFormOptions["entityId"] = oppoId;

                // Open the form.
                Xrm.Navigation.openForm(entityFormOptions);
            });
        }
    },
    RefreshRibbon: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        formContext.ui.refreshRibbon();
    },
    ValidateSalesOrgAccounts: async function (executionContext, fieldName, field) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var fieldVerified = " ";
        switch (fieldName) {
            case "niq_soldtoparty": fieldVerified = "niq_soldtopartyverified";
                break;
            case "niq_billtoparty": fieldVerified = "niq_billtopartyverified";
                break;
            case "niq_deliverytoparty": fieldVerified = "niq_delivertopartyverified";
                break;
            default: fieldVerified = " ";
                break;
        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_salesorgid") && CommonForm.Events.CheckValueExists(formContext, fieldName)) {
            var salesOrgId = formContext.getAttribute("niq_salesorgid").getValue()[0].id;
            var fieldId = formContext.getAttribute(fieldName).getValue()[0].id;
            salesOrgId = salesOrgId.replace("{", "").replace("}", "");
            fieldId = fieldId.replace("{", "").replace("}", "");


            await Xrm.WebApi.online.retrieveMultipleRecords("niq_saleorgassignment", "?$select=niq_accountblocked&$filter=_niq_salesorg_value eq " + salesOrgId + " and  _niq_account_value eq " + fieldId + "&$top=1").then(
                function success(results) {
                    if (results.entities.length) {


                        var accBlocked = results.entities[0]["niq_accountblocked"];
                        if (accBlocked) {
                            if (fieldVerified !== " " && CommonForm.Events.CheckFieldExists(formContext, fieldVerified)) {
                                formContext.getAttribute(fieldVerified).setValue(false);
                            }
                            formContext.ui.setFormNotification("Selected " + field + "Account is blocked for Sales Org. Please submit an unblocking request for the selected SAP account.", "ERROR", field + "error");
                        } else {
                            if (fieldVerified !== " " && CommonForm.Events.CheckFieldExists(formContext, fieldVerified)) {
                                formContext.getAttribute(fieldVerified).setValue(true);
                                OpportunityForm.Events.RefreshRibbon(executionContext);
                            }
                        }

                    }
                    else {
                        if (fieldVerified !== " " && CommonForm.Events.CheckFieldExists(formContext, fieldVerified)) {
                            formContext.getAttribute(fieldVerified).setValue(false);
                        }
                        formContext.ui.setFormNotification("Selected " + field + " Account is not connected to Sales Org. Please submit an extension request for the selected SAP account.", "WARNING", field + "warning");
                    }
                },
                function (error) {
                    Xrm.Utility.alertDialog(error.message);
                }
            );

        }
        else {
            if (fieldVerified !== " " && CommonForm.Events.CheckFieldExists(formContext, fieldVerified)) {
                formContext.getAttribute(fieldVerified).setValue(false);
            }
            formContext.ui.clearFormNotification(field + "warning");
            formContext.ui.clearFormNotification(field + "error");


        }
    },
    //DYNCRM-23337 - Validate SalesOrg Accounts
    RetrieveChildOpportunitiesForValidation: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var oppo = formContext.data.entity.getId();
        var oppo_id = oppo.replace('{', '').replace('}', '');

        Xrm.WebApi.retrieveMultipleRecords("opportunity", "?$select=name,_niq_billtoparty_value,_niq_deliverytoparty_value,_niq_salesorgid_value,_niq_soldtoparty_value&$filter=_niq_hostopportunity_value eq '" + oppo_id + "'").then(
            function success(results) {
                console.log(results);
                for (var i = 0; i < results.entities.length; i++) {
                    var result = results.entities[i];
                    var opportunityid = result["opportunityid"]; // Guid
                    var billtoparty = result["_niq_billtoparty_value"]; // Lookup
                    var deliverytoparty = result["_niq_deliverytoparty_value"]; // Lookup
                    var soldtoparty = result["_niq_soldtoparty_value"]; // Lookup
                    var sorgid = result["_niq_salesorgid_value"];
                    var name = result["name"];
                    var stp = "Sold To Party" + name;
                    var dtp = "Delievery To Party" + name;
                    var btp = "Bill To Party" + name;
                    OpportunityForm.Events.SalesOrgAccountsValidation(executionContext, "niq_soldtoparty", "Sold To Party", soldtoparty, sorgid, stp, name);
                    OpportunityForm.Events.SalesOrgAccountsValidation(executionContext, "niq_deliverytoparty", "Delievery To Party", deliverytoparty, sorgid, dtp, name);
                    OpportunityForm.Events.SalesOrgAccountsValidation(executionContext, "niq_billtoparty", "Bill To Party", billtoparty, sorgid, btp, name);
                }
            },
            function (error) {
                console.log(error.message);
            }
        );
    },
    SalesOrgAccountsValidation: function (executionContext, fieldName, field, fieldid, salesorgid, notificationid, name) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var fieldVerified = " ";
        switch (fieldName) {
            case "niq_soldtoparty": fieldVerified = "niq_soldtopartyverified";
                break;
            case "niq_billtoparty": fieldVerified = "niq_billtopartyverified";
                break;
            case "niq_deliverytoparty": fieldVerified = "niq_delivertopartyverified";
                break;
            default: fieldVerified = " ";
                break;
        }
        if (salesorgid != null && fieldid != null) {
            var salesOrgId = salesorgid;
            var fieldId = fieldid;
            salesOrgId = salesOrgId.replace("{", "").replace("}", "");
            fieldId = fieldId.replace("{", "").replace("}", "");

            Xrm.WebApi.online.retrieveMultipleRecords("niq_saleorgassignment", "?$select=niq_accountblocked&$filter=_niq_salesorg_value eq " + salesOrgId + " and  _niq_account_value eq " + fieldId + "&$top=1").then(
                function success(results) {
                    if (results.entities.length) {

                        var accBlocked = results.entities[0]["niq_accountblocked"];
                        if (accBlocked) {
                            if (fieldVerified !== " " && CommonForm.Events.CheckFieldExists(formContext, fieldVerified)) {
                                formContext.getAttribute(fieldVerified).setValue(false);
                            }
                            formContext.ui.setFormNotification(name + " Child Opportunity - Selected " + field + "Account is blocked for Sales Org. Please submit an unblocking request for the selected SAP account.", "ERROR", notificationid + "error");
                        } else {
                            if (fieldVerified !== " " && CommonForm.Events.CheckFieldExists(formContext, fieldVerified)) {
                                formContext.getAttribute(fieldVerified).setValue(true);
                                OpportunityForm.Events.RefreshRibbon(executionContext);
                            }
                        }
                    }
                    else {
                        if (fieldVerified !== " " && CommonForm.Events.CheckFieldExists(formContext, fieldVerified)) {
                            formContext.getAttribute(fieldVerified).setValue(false);
                        }
                        formContext.ui.setFormNotification(name + " Child Opportunity - Selected " + field + " Account is not connected to Sales Org. Please submit an extension request for the selected SAP account.", "WARNING", notificationid + "warning");
                    }
                },
                function (error) {
                    Xrm.Utility.alertDialog(error.message);
                }
            );

        }
        else {
            if (fieldVerified !== " " && CommonForm.Events.CheckFieldExists(formContext, fieldVerified)) {
                formContext.getAttribute(fieldVerified).setValue(false);
            }
            formContext.ui.clearFormNotification(notificationid + "warning");
            formContext.ui.clearFormNotification(notificationid + "error");
        }
    },
    OnChangeStageToNegotiation: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.data.process.addOnStageChange(this.OnBpfStageChange);
    },
    OnChangeContractAction: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        //if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete")) {
        //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").setDisabled(true);
        //}
        if (formContext.getAttribute("niq_opportunitytype").getValue() == 2 && formContext.getAttribute("niq_existingcontractaction").getValue() == 4) {
            formContext.getControl("header_process_niq_isdeferredrevenueclicked").setDisabled(true);
        }
        else {
            if (formContext.getControl("header_process_niq_isdeferredrevenueclicked") != null)
                formContext.getControl("header_process_niq_isdeferredrevenueclicked").setVisible(false);
        }
        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_tempeoafinallyexecutedagreementprovided")) {
            formContext.getControl("header_process_niq_tempeoafinallyexecutedagreementprovided").setDisabled(true);
        }
        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_soldtopartyverified")) {
            formContext.getControl("header_process_niq_soldtopartyverified").setDisabled(true);
        } if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_billtopartyverified")) {
            formContext.getControl("header_process_niq_billtopartyverified").setDisabled(true);
        } if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_delivertopartyverified")) {
            formContext.getControl("header_process_niq_delivertopartyverified").setDisabled(true);
        }
        if (CommonForm.Events.CheckControlExists(formContext, "header_process_totalamount")) {
            formContext.getControl("header_process_totalamount").setDisabled(true);
        }
        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_contractstartdate")) {
            formContext.getControl("header_process_niq_contractstartdate").setDisabled(true);
        }
        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_contractenddate")) {
            formContext.getControl("header_process_niq_contractenddate").setDisabled(true);
        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_opportunitytype")) {
            var oppoType = formContext.getAttribute("niq_opportunitytype").getValue();
            if (oppoType === 2) {
                if (CommonForm.Events.CheckValueExists(formContext, "niq_existingcontractaction")) {
                    var contractaction = formContext.getAttribute("niq_existingcontractaction").getValue();
                    ////if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete") && (CommonForm.Events.CheckFieldExists(formContext, "niq_valueofapicola")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_valueofpricechange")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_valueofproductenhancements")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_valueofscopechange")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_onetimefees")) && (CommonForm.Events.CheckValueExists(formContext, "niq_existingcontractannualvalue")) && (CommonForm.Events.CheckValueExists(formContext, "niq_newcontractannualvalue"))) {
                    //    var sumOfApiCola = parseFloat((Math.round(formContext.getControl("niq_valueofapicola").getAttribute().getValue() * 100) / 100).toFixed(2));
                    //    var sumOfPriceChange = parseFloat((Math.round(formContext.getControl("niq_valueofpricechange").getAttribute().getValue() * 100) / 100).toFixed(2));
                    //    var sumOfProductEnhancement = parseFloat((Math.round(formContext.getControl("niq_valueofproductenhancements").getAttribute().getValue() * 100) / 100).toFixed(2));
                    //    var sumOfScopeChange = parseFloat((Math.round(formContext.getControl("niq_valueofscopechange").getAttribute().getValue() * 100) / 100).toFixed(2));
                    //    var sumOfOnetimefee = parseFloat((Math.round(formContext.getControl("niq_onetimefees").getAttribute().getValue() * 100) / 100).toFixed(2));
                    //    var sumServices = parseFloat((Math.round((sumOfApiCola + sumOfPriceChange + sumOfProductEnhancement + sumOfScopeChange + sumOfOnetimefee) * 100) / 100).toFixed(2));
                    //    var changeincontractvalue = parseFloat((Math.round(formContext.getControl("niq_changeincontractvalue").getAttribute().getValue() * 100) / 100).toFixed(2));

                    //    //if ((sumServices === changeincontractvalue) && CommonForm.Events.CheckValueExists(formContext, "niq_existingcontractannualvalue") && (formContext.getControl("niq_existingcontractannualvalue").getAttribute().getValue() !== 0) && CommonForm.Events.CheckValueExists(formContext, "niq_newcontractannualvalue")) {
                    //    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setValue(true);
                    //    //}
                    //    //else {
                    //    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setValue(false);

                    //    //}

                    //}
                    //else if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete")) {
                    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").setVisible(false);
                    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setRequiredLevel("none");
                    //    if (formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute() != null && formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().getValue())
                    //        formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setValue(false);
                    //}
                    if (contractaction === 2 || contractaction === 3) {
                        if (CommonForm.Events.CheckControlExists(formContext, "niq_contractdecision")) {

                            if (formContext.getControl("niq_contractdecision").getAttribute().getValue() !== 100000000) {
                                formContext.getControl("niq_contractdecision").addOption({ value: 100000000, text: 'No Changes To Existing Contract' });
                                formContext.getControl("niq_contractdecision").getAttribute().setValue(100000000);
                            }
                            else {
                                formContext.getControl("niq_contractdecision").removeOption(100000000);
                                formContext.getControl("niq_contractdecision").addOption({ value: 100000000, text: 'No Changes To Existing Contract' });
                                formContext.getControl("niq_contractdecision").getAttribute().setValue(100000000);
                            }

                        }


                    }
                    else if (CommonForm.Events.CheckControlExists(formContext, "niq_contractdecision")) {

                        formContext.getControl("niq_contractdecision").removeOption(100000000);
                    }
                    //if ((contractaction === 1 || contractaction === 2 || contractaction === 4) && CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete")) {
                    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").setVisible(true);
                    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setRequiredLevel("required");
                    //}
                    //else if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete")) {
                    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").setVisible(false);
                    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setRequiredLevel("none");
                    //}
                }
                else {
                    if (CommonForm.Events.CheckFieldExists(formContext, "niq_contractdecision")) {

                        formContext.getControl("niq_contractdecision").removeOption(100000000);
                    }
                    //if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete")) {
                    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").setVisible(false);
                    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setRequiredLevel("none");

                    //}
                }

            }
            else {
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_contractdecision")) {

                    formContext.getControl("niq_contractdecision").removeOption(100000000);
                }
                //if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete")) {
                //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").setVisible(false);
                //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setRequiredLevel("none");

                //}
            }
        }
        else {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_contractdecision")) {

                formContext.getControl("niq_contractdecision").removeOption(100000000);
            }
            //if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete")) {
            //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").setVisible(false);
            //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setRequiredLevel("none");

            //}
        }
    },


    OnChangeOfStage: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        if ((!CommonForm.Events.CheckValueExists(formContext, "niq_originalopportunityid")) && (!CommonForm.Events.CheckValueExists(formContext, "niq_ultimateoriginalopportunityid")) && formContext.getAttribute("statecode") != null && (formContext.getAttribute("statecode").getValue() === 1)) {
            CommonForm.Events.ShowHideSections(formContext, "Summary", "Summary_section_14", true);
        }

        else {
            CommonForm.Events.ShowHideSections(formContext, "Summary", "Summary_section_14", false);
        }
    },
    HideandShowOppoProductEnhancementTab: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        if ((CommonForm.Events.CheckValueExists(formContext, "niq_opportunitytype")) && (CommonForm.Events.CheckValueExists(formContext, "niq_existingcontractaction"))) {
            var oppoType = formContext.getAttribute("niq_opportunitytype").getValue();
            var contractaction = formContext.getAttribute("niq_existingcontractaction").getValue();
            if (oppoType === 2 && contractaction !== 3) {

                CommonForm.Events.ShowHideTabs(formContext, "tab_9", true);
            }

            else {
                CommonForm.Events.ShowHideTabs(formContext, "tab_9", false);
            }
        }
    },
    OnBpfStageChange: function (executionContext) {
        "use strict";


        var formContext = executionContext.getFormContext();
        var activeProcess = (formContext.data.process.getActiveProcess() !== null) ? (formContext.data.process.getActiveProcess().getName()) : null;
        var activeStage = (formContext.data.process.getActiveStage() !== null) ? (formContext.data.process.getActiveStage().getName()) : null;
        if ((activeProcess === "Opportunity Business Process Flow") && ((activeStage === "Negotiation") || (activeStage === "Pre-Proposal") || (activeStage === "Proposal"))) {
            var oppoId = formContext.data.entity.getId().replace("{", "").replace("}", "");
            formContext.data.refresh(true).then(function refreshOppo() {
                var entityFormOptions = {};
                entityFormOptions["entityName"] = "opportunity";
                entityFormOptions["entityId"] = oppoId;
                // Open the form.
                Xrm.Navigation.openForm(entityFormOptions);
            });
        }


    },
    /*
    ExistingContractAnnualValueVisibility: function (executionContext) {
        "use strict";
        //show/hide Existing Contract Annual Value on Opportunity form
        var formContext = executionContext.getFormContext();
        if ((CommonForm.Events.CheckFieldExists(formContext, "niq_opportunitytype")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_existingcontractannualvalue"))) {
            //Getting Opportunity Type Value
            var opportunityType = formContext.getAttribute("niq_opportunitytype").getValue();
            //Checking Opportunity Type is equal to Existing Contract Management Value 
            if ((opportunityType !== null) && (opportunityType === 2)) {
                formContext.getControl("niq_existingcontractannualvalue").setVisible(true);
                formContext.getAttribute("niq_existingcontractannualvalue").setRequiredLevel("required");
                if (CommonForm.Events.CheckControlExists(formContext, "niq_existingcontractannualvalue1")) {
                    if (CommonForm.Events.CheckFieldExists(formContext, "niq_existingcontractaction")) {
                        //Getting Existing Contract action Value
                        var contractAction = formContext.getAttribute("niq_existingcontractaction").getValue();
                        //Checking Existing Contract Action is not Instruct SAP revenue booking for existing evergreen contract
                        if ((contractAction === 1) || (contractAction === 2) || (contractAction === 4)) {
                            formContext.getControl("niq_existingcontractannualvalue1").setVisible(true);
                        }
                        else {
                            formContext.getControl("niq_existingcontractannualvalue1").setVisible(false);
                        }
                    }
                }
            }
            else {
                formContext.getControl("niq_existingcontractannualvalue").setVisible(false);
                formContext.getAttribute("niq_existingcontractannualvalue").setRequiredLevel("none");
                formContext.getAttribute("niq_existingcontractannualvalue").setValue(null);
            }
        }
    },
    */
    OnChangeOfApprovalStatusShowNotification: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_approvalstatus")) {
            var approvalstatus = formContext.getAttribute("niq_approvalstatus").getValue();


            if (approvalstatus === 100000001 || approvalstatus === 100000000) {
                formContext.ui.setFormNotification("Opportunity was submitted to Gatekeeper for approval. You need to recall it to be able to edit it or any records related to it.", "INFO", "onChangeOfApprovalStatusShowNotification");
                CommonForm.Events.EnableOrDisableSection(formContext, "tab_9", "tab_9_section_1", true);

            }
            else {
                formContext.ui.clearFormNotification("onChangeOfApprovalStatusShowNotification");
                CommonForm.Events.EnableOrDisableSection(formContext, "tab_9", "tab_9_section_1", false);
            }
        }
    },
    SetDefaultValueofPE: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_valueofproductenhancements")) {
            if (!CommonForm.Events.CheckValueExists(formContext, "niq_valueofproductenhancements")) {
                formContext.getAttribute("niq_valueofproductenhancements").setValue(0);
                formContext.data.refresh(true);
            }
        }
    },
    ClearCurrency: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "transactioncurrencyid")) {
            var formType = formContext.ui.getFormType();
            if (formType === 1 && formContext.getAttribute("niq_opportunitytype").getValue() !== 2) {
                formContext.getAttribute("transactioncurrencyid").setValue(null);
            }
        }
    },
    bPFStageErrorNotification: function (executionContext) {
        "use strict";
        var negotiationStageErrorMessage = "Please proceed to the main quote first and select values for all the mandatory Quote product characteristics for the quote products. You will be able to move opportunity to Closed Won in Review stage or resubmit to Gatekeeper after doing that.";
        var closeWonInReviewStageErrorMessage = "FAR got Rejected as main quote related mandatory Quote product characteristics values are not added. Please add mandatory data and resubmit for approval.";
        var formContext = executionContext.getFormContext();
        formContext.ui.clearFormNotification("onNegotiationMQPC");
        formContext.ui.clearFormNotification("onClosedWonInReviewMQPC");
        if (formContext.data.process.getActiveStage().getName().toLowerCase() === "negotiation" && formContext.getAttribute("niq_mandatorycharvaluesadded").getValue() === false) {
            formContext.ui.setFormNotification(negotiationStageErrorMessage, "WARNING", "onNegotiationMQPC");
        }
        //Mandatory Char Values Added is false and BPF is in Close won - in review stage, remove the Approve option value and Promp user for Rejection.
        else if (formContext.data.process.getActiveStage().getName().toLowerCase() === "closed won - in review" && formContext.getAttribute("niq_mandatorycharvaluesadded").getValue() === false &&
            formContext.getAttribute("niq_approvalstatus").getValue() === 100000003) {
            formContext.ui.setFormNotification(closeWonInReviewStageErrorMessage, "ERROR", "onClosedWonInReviewMQPC");
        }
    },
    TempOrFinallyExecutedURLValidation: async function (executionContext) {
        formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_mainquoteid")) {
            var quoteId = formContext.getAttribute("niq_mainquoteid").getValue()[0].id;
            await Xrm.WebApi.online.retrieveRecord("quote", quoteId, "?$select=niq_clmgate2").then(
                function success(result) {
                    var clmgate2 = result["niq_clmgate2"];
                    if (clmgate2 === true) {
                        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_signedagreementcreatedandexecutedfromquot")) {
                            formContext.getControl("header_process_niq_signedagreementcreatedandexecutedfromquot").getAttribute().setRequiredLevel("required");
                            formContext.getControl("header_process_niq_signedagreementcreatedandexecutedfromquot").setVisible(true);
                        }
                        formContext.getControl("header_process_niq_tempeoafinallyexecutedagreementprovided").getAttribute().setRequiredLevel("none");
                        formContext.getControl("header_process_niq_tempeoafinallyexecutedagreementprovided").setVisible(false);
                    } else if (clmgate2 === false || clmgate2 === null) {
                        formContext.getControl("header_process_niq_signedagreementcreatedandexecutedfromquot").getAttribute().setRequiredLevel("none");
                        formContext.getControl("header_process_niq_signedagreementcreatedandexecutedfromquot").setVisible(false);
                        formContext.getControl("header_process_niq_tempeoafinallyexecutedagreementprovided").setVisible(true);
                        formContext.getControl("header_process_niq_tempeoafinallyexecutedagreementprovided").getAttribute().setRequiredLevel("required");
                    }
                },
                function (error) { }
            );
        }
    },
    SetURLCheckboxNegotiationStage: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_mainquoteid")) {
            var quoteId = formContext.getAttribute("niq_mainquoteid").getValue()[0].id;
            Xrm.WebApi.online.retrieveRecord("quote", quoteId, "?$select=niq_congaagreementstatus,niq_finallyexecutedagreementurl,niq_clmgate2").then(
                function success(result) {
                    var clmgate2 = result["niq_clmgate2"];
                    var congaagreementstatus = result["niq_congaagreementstatus"];
                    var finallyexecutedagreementurl = result["niq_finallyexecutedagreementurl"];
                    if (clmgate2 === true) {
                        if (CommonForm.Events.CheckValueExists(formContext, "niq_finallyexecutedagreementurl") || (CommonForm.Events.CheckValueExists(formContext, "niq_tempeoaurl")) || (congaagreementstatus === 100000005 && finallyexecutedagreementurl !== null)) {
                            if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_signedagreementcreatedandexecutedfromquot")) {
                                formContext.getControl("header_process_niq_signedagreementcreatedandexecutedfromquot").getAttribute().setValue(true);
                            } else {
                                formContext.getControl("header_process_niq_signedagreementcreatedandexecutedfromquot").getAttribute().setValue(false);
                            }
                        } else {
                            formContext.getControl("header_process_niq_signedagreementcreatedandexecutedfromquot").getAttribute().setValue(false);
                        }
                    }
                },
                function (error) { }
            );
        }
    },

    SalesOrgSalesGroupRequired: async function (executionContext) {
        "use strict";
        //make Sales Org-Sales Group field required for valid Sales Org
        // get the form context
        var formContext = executionContext.getFormContext();

        if (CommonForm.Events.CheckFieldExists(formContext, "niq_salesorgid") && (CommonForm.Events.CheckFieldExists(formContext, "niq_salesgroupsalesorgid")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_originalopportunityid"))) {
            var salesorgvalue = formContext.getAttribute("niq_salesorgid").getValue();
            var originalOppo = formContext.getAttribute("niq_originalopportunityid").getValue();
            var BU = formContext.getAttribute("niq_creatorsbusinessfunctionalunit").getValue();
            formContext.getAttribute("niq_salesgroupsalesorgid").setRequiredLevel("none");
            if (CommonForm.Events.CheckValueExists(formContext, "niq_salesorgid")) {
                var salesOrg = formContext.getAttribute("niq_salesorgid").getValue();
                var salesOrg_id = salesOrg[0].id.replace('{', '').replace('}', '');
                // retrieve salesorgcode
                await Xrm.WebApi.retrieveRecord("niq_salesorg", salesOrg_id, "?$select=niq_salesorgcode").then(
                    async function success(result) {
                        if (result["niq_salesorgcode"] !== null) {
                            var salesOrgCode = result.niq_salesorgcode;
                            //retrieve Sales Org List_Oppoortunity_Lead configurationsetting
                            await Xrm.WebApi.online.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_to&$filter=niq_name eq 'Sales%20Org%20List_Oppoortunity_Lead'").then(
                                function success(results) {
                                    if (result["niq_salesorgcode"] !== null) {
                                        var niq_to = results.entities[0]["niq_to"];
                                        if (niq_to !== null) {
                                            if ((niq_to.includes(salesOrgCode)) && (BU === null)) {
                                                formContext.getAttribute("niq_salesgroupsalesorgid").setRequiredLevel("required");
                                                if (originalOppo === null && BU === null) {
                                                    formContext.getAttribute("niq_salesgroupsalesorgid").setRequiredLevel("required");
                                                }
                                                else {
                                                    formContext.getAttribute("niq_salesgroupsalesorgid").setRequiredLevel("none");
                                                }

                                            }
                                            else {
                                                formContext.getAttribute("niq_salesgroupsalesorgid").setRequiredLevel("none");

                                                //formContext.getAttribute("niq_salesgroupsalesorgid").setValue(true);
                                            }

                                        }
                                    }
                                },
                                function (error) {

                                }
                            );
                        }
                    },
                    function (error) {

                    }
                );
            }
        }
    },

    OnCreateofOpportunity: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "ownerid")) {
            var owner = formContext.getAttribute("ownerid").getValue();
            var ownerId = owner[0].id.replace('{', '').replace('}', '');
            Xrm.WebApi.retrieveRecord("systemuser", ownerId, "?$select=niq_businessfunctionalunit").then(
                function success(result) {
                    console.log(result);
                    var niq_businessfunctionalunit = result["niq_businessfunctionalunit"];
                    var niq_businessfunctionalunit_formatted = result["niq_businessfunctionalunit@OData.Community.Display.V1.FormattedValue"];
                    if (niq_businessfunctionalunit === 100000012) {
                        formContext.getAttribute("niq_creatorsbusinessfunctionalunit").setValue(niq_businessfunctionalunit_formatted);

                    }
                    else {
                        formContext.getAttribute("niq_creatorsbusinessfunctionalunit").setValue(null);

                    }
                },
                function (error) {
                    console.log(error.message);
                }
            );

        }

    },


    PopulatingValueOfOppo: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if ((CommonForm.Events.CheckFieldExists(formContext, "niq_originalopportunityid")) && (CommonForm.Events.CheckValueExists(formContext, "niq_originalopportunityid")) && (CommonForm.Events.CheckValueExists(formContext, "niq_opportunitytype")) && (CommonForm.Events.CheckValueExists(formContext, "niq_existingcontractaction")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_finallyexecutedagreementurl"))) {
            var oppotype = formContext.getAttribute("niq_opportunitytype").getValue();
            var originaloppo = formContext.getAttribute("niq_originalopportunityid").getValue();
            var originaloppo_id = originaloppo[0].id.replace('{', '').replace('}', '');
            var action = formContext.getAttribute("niq_existingcontractaction").getValue();
            Xrm.WebApi.online.retrieveRecord("opportunity", originaloppo_id, "?$select=niq_finallyexecutedagreementurl").then(
                function success(result) {
                    if (oppotype === 2) {
                        if ((action === 2) || (action === 3)) {
                            if ((result["niq_finallyexecutedagreementurl"] !== null)) {
                                var finallyexecutedagreementurl = result["niq_finallyexecutedagreementurl"];
                                formContext.getAttribute("niq_finallyexecutedagreementurl").setValue(finallyexecutedagreementurl);
                            }
                        }
                        else {
                            formContext.getAttribute("niq_finallyexecutedagreementurl").setValue(null);
                        }
                    }
                    else {
                        formContext.getAttribute("niq_finallyexecutedagreementurl").setValue(null);
                    }

                },
                function (error) {
                    Xrm.Utility.alertDialog(error.message);
                }
            );
        }
    },
    TothrowerrorforAgreementtypeandLanguage: function (executionContext) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var stage1 = CommonForm.Events.CheckValueExists(formContext, "niq_stage") ? formContext.getAttribute("niq_stage").getValue() : "";
            var preventSave = false;
            var args = executionContext.getEventArgs();
            if ((stage1 !== "Proposal" && stage1 !== "Pre-Proposal" && stage1 !== null)) {
                var quote = formContext.getAttribute("niq_mainquoteid").getValue();
                var quoteId = quote[0].id;
                quoteId = quoteId.replace("{", "");
                quoteId = quoteId.replace("}", "");

                var req = new XMLHttpRequest();
                req.open("GET", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.1/quotes(" + quoteId + ")?$select=niq_agreementtype , niq_agreementlanguage , niq_clmgate1", false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var result = JSON.parse(this.response);
                            var agreementType = result["niq_agreementtype"];
                            var agreementLanguage = result["niq_agreementlanguage"];
                            var clmgate1 = result["niq_clmgate1"];
                            if ((clmgate1 === true) && (agreementLanguage === null)) {
                                var niqerror = "Agreement Type and Agreement Language must be filled out on the main quote.";
                                formContext.ui.setFormNotification(niqerror, "ERROR", "agreementerror");
                                args.preventDefault();
                            }
                            else {
                                formContext.ui.clearFormNotification("agreementerror");
                            }

                        }
                        else {
                            Xrm.Utility.alertDialog(this.statusText);
                        }
                    }
                };
                req.send();

            }
        }
        catch (e) {
            throw e.message;
        }


    },
    TothrowerrorforAgreementtype: function (executionContext) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var stage2 = CommonForm.Events.CheckValueExists(formContext, "niq_stage") ? formContext.getAttribute("niq_stage").getValue() : "";
            var preventSave = false;
            var args = executionContext.getEventArgs();
            if (args.getDirection() === "Next") {
                if (stage2 === "Negotiation") {
                    var quote = formContext.getAttribute("niq_mainquoteid").getValue();
                    var quoteId = quote[0].id;
                    quoteId = quoteId.replace("{", "");
                    quoteId = quoteId.replace("}", "");
                    var req = new XMLHttpRequest();
                    req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/quotes(" + quoteId + ")?$select=niq_agreementtype,niq_blockedproductdesc", false);
                    req.setRequestHeader("OData-MaxVersion", "4.0");
                    req.setRequestHeader("OData-Version", "4.0");
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req.onreadystatechange = null;
                            if (this.status === 200) {
                                var result = JSON.parse(this.response);
                                var agreementType = result["niq_agreementtype"];
                                if (agreementType === null) {
                                    var niqerror = "Agreement Type must be populated on the main quote before you can move past Negotiation stage";
                                    formContext.ui.setFormNotification(niqerror, "ERROR", "agreementerror");
                                    args.preventDefault();
                                    QuoteForm.Events.setRequiredAgreementType(executionContext);

                                }
                                else {
                                    formContext.ui.clearFormNotification("agreementerror");
                                }
                            }
                            else {
                                Xrm.Utility.alertDialog(this.statusText);
                            }
                        }
                    };
                    req.send();
                }
            }

        }
        catch (e) {
            throw e.message;
        }
    },


    TothrowerrorforHostOpportunity: function (executionContext) {
        "use strict";
        try {
            return;
            var formContext = executionContext.getFormContext();
            var targetOppId = formContext.data.entity.getId().replace("{", "").replace("}", "");
            var isHostOpp = formContext.getAttribute("niq_ishostopportunity").getValue();
            var hostOpp = formContext.getAttribute("niq_hostopportunity").getValue();
            var revShareDeal = formContext.getAttribute("niq_revenuesharedeal").getValue();

            var stage = CommonForm.Events.CheckValueExists(formContext, "niq_stage") ? formContext.getAttribute("niq_stage").getValue() : "";
            var preventSave = false;
            var args = executionContext.getEventArgs();
            if (args.getDirection() === "Next") {
                if (stage === "Negotiation") {
                    if (isHostOpp == 1 && hostOpp == null && revShareDeal == 1) {
                        var fetchXmlChildOpp = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
                            "<entity name='opportunity' >" +
                            "<attribute name='name' />" +
                            "<attribute name='niq_stage' />" +
                            "<attribute name='statecode' />" +
                            "<attribute name='niq_opportunitynumber' />" +
                            "<attribute name='opportunityid' />" +
                            "<attribute name='niq_ishostopportunity' />" +
                            "<attribute name='niq_hostopportunity' />" +
                            "<attribute name='niq_approvalstatus' />" +
                            "<attribute name='niq_revenuesharedeal' />" +
                            "<filter type='and' >" +
                            "<condition attribute='niq_hostopportunity' operator='eq' uitype='opportunity' value='" + targetOppId + "' />" +
                            "<condition attribute='statecode' operator='eq' value='0' />" +
                            "</filter>" +
                            "</entity>" +
                            "</fetch>";
                        var serverUrl = Xrm.Utility.getGlobalContext().getClientUrl();
                        var fetchXmlResults = GetCRMWebAPI.Methods.GetFetchRecords(serverUrl, fetchXmlChildOpp, "opportunities");
                        if (fetchXmlResults !== null && fetchXmlResults.value.length > 0) {
                            var oppNumber = '';
                            for (var i = 0; i < fetchXmlResults.value.length; i++) {
                                if (fetchXmlResults.value[i].niq_stage !== "Closed Won - In Review" && (fetchXmlResults.value[i].niq_approvalstatus === 100000001 || fetchXmlResults.value[i].niq_approvalstatus !== null) && fetchXmlResults.value[i].statecode === 0) {
                                    oppNumber += fetchXmlResults.value[i].niq_opportunitynumber + ", ";
                                }
                            }
                            if (oppNumber != null && oppNumber.length > 0) {
                                oppNumber = oppNumber.substring(0, oppNumber.length - 2);
                                var hostOppErrMsg = "These child opportunities " + oppNumber + " have not been submitted to gatekeeper. Please send all child opportunities to the gatekeeper before sending the host opportunity to gatekeeper";
                                formContext.ui.setFormNotification(hostOppErrMsg, "ERROR", "hostopportunityerror");
                                args.preventDefault();
                            }
                            else {
                                formContext.ui.clearFormNotification("hostopportunityerror");
                            }
                        }
                    }
                }
            }
        }
        catch (e) {
            throw e.message;
        }
    },

    showErrorforRevenueSchedules: function (executionContext) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var stage1 = CommonForm.Events.CheckValueExists(formContext, "niq_stage") ? formContext.getAttribute("niq_stage").getValue() : "";
            var preventSave = true;
            var args = executionContext.getEventArgs();
            if ((stage1 == "Proposal" || stage1 == "Negotiation") && stage1 !== null) {
                var quote = formContext.getAttribute("niq_mainquoteid").getValue();
                var quoteId = quote[0].id;
                quoteId = quoteId.replace("{", "");
                quoteId = quoteId.replace("}", "");

                var req = new XMLHttpRequest();
                req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/quotes(" + quoteId + ")?$select=niq_elrevenueschedulecomplete,niq_elbillingschedulecomplete,niq_contractstartdate,niq_nonstandardbillingterm", false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var result = JSON.parse(this.response);
                            var revenueSchedule = result["niq_elrevenueschedulecomplete"];
                            var billingSchedule = result["niq_elbillingschedulecomplete"];
                            var nonStandardBillingTerm = result["niq_nonstandardbillingterm"];
                            var date = result["niq_contractstartdate"];

                            var fetchXML = `<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
                            <entity name="quotedetail">
                              <attribute name="productdescription" />
                              <attribute name="quotedetailid" />
                              <attribute name="niq_revenueschedulestatus" />
                              <attribute name="niq_billingschedulestatus" />
                              <order attribute="niq_brandid" descending="false" />
                              <filter type="and">
                                <filter type="or">
                                  <condition attribute="niq_billingschedulestatus" operator="eq" value="610570001" />
                                  <condition attribute="niq_billingschedulestatus" operator="eq" value="610570000" />
                                  <condition attribute="niq_revenueschedulestatus" operator="eq" value="610570000" />
                                  <condition attribute="niq_revenueschedulestatus" operator="eq" value="610570001" />
                                </filter>
                                <condition attribute="quoteid" operator="eq" uitype="quote" value="${quoteId}" />
                              </filter>
                            </entity>
                          </fetch>`;
                            var fetchResults = GetCRMWebAPI.Methods.GetFetchRecords(Xrm.Utility.getGlobalContext().getClientUrl(), fetchXML, "quotedetails");
                            //var missingRevenueScheduleQPcount = fetchResults.value.filter(item =>
                            //    item.niq_revenueschedulestatus === 610570000 ||
                            //    item.niq_revenueschedulestatus === 610570001 ||
                            //    item.niq_revenueschedulestatus === 610570002
                            //).length;
                            if (stage1 == "Proposal") {
                                if (args.getDirection() === "Next" && (fetchResults !== null && fetchResults.value.length > 0) && date !== null) {
                                    Xrm.Navigation.openErrorDialog({ message: "Please return to Quote Product tab and complete your Revenue or Billing schedule inputs prior to proceeding further." });
                                    args.preventDefault();
                                }
                                //else if (args.getDirection() === "Next"  && (missingRevenueScheduleQPcount > 0) && date !== null) {
                                //    Xrm.Navigation.openErrorDialog({ message: "Please return to Quote Product tab and complete your Revenue or Billing schedule inputs prior to proceeding further." });
                                //    args.preventDefault();
                                //}
                            }
                            else { //for negotiation stage
                                if (args.getDirection() === "Next" && (fetchResults !== null && fetchResults.value.length > 0) && date !== null) {
                                    Xrm.Navigation.openErrorDialog({ message: "Please return to Quote Product tab and complete your Revenue or Billing schedule inputs prior to proceeding further." });
                                    args.preventDefault();
                                }
                            }
                        }
                        else {
                            Xrm.Utility.alertDialog(this.statusText);
                        }

                    }
                };
                req.send();

            }
        }
        catch (e) {
            throw e.message;
        }

    },
    showNotificationforRevenueSchedules: function (executionContext) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var quote = formContext.getAttribute("niq_mainquoteid").getValue();
            if (quote === null) {
                return;
            }
            var quoteId = quote[0].id;
            quoteId = quoteId.replace("{", "");
            quoteId = quoteId.replace("}", "");

            var req = new XMLHttpRequest();
            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/quotes(" + quoteId + ")?$select=niq_elrevenueschedulecomplete,niq_contractstartdate", false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var result = JSON.parse(this.response);
                        var revenueSchedule = result["niq_elrevenueschedulecomplete"];
                        var date = result["niq_contractstartdate"];
                        var currentStage = formContext.data.process.getActiveStage().getName();

                        var targetOppId = formContext.data.entity.getId().replace("{", "").replace("}", "");
                        var fetchXML = `<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
                          <entity name="quotedetail">
                          <attribute name="quotedetailname" />
                          <attribute name="quotedetailid" />
                          <order attribute="niq_brandid" descending="false" />
                          <filter type="or">
                            <condition attribute="niq_revenueschedulestatus" operator="eq" value="610570000" />
                            <condition attribute="niq_revenueschedulestatus" operator="eq" value="610570001" />
                          </filter>
                          <link-entity name="quote" from="quoteid" to="quoteid" link-type="inner" alias="af">
                            <filter type="and">
                              <condition attribute="quoteid" operator="eq" uitype="quote" value="${quoteId}" />
                            </filter>
                            <link-entity name="opportunity" from="opportunityid" to="opportunityid" link-type="inner" alias="ag">
                              <filter type="and">
                                <condition attribute="opportunityid" operator="eq" uitype="opportunity" value="${targetOppId}" />
                              </filter>
                            </link-entity>
                          </link-entity>
                        </entity>
                      </fetch>`;

                        var fetchResults = GetCRMWebAPI.Methods.GetFetchRecords(Xrm.Utility.getGlobalContext().getClientUrl(), fetchXML, "quotedetails");

                        if ((currentStage != 'Closed Won - Approved' && currentStage != 'Closed Lost') && (fetchResults !== null && fetchResults.value.length > 0) && date !== null) {
                            var niqerror = "There is still unscheduled revenue on at least one product within the main Quote. Check quote products with \"Revenue schedule status\" = \"Incomplete data\" or \"Incomplete schedules (manual)\" and make sure that these products have dates, revenue frequency and revenue schedules present. If you face a technical issue with populating this data, raise a Help & Support request.";
                            formContext.ui.setFormNotification(niqerror, "ERROR", "scheduleerror");

                        }
                        else {
                            formContext.ui.clearFormNotification("scheduleerror");
                        }

                    }
                    else {
                        Xrm.Utility.alertDialog(this.statusText);
                    }
                }
            };
            req.send();


        }
        catch (e) {
            throw e.message;
        }

    },

    showNotificationforBillingSchedules: function (executionContext) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var quote = formContext.getAttribute("niq_mainquoteid").getValue();
            var targetOppId = formContext.data.entity.getId().replace("{", "").replace("}", "");
            var stage = formContext.getAttribute("niq_stage").getValue();
            if (quote === null) {
                return;
            }
            var quoteId = quote[0].id;
            quoteId = quoteId.replace("{", "");
            quoteId = quoteId.replace("}", "");
            var req = new XMLHttpRequest();
            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/quotes(" + quoteId + ")?$select=niq_elbillingschedulecomplete,niq_contractstartdate,niq_nonstandardbillingterm", false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var result = JSON.parse(this.response);
                        var billingSchedule = result["niq_elbillingschedulecomplete"];
                        var nonStandardBillingTerm = result["niq_nonstandardbillingterm"];

                        var date = result["niq_contractstartdate"];
                        var fetchXML = `<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
                        <entity name="quotedetail">
                          <attribute name="quotedetailname" />
                          <attribute name="quotedetailid" />
                          <order attribute="niq_brandid" descending="false" />
                          <filter type="or">
                            <condition attribute="niq_billingschedulestatus" operator="eq" value="610570001" />
                            <condition attribute="niq_billingschedulestatus" operator="eq" value="610570000" />
                          </filter>
                          <link-entity name="quote" from="quoteid" to="quoteid" link-type="inner" alias="an">
                            <filter type="and">
                              <condition attribute="quoteid" operator="eq" uitype="quote" value="${quoteId}" />
                            </filter>
                            <link-entity name="opportunity" from="opportunityid" to="opportunityid" link-type="inner" alias="ao">
                              <filter type="and">
                                <condition attribute="opportunityid" operator="eq" uitype="opportunity" value="${targetOppId}" />
                              </filter>
                            </link-entity>
                          </link-entity>
                        </entity>
                      </fetch>`;

                        var fetchResults = GetCRMWebAPI.Methods.GetFetchRecords(Xrm.Utility.getGlobalContext().getClientUrl(), fetchXML, "quotedetails");
                        //in Pre-Proposal stage is no need for billing schedule not generated error
                        // DYNCRM-22689 changes
                        if ((fetchResults !== null && fetchResults.value.length > 0) && date !== null &&
                            (formContext.data.process.getActiveStage().getName() == 'Negotiation' || formContext.data.process.getActiveStage().getName().toLowerCase() === "closed won - in review" ||
                                formContext.data.process.getActiveStage().getName() == 'Proposal')) {
                            var niqerror = "There is still unscheduled billing on at least one product within the main Quote. Check quote products with \"Billing schedule status\" = \"Incomplete data\" or \"Incomplete schedules (manual)\" and make sure that these products have dates, billing frequency and billing schedules present. If you face a technical issue with populating this data, raise a Help&Support request.";
                            formContext.ui.setFormNotification(niqerror, "ERROR", "billingerror");
                        }
                        else {
                            formContext.ui.clearFormNotification("billingerror");
                        }

                    }
                    else {
                        Xrm.Utility.alertDialog(this.statusText);
                    }
                }
            };
            req.send();


        }
        catch (e) {
            throw e.message;
        }

    },

    OnChangeInvoiceRecipientFields: function (executionContext) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var formType = formContext.ui.getFormType();
            if (formType !== 1 && formType !== 4)
                //Force save 
                formContext.data.entity.save();
        }
        catch (e) {
            throw e.message;
        }
    },

    ShowHideIsCanceledCancelationReason: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var OriginalOppo = formContext.getAttribute("niq_originalopportunityid").getValue();
        var BusinessArea = formContext.getAttribute("niq_businessarea").getValue();
        var Existingcontractaction = formContext.getAttribute("niq_existingcontractaction").getValue();


        if (OriginalOppo === null && BusinessArea === 100000000) {
            formContext.getControl("niq_iscanceled").setVisible(true);
            formContext.getControl("niq_cancelationreason").setVisible(true);
            formContext.getControl("niq_iscanceled1").setVisible(false);
            formContext.getControl("niq_cancelationreason1").setVisible(false);
            formContext.getControl("header_process_niq_iscanceled").setVisible(true);
            formContext.getControl("header_process_niq_cancelationreason").setVisible(true);

        }
        else if (OriginalOppo != null && Existingcontractaction === 4) {
            formContext.getControl("niq_iscanceled1").setVisible(true);
            formContext.getControl("niq_cancelationreason1").setVisible(true);
            formContext.getControl("niq_iscanceled").setVisible(false);
            formContext.getControl("niq_cancelationreason").setVisible(false);
            formContext.getControl("header_process_niq_iscanceled").setVisible(false);
            formContext.getControl("header_process_niq_cancelationreason").setVisible(false);
        }
        else {
            /*formContext.getAttribute("niq_iscanceled").setValue(null);*/
            formContext.getControl("niq_iscanceled").setVisible(false);
            /*formContext.getAttribute("niq_cancelationreason").setValue(null);	*/
            formContext.getControl("niq_cancelationreason").setVisible(false);
            formContext.getControl("niq_iscanceled1").setVisible(false);
            formContext.getControl("niq_cancelationreason1").setVisible(false);
            formContext.getControl("header_process_niq_iscanceled").setVisible(false);
            formContext.getControl("header_process_niq_cancelationreason").setVisible(false);

        }
    },

    ShowHideIsCanceledCancelationReasons: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var Existingcontractaction = formContext.getAttribute("niq_existingcontractaction").getValue();
        if (Existingcontractaction === 1 || Existingcontractaction === 2 || Existingcontractaction === 3) {
            formContext.getControl("niq_iscanceled1").setVisible(false);
            formContext.getControl("niq_cancelationreason1").setVisible(false);
        }
        else {
            formContext.getControl("niq_iscanceled1").setVisible(true);
            formContext.getControl("niq_cancelationreason1").setVisible(true);
            formContext.getControl("niq_iscanceled").setVisible(false);
            formContext.getControl("niq_cancelationreason").setVisible(false);
        }

    },

    PopulatingValueOfCloneOppo: function (executionContext) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var formInformationTips = "Sales Org, Sales Group and Opportunity Currency: This field cannot be changed for a cloned opportunity.  If you need them changed you will need to create a New Opportunity.";
            var fieldInformationTips = "Are you creating this opportunity to reflect a completely new sale/to manage an existing contract? : This field cannot be changed for a cloned opportunity.  If this is not a new sale, use the Manage Existing Contract";

            if ((CommonForm.Events.CheckFieldExists(formContext, "niq_cloneopportunity")) && (CommonForm.Events.CheckValueExists(formContext, "niq_cloneopportunity"))) {

                var originaloppo = formContext.getAttribute("niq_cloneopportunity").getValue();
                var originaloppo_id = originaloppo[0].id.replace('{', '').replace('}', '');
                formContext.ui.setFormNotification(formInformationTips, "INFORMATION");
                formContext.ui.setFormNotification(fieldInformationTips, "INFORMATION");
                formContext.getControl("niq_opportunitytype").setDisabled(true);
                formContext.getControl("niq_salesorgid").setDisabled(true);
                formContext.getControl("niq_salesgroupsalesorgid").setDisabled(true);
                formContext.getControl("transactioncurrencyid").setDisabled(true);
                Xrm.WebApi.online.retrieveMultipleRecords("opportunity", "?$select=_niq_salesgroupsalesorgid_value,_niq_salesorgid_value,_parentaccountid_value,_transactioncurrencyid_value&$filter=opportunityid eq " + originaloppo_id).
                    then(function success(results) {
                        for (var i = 0; i < results.entities.length; i++) {
                            if ((results.entities[i]["_niq_salesorgid_value"] !== null)) {
                                var lookupSalesGroupOrgValue = new Array();
                                lookupSalesGroupOrgValue[0] = new Object();
                                lookupSalesGroupOrgValue[0].id = results.entities[i]["_niq_salesorgid_value"];;
                                lookupSalesGroupOrgValue[0].name = results.entities[i]["_niq_salesorgid_value@OData.Community.Display.V1.FormattedValue"];
                                lookupSalesGroupOrgValue[0].entityType = results.entities[i]["_niq_salesorgid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                formContext.getAttribute("niq_salesorgid").setValue(lookupSalesGroupOrgValue);
                            }
                            else {
                                formContext.getAttribute("niq_salesorgid").setValue(null);
                            }
                            if ((results.entities[i]["_niq_salesgroupsalesorgid_value"] !== null)) {
                                var lookupSalesGroupValue = new Array();
                                lookupSalesGroupValue[0] = new Object();
                                lookupSalesGroupValue[0].id = results.entities[i]["_niq_salesgroupsalesorgid_value"];
                                lookupSalesGroupValue[0].name = results.entities[i]["_niq_salesgroupsalesorgid_value@OData.Community.Display.V1.FormattedValue"];
                                lookupSalesGroupValue[0].entityType = results.entities[i]["_niq_salesgroupsalesorgid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                formContext.getAttribute("niq_salesgroupsalesorgid").setValue(lookupSalesGroupValue);
                            }
                            else {
                                formContext.getAttribute("niq_salesgroupsalesorgid").setValue(null);
                            }
                            if ((results.entities[i]["_parentaccountid_value"] !== null)) {
                                var lookupParentAccountidValue = new Array();
                                lookupParentAccountidValue[0] = new Object();
                                lookupParentAccountidValue[0].id = results.entities[i]["_parentaccountid_value"];
                                lookupParentAccountidValue[0].name = results.entities[i]["_parentaccountid_value@OData.Community.Display.V1.FormattedValue"];
                                lookupParentAccountidValue[0].entityType = results.entities[i]["_parentaccountid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                formContext.getAttribute("parentaccountid").setValue(lookupParentAccountidValue);
                            }
                            else {
                                formContext.getAttribute("parentaccountid").setValue(null);
                            }
                            if ((results.entities[i]["_transactioncurrencyid_value"] !== null)) {
                                var lookupTransactionCurrencyValue = new Array();
                                lookupTransactionCurrencyValue[0] = new Object();
                                lookupTransactionCurrencyValue[0].id = results.entities[i]["_transactioncurrencyid_value"];;
                                lookupTransactionCurrencyValue[0].name = results.entities[i]["_transactioncurrencyid_value@OData.Community.Display.V1.FormattedValue"];
                                lookupTransactionCurrencyValue[0].entityType = results.entities[i]["_transactioncurrencyid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                formContext.getAttribute("transactioncurrencyid").setValue(lookupTransactionCurrencyValue);
                            }
                            else {
                                formContext.getAttribute("transactioncurrencyid").setValue(null);
                            }

                        }
                    },
                        function (error) {
                            Xrm.Utility.alertDialog(error.message);
                        }
                    );
            }
            else {
                /*
                formContext.getAttribute("niq_salesorgid").setValue(null);
                formContext.getAttribute("niq_salesgroupsalesorgid").setValue(null);
                formContext.getAttribute("parentaccountid").setValue(null);
                formContext.getAttribute("transactioncurrencyid").setValue(null);
                */
            }
        }
        catch (e) {
            throw e.message;
        }
    },

    displayMessageBlockedQuoteProduct: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (formContext.ui.getFormType() !== 1) {
            var quote = formContext.getAttribute("niq_mainquoteid").getValue();
            if (quote != null) {
                var quoteId = quote[0].id;
                if (quoteId != null) {
                    quoteId = quoteId.replace("{", "");
                    quoteId = quoteId.replace("}", "");
                    var globalContext = Xrm.Utility.getGlobalContext();
                    var serverUrl = globalContext.getClientUrl();
                    var fetchQuote = "<fetch top='1'><entity name='quote'><attribute name='niq_blockedproductdesc' /><filter><condition attribute='quoteid' operator='eq' value='" + quoteId + "' />   </filter></entity></fetch>";
                    var fetchResults = GetCRMWebAPI.Methods.GetFetchRecords(serverUrl, fetchQuote, "quotes");
                    if (fetchResults !== null && fetchResults.value.length > 0 && fetchResults.value[0]['niq_blockedproductdesc'] !== null) {
                        var blockedProdDesc = fetchResults.value[0]['niq_blockedproductdesc'];
                        if (blockedProdDesc != null) {
                            Xrm.Page.ui.setFormNotification("This cloned opportunity contains the following blocked products which must be removed in Experlogix before this opportunity can be closed to avoid SAP integration failure: " + blockedProdDesc, "WARNING");
                        }
                    }
                }
            }
        }
    },
    checkforActiveOPERecords: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var opportunityType = formContext.getAttribute("niq_opportunitytype").getValue();
        //var stage = Xrm.Page.data.getActiveProcess.getActiveStage();
        var activeStage = Xrm.Page.data.process.getActiveStage();
        var stageName = activeStage.getName();
        //alert(stageName);

        var formType = formContext.ui.getFormType();
        if (formType == 1) {
            //new

            if ((formContext.getControl("header_process_niq_product_enhancement_impact_provisions") != null) && (formContext.getControl("header_process_niq_product_enhancement_impact_provisions") != undefined)) {
                //if (fldattribute != undefined) {
                //    formContext.getControl("header_process_niq_product_enhancement_impact_provisions").getAttribute().setRequiredLevel("none");
                //}
                formContext.getControl("header_process_niq_product_enhancement_impact_provisions").setVisible(false);
            }
        }
        else if (formType == 4) {//disabled
            if (opportunityType == 1) {                                          //type is "completely new sale"
                if ((formContext.getControl("header_process_niq_product_enhancement_impact_provisions") != null) && (formContext.getControl("header_process_niq_product_enhancement_impact_provisions") != undefined)) {
                    formContext.getControl("header_process_niq_product_enhancement_impact_provisions").setVisible(false);
                }
            }
            return;
        }
        else {
            if (opportunityType == 2) { // only when type is "existing contract mgt"
                var oppid = formContext.data.entity.getId().replace("{", "").replace("}", "");

                await Xrm.WebApi.retrieveMultipleRecords(
                    "niq_opportunityproductenhancement",
                    `?$filter=_niq_opportunitynameid_value eq ${oppid} and statecode eq 0`
                ).then(
                    function (result) {
                        var recordcount = result.entities.length;
                        console.log(result);

                        var fldcontrol = formContext.getControl("header_process_niq_product_enhancement_impact_provisions");
                        var fldattribute = fldcontrol.getAttribute();

                        if (recordcount >= 1) {
                            if ((formContext.getControl("header_process_niq_product_enhancement_impact_provisions") != null) && (formContext.getControl("header_process_niq_product_enhancement_impact_provisions") != undefined)) {
                                formContext.getControl("header_process_niq_product_enhancement_impact_provisions").setVisible(true);
                                //alert('making visible');
                                if (fldattribute != undefined) {
                                    formContext.getControl("header_process_niq_product_enhancement_impact_provisions").getAttribute().setRequiredLevel("required");
                                }
                            }
                        }
                        else {
                            if ((formContext.getControl("header_process_niq_product_enhancement_impact_provisions") != null) && (formContext.getControl("header_process_niq_product_enhancement_impact_provisions") != undefined)) {
                                if (fldattribute != undefined) {
                                    formContext.getControl("header_process_niq_product_enhancement_impact_provisions").getAttribute().setRequiredLevel("none");
                                }
                                formContext.getControl("header_process_niq_product_enhancement_impact_provisions").setVisible(false);
                            }
                        }

                        /*for (var i = 0; i < result.entities.length; i++) {
                            var enhancement = result.entities[i];
                            var enhancementId = enhancement["niq_opportunityproductenhancementid"];
                        }*/
                    },
                    function (error) {
                        console.log(error.message);
                    }
                );
            } else if (opportunityType == 1) {
                ////only when type is "completely new sale"
                if ((formContext.getControl("header_process_niq_product_enhancement_impact_provisions") != null) && (formContext.getControl("header_process_niq_product_enhancement_impact_provisions") != undefined)) {
                    formContext.getControl("header_process_niq_product_enhancement_impact_provisions").setVisible(false);
                }
            }
        }

    },

    ShowhideProjectDetailSection: function (executionContext) {

        var formContext = executionContext.getFormContext();
        if (formContext.getAttribute("niq_businessarea") != null || formContext.getAttribute("niq_businessarea").getValue() != null) {

            var businessAreaValue = formContext.getAttribute("niq_businessarea").getValue();

            if (businessAreaValue == 100000000) {
                formContext.ui.tabs.get("Summary").sections.get("ProjectDetailSection").setVisible(true);
            }
            else {

                formContext.ui.tabs.get("Summary").sections.get("ProjectDetailSection").setVisible(false);
            }
        }
    },

    hostChildOpportunityGridSetDisable: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var approvalStatus;
        var status;
        var opportunityId = formContext.data.entity.getId();

        if (opportunityId != null) {
            var fetchXmlQuery = '<fetch version= "1.0" output-format="xml-platform" mapping= "logical" distinct= "false">' +
                '<entity name= "opportunity">' +
                '<attribute name="opportunityid"/>' +
                '<attribute name="niq_stage"/>' +
                '<attribute name="niq_approvalstatus"/>' +
                '<attribute name="statecode"/>' +
                '<filter type="and">' +
                '<condition attribute="opportunityid" operator="eq" value="' + opportunityId + '"/>' +
                '</filter>' +
                '</entity>' +
                '</fetch>';
            var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
            var results = GetCRMWebAPI.Methods.GetFetchRecords(clienturl, fetchXmlQuery, "opportunities");

            if (results != null && results.value.length > 0) {
                approvalStatus = results.value[0]["niq_approvalstatus"]; // approval status
                status = results.value[0]["statecode"]; // Status  
            }
            OpportunityForm.Events.disablechildOpportunityGrid(executionContext, approvalStatus, status);
        }
    },
    disablechildOpportunityGrid: function (executionContext, approvalStatus, status) {
        var formContext = executionContext.getFormContext();
        var fieldsList = ["estimatedclosedate", "niq_closeprobability", "niq_customerponumber", "niq_customerpodate", "niq_billingtype",
            "niq_billinginstructions", "niq_shouldclientbeinvoicedforthisopportunity",
            "name", "parentaccountid", "niq_salesgroupsalesorgid", "niq_soldtoparty", "niq_billtoparty",
            "niq_deliverytoparty", "parentcontactid", "niq_competitor1", "niq_contractdecision"];
        if (approvalStatus != 100000001 && approvalStatus != 100000000 && status == 0) {
            formContext.getData().getEntity().attributes.forEach(function (attr) {
                var fld = attr.getName();
                if (!fieldsList.includes(fld)) {
                    //attr.controls.get(0).setDisabled = true;
                    attr.controls.forEach(function (control) {
                        control.setDisabled(true);
                    });
                }
            });
        }
        else {
            formContext.getData().getEntity().attributes.forEach(function (attr) {
                attr.controls.forEach(function (control) {
                    control.setDisabled(true);
                });
            });
        }

    },
    OnChangeOpportunityTypeAndContractAction: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        if (CommonForm.Events.CheckValueExists(formContext, "niq_opportunitytype")) {
            var oppoType = formContext.getAttribute("niq_opportunitytype").getValue();
            if (oppoType === 2) {
                if (CommonForm.Events.CheckValueExists(formContext, "niq_existingcontractaction")) {
                    var contractaction = formContext.getAttribute("niq_existingcontractaction").getValue();

                    if (contractaction === 1) {
                        if (CommonForm.Events.CheckControlExists(formContext, "niq_contractdecision")) {
                            formContext.getControl("niq_contractdecision").getAttribute().setValue(100000001);
                        }
                    }
                    if (contractaction === 2 || contractaction === 3) {
                        if (CommonForm.Events.CheckControlExists(formContext, "niq_contractdecision")) {
                            formContext.getControl("niq_contractdecision").getAttribute().setValue(100000000);
                        }
                    }
                    if (contractaction === 4) {
                        if (CommonForm.Events.CheckControlExists(formContext, "niq_contractdecision")) {
                            formContext.getControl("niq_contractdecision").getAttribute().setValue(100000002);
                        }
                    }
                }
            }
            else {
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_contractdecision")) {
                    formContext.getControl("niq_contractdecision").getAttribute().setValue(100000001);
                }
            }
        }
    },


    PopulateDefaultFieldsFromDefaultSettings: function (executionContext) {
        //niq_salesorgid, niq_salesgroupsalesorgid, transactioncurrencyid
        var formContext = executionContext.getFormContext();
        //This logic should not run for clone opportunity scenario_Bug 26696
        if ((CommonForm.Events.CheckFieldExists(formContext, "niq_cloneopportunity")) && (CommonForm.Events.CheckValueExists(formContext, "niq_cloneopportunity"))) {
            return;
        }
        //IC-POC #26736_B
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_opportunitytype") &&
            CommonForm.Events.CheckValueExists(formContext, "niq_opportunitytype")) {

            var opportunityType = formContext.getAttribute("niq_opportunitytype").getValue();

            // If opportunity type is 2, do not populate default fields
            if (opportunityType === 2) {
                return;
            }
        }
        //IC-POC #26736_E
        var userSettings = Xrm.Utility.getGlobalContext().userSettings;
        var formType = formContext.ui.getFormType();
        var currentuserid = userSettings.userId.substring(1, 37);
        //alert(currentuserid);
        var username = userSettings.userName;
        if (formContext.getAttribute("niq_salesorgid").getValue() == null || formContext.getAttribute("niq_salesgroupsalesorgid").getValue() == null || formContext.getAttribute("transactioncurrencyid").getValue() == null) {
            Xrm.WebApi.retrieveMultipleRecords("niq_salesuserdefaultsettings", "?$select=_niq_defaultcurrency_value,_niq_defaultsalesgroupsalesorg_value,_niq_defaultsalesorg_value&$filter=_niq_user_value eq '" + currentuserid + "' and statecode eq 0").then(
                function success(results) {
                    console.log(results);
                    for (var i = 0; i < results.entities.length; i++) {
                        var result = results.entities[i];
                        // Columns
                        var niq_salesuserdefaultsettingsid = result["niq_salesuserdefaultsettingsid"]; // Guid
                        var niq_defaultcurrency = result["_niq_defaultcurrency_value"]; // Lookup
                        var niq_defaultcurrency_formatted = result["_niq_defaultcurrency_value@OData.Community.Display.V1.FormattedValue"];
                        var niq_defaultcurrency_lookuplogicalname = result["_niq_defaultcurrency_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        var niq_defaultsalesgroupsalesorg = result["_niq_defaultsalesgroupsalesorg_value"]; // Lookup
                        var niq_defaultsalesgroupsalesorg_formatted = result["_niq_defaultsalesgroupsalesorg_value@OData.Community.Display.V1.FormattedValue"];
                        var niq_defaultsalesgroupsalesorg_lookuplogicalname = result["_niq_defaultsalesgroupsalesorg_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        var niq_defaultsalesorg = result["_niq_defaultsalesorg_value"]; // Lookup
                        var niq_defaultsalesorg_formatted = result["_niq_defaultsalesorg_value@OData.Community.Display.V1.FormattedValue"];
                        var niq_defaultsalesorg_lookuplogicalname = result["_niq_defaultsalesorg_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        //alert('niq_defaultcurrency_lookuplogicalname ' + niq_defaultcurrency_lookuplogicalname + '\n niq_defaultcurrency_formatted ' + niq_defaultcurrency_formatted + '\n niq_defaultcurrency ' + niq_defaultcurrency +'\n niq_defaultsalesgroupsalesorg_lookuplogicalname ' + niq_defaultsalesgroupsalesorg_lookuplogicalname+ '\n niq_defaultsalesgroupsalesorg ' + niq_defaultsalesgroupsalesorg + '\n niq_defaultsalesgroupsalesorg_formatted ' + niq_defaultsalesgroupsalesorg_formatted + '\n niq_defaultsalesorg_lookuplogicalname ' + niq_defaultsalesorg_lookuplogicalname+'\n niq_defaultsalesorg' + niq_defaultsalesorg + '\n niq_defaultsalesorg_formatted ' + niq_defaultsalesorg_formatted);
                        if (formType === 1) {
                            if (formContext.getAttribute("niq_salesorgid").getValue() == null && niq_defaultsalesorg != null) {
                                var salesOrg = {
                                    "entityType": niq_defaultsalesorg_lookuplogicalname, // change this to the logical name of parent table.
                                    "id": niq_defaultsalesorg, // guid of the parent record
                                    "name": niq_defaultsalesorg_formatted // text representing the name of the record to be displayed in the lookup.
                                };

                                // replace salesorg with the lookup field name.
                                formContext.getAttribute("niq_salesorgid").setValue([salesOrg]);
                                formContext.getControl("niq_salesgroupsalesorgid").setDisabled(false);
                            }
                            if (formContext.getAttribute("niq_salesgroupsalesorgid").getValue() == null && niq_defaultsalesgroupsalesorg != null) {
                                var salesGroudSalesOrg = {
                                    "entityType": niq_defaultsalesgroupsalesorg_lookuplogicalname,
                                    "id": niq_defaultsalesgroupsalesorg,
                                    "name": niq_defaultsalesgroupsalesorg_formatted
                                };

                                // replace salesgroupsalesorg with the lookup field name.
                                formContext.getAttribute("niq_salesgroupsalesorgid").setValue([salesGroudSalesOrg]);

                            }

                            if (formType == 1 || (formType == 2 && (formContext.getAttribute("transactioncurrencyid").getValue() == null && niq_defaultcurrency != null))) {
                                var currency = {
                                    "entityType": niq_defaultcurrency_lookuplogicalname,
                                    "id": niq_defaultcurrency,
                                    "name": niq_defaultcurrency_formatted
                                };

                                formContext.getAttribute("transactioncurrencyid").setValue([currency]);
                            }
                        }
                    }
                },

                function (error) {
                    console.log(error.message);
                }
            );
        }
    },
    PopulateEstCloseDateFromDefaultSettings: function (executionContext) {


        // var formContext = Xrm.Page;
        var formContext = executionContext.getFormContext();
        var est_Close_Date = formContext.getAttribute("estimatedclosedate").getValue();
        var formType = formContext.ui.getFormType();
        if (est_Close_Date == null || formType == 1) {
            var opportunityType = formContext.getAttribute("niq_opportunitytype").getValue();
            var userid = Xrm.Utility.getGlobalContext().userSettings.userId;
            userid = userid.substring(1, userid.length - 1);
            var daysToAdd = 0;


            var options = "?$select=niq_defaultsalescycleindaysnewsale,niq_defausalescycleexistingcontractmanagement,_niq_user_value&$filter=_niq_user_value eq " + userid;
            Xrm.WebApi.retrieveMultipleRecords("niq_salesuserdefaultsettings", options).then(
                function success(results) {
                    if (results == undefined || results == null) return;
                    var niq_defaultsalescycleindaysnewsale = results.entities[0]["niq_defaultsalescycleindaysnewsale"];
                    var niq_defausalescycleexistingcontractmanagement = results.entities[0]["niq_defausalescycleexistingcontractmanagement"];
                    if (opportunityType == 1) daysToAdd = niq_defaultsalescycleindaysnewsale;                 // completely new sale
                    else if (opportunityType == 2) daysToAdd = niq_defausalescycleexistingcontractmanagement; // existing contract mgt
                    if (daysToAdd != undefined && daysToAdd != null) {
                        let reqdate = new Date();
                        reqdate.setDate(new Date().getDate() + daysToAdd);
                        formContext.getAttribute("estimatedclosedate").setValue(reqdate);
                    }
                },
                function (error) {
                    console.log(error.message);
                });
        }
    },

    ShowSectionsBasedOnPartyValues: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        var stpControl, btpControl, dtpControl, stpControlId, btpControlId, dtpControlId;

        if (formContext.getAttribute("niq_soldtoparty") != null && formContext.getAttribute("niq_soldtoparty").getValue() != null) {
            stpControl = formContext.getControl("niq_soldtoparty");
            stpControlId = stpControl.getAttribute().getValue()[0].id;
        }
        if (formContext.getAttribute("niq_billtoparty") != null && formContext.getAttribute("niq_billtoparty").getValue() != null) {
            btpControl = formContext.getControl("niq_billtoparty");
            btpControlId = btpControl.getAttribute().getValue()[0].id;
        }
        if (formContext.getAttribute("niq_deliverytoparty") != null && formContext.getAttribute("niq_deliverytoparty").getValue()) {
            dtpControl = formContext.getControl("niq_deliverytoparty");
            dtpControlId = dtpControl.getAttribute().getValue()[0].id;
        }

        if (stpControlId === btpControlId &&
            stpControlId === dtpControlId) {
            //alert('equal');
            formContext.ui.tabs.get("Summary").sections.get("CommonPartyDetails").setVisible(true);
            formContext.ui.tabs.get("Summary").sections.get("SoldToPartyDetails").setVisible(false);
            formContext.ui.tabs.get("Summary").sections.get("BillToPartyDetails").setVisible(false);
            formContext.ui.tabs.get("Summary").sections.get("DeliverToPartyDetails").setVisible(false);

        }
        else {
            //alert('not equal');
            formContext.ui.tabs.get("Summary").sections.get("CommonPartyDetails").setVisible(false);
            formContext.ui.tabs.get("Summary").sections.get("SoldToPartyDetails").setVisible(true);
            formContext.ui.tabs.get("Summary").sections.get("BillToPartyDetails").setVisible(true);
            formContext.ui.tabs.get("Summary").sections.get("DeliverToPartyDetails").setVisible(true);
        }
    },

    /**
   * Visibility of Competitor tab only when status is closed lost
   * @param {any} executionContext - The execution context provided by the Dynamics 365 CRM form.
   */
    Showhidecomepetitorstab: function (executionContext) {
        var formContext = executionContext?.getFormContext();

        var oldCompetitorsTab = formContext?.ui?.tabs?.get("tab_12");
        var newCompetitorsTab = formContext?.ui?.tabs?.get("Competitors_tab");

        var niq_stage = formContext?.getAttribute("niq_stage")?.getValue();

        if (niq_stage === "Closed Lost") {
            oldCompetitorsTab?.setVisible(false);
            newCompetitorsTab?.setVisible(true);
        } else {
            oldCompetitorsTab?.setVisible(true);
            newCompetitorsTab?.setVisible(false);
        }
    },

    /**
    * Visibility of Closure scetion only when status is closed lost
    * @param {any} executionContext - The execution context provided by the Dynamics 365 CRM form.
    */
    ShowHideClosureSection: function (executionContext) {

        var formContext = executionContext.getFormContext();
        var Stage = formContext.getAttribute("niq_stage")?.getValue();
        if (Stage == 'Closed Lost') {
            formContext.ui.tabs.get("Summary")?.sections.get("Summary_section_8")?.setVisible(true);
        }
        else {
            formContext.ui.tabs.get("Summary")?.sections.get("Summary_section_8")?.setVisible(false);
        }

    },
    /**
    * Checks if the revenue schedule dates are within the valid range based on the quote details.
    * This function prevents stage progression if the schedules are not in line with the quote product dates.
    * 
    * @param {ExecutionContext} executionContext - The execution context that contains the form and event data.
    */
       validateScheduleDateWithinQuoteDates: async function (executionContext) {
        "use strict";
 
        // Get the form context and event arguments
        var formContext = executionContext?.getFormContext();
        var args = executionContext?.getEventArgs();
 
        // Get the active process and stage names using optional chaining
        var activeProcess = formContext.data.process.getActiveProcess()?.getName() ?? null;
        var activeStage = formContext.data.process.getActiveStage()?.getName() ?? null;
 
        // Check if the active process is "Opportunity Business Process Flow" and the active stage is "Negotiation"
        if (activeProcess === "Opportunity Business Process Flow" && activeStage === "Negotiation" && args.getDirection() === "Next") {
            var opportunityId = formContext.data.entity.getId();
 
            // Exit if Opportunity ID is not available
            if (!opportunityId) return;
 
            // Remove curly braces from Opportunity ID
            var opportunityIdFormatted = opportunityId.replace("{", "").replace("}", "");
 
            // Get the main quote ID from the opportunity form, and check if it exists
            var quote = formContext.getAttribute("niq_mainquoteid")?.getValue();
            if (!quote?.length) return; // Exit if no quote is available
 
            // Extract the quote ID from the value
            var quoteId = quote[0].id.replace("{", "").replace("}", "");
 
            // Fetch quote details related to the main quote
            var fetchQuoteDetailsXml = `
                <fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
                    <entity name="quotedetail">
                        <attribute name="quotedetailid" />
                        <attribute name="quoteid" />
                        <attribute name="niq_lineitemstartdate" />
                        <attribute name="niq_lineitemenddate" />
                        <filter type="and">
                            <condition attribute="quoteid" operator="eq" value="${quoteId}" />
                        </filter>
                    </entity>
                </fetch>`;
 
            //args.preventDefault();
 
            // Execute the fetchXML query to get quote details
            var quoteDetailsResult = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", "?fetchXml=" + encodeURIComponent(fetchQuoteDetailsXml));
 
            // Iterate through the results (quote details)
            for (var quoteDetail of quoteDetailsResult.entities) {
                var startDate = quoteDetail?.niq_lineitemstartdate;
                var endDate = quoteDetail?.niq_lineitemenddate;
 
                // If any required fields are missing, skip this iteration
                if (!startDate || !endDate) return;
 
                // Fetch schedules related to the quote detail
                var scheduleFetchXml = `
                    <fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
                                    <entity name="niq_schedule">
                                        <attribute name="niq_scheduleid" />
                                        <attribute name="niq_name" />
                                        <attribute name="createdon" />
                                        <attribute name="modifiedon" />
                                        <attribute name="niq_scheduledate" />
                                        <attribute name="niq_lineitemid" />
                                        <order attribute="niq_name" descending="false" />
                                        <filter type="and">
                                        <condition attribute="niq_lineitemid" operator="eq" uitype="quotedetail" value="${quoteDetail?.quotedetailid}" />
                                        <condition attribute="niq_scheduletype" operator="eq" value="100000001" />
                                        <filter type="or">
                                        <condition attribute="niq_scheduledate" operator="lt" value="${startDate}"  />
                                        <condition attribute="niq_scheduledate" operator="gt" value="${endDate}" />
                                        </filter>
                                        </filter>
                                        <link-entity name="quotedetail" from="quotedetailid" to="niq_lineitemid" link-type="inner" alias="ad">
                                        <attribute name="niq_deliveryfrequency" />
                                        <filter type="and">
                                            <condition attribute="quoteid" operator="eq" uitype="quote" value="${quoteId}" />
                                            <condition attribute="niq_deliveryfrequency" operator="eq" value="100000009" />
                                        </filter>
                                        </link-entity>
                                    </entity>
                                    </fetch>`;
 
                // Execute the FetchXML for niq_schedule
                var schedules = await Xrm.WebApi.retrieveMultipleRecords("niq_schedule", "?fetchXml=" + encodeURIComponent(scheduleFetchXml));
 
                // If schedules are found, show error and prevent stage progression
                if (args.getDirection() === "Next" && schedules?.entities?.length > 0) {
                    await Xrm.Navigation.openErrorDialog({
                        message: "The revenue schedule dates are not in line with quote product dates for one or several quote products. Please check quote products with revenue frequency = 'custom' and make sure that revenue schedules are within quote product start and end dates."
                    });
                    args.preventDefault();
                    return;  // Exit early to prevent further processing
                }
                else {
                formContext.data.process.moveNext();
                formContext.data.process.removeOnPreStageChange(OpportunityForm.Events.validateScheduleDateWithinQuoteDates);
                }
            }
            //formContext.data.process.removeOnPreStageChange(OpportunityForm.Events.validateScheduleDateWithinQuoteDates);
            //formContext.data.process.moveNext(); // Directly move to the next stage
 
        }
    },
    LockForecastingdatapresenseOnBPF: function (executionContext) {

        let formContext = executionContext.getFormContext();
        let bpfRevenuesharedeal = formContext.getAttribute("niq_revenuesharedeal")?.getValue();
        let hostopportunity = formContext.getAttribute("niq_hostopportunity")?.getValue();
        let activeStage = (formContext.data.process.getActiveStage() !== null) ? (formContext.data.process.getActiveStage().getName()) : null;

        if (bpfRevenuesharedeal === true && hostopportunity === null) {

            if ((formContext.getControl("header_process_niq_forecastingdatapresence") != undefined) && (formContext.getControl("header_process_niq_forecastingdatapresence") != null)) {

                //formContext.getControl("niq_forecastingdatapresence").getAttribute().setRequiredLevel("none"); 
                formContext.getControl("header_process_niq_forecastingdatapresence").getAttribute().setRequiredLevel("none");

            }

        }
        else {
            if ((formContext.getControl("header_process_niq_forecastingdatapresence") != undefined) && (formContext.getControl("header_process_niq_forecastingdatapresence") != null)) {

                //formContext.getControl("niq_forecastingdatapresence").getAttribute().setRequiredLevel("none"); 
                formContext.getControl("header_process_niq_forecastingdatapresence").getAttribute().setRequiredLevel("required");

            }
        }

    },
    lockFieldsforABO: function (executionContext) {
        let formContext = executionContext.getFormContext();
        var opportuntiyType = formContext.getAttribute("niq_opportunitytype")?.getValue();
        var existing_contract = formContext.getAttribute("niq_existingcontractaction")?.getValue();
        var amendmendedFromOpportunity = formContext.getAttribute("niq_amendedfromopportunity")?.getValue();
        if (amendmendedFromOpportunity != null && opportuntiyType == 2 && existing_contract == 4) {
            formContext.getControl("niq_opportunitytype").setDisabled(true);
            formContext.getControl("niq_existingcontractaction").setDisabled(true);
        }
    },
    //DYNCRM-22762 - Auto populate Name on Invoice (If Diff from Invoice Recipient) from Invoice Recipient
    populateNameOnInvoice: function (executionContext) {
        "use strict";
        return;
        var formContext = executionContext.getFormContext();

        if (CommonForm.Events.CheckFieldExists(formContext, "parentcontactid") && CommonForm.Events.CheckValueExists(formContext, "parentcontactid")) {
            var invoiceRecipient = formContext.getAttribute("parentcontactid").getValue();

            if (CommonForm.Events.CheckFieldExists(formContext, "niq_nameoninvoiceifdifffrominvoicerecipient")) {
                formContext.getAttribute("niq_nameoninvoiceifdifffrominvoicerecipient").setValue(invoiceRecipient);
            }
        }
    },

    //DYNCRM-21776 - Technical Story : Pending Flag - Post New Account Request
    validateCustomerAccountRequestsPendingOnAccountRequest: function (executionContext) {
        /*
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            const process = formContext.data.process;
            const currentStage = process?.getActiveStage();
            const currentStageName = currentStage?.getName();

            if (!currentStageName) return;

            if (currentStageName === "Negotiation") {
                const accountNameAttribute = formContext.getAttribute("parentaccountid");
                if (accountNameAttribute && accountNameAttribute.getValue()) {
                    var accountGUID = accountNameAttribute.getValue()[0].id;
                    accountGUID = accountGUID.replace("{", "").replace("}", "");
                    var accountRecord = null;
                    var req = new XMLHttpRequest();
                    req.open("GET", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/accounts(" + accountGUID + ")?$select=niq_accounttype", false);
                    req.setRequestHeader("OData-MaxVersion", "4.0");
                    req.setRequestHeader("OData-Version", "4.0");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Prefer", "odata.include-annotations=*");
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req.onreadystatechange = null;
                            if (this.status === 200) {
                                accountRecord = JSON.parse(this.response);

                            } else {
                                console.log(this.responseText);
                            }
                        }
                    };
                    req.send();
                }
                if (accountRecord != null) {
                    if (accountRecord["niq_accounttype"] == 1) {
                        //CustomerAccount
                        var req = new XMLHttpRequest();
                        req.open("GET", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/niq_accountrequests?$select=niq_accountrequestid&$filter=(niq_customeraccountrequestspending eq true and _niq_customeraccount_value eq " + accountGUID + ")", false);
                        req.setRequestHeader("OData-MaxVersion", "4.0");
                        req.setRequestHeader("OData-Version", "4.0");
                        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                        req.setRequestHeader("Accept", "application/json");
                        req.setRequestHeader("Prefer", "odata.include-annotations=*");
                        req.onreadystatechange = function () {
                            if (this.readyState === 4) {
                                req.onreadystatechange = null;
                                if (this.status === 200) {
                                    var accountRequestEntity = JSON.parse(this.response);
                                    if (accountRequestEntity.value.length > 0) {
                                        executionContext.getEventArgs().preventDefault();
                                        formContext.ui.setFormNotification("You cannot proceed to the next stage because there are pending customer account requests.", "ERROR", "pendingCustomerAccountRequestFound")
                                    }
                                    else {
                                        formContext.ui.clearFormNotification("pendingCustomerAccountRequestFound")
                                    }
                                } else {
                                    console.log(this.responseText);
                                }
                            }
                        };
                        req.send();
                    }
                }
            }
        }
        catch (error) {
            console.error("Error in validateCustomerAccountRequestsPendingOnAccountRequest:", error);
        }
        */
    },

    // DYNCRM-23064 - Show warning message when Existing Contract Management is selected
    checkNewSaleOrExisting: function (executionContext) {
        var formContext = executionContext.getFormContext();
        // if (formContext.ui.getFormType() == 1) {
        var newSalesOrExisting = formContext.getAttribute("niq_opportunitytype").getValue();
        if (newSalesOrExisting == 2) {
            Xrm.Page.getControl("niq_opportunitytype").setNotification("All existing contract management actions have been moved to the Customer Account to ensure alignment with the client assets.  Please select the appropriate action from the Asset view located on the Customer Account to proceed");
        }
        else {
            Xrm.Page.getControl("niq_opportunitytype").clearNotification();
        }
        //}
    },
    PopulateClientAccountInMSAOpportunity: async function (executionContext) {
        try {
            var formContext = executionContext.getFormContext();
            var formType = formContext.ui.getFormType();

            if (formType != 4) { //Opp not in Won or Lost

                var accountLookup = formContext.getAttribute("parentaccountid").getValue();
                if (accountLookup && accountLookup.length > 0) {
                    var accountId = accountLookup[0].id;
                    accountId = accountId.replace("{", "").replace("}", "");

                    const accountResult = await Xrm.WebApi.retrieveRecord("account", accountId, "?$select=_niq_ultimateparentid_value");
                    if (accountResult && accountResult["_niq_ultimateparentid_value"]) {
                        const msaContractResult_Active_UP = await Xrm.WebApi.retrieveMultipleRecords("niq_msacontract", "?$filter=niq_msastatus eq 610570000 and _niq_clientaccount_value eq " + accountResult["_niq_ultimateparentid_value"] + "&$select=niq_msacontractid,niq_name&$orderby=createdon desc&$top=1");
                        if (msaContractResult_Active_UP.entities.length > 0) {
                            var msaContractId = msaContractResult_Active_UP.entities[0].niq_msacontractid;
                            var msaContractName = msaContractResult_Active_UP.entities[0].niq_name;

                            OpportunityForm.Events.SetMSAContractLookup(formContext, msaContractId, msaContractName);
                        } else {
                            const msaContractResult_Future_UP = await Xrm.WebApi.retrieveMultipleRecords("niq_msacontract", "?$filter=niq_msastatus eq 610570002 and _niq_clientaccount_value eq " + accountResult["_niq_ultimateparentid_value"] + "&$select=niq_msacontractid,niq_name&$orderby=createdon desc&$top=1");
                            if (msaContractResult_Future_UP.entities.length > 0) {
                                var msaContractId = msaContractResult_Future_UP.entities[0].niq_msacontractid;
                                var msaContractName = msaContractResult_Future_UP.entities[0].niq_name;

                                OpportunityForm.Events.SetMSAContractLookup(formContext, msaContractId, msaContractName);
                            } else {
                                formContext.getAttribute("niq_msacontract").setValue(null);
                            }
                        }
                    } else {
                        const msaContractResult_Active_Account = await Xrm.WebApi.retrieveMultipleRecords("niq_msacontract", "?$filter=niq_msastatus eq 610570000 and _niq_clientaccount_value eq " + accountId + "&$select=niq_msacontractid,niq_name&$orderby=createdon desc&$top=1");
                        if (msaContractResult_Active_Account.entities.length > 0) {
                            var msaContractId = msaContractResult_Active_Account.entities[0].niq_msacontractid;
                            var msaContractName = msaContractResult_Active_Account.entities[0].niq_name;

                            OpportunityForm.Events.SetMSAContractLookup(formContext, msaContractId, msaContractName);
                        } else {
                            const msaContractResult_Future_Account = await Xrm.WebApi.retrieveMultipleRecords("niq_msacontract", "?$filter=niq_msastatus eq 610570002 and _niq_clientaccount_value eq " + accountId + "&$select=niq_msacontractid,niq_name&$orderby=createdon desc&$top=1");
                            if (msaContractResult_Future_Account.entities.length > 0) {
                                var msaContractId = msaContractResult_Future_Account.entities[0].niq_msacontractid;
                                var msaContractName = msaContractResult_Future_Account.entities[0].niq_name;

                                OpportunityForm.Events.SetMSAContractLookup(formContext, msaContractId, msaContractName);
                            } else {
                                formContext.getAttribute("niq_msacontract").setValue(null);
                            }
                        }
                    }
                } else {
                    formContext.getAttribute("niq_msacontract").setValue(null);
                }
            }
        }
        catch (error) {
            console.log("Error retrieving records: " + error.message);
        }
    },

    SetMSAContractLookup: async function (formContext, msaContractId, msaContractName) {
        formContext.getAttribute("niq_msacontract").setValue([
            {
                id: msaContractId,
                name: msaContractName,
                entityType: "niq_msacontract"
            }]);
    },

    //Trigger points:
    //Main form
    //Onload of form, paramter passed = "Onload"
    //Onchange of ownerid, parameter passed = "OnChange"
    //onchange of niq_revenuesharedeal, paramter passed = null
    //Quick create form
    //Onload of form, paramter passed = "Onload"
    ConfigureLocalcontributor: function (executionContext, type = null) {
        var userSettings = Xrm.Utility.getGlobalContext().userSettings;
        var formContext = executionContext.getFormContext();
        var owner = formContext.getAttribute("ownerid").getValue();
        var revShare = formContext.getAttribute("niq_revenuesharedeal")?.getValue();
        var localcontributor = formContext.getAttribute("niq_localcontributor")?.getValue();
        var formType = formContext.ui.getFormType();
        // unlock the field, if the form is create form or update form not for disabled or readonly forms.
        if (formType == 1 || formType == 2) {
            if (owner != null && owner[0].id.slice(1, -1) == userSettings.userId.slice(1, -1)) {
                formContext.getControl("niq_localcontributor").setDisabled(false);//can edit
                if (type != null && ((formType == 1 && type == "OnLoad") || type == "OnChange") && localcontributor == null) {
                    formContext.getAttribute("niq_localcontributor").setValue(owner);
                }
            }
            else {
                formContext.getControl("niq_localcontributor").setDisabled(true);
                if (type != null && type == "OnChange") {
                    formContext.getAttribute("niq_localcontributor").setValue(owner != null ? owner : null);
                }
            }
        }

        if (revShare != null && revShare) {
            formContext.getAttribute("niq_localcontributor").setRequiredLevel("required");
        }
        else {
            formContext.getAttribute("niq_localcontributor").setRequiredLevel("none");
        }
    },


    //DYNCRM-21871 -- Check if the associated account is in compliance or not --------Functions Start here 
    checkAccountCompliance: function (executionContext) {
        //commented for 22194
        //return;

        var formContext = executionContext.getFormContext()
        var canProceed = true; // Flag to check if user can proceed to the next stage
        var ApprovalStatus = formContext.getAttribute("niq_approvalstatus").getValue()
        if (ApprovalStatus != 100000002) {
            // Check Parent Account
            if (CommonForm.Events.CheckFieldExists(formContext, "parentaccountid")) {
                var accountName = formContext.getAttribute("parentaccountid").getValue();
                if (accountName && accountName.length > 0) {
                    var accountId = accountName[0].id;
                    var opportunityType = formContext.getAttribute("niq_opportunitytype");
                    if (checkAccountComplianceCondition(accountId, formContext, "Account Name", opportunityType, "parentaccountid", "Customer")) {
                        canProceed = false;
                    } else {
                        removeNotification(formContext, "parentaccountid"); // Use accountId for consistency
                    }
                } else {
                    removeNotification(formContext, "parentaccountid"); // Use accountId for consistency
                }

            }

            // Check Sold To Party
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_soldtoparty")) {
                var soldToParty = formContext.getAttribute("niq_soldtoparty").getValue();
                if (soldToParty && soldToParty.length > 0) {
                    var accountId = soldToParty[0].id;
                    var opportunityType = formContext.getAttribute("niq_opportunitytype");
                    if (checkAccountComplianceCondition(accountId, formContext, "Sold To Party", opportunityType, "niq_soldtoparty", "SAP")) {
                        canProceed = false;
                    } else {
                        removeNotification(formContext, "niq_soldtoparty"); // Use accountId for consistency
                    }
                } else {
                    removeNotification(formContext, "niq_soldtoparty"); // Use accountId for consistency
                }

            }

            // Check Bill To Party
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_billtoparty")) {
                var billToParty = formContext.getAttribute("niq_billtoparty").getValue();
                if (billToParty && billToParty.length > 0) {
                    var accountId = billToParty[0].id;
                    var opportunityType = formContext.getAttribute("niq_opportunitytype");
                    if (checkAccountComplianceCondition(accountId, formContext, "Bill To Party", opportunityType, "niq_billtoparty", "SAP")) {
                        canProceed = false;
                    } else {
                        removeNotification(formContext, "niq_billtoparty"); // Use accountId for consistency
                    }
                } else {
                    removeNotification(formContext, "niq_billtoparty"); // Use accountId for consistency
                }

            }

            // Check Delivery To Party
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_deliverytoparty")) {
                var deliverToParty = formContext.getAttribute("niq_deliverytoparty").getValue();
                if (deliverToParty && deliverToParty.length > 0) {
                    var accountId = deliverToParty[0].id;
                    var opportunityType = formContext.getAttribute("niq_opportunitytype");
                    if (checkAccountComplianceCondition(accountId, formContext, "Delivery To Party", opportunityType, "niq_deliverytoparty", "SAP")) {
                        canProceed = false;
                    } else {
                        removeNotification(formContext, "niq_deliverytoparty"); // Use accountId for consistency
                    }
                } else {
                    removeNotification(formContext, "niq_deliverytoparty"); // Use accountId for consistency
                }

            }

            // If no compliance condition was triggered, allow moving to the next stage
            if (canProceed) {
                formContext.getAttribute("niq_readyfornextstage").setValue(true); // Set to "Yes" (1)
                formContext.ui.clearFormNotification("ComplianceErrorStageChange")
            } else {
                formContext.getAttribute("niq_readyfornextstage").setValue(false); // Set to "No" (0)
            }
        }
    },
    checkDataAvailabilityAndCompliance(formContext) {
        // Retrieve related opportunity ID
        var ApprovalStatus = formContext.getAttribute("niq_approvalstatus").getValue()
        if (ApprovalStatus != 100000002) { //Approved
            var relatedOpportunityId = formContext.data.entity.getId().replace("{", "").replace("}", "");;

            if (!relatedOpportunityId) {
                console.log("No related opportunity ID found.");
                return;
            }

            // Construct the FetchXML query dynamically with the relatedOpportunityId
            var fetchXml = `
        <fetch version="1.0" output-format="xml-platform">
          <entity name="niq_financeapprovalrequests">
            <attribute name="niq_financeapprovalrequests" />
            <order attribute="niq_financeapprovalrequests" descending="false" />
            <filter type="and">
              <condition attribute="niq_relatedopportunity" operator="eq" value="${relatedOpportunityId}" />
              <condition attribute="niq_approvalstatus" operator="in">
                <value>100000005</value>
                <value>100000006</value>
                <value>100000001</value>
                <value>100000004</value>
                <value>100000003</value>
                <value>100000007</value>
              </condition>
            </filter>
            <link-entity name="opportunity" from="opportunityid" to="niq_relatedopportunity" visible="false" link-type="outer" alias="op">
              <attribute name="niq_soldtoparty" />
              <attribute name="niq_deliverytoparty" />
              <attribute name="niq_billtoparty" />
              <attribute name="parentaccountid" />
            </link-entity>
          </entity>
        </fetch>`;

            // Use Xrm.WebApi.retrieveMultipleRecords method to execute the FetchXML query
            Xrm.WebApi.retrieveMultipleRecords("niq_financeapprovalrequests", `?fetchXml=${encodeURIComponent(fetchXml)}`).then(
                function (response) {

                    if (response.entities.length > 0) {
                        // Data found, now process each record
                        response.entities.forEach(function (record) {
                            // Check if each related field is populated and check compliance status for each related account
                            var relatedAccounts = [
                                record['op.niq_soldtoparty'],
                                record['op.niq_deliverytoparty'],
                                record['op.niq_billtoparty'],
                                record['op.parentaccountid']
                            ];

                            // Loop through related accounts
                            relatedAccounts.forEach(function (accountLookup) {
                                if (accountLookup) {
                                    // Retrieve the compliance status for each related account
                                    Xrm.WebApi.retrieveRecord("account", accountLookup, "?$select=niq_compliancestatus").then(function (account) {

                                        var complianceStatus = account.niq_compliancestatus;

                                        // If the compliance status matches and the account is not canceled, show notification
                                        if (complianceStatus === 610570000) {
                                            var notificationMessage = "Account(s) on this Opportunity have status Compliance Blocked. You can only proceed further with this Opportunity as long as Is Canceled field = Canceled.";
                                            var notificationKey = "ComplianceBlockedWarning_FAR"; // Unique notification key

                                            // Show the form notification
                                            formContext.ui.setFormNotification(notificationMessage, "WARNING", notificationKey);
                                        }
                                    });
                                }
                            });
                        });
                    }
                }
            );
        }

    },
    checkAccountComplianceOnbpfChange: function (executionContext) {
        //commented for 22194
        //return;
        "use strict";
        var formContext = executionContext.getFormContext();
        var args = executionContext.getEventArgs();
        const process = formContext.data.process;
        const currentStage = process?.getActiveStage();
        const currentStageName = currentStage?.getName();
        if (!currentStageName) return;
        if (currentStageName === "Pre-Proposal" || currentStageName === "Proposal" || currentStageName === "Negotiation") {
            var readyForNextStage = formContext.getAttribute("niq_readyfornextstage").getValue();
            if (!readyForNextStage) {
                args.preventDefault();
                formContext.ui.setFormNotification("You cannot proceed to the next stage because One of your Account(s) on this Opportunity have status Compliance Blocked or Financial Blocked. To proceed further with this Opportunity, select different Account(s). If not close this Opportunity as Lost.", "ERROR", "ComplianceErrorStageChange");
            }
        }
    },
    checkRevenueActionTaken: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.getControl("header_process_niq_isdeferredrevenueclicked")?.clearNotification("revenueActionUniqueId");
        var oppoType = formContext.getAttribute("niq_opportunitytype").getValue();
        var existingContractAction = formContext.getAttribute("niq_existingcontractaction").getValue();
        var activeStage = (formContext.data.process.getActiveStage() !== null) ? (formContext.data.process.getActiveStage().getName()) : null;
        if (oppoType == 2 && existingContractAction == 4 && activeStage == "Negotiation") {
            var isDeferredRevenueActionAclicked = formContext.getAttribute("niq_isdeferredrevenueclicked").getValue();
            if (isDeferredRevenueActionAclicked == null || isDeferredRevenueActionAclicked == false) {
                executionContext.getEventArgs().preventDefault();
                formContext.ui.setFormNotification("Please select the Deferred Revenue Reconciliation button.", "ERROR", "error");
                formContext.getAttribute("niq_isdeferredrevenueclicked").setRequiredLevel("required");
            }
        }
    },
    //DYNCRM-21871 -- Check if the associated account is in compliance or not --------Functions End here 

    // Function to make the "Invoice Dispatch Method" field read only
    HideInvoiceDispatchMethodField: function (executionContext) {
        var formContext = executionContext.getFormContext(); // Get the form context
        let formType = formContext.ui.getFormType();// Get the form type
        var requiredRoles = ["NIQ Sales User"];
        // Check if the user has any of the required roles
        if (CommonForm.Events.UserHasRequiredRole(executionContext, requiredRoles) && (formType === 1 || formType === 2)) {
            var invoiceDispatchMethodField = formContext.getControl("niq_invoicedispatchmethod");
            if (invoiceDispatchMethodField) {
                invoiceDispatchMethodField.setDisabled(false); // // Make the field read-only (disabled)
            }
        }
    },
    // on change of sales org/Account set EDICOM
    SetInvoiceDispatchMethod: async function (executionContext) {
        var formContext = executionContext.getFormContext(); // Get the form context
        let salesOrgId = formContext.getAttribute("niq_salesorgid")?.getValue();// Get sales Org of Opportunity
        let account = formContext.getAttribute("niq_billtoparty")?.getValue();// Get Account of Opportunity
        let formType = formContext.ui.getFormType();// Get the form type

        if (CommonForm.Events.IsValid(salesOrgId) && CommonForm.Events.IsValid(account) && (formType === 1 || formType === 2)) {
            let fetchAccount = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                "  <entity name='account'>" +
                "    <attribute name='name' />" +
                "    <order attribute='name' descending='false' />" +
                "    <filter type='and'>" +
                "      <condition attribute='accountid' operator='eq' value='{" + account[0].id.replace(/[{}]/g, '') + "}' />" +
                "    </filter>" +
                "    <link-entity name='niq_saleorgassignment' from='niq_account' to='accountid' link-type='inner' alias='ag'>" +
                "       <attribute name='niq_invoicedispatchmethod' />" +
                "      <filter type='and'>" +
                "        <condition attribute='niq_salesorg' operator='eq' value='{" + salesOrgId[0].id.replace(/[{}]/g, '') + "}' />" +
                "      </filter>" +
                "    </link-entity>" +
                "  </entity>" +
                "</fetch>";

            fetchAccount = "?fetchXml=" + encodeURIComponent(fetchAccount);
            let results = await Xrm.WebApi.retrieveMultipleRecords("account", fetchAccount);
            if (results.entities.length > 0) {
                // Set Invoice Dispatch Method field to EDICOM
                let isValid = await CommonForm.Events.IsValidToSetInvoiceDispatchMethod(executionContext, "niq_salesorgid");
                if (isValid) {
                    let invoiceDispatchMethod = formContext.getAttribute("niq_invoicedispatchmethod")?.getValue();
                    if (invoiceDispatchMethod !== 4) { //EDICOM
                        formContext.getAttribute("niq_invoicedispatchmethod").setValue(4); // EDICOM
                    }

                } else {
                    let salesOrgAssignInvoiceDispatchMethod = results.entities[0]["ag.niq_invoicedispatchmethod"];
                    if (salesOrgAssignInvoiceDispatchMethod) {
                        formContext.getAttribute("niq_invoicedispatchmethod")?.setValue(salesOrgAssignInvoiceDispatchMethod);
                        formContext.getControl("niq_invoicedispatchmethod")?.setDisabled(true);
                    } else {
                        //formContext.getAttribute("niq_invoicedispatchmethod")?.setValue(null);
                        formContext.getControl("niq_invoicedispatchmethod")?.setDisabled(false);
                    }
                }
            }
        } else {
            if (formType === 1 || formType === 2) {
                formContext.getAttribute("niq_invoicedispatchmethod")?.setValue(null);
                formContext.getControl("niq_invoicedispatchmethod")?.setDisabled(true);
            }
        }
    },

    //DYNCRM 22671 - Populate InvoiceRecepientAccountsPayable
    populateInvoiceRecepientAccountsPayable: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var accountLookup = formContext.getAttribute("niq_billtoparty").getValue();
        var salesorgLookup = formContext.getAttribute("niq_salesorgid").getValue();
        if (accountLookup && accountLookup.length > 0) {
            var accountId = accountLookup[0].id;
            accountId = accountId.replace("{", "").replace("}", "");
        }
        if (salesorgLookup && salesorgLookup.length > 0) {
            var salesorgId = salesorgLookup[0].id;
            salesorgId = salesorgId.replace("{", "").replace("}", "");
        }
        if (accountId && salesorgId) {
            var fetchXml = `
                    <fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false" top="1">
                        <entity name="niq_saleorgassignment">
                        <attribute name="niq_saleorgassignmentid" />
                        <attribute name="niq_accountspayableapcontact" />
                        <attribute name="niq_name" />
                        <attribute name="createdon" />
                        <order attribute="createdon" descending="true" />
                        <filter type="and">
                            <condition attribute="niq_account" operator="eq" value="${accountId}" />
                            <condition attribute="niq_salesorg" operator="eq" value="${salesorgId}" />
                        </filter>
                        </entity>
                    </fetch>`;

            var salesOrgAssignmentResult = await Xrm.WebApi.retrieveMultipleRecords("niq_saleorgassignment", "?fetchXml=" + encodeURIComponent(fetchXml));
            if (salesOrgAssignmentResult.entities.length > 0) {
                var salesOrgAssignmentEntity = salesOrgAssignmentResult.entities[0];
                var apContactId = salesOrgAssignmentEntity["_niq_accountspayableapcontact_value"];
                var apContactName = salesOrgAssignmentEntity["_niq_accountspayableapcontact_value@OData.Community.Display.V1.FormattedValue"];

                if (!(CommonForm.Events.CheckValueExists(formContext, "niq_nameoninvoiceifdifffrominvoicerecipient"))) {

                    formContext.getAttribute("niq_nameoninvoiceifdifffrominvoicerecipient").setValue([
                        {
                            id: apContactId,
                            entityType: "contact",
                            name: apContactName
                        }
                    ]);
                }
            }
        }
    },

    OnChange_BilltoParty: function (executionContext) {

        var formContext = executionContext.getFormContext();
        var billToParty = formContext.getAttribute("niq_billtoparty");

        if (CommonForm.Events.CheckValueExists(formContext, "niq_billtoparty")) {
            var makeFieldsReadOnly = [
                "niq_porequired",
                "niq_invoicedispatchmethod",
                "niq_nameoninvoiceifdifffrominvoicerecipient"
            ];
            makeFieldsReadOnly.forEach(fieldLogicalName => {
                if (CommonForm.Events.CheckFieldExists(formContext, fieldLogicalName)) {
                    var fieldValue = CommonForm.Events.CheckValueExists(formContext, fieldLogicalName);
                    if (fieldValue === true) {
                        formContext.getControl(fieldLogicalName).setDisabled(true);  // Make read-only
                    }
                    else {
                        formContext.getControl(fieldLogicalName).setDisabled(false); // Keep editable
                    }
                }
            });

            if (billToParty && billToParty.getValue() != null) {
                var accountId = billToParty.getValue()[0].id.replace("{", "").replace("}", "");
        
                Xrm.WebApi.retrieveRecord("account", accountId, "?$select=niq_porequired").then(function (account) {
                    var poRequiredAttr = formContext.getAttribute("niq_porequired");
                    if (poRequiredAttr) {
                        if (account.niq_porequired != null) {
                            poRequiredAttr.setValue(account.niq_porequired);
                        } else {
                            poRequiredAttr.setValue(null);
                        }
                    }
                }).catch(function (error) {
                    console.error("Error retrieving Account record: ", error.message);
                });
            }
            
            formContext.ui.tabs.get("Summary").sections.get("BillToPartyDetails").setVisible(true);
        }
        else {
            formContext.ui.tabs.get("Summary").sections.get("BillToPartyDetails").setVisible(false);
        }
    },

    //Making po required field mandatory on load of the form
    OnLoadFormPORequiredToMandatory: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_porequired")) {
            formContext.getAttribute("niq_porequired").setRequiredLevel("required");
        }

    },

    AutomaticCreationofModifyAccountRequest: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        let formType = formContext.ui.getFormType();
        if (formType !== 1) {
            var opportunityId = formContext.data.entity.getId();
            opportunityId = opportunityId.replace("{", "").replace("}", "");
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_billtoparty") && CommonForm.Events.CheckValueExists(formContext, "niq_billtoparty") && CommonForm.Events.CheckFieldExists(formContext, "niq_porequired") && CommonForm.Events.CheckValueExists(formContext, "niq_porequired") && CommonForm.Events.CheckFieldExists(formContext, "niq_invoicedispatchmethod") && CommonForm.Events.CheckValueExists(formContext, "niq_invoicedispatchmethod") && CommonForm.Events.CheckFieldExists(formContext, "niq_nameoninvoiceifdifffrominvoicerecipient") && CommonForm.Events.CheckValueExists(formContext, "niq_nameoninvoiceifdifffrominvoicerecipient")) {
                var fieldsChanged = [
                    "niq_porequired",
                    "niq_invoicedispatchmethod",
                    "niq_nameoninvoiceifdifffrominvoicerecipient"
                ];
                var anyFieldChanged = fieldsChanged.some(function (fieldLogicalName) {
                    var fieldsChanged = formContext.getAttribute(fieldLogicalName).getIsDirty();
                    return fieldsChanged;
                }
                );
                if (anyFieldChanged) {
                    var billToParty = formContext.getAttribute("niq_billtoparty").getValue();
                    billToParty = billToParty[0].id.replace('{', '').replace('}', '');
                    var result = await Xrm.WebApi.retrieveRecord("account", billToParty, "?$select=_niq_ultimateparentid_value");
                    var parentAccountid = result["_niq_ultimateparentid_value"];
                    var entityData =
                        {};
                    entityData["niq_RelatedOpportunity@odata.bind"] = "/opportunities(" + opportunityId + ")";
                    entityData["niq_CustomerAccount@odata.bind"] = "/accounts(" + parentAccountid + ")";
                    entityData["niq_requesttype"] = 610570001;
                    //entityData["ownerid@odata.bind"]= "/systemusers(" + currentUserId + ")";
                    let response = await Xrm.WebApi.createRecord("niq_accountrequest", entityData);
                    formContext.ui.setFormNotification(
                        "Account Request has been successfully created.",
                        "INFO",
                        "account_request_created"
                    );
                    setTimeout(function () {
                        formContext.ui.clearFormNotification("account_request_created");
                    }, 10000);

                }
                else {
                    return;
                }
            }
        }
    },
    autopopulatePartiesSync: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const process = formContext.data.process;
        const currentStage = process?.getActiveStage();
        const currentStageName = currentStage?.getName();
        var sapAccountId = null;
        if (!currentStageName) return;
        if (!["Pre-Proposal", "Proposal"].includes(currentStageName)) return;

        const billTo = formContext.getAttribute("niq_billtoparty")?.getValue();
        const soldTo = formContext.getAttribute("niq_soldtoparty")?.getValue();
        const deliverTo = formContext.getAttribute("niq_deliverytoparty")?.getValue();
        const opportunityId = formContext.data.entity.getId().replace(/[{}]/g, "");
        const opportunity = OpportunityForm.Events.syncRetrieve("opportunities", opportunityId, ["_parentaccountid_value"]);

        if (!opportunity || !opportunity._parentaccountid_value) return;

        const parentAccountId = opportunity._parentaccountid_value;
        const account = OpportunityForm.Events.syncRetrieve("accounts", parentAccountId, ["_niq_primarysapaccount_value"]);

        if (account && account._niq_primarysapaccount_value) {
            sapAccountId = account._niq_primarysapaccount_value;
        }
        else {
            const fallbackAccounts = OpportunityForm.Events.syncRetrieveMultiple("accounts", `_niq_ultimateparentid_value eq '${parentAccountId}'`, ["accountid"]);

            if (fallbackAccounts && fallbackAccounts.length == 1) {
                sapAccountId = fallbackAccounts[0].accountid;
            }
        }

        if (sapAccountId) {
            const sapAccount = OpportunityForm.Events.syncRetrieve("accounts", sapAccountId, ["niq_compliancefinancialstatus"]);
            if (!sapAccount) return;

            const status = sapAccount.niq_compliancefinancialstatus;
            const invalidStatuses = [610570000, 610570001, 610570003, 610570004];
            if (invalidStatuses.includes(status)) return;

            const reference = [{ id: sapAccountId, entityType: "account" }];
            if (billTo == null)
                formContext.getAttribute("niq_billtoparty").setValue(reference);
            if (soldTo == null)
                formContext.getAttribute("niq_soldtoparty").setValue(reference);
            if (deliverTo == null)
                formContext.getAttribute("niq_deliverytoparty").setValue(reference);
        }
    },
    syncRetrieve: function (entitySetName, id, selectFields) {
        const req = new XMLHttpRequest();
        const url = `${Xrm.Utility.getGlobalContext().getClientUrl()}/api/data/v9.1/${entitySetName}(${id})?$select=${selectFields.join(",")}`;
        req.open("GET", url, false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=*");

        try {
            req.send();
            if (req.status === 200) {
                return JSON.parse(req.responseText);
            } else {
                console.error("Error retrieving record:", req.statusText);
                return null;
            }
        } catch (e) {
            console.error("Request failed:", e);
            return null;
        }
    },


    syncRetrieveMultiple: function (entitySetName, filter, selectFields) {
        var req = new XMLHttpRequest();
        var url = Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/" + entitySetName + "?$select=" + selectFields.join(",") + (filter ? "&$filter=" + encodeURIComponent(filter) : "");
        req.open("GET", url, false); // false = synchronous
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.send();

        if (req.status === 200) {
            var results = JSON.parse(req.responseText);
            return results.value;
        } else {
            console.error("Error retrieving records: " + req.statusText);
            return null;
        }
    },

    // Lock fields for Amendment Opportunity
    lockFieldsOnLoad: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const fieldsToLock = [
            "niq_soldtoparty",
            "parentaccountid",
            "niq_salesorgid"
        ];
        var existingContractAction = formContext.getAttribute("niq_existingcontractaction")?.getValue();
        var opportunityType = formContext.getAttribute("niq_opportunitytype")?.getValue();
        if (existingContractAction !== null && opportunityType !== null && existingContractAction === 4 && opportunityType === 2) {
            fieldsToLock.forEach(field => {
                const control = formContext.getControl(field);
                if (control) {
                    control.setDisabled(true);
                }
            });
        }
    },
    //US-25486
    MakeFieldMandatory : function(executionContext)
    {
        var formContext = executionContext.getFormContext();
        var currentOppId = formContext.data.entity.getId();
        if(currentOppId != null || currentOppId != ""){
            var shouldClientBeInvoicedForThisOpportunity = formContext.getAttribute("niq_shouldclientbeinvoicedforthisopportunity")?.getValue();
            if(shouldClientBeInvoicedForThisOpportunity != null && shouldClientBeInvoicedForThisOpportunity == 100000000)
            {
                var currentStage = formContext.getAttribute("niq_stage")?.getValue();
                var approvalStatus = formContext.getAttribute("niq_approvalstatus")?.getValue();
                if(currentStage != null || currentStage != "")
                {
                    if(currentStage == "Negotiation" || (currentStage == "Closed Won - In Review" && (approvalStatus == 100000004 || approvalStatus == 100000006 || approvalStatus == 100000005 || approvalStatus == 100000003)))
                    {
                        formContext.getAttribute("parentcontactid").setRequiredLevel("required");
                    }else{
                        formContext.getAttribute("parentcontactid").setRequiredLevel("none");
                    }
                }
            }
        }
    },
    //US-25486
    MakeEditableField : async function(executionContext)
    {
        var formContext = executionContext.getFormContext();
        var currentOppId = formContext.data.entity.getId();
        if(currentOppId != null || currentOppId != "")
        {
            var oppStatus = formContext.getAttribute("statecode")?.getValue();
            var soldToParty = formContext.getAttribute("niq_soldtoparty")?.getValue();
            var probability = formContext.getAttribute("niq_closeprobability")?.getValue();
            if(oppStatus == 0 && soldToParty != null && (probability == 100000004 || probability == 100000005 || probability == 100000006))
            {
                formContext.getControl("parentcontactid").setDisabled(false);
            }else{
                formContext.getControl("parentcontactid").setDisabled(true);
            }
        }
    },
    //US-25486
    SetNameOnInvoice : function(executionContext)
    {
        var formContext = executionContext.getFormContext();
        var currentOppId = formContext.data.entity.getId();
        if(currentOppId != null || currentOppId != "")
        {
            var accountPayableContact = formContext.getAttribute("niq_nameoninvoiceifdifffrominvoicerecipient").getValue();
            if(accountPayableContact != null)
            {
                var nameInvoiceName = [];
                nameInvoiceName[0] = {};
                nameInvoiceName[0].id = accountPayableContact[0].id;
                nameInvoiceName[0].entityType = accountPayableContact[0].entityType;
                nameInvoiceName[0].name = accountPayableContact[0].name;
                formContext.getAttribute("parentcontactid").setValue(nameInvoiceName);
            }
        }
    },
    //US-25486
    ReadOnlyFields : function(executionContext)
    {
        var formContext = executionContext.getFormContext();
        var currentOppId = formContext.data.entity.getId();
        var currentStage = formContext.getAttribute("niq_stage")?.getValue();
        if(currentOppId != "" && (currentStage == "Closed Won - In Review" || currentStage == "Closed Won - Approved"))
        {            
            formContext.getControl("niq_porequired")?.setDisabled(true);
            formContext.getControl("niq_nameoninvoiceifdifffrominvoicerecipient")?.setDisabled(true);
            formContext.getControl("niq_invoicedispatchmethod")?.setDisabled(true);
        }
    },

    //DYNCRM-24673
    BlockNegotiationStageDraftStatus: async function(executionContext)
    {
        var formContext = executionContext.getFormContext();
        var Account = formContext.getAttribute("parentaccountid")?.getValue();
        var customerAccount = Account[0].id;
        var Account = await Xrm.WebApi.retrieveRecord("account",customerAccount,"?$select=niq_compliancefinancialstatus");
        var complianceStatus = Account["niq_compliancefinancialstatus"];
        var args = executionContext.getEventArgs();
        var currentStage = formContext.data.process.getActiveStage()?.getName().toLowerCase();
        if (currentStage == "negotiation" && complianceStatus == 610570006)
        {
            if(args.getDirection() == "Next")
            {
                Xrm.Navigation.openAlertDialog({ text: "The Customer Account Compliance Financial Status is in Draft state and cannot move beyond the Negotiation stage." });
                args.preventDefault();

            }

        }

    },
     /**
    * Toggles visibility between two subgrids based on Revenue Share and Host Opportunity flags.
    * Shows the main subgrid with Ready for next stage column if both conditions are true, otherwise shows the cloned subgrid.
    *
    * @param {object} executionContext - The form execution context.
    */
    ToggleSubgridsByHostAndRevStatus: function (executionContext) {
    var formContext = executionContext.getFormContext();

    var bpfRevenuesharedeal = formContext.getAttribute("niq_revenuesharedeal")?.getValue();
    var hostOpportunity = formContext.getAttribute("niq_ishostopportunity")?.getValue();

    var subgridHost = formContext.getControl("OpportunitiesConnectedViaHost");//Main subgrid
    var subgridHost1 = formContext.getControl("OpportunitiesConnectedViaHost_1");//Cloned subgrid

    if (!subgridHost || !subgridHost1) {
        console.warn("One or both subgrid controls not found on the form.");
        return;
    }

    var showHost = bpfRevenuesharedeal === true && hostOpportunity === true;

    // Show/hide subgrids based on condition
    subgridHost.setVisible(showHost);//if condtions are met show the main subgrid with ready for nextstage column
    subgridHost1.setVisible(!showHost);//if condtions are not met show the Cloned subgrid without ready for nextstage column
    },
    //DYNCRM-28817
    displayWarningonRenewalOpportunityWithCustomSchedule : async function(executionContext){
        var formContext = executionContext.getFormContext();
        var currentOpportunityGuid = formContext.data.entity.getId();
        if(currentOpportunityGuid !== null || currentOpportunityGuid !== ""){
            var mainQuoteId = formContext.getAttribute("niq_mainquoteid").getValue();
            var NewSaleOrExistingContract = formContext.getAttribute("niq_opportunitytype").getValue();
            if(mainQuoteId != null && NewSaleOrExistingContract != null && NewSaleOrExistingContract == 2) //Existing Contract Management
            {
                mainQuoteId = mainQuoteId[0].id;
                var ExistingContractAction = formContext.getAttribute("niq_existingcontractaction").getValue();
                var OppEntity = await Xrm.WebApi.retrieveRecord("opportunity", currentOpportunityGuid.replace("{","").replace("}",""), "?$select=niq_automaticrenewal,niq_automatedopportunity");
                if((OppEntity["niq_automaticrenewal"] == true || OppEntity["niq_automatedopportunity"] == true) && (ExistingContractAction == 1 || ExistingContractAction == 2 || ExistingContractAction == 3)){
                    //Check if current opportunity have any Custom Schedule quote products, if yes show warning to FAR Approver
                    var fetchxmlCustomFrequencyQProducts = `<fetch distinct='false'>
                                <entity name='quotedetail'>
                                    <attribute name="niq_deliveryfrequency" />
                                    <attribute name="productname" />
                                    <attribute name="quotedetailid" />
                                    <attribute name="quotedetailname" />
                                    <filter type='and'>
                                        <condition attribute="niq_deliveryfrequency" operator="eq" value="100000009" />
                                        <condition attribute='quoteid' operator='eq' value='${mainQuoteId}' />
                                    </filter>
                                </entity>
                            </fetch>`;
                    var resultScheduleQP = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", "?fetchXml=" + fetchxmlCustomFrequencyQProducts);
                    //Have some quote products with custom revenue schedule
                    if (resultScheduleQP && resultScheduleQP['entities'] && resultScheduleQP['entities'].length > 0) {
                        formContext.ui.setFormNotification("Opportunity contains system-generated custom revenue and/or billing schedules. Please review the dates & schedules for accuracy prior to proceeding with this opportunity.", "WARNING", "101");
                    }
                    else {
                        formContext.ui.clearFormNotification("101");
                        //Check if current opportunity have any Custom billing Schedule quote products, if yes show warning to FAR Approver
                        var fetchxmlCustomBillingFrequencyQProducts = `<fetch distinct='false'>
                                <entity name='quotedetail'>
                                    <attribute name="niq_billingfrequency" />
                                    <attribute name="productname" />
                                    <attribute name="quotedetailid" />
                                    <attribute name="quotedetailname" />
                                    <filter type='and'>
                                        <condition attribute="niq_billingfrequency" operator="eq" value="100000009" />
                                        <condition attribute='quoteid' operator='eq' value='${mainQuoteId}' />
                                    </filter>
                                </entity>
                            </fetch>`;
                        var resultBillingScheduleQP = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", "?fetchXml=" + fetchxmlCustomBillingFrequencyQProducts);
                        //Have some quote products with custom schedule
                        if (resultBillingScheduleQP && resultBillingScheduleQP['entities'] && resultBillingScheduleQP['entities'].length > 0) {
                            formContext.ui.setFormNotification("Opportunity contains system-generated custom revenue and/or billing schedules. Please review the dates & schedules for accuracy prior to proceeding with this opportunity.", "WARNING", "102");
                        }
                        else {
                            formContext.ui.clearFormNotification("102");
                        }
                    }
                }
            }
        }
    }
}

//DYNCRM-1725
function fieldingCountryCI_OnChange(executionContext) {

    var formContext = executionContext.getFormContext();
    var businessArea = formContext.getAttribute("niq_businessarea").getValue();
    if (businessArea == 100000001) {
        formContext.getControl("niq_fieldingcountryci").setVisible(true);
        formContext.getAttribute("niq_fieldingcountryci").setRequiredLevel("required");
    } else {
        formContext.getControl("niq_fieldingcountryci").setVisible(false);
        formContext.getAttribute("niq_fieldingcountryci").setRequiredLevel("none");
    }
}

function opportunityInOmCorrection(executionContext) {
    var formContext = executionContext.getFormContext();
    if (CommonForm.Events.CheckFieldExists(formContext, "niq_approvalstatus") && CommonForm.Events.CheckFieldExists(formContext, "niq_stage")) {
        var approvalStatus = formContext.getAttribute("niq_approvalstatus")?.getValue();
        var stage = formContext.getAttribute("niq_stage")?.getValue();

        if (approvalStatus == 100000005 && stage == "Closed Won - In Review") {
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add-On Finance Gatekeeper")) {
                CommonForm.Events.disableFormFields(false, formContext);
            }
            else if
                (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add-On Finance Gatekeeper")) {
                CommonForm.Events.disableFormFields(false, formContext);
            }
            else if
                (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add-On Finance Gatekeeper") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User")) {
                CommonForm.Events.disableFormFields(false, formContext);
            }
            else if
                (CommonForm.Events.CheckIfLoggedInUserRoles("System Administrator")) {
                CommonForm.Events.disableFormFields(false, formContext);
            }
            else if
                (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin")) {
                CommonForm.Events.disableFormFields(false, formContext);
            }
            else {
                CommonForm.Events.disableFormFields(true, formContext);
            }
        }

        if (approvalStatus == 100000006 && stage == "Closed Won - In Review") {
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add On Sales Ops Approver")) {
                CommonForm.Events.disableFormFields(false, formContext);
            }
            else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User")) {
                CommonForm.Events.disableFormFields(false, formContext);
            }
            else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add-On Finance Gatekeeper")) {
                CommonForm.Events.disableFormFields(false, formContext);
            }
            else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add-On Finance Gatekeeper")) {
                CommonForm.Events.disableFormFields(false, formContext);
            }
            else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User")) {
                CommonForm.Events.disableFormFields(false, formContext);
            }
            else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add-On Finance Gatekeeper") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User")) {
                CommonForm.Events.disableFormFields(false, formContext);
            }
            else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add On Sales Ops Approver")) {
                CommonForm.Events.disableFormFields(false, formContext);
            }
            else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add On Sales Ops Approver")) {
                CommonForm.Events.disableFormFields(false, formContext);
            }
            else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add On Sales Ops Approver")) {
                CommonForm.Events.disableFormFields(false, formContext);
            }
            else if (CommonForm.Events.CheckIfLoggedInUserRoles("System Administrator")) {
                CommonForm.Events.disableFormFields(false, formContext);
            }
            else if (CommonForm.Events.CheckIfLoggedInUserRoles("Business Administrator")) {
                CommonForm.Events.disableFormFields(false, formContext);
            }
            else {
                CommonForm.Events.disableFormFields(true, formContext);
            }
        }
    }
}

//DYNCRM-1725: BPF Fielding Country should hide when Business Area eq CI
function BpfFieldingCountry_OnLoad(executionContext) {
    var formContext = executionContext.getFormContext();
    var bpfBusinessArea = formContext.getAttribute("niq_businessarea").getValue();
    if (bpfBusinessArea == 100000001) {
        var bpfFieldCountry = formContext.getControl('header_process_niq_fieldingcountry').setVisible(false);
    }

}
/**
 * Updating the contacts on primary search contact field
 * @param {any} executionContext - The execution context provided by the Dynamics 365 CRM form.
 */
function FilterContactbasedonUltimateAccount(executionContext) {
    "use strict";
    var formContext = executionContext.getFormContext();

    if (CommonForm?.Events?.CheckFieldExists(formContext, "parentaccountid") &&
        CommonForm?.Events?.CheckValueExists(formContext, "parentaccountid")) {
        var parentaccountId = formContext?.getAttribute("parentaccountid")?.getValue()?.[0]?.id;
        var viewId = formContext?.getControl("niq_primarycontactid")?.getDefaultView();

        if (!parentaccountId || !viewId) {
            return;
        }

        var entity = "contact";
        var ViewDisplayName = "All Related Contacts";
        var layout = "<grid name='resultset' object='2' jump='lastname' select='1' icon='1' preview='1'>" +
            "<row name='result' id='contactid'>" +
            "<cell name='fullname' width='300'/>" +
            "<cell name='emailaddress1' width='100'/>" +
            "</row>" +
            "</grid>";

        Xrm?.WebApi?.online?.retrieveMultipleRecords("account", "?$filter=accountid eq " + parentaccountId + "&$select=_niq_ultimateparentid_value").then(
            function success(results) {
                if (results?.entities?.length > 0) {
                    var ultimateParentId = results?.entities?.[0]?._niq_ultimateparentid_value;

                    if (ultimateParentId) {
                        Xrm?.WebApi?.online?.retrieveMultipleRecords("account", "?$filter=_niq_ultimateparentid_value eq " + ultimateParentId).then(
                            function success(results) {
                                var conditions = "";

                                results?.entities?.forEach(function (account) {
                                    conditions += "<condition attribute='accountid' operator='eq' value='" + account?.accountid + "' />";
                                });

                                conditions += "<condition attribute='accountid' operator='eq' value='" + ultimateParentId + "' />";

                                var fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                    "<entity name='contact'>" +
                                    "<attribute name='fullname' />" +
                                    "<attribute name='contactid' />" +
                                    "<attribute name='emailaddress1' />" +
                                    "<order attribute='fullname' descending='false' />" +
                                    "<link-entity name='account' from='accountid' to='parentcustomerid' link-type='inner' alias='ac'>" +
                                    "<filter type='or'>" + conditions + "</filter>" +
                                    "</link-entity>" +
                                    "</entity>" +
                                    "</fetch>";

                                formContext?.getControl("niq_primarycontactid")?.addCustomView(viewId, entity, ViewDisplayName, fetchXML, layout, false);
                            }
                        );
                    } else {
                        var fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                            "<entity name='contact'>" +
                            "<attribute name='fullname' />" +
                            "<attribute name='contactid' />" +
                            "<attribute name='emailaddress1' />" +
                            "<order attribute='fullname' descending='false' />" +
                            "<link-entity name='account' from='accountid' to='parentcustomerid' link-type='inner' alias='ac'>" +
                            "<filter type='and'>" +
                            "<condition attribute='accountid' operator='eq' value='" + parentaccountId + "' />" +
                            "</filter>" +
                            "</link-entity>" +
                            "</entity>" +
                            "</fetch>";

                        formContext?.getControl("niq_primarycontactid")?.addCustomView(viewId, entity, ViewDisplayName, fetchXML, layout, false);
                    }
                }
            }
        );
    }
}

//DYNCRM-22277 - Hide show AmendedFromOpportunity and LeadId field
function showABOFields(executionContext) {
    var formContext = executionContext.getFormContext();
    var AmendmentOpportunity = formContext.getAttribute("niq_amendedfromopportunity").getValue();
    if (AmendmentOpportunity != null && AmendmentOpportunity != undefined) {
        formContext.getControl("niq_amendedfromopportunity").setVisible(true);
        //formContext.getControl("niq_leadid").setVisible(true);
    }
}
//DYNCRM-21871 -- Check if the associated account is in compliance or not --------Functions Start here 

function checkAccountComplianceCondition(accountId, formContext, fieldName, opportunityType, fieldLogicalName, accounttype) {
    //commented for 22194
    //return;
    var isComplianceBlocked = false; // Track if any compliance condition triggers
    // Always check for Compliance Status 610570002, regardless of opportunityType
    checkComplianceStatus(
        formContext, // Pass formContext
        accountId,
        610570002, // New Compliance Status
        fieldName + ": At least one of this Opportunity Account(s) is 'Compliance Restricted'. Please contact Ethics and Compliance Team at Compliance.Inbox@smb.nielseniq.com to get approval for this Opportunity and upload it to Files SharePoint. Otherwise, the FAR will be rejected by OM.",
        "",
        true, // Set 'niq_readyfornextstage' to 'Yes' (1)
        fieldLogicalName,
        accounttype
    );

    // If opportunityType is defined, proceed with the existing conditions
    if (opportunityType) {
        var opportunityTypeValue = opportunityType.getValue();

        // Existing conditions for Opportunity Type 1
        if (opportunityTypeValue === 1) {
            if (checkComplianceStatus(
                formContext,
                accountId,
                (fieldName === "Account Name") ? [610570001, 610570004] : [610570001, 610570004],
                //610570000, // Compliance Blocked
                fieldName + ": Account(s) on this Opportunity have status Compliance Blocked. To proceed further with this Opportunity, select different Account(s). If not, close this Opportunity as Lost.",
                fieldName + ": Account(s) on this Opportunity have status [Financial Blocked / Financial Blocked in MSD]. To proceed further with this Opportunity, select a different account(s). If not possible, close this Opportunity as Lost.",
                false, // Set 'niq_readyfornextstage' to 'No' (0)
                fieldLogicalName,
                accounttype
            )) {
                isComplianceBlocked = true;
            }
        }
        // Existing conditions for Opportunity Type 2
        else if (opportunityTypeValue === 2) {
            var existingContractAction = formContext.getAttribute("niq_existingcontractaction").getValue();
            var isCanceled = formContext.getAttribute("niq_iscanceled").getValue();

            if (existingContractAction !== 4 && (isCanceled === 100000001 || isCanceled === 100000000)) {
                if (checkComplianceStatus(
                    formContext,
                    accountId,
                    (fieldName === "Account Name") ? [610570001, 610570004] : [610570001, 610570004], // Compliance Blocked
                    fieldName + ": Account(s) on this Opportunity have status Compliance Blocked. To proceed further with this Opportunity, select different Account(s). If not, close this Opportunity as Lost.",
                    fieldName + ": Account(s) on this Opportunity have status [Financial Blocked / Financial Blocked in MSD]. To proceed further with this Opportunity, select a different account(s). If not possible, close this Opportunity as Lost.",
                    false, // Set 'niq_readyfornextstage' to 'No' (0)
                    fieldLogicalName,
                    accounttype
                )) {
                    isComplianceBlocked = true;
                }
            } else if (existingContractAction === 4 && isCanceled === 100000001) {
                if (checkComplianceStatus(
                    formContext,
                    accountId,
                    (fieldName === "Account Name") ? [610570001, 610570004] : [610570001, 610570004], // Compliance Blocked
                    fieldName + ": Account(s) on this Opportunity have status Compliance Blocked. To proceed further with this Opportunity, select different Account(s). If not, close this Opportunity as Lost.",
                    fieldName + ": Account(s) on this Opportunity have status [Financial Blocked / Financial Blocked in MSD]. To proceed further with this Opportunity, select a different account(s). If not possible, close this Opportunity as Lost.",
                    false,// Set 'niq_readyfornextstage' to 'No' (0)
                    fieldLogicalName,
                    accounttype
                )) {
                    isComplianceBlocked = true;
                }
            } else if (existingContractAction === 4 && isCanceled === 100000000) {
                if (checkComplianceStatus(
                    formContext,
                    accountId,
                    (fieldName === "Account Name") ? [610570001, 610570004] : [610570001, 610570004], // Compliance Blocked
                    fieldName + ": Account(s) on this Opportunity have status Compliance Blocked. You can only proceed further with this Opportunity as long as Is Canceled field = Canceled.",
                    fieldName + ": Account(s) on this Opportunity have status Financial Blocked / Financial blocked in MSD. You can only proceed further with this Opportunity as long as field Is Canceled? = Canceled",
                    true, // Set 'niq_readyfornextstage' to 'Yes' (1)
                    fieldLogicalName,
                    accounttype
                )) {
                    isComplianceBlocked = true;
                }
            }
        }
    }

    return isComplianceBlocked; // Return if a compliance issue was found
}

// Generic function to check compliance status
function checkComplianceStatus(formContext, accountId, complianceStatusToCheck, message, message2, readyForNextStageValue, fieldLogicalName, accounttype) {
    //commented for 22194
    //return;
    Xrm.WebApi.retrieveRecord("account", accountId, "?$select=niq_compliancefinancialstatus,statecode").then(function (account) {
        var complianceStatus = account.niq_compliancefinancialstatus;
        var stateCode = account.statecode;
        if ((complianceStatus === 610570004 || complianceStatus === 610570003)) {
            message = message2
        }
        // If the complianceStatusToCheck is an array, check if the complianceStatus is in that array
        if (Array.isArray(complianceStatusToCheck)) {
            if (complianceStatusToCheck.includes(complianceStatus)) {
                var notificationKey = fieldLogicalName + "_ComplianceBlockedWarning"; // Use accountId for notification key
                formContext.ui.setFormNotification(message, "WARNING", notificationKey);
                formContext.getAttribute("niq_readyfornextstage").setValue(readyForNextStageValue);
            }
        } else {
            // Else just compare with the single complianceStatus
            if (complianceStatus === complianceStatusToCheck) {
                var notificationKey = fieldLogicalName + "_ComplianceBlockedWarning"; // Use accountId for notification key
                formContext.ui.setFormNotification(message, "WARNING", notificationKey);
                formContext.getAttribute("niq_readyfornextstage").setValue(readyForNextStageValue);
            }
        }
        // If the account is inactive, display the inactive account notification
        if (accounttype === "Customer") {
            if (complianceStatus === 610570007) {
                formContext.ui.setFormNotification("Customer Account on this Opportunity have status Inactive. To proceed further with this Opportunity, select a different customer account", "WARNING", "AccountInactive");
                formContext.getAttribute("niq_readyfornextstage").setValue(false);
            } else {
                formContext.ui.clearFormNotification("AccountInactive"); // Remove notification if the condition is resolved
            }
        }
    });
}

// Remove notification for a particular field if the condition is resolved
function removeNotification(formContext, fieldLogicalName) {
    var notificationKey = fieldLogicalName + "_ComplianceBlockedWarning"; // Use accountId for notification key
    formContext.ui.clearFormNotification(notificationKey); // Remove notification if the condition is resolved
}

//IC-POC #26171_B

// Added function to display Revenue Share Line Creation Status Notification

function displayRevenueShareLineCreationStatus(executionContext) {
    const formContext = executionContext.getFormContext();
    const process = formContext.data.process;
    const NOTIFICATION_ID = "revShareNotification";

    /**
     * Evaluates the current BPF stage and status field,
     * displays an appropriate notification, and resets the status if required.
     */
    function evaluateAndShowNotification() {
        const currentStage = process.getActiveStage();
        if (!currentStage) return;

        const stageName = currentStage.getName();
        const statusAttr = formContext.getAttribute("niq_revsharelinecreationstatus");

        // Remove any existing notification to avoid duplication
        formContext.ui.clearFormNotification(NOTIFICATION_ID);

        // Show notification only when current stage is 'Proposal' and status exists
        if (stageName === "Proposal" && statusAttr) {
            const status = statusAttr.getText();
            if (!status) return;

            let message = "";
            let level = "INFO";

            // Determine the message and level based on the current status
            switch (status) {
                case "In Progress":
                    message = "Revenue Share Lines generation is in progress for this opportunity. Please refresh the form after some time for further status.";
                    level = "WARNING";
                    break;
                case "Completed":
                    message = "Revenue Share Lines generation completed. Please refresh the form and proceed further.";

                    // Reset the status field to null to avoid repeat notification on reload
                    statusAttr.setValue(null);
                    //formContext.data.entity.save(); // Save the updated status field
                    break;
                case "Failed":
                    message = "Revenue Share Lines generation failed for this opportunity. Please check and  try again.";
                    level = "ERROR";
                    break;
                default:
                    return; // Exit if status doesn't match expected values
            }

            // Show the corresponding notification on the form
            formContext.ui.setFormNotification(message, level, NOTIFICATION_ID);
        }
    }

    // Trigger the notification evaluation logic on form load
    evaluateAndShowNotification();

    // Re-evaluate when stage changes (optional enhancement)
    process.addOnStageChange(evaluateAndShowNotification);
}

//IC-POC #26171_E