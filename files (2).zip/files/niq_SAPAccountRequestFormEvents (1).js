if (typeof SAPAccountRequestForm === "undefined") {
    SAPAccountRequestForm = {
        __namespace: true,
    };
}

SAPAccountRequestForm.IsRegisteredOnFieldChangeEvent = false;
SAPAccountRequestForm.IsValidateDuplicateAccountsOnSave = false;
SAPAccountRequestForm.IsCreateSalesOrgOnSaveOfAccountRequestExecuted = false;

SAPAccountRequestForm.RequestStatusFields = [
    "niq_requeststatus_new",
    "niq_requeststatus_db",
    "niq_requeststatus_compliancereview",
    "niq_requeststatus_mdmreview",
    "niq_requeststatus_closed",
    "header_process_niq_requeststatus_new",
    "header_process_niq_requeststatus_db",
    "header_process_niq_requeststatus_compliancereview",
    "header_process_niq_requeststatus_mdmreview",
    "header_process_niq_requeststatus_closed",
];

SAPAccountRequestForm.StageRequestStatusFieldsMapping = {
    "new": ["niq_requeststatus_new", "header_process_niq_requeststatus_new"],
    "dnb match": ["niq_requeststatus_db", "header_process_niq_requeststatus_db"],
    "compliance review": ["niq_requeststatus_compliancereview", "header_process_niq_requeststatus_compliancereview"],
    "mdm review": ["niq_requeststatus_mdmreview", "header_process_niq_requeststatus_mdmreview"],
    "closed": ["niq_requeststatus_closed", "header_process_niq_requeststatus_closed", "niq_mdmclosingcomments", "header_process_niq_mdmclosingcomments"]
};

SAPAccountRequestForm.RequestTypeFormGUIDMapping = {
    610570000: "7192f191-ba71-f011-b4cb-00224881030d", // New SAP Account Request
    610570001: "00f94f3f-18cf-ef11-b8e8-7c1e524e097b", // Modify SAP Account Request
    610570002: "e69afa5a-1dcf-ef11-b8e9-6045bdf50c47", // Extend SAP Account Request
    610570003: "97eea200-1ecf-ef11-b8e9-6045bd9791de", // SAP Account Compliance Blocking
    610570004: "97eea200-1ecf-ef11-b8e9-6045bd9791de", // SAP Account Finance Blocking
    610570005: "97eea200-1ecf-ef11-b8e9-6045bd9791de", // SAP Account Compliance Restriction
    610570006: "97eea200-1ecf-ef11-b8e9-6045bd9791de", // SAP Account Compliance Unblock
    610570007: "97eea200-1ecf-ef11-b8e9-6045bd9791de", // SAP Account Compliance Unrestrict
    610570008: "279dd486-0e36-f011-8c4e-7c1e528418ea", // Customer Account Creation 
    610570009: "296036e3-0e36-f011-8c4d-6045bd9e6513" // Customer Account Modification
};

SAPAccountRequestForm.Events = {
    FormOnload: function (executionContext) {
        try {
            const formContext = executionContext.getFormContext();
            const requestTypeAttribute = formContext.getAttribute("niq_requesttype");
            const formType = formContext.ui.getFormType();

            //Hide DnB Matach lookup on CREATE Form Type
            if (formContext.getAttribute("niq_dnbmatch")) {
                if (formType == 1 && requestTypeAttribute.getValue() == 610570000) { //create mode //New SAP Account Request
                    SAPAccountRequestForm.Events.ManageVisiblity(formContext, "niq_dnbmatch", false);
                }
                else {
                    SAPAccountRequestForm.Events.ManageVisiblity(formContext, "niq_dnbmatch", true);
                }
            }

            //Set current user as Requestor and create Sales Org
            if (formType == 1) {
                var userSettings = Xrm.Utility.getGlobalContext().userSettings;
                var currentuserid = userSettings.userId;
                var lookup = [];
                lookup[0] = {};
                lookup[0].id = currentuserid;
                lookup[0].entityType = "systemuser";
                lookup[0].name = userSettings.userName;
                formContext.getAttribute("niq_requestorname").setValue(lookup);

                formContext.data.entity.addOnPostSave(SAPAccountRequestForm.Events.CreateSalesOrgOnSaveOfAccountRequest);
            }

            formContext.data.entity.addOnPostSave(SAPAccountRequestForm.Events.populateHFMClientCode);

            if (requestTypeAttribute.getValue() != null) {
                if (!SAPAccountRequestForm.IsRegisteredOnFieldChangeEvent) {
                    const registerOnFieldChangeIfExists = (formContext, fieldName, handler) => {
                        const attribute = formContext.getAttribute(fieldName);
                        if (attribute) {
                            attribute.addOnChange(handler);
                        }
                    };

                    formContext.data.process.addOnPreStageChange(SAPAccountRequestForm.Events.BlockingBPFStageComplianceReview);
                    formContext.data.process.addOnPreStageChange(SAPAccountRequestForm.Events.fblockStageNavigationOnDuplicate);
                    formContext.data.process.addOnPreStageChange(this.restrictUserToMovePreviousStage);
                    formContext.data.process.addOnStageChange(SAPAccountRequestForm.Events.ValidateBPFStage);
                    formContext.data.process.addOnStageChange(SAPAccountRequestForm.Events.ValidateRequiredDocumentURLsForAccountRequest);
                    formContext.data.process.addOnStageChange(SAPAccountRequestForm.Events.MDMReviewStage);

                    registerOnFieldChangeIfExists(formContext, "niq_invoicedispatchmethod", SAPAccountRequestForm.Events.MappingCustomerGroupFieldsInvoiceDispatchMethod);
                    registerOnFieldChangeIfExists(formContext, "niq_porequired", SAPAccountRequestForm.Events.MappingCustomerGroupFieldsPoRequired);
                    registerOnFieldChangeIfExists(formContext, "niq_requeststatus", SAPAccountRequestForm.Events.LockFormComplianceReview);
                    registerOnFieldChangeIfExists(formContext, "niq_requeststatus", SAPAccountRequestForm.Events.lockFieldsMDMapproved);
                    registerOnFieldChangeIfExists(formContext, "niq_requeststatus_mdmreview", SAPAccountRequestForm.Events.OnChangeRequestStatusMDMReview);
                    registerOnFieldChangeIfExists(formContext, "niq_requesttype", SAPAccountRequestForm.Events.ValidateRequestType);
                    registerOnFieldChangeIfExists(formContext, "niq_requesttype", SAPAccountRequestForm.Events.LockFormComplianceReview);
                    registerOnFieldChangeIfExists(formContext, "ownerid", SAPAccountRequestForm.Events.ChangeOwner);
                    registerOnFieldChangeIfExists(formContext, "statecode", SAPAccountRequestForm.Events.ValidateBPFStage);
                    registerOnFieldChangeIfExists(formContext, "niq_taxtype1", SAPAccountRequestForm.Events.ManageTaxNumberRequirementLevel);
                    registerOnFieldChangeIfExists(formContext, "niq_taxtype2", SAPAccountRequestForm.Events.ManageTaxNumberRequirementLevel);
                    registerOnFieldChangeIfExists(formContext, "niq_taxtype3", SAPAccountRequestForm.Events.ManageTaxNumberRequirementLevel);
                    registerOnFieldChangeIfExists(formContext, "niq_taxtype4", SAPAccountRequestForm.Events.ManageTaxNumberRequirementLevel);
                    registerOnFieldChangeIfExists(formContext, "niq_taxtype5", SAPAccountRequestForm.Events.ManageTaxNumberRequirementLevel);
                    registerOnFieldChangeIfExists(formContext, "niq_accountspayableapcontact", SAPAccountRequestForm.Events.SetEmailField);

                    SAPAccountRequestForm.IsRegisteredOnFieldChangeEvent = true;
                }

                SAPAccountRequestForm.Events.ValidateRequestType(executionContext);
                SAPAccountRequestForm.Events.filterOwnerUserOnMDM(executionContext);
                SAPAccountRequestForm.Events.OnChangeOfCountryDetails(executionContext); // Added on 9/8/2025 to accomodate on load of countrt validation
                SAPAccountRequestForm.Events.HideShowCustomerGroupFields(executionContext);
                SAPAccountRequestForm.Events.lockFieldsMDMapproved(executionContext);
                SAPAccountRequestForm.Events.lockRequestStatusMDMUntilMDMReview(executionContext);
                SAPAccountRequestForm.Events.LockFormComplianceReview(executionContext);
                SAPAccountRequestForm.Events.MakeStatusInProgressForNewBPF(executionContext);
                SAPAccountRequestForm.Events.MappingCustomerGroupFieldsInvoiceDispatchMethod(executionContext);
                SAPAccountRequestForm.Events.MappingCustomerGroupFieldsPoRequired(executionContext);
                SAPAccountRequestForm.Events.OnChangeRequestStatusMDMReview(executionContext);
                SAPAccountRequestForm.Events.OnLoadFieldVisibilityForComplianceOnApprovedRequest(executionContext);
                SAPAccountRequestForm.Events.OnLoadFieldVisibilityForMDMOnApprovedRequest(executionContext);
                SAPAccountRequestForm.Events.OnLoadFieldVisibilityForMDMTeam(executionContext);
                SAPAccountRequestForm.Events.OnLoadFieldVisibilityForSellers(executionContext);
                SAPAccountRequestForm.Events.OnLoadFieldVisibilityForSellersOnApprovedRequest(executionContext);
                SAPAccountRequestForm.Events.populateFinanceIndustryMapping(executionContext);
                SAPAccountRequestForm.Events.populateHFMClientCode(executionContext);
                SAPAccountRequestForm.Events.prePopulateFieldsOnAccountRequestExt(executionContext);
                SAPAccountRequestForm.Events.RemoveOptionsforMDMStatus(executionContext);
                SAPAccountRequestForm.Events.showHideFields(executionContext);
                SAPAccountRequestForm.Events.ValidateBPFStage(executionContext);
                SAPAccountRequestForm.Events.ValidateRequiredDocumentURLsForAccountRequest(executionContext);
                SAPAccountRequestForm.Events.OnLoadFieldRequiredLevelForAllUsers(executionContext);
                SAPAccountRequestForm.Events.ManageTaxNumberRequirementLevel(executionContext);
                SAPAccountRequestForm.Events.SetEmailField(executionContext);

                const requestType = requestTypeAttribute?.getValue();

                switch (requestType) {
                    case 610570000: // New SAP Account Request
                        formContext.getAttribute("niq_accounttype")?.setValue(2);
                        //TEMP formContext.getControl("niq_requesttype")?.setDisabled(true);
                        //TEMP formContext.getControl("niq_state")?.setDisabled(false);
                        //TEMP formContext.getControl("niq_housenumber")?.setDisabled(false);
                        //TEMP formContext.getControl("niq_relatedopportunity")?.setDisabled(false);
                        //TEMP formContext.getControl("niq_dunsnumber")?.setDisabled(false);
                        //TEMP formContext.getControl("niq_dnbmatch")?.setDisabled(false);
                        //TEMP formContext.getAttribute("niq_housenumber")?.setRequiredLevel("none");
                        formContext.getAttribute("niq_dnbmatch")?.addOnChange(SAPAccountRequestForm.Events.populateFieldsFromDnBMatch);
                        formContext.data.entity.addOnPostSave(SAPAccountRequestForm.Events.moveNextStage);
                        SAPAccountRequestForm.Events.makeMDMCommentsRequired(executionContext);

                        if (formType == 1) {
                            SAPAccountRequestForm.Events.SetDefaultValueForCommunicationMethod(executionContext);
                            SAPAccountRequestForm.Events.setDefaultValueforLegalReviewFields(executionContext);
                        }
                        break;

                    default:
                        // No action needed for other request types
                        break;
                }
            }
        }
        catch (exception) {
            console.log("Error in FormOnload: " + exception);
        }
    },

    FormOnSavefunction: async function (executionContext) {
        const formContext = executionContext.getFormContext();

        if (!SAPAccountRequestForm.IsValidateDuplicateAccountsOnSave) {
            executionContext.getEventArgs().preventDefault();

            const isDuplicate = await SAPAccountRequestForm.Events.IsDuplicateAccountFound(formContext);
            const accountSubgrid = formContext.getControl("SG_DuplicateAccounts");
            const duplicateSection = formContext.ui.tabs.get("New SAP Account Details").sections.get("DuplicateAccounts");

            if (isDuplicate) {
                SAPAccountRequestForm.IsValidateDuplicateAccountsOnSave = false;
                SAPAccountRequestForm.Events.ShowCustomErrorMessage(formContext);
                //TEMP duplicateSection.setVisible(true);
                const filterXml = await SAPAccountRequestForm.Events.GetFetchConditionForDuplicateAccount(formContext);
                accountSubgrid.setFilterXml(filterXml);
                accountSubgrid.refresh();

            } else {
                SAPAccountRequestForm.IsValidateDuplicateAccountsOnSave = true;
                formContext.ui.clearFormNotification("Error_DuplicateAccounts");
                //TEMP duplicateSection.setVisible(false);
                accountSubgrid.setFilterXml("<filter type='and'><condition attribute='accountid' operator='null' /></filter>");
                accountSubgrid.refresh();
                formContext.data.entity.save();
            }
        }

        SAPAccountRequestForm.Events.checkDuplicateDUNS(executionContext);
    },

    SetDefaultValueForCommunicationMethod: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var communicationMethodAttribute = formContext.getAttribute("niq_communicationmethod");
        if (communicationMethodAttribute) {
            var sapAccountMasterSupportData = await Xrm.WebApi.retrieveRecord("niq_sapaccountmastersupportdata", "6163b95a-b10b-f011-bae4-7c1e5285f8dc", "?$select=niq_sapaccountmastersupportdataid,niq_name");
            if (sapAccountMasterSupportData != null) {
                const communicationMethodLookupValue = [{
                    id: sapAccountMasterSupportData.niq_sapaccountmastersupportdataid,
                    name: sapAccountMasterSupportData.niq_name,
                    entityType: "niq_sapaccountmastersupportdata"
                }];
                communicationMethodAttribute.setValue(communicationMethodLookupValue);
            }
        }
    },

    setDefaultValueforLegalReviewFields: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var legalSAPAccountGroup = formContext.getAttribute("niq_legalsapaccountgroup");
        var legalSAPAccountGroupType = formContext.getAttribute("niq_legalsapaccountgrouptype");
        var legalSAPAccountType = formContext.getAttribute("niq_legalsapaccounttype");
        if (legalSAPAccountGroup) {
            var legalSAPAccountGroupData = await Xrm.WebApi.retrieveRecord("niq_sapaccountmastersupportdata", "d3401567-1b6e-f011-b4cc-7c1e528418ea", "?$select=niq_sapaccountmastersupportdataid,niq_name");
            if (legalSAPAccountGroupData) {
                var legalSAPAccountGroupLookup = {
                    id: legalSAPAccountGroupData["niq_sapaccountmastersupportdataid"],
                    name: legalSAPAccountGroupData["niq_name"],
                    entityType: "niq_sapaccountmastersupportdata"
                };
                legalSAPAccountGroup.setValue([legalSAPAccountGroupLookup]);
            }
        }
        if (legalSAPAccountGroupType) {
            var legalSAPAccountGroupTypeData = await Xrm.WebApi.retrieveRecord("niq_sapaccountmastersupportdata", "e6da8191-1b6e-f011-b4cc-7c1e528418ea", "?$select=niq_sapaccountmastersupportdataid,niq_name");
            if (legalSAPAccountGroupTypeData) {
                var legalSAPAccountGroupTypeLookup = {
                    id: legalSAPAccountGroupTypeData["niq_sapaccountmastersupportdataid"],
                    name: legalSAPAccountGroupTypeData["niq_name"],
                    entityType: "niq_sapaccountmastersupportdata"
                };
                legalSAPAccountGroupType.setValue([legalSAPAccountGroupTypeLookup]);
            }
        }
        if (legalSAPAccountType) {
            var legalSAPAccountTypeData = await Xrm.WebApi.retrieveRecord("niq_sapaccountmastersupportdata", "311b2d80-1e6e-f011-b4cc-7c1e528418ea", "?$select=niq_sapaccountmastersupportdataid,niq_name");
            if (legalSAPAccountTypeData) {
                var legalSAPAccountTypeDataLookup = {
                    id: legalSAPAccountTypeData["niq_sapaccountmastersupportdataid"],
                    name: legalSAPAccountTypeData["niq_name"],
                    entityType: "niq_sapaccountmastersupportdata"
                };
                legalSAPAccountType.setValue([legalSAPAccountTypeDataLookup]);
            }
        }
    },

    ManageTaxNumberRequirementLevel: function (executionContext) {
        var formContext = executionContext.getFormContext();

        for (let i = 1; i <= 5; i++) {
            let taxTypeField = `niq_taxtype${i}`;
            let taxNumberField = `niq_taxnumber${i}`;
            let taxTypeAttribute = formContext.getAttribute(taxTypeField);
            if (taxTypeAttribute && taxTypeAttribute.getValue() != null) {
                SAPAccountRequestForm.Events.ManageRequiredLevel(formContext, taxNumberField, "required");
            } else {
                SAPAccountRequestForm.Events.ManageRequiredLevel(formContext, taxNumberField, "none");
            }
        }
    },

    CreateSalesOrgOnSaveOfAccountRequest: function (executionContext) {
        const formContext = executionContext.getFormContext();
        if (!SAPAccountRequestForm.IsCreateSalesOrgOnSaveOfAccountRequestExecuted) {
            var salesOrgAttribute = formContext.getAttribute("niq_salesorg");
            if (salesOrgAttribute && salesOrgAttribute.getValue() != null) {
                var salesOrgValue = salesOrgAttribute.getValue();
                SAPAccountRequestForm.Events.CreateSalesOrgExtensionRecord(formContext, salesOrgValue[0]);
                SAPAccountRequestForm.IsCreateSalesOrgOnSaveOfAccountRequestExecuted = true;
            }
        }
    },

    OnLoadFieldRequiredLevelForAllUsers: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const formType = formContext.ui.getFormType();
        const arrFields = ["niq_salesorg", "niq_accountspayableapcontact", "niq_porequired", "niq_invoicedispatchmethod", "niq_willsapaccountuseanytradeandbarter", "niq_invoicedispatchmethod"];
        arrFields.forEach(field => {
            SAPAccountRequestForm.Events.ManageVisiblity(formContext, field, true);
            SAPAccountRequestForm.Events.ManageRequiredLevel(formContext, field, "required");
            SAPAccountRequestForm.Events.ManageAccessiblity(formContext, field, false);
        });

        if (formType != 1) {
            SAPAccountRequestForm.Events.ManageAccessiblity(formContext, "niq_salesorg", true);
        }
    },

    ValidateBPFStage: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const currentStage = formContext.data.process.getActiveStage();

        if (!currentStage) {
            console.log("No active stage found in BPF.");
            return;
        }

        const stageName = currentStage.getName()?.toLowerCase();
        const requestTypeAttr = formContext.getAttribute("niq_requesttype");
        const requestStatusFieldArray = SAPAccountRequestForm.StageRequestStatusFieldsMapping[stageName];
        const formType = formContext.ui.getFormType();

        if (requestStatusFieldArray) {
            SAPAccountRequestForm.Events.ManageRequestStatusFieldBehavior(formContext, requestStatusFieldArray);
        }

        // Make request type fields editable for non-create forms
        if (formType !== 1) {
            SAPAccountRequestForm.Events.ManageAccessiblity(formContext, "niq_requesttype", true);
            SAPAccountRequestForm.Events.ManageAccessiblity(formContext, "header_process_niq_requesttype", true);
        }

        // Enable or disable ownerid fields based on stage
        const isMDMReview = stageName === "mdm review";

        if (CommonForm.Events.CheckFieldExists(formContext, "ownerid")) {
            SAPAccountRequestForm.Events.ManageAccessiblity(formContext, "ownerid", !isMDMReview);
            SAPAccountRequestForm.Events.ManageAccessiblity(formContext, "header_ownerid", !isMDMReview);
        }

        if (isMDMReview) {
            SAPAccountRequestForm.Events.assignToMDMTeamInMDMBPF(executionContext);
        }
        if (requestTypeAttr.getValue() !== null && requestTypeAttr.getValue() == 610570000 && stageName == "compliance review") {
            formContext.getAttribute("niq_requeststatus_compliancereview").setValue(610570000);
            formContext.getAttribute("niq_requeststatus").setValue(610570005);
        }
    },

    ValidateRequestType: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const formType = formContext.ui.getFormType();
        const requestTypeAttribute = formContext.getAttribute("niq_requesttype");

        if (requestTypeAttribute) {
            const requestTypeValue = requestTypeAttribute.getValue();
            //New
            if (requestTypeValue == 610570000) {
                //TEMP formContext.ui.process.setVisible(true);
            } else {
                //TEMP formContext.ui.process.setVisible(false);
            }
            const targetFormId = SAPAccountRequestForm.RequestTypeFormGUIDMapping[requestTypeValue];

            if (targetFormId && targetFormId.toLowerCase() !== formContext.ui.formSelector.getCurrentItem().getId()) {
                if (formType !== 1) {
                    SAPAccountRequestForm.Events.NavigateToExistingForm(formContext, targetFormId);
                }
                else {
                    SAPAccountRequestForm.Events.NavigateToNewForm(formContext, targetFormId, requestTypeValue);
                }
            }
        }
    },

    NavigateToExistingForm: function (formContext, targetFormId) {
        if (formContext.ui.formSelector) {
            const availableForms = formContext.ui.formSelector.items.get();
            const targetForm = availableForms.find(form => form.getId().toLowerCase() === targetFormId.toLowerCase());
            if (targetForm) {
                targetForm.navigate();
            }
        }
    },

    NavigateToNewForm: function (formContext, targetFormId, requestTypeValue) {
        const opportunityAttribute = formContext.getAttribute("niq_relatedopportunity");
        const opportunityValue = opportunityAttribute ? opportunityAttribute.getValue() : null;
        var formParameters = {};
        formParameters["niq_relatedopportunity"] = opportunityValue ? opportunityValue : null;
        formParameters["niq_requesttype"] = requestTypeValue;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_accountrequest";
        entityFormOptions["createFromEntity"] = opportunityValue ? opportunityValue[0] : null;
        entityFormOptions["formId"] = targetFormId.toUpperCase();
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );
    },

    OnLoadFieldVisibilityForSellers: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var requestType = formContext.getAttribute("niq_requesttype")?.getValue();
        var mdmstatus = formContext.getAttribute("niq_requeststatus_mdmreview")?.getValue();
        var formType = formContext.ui.getFormType();

        const isSalesUser = CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User");
        const isMDMReviewer = CommonForm.Events.CheckIfLoggedInUserRoles("NIQ MDM Reviewers");

        const setFieldsDisabled = (fields) => {
            fields.forEach(field => {
                SAPAccountRequestForm.Events.ManageAccessiblity(formContext, field, true);
            });
        };

        const setFieldsEnabledRequired = (fields) => {
            fields.forEach(field => {
                SAPAccountRequestForm.Events.ManageAccessiblity(formContext, field, false);
                SAPAccountRequestForm.Events.ManageRequiredLevel(formContext, field, "required");
            });
        };

        const hideFields = (fields) => {
            fields.forEach(field => {
                SAPAccountRequestForm.Events.ManageVisiblity(formContext, field, false);
            });
        };

        const clearRequiredLevels = () => {
            formContext.ui.controls.forEach(control => {
                let name = control.getName();
                if (name && formContext.getAttribute(name)) {
                    SAPAccountRequestForm.Events.ManageRequiredLevel(formContext, name, "none");
                }
            });
        };

        let arrFields = [];
        let arrHideFields = [];
        let arrReadOnlyFields = [];

        if (formType === 2 && mdmstatus !== 610570008) {
            if (requestType === 610570000) {
                arrFields = requestType === 610570000
                    ? ["niq_city", "niq_country", "niq_customeraccount", "niq_isthisagovernmentaccount", "niq_language", "ownerid", "niq_willsapaccountuseanytradeandbarter", "niq_sapaccountname", "niq_dunsnumber", "niq_housenumber", "niq_dnbmatch", "header_ownerid", "niq_porequired", "niq_zipcode", "niq_requeststatus", "niq_requesttype", "niq_requestorname", "niq_accountrequestnumber", "niq_addressline1", "niq_willsapaccountuseanytradebarter", "niq_ultimateparentaccount", "niq_vatabncompanyregistrationnumber"]
                    : ["niq_city", "niq_country", "niq_customeraccount", "niq_dunsnumber", "niq_housenumber", "niq_industrycode", "niq_invoicedispatchmethod", "niq_isthisagovernmentaccount", "niq_language", "niq_sapaccountname", "header_ownerid", "niq_porequired", "niq_zipcode", "niq_requeststatus", "niq_requesttype", "niq_requestorname", "niq_requestorscomment", "niq_accountrequestnumber", "niq_addressline1", "niq_addressline2", "niq_willsapaccountuseanytradebarter", "niq_telnumber", "niq_ultimateparentaccount", "niq_vatabncompanyregistrationnumber"];

                if (isSalesUser) {
                    formContext.ui.controls.forEach(control => {
                        let name = control.getName();
                        //TEMP if (name) control.setDisabled(true);
                    });
                    setFieldsEnabledRequired(arrFields);

                    arrFields = ["niq_industrycode", "niq_requestorscomment", "niq_addressline2", "niq_telnumber"];
                    arrFields.forEach(field => {
                        SAPAccountRequestForm.Events.ManageAccessiblity(formContext, field, false);
                    })
                }
            }
        } else if (formType === 1 && requestType === 610570000 && isSalesUser) {
            arrFields = ["niq_sapaccountname", "niq_country", "niq_requestorname"];
            clearRequiredLevels();
            setFieldsEnabledRequired(arrFields);
        }

        if (mdmstatus == 610570008 && requestType == 610570000 && isSalesUser) {
            arrFields = ["niq_accountingclerk", "niq_accountassigngroup", "niq_arpledging", "niq_customergroup1", "niq_customergroup2", "niq_customergroup3", "niq_customergroup4", "niq_customergroup5", "niq_customerorderblock", "niq_deliveringplant", "niq_distributionchannel", "niq_district", "niq_division", "niq_housebank", "niq_lockboxkey", "niq_periodicacctstatements", "niq_previousnumber", "niq_salesoffice", "niq_withholdingtaxagent", "niq_withholdingtaxcode", "niq_withholdingtaxtype", "niq_withholdtaxvalidfrom", "niq_withholdtaxvalidto"];
            formContext.ui.controls.forEach(control => {
                let name = control.getName();
                if (name && formContext.getAttribute(name)) {
                    SAPAccountRequestForm.Events.ManageAccessiblity(formContext, name, true);
                }
            });
            hideFields(arrFields);
        }

        if (requestType == 610570000) { //New SAP Account Request
            if (isSalesUser) {
                arrHideFields = ["niq_accountingclerk", "niq_bankaccountno", "niq_bankcontrolkey", "niq_bankcountrykey", "niq_banktype", "niq_collectionprofile", "niq_countrykey", "niq_recordpaymenthistory", "niq_nameco", "niq_personnelnumber", "niq_street1", "niq_street2", "niq_street3", "niq_taxjurcode"];
                arrReadOnlyFields = ["niq_communicationmethod", "niq_customernumber", "niq_email", "niq_hfmclientcodeid", "niq_industrysector", "niq_compliancecomments", "niq_mdmclosingcomments", "niq_legalsapaccountgroup", "niq_legalsapaccountgrouptype", "niq_legalsapaccounttype", "niq_previousaccountnumber", "niq_requeststatus", "niq_requesttype", "niq_accountrequestnumber", "niq_screeningresult", "niq_taxnumber1", "niq_taxnumber2", "niq_taxnumber3", "niq_taxnumber4", "niq_taxnumber5", "niq_taxtype1", "niq_taxtype2", "niq_taxtype3", "niq_taxtype4", "niq_taxtype5", "niq_vatregistrationnumber", "niq_risklevel"];
                hideFields(arrHideFields);
                setFieldsDisabled(arrReadOnlyFields);
            }

            if (isMDMReviewer) {
                arrHideFields = ["niq_collectionprofile", "niq_countrykey", "niq_recordpaymenthistory", "niq_nameco", "niq_personnelnumber", "niq_addressline1", "niq_addressline2", "niq_street1", "niq_street2", "niq_street3", "niq_taxjurcode"];
                arrReadOnlyFields = ["niq_customernumber", "niq_compliancecomments", "niq_previousaccountnumber", "niq_requesttype", "niq_requestorname", "niq_accountrequestnumber", "niq_screeningresult"];
                hideFields(arrHideFields);
                setFieldsDisabled(arrReadOnlyFields);
            }
        }
    },

    triggerDnBOnAccountRequest: async function (executionContext, currentGuid) {
        var dunsmatchuniqueguid = null;
        var formContext = executionContext.getFormContext();
        var results = await Xrm.WebApi.retrieveMultipleRecords("niq_accountrequestprocessflow", "?$select=_activestageid_value&$filter=_bpf_niq_accountrequestid_value eq " + currentGuid.replace("{", "").replace("}", "") + "");
        var result = results.entities[0];
        var activestageid = result["_activestageid_value"]; // Lookup
        var activeStageName = result["_activestageid_value@OData.Community.Display.V1.FormattedValue"];
        if (activeStageName !== "Dnb Match")
            return;
        var accountname = formContext.getAttribute("niq_sapaccountname")?.getValue();
        var trimmedname = accountname.replace(/\s*\(.*?\)\s*/g, "").trim();
        var country = formContext.getAttribute("niq_country")?.getValue();
        var countrycode = null;
        if (country != null) {
            var result = await Xrm.WebApi.retrieveRecord("niq_country", country[0].id.slice(1, -1), "?$select=niq_countrycode,niq_isvatrequired");
            if (result != null) {
                countrycode = result.niq_countrycode;
            }
        }

        var query = {};
        if (trimmedname != null && countrycode != null) {
            var dnbmatchuniqueguidtemp = formContext.getAttribute("niq_dnbmatchuniqueguidtemp").getValue();
            if (dnbmatchuniqueguidtemp != null) {
                dunsmatchuniqueguid = dnbmatchuniqueguidtemp;
            }
            else if (dunsmatchuniqueguid == null) {
                dunsmatchuniqueguid = this.generateTimeBasedGUID();
                formContext.getAttribute("niq_dnbmatchuniqueguidtemp").setValue(dunsmatchuniqueguid);
            }

            query.dnbmatchuniqueguidtemp = dunsmatchuniqueguid;
            query.Accountname = trimmedname;
            query.CountryCode = countrycode;

            if (result.niq_isvatrequired) {
                var vtp = formContext.getAttribute("niq_vatabncompanyregistrationnumber")?.getValue();
                if (vtp != "NA")
                    query.registrationNumber = vtp;
            }
            else {
                query.streetAddressLine1 = formContext.getAttribute("niq_addressline1")?.getValue();
                query.streetAddressLine2 = formContext.getAttribute("niq_addressline2")?.getValue();
                query.addressLocality = formContext.getAttribute("niq_city")?.getValue();
                query.postalCode = formContext.getAttribute("niq_zipcode")?.getValue();
                var statelookup = formContext.getAttribute("niq_state").getValue();
                if (statelookup && statelookup.length > 0) {
                    var stateId = statelookup[0].id.replace("{", "").replace("}", "");
                    Xrm.WebApi.retrieveRecord("niq_sapcountrystate", stateId, "?$select=niq_statecode").then(
                        function (result) {
                            query.addressRegion = result.niq_statecode;
                            console.log("State Code:", result.niq_statecode)
                        },
                        function (error) {
                            console.error("Error retrieving state record:", error.message);
                        }

                    )
                }
            }

            Xrm.Utility.showProgressIndicator("Searching D&B Match Records.....");
            var data = await this.callflow(query);

            //Handle flow response
            if (data == "Success") {
                //Close Progress bar
                Xrm.Utility.closeProgressIndicator();

                //Show DNB related fields
                SAPAccountRequestForm.Events.ManageVisiblity(formContext, "niq_dnbmatch", true);
                SAPAccountRequestForm.Events.ManageVisiblity(formContext, "niq_dunsnumber", true);

            }
            else
                if (data == "Error") {
                    //Close Progress bar
                    Xrm.Utility.closeProgressIndicator();

                    //Show error
                    var alertStrings = {
                        confirmButtonLabel: "OK",
                        text: "DNB Matching service is not working as expected! Please try after sometime.",
                        title: "DNB Match Error"
                    };
                    var alertOptions = { height: 120, width: 260 };
                    Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                }

        }
        console.log(data);
    },

    // US-24896-24640-25150
    //this goes on save of form
    OnSaveDeleteOtherDnbMatch: function (executionContext) {
        var dunsmatchuniqueguid;
        var formContext = executionContext.getFormContext();
        var requestType = formContext.getAttribute("niq_requesttype")?.getValue();
        var dnbmatch = formContext.getAttribute("niq_dnbmatch")?.getValue();
        var stage = formContext.data.process.getActiveStage();
        if (dnbmatch != null && stage.getName() === "MDM Review") {
            var dnbMatchGuid = dnbmatch[0].id.replace("{", "").replace("}", "");
            if (requestType != null && requestType == 610570000 && dnbMatchGuid.toLowerCase() !== "9b278438-ac6b-f011-b4cb-6045bda1a937") {
                var fetchData = {
                    "niq_dnbmatchid": dnbmatch[0].id.slice(1, -1),
                    "niq_name": "Match Not Found",
                    "niq_dunsmatchuniqueguid": dunsmatchuniqueguid == null ? formContext.getAttribute("niq_dnbmatchuniqueguidtemp")?.getValue() : dunsmatchuniqueguid
                };
                var fetchXml = [
                    "<fetch>",
                    "  <entity name='niq_dnbmatch'>",
                    "    <attribute name='niq_dnbmatchid'/>",
                    "    <attribute name='niq_dunsnumber'/>",
                    "    <attribute name='niq_name'/>",
                    "    <filter>",
                    "      <condition attribute='niq_dnbmatchid' operator='ne' value='", fetchData.niq_dnbmatchid/*00000000-0000-0000-0000-000000000000*/, "'/>",
                    "      <condition attribute='niq_name' operator='ne' value='", fetchData.niq_name/*Match Not Found*/, "'/>",
                    "      <condition attribute='niq_dunsmatchuniqueguid' operator='eq' value='", fetchData.niq_dunsmatchuniqueguid, "'/>",
                    "    </filter>",
                    "  </entity>",
                    "</fetch>"
                ].join("");

                Xrm.WebApi.retrieveMultipleRecords("niq_dnbmatch", "?fetchXml=" + fetchXml).then(
                    function success(result) {
                        for (var i = 0; i < result.entities.length; i++) {
                            console.log(result.entities[i]['niq_dnbmatchid']);
                            Xrm.WebApi.deleteRecord("niq_dnbmatch", result.entities[i]['niq_dnbmatchid']).then(
                                function success(result) {
                                    console.log("Account deleted");
                                },
                                function (error) {
                                    console.log(error.message);
                                }
                            );
                        }
                    },
                    function (error) {
                        console.log(error.message);
                    }
                );
            }
        }
    },

    IsDuplicateAccountFound: async function (formContext) {
        const filterXml = SAPAccountRequestForm.Events.BuildDuplicateAccountConditions(formContext);
        if (!filterXml) return false;

        const fetchXml = `
            <fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
                <entity name="account">
                    ${filterXml}
                </entity>
            </fetch>`;

        const encodedFetchXml = encodeURIComponent(fetchXml);
        const response = await Xrm.WebApi.retrieveMultipleRecords("account", `?fetchXml=${encodedFetchXml}`);
        return response.entities?.length > 0;
    },

    GetFetchConditionForDuplicateAccount: async function (formContext) {
        return SAPAccountRequestForm.Events.BuildDuplicateAccountConditions(formContext);
    },

    BuildDuplicateAccountConditions: function (formContext) {
        const getValueOrEmpty = (fieldName) => {
            const value = formContext.getAttribute(fieldName)?.getValue();
            return value ?? "";
        };

        const accountLegalName = getValueOrEmpty("niq_sapaccountname");
        const dunsNumber = getValueOrEmpty("niq_dunsnumber");
        const vatTaxationNumber = getValueOrEmpty("niq_vattaxationnumber");

        if (!accountLegalName && !dunsNumber && !vatTaxationNumber) {
            return "";
        }

        let conditions = "";

        if (accountLegalName) {
            conditions += `<condition attribute="name" operator="eq" value="${accountLegalName}" />`;
        }
        if (dunsNumber) {
            conditions += `<condition attribute="niq_dunsnumber" operator="eq" value="${dunsNumber}" />`;
        }
        if (vatTaxationNumber) {
            for (let i = 1; i <= 5; i++) {
                conditions += `<condition attribute="niq_tax${i}" operator="eq" value="${vatTaxationNumber}" />`;
            }
        }

        return `
            <filter type="and">
                <filter type="or">
                    ${conditions}
                </filter>
            </filter>`;
    },

    onChangeOfCountry: async function (executionContext) {
        SAPAccountRequestForm.Events.OnChangeOfCountryDetails(executionContext);
        SAPAccountRequestForm.Events.triggerDnBOnAccountRequestonfieldchange(executionContext);
    },

    //24401
    OnChangeOfCountryDetails: async function (executionContext) {
        var Country;
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_country") && formContext.getAttribute("niq_country")?.getValue() != null) {
            Country = formContext.getAttribute("niq_country")?.getValue()[0].id;
        }
        if (Country != null || Country != "undefined") {
            var CountryId = Country.replace("{", "").replace("}", "");
            var CountryDetails = await Xrm.WebApi.retrieveRecord("niq_country", CountryId, "?$select=niq_name,niq_isvatrequired");
            var IsVATRequired = CountryDetails["niq_isvatrequired"];
            if (IsVATRequired == 1) {
                //TEMP formContext.getAttribute("niq_vatabncompanyregistrationnumber") ? formContext.getAttribute("niq_vatabncompanyregistrationnumber").setRequiredLevel("required") : console.log("niq_vatabncompanyregistrationnumber not found on the form");
                //TEMP formContext.getAttribute("niq_country") ? formContext.getAttribute("niq_country").setRequiredLevel("none") : console.log("niq_country not found on the form");
                //TEMP formContext.getAttribute("niq_city") ? formContext.getAttribute("niq_city").setRequiredLevel("none") : console.log("niq_city not found on the form");
                //TEMP formContext.getAttribute("niq_zipcode") ? formContext.getAttribute("niq_zipcode").setRequiredLevel("none") : console.log("niq_zipcode not found on the form");
                //TEMP formContext.getAttribute("niq_state") ? formContext.getAttribute("niq_state").setRequiredLevel("none") : console.log("niq_stateprovince not found on the form");
                //TEMP formContext.getAttribute("niq_addressline1") ? formContext.getAttribute("niq_addressline1").setRequiredLevel("none") : console.log("niq_addressline1 not found on the form");
                //TEMP formContext.getAttribute("niq_state") ? formContext.getAttribute("niq_state").setRequiredLevel("none") : console.log("niq_state not found on the form");
            }
            else if (IsVATRequired == 0 || IsVATRequired == null) {
                //TEMP formContext.getAttribute("niq_vatabncompanyregistrationnumber") ? formContext.getAttribute("niq_vatabncompanyregistrationnumber").setRequiredLevel("none") : console.log("niq_vatabncompanyregistrationnumber not found on the form");
                //TEMP formContext.getAttribute("niq_country") ? formContext.getAttribute("niq_country").setRequiredLevel("required") : console.log("niq_country not found on the form");
                //TEMP formContext.getAttribute("niq_city") ? formContext.getAttribute("niq_city").setRequiredLevel("required") : console.log("niq_city not found on the form");
                //TEMP formContext.getAttribute("niq_zipcode") ? formContext.getAttribute("niq_zipcode").setRequiredLevel("required") : console.log("niq_zipcode not found on the form");
                //TEMP formContext.getAttribute("niq_state") ? formContext.getAttribute("niq_state").setRequiredLevel("required") : console.log("niq_stateprovince not found on the form");
                //TEMP formContext.getAttribute("niq_addressline1") ? formContext.getAttribute("niq_addressline1").setRequiredLevel("required") : console.log("niq_addressline1 not found on the form");
                //TEMP formContext.getAttribute("niq_state") ? formContext.getAttribute("niq_state").setRequiredLevel("required") : console.log("niq_state not found on the form");
            }

            if (formContext.getAttribute("niq_housenumber")) {
                SAPAccountRequestForm.Events.ManageRequiredLevel(formContext, "niq_housenumber", CountryDetails["niq_name"] === "Brazil" ? "required" : "none");
            }
        }
        else {
            //TEMP formContext.getAttribute("niq_vatabncompanyregistrationnumber") ? formContext.getAttribute("niq_vatabncompanyregistrationnumber").setRequiredLevel("none") : console.log("niq_vatabncompanyregistrationnumber not found on the form");
            //TEMP formContext.getAttribute("niq_country") ? formContext.getAttribute("niq_country").setRequiredLevel("required") : console.log("niq_country not found on the form");
            //TEMP formContext.getAttribute("niq_city") ? formContext.getAttribute("niq_city").setRequiredLevel("none") : console.log("niq_city not found on the form");
            //TEMP formContext.getAttribute("niq_zipcode") ? formContext.getAttribute("niq_zipcode").setRequiredLevel("none") : console.log("niq_zipcode not found on the form");
            //TEMP formContext.getAttribute("niq_state") ? formContext.getAttribute("niq_state").setRequiredLevel("none") : console.log("niq_stateprovince not found on the form");
            //TEMP formContext.getAttribute("niq_addressline1") ? formContext.getAttribute("niq_addressline1").setRequiredLevel("none") : console.log("niq_addressline1 not found on the form");
            //TEMP formContext.getAttribute("niq_state") ? formContext.getAttribute("niq_state").setRequiredLevel("none") : console.log("niq_state not found on the form");
        }
    },

    triggerDnBOnAccountRequestonfieldchange: async function (executionContext) {
        var dunsmatchuniqueguid = null;
        var formContext = executionContext.getFormContext();
        const stage = formContext.data.process.getActiveStage();
        if (stage.getName() !== "Dnb Match")
            return;
        var accountname = formContext.getAttribute("niq_sapaccountname")?.getValue();
        var trimmedname = accountname.replace(/\s*\(.*?\)\s*/g, "").trim();
        var country = formContext.getAttribute("niq_country")?.getValue();
        var countrycode = null;
        if (country != null) {
            var result = await Xrm.WebApi.retrieveRecord("niq_country", country[0].id.slice(1, -1), "?$select=niq_countrycode,niq_isvatrequired");
            if (result != null) {
                countrycode = result.niq_countrycode;
            }
        }

        var query = {};
        if (trimmedname != null && countrycode != null) {
            var dnbmatchuniqueguidtemp = formContext.getAttribute("niq_dnbmatchuniqueguidtemp").getValue();
            if (dnbmatchuniqueguidtemp != null) {
                dunsmatchuniqueguid = dnbmatchuniqueguidtemp;
            }
            else if (dunsmatchuniqueguid == null) {
                dunsmatchuniqueguid = this.generateTimeBasedGUID();
                formContext.getAttribute("niq_dnbmatchuniqueguidtemp").setValue(dunsmatchuniqueguid);
            }

            query.dnbmatchuniqueguidtemp = dunsmatchuniqueguid;
            query.Accountname = trimmedname;
            query.CountryCode = countrycode;

            if (result.niq_isvatrequired) {
                var vtp = formContext.getAttribute("niq_vatabncompanyregistrationnumber")?.getValue();
                if (vtp != "NA")
                    query.registrationNumber = vtp;
            }
            else {
                query.streetAddressLine1 = formContext.getAttribute("niq_addressline1")?.getValue();
                query.streetAddressLine2 = formContext.getAttribute("niq_addressline2")?.getValue();
                query.addressLocality = formContext.getAttribute("niq_city")?.getValue();
                query.postalCode = formContext.getAttribute("niq_zipcode")?.getValue();
                var statelookup = formContext.getAttribute("niq_state").getValue();
                if (statelookup && statelookup.length > 0) {
                    var stateId = statelookup[0].id.replace("{", "").replace("}", "");
                    Xrm.WebApi.retrieveRecord("niq_sapcountrystate", stateId, "?$select=niq_statecode").then(
                        function (result) {
                            query.addressRegion = result.niq_statecode;
                            console.log("State Code:", result.niq_statecode)
                        },
                        function (error) {
                            console.error("Error retrieving state record:", error.message);
                        }

                    )
                }
            }

            Xrm.Utility.showProgressIndicator("Searching D&B Match Records.....");
            var data = await this.callflow(query);

            //Handle flow response
            if (data == "Success") {
                //Close Progress bar
                Xrm.Utility.closeProgressIndicator();

                //Show DNB related fields
                SAPAccountRequestForm.Events.ManageVisiblity(formContext, "niq_dnbmatch", true);
                SAPAccountRequestForm.Events.ManageVisiblity(formContext, "niq_dunsnumber", true);

            }
            else
                if (data == "Error") {
                    //Close Progress bar
                    Xrm.Utility.closeProgressIndicator();

                    //Show error
                    var alertStrings = {
                        confirmButtonLabel: "OK",
                        text: "DNB Matching service is not working as expected! Please try after sometime.",
                        title: "DNB Match Error"
                    };
                    var alertOptions = { height: 120, width: 260 };
                    Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                }

        }
        console.log(data);
    },

    // US-24403
    checkDuplicateDUNS: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var eventArgs = executionContext.getEventArgs();
        var saveMode = eventArgs.getSaveMode();
        var dunsNumber = formContext.getAttribute("niq_dunsnumber")?.getValue();
        var dnbMatch = formContext.getAttribute("niq_dnbmatch")?.getValue();
        var accountType = formContext.getAttribute("niq_accounttype")?.getValue();
        var accountRequestId = formContext.data.entity.getId().replace("{", "").replace("}", "");
        var process = executionContext.getFormContext().data.process;
        var activeStage = formContext.data.process.getActiveStage();
        var currentStage = activeStage.getName().toLowerCase();
        if (currentStage == "d&b match" || currentStage == "dnb match" || currentStage == 'mdm review') {
            if (dunsNumber !== null || dnbMatch != null) {
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_dunsnumber") || dnbMatch != null) {
                    var req1 = new XMLHttpRequest();
                    req1.open("GET", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/accounts?$filter=niq_dunsnumber eq '" + dunsNumber + "'", false);
                    req1.setRequestHeader("OData-MaxVersion", "4.0");
                    req1.setRequestHeader("OData-Version", "4.0");
                    req1.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req1.setRequestHeader("Accept", "application/json");
                    req1.setRequestHeader("Prefer", "odata.include-annotations=*");
                    req1.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req1.onreadystatechange = null;
                            if (this.status === 200) {
                                var results = JSON.parse(this.response);
                                console.log(results);
                                if (results.value.length > 0) {
                                    formContext.getAttribute("niq_requeststatus_db").setValue(610570011);
                                    var stageName = process.getActiveStage().getName();
                                    if (saveMode == 1 || saveMode == 2 || saveMode == 70) {
                                        eventArgs.preventDefault();
                                        formContext.ui.setFormNotification("An account with these details already exists. Duplicate account creation is not allowed. If you wish to change the existing account details, please submit a 'Modification' request.", "ERROR", "duplicate_duns");
                                    }

                                    var data =
                                    {
                                        "niq_requeststatus_db": 610570011,
                                        "niq_duplicatecheck": true
                                    }
                                    // update the record
                                    Xrm.WebApi.updateRecord("niq_accountrequest", accountRequestId, data).then(
                                        function success(result) {
                                            console.log("Account updated");

                                        },
                                        function (error) {
                                            console.log(error.message);

                                        }
                                    );

                                    formContext.data.process.moveNext(function (result) {
                                        if (result === "success") {
                                            console.log("BPF advanced to the next stage because the account was closed.");
                                        } else {
                                            console.error("Could not advance BPF stage.");
                                        }
                                    });
                                    SAPAccountRequestForm.Events.filterMatchingAccountsGrid(formContext, dunsNumber, accountType);
                                    if (accountType == 1) {
                                        formContext.getAttribute("niq_requeststatus").setValue(610570007);
                                    } else {
                                        formContext.getAttribute("header_process_niq_requeststatus_mdmreview").setValue(610570007);
                                    }
                                } else {
                                    formContext.ui.clearFormNotification("duplicate_duns");
                                    formContext.getAttribute("niq_requeststatus_db").setValue(610570000);
                                    if (accountType == 1) {
                                        //TEMP formContext.getControl("Duplicate_Accounts").setVisible(false);
                                        formContext.getAttribute("niq_duplicatecheck").setValue(false);
                                        var accountRef = formContext.getAttribute("niq_createdaccount")?.getValue();
                                        if (accountRef && accountRef.length > 0) {
                                            var entityFormOptions = {
                                                entityName: "account",
                                                entityId: accountId
                                            };
                                            Xrm.Navigation.openForm(entityFormOptions);
                                        }
                                        else {
                                            var accountData = {
                                                "name": formContext.getAttribute("niq_requestaccountname")?.getValue(),
                                                "niq_accounttype": 1,
                                                "niq_geography": formContext.getAttribute("niq_geography")?.getValue(),
                                            };
                                            Xrm.WebApi.createRecord("account", accountData).then(function (createResult) {
                                                var entityId = createResult.id;
                                                var entityFormOptions = {
                                                    entityName: "account",
                                                    entityId: entityId
                                                };
                                                formContext.getAttribute("niq_createdaccount").setValue([
                                                    {
                                                        id: entityId,
                                                        name: accountData.name,
                                                        entityType: "account"
                                                    }
                                                ]);
                                                Xrm.Navigation.openForm(entityFormOptions);
                                                formContext.getAttribute("niq_requeststatus").setValue(610570007);
                                                formContext.data.process.moveNext(function (result) {
                                                    if (result === "success") {
                                                        console.log("BPF advanced to the next stage because the account was closed.");
                                                    } else {
                                                        console.error("Could not advance BPF stage.");
                                                    }
                                                }
                                                );
                                            });
                                        }
                                    } else {
                                        arrFields = ["niq_ultimateparentaccount", "niq_customeraccount", "header_ownerid", "niq_invoicedispatchmethod", "niq_willsapaccountuseanytradebarter"]
                                        for (var i = 0; i < arrFields.length; i++) {
                                            if (CommonForm.Events.CheckFieldExists(formContext, arrFields[i])) {
                                                //TEMP formContext.getAttribute(arrFields[i]).setRequiredLevel("required");
                                            }
                                        }
                                        //TEMP formContext.getControl("SG_DuplicateAccounts").setVisible(false);
                                        formContext.ui.clearFormNotification("duplicate_duns");
                                        formContext.getAttribute("niq_requeststatus_db").setValue(610570000);
                                        //TEMP formContext.getControl("niq_ultimateparentaccount").setDisabled(true);
                                    }

                                }
                            } else {
                                console.log(this.responseText);
                            }
                        }
                    };
                    req1.send();
                }
            }
        }
    },

    checkForDuplicateAccount: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const eventArgs = executionContext.getEventArgs();
        const saveMode = eventArgs.getSaveMode();
        const formType = formContext.ui.getFormType();
        const requestType = formContext.getAttribute("niq_requesttype")?.getValue();

        const sapLegalName = formContext.getAttribute("niq_sapaccountname")?.getValue();
        const vatNumber = formContext.getAttribute("niq_vatabncompanyregistrationnumber")?.getValue();
        const city = formContext.getAttribute("niq_city")?.getValue();
        const postalCode = formContext.getAttribute("niq_zipcode")?.getValue();
        const street = formContext.getAttribute("niq_addressline1")?.getValue();
        const housenumber = formContext.getAttribute("niq_housenumber")?.getValue();
        const telephone = formContext.getAttribute("niq_telnumber")?.getValue();
        const address2_line1 = formContext.getAttribute("niq_address1street2")?.getValue();

        const clientUrl = Xrm.Utility.getGlobalContext().getClientUrl();
        let filter;

        if (vatNumber === "NA") {
            filter = `$filter=niq_sapaccountname eq '${sapLegalName}' and address1_line1 eq '${street}' and address1_line2 eq '${address2_line1}' and address1_city eq '${city}' and address1_postalcode eq '${postalCode}' and niq_housenumber eq '${housenumber}' and niq_telnumber eq '${telephone}'`;
        }
        else if (vatNumber != null) {
            filter = `$filter=niq_sapaccountname eq '${sapLegalName}' and niq_vatabncompanyregistrationnumber eq '${vatNumber}'`;
        }
        else {
            filter = `$filter=niq_sapaccountname eq '${sapLegalName}'`;
        }

        const url = `${clientUrl}/api/data/v9.2/accounts?$select=accountid&${filter}`;

        const req = new XMLHttpRequest();
        req.open("GET", url, false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Prefer", "odata.include-annotations=*");

        req.onreadystatechange = function () {
            if (req.readyState === 4) {
                req.onreadystatechange = null;
                if (req.status === 200) {
                    const results = JSON.parse(req.responseText);
                    if (results.value.length > 0 && formType !== 2 && requestType === 610570000 && [1, 2, 70].includes(saveMode)) {
                        eventArgs.preventDefault();
                        const alertStrings = {
                            confirmButtonLabel: "Ok",
                            text: "An account with these details already exists. Duplicate account creation is not allowed. If you wish to change the account details, please submit a 'Modification' request."
                        };
                        const alertOptions = { height: 240, width: 260 };
                        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);

                        formContext.ui.setFormNotification(
                            alertStrings.text,
                            "ERROR",
                            "duplicate_accounts"
                        );

                        SAPAccountRequestForm.Events.ShowDuplicateAccountsGrid(
                            formContext,
                            sapLegalName,
                            city,
                            street,
                            vatNumber,
                            postalCode,
                            housenumber,
                            telephone,
                            address2_line1
                        );
                    } else {
                        formContext.ui.clearFormNotification("duplicate_accounts");
                    }
                } else {
                    console.error("Error fetching accounts:", req.responseText);
                }
            }
        };

        req.send();
    },

    ManageRequestStatusFieldBehavior: function (formContext, requestStatusFieldArray) {
        const statecodeAttribute = formContext.getAttribute("statecode");
        SAPAccountRequestForm.RequestStatusFields.forEach((fieldLogicalName) => {
            const isFieldMapped = requestStatusFieldArray.includes(fieldLogicalName);
            if (statecodeAttribute && statecodeAttribute.getValue() == 1) {
                SAPAccountRequestForm.Events.ManageAccessiblity(formContext, fieldLogicalName, true);
            }
            else {
                SAPAccountRequestForm.Events.ManageAccessiblity(formContext, fieldLogicalName, !isFieldMapped);
            }
            SAPAccountRequestForm.Events.ManageRequiredLevel(formContext, fieldLogicalName, isFieldMapped ? "required" : "none");
            SAPAccountRequestForm.Events.ManageVisiblity(formContext, fieldLogicalName, isFieldMapped);
        });
    },

    ManageVisiblity: function (formContext, controlName, isVisible) {
        if (!controlName.includes("header_process_")) {
            let attr = formContext.getAttribute(controlName);
            if (attr) {
                const controls = attr.controls;
                if (controls) {
                    for (let i = 0; i < controls.getLength(); i++) {
                        const control = controls.get(i);
                        if (!control.getName().includes("header_process_")) {
                            //TEMP control.setVisible(isVisible);
                        }
                    }
                }
            }
        }
    },

    ManageRequiredLevel: function (formContext, attributeName, isRequired) {
        const attribute = formContext.getAttribute(attributeName);
        if (attribute) {
            //TEMP attribute.setRequiredLevel(isRequired);
        }
    },

    ManageAccessiblity: function (formContext, controlName, isDisabled) {
        if (controlName.includes("header_process_")) {
            const control = formContext.getControl(controlName);
            if (control) {
                //TEMP control.setDisabled(isDisabled);
            }
        }
        else {
            let attr = formContext.getAttribute(controlName);
            if (attr) {
                const controls = attr.controls;
                if (controls) {
                    for (let i = 0; i < controls.getLength(); i++) {
                        const control = controls.get(i);
                        //TEMP control.setDisabled(isDisabled);
                    }
                }
            }
        }
    },

    //DYNCRM-23922 - Validate Sharepoint Document
    ValidateRequiredDocumentURLsForAccountRequest: async function (executionContext) {
        var warningMessage = null;
        var formContext = executionContext.getFormContext();
        if (formContext.data.process.getActiveStage().getName().toLowerCase() === "new") return; //old value sap account request

        var accountRequestId = Xrm.Page.data.entity.getId();
        if (!accountRequestId) return;

        const AccountRequestEntity = await Xrm.WebApi.online.retrieveRecord("niq_accountrequest", accountRequestId, "?$select=niq_letterheadurl, niq_lsaurl, niq_msaurl, niq_paymenttermsurl, niq_revenuecontrollersapprovalurl, niq_vattaxationdetailsurl");
        const requestTypeAttribute = formContext.getAttribute("niq_requesttype");

        if (requestTypeAttribute) {
            const requestTypeValue = requestTypeAttribute.getValue();

            switch (requestTypeValue) {
                case 610570000:
                    //New SAP Account Request
                    if (AccountRequestEntity.niq_msaurl == null || AccountRequestEntity.niq_lsaurl == null || AccountRequestEntity.niq_letterheadurl == null) {
                        warningMessage = "No attachment was included on this New SAP Account Request. Please, make sure you have the right DnB match and/or add any of the support documentation (MSA, LSA, Letterhead, etc) to avoid rejection of the request."
                    }
                    break;
            }

            if (warningMessage) {
                formContext.ui.setFormNotification(warningMessage, "WARNING", "Error_AccountRequest_File_Missing");
            }
            else {
                formContext.ui.clearFormNotification("Error_AccountRequest_File_Missing");
            }
        }
    },

    showHideFields: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const country = formContext.getAttribute("niq_countryid")?.getValue()?.[0]?.name;

        if (formContext.getAttribute("niq_housenumber") && formContext.getAttribute("niq_salesgroupid")) {
            SAPAccountRequestForm.Events.ManageVisiblity(formContext, "niq_housenumber", country === "Brazil");
            SAPAccountRequestForm.Events.ManageVisiblity(formContext, "niq_salesgroupid", ["United States", "Canada"].includes(country));
        }
    },

    ShowCustomErrorMessage: async function (formContext) {
        formContext.ui.clearFormNotification("Error_DuplicateAccounts");
        var errorMsg = `This SAP account already exists. Creating a duplicate SAP account request is not permitted, but you can request a modification of the Account by changing the type of request to "Modification"`;
        formContext.ui.setFormNotification(errorMsg, "ERROR", "Error_DuplicateAccounts");
    },

    setValues: async function (executionContext) {
        const formContext = executionContext.getFormContext();
        const paymentterm = formContext.getAttribute("niq_paymentterms")?.getValue()?.[0]?.name;

        if (paymentterm) {
            const filterValue = paymentterm === "ND00" ? "GD01" : "GD02";
            try {
                await SAPAccountRequestForm.Events.UpdateDunningProcedure(formContext, filterValue);
            }
            catch (error) {
                console.log("Error setting values: " + error.message);
                Xrm.Navigation.openErrorDialog({ message: "An error occurred while setting the Dunning Procedure." });
            }
        }
    },

    UpdateDunningProcedure: async function (formContext, masterValue) {
        try {
            const results = await Xrm.WebApi.retrieveMultipleRecords("niq_sapaccountmastersupportdata", `?$filter=niq_mastervalue eq '${masterValue}'`);

            if (results.entities.length > 0) {
                const lookupValue = [{
                    id: results.entities[0]["niq_sapaccountmastersupportdataid"],
                    name: results.entities[0]["niq_name"],
                    entityType: "niq_sapaccountmastersupportdata"
                }];
                formContext.getAttribute("niq_dunningprocedure").setValue(lookupValue);
            }
            else {
                console.log("No records found for the specified master value.");
            }
        }
        catch (error) {
            console.log("Error retrieving records: " + error.message);
            Xrm.Navigation.openErrorDialog({ message: "An error occurred while updating the Dunning Procedure." });
        }
    },

    OnClick_Validate: async function (formContext) {
        try {

            if (await SAPAccountRequestForm.Events.IsDuplicateAccountFound(formContext)) {
                SAPAccountRequestForm.Events.ShowCustomErrorMessage(formContext);

                var accountSubgrid = formContext.getControl("SG_DuplicateAccounts");
                accountSubgrid.setFilterXml(await SAPAccountRequestForm.Events.GetFetchConditionForDuplicateAccount(formContext));
                accountSubgrid.refresh();
                //TEMP formContext.ui.tabs.get("New SAP Account Details").sections.get("DuplicateAccounts").setVisible(true);
            } else {
                //TEMP formContext.ui.tabs.get("New SAP Account Details").sections.get("DuplicateAccounts").setVisible(false);
                var accountSubgrid = formContext.getControl("SG_DuplicateAccounts");
                accountSubgrid.setFilterXml("<filter type='and'><condition attribute='accountid' operator='null' /></filter>");
                accountSubgrid.refresh();
            }
        }
        catch (error) {
            console.log("Error retrieving records: " + error.message);
            Xrm.Navigation.openErrorDialog({ message: "An error occurred from OnClick_Validate." });
        }
    },

    //DYNCRM-21777 - Basic Duplicate Check
    EnableRule_ValidateButton: async function (formContext) {
        let formType = formContext.ui.getFormType();
        let currentFormId = formContext.ui.formSelector.getCurrentItem().getId();

        //Show button in CreateFormType and New SAP Account Request
        if (formType == 1 && currentFormId == SAPAccountRequestForm.RequestTypeFormGUIDMapping[610570000]) {
            return true;
        } else {
            return false;
        }
    },

    EnableRule_ModifyRequestButton: async function (formContext) {
        let formName = formContext.ui.formSelector.getCurrentItem().getLabel();
        let entityName = formContext.data.entity.getEntityName();
        if (formName == "New SAP Account Request" && entityName == "niq_accountrequest") {
            return true;
        } else {
            return false;
        }
    },

    HideShowCustomerGroupFields: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        try {
            var CustomerBillingSection = formContext.ui.tabs?.get("Review").sections?.get("Review_section_8");
            var userId = Xrm.Utility.getGlobalContext().userSettings.userId;
            var teamid = "047aaf19-7bce-ef11-b8e8-7c1e524e097b";
            var isUserInTeam = false;

            var query = "?$filter=systemuserid eq " + userId + " and teamid eq " + teamid;
            var response = await Xrm.WebApi.retrieveMultipleRecords("teammembership", query);

            if (response.entities.length > 0) {
                isUserInTeam = true;
            }

            if (!CommonForm.Events.CheckIfLoggedInUserRole("NIQ Sales User") && isUserInTeam) {
                //TEMP CustomerBillingSection.setVisible(true);
            } else {
                //TEMP CustomerBillingSection.setVisible(false);
            }
        } catch (exception) {
            console.log("Error : " + exception);
        }
    },

    ShowDuplicateAccountsGrid: function (formContext, sapLegalName, city, street, vatNumber, postalCode, housenumber, telephone, address2_line1) {
        var accountSubgrid = formContext.getControl("SG_DuplicateAccounts");
        if (accountSubgrid) {
            if (vatNumber == "NA") {
                var fetchXml = `
                    <fetch>
        <!-- Table -->
        <entity name="account">
            <!-- Columns -->
            <attribute name="accountid"/>
            <attribute name="address1_city"/>
            <attribute name="niq_sapaccountname"/>
           <!-- Filter By -->
            <filter type="and">
                <condition attribute="niq_sapaccountname" operator="eq" value="${sapLegalName}"/>
                <condition attribute="address1_line1" operator="eq" value="${street}"/>
                <condition attribute="address1_city" operator="eq" value="${city}"/>
                <condition attribute="address1_line2" operator="eq" value="${address2_line1}"/>
                <condition attribute="address1_postalcode" operator="eq" value="${postalCode}"/>
                <condition attribute="niq_housenumber" operator="eq" value="${housenumber}"/>
                <condition attribute="niq_telnumber" operator="eq" value="${telephone}"/>
            </filter>
        </entity>
    </fetch>`;
            }
            else if (vatNumber != null) {
                var fetchXml = `
                    <fetch>
        <!-- Table -->
        <entity name="account">
            <!-- Columns -->
            <attribute name="accountid" />
            <attribute name="address1_city" />
            <attribute name="address1_line1" />
            <attribute name="niq_vatabncompanyregistrationnumber" />
            <attribute name="address1_postalcode" />
            <!-- Filter By -->
            <filter type="and">
                <condition attribute="niq_sapaccountname" operator="eq" value="${sapLegalName}" />
                <condition attribute="niq_vatabncompanyregistrationnumber" operator="eq" value="${vatNumber}" />
            </filter>
        </entity>
    </fetch>`;
            }
            else {
                var fetchXml = `
                    <fetch>
        <!-- Table -->
        <entity name="account">
            <!-- Columns -->
            <attribute name="accountid" />
            <attribute name="address1_city" />
            <attribute name="address1_line1" />
            <attribute name="niq_vatabncompanyregistrationnumber" />
            <attribute name="address1_postalcode" />
            <!-- Filter By -->
            <filter type="and">
                <condition attribute="niq_sapaccountname" operator="eq" value="${sapLegalName}" />
            </filter>
        </entity>
    </fetch>`;
            }
            accountSubgrid.setFilterXml(fetchXml);
            //TEMP accountSubgrid.setVisible(true);
            accountSubgrid.refresh();
        } else {
            console.warn("Subgrid 'SG_DuplicateAccounts' not found on the form.");
        }
    },

    moveNextStage: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var requesttype = formContext.getAttribute("niq_requesttype")?.getValue();
        var currentId = formContext.data.entity.getId();
        var results = await Xrm.WebApi.retrieveMultipleRecords("niq_accountrequestprocessflow", "?$select=_activestageid_value&$filter=_bpf_niq_accountrequestid_value eq " + currentId.replace("{", "").replace("}", "") + "");
        if (results.entities.length > 0) {
            var result = results.entities[0];
            var businessprocessflowinstanceid = result["businessprocessflowinstanceid"];
            var activestageid = result["_activestageid_value"]; // Lookup
            var activeStageName = result["_activestageid_value@OData.Community.Display.V1.FormattedValue"];
            if (activeStageName.toLowerCase() == "new") {
                var record = {};

                if (requesttype === 610570000) {
                    record["activestageid@odata.bind"] = "/processstages(0c0e696b-5842-4d10-925a-c5d8712a6890)"; // new sap account
                }
                await Xrm.WebApi.updateRecord("niq_accountrequestprocessflow", businessprocessflowinstanceid, record);
                var record2 = {};
                record2.niq_requeststatus_db = 610570000;
                record2.niq_requeststatus = 610570000;
                await Xrm.WebApi.updateRecord("niq_accountrequest", currentId, record2);
                formContext.data.refresh(true);
                //US-25150

                if (requesttype === 610570000) {
                    SAPAccountRequestForm.Events.triggerDnBOnAccountRequest(executionContext, currentId);
                }
            }

        }
        if (activeStageName.toLowerCase() != "new" && requesttype !== 610570000) {
            //TEMP formContext.getControl("niq_requestaccountname").setDisabled(true);
        }
    },

    callflow: async function (query) {
        return new Promise(async (resolve, reject) => {
            var data = JSON.stringify(query);
            var result = await Xrm.WebApi.retrieveRecord("niq_configurationsetting", "cc64ee3b-a36b-f011-b4cb-6045bda1a937", "?$select=niq_to");
            var flowUrl = result["niq_to"];
            var xhr = new XMLHttpRequest();
            xhr.addEventListener("readystatechange", function () {
                if (this.readyState === 4 && this.status == 200) {
                    resolve(this.responseText);
                }
                else if (this.readyState === 4) {
                    reject(new Error(`Request failed with status ${xhr.status}: ${xhr.statusText}`));
                    Xrm.Utility.closeProgressIndicator();
                }
            });

            xhr.open("POST", flowUrl);
            xhr.setRequestHeader("Content-Type", "application/json");
            xhr.send(data);
        });

    },

    generateTimeBasedGUID: function () {
        const timestamp = Date.now().toString(16);  // Get the current timestamp in hexadecimal format
        const template = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'; // GUID template

        return template.replace(/[xy]/g, function (c) {
            const random = (parseInt(timestamp.slice(-8), 16) + Math.random() * 16) % 16 | 0;
            const value = c === 'x' ? random : (random & 0x3) | 0x8;  // Adjust bits for GUID compliance
            return value.toString(16);
        });
    },

    populateHFMClientCode: async function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var ultimateParentAccount = "";
        var hfmclient = formContext.getAttribute("niq_hfmclientcodeid")?.getValue();
        var reqstatus = formContext.getAttribute("niq_requeststatus_mdmreview")?.getValue();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_customeraccount")) {
            var accountId = formContext.getAttribute("niq_customeraccount")?.getValue()[0].id.replace("{", "").replace("}", "");
        }
        if (reqstatus == 610570007)// MDM-Pending Review
        {
            if (hfmclient == null || hfmCode == "") {
                var res = await Xrm.WebApi.retrieveMultipleRecords("account", "?$select=_niq_ultimateparentid_value&$filter=(niq_accounttype eq 1 and accountid eq " + accountId + ")");
                if (res.entities.length > 0) {
                    var results = res.entities[0];
                    var ultimateParentAccount = results["_niq_ultimateparentid_value"];
                }
                if (ultimateParentAccount != null && ultimateParentAccount != undefined && ultimateParentAccount != "") {
                    try {
                        var ultimateAccountResult = await Xrm.WebApi.retrieveRecord("account", ultimateParentAccount, "?$select=niq_industry");
                        var industry = ultimateAccountResult["niq_industry"];
                        var result = await Xrm.WebApi.retrieveMultipleRecords("niq_hfmcode", "?$select=niq_hfmid&$filter=niq_isfinancialindustrymapping eq false and _niq_ultimateparentaccount_value eq " + ultimateParentAccount);
                        if (result.entities.length > 0) {
                            var Record = result.entities[0];
                            var hfmCode = Record["niq_hfmcodeid"];
                            var hfmCodeName = Record["niq_name"];
                            formContext.getAttribute("niq_hfmclientcodeid").setValue([
                                {
                                    id: hfmCode,
                                    name: hfmCodeName,
                                    entityType: "niq_hfmcode"
                                }
                            ]);
                            formContext.getAttribute("niq_industry").setValue(industry);
                        }
                        else {
                            SAPAccountRequestForm.Events.populateHFMClientCodeifUltimateParentAccountIsEmpty(executionContext);
                        }
                    }
                    catch (error) {
                        console.error("Error retrieving finance industry mappings: " + error.message);
                    }
                }
                else {
                    SAPAccountRequestForm.Events.populateHFMClientCodeifUltimateParentAccountIsEmpty(executionContext);
                }
            }
        }
    },

    // US-24109
    populateHFMClientCodeifUltimateParentAccountIsEmpty: async function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_customeraccount")) {
            var accountId = formContext.getAttribute("niq_customeraccount")?.getValue()[0].id.replace("{", "").replace("}", "");
        }
        var res = await Xrm.WebApi.retrieveMultipleRecords("account", "?$select=niq_industry&$filter=(niq_accounttype eq 1 and accountid eq " + accountId + ")");
        if (res.entities.length > 0) {
            var results = res.entities[0];
            var industry = results["niq_industry"];
        }
        try {
            var result = await Xrm.WebApi.retrieveMultipleRecords("niq_hfmcode", "?$select=niq_name,niq_financeindustryl1mapping,niq_financeindustryl2mapping&$filter=niq_industry eq " + industry + " and niq_isfinancialindustrymapping eq false");
            if (result.entities.length > 0) {
                var Record = result.entities[0];
                var hfmCode = Record["niq_hfmcodeid"];
                var hfmCodeName = Record["niq_name"];
                formContext.getAttribute("niq_hfmclientcodeid").setValue([
                    {
                        id: hfmCode,
                        name: hfmCodeName,
                        entityType: "niq_hfmcode"
                    }
                ]);
                formContext.getAttribute("niq_industry").setValue(industry);
            }
            else {
                formContext.getAttribute("niq_hfmclientcodeid").setValue(null);
            }
        }
        catch (error) {
            console.error("Error retrieving finance industry mappings: " + error.message);
        }
    },

    populateFieldsFromDnBMatch: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const dnbMatch = formContext.getAttribute("niq_dnbmatch")?.getValue();

        if (!dnbMatch || dnbMatch.length === 0) return;

        const dnbMatchId = dnbMatch[0].id;

        Xrm.WebApi.retrieveRecord("niq_dnbmatch", dnbMatchId).then(
            function (result) {
                const setIfEmpty = (fieldName, value) => {
                    const field = formContext.getAttribute(fieldName);
                    if (field && !field.getValue() && value) {
                        field.setValue(value);
                    }
                };

                formContext.getAttribute("niq_dunsnumber").setValue(null);
                formContext.getAttribute("niq_dunsnumber").setValue(result.niq_dunsnumber);

                setIfEmpty("niq_addressline1", result.address_line_1);
                setIfEmpty("niq_addressline2", result.address_line_2);
                setIfEmpty("niq_city", result.niq_primaryaddresscity);
                setIfEmpty("niq_zipcode", result.niq_primaryaddresspostalcode);
                setIfEmpty("niq_telnumber", result.niq_primaryphone);
                setIfEmpty("niq_website", result.niq_companyurl);

                const stateField = formContext.getAttribute("niq_state");
                if (stateField && !stateField.getValue() && result.niq_primaryaddressstateprovince) {
                    const code = result.niq_primaryaddressstateprovince.split(" - ")[0].trim();
                    const options = stateField.getOptions();
                    const match = options.find(opt => opt.text.startsWith(code));
                    if (match) {
                        stateField.setValue(match.value);
                    } else {
                        console.warn("No matching option found for code:", code);
                    }
                }
            },
            function (error) {
                console.error("Error retrieving DnB Match record:", error.message);
            }
        );
    },

    MDMAccountReview: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const activeStage = formContext.data.process.getActiveStage();
        const activeStageName = activeStage?.getName();
        const status = formContext.getAttribute("niq_requeststatus")?.getValue();
        const dnbMatch = formContext.getAttribute("niq_dnbmatch")?.getValue();
        const dnbName = dnbMatch?.[0]?.name || null;
        const APPROVED_BY_MDM = 610570008;

        if (activeStageName === "MDM Review" && status === APPROVED_BY_MDM && dnbName === "Match Not Found") {
            formContext.data.entity.addOnPostSave(() => {
                formContext.data.process.moveNext(movedToCompliance => {
                    if (!movedToCompliance) return;

                    const complianceField = formContext.getAttribute("niq_requeststatus_compliancereview");
                    const complianceOption = complianceField.getOptions().find(opt => opt.text === "Compliance OnHold");

                    if (complianceOption) {
                        complianceField.setValue(complianceOption.value);
                        formContext.data.process.moveNext(movedToClosed => {
                            if (!movedToClosed) return;

                            const closedField = formContext.getAttribute("niq_requeststatus_closed");
                            const closedOption = closedField.getOptions().find(opt => opt.text === "Closed");

                            if (closedOption) {
                                closedField.setValue(closedOption.value);
                            }
                        });
                    }
                });
            });
        }
    },

    RemoveOptionsforMDMStatus: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const currentStage = formContext.data.process.getActiveStage();
        const currentStageName = currentStage?.getName()?.toLowerCase();

        if (currentStageName === "mdm review") {
            const mdmStatusControl = formContext.getControl("header_process_niq_requeststatus_mdmreview");
            if (mdmStatusControl) {
                mdmStatusControl.removeOption(610570010);
                mdmStatusControl.removeOption(610570011);
            }
        }
    },

    MakeStatusInProgressForNewBPF: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const currentStageName = formContext.data.process.getActiveStage()?.getName()?.toLowerCase();

        if (currentStageName !== "new") return;

        const accountType = formContext.getAttribute("niq_accounttype")?.getValue();
        const statusValue = 610570000;

        if (accountType !== null && accountType !== 2) {
            formContext.getAttribute("header_process_niq_requeststatus_new")?.setValue(statusValue);
        } else {
            formContext.getAttribute("niq_requeststatus_new")?.setValue(statusValue);
        }
    },

    SellerRequiredFields: function (executionContext) {
        const formContext = executionContext.getFormContext();

        const applySettings = (requiredFields = [], readOnlyFields = [], hiddenFields = []) => {
            requiredFields.forEach(field => SAPAccountRequestForm.Events.ManageRequiredLevel(formContext, field, "required"));
            readOnlyFields.forEach(field => SAPAccountRequestForm.Events.ManageAccessiblity(formContext, field, true));
            hiddenFields.forEach(field => SAPAccountRequestForm.Events.ManageVisiblity(formContext, field, false));
        };

        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User")) {
            applySettings(
                [
                    "niq_city", "niq_country", "niq_customeraccount", "niq_dunsnumber", "niq_housenumber",
                    "niq_industrycode", "niq_invoicedispatchmethod", "niq_isthisagovernmentaccount", "niq_language",
                    "niq_sapaccountname", "niq_relatedopportunity", "ownerid", "niq_porequired", "niq_zipcode",
                    "niq_requeststatus", "niq_requesttype", "niq_requestorname", "niq_requestorscomment",
                    "niq_accountrequestnumber", "niq_addressline1", "niq_addressline2", "niq_willsapaccountuseanytradebarter",
                    "niq_ultimateparentaccount", "niq_vatabncompanyregistrationnumber", "niq_state"
                ],
                [
                    "niq_communicationmethod", "niq_dunsnumber", "niq_email",
                    "niq_hfmclientcodeid", "niq_industrycode", "niq_industrysector", "niq_compliancecomments",
                    "niq_mdmclosingcomments", "niq_legalsapaccountgroup", "niq_legalsapaccountgrouptype",
                    "niq_legalsapaccounttype", "niq_previousaccountnumber", "niq_requeststatus", "niq_requesttype",
                    "niq_accountrequestnumber", "niq_screeningresult", "niq_searchterm",
                    "niq_taxnumber1", "niq_taxnumber2", "niq_taxnumber3", "niq_taxnumber4", "niq_taxnumber5",
                    "niq_taxtype1", "niq_taxtype2", "niq_taxtype3", "niq_taxtype4", "niq_taxtype5"
                ],
                [
                    "niq_bankaccountno", "niq_bankcontrolkey", "niq_bankcountrykey", "niq_banktype",
                    "niq_collectionprofile", "niq_countrykey", "niq_recordpaymenthistory", "niq_nameco",
                    "niq_personnelnumber", "niq_street1", "niq_street2", "niq_street3",
                    "niq_taxjurcode", "niq_vattype"
                ]
            );
        }

        else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ MDM Reviewers")) {
            applySettings(
                [],
                [
                    "niq_compliancecomments", "niq_previousaccountnumber", "niq_requesttype",
                    "niq_requestorname", "niq_accountrequestnumber", "niq_screeningresult"
                ],
                [
                    "niq_collectionprofile", "niq_countrykey", "niq_recordpaymenthistory", "niq_nameco",
                    "niq_personnelnumber", "niq_street1", "niq_street2", "niq_street3", "niq_taxjurcode"
                ]
            );
        }

        else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Compliance Reviewers")) {
            applySettings(
                [],
                [
                    "niq_city", "niq_communicationmethod", "niq_country",
                    "niq_customeraccount", "niq_dunsnumber", "niq_email", "niq_hfmclientcodeid",
                    "niq_industrycode", "niq_industrysector", "niq_mdmclosingcomments", "niq_legalsapaccountgroup",
                    "niq_legalsapaccountgrouptype", "niq_porequired", "niq_zipcode", "niq_previousaccountnumber",
                    "niq_requeststatus", "niq_requesttype", "niq_requestorname", "niq_requestorscomment",
                    "niq_accountrequestnumber", "niq_screeningresult", "niq_addressline1", "niq_addressline2", "niq_willsapaccountuseanytradebarter",
                    "niq_telnumber", "niq_ultimateparentaccount", "niq_vatabncompanyregistrationnumber", "niq_vattype"
                ],
                [
                    "niq_bankaccountno", "niq_bankcontrolkey", "niq_bankcountrykey", "niq_banktype",
                    "niq_collectionprofile", "niq_countrykey", "niq_recordpaymenthistory", "niq_nameco",
                    "niq_personnelnumber", "niq_street1", "niq_street2", "niq_street3", "niq_taxjurcode"
                ]
            );
        }
    },

    // US-24896-24640-25150
    filterDNB: function (executionContext) {
        var dunsmatchuniqueguid;
        var formContext = executionContext.getFormContext();
        dunsmatchuniqueguid = dunsmatchuniqueguid == null ? formContext.getAttribute("niq_dnbmatchuniqueguidtemp")?.getValue() : dunsmatchuniqueguid;
        var fetchData = {
            "niq_confidencecode": "6",
            "niq_name": "Match Not Found",
            "niq_dunsmatchuniqueguid": dunsmatchuniqueguid
        };

        if (dunsmatchuniqueguid != null) {

            var fetchXml = [
                "<fetch top='15'>",
                "  <entity name='niq_dnbmatch'>",
                "    <filter type='or'>",
                "      <condition attribute='niq_name' operator='eq' value='", fetchData.niq_name/*Match Not Found*/, "'/>",
                "      <condition attribute='niq_dunsmatchuniqueguid' operator='eq' value='", fetchData.niq_dunsmatchuniqueguid/*17a93f26-d7d5-4594-9fbc-86bf7cb762c1*/, "'/>",
                "    </filter>",
                "    <filter type='and'>",
                "      <condition attribute='niq_confidencecode' operator='ge' value='", fetchData.niq_confidencecode/*6*/, "'/>",
                "    </filter>",
                "  </entity>",
                "</fetch>"
            ].join("");
        }
        else {
            var fetchXml = [

                "    <filter type='or'>",
                "      <condition attribute='niq_name' operator='eq' value='", fetchData.niq_name/*Match Not Found*/, "'/>",
                "    </filter>",

            ].join("");
        }

        formContext.getControl("niq_dnbmatch").addCustomFilter(fetchXml, "niq_dnbmatch");
    },

    //23122 preventing the bpf to move previous stage
    restrictUserToMovePreviousStage: function (executionContext) {
        const formContext = executionContext.getFormContext();
        let bpfArgs = executionContext.getEventArgs();
        let direction = bpfArgs.getDirection().toLowerCase();

        const currentStage = formContext.data.process.getActiveStage();
        const stageName = currentStage.getName().toLowerCase();

        if (direction == "previous") {
            bpfArgs.preventDefault();
            var alertStrings = {
                confirmButtonLabel: "OK",
                text: "Moving back to a previous stage is not allowed.",
                title: "Stage Navigation Blocked"
            };
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);

        }

        let requestType = formContext.getAttribute("niq_requesttype")?.getValue();
        var accountRequestId = formContext.data.entity.getId();
        accountRequestId = accountRequestId.replace("{", "").replace("}", "");

        if (!currentStage) {
            console.log("No active stage found in BPF.");
            return;
        }
    },

    //Funtion to call Side Pane
    OpenTheRecordSidePane: async function (executionContext) {
        const paneId = "SalesOrgExtensionSidePane";
        const formContext = executionContext.getFormContext();

        const entityName = formContext.data.entity.getEntityName();
        const recordId = formContext.data.entity.getId();
        if (recordId == null) {
            return;
        }
        const pane = Xrm.App.sidePanes.getPane(paneId) ?? await Xrm.App.sidePanes.createPane({
            paneId: paneId,
            canClose: true
        });
        pane.width = 600;  //you can decide what's the width of the side pane.
        //you could change the width for each record, in case you want to
        pane.navigate({
            pageType: "entityrecord",
            entityName: entityName,
            entityId: recordId,
            formId: "45e5fff6-8604-f011-bae3-6045bd91605b"
        });

    },

    EnableRule_NewSalesOrgExtension: function () {
        return true;
    },

    //US - 24965
    OpenSalesOrgExtensionRequestRecordSidePane: async function (executionContext) {
        const paneId = "InformationExtension";
        const formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRole("NIQ MDM Reviewers")) {
            const entityName = formContext.data.entity.getEntityName();
            const recordId = formContext.data.entity.getId();
            if (recordId == null) {
                return;
            }
            const pane = Xrm.App.sidePanes.getPane(paneId) ?? await Xrm.App.sidePanes.createPane({
                paneId: paneId,
                canClose: true
            });
            pane.width = 600;  //you can decide what's the width of the side pane.
            //you could change the width for each record, in case you want to
            pane.navigate({
                pageType: "entityrecord",
                entityName: entityName,
                entityId: recordId,
                formId: "71808eeb-3050-f011-877a-6045bdf317ec"
            });
        }
    },

    //OnClick of New button open multi-lookup form
    openSalesOrgExtensionRequestForm: function (formContext) {
        var lookupOptions = {};
        lookupOptions =
        {
            defaultEntityType: "niq_salesorg",
            entityTypes: ["niq_salesorg"],
            allowMultiSelect: true,
            defaultViewId: "57be3524-74fe-eb11-94ef-000d3a341bfb",
            viewIds: ["57be3524-74fe-eb11-94ef-000d3a341bfb"],
            searchText: "",
            filters: []
        };
        Xrm.Utility.lookupObjects(lookupOptions).then(
            async function (selectedSalesOrgs) {
                if (selectedSalesOrgs.length > 0) {
                    let createPromises = [];
                    for (let i = 0; i < selectedSalesOrgs.length; i++) {
                        createPromises.push(SAPAccountRequestForm.Events.CreateSalesOrgExtensionRecord(formContext, selectedSalesOrgs[i]));
                    }

                    const results = await Promise.allSettled(createPromises);

                    let errorMessages = results
                        .filter(r => r.status === "rejected")
                        .map(r => {
                            if (typeof r.reason === "string") {
                                return r.reason.replace(/^Plugin Exception:\s*/i, "");
                            }
                            return r.reason;
                        });

                    if (errorMessages.length > 0) {
                        // Add your additional message at the end
                        errorMessages.push("Above record(s) cannot be added to this extension Request.");
                        Xrm.Navigation.openAlertDialog({
                            title: "Validation Errors",
                            text: errorMessages.join('\n\n')
                        });
                    }
                }
            },
            function (error) {
                console.log(error);
            });
    },

    OpenCreateSalesOrgExtensionLookupObjects: async function (formContext) {
        const accountRequestId = formContext.data.entity.getId();

        //define data for lookupOptions
        var lookupOptions =
        {
            defaultEntityType: "niq_salesorg",
            entityTypes: ["niq_salesorg"],
            allowMultiSelect: true,
            defaultViewId: "57be3524-74fe-eb11-94ef-000d3a341bfb",
            viewIds: ["57be3524-74fe-eb11-94ef-000d3a341bfb"],
            searchText: "",
            filters: []
        };

        // Get account records based on the lookup Options
        Xrm.Utility.lookupObjects(lookupOptions).then(
            function (success) {
                console.log(success);
                if (success.length > 0) {
                    for (let i = 0; i < success.length; i++) {
                        SAPAccountRequestForm.Events.CreateSalesOrgExtensionRecord(formContext, success[i]);
                    }
                }

            },
            function (error) {
                console.log(error);
            });
    },

    CreateSalesOrgExtensionRecord: async function (formContext, salesOrgObj) {
        return new Promise(async (resolve, reject) => {
            const cleanId = (id) => id.replace("{", "").replace("}", "");

            const currentRecord = cleanId(formContext.data.entity.getId());
            const salesOrgId = cleanId(salesOrgObj.id);

            const getLookupId = (attribute) => {
                const value = attribute?.getValue();
                return value ? cleanId(value[0].id) : null;
            };

            const record = {
                "niq_accountrequest@odata.bind": `/niq_accountrequests(${currentRecord})`,
                "niq_SalesOrg@odata.bind": `/niq_salesorgs(${salesOrgId})`
            };

            const invoiceDispatchMethod = formContext.getAttribute("niq_invoicedispatchmethod")?.getValue();
            if (invoiceDispatchMethod) {
                record.niq_invoicedispatchmethod = invoiceDispatchMethod;
            }

            const customerGroup1Id = getLookupId(formContext.getAttribute("niq_customergroup1"));
            if (customerGroup1Id) {
                record["niq_CustomerGroup1@odata.bind"] = `/niq_sapaccountmastersupportdatas(${customerGroup1Id})`;
            }

            const customerGroup4Id = getLookupId(formContext.getAttribute("niq_customergroup4"));
            if (customerGroup4Id) {
                record["niq_CustomerGroup4@odata.bind"] = `/niq_sapaccountmastersupportdatas(${customerGroup4Id})`;
            }

            const accountPayableContactId = getLookupId(formContext.getAttribute("niq_accountspayableapcontact"));
            if (accountPayableContactId) {
                record["niq_AccountPayableAPContact@odata.bind"] = `/contacts(${accountPayableContactId})`;
            }

            const usesTradeAndBarter = formContext.getAttribute("niq_willsapaccountuseanytradeandbarter")?.getValue();
            const isGovAccount = formContext.getAttribute("niq_isthisagovernmentaccount")?.getValue();
            if ((isGovAccount && usesTradeAndBarter) || isGovAccount) {
                const data = await Xrm.WebApi.retrieveRecord("niq_sapaccountmastersupportdata", "8766b95a-b10b-f011-bae4-7c1e5285f8dc", "?$select=niq_sapaccountmastersupportdataid");
                if (data) {
                    record["niq_ARpledging@odata.bind"] = `/niq_sapaccountmastersupportdatas(${data.niq_sapaccountmastersupportdataid})`;
                }
            }
            else if (usesTradeAndBarter) {
                const data = await Xrm.WebApi.retrieveRecord("niq_sapaccountmastersupportdata", "b575b95a-b10b-f011-bae4-7c1e5285f8dc", "?$select=niq_sapaccountmastersupportdataid");
                if (data) {
                    record["niq_ARpledging@odata.bind"] = `/niq_sapaccountmastersupportdatas(${data.niq_sapaccountmastersupportdataid})`;
                }
            }

            return Xrm.WebApi.createRecord("niq_salesorgextensionrequest", record).then(
                (result) => {
                    console.log("Sales Org Extension request created: " + result.id);
                    formContext.getControl("relatedsalesorgextensionrequests").refresh();
                    return result;
                },
                (error) => {
                    throw new Error(error.message);
                }
            );
        });
    },

    OnLoadFieldVisibilityForMDMTeam: async function (executionContext) {
        const formContext = executionContext.getFormContext();
        const requestType = formContext.getAttribute("niq_requesttype")?.getValue();
        const mdmStatus = formContext.getAttribute("niq_requeststatus_mdmreview")?.getValue();

        if (mdmStatus === 610570008 || requestType !== 610570000) {
            return;
        }

        try {
            const userId = Xrm.Utility.getGlobalContext().userSettings.userId;
            const teamChecks = [
                { id: "047aaf19-7bce-ef11-b8e8-7c1e524e097b", label: "MDM" },
                { id: "ec841307-7bce-ef11-b8e8-7c1e524e097b", label: "Compliance" }
            ];

            let isTeamMember = false;

            for (const team of teamChecks) {
                const query = `?$filter=systemuserid eq ${userId} and teamid eq ${team.id}`;
                const response = await Xrm.WebApi.retrieveMultipleRecords("teammembership", query);
                if (response.entities.length > 0) {
                    isTeamMember = true;
                    break;
                }
            }

            if (!isTeamMember) return;

            const fieldsByRequestType = {
                //"niq_communicationmethod","niq_email"
                610570000: ["niq_bankaccountno", "niq_bankcontrolkey", "niq_bankcountrykey", "niq_banknumber", "niq_banktype", "niq_city", "niq_country", "niq_customeraccount", "niq_dunsnumber", "niq_dnbmatch",
                    "niq_hfmclientcodeid", "niq_housenumber", "niq_industrycode", "niq_industrysector", "niq_isthisagovernmentaccount", "niq_language", "niq_sapaccountname", "niq_relatedopportunity",
                    "header_ownerid", "niq_legalsapaccountgroup", "niq_legalsapaccountgrouptype", "niq_legalsapaccounttype", "niq_porequired", "niq_zipcode", "niq_previousaccountnumber", "niq_requeststatus", "niq_requesttype", "niq_requestorname",
                    "niq_requestorscomment", "niq_accountrequestnumber", "niq_screeningresult", "niq_searchterm", "niq_addressline1", "niq_addressline2", "niq_willsapaccountuseanytradebarter",
                    "niq_telnumber", "niq_ultimateparentaccount", "niq_vatregistrationnumber"]
            };

            const arrFields = fieldsByRequestType[requestType] || [];

            // Disable all controls
            formContext.ui.controls.forEach(control => {
                const name = control.getName();
                //TEMP if (name) control.setDisabled(true);
            });

            // Enable and require specific fields
            arrFields.forEach(field => {
                if (CommonForm.Events.CheckFieldExists(formContext, field)) {
                    const control = formContext.getControl(field);
                    //TEMP control.setDisabled(false);
                    //TEMP formContext.getAttribute(field).setRequiredLevel("required");
                }
            });

            arrFields = ["niq_taxtype1", "niq_taxtype2", "niq_taxtype3", "niq_taxtype4", "niq_taxtype5", "niq_taxnumber1", "niq_taxnumber2", "niq_taxnumber3", "niq_taxnumber4", "niq_taxnumber5", "niq_previousaccountnumber"];

            arrFields.forEach(field => {
                if (CommonForm.Events.CheckFieldExists(formContext, field)) {
                    const control = formContext.getControl(field);
                    //TEMP control.setDisabled(false);
                }
            });

        } catch (error) {
            console.error("Error in OnLoadFieldVisibilityForMDMTeam:", error);
        }
    },

    OnLoadFieldVisibilityForSellersOnApprovedRequest: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const requestType = formContext.getAttribute("niq_requesttype")?.getValue();
        const mdmStatus = formContext.getAttribute("niq_requeststatus_mdmreview")?.getValue();

        if (mdmStatus !== 610570008 || requestType !== 610570000) {
            return;
        }

        const arrFields = [
            "niq_accountingclerk", "niq_accountassigngroup", "niq_arpledging", "niq_customergroup1", "niq_customergroup2",
            "niq_customergroup3", "niq_customergroup4", "niq_customergroup5", "niq_customerorderblock", "niq_deliveringplant",
            "niq_distributionchannel", "niq_district", "niq_division", "niq_housebank", "niq_lockboxkey", "niq_periodicacctstatements",
            "niq_previousnumber", "niq_salesoffice", "niq_withholdingtaxagent", "niq_withholdingtaxcode", "niq_withholdingtaxtype",
            "niq_withholdtaxvalidfrom", "niq_withholdtaxvalidto"
        ];

        try {
            if (CommonForm.Events.CheckIfLoggedInUserRole("NIQ Sales User")) {
                formContext.ui.controls.forEach(control => {
                    const name = control.getName();
                    if (name) {
                        //TEMP control.setDisabled(true);
                    }
                });

                arrFields.forEach(field => {
                    if (CommonForm.Events.CheckFieldExists(formContext, field)) {
                        //TEMP formContext.getControl(field).setVisible(false);
                    }
                });
            }
        } catch (error) {
            console.error("Error in OnLoadFieldVisibilityForSellersOnApprovedRequest:", error);
        }
    },

    OnLoadFieldVisibilityForComplianceOnApprovedRequest: async function (executionContext) {
        const formContext = executionContext.getFormContext();
        const requestType = formContext.getAttribute("niq_requesttype")?.getValue();
        const mdmStatus = formContext.getAttribute("niq_requeststatus_mdmreview")?.getValue();

        if (mdmStatus !== 610570008 || requestType !== 610570000) {
            return;
        }

        const arrFields = [
            "niq_countrykey", "niq_iban", "niq_industrysector", "niq_relatedopportunity",
            "header_ownerid", "niq_recordpaymenthistory", "niq_taxjurcode"
        ];

        try {
            const userId = Xrm.Utility.getGlobalContext().userSettings.userId;
            const complianceTeamId = "ec841307-7bce-ef11-b8e8-7c1e524e097b";
            const query = `?$filter=systemuserid eq ${userId} and teamid eq ${complianceTeamId}`;
            const response = await Xrm.WebApi.retrieveMultipleRecords("teammembership", query);

            if (response.entities.length === 0) return;

            // Disable all controls
            formContext.ui.controls.forEach(control => {
                const name = control.getName();
                //TEMP if (name) control.setDisabled(true);
            });

            // Hide specific fields
            arrFields.forEach(field => {
                if (CommonForm.Events.CheckFieldExists(formContext, field)) {
                    //TEMP formContext.getControl(field).setVisible(false);
                }
            });

        } catch (error) {
            console.error("Error in OnLoadFieldVisibilityForComplianceOnApprovedRequest:", error);
        }
    },

    // DYNCRM-21779: Block BPF stage transition from Compliance Review to MDM Review if screening result is Decline or null
    BlockingBPFStageComplianceReview: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const bpfArgs = executionContext.getEventArgs();
        const direction = bpfArgs.getDirection()?.toLowerCase();

        if (direction !== "next") return;

        const currentStage = formContext.data.process.getActiveStage()?.getName()?.toLowerCase();
        const screeningResult = formContext.getAttribute("niq_screeningresult")?.getValue();

        const isComplianceReview = currentStage === "compliance review";
        const isNotSysAdmin = !CommonForm.Events.CheckIfLoggedInUserRole("System Administrator");
        const isScreeningInvalid = screeningResult === null || screeningResult === "undefined";

        if (isComplianceReview && isNotSysAdmin && isScreeningInvalid) {
            bpfArgs.preventDefault();

            const alertStrings = {
                confirmButtonLabel: "OK",
                text: "Moving to the next stage is not allowed.",
                title: "Stage Navigation Blocked"
            };
            const alertOptions = { height: 120, width: 260 };

            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        }
    },

    fblockStageNavigationOnDuplicate: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const eventArgs = executionContext.getEventArgs();
        const requestStatus = formContext.getAttribute("niq_requeststatus_db")?.getValue();
        const accountType = CommonForm.Events.CheckFieldExists(formContext, "niq_accounttype")
            ? formContext.getAttribute("niq_accounttype")?.getValue()
            : null;

        const direction = eventArgs?.getDirection?.()?.toLowerCase();
        if (direction !== "next" || requestStatus !== 610570011) return;

        const activeStageName = formContext.data.process.getActiveStage()?.getName()?.toLowerCase();
        const isMatchStage = activeStageName === "d&b match" || activeStageName === "dnb match";

        if (!isMatchStage) return;

        const accountRequestId = formContext.data.entity.getId().replace(/[{}]/g, "");

        if (accountType === 2) {
            eventArgs.preventDefault();

            // Trigger workflow
            const processInstanceId = Xrm.Page.data.process.getInstanceId().replace(/[{}]/g, "");
            const workflowId = "ab3df73c-5369-f011-bec2-0022488bdf4b";
            const clientUrl = Xrm.Utility.getGlobalContext().getClientUrl();

            const req = new XMLHttpRequest();
            req.open("POST", `${clientUrl}/api/data/v9.2/workflows(${workflowId})/Microsoft.Dynamics.CRM.ExecuteWorkflow`, true);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.onreadystatechange = function () {
                if (this.readyState === 4) req.onreadystatechange = null;
            };
            req.send(JSON.stringify({ EntityId: processInstanceId }));

            // Update record
            const updateData = {
                niq_requeststatus_closed: 610570017,
                niq_duplicatecheck: true
            };

            Xrm.WebApi.updateRecord("niq_accountrequest", accountRequestId, updateData).then(
                () => console.log("Account updated"),
                error => console.error(error.message)
            );
        } else {
            eventArgs.preventDefault();

            const alertStrings = {
                confirmButtonLabel: "OK",
                text: "Moving to Next stage is not allowed.",
                title: "Duplicate Account(s) found."
            };
            const alertOptions = { height: 120, width: 260 };

            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        }
    },

    ChangeOwner: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var owner = formContext.getAttribute("ownerid").getValue();
        var formType = formContext.ui.getFormType();
        if (CommonForm.Events.CheckFieldExists(formContext, "ownerid") && CommonForm.Events.CheckFieldExists(formContext, "niq_requestorname")) {
            if (owner !== null && formType == 2) {
                if (owner[0].entityType == "systemuser") {
                    var lookup = [];
                    lookup[0] = {};
                    lookup[0].id = owner[0].id;
                    lookup[0].entityType = owner[0].entityType.toLowerCase();
                    lookup[0].name = owner[0].name;
                    formContext.getAttribute("niq_requestorname").setValue(lookup);
                }
            } else {
                formContext.getAttribute("niq_requestorname").setValue(null);
            }
        }
    },

    lockFieldsMDMapproved: async function (executionContext) {
        const formContext = executionContext.getFormContext();
        const formType = formContext.ui.getFormType();
        const requestStatus = formContext.getAttribute("niq_requeststatus")?.getValue();
        const requestType = formContext.getAttribute("niq_requesttype")?.getValue();

        const disableAllControls = () => {
            formContext.ui.controls.forEach(control => {
                const name = control.getName();
                if (name) {
                    SAPAccountRequestForm.Events.ManageAccessiblity(formContext, name, true);
                }
            });
        };

        if (requestStatus === 610570008) {
            // Approved by MDM
            disableAllControls();

            if (await SAPAccountRequestForm.Events.IsLoggedInUserMDMReviewers()) {
                SAPAccountRequestForm.Events.ManageAccessiblity(formContext, "niq_requeststatus", false);
            }
        } else {
            const restrictedTypes = [610570003, 610570004, 610570005, 610570006, 610570007];

            if (formType !== 1 && restrictedTypes.includes(requestType)) {
                if (await SAPAccountRequestForm.Events.IsLoggedInUserMDMReviewers() && requestStatus !== 610570008) {
                    SAPAccountRequestForm.Events.ManageAccessiblity(formContext, "ownerid", false);
                    SAPAccountRequestForm.Events.ManageAccessiblity(formContext, "niq_requeststatus", false);
                    SAPAccountRequestForm.Events.ManageAccessiblity(formContext, "niq_requestorscomment", false);
                } else {
                    disableAllControls();
                }
            }
        }
    },

    IsLoggedInUserMDMReviewers: async function () {
        let fetchUser = `<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">
                                    <entity name="systemuser">
                                        <attribute name="fullname" />
                                        <attribute name="systemuserid" />
                                        <order attribute="fullname" descending="false" />
                                        <filter type="and">
                                        <condition attribute="systemuserid" operator="eq-userid" />
                                        </filter>
                                        <link-entity name="teammembership" from="systemuserid" to="systemuserid" visible="false" intersect="true">
                                        <link-entity name="team" from="teamid" to="teamid" alias="team">
                                            <filter type="and">
                                            <condition attribute="name" operator="eq" value="MDM Reviewers" />
                                            </filter>
                                        </link-entity>
                                        </link-entity>
                                    </entity>
                                    </fetch>`;

        const UserList = await Xrm.WebApi.retrieveMultipleRecords("systemuser", `?fetchXml=${fetchUser}`);
        if (UserList && UserList.entities && UserList.entities.length > 0) {
            return true;
        } else {
            return false;
        }
    },

    MappingCustomerGroupFieldsPoRequired: async function (executionContext) {
        const formContext = executionContext.getFormContext();
        const poRequired = formContext.getAttribute("niq_porequired")?.getValue();
        const customerGroupAttr = formContext.getAttribute("niq_customergroup1");

        if (!customerGroupAttr) {
            console.warn("Field 'niq_customergroup1' not found.");
            return;
        }

        if (poRequired === 1 || poRequired === true) {
            try {
                const mandatoryPo = "Mandatory PO";
                const response = await Xrm.WebApi.retrieveMultipleRecords(
                    "niq_sapaccountmastersupportdata",
                    `?$select=niq_name&$filter=niq_name eq '${mandatoryPo}'`
                );

                const result = response.entities?.[0];
                if (result) {
                    const lookupValue = [{
                        id: result.niq_sapaccountmastersupportdataid,
                        name: result.niq_name,
                        entityType: "niq_sapaccountmastersupportdata"
                    }];
                    customerGroupAttr.setValue(lookupValue);
                    //TEMP customerGroupAttr.setRequiredLevel("required");
                } else {
                    console.warn(`No record found for '${mandatoryPo}'`);
                }
            } catch (error) {
                console.error("Error retrieving Mandatory PO record:", error);
            }
        } else if (poRequired === 0 || poRequired === false) {
            customerGroupAttr.setValue(null);
            //TEMP customerGroupAttr.setRequiredLevel("none");
        }
    },

    assignToMDMTeamInMDMBPF: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const recordId = formContext.data.entity.getId()?.replace("{", "").replace("}", "");
        const entityLogicalName = formContext.data.entity.getEntityName();

        if (!recordId || !entityLogicalName) {
            console.warn("Record ID or entity name is missing.");
            return;
        }

        const teamId = "047aaf19-7bce-ef11-b8e8-7c1e524e097b"; // MDM Reviewers Team
        const ownerData = {
            "ownerid@odata.bind": `/teams(${teamId})`
        };

        Xrm.WebApi.updateRecord(entityLogicalName, recordId, ownerData)
            .then(() => {
                console.log("Owner changed to MDM Review Team successfully!");
                formContext.data.refresh(true);
            })
            .catch(err => {
                console.error("Error changing owner:", err.message);
            });
    },

    ConcateAccountRequestName: async function (executionContext) {
        const formContext = executionContext.getFormContext();
        const eventArgs = executionContext.getEventArgs();
        const formType = formContext.ui.getFormType();
        const saveMode = eventArgs.getSaveMode();
        const accountType = formContext.getAttribute("niq_accounttype")?.getValue();
        const accountNameNoCountry = formContext.getAttribute("niq_sapaccountname")?.getValue();
        const country = formContext.getAttribute("niq_country")?.getValue();
        let accountName = formContext.getAttribute("niq_requestaccountname")?.getValue();

        if (!accountName || !country || accountType !== 1) return;

        const countryId = country[0].id.replace("{", "").replace("}", "");
        const countryName = country[0].name;
        const suffix = ` (${countryName})`;

        if (accountName.endsWith(suffix)) return;

        const query = `?$select=accountid,name,_niq_countryid_value&$filter=(name eq '${accountName}' and _niq_countryid_value eq ${countryId} and niq_accounttype eq 1)`;
        const url = `${Xrm.Utility.getGlobalContext().getClientUrl()}/api/data/v9.2/accounts${query}`;

        try {
            const response = await fetch(url, {
                method: "GET",
                headers: {
                    "OData-MaxVersion": "4.0",
                    "OData-Version": "4.0",
                    "Content-Type": "application/json; charset=utf-8",
                    "Accept": "application/json",
                    "Prefer": "odata.include-annotations=*"
                }
            });

            if (!response.ok) {
                console.error("Fetch error:", await response.text());
                return;
            }

            const results = await response.json();
            if (results.value.length > 0) {
                if ([1, 2, 70].includes(saveMode)) {
                    eventArgs.preventDefault();
                    const alertStrings = {
                        confirmButtonLabel: "Ok",
                        text: "An account with these details already exists. Duplicate account creation is not allowed. If you wish to change the account details, please submit a 'Modification' request."
                    };
                    const alertOptions = { height: 240, width: 260 };
                    await Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                    SAPAccountRequestForm.Events.filterMatchingCustomerAccountsGrid(formContext, accountName, accountType, countryId);
                }
            } else {
                const updatedName = accountName + suffix;
                if (formType === 1 && accountNameNoCountry == null) {
                    formContext.getAttribute("niq_sapaccountname").setValue(accountName);
                    formContext.getAttribute("niq_requestaccountname").setValue(updatedName);
                    //TEMP formContext.getControl("niq_requestaccountname")?.setDisabled(true);
                    //TEMP formContext.getControl("Duplicate_Accounts")?.setVisible(false);
                } else if (formType === 2) {
                    const currentRecordId = formContext.data.entity.getId().replace("{", "").replace("}", "");
                    const updateData = { niq_requestaccountname: accountNameNoCountry + suffix };
                    await Xrm.WebApi.updateRecord("niq_accountrequest", currentRecordId, updateData);
                    //TEMP formContext.getControl("niq_requestaccountname")?.setDisabled(true);
                    //TEMP formContext.getControl("Duplicate_Accounts")?.setVisible(false);
                    formContext.data.refresh(true);
                }
            }
        } catch (error) {
            console.error("Error during account name check:", error);
        }
    },

    filterMatchingAccountsGrid: function (formContext, dunsNumber, accountType) {
        var accountSubgrid = ""
        if (accountType == 2) {
            accountSubgrid = formContext.getControl("SG_DuplicateAccounts");
        } else if (accountType == 1) {
            accountSubgrid = formContext.getControl("Duplicate_Accounts");
        }
        if (accountSubgrid) {
            var fetchXml = `
                <fetch>
                  <entity name="account">
                    <attribute name="name" />
                    <attribute name="niq_dunsnumber" />
                    <filter>
                      <condition attribute="niq_dunsnumber" operator="eq" value="${dunsNumber}" />
                    </filter>
                  </entity>
                </fetch>`;

            accountSubgrid.setFilterXml(fetchXml);
            //TEMP accountSubgrid.setVisible(true);
            accountSubgrid.refresh();
        } else {
            //TEMP accountSubgrid.setVisible(false);
            console.warn("Subgrid 'SG_DuplicateAccounts' not found on the form.");
        }
    },
    filterMatchingCustomerAccountsGrid: function (formContext, accountName, accountType, countryId) {
        var accountSubgrid = "";
        if (accountType == 1) {
            accountSubgrid = formContext.getControl("Duplicate_Accounts");
            var fetchXml = `
                <fetch>
                <entity name="account">
                    <attribute name="accountid" />
                    <attribute name="name" />
                    <attribute name="niq_accounttype" />
                    <attribute name="niq_countryid" />
                    <filter type="and">
                        <condition attribute="name" operator="eq" value="${accountName}" />
                        <condition attribute="niq_countryid" operator="eq" value="${countryId}" />
                    </filter>
                </entity>
            </fetch>`;

            accountSubgrid.setFilterXml(fetchXml);
            //TEMP accountSubgrid.setVisible(true);
            accountSubgrid.refresh();
        } else {
            //TEMP accountSubgrid.setVisible(false);
            console.warn("Subgrid 'SG_DuplicateAccounts' not found on the form.");
        }
    },

    //MDM Team User Filter on owner inSAP Account Request form
    filterOwnerUser: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        // Replace with your actual MDM Team GUID
        var results = await Xrm.WebApi.retrieveMultipleRecords("team", "?$select=teamid,name&$filter=name eq 'MDM Reviewers'");
        if (results.entities.length > 0) {
            var result = results.entities[0];
            var mdmTeamId = result["teamid"];
            // Filter to show only users who are members of the MDM team
            var fetchXmlFilter = `
                <filter type="and">
                <condition attribute="systemuserid" operator="in">
                <fetch mapping="logical">
                <entity name="teammembership">
                <attribute name="systemuserid" />
                <filter type="and">
                <condition attribute="teamid" operator="eq" value="`+ mdmTeamId + `" />
                </filter>
                </entity>
                </fetch>
                </condition>
                </filter>
                `;
            formContext.getControl("header_ownerid").addCustomFilter(fetchXmlFilter, "systemuser");
        }
    },

    filterOwnerUserOnMDM: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var lookupControl = formContext.getControl("header_ownerid");
        var viewGuid = "{4dde7184-336d-f011-b4cc-6045bd9d5cc0}";
        var activeStage = formContext.data.process.getActiveStage();
        var currentStage = activeStage.getName().toLowerCase();
        if (currentStage == "mdm review") {
            if (lookupControl) {
                lookupControl.setDefaultView(viewGuid);
            }
        }
    },

    //DYNCRM-21779 locking the form for compliance review stage and status compliance on hold as part of Dow Jones Request
    LockFormComplianceReview: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var requestType = formContext.getAttribute("niq_requesttype")?.getValue();
        var requestStatus = formContext.getAttribute("niq_requeststatus")?.getValue();
        var currentStage = formContext.data.process.getActiveStage();
        var currentStageName = currentStage.getName().toLowerCase();
        if (requestType == 610570000) {
            if (currentStageName == "compliance review" && requestStatus == 610570005) {
                if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User,NIQ Finance User,NIQ Add-On Finance Gatekeeper,NIQ Add On Sales Ops Approver")) {
                    let formControls = formContext.ui.controls;
                    formControls.forEach(control => {
                        if (control.getName() != "" && control.getName() != null) {
                            //TEMP control.setDisabled(true);
                        }
                    });
                }

            }
        }
    },

    lockRequestStatusMDMUntilMDMReview: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var activeStage = formContext.data.process.getActiveStage();
        var currentStage = activeStage.getName().toLowerCase();
        if (currentStage == "mdm review") {
            SAPAccountRequestForm.Events.ManageAccessiblity(formContext, "niq_requeststatus_mdmreview", false);
            SAPAccountRequestForm.Events.ManageRequiredLevel(formContext, "niq_requeststatus_mdmreview", "required");
        }
        else {
            SAPAccountRequestForm.Events.ManageAccessiblity(formContext, "niq_requeststatus_mdmreview", true);
            SAPAccountRequestForm.Events.ManageRequiredLevel(formContext, "niq_requeststatus_mdmreview", "none");
        }
    },

    MakeStatusInProgressForNewBPF: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var currentStage = formContext.data.process.getActiveStage();
        var currentStageName = currentStage.getName().toLowerCase();
        var processId = formContext.data.process.getActiveProcess().getId();
        if (currentStageName == "new") {
            //TEMP formContext.getControl("niq_dunsnumber").setVisible(false);
            //TEMP formContext.getControl("niq_dnbmatch").setVisible(false);
            if (formContext.getAttribute("niq_accounttype")?.getValue() != null && formContext.getAttribute("niq_accounttype")?.getValue() != 2) {
                formContext.getAttribute("header_process_niq_requeststatus_new").setValue(610570000);
            }
            else {
                formContext.getAttribute("niq_requeststatus_new").setValue(610570000);
            }
        }
        else {
            //TEMP formContext.getControl("niq_dunsnumber")?.setVisible(true);
            //TEMP formContext.getControl("niq_dnbmatch")?.setVisible(true);
        }
    },

    //24646 Mapping invoice dispatch method with customer group 4
    MappingCustomerGroupFieldsInvoiceDispatchMethod: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var InvoiceDispatchMethod = formContext.getAttribute("niq_invoicedispatchmethod")?.getValue();
        var CustomerGroup4 = formContext.getAttribute("niq_customergroup4");
        if (InvoiceDispatchMethod !== null && InvoiceDispatchMethod == 1) //Email
        {
            var Email = "Email";
            var record = await Xrm.WebApi.retrieveMultipleRecords("niq_sapaccountmastersupportdata", "?$select=niq_name&$filter=niq_name eq '" + Email + "'");
            var result = record.entities[0];
            var lookupValue = [{
                id: result.niq_sapaccountmastersupportdataid,
                name: result.niq_name,
                entityType: "niq_sapaccountmastersupportdata"

            }];
            if (CustomerGroup4) {
                CustomerGroup4.setValue(lookupValue);
                //TEMP CustomerGroup4.setRequiredLevel("required");
            }

        }
        else if (InvoiceDispatchMethod !== null && InvoiceDispatchMethod == 2) //PrintOut
        {
            var PrintOut = "Print";
            var record = await Xrm.WebApi.retrieveMultipleRecords("niq_sapaccountmastersupportdata", "?$select=niq_name&$filter=niq_name eq '" + PrintOut + "'");
            var result = record.entities[0];
            var lookupValue = [{
                id: result.niq_sapaccountmastersupportdataid,
                name: result.niq_name,
                entityType: "niq_sapaccountmastersupportdata"

            }];
            if (CustomerGroup4) {
                CustomerGroup4.setValue(lookupValue);
                //TEMP CustomerGroup4.setRequiredLevel("required");
            }
        }
        else if (InvoiceDispatchMethod !== null && InvoiceDispatchMethod == 3) //Upload to Portal
        {
            var UploadToPortal = "Portal_EIPP";
            var record = await Xrm.WebApi.retrieveMultipleRecords("niq_sapaccountmastersupportdata", "?$select=niq_name&$filter=niq_name eq '" + UploadToPortal + "'");
            var result = record.entities[0];
            var lookupValue = [{
                id: result.niq_sapaccountmastersupportdataid,
                name: result.niq_name,
                entityType: "niq_sapaccountmastersupportdata"

            }];
            if (CustomerGroup4) {
                CustomerGroup4.setValue(lookupValue);
                //TEMP CustomerGroup4.setRequiredLevel("required");
            }
        }
        else if (InvoiceDispatchMethod !== null && InvoiceDispatchMethod == 4) //EDCOM
        {
            var EDCOM = "EDICOM";
            var record = await Xrm.WebApi.retrieveMultipleRecords("niq_sapaccountmastersupportdata", "?$select=niq_name&$filter=niq_name eq '" + EDCOM + "'");
            var result = record.entities[0];
            var lookupValue = [{
                id: result.niq_sapaccountmastersupportdataid,
                name: result.niq_name,
                entityType: "niq_sapaccountmastersupportdata"

            }];
            if (CustomerGroup4) {
                CustomerGroup4.setValue(lookupValue);
                //TEMP CustomerGroup4.setRequiredLevel("required");
            }
        }
        else {
            if (CustomerGroup4) {
                CustomerGroup4.setValue(null);
                //TEMP CustomerGroup4.setRequiredLevel("none");
            }
        }

    },

    OnChangeRequestStatusMDMReview: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_requeststatus_mdmreview")) {
            var requestStatusMDMReview = formContext.getAttribute("niq_requeststatus_mdmreview")?.getValue();
            if (requestStatusMDMReview !== null)
                formContext.getAttribute("niq_requeststatus").setValue(requestStatusMDMReview);
        }
    },

    //DYNCRM-24405 Child 2 : Create SAP account request - account modification
    OnLoad_LockApplyForAllIfChecked: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_applyforallforuionly")) {
            var isApplyForAllChecked = formContext.getAttribute("niq_applyforallforuionly")?.getValue();
            //Disable if the record is being created or the record is being updated and the check box was checked previously
            //TEMP if (isApplyForAllChecked || (formType == 1)) formContext.getControl("niq_applyforallforuionly").setDisabled(true);
        }
    },

    OnLoadFieldVisibilityForMDMOnApprovedRequest: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var requestType = formContext.getAttribute("niq_requesttype")?.getValue();
        var arrFields = []
        var mdmstatus = formContext.getAttribute("niq_requeststatus_mdmreview")?.getValue();
        if (mdmstatus == 610570008) {
            if (requestType == 610570000) {
                arrFields = ["niq_countrykey", "niq_iban", "niq_industrysector", "niq_relatedopportunity",
                    "header_ownerid", "niq_recordpaymenthistory", "niq_taxjurcode"];
                try {

                    var userId = Xrm.Utility.getGlobalContext().userSettings.userId;
                    var teamid = "047aaf19-7bce-ef11-b8e8-7c1e524e097b";//MDM Team ID
                    var isMDMTeamMember = false;
                    var query = "?$filter=systemuserid eq " + userId + " and teamid eq " + teamid;
                    var response = await Xrm.WebApi.retrieveMultipleRecords("teammembership", query);
                    if (response.entities.length > 0) {
                        isMDMTeamMember = true;
                    }
                    if (isMDMTeamMember) {
                        let formControls = formContext.ui.controls;
                        formControls.forEach(control => {
                            if (control.getName() != "" && control.getName() != null) {
                                //TEMP control.setDisabled(true);
                            }
                        });
                        for (var i = 0; i < arrFields.length; i++) {
                            if (CommonForm.Events.CheckFieldExists(formContext, arrFields[i])) {
                                //TEMP formContext.getControl(arrFields[i]).setVisible(false);
                            }
                        }
                    }

                }
                catch (exception) {
                    console.log("Error : " + exception);
                }
            }
        }
    },

    onSaveCreateCustomerAccountRequest: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        SAPAccountRequestForm.Events.ConcateAccountRequestName(executionContext);
        SAPAccountRequestForm.Events.OnSaveDeleteOtherDnbMatch(executionContext);
        SAPAccountRequestForm.Events.MDMAccountReview(executionContext);
    },

    populateFinanceIndustryMapping: async function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var ultimateParentAccount = "";
        var reqstatus = formContext.getAttribute("niq_requeststatus_mdmreview")?.getValue();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_customeraccount")) {
            var accountId = formContext.getAttribute("niq_customeraccount")?.getValue()[0].id.replace("{", "").replace("}", "");
        }
        if (accountId != null && accountId != undefined && accountId != "") {
            var res = await Xrm.WebApi.retrieveMultipleRecords("account", "?$select=_niq_ultimateparentid_value&$filter=(niq_accounttype eq 1 and accountid eq " + accountId + ")");
            if (res.entities.length > 0) {
                var results = res.entities[0];
                var ultimateParentAccount = results["_niq_ultimateparentid_value"];
            }

            if (ultimateParentAccount != null && ultimateParentAccount != undefined && ultimateParentAccount != "") {
                try {
                    var ultimateAccountResult = await Xrm.WebApi.retrieveRecord("account", ultimateParentAccount, "?$select=niq_industry");
                    var industry = ultimateAccountResult["niq_industry"];
                    var result = await Xrm.WebApi.retrieveMultipleRecords("niq_hfmcode", "?$select=niq_industry,niq_financeindustryl1mapping,niq_financeindustryl2mapping&$filter=niq_industry eq " + industry + " and niq_isfinancialindustrymapping eq true and _niq_ultimateparentaccount_value eq " + ultimateParentAccount);
                    if (result.entities.length > 0) {
                        var Record = result.entities[0];
                        var hfmCodeL1Mapping = Record.niq_financeindustryl1mapping;
                        var hfmCodeL2Mapping = Record.niq_financeindustryl2mapping;
                        var industry = Record.niq_industry;
                        if ((hfmCodeL1Mapping != null && hfmCodeL1Mapping != undefined && hfmCodeL1Mapping != "") || (hfmCodeL2Mapping != null && hfmCodeL2Mapping != undefined && hfmCodeL2Mapping != "")) {
                            formContext.getAttribute("niq_financereportingindustryl1").setValue(hfmCodeL1Mapping);
                            formContext.getAttribute("niq_financereportingindustryl2").setValue(hfmCodeL2Mapping);
                        }
                        else {
                            SAPAccountRequestForm.Events.populateFinanceIndustryMappingifUltimateParentAccountIsEmpty(executionContext);
                        }
                    }
                    else {
                        SAPAccountRequestForm.Events.populateFinanceIndustryMappingifUltimateParentAccountIsEmpty(executionContext);
                    }
                }
                catch (error) {
                    console.error("Error retrieving finance industry mappings: " + error.message);
                }
            }
            else {
                SAPAccountRequestForm.Events.populateFinanceIndustryMappingifUltimateParentAccountIsEmpty(executionContext);
            }
        }
    },

    populateFinanceIndustryMappingifUltimateParentAccountIsEmpty: async function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_customeraccount")) {
            var accountId = formContext.getAttribute("niq_customeraccount")?.getValue()[0].id.replace("{", "").replace("}", "");
        }
        var res = await Xrm.WebApi.retrieveMultipleRecords("account", "?$select=niq_industry&$filter=(niq_accounttype eq 1 and accountid eq " + accountId + ")");
        if (res.entities.length > 0) {
            var results = res.entities[0];
            var industry = results["niq_industry"];
        }
        try {
            var result = await Xrm.WebApi.retrieveMultipleRecords("niq_hfmcode", "?$select=niq_industry,niq_financeindustryl1mapping,niq_financeindustryl2mapping&$filter=niq_industry eq " + industry + " and niq_isfinancialindustrymapping eq true");
            if (result.entities.length > 0) {
                var Record = result.entities[0];
                var hfmCodeL1Mapping = Record.niq_financeindustryl1mapping;
                formContext.getAttribute("niq_financereportingindustryl1").setValue(hfmCodeL1Mapping);
                var hfmCodeL2Mapping = Record.niq_financeindustryl2mapping;
                formContext.getAttribute("niq_financereportingindustryl2").setValue(hfmCodeL2Mapping);
                var industry = Record.niq_industry;
            }
            else {
                formContext.getAttribute("niq_financereportingindustryl1").setValue(null);
                formContext.getAttribute("niq_financereportingindustryl2").setValue(null);
            }
        }
        catch (error) {
            console.error("Error retrieving finance industry mappings: " + error.message);
        }
    },
    MDMReviewStage: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const activeStage = formContext.data.process.getActiveStage();
        const activeStageName = activeStage ? activeStage.getName() : null;
        const status = formContext.getAttribute("niq_requeststatus")?.getValue();
        const dnbMatch = formContext.getAttribute("niq_dnbmatch")?.getValue();
        const dnbName = (dnbMatch && dnbMatch.length > 0) ? dnbMatch[0].name : null;
        var accountRequestId = formContext.data.entity.getId().replace("{", "").replace("}", "");
        var requestType = formContext.getAttribute("niq_requesttype").getValue();

        if (activeStageName === "MDM Review")//When current stage is MDM review
        {
            if (requestType == 610570000) //Logic for New SAP Account Request
            {
                var data =
                {
                    "niq_requeststatus_mdmreview": 610570007,
                    "niq_requeststatus": 610570007
                }

                // update the record
                Xrm.WebApi.updateRecord("niq_accountrequest", accountRequestId, data).then(
                    function success(result) {
                        console.log("Request updated");
                        formContext.data.refresh();
                    },
                    function (error) {
                        console.log(error.message);
                    }
                );
            }
        }
    },
    //US - 24965
    prePopulateFieldsOnAccountRequestExt: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var Opportunity = formContext.getAttribute("niq_relatedopportunity")?.getValue();
        var requestType = formContext.getAttribute("niq_requesttype")?.getValue();

        if (requestType == 610570000) {
            if (Opportunity == null) {
                formContext.getAttribute("niq_requeststatus").setValue(610570000);
            }
        }
    },

    HideShowNewButton: function (formContext) {
        var requestType = formContext.getAttribute("niq_requesttype")?.getValue();
        if (requestType != null && (requestType == 610570000 || requestType == 610570002)) {
            return true;
        } else {
            return false;
        }
    },

    // US-25039
    makeMDMCommentsRequired: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var rejectionReason = formContext.getAttribute("niq_rejectedreason")?.getValue();
        if (rejectionReason == 610570002) {
            //TEMP formContext.getAttribute("niq_mdmclosingcomments").setRequiredLevel("required");
        } else {
            //TEMP formContext.getAttribute("niq_mdmclosingcomments").setRequiredLevel("none");
        }
    },

    //Set Email field based on Account Accounts payable(AP) Contact
    SetEmailField: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        //niq_email
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_email") && CommonForm.Events.CheckFieldExists(formContext, "niq_accountspayableapcontact")) {
            var accountPayableContact = formContext.getAttribute("niq_accountspayableapcontact").getValue();
            if (accountPayableContact != null) {
                var result = await Xrm.WebApi.retrieveRecord("contact", accountPayableContact[0].id.replace("{", "").replace("}", ""), "?$select=emailaddress1");
                var email = result["emailaddress1"];
                email != null ? formContext.getAttribute("niq_email").setValue(email) : formContext.getAttribute("niq_email").setValue(null);
            } else {
                formContext.getAttribute("niq_email").setValue(null);
            }
        }
    },
}