const AssetStatus = {
    Active: 1001,
    Inactive: 1002,
    Future: 1003
};

const AssetType = {
    Individual: 1,
    Host: 2,
    Child: 3
}


// Helper function to retrieve asset names for valid statuses
async function getAssetNamesForStatus(SelectedControlSelectedItemIds, validStatuses) {
    const assetNames = [];
    for (const item of SelectedControlSelectedItemIds) {
        // Retrieve the asset status and asset name for each item
        const asset = await Xrm.WebApi.retrieveRecord("niq_assetconfig", item, "?$select=niq_assettype,niq_assetstatus,_niq_originatingopportunity_value,&$expand=niq_asset($select=niq_assetname)");

        // Check if the asset status matches any of the valid statuses
        if (validStatuses.length === 5 && validStatuses.includes(asset.niq_assettype) && validStatuses.includes(asset.niq_assetstatus)) // Asset Type == RevShare
        {
            assetNames.push(asset["niq_asset"]["niq_assetname"]);
        } else if (validStatuses.length === 2 && validStatuses.includes(asset.niq_assetstatus)) {
            assetNames.push(asset["niq_asset"]["niq_assetname"]);
        } else if (validStatuses.includes(asset.niq_assetstatus)) {
            if (asset.niq_assettype == 4) {
                while (assetNames.length > 0) {
                    assetNames.pop();
                }
                return assetNames;
            } else {
                assetNames.push(asset["niq_asset"]["niq_assetname"]);
            }
        }
    }
    return assetNames;
}


// Helper function to show error dialogs
async function showErrorDialog(action, assetNames) {
    if (assetNames.length > 0) {
        str = "";
        if (assetNames.length == 1)
            str = "is";
        else
            str = "are";
        const errorOptions = {
            errorCode: 1234,
            details: `These assets ${assetNames.join(", ")} you have selected ` + str + ` not eligible for ${action}`,
            message: `These assets ${assetNames.join(", ")} you have selected ` + str + ` not eligible for ${action}`
        };
        await Xrm.Navigation.openErrorDialog(errorOptions);
    }
}

// Generalized Show/Hide Button Logic for Asset Config Subgrid
async function ShowHideAssetConfigSubgridButton(SelectedControlSelectedItemIds, validStatuses) {
    Xrm.Utility.showProgressIndicator();
    try {
        const assetNames = await getAssetNamesForStatus(SelectedControlSelectedItemIds, validStatuses);
        return assetNames.length > 0;
    } finally {
        Xrm.Utility.closeProgressIndicator();
    }
}

// OnClick Handlers (Amend, Apply COLA, Apply PE, Renew)
async function OnClick_Action(SelectedControlSelectedItemIds, actionName, validStatuses) {
    Xrm.Utility.showProgressIndicator();
    try {
        const assetNames = await getAssetNamesForStatus(SelectedControlSelectedItemIds, validStatuses);
        if (assetNames.length > 0) {
            await showErrorDialog(actionName, assetNames);
            return false;
        }
        return true;
    } finally {
        Xrm.Utility.closeProgressIndicator();
    }
}

//DYNCRM-22990 Helper function to check if all assets belong to the same opportunity
async function checkIfSameOpportunity(SelectedControlSelectedItemIds) {
    let opportunityId = null;

    for (const item of SelectedControlSelectedItemIds) {
        const asset = await Xrm.WebApi.retrieveRecord("niq_assetconfig", item, "?$select=_niq_originatingopportunity_value");

        if (opportunityId === null) {
            opportunityId = asset["_niq_originatingopportunity_value"];
        } else if (opportunityId !== asset["_niq_originatingopportunity_value"]) {
            return false; // If opportunities are different, return false
        }
    }

    return true; // If all opportunities match
}


async function checkIfEvergreen(SelectedControlSelectedItemIds) {

    for (const item of SelectedControlSelectedItemIds) {
        const asset = await Xrm.WebApi.retrieveRecord("niq_assetconfig", item, "?$select=niq_termtype");

        if (asset.niq_termtype === 100000000) {
            return true;
        }
        else
            return false;
    }

}


async function checkIfRevshare(SelectedControlSelectedItemIds) {
    for (const item of SelectedControlSelectedItemIds) {
        const asset = await Xrm.WebApi.retrieveRecord("niq_assetconfig", item, "?$select=niq_assettype");

        if (asset["niq_assettype"] == 4) {
            return false
        }
    }
    return true; // If all opportunities match
}


//DYNCRM-22990 Individual Action Handlers
// async function OnClick_Amend(SelectedControlSelectedItemIds) {
//     await OnClick_Action(SelectedControlSelectedItemIds, "Amend", [1002]);
// }

async function OnClick_Amend(SelectedControlSelectedItemIds) {
    var isValid = true;
    var hostChildResult = await checkIfHostChildAssetSelected(SelectedControlSelectedItemIds);
    if (hostChildResult.ishostchild) {
        if (!hostChildResult.isSameHostInAsset) {
            const errorOptions = {
                errorCode: 1235,
                details: "The selected child assets are associated with a different host. Please select child assets that links to the same host.",
                message: "The selected child assets are associated with a different host. Please select child assets that links to the same host."
            };
            Xrm.Utility.closeProgressIndicator();
            await Xrm.Navigation.openErrorDialog(errorOptions);
            return;
        }
        if (hostChildResult.isOnlyRevShare) {
            hostChildResult.revShareId;
            var asset = await Xrm.WebApi.retrieveRecord("niq_assetconfig", hostChildResult.revShareId, "?$select=_niq_originatingopportunity_value")
            var results = await Xrm.WebApi.retrieveMultipleRecords("opportunity", "?$filter=(_niq_amendedfromopportunity_value eq " + asset._niq_originatingopportunity_value + " and statecode eq 0)");
            if (results.entities.length > 0) {
                var HostOppNumber = results.entities[0].niq_opportunitynumber;
                var message = "Other amendment/ renewal opportunity <" + HostOppNumber + "> is currently open for this asset and must be closed before a new renew/ amendment can be initiated. Please review and close existing opportunity before proceeding";
                await Xrm.Navigation.openAlertDialog({ title: "Warning!", text: message });
                return;
            }
            var confirmStrings = { text: "You have selected a revenue share asset to amend. Would you like to add assets to the host, or are you planning to add new child(ren) to the host opportunity.", title: "Confirmation Dialog", confirmButtonLabel: "Yes", cancelButtonLabel: "No" };
            var confirmOptions = { height: 200, width: 450 };
            await Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
                async function (success) {
                    if (success.confirmed)
                        console.log("Dialog closed using OK button.");
                    else
                        isValid = false;
                });
        }
        if (hostChildResult.isOnlyHost) {
            var confirmStrings = { text: "You have only selected the host assets for the amendment. Are you sure there are no amendments for the child assets?", title: "Confirmation Dialog", confirmButtonLabel: "Yes", cancelButtonLabel: "No" };
            var confirmOptions = { height: 200, width: 450 };
            await Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
                async function (success) {
                    if (success.confirmed)
                        console.log("Dialog closed using OK button.");
                    else
                        isValid = false;
                });
        }
    }
    else if (hostChildResult.isIndividualHostChildAssetPresent) {
        const errorOptions = {
            errorCode: 1235,
            details: "Host/Child asset actions cannot be combined with Non-Host/Child assets. Please perform asset actions separately.",
            message: "Host/Child asset actions cannot be combined with Non-Host/Child assets. Please perform asset actions separately."
        };
        Xrm.Utility.closeProgressIndicator();
        await Xrm.Navigation.openErrorDialog(errorOptions);
        return;
    }
    if (!hostChildResult.ishostchild) {
        //DYNCRM-22990 Check if all assets belong to the same opportunity
        const sameOpportunity = await checkIfSameOpportunity(SelectedControlSelectedItemIds);

        if (!sameOpportunity) {
            // Show error if different opportunities are selected
            const errorOptions = {
                errorCode: 1235,
                details: "Please select assets that belong to the same opportunity for amendments.",
                message: "Please select assets that belong to the same opportunity for amendments."
            };
            Xrm.Utility.closeProgressIndicator();
            await Xrm.Navigation.openErrorDialog(errorOptions);
            return; // Exit early
        }
    }
    if (SelectedControlSelectedItemIds != null && SelectedControlSelectedItemIds != "") {
        var strIds = SelectedControlSelectedItemIds.toString();
        var arrIds = strIds.split(",");
        for (var i = 0; i < arrIds.length; i++) {
            var assetconfigid = arrIds[i];

            var oppo = await Xrm.WebApi.retrieveMultipleRecords("opportunity", `?$filter=(contains(niq_assetconfigidinput,'` + assetconfigid + `') and niq_opportunitytype eq 2 and statecode eq 0)`);
            if (oppo.entities.length > 0) {

                // var oppnums = oppo.entities.toString();
                // var opparrs= oppnums.split(",");
                // await Xrm.Navigation.openErrorDialog({ errorCode: "ABC7123", details: "Other amendment/ renewal opportunity <" + opparrs + "> is currently open for this asset and must be closed before a new renew/ amendment can be initiated. Please review and close existing opportunity before proceeding", message: "Other amendment/ renewal opportunity <" + opparrs + "> is currently open for this asset and must be closed before a new renew/ amendment can be initiated. Please review and close existing opportunity before proceeding" });

                if (oppo.entities.length > 1) {
                    var opportunityNumbers = [];
                    for (var i = 0; i < oppo.entities.length; i++) {
                        opportunityNumbers.push(oppo.entities[i]["niq_opportunitynumber"]);
                    }
                    var numbersString = opportunityNumbers.join(", ");
                    var message = "Other amendment/ renewal opportunity <" + numbersString + "> are currently open for this asset and must be closed before a new renew/ amendment can be initiated. Please review and close existing opportunity before proceeding";

                    await Xrm.Navigation.openAlertDialog({ title: "Warning!", text: message });
                }
                else {
                    var opportunityNumbers = [];
                    for (var i = 0; i < oppo.entities.length; i++) {
                        opportunityNumbers.push(oppo.entities[i]["niq_opportunitynumber"]);
                    }
                    var numbersString = opportunityNumbers
                    var message = "Other amendment/ renewal opportunity <" + numbersString + "> is currently open for this asset and must be closed before a new renew/ amendment can be initiated. Please review and close existing opportunity before proceeding";

                    await Xrm.Navigation.openAlertDialog({ title: "Warning!", text: message });
                }

                //await Xrm.Navigation.openErrorDialog({ details: "Other amendment/ renewal opportunity <" + numbersString + "> is currently open for this asset and must be closed before a new renew/ amendment can be initiated. Please review and close existing opportunity before proceeding", message: "Other amendment/ renewal opportunity <" + numbersString + "> is currently open for this asset and must be closed before a new renew/ amendment can be initiated. Please review and close existing opportunity before proceeding" });

                saveEvent.preventDefault();
            }
        }
    }
    if (isValid) {
        Xrm.Utility.showProgressIndicator();
        try {
            // Proceed with the existing logic (checking status and showing error dialog if necessary)
            const assetNames = await getAssetNamesForStatus(SelectedControlSelectedItemIds, [1002]);
            if (assetNames.length > 0) {
                Xrm.Utility.closeProgressIndicator();
                await showErrorDialog("Amend", assetNames);
            }
            else {
                //DYNCRM-22277 - Create Amended Opportunity
                var OpportunityId = "";
                Xrm.Utility.showProgressIndicator("Creating Amendment Opportunity.");
                if (!hostChildResult.ishostchild) {
                    var Opportunity = await Xrm.WebApi.retrieveRecord("niq_assetconfig", SelectedControlSelectedItemIds[0], "?$select=_niq_originatingopportunity_value");
                    OpportunityId = Opportunity["_niq_originatingopportunity_value"];
                }
                else {
                    OpportunityId = hostChildResult.hosstOpportunityId
                }
                var result = await Xrm.WebApi.retrieveRecord("niq_configurationsetting", "58679c7b-56c3-ef11-b8e9-0022488795c2", "?$select=niq_to");
                let commaSeparatedGuids = "";
                //DYNCRM-24098 populate amendment values
                SelectedControlSelectedItemIds.forEach((guid, index) => {
                    commaSeparatedGuids += guid;
                    if (index < SelectedControlSelectedItemIds.length - 1) {
                        commaSeparatedGuids += ",";
                    }
                });
                var flowUrl = result["niq_to"];
                const requestData = {
                    opportunityId: OpportunityId,
                    AssetIds: commaSeparatedGuids,
                    isHostChild: hostChildResult.ishostchild,
                    loggedInUserId: Xrm.Utility.getGlobalContext().userSettings.userId.replace('{', '').replace('}', '')
                };

                // Make the HTTP POST request
                fetch(flowUrl, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(requestData)
                })
                    .then(response => {
                        if (response.ok) {
                            return response.json();
                        } else {
                            throw new Error("HTTP request failed with status " + response.status);
                        }
                    })
                    .then(data => {
                        if (data.IsSuccess) {
                            var OppId = data.OpportunityGUID;
                            Xrm.Utility.openEntityForm("opportunity", OppId);
                            Xrm.Utility.closeProgressIndicator();
                        }
                        else {

                        }
                    })
                    .catch(error => {
                        console.error("Error triggering Power Automate:", error);
                        Xrm.Utility.closeProgressIndicator();
                    });
            }
        }
        catch {
            console.error("Error triggering Power Automate:");
        }
    }
}

async function checkIfHostChildAssetSelected(assetIds) {
    var isHostChild = true;
    var hostId;
    var samesHostCheck = true;
    var onlyrevshare = true;
    var onlyhost = true;
    var revshareid;
    var hostchildPresent = false;
    var individualPresent = false;
    const promises = assetIds.map(async (assetGuid) => {
        var result = await Xrm.WebApi.retrieveRecord("niq_assetconfig", assetGuid, "?$select=niq_assettype,_niq_hostopportunity_value");
        if (result['niq_assettype'] == 1) {
            isHostChild = false;
            individualPresent = true;
            console.log("ISHOSTCHILD: ", false);
        }
        else {
            hostchildPresent = true;
        }
        if (result['niq_assettype'] == 4)
            revshareid = assetGuid;
        if (result['niq_assettype'] != 4)
            onlyrevshare = false;
        if (result['niq_assettype'] != 2)
            onlyhost = false;
        if (result['_niq_hostopportunity_value'] != null && result['_niq_hostopportunity_value'] != undefined) {
            if (hostId === undefined)
                hostId = result['_niq_hostopportunity_value'];
            var currentAssetHostId = result['_niq_hostopportunity_value'];
            if (hostId !== currentAssetHostId)
                samesHostCheck = false;
        }
    });
    await Promise.all(promises);
    return {
        ishostchild: isHostChild,
        isSameHostInAsset: samesHostCheck,
        hosstOpportunityId: hostId,
        isOnlyRevShare: onlyrevshare,
        isOnlyHost: onlyhost,
        isIndividualHostChildAssetPresent: individualPresent && hostchildPresent ? true : false,
        revShareId: revshareid
    };
}


async function OnClick_HCAmendment(SelectedControlSelectedItemIds) {
    debugger;
    let assetIds = SelectedControlSelectedItemIds.toString();
    Xrm.Utility.showProgressIndicator("Amending Asset.");
    // let assetIds = "8bdf9f7a-a5fa-ef11-bae2-6045bda1abcd,e2955ac0-a7fa-ef11-bae2-6045bda1abcd,8fdf9f7a-a5fa-ef11-bae2-6045bda1abcd,e4955ac0-a7fa-ef11-bae2-6045bda1abcd,";
    let hostOpprtunityId = "18684fe3-5385-4389-b144-19826a22cc75";

    let body = {
        "assetIds": assetIds,
        "hostOpprtunityId": hostOpprtunityId
    };

    let req = new XMLHttpRequest();
    req.open("POST", "https://prod-53.northeurope.logic.azure.com:443/workflows/31dc6395fc2043149e83d221eb2b4cfd/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=YDbR60gDV46VB8ehxV8f5GjPwVDfEVn2Fpdrk2tKabk", true);
    req.setRequestHeader("Content-Type", "application/json");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                let resultJson = JSON.parse(this.response);
                console.log(resultJson);
                Xrm.Utility.openEntityForm("opportunity", resultJson.HostOpportunityId);
                Xrm.Utility.closeProgressIndicator();
            } else {
                console.log(this.statusText);
                Xrm.Utility.closeProgressIndicator();
            }
        }
    };
    req.send(JSON.stringify(body));
}

async function OnClick_HCPECOLA(SelectedControlSelectedItemIds) {
    debugger;
    const isRevShareSelected = await checkIfRevshare(SelectedControlSelectedItemIds);

    if (!isRevShareSelected) {
        // Show error if different opportunities are selected
        var message = "Revenue Share assets cannot be used for COLA/PE application.";
        await Xrm.Navigation.openAlertDialog({ title: "Warning!", text: message });
        return;
    }
    let assetIds = SelectedControlSelectedItemIds.toString();
    // Xrm.Utility.showProgressIndicator("Amending Asset.");
    Xrm.App.sidePanes.createPane({
        title: "HC COLA/PE",
        imageSrc: "WebResources/carl_accounticon.svg",
        hideHeader: false,
        canClose: true,
        width: 600
    }).then((pane) => {
        pane.navigate({
            pageType: "webresource",
            webresourceName: "niq_HCPECOLADialogue",
        })
    });
}

async function OnClick_HCRenewal(SelectedControlSelectedItemIds) {
    debugger;
    Xrm.Utility.showProgressIndicator("Renewing Assets.");
    let assetConfigIds = "8bdf9f7a-a5fa-ef11-bae2-6045bda1abcd,e2955ac0-a7fa-ef11-bae2-6045bda1abcd,19a5cc41-a8fa-ef11-bae2-7c1e528418ea";

    let body = {
        "AssetConfigIdInput": assetConfigIds

    };

    let req = new XMLHttpRequest();
    req.open("POST", "https://prod-47.northeurope.logic.azure.com:443/workflows/8ff8b9bfc3a34c7c8154286f7e93a25e/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=aDrkb3e3eQo5yTD7CHv8nTh6tovzd6hvticBo9l5pLo", true);
    req.setRequestHeader("Content-Type", "application/json");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                let resultJson = JSON.parse(this.response);
                console.log(resultJson);
                Xrm.Utility.openEntityForm("opportunity", resultJson.HostOpportunityID);
                Xrm.Utility.closeProgressIndicator();
            } else {
                console.log(this.statusText);
                Xrm.Utility.closeProgressIndicator();
            }
        }
    };
    req.send(JSON.stringify(body));
}
// Check if any exting opportunity is present for this asset ids
async function checkExistingPECOLAOpportunity(SelectedControlSelectedItemIds) {
    var strIds = SelectedControlSelectedItemIds.toString();
    var arrIds = strIds.split(",");
    let conditions = null;
    for (var i = 0; i < arrIds.length; i++) {
        conditions = arrIds.map(id =>
            `<condition attribute="niq_assetconfigidinput" operator="like" value="%${id.trim()}%" />`
        ).join("\n");
    }

    let fetchXml = `
        <fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">
        <entity name="opportunity">
            <attribute name="name" />
            <attribute name="opportunityid" />
            <attribute name="niq_opportunitynumber" />
            <filter type="and">
            <filter type="or">
            ${conditions}
            </filter>
            <condition attribute="statecode" operator="eq" value="0" />
            <condition attribute="niq_opportunitytype" operator="eq" value="2" />
            condition attribute="niq_existingcontractaction" operator="eq" value="2" />
            </filter>
        </entity>
        </fetch>`;

    var opportunity = await Xrm.WebApi.retrieveMultipleRecords("opportunity", "?fetchXml=" + encodeURIComponent(fetchXml))
    if (opportunity.entities.length > 0) {
        var opportunityNumbers = [];
        for (var i = 0; i < opportunity.entities.length; i++) {
            opportunityNumbers.push(opportunity.entities[i]["niq_opportunitynumber"]);
        }
        var numbersString = opportunityNumbers.join(", ");
        if (opportunity.entities.length == 1) {
            var message = "Other PE/COLA opportunity <" + numbersString + "> is currently open for this asset and must be closed before a new amendment can be initiated. Please review and close existing opportunity before proceeding";
        }
        else {
            var message = "Other PE/COLA opportunity <" + numbersString + "> are currently open for this asset and must be closed before a new amendment can be initiated. Please review and close existing opportunity before proceeding";
        }

        await Xrm.Navigation.openAlertDialog({ title: "Warning!", text: message });
        saveEvent.preventDefault();
    }

}

// on Click of Apply Cola/PE button trigger a flow
async function OnClick_ApplyCOLA(SelectedControlSelectedItemIds) {
    let message = null;
    // Get Parent record id
    let accountId = formContext.data.entity.getId();
    if (!SelectedControlSelectedItemIds || SelectedControlSelectedItemIds.length === 0) {
        return;
    }
    // Check if any exting opportunity is present for this asset ids
    await checkExistingPECOLAOpportunity(SelectedControlSelectedItemIds);

    //Build Fetch xml to get assestconfig records
    let fetchXml = buildFetchXml(accountId);
    // Fetch xml to get assestconfig records
    let assetConfiRecords = await fetchAssetConfigRecords(fetchXml);

    // Get only select records from All assetconfig 
    let records = filterRecords(assetConfiRecords, SelectedControlSelectedItemIds);

    if (records.length > 0) {
        let firstRecord = records[0];
        let assetType = firstRecord.niq_assettype;
        console.log("Asset Type of the first record:", assetType);

        switch (assetType) {
            case 1: // Individual
                // Validate assest belongs to same originating Opportunity and selected assets are of type Individual
                let { individualCount, otherCount, isSameOriginatingOpportunity } = validateAssets(records);
                if (individualCount > 0 && otherCount > 0) {
                    Xrm.Utility.closeProgressIndicator();
                    message = "Host/Child asset actions cannot be combined with Non-Host/Child assets. Please perform asset actions separately.";
                    await showErrorDialogMsg(message);
                    return;
                } else if (!isSameOriginatingOpportunity) {
                    Xrm.Utility.closeProgressIndicator();
                    message = "Please select assets that belong to the same opportunity for COLA & PE application.";
                    await showErrorDialogMsg(message);
                    return;
                } else {
                    const oppStatus = await OnClick_Action(SelectedControlSelectedItemIds, "Apply COLA", [1002]);
                    if (oppStatus) {
                        await openSidePane(formContext, assetType);
                    }
                }
                break;
            case 2: // Child
            case 3: // Host
                // Validate assest belongs to same Host Opportunity and selected assets are of type Host/child
                let hostOpportunity = firstRecord._niq_hostopportunity_value;
                let { filteredRecords, isSameHostOpportunity } = filterByHostOpportunity(assetConfiRecords, hostOpportunity);
                if (!(records.every(record => record._niq_hostopportunity_value === hostOpportunity))) {
                    Xrm.Utility.closeProgressIndicator();
                    message = "Please select assets that belong to the same Host Child Contract for COLA & PE application.";
                    await showErrorDialogMsg(message);
                    return;
                } else if (filteredRecords.length !== records.length) {
                    Xrm.Utility.closeProgressIndicator();
                    message = "Please select all Assets under Host Opportunity/ Contract for applying COLA & PE application.";
                    await showErrorDialogMsg(message);
                    return;
                } else {
                    await openSidePane(formContext, assetType);
                }
                console.log("Filtered Records:", filteredRecords);
                break;
            default:
                break;
        }
    }
}

// Validate assest belongs to same Host Opportunity and selected assets are of type Host/child
function filterByHostOpportunity(records, hostOpportunityParam) {
    let filteredRecords = [];
    let isSameHostOpportunity = true;
    records.entities.forEach(record => {
        if ((record.niq_assettype === 2 || record.niq_assettype === 3) && record._niq_hostopportunity_value === hostOpportunityParam) {
            filteredRecords.push(record);
        }
        //else if (record.niq_assettype === 2 || record.niq_assettype === 3) {
        //   isSameHostOpportunity = false;
        //}
    });

    return { filteredRecords, isSameHostOpportunity };

}

async function openSidePane(formContext, assetType) {
    var id = formContext.ui.formSelector.getCurrentItem().getId();
    await Xrm.App.sidePanes.createPane({
        title: "Apply COLA/PE",
        imageSrc: "WebResources/carl_accounticon.svg",
        paneId: "ApplyColaPE",
        hideHeader: false,
        canClose: true,
        width: 600,
        // Pass your data here
    }).then((pane) => {
        pane.navigate({
            pageType: "webresource",
            webresourceName: "niq_ColaPEDailogue",
            data: assetType
        });
    });
}


async function showErrorDialogMsg(errorMessage) {
    const errorOptions = {
        errorCode: 1235, // You can set a default error code or make it dynamic if needed
        details: errorMessage,
        message: errorMessage
    };
    Xrm.Utility.closeProgressIndicator();
    await Xrm.Navigation.openErrorDialog(errorOptions);
}

//Build Fetch xml to get assestconfig records
async function fetchAssetConfigRecords(fetchXml) {
    return await Xrm.WebApi.retrieveMultipleRecords("niq_assetconfig", fetchXml);
}
// Get only select records from All assetconfig 
function filterRecords(records, selectedIds) {
    return records.entities.filter(record => selectedIds.includes(record.niq_assetconfigid));
}
// Validate assest belongs to same originating Opportunity and selected assets are of type Individual
function validateAssets(records) {
    let individualCount = 0;
    let otherCount = 0;
    let originatingOpportunity = null;
    let isSameOriginatingOpportunity = true;

    records.forEach(record => {
        if (record.niq_assettype === 1) { // Individual
            individualCount++;
        } else {
            otherCount++;
        }

        if (originatingOpportunity === null) {
            originatingOpportunity = record._niq_originatingopportunity_value;
        } else if (originatingOpportunity !== record._niq_originatingopportunity_value) {
            isSameOriginatingOpportunity = false;
        }
    });

    return { individualCount, otherCount, isSameOriginatingOpportunity };
}
//Build Fetch xml to get assestconfig records
function buildFetchXml(accountId) {
    return `?fetchXml=
               <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                <entity name='niq_assetconfig'>
                <attribute name='niq_assetconfigid' />
                <attribute name='niq_assetsalesorg' />
                <attribute name='niq_assetprice' />
                <attribute name='niq_originatingopportunity' />
                <attribute name='niq_originatingquote' />
                <attribute name='niq_assetstatus' />
                <attribute name='niq_originatingsalesorder' />
                <attribute name='niq_asset' />
                <attribute name='niq_assetcreationdate' />
                <attribute name='niq_countofproduct' />
                <attribute name='niq_assetextendedamount' />
                <attribute name='niq_assetenddate' />
                <attribute name='niq_assetstartdate' />
                <attribute name='niq_updatefrequency' />
                <attribute name='niq_termtype' />
                <attribute name='niq_assettype' />
                <attribute name='niq_hostopportunity' />
                <attribute name='statuscode' />
                <attribute name='statecode' />
                <attribute name='niq_ratecardid' />
                <attribute name='niq_originatinglead' />
                <attribute name='niq_iscurrentassetconfig' />
                <attribute name='niq_experlogixconfig' />
                <attribute name='exchangerate' />
                <attribute name='createdon' />
                <attribute name='transactioncurrencyid' />
                <attribute name='createdby' />
                <attribute name='niq_assetextendedamount_base' />
                <attribute name='niq_assetconfignumber' />
                <attribute name='niq_assetactiondate' />
                <attribute name='niq_originatingaction' />
                <attribute name='niq_assettermnote' />
                <attribute name='niq_account' />
                <order attribute='niq_assetconfignumber' descending='false' />
                <filter type='and'>
                <condition attribute='niq_iscurrentassetconfig' operator='eq' value='1' />
                <condition attribute='niq_account' operator='eq' value='${accountId}' />
                </filter>
                </entity>
                </fetch>`;
}

async function OnClick_ApplyPE(SelectedControlSelectedItemIds) {
    await OnClick_Action(SelectedControlSelectedItemIds, "Apply PE", [1002]);
}

//DYNCRM-22767 - Create Renewal Opportunity
async function OnClick_Renew(SelectedControlSelectedItemIds) {
    if (!SelectedControlSelectedItemIds || SelectedControlSelectedItemIds.length === 0) return;
    const assetNames = await getAssetNamesForStatus(SelectedControlSelectedItemIds, [1003]);
    if (assetNames.length > 0) {
        Xrm.Utility.closeProgressIndicator();
        await showErrorDialog("Renew", assetNames);
        return;
    }
    let allowCreateRenewalOpportunity = true;
    let confirmDialogBoxShownForMultipleSalesOrg = false;
    let assetCounts = { host: 0, child: 0, individual: 0, revShare: 0 };
    let validAssetType = 1; // Individual
    let isIndividualType = true;
    let salesOrg;
    let assetCurrencyId;
    let assetSalesOrgId;
    var isSameCurrency = true;
    var isSameSalesOrd = true;
    const assetIds = SelectedControlSelectedItemIds.toString().split(",");

    for (const assetconfigid of assetIds) {
        const opportunities = await Xrm.WebApi.retrieveMultipleRecords("opportunity", `?$select=niq_opportunitynumber&$filter=(contains(niq_assetconfigidinput,'${assetconfigid}') and niq_opportunitytype eq 2 and statecode eq 0)`);
        if (opportunities.entities.length > 0) {
            const opportunityNumbers = opportunities.entities.map(entity => entity.niq_opportunitynumber).join(", ");
            const message = `Other amendment/ renewal opportunity <${opportunityNumbers}> ${opportunities.entities.length > 1 ? 'are' : 'is'} currently open for this asset and must be closed before a new renew/ amendment can be initiated. Please review and close existing opportunity before proceeding`;
            await Xrm.Navigation.openAlertDialog({ title: "Warning!", text: message });
            saveEvent.preventDefault();
            return;
        }
    }

    if (await validateFutureAssets(SelectedControlSelectedItemIds)) return;

    for (const item of SelectedControlSelectedItemIds) {
        const assetConfigResult = await Xrm.WebApi.retrieveRecord("niq_assetconfig", item, "?$select=niq_assettype,_transactioncurrencyid_value,_niq_assetsalesorg_value");
        assetCounts[getAssetTypeName(assetConfigResult.niq_assettype)]++;
        if (validAssetType !== assetConfigResult.niq_assettype) {
            isIndividualType = false;
        }
    }

    const hostChildResult = await checkIfHostChildAssetSelected(SelectedControlSelectedItemIds);
    if (hostChildResult.isIndividualHostChildAssetPresent) {
        const errorOptions = {
            errorCode: 1235,
            details: "Host/Child asset actions cannot be combined with Non-Host/Child assets. Please perform asset actions separately.",
            message: "Host/Child asset actions cannot be combined with Non-Host/Child assets. Please perform asset actions separately."
        };
        Xrm.Utility.closeProgressIndicator();
        await Xrm.Navigation.openErrorDialog(errorOptions);
        return;
    }
    if (isIndividualType) {
        for (const assetconfigid of assetIds) {
            const result = await Xrm.WebApi.retrieveRecord("niq_assetconfig", assetconfigid, "?$select=_niq_assetsalesorg_value");
            if (result) {
                if (!salesOrg) salesOrg = result._niq_assetsalesorg_value;
                if (salesOrg !== result._niq_assetsalesorg_value && !confirmDialogBoxShownForMultipleSalesOrg) {
                    confirmDialogBoxShownForMultipleSalesOrg = true;
                    const confirmOptions = {
                        title: "Confirmation",
                        text: "You've selected to combine Assets which cross different Sales Orgs. Please be aware that depending on the Asset combination included, some may not be able to be combined, based on rate card availability within the selected Sales Org on your opportunity. This will result in needing to separate out the Assets to separate opportunities. Would you like to proceed?",
                        confirmButtonLabel: "Yes",
                        cancelButtonLabel: "No"
                    };
                    const confirmation = await Xrm.Navigation.openConfirmDialog(confirmOptions);
                    if (!confirmation.confirmed) {
                        allowCreateRenewalOpportunity = false;
                        return;
                    }
                }
            }
        }
        var currencySalesOrgValidated = await validateCurrencyAndSalesOrgInSelectedAssets(SelectedControlSelectedItemIds);
        if (currencySalesOrgValidated) {
            await createRenewalOpportunity(SelectedControlSelectedItemIds, allowCreateRenewalOpportunity, false);
        }
    } else {
        await handleNonIndividualAssets(assetCounts, hostChildResult, SelectedControlSelectedItemIds, allowCreateRenewalOpportunity);
    }
}

async function validateCurrencyAndSalesOrgInSelectedAssets(SelectedControlSelectedItemIds) {
    let assetCurrencyId;
    let assetSalesOrgId;
    for (const item of SelectedControlSelectedItemIds) {
        const assetConfigResult = await Xrm.WebApi.retrieveRecord("niq_assetconfig", item, "?$select=niq_assettype,_transactioncurrencyid_value,_niq_assetsalesorg_value");
        if (assetCurrencyId == undefined)
            assetCurrencyId = assetConfigResult._transactioncurrencyid_value;
        if (assetSalesOrgId == undefined)
            assetSalesOrgId = assetConfigResult._niq_assetsalesorg_value;

        if (assetCurrencyId != assetConfigResult._transactioncurrencyid_value || assetSalesOrgId != assetConfigResult._niq_assetsalesorg_value) {
            const errorOptions = {
                errorCode: 1235,
                details: "You have selected assets belong to different sales orgs or currencies. Please select assets that are part of the same sales org/currencies.",
                message: "You have selected assets belong to different sales orgs or currencies. Please select assets that are part of the same sales org/currencies."
            };
            Xrm.Utility.closeProgressIndicator();
            await Xrm.Navigation.openErrorDialog(errorOptions);
            return false;
        }
    }
    return true;
}
async function validateCurrencyInSelectedAssets(SelectedControlSelectedItemIds) {
    let assetCurrencyId;
    for (const item of SelectedControlSelectedItemIds) {
        const assetConfigResult = await Xrm.WebApi.retrieveRecord("niq_assetconfig", item, "?$select=niq_assettype,_transactioncurrencyid_value,_niq_assetsalesorg_value");
        if (assetCurrencyId == undefined)
            assetCurrencyId = assetConfigResult._transactioncurrencyid_value;

        if (assetCurrencyId != assetConfigResult._transactioncurrencyid_value) {
            const errorOptions = {
                errorCode: 1235,
                details: "You have selected assets belong to different currencies. Please select assets with the same currency.",
                message: "You have selected assets belong to different currencies. Please select assets with the same currency."
            };
            Xrm.Utility.closeProgressIndicator();
            await Xrm.Navigation.openErrorDialog(errorOptions);
            return false;
        }
    }
    return true;
}

async function validateFutureAssets(SelectedControlSelectedItemIds) {
    const invalidStatuses = [1003]; // Future
    for (const item of SelectedControlSelectedItemIds) {
        const asset = await Xrm.WebApi.retrieveRecord("niq_assetconfig", item, "?$select=niq_assetstatus");
        if (invalidStatuses.includes(asset.niq_assetstatus)) {
            const errorOptions = {
                errorCode: 1235,
                details: "You cannot create renewal opportunity from Future Assets.",
                message: "You cannot create renewal opportunity from Future Assets."
            };
            Xrm.Utility.closeProgressIndicator();
            await Xrm.Navigation.openErrorDialog(errorOptions);
            return true;
        }
    }
    return false;
}

async function createRenewalOpportunity(SelectedControlSelectedItemIds, allowCreateRenewalOpportunity, isHostChildOpportunityNeeded) {
    if (SelectedControlSelectedItemIds.length > 0 && allowCreateRenewalOpportunity) {
        Xrm.Utility.showProgressIndicator("Creating Renewal Opportunity.");
        const result = await Xrm.WebApi.retrieveRecord("niq_configurationsetting", "f4c5233b-32e5-ef11-8eea-6045bdf50c47", "?$select=niq_to");
        const flowUrl = result.niq_to;
        const requestData = {
            AssetConfigIdInput: SelectedControlSelectedItemIds.join(","),
            HostChildOpportunityIsNeeded: isHostChildOpportunityNeeded,
            loggedInUserId: Xrm.Utility.getGlobalContext().userSettings.userId.replace('{', '').replace('}', '')
        };
        try {
            const response = await fetch(flowUrl, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(requestData)
            });
            if (!response.ok) throw new Error(`HTTP request failed with status ${response.status}`);
            const data = await response.json();
            if (data.IsSuccess) {
                Xrm.Utility.openEntityForm("opportunity", data.OpportunityGUID);
            }
        }
        catch (error) {
            console.error("Error triggering Power Automate:", error);
        }
        finally {
            Xrm.Utility.closeProgressIndicator();
        }
    }
}

function getAssetTypeName(assetType) {
    switch (assetType) {
        case 1: return 'individual';
        case 2: return 'host';
        case 3: return 'child';
        case 4: return 'revShare';
        default: return 'unknown';
    }
}

async function handleNonIndividualAssets(assetCounts, hostChildResult, SelectedControlSelectedItemIds, allowCreateRenewalOpportunity) {
    if (assetCounts.individual > 0 && assetCounts.host === 0 && assetCounts.child === 0 && assetCounts.revShare === 0) {
        var currencySalesOrgValidated = await validateCurrencyAndSalesOrgInSelectedAssets(SelectedControlSelectedItemIds);
        if (currencySalesOrgValidated) {
            await createRenewalOpportunity(SelectedControlSelectedItemIds, allowCreateRenewalOpportunity, false);
        }
        return;
    }
    else if (hostChildResult.ishostchild && !hostChildResult.isSameHostInAsset) {
        const errorOptions = {
            errorCode: 1235,
            details: "The selected child assets are associated with a different host. Please select child assets that link to the same host.",
            message: "The selected child assets are associated with a different host. Please select child assets that link to the same host."
        };
        Xrm.Utility.closeProgressIndicator();
        await Xrm.Navigation.openErrorDialog(errorOptions);
        return;
    }
    else if (((assetCounts.host > 0 || assetCounts.revShare > 0) && assetCounts.child > 0 && assetCounts.individual > 0) || ((assetCounts.host > 0 || assetCounts.revShare > 0) && assetCounts.child === 0 && assetCounts.individual > 0)) {
        const errorOptions = {
            errorCode: 1235,
            details: "Host/Child asset actions cannot be combined with Non-Host/Child assets. Please perform asset actions separately.",
            message: "Host/Child asset actions cannot be combined with Non-Host/Child assets. Please perform asset actions separately."
        };
        Xrm.Utility.closeProgressIndicator();
        await Xrm.Navigation.openErrorDialog(errorOptions);
        return;
    }
    else if ((assetCounts.revShare > 0 && assetCounts.host === 0 && assetCounts.child === 0 && assetCounts.individual === 0) || (assetCounts.revShare > 0 && assetCounts.host === 0 && assetCounts.child === 0 && assetCounts.individual === 0)) {
        const errorOptions = {
            errorCode: 1235,
            details: "Only RevShare asset can not be selected to be renewed from a Multicountry contract. Please select atleast a Host Asset or a Child Asset and try again.",
            message: "Only RevShare asset can not be selected to be renewed from a Multicountry contract. Please select atleast a Host Asset or a Child Asset and try again."
        };
        Xrm.Utility.closeProgressIndicator();
        await Xrm.Navigation.openErrorDialog(errorOptions);
        return;
    }
    else if ((assetCounts.host > 0 && assetCounts.child === 0 && assetCounts.individual === 0 && assetCounts.revShare === 0) || (assetCounts.host > 0 && assetCounts.child === 0 && assetCounts.individual === 0 && assetCounts.revShare > 0)) {
        const confirmOptions = {
            title: "Confirmation",
            text: "You have not selected any child assets for renewal. The host assets will become individual, and the child assets will expire, and there will be no host/child connection. Do you want to proceed?",
            confirmButtonLabel: "Yes",
            cancelButtonLabel: "No"
        };
        const confirmation = await Xrm.Navigation.openConfirmDialog(confirmOptions);
        if (confirmation.confirmed) {
            var currencySalesOrgValidated = await validateCurrencyAndSalesOrgInSelectedAssets(SelectedControlSelectedItemIds);
            if (currencySalesOrgValidated) {
                await createRenewalOpportunity(SelectedControlSelectedItemIds, allowCreateRenewalOpportunity, false);
            }
            return;
        }
        else {
            return;
        }
    }
    else if (assetCounts.host === 0 && assetCounts.child > 0 && assetCounts.individual === 0 && assetCounts.revShare > 0) {
        const confirmOptions = {
            title: "Confirmation",
            text: "You have chosen to renew only child assets without selecting any host assets. Are you certain that the host assets do not need renewal?",
            confirmButtonLabel: "Yes",
            cancelButtonLabel: "No"
        };
        const confirmation = await Xrm.Navigation.openConfirmDialog(confirmOptions);
        if (confirmation.confirmed) {
            var currencySalesOrgValidated = await validateCurrencyInSelectedAssets(SelectedControlSelectedItemIds);
            if (currencySalesOrgValidated) {
                await createRenewalOpportunity(SelectedControlSelectedItemIds, allowCreateRenewalOpportunity, true);
            }
            return;
        }
        else {
            return;
        }
    }
    else if (assetCounts.host === 0 && assetCounts.child > 0 && assetCounts.individual === 0 && assetCounts.revShare === 0) {
        const confirmOptions = {
            title: "Confirmation",
            text: "You have not selected a revenue share asset along with the child assets for the renewal. As a result, the child assets will be converted to individual assets, and there will be no host/child connection. Do you want to proceed?",
            confirmButtonLabel: "Yes",
            cancelButtonLabel: "No"
        };
        const confirmation = await Xrm.Navigation.openConfirmDialog(confirmOptions);
        if (confirmation.confirmed) {
            var currencySalesOrgValidated = await validateCurrencyInSelectedAssets(SelectedControlSelectedItemIds);
            if (currencySalesOrgValidated) {
                await createRenewalOpportunity(SelectedControlSelectedItemIds, allowCreateRenewalOpportunity, false);
            }
            return;
        }
        else {
            return;
        }
    }
    var currencySalesOrgValidated = await validateCurrencyInSelectedAssets(SelectedControlSelectedItemIds);
    if (currencySalesOrgValidated) {
        await createRenewalOpportunity(SelectedControlSelectedItemIds, allowCreateRenewalOpportunity, true);
    }
}

async function OnClick_DemoRenewal(SelectedControlSelectedItemIds) {
    window.parent.Xrm.Utility.showProgressIndicator("Applying Renewal");
    let flowUrl = "https://prod-04.northeurope.logic.azure.com:443/workflows/e06da0f249f84e6b89571267cb84adfc/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=NZykUDRwN8r61i1Q8JOIEAQ1OBlLvCZEfMZi8-u4Jr4";
    let requestData = {
        "AssetIds": SelectedControlSelectedItemIds.join(","),
    };
    fetch(flowUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestData)
    }).then(response => {
        if (response.ok == true) {
            window.parent.Xrm.Utility.closeProgressIndicator();
            var alertStrings = {
                confirmButtonLabel: "Ok",
                text: "Successfully generated opportunity for this renewal. ",
                title: "Confirmation Dialog"
            };
            var alertOptions = { height: 260, width: 260 };
            window.parent.Xrm.Navigation.openAlertDialog(alertStrings, alertOptions).then(() => {
                window.parent.Xrm.Utility.closeProgressIndicator();
            });
        }

    }).catch(error => console.error("Error:", error));
}


// Button Visibility Handlers
async function ShowHideAssetConfigSubgridbuttonRenew(SelectedControlSelectedItemIds) {
    var statusFlag = await ShowHideAssetConfigSubgridButton(SelectedControlSelectedItemIds, [AssetStatus.Active, AssetStatus.Inactive]);
    var roleFlag = await checkUserRole(["NIQ Sales User", "System Administrator", "NIQ Business Admin"]);
    return statusFlag && roleFlag;
}

async function ShowHideAssetConfigSubgridbuttonAmend(SelectedControlSelectedItemIds) {
    var statusFlag = await ShowHideAssetConfigSubgridButton(SelectedControlSelectedItemIds, [AssetStatus.Active, AssetStatus.Future]);
    var roleFlag = await checkUserRole(["NIQ Sales User", "System Administrator", "NIQ Business Admin"]);
    return statusFlag && roleFlag;
}

async function ShowHideAssetConfigSubgridbuttonApplyCola(SelectedControlSelectedItemIds) {
    var statusFlag = await ShowHideAssetConfigSubgridButton(SelectedControlSelectedItemIds, [AssetStatus.Active, AssetStatus.Future, AssetType.Child, AssetType.Host, AssetType.Individual]);
    var roleFlag = await checkUserRole(["NIQ Sales User", "System Administrator", "NIQ Business Admin"]);
    return statusFlag && roleFlag;
}

async function ShowHideAssetConfigSubgridbuttonApplyPE(SelectedControlSelectedItemIds) {
    return await ShowHideAssetConfigSubgridButton(SelectedControlSelectedItemIds, [AssetStatus.Active, AssetStatus.Future]);
}

async function ShowHideAssetConfigSubgridbuttonDemoRenewal(SelectedControlSelectedItemIds) {
    var statusFlag = await ShowHideAssetConfigSubgridButton(SelectedControlSelectedItemIds, [AssetStatus.Active]);
    var roleFlag = await checkUserRole(["NIQ Sales User", "System Administrator"]);
    return statusFlag && roleFlag;
}

async function checkUserRole(rolesToCheck) {
    var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
    if (roles === null) return false;
    var hasRole = false;
    rolesToCheck.forEach(function (role) {
        roles.forEach(function (item) {
            if (item.name.toLowerCase() === role.toLowerCase()) {
                hasRole = true;
            }
        });
    });
    return hasRole;
}