const baseUrl = "https://orgbc876bfc.crm8.dynamics.com";

async function fetchData(entitySet, selectFields, filter = "") {
  let url = `${baseUrl}/api/data/v9.2/${entitySet}?$select=${selectFields}`;
  if (filter) url += `&$filter=${filter}`;
  const response = await fetch(url, {
    method: "GET",
    headers: {
      "OData-MaxVersion": "4.0",
      "OData-Version": "4.0",
      "Content-Type": "application/json; charset=utf-8",
      "Accept": "application/json",
      "Prefer": "odata.include-annotations=*"
    }
  });
  if (!response.ok) throw new Error("API error: " + response.statusText + " (" + response.status + ")");
  const data = await response.json();
  return data.value || [];
}

async function getContinents() {
  return await fetchData("mash_continents", "mash_continentid,mash_continentsid,mash_name");
}
async function getCountries(continentId) {
  return await fetchData(
    "mash_countries",
    "mash_countryid,mash_countrysid,mash_name,_mash_continent_value",
    `_mash_continent_value eq ${continentId}`
  );
}
async function getStates(countryId) {
  return await fetchData(
    "mash_states",
    "mash_stateid,mash_statesid,mash_name,_mash_country_value",
    `_mash_country_value eq ${countryId}`
  );
}
async function buildHierarchy() {
  const continents = await getContinents();
  const hierarchy = [];
  for (const continent of continents) {
    const countries = await getCountries(continent.mash_continentid);
    const countryNodes = [];
    for (const country of countries) {
      const states = await getStates(country.mash_countryid);
      const stateNodes = states.map(state => ({
        level: "State",
        id: state.mash_statesid,
        name: state.mash_name
      }));
      countryNodes.push({
        level: "Country",
        id: country.mash_countrysid,
        name: country.mash_name,
        children: stateNodes
      });
    }
    hierarchy.push({
      level: "Continent",
      id: continent.mash_continentsid,
      name: continent.mash_name,
      children: countryNodes
    });
  }
  return hierarchy;
}

// UI functions for rendering grid
function createRow(item, parentId = "") {
  const tr = document.createElement("tr");
  tr.className = `${item.level}`;
  tr.dataset.level = item.level;
  tr.dataset.id = item.id;
  if (parentId) tr.dataset.parent = parentId;

  const tdLevel = document.createElement("td");
  const icon = document.createElement("span");

  if (item.children && item.children.length > 0) {
    icon.className = "expand-icon collapsed";
    icon.textContent = "+";
    icon.onclick = (e) => {
      e.stopPropagation();
      toggleChildren(item.id, icon);
    };
  } else {
    icon.className = "no-icon";
  }

  tdLevel.appendChild(icon);
  tdLevel.appendChild(document.createTextNode(" " + item.level));

  const tdId = document.createElement("td");
  tdId.textContent = item.id;

  const tdName = document.createElement("td");
  tdName.textContent = item.name;

  tr.appendChild(tdLevel);
  tr.appendChild(tdId);
  tr.appendChild(tdName);

  return tr;
}

function toggleChildren(parentId, icon) {
  const rows = document.querySelectorAll(`[data-parent='${parentId}']`);
  const isCollapsed = icon.classList.contains("collapsed");

  if (isCollapsed) {
    rows.forEach(row => row.style.display = "");
    icon.classList.remove("collapsed");
    icon.classList.add("expanded");
    icon.textContent = "-";
  } else {
    collapseRecursively(parentId);
    icon.classList.remove("expanded");
    icon.classList.add("collapsed");
    icon.textContent = "+";
  }
}

function collapseRecursively(parentId) {
  const children = document.querySelectorAll(`[data-parent='${parentId}']`);
  children.forEach(row => {
    row.style.display = "none";
    const childIcon = row.querySelector(".expand-icon");
    if (childIcon && childIcon.classList.contains("expanded")) {
      childIcon.classList.remove("expanded");
      childIcon.classList.add("collapsed");
      childIcon.textContent = "+";
    }
    collapseRecursively(row.dataset.id);
  });
}

// Entry point: call this after DOM is ready
document.addEventListener("DOMContentLoaded", renderGrid);

async function renderGrid() {
  const tbody = document.getElementById("grid-body");
  const errorMessage = document.getElementById("errorMessage");
  tbody.innerHTML = "";
  errorMessage.textContent = "";
  try {
    const data = await buildHierarchy();
    data.forEach(level1 => {
      const row1 = createRow(level1);
      tbody.appendChild(row1);
      level1.children?.forEach(level2 => {
        const row2 = createRow(level2, level1.id);
        row2.style.display = "none";
        tbody.appendChild(row2);
        level2.children?.forEach(level3 => {
          const row3 = createRow(level3, level2.id);
          row3.style.display = "none";
          tbody.appendChild(row3);
        });
      });
    });
  } catch (e) {
    errorMessage.textContent = "Error loading data: " + e.message;
  }
}