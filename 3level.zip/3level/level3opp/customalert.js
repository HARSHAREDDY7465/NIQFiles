
// --- Custom Alert Function ---
function checkEstimatedRevenue(value) {
    if (Number(value) > 100000) {
        alert("Warning: Estimated Revenue exceeds 100,000!");
    }
}

// Attach listener to input fields after DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll("input.crm-editbox[type='number']").forEach(input => {
        input.addEventListener("blur", () => {
            const label = input.closest("td")?.previousElementSibling?.textContent || "";
            if (label.includes("Revenue")) {
                checkEstimatedRevenue(input.value);
            }
        });
    });
});
