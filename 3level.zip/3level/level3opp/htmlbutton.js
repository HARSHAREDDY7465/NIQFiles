function openMyHtmlPage(primaryControl) {
    var formContext = primaryControl;
    var recordId = formContext.data.entity.getId(); // Get current record ID
    var webresourceName = "niq_Oppindex"; // Your HTML web resource name
    var windowOptions = { height: 600, width: 800 };

    // Open the web resource and pass the encoded recordId
    Xrm.Navigation.openWebResource(webresourceName, windowOptions, recordId);
}
