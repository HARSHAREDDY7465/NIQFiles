function filterChar(executionContext) {
  var formContext = executionContext.getFormContext();
  var opportunityId = formContext.data.entity.getId().replace("{", "").replace("}", "");
  var charSubgrid = formContext.getControl("cc_1759159449029"); 
  charSubgrid.setVisible(true);
  var fetchXml = `
      <fetch>
        <entity name='niq_productcharacteristic'> <!-- Replace with actual logical name -->
          <filter>
            <condition attribute='mash_country' operator='eq' value='${opportunityId}' />
          </filter>
        </entity>
      </fetch>`;
  statesSubgrid.setFilterXml(fetchXml);
  statesSubgrid.refresh();    
}