const baseUrl = "https://orgbc876bfc.crm8.dynamics.com";

const recordUrlFields = {
    Continent: "mash_continentrecordurl",
    Country: "mash_countryrecordurl",
    State: "mash_staterecordurl"
};

async function fetchData(entitySet, selectFields, filter = "") {
    let url = `${baseUrl}/api/data/v9.2/${entitySet}?$select=${selectFields}`;
    if (filter) url += `&$filter=${filter}`;
    const response = await fetch(url, {
        method: "GET",
        headers: {
        "OData-MaxVersion": "4.0",
        "OData-Version": "4.0",
        "Content-Type": "application/json; charset=utf-8",
        "Accept": "application/json",
        "Prefer": "odata.include-annotations=*"
        }
    });
    if (!response.ok) throw new Error("API error: " + response.statusText + " (" + response.status + ")");
    const data = await response.json();
    return data.value || [];
}

async function getContinents() {
    return await fetchData(
        "mash_continents",
        `mash_continentid,mash_continentsid,mash_name,${recordUrlFields.Continent}`
    );
}

async function getCountries(continentId) {
    return await fetchData(
        "mash_countries",
        `mash_countryid,mash_countrysid,mash_name,${recordUrlFields.Country},_mash_continent_value`,
        `_mash_continent_value eq ${continentId}`
    );
}

async function getStates(countryId) {
    return await fetchData(
        "mash_states",
        `mash_stateid,mash_statesid,mash_name,${recordUrlFields.State},_mash_country_value`,
        `_mash_country_value eq ${countryId}`
    );
}

async function buildHierarchy() {
    const continents = await getContinents();
    const hierarchy = [];
    for (const continent of continents) {
        const countries = await getCountries(continent.mash_continentid);
        const countryNodes = [];
        for (const country of countries) {
        const states = await getStates(country.mash_countryid);
        const stateNodes = states.map(state => ({
            level: "State",
            id: state.mash_statesid,
            name: state.mash_name,
            record_url: state[recordUrlFields.State]
        }));
        countryNodes.push({
            level: "Country",
            id: country.mash_countrysid,
            name: country.mash_name,
            record_url: country[recordUrlFields.Country],
            children: stateNodes
        });
        }
        hierarchy.push({
        level: "Continent",
        id: continent.mash_continentsid,
        name: continent.mash_name,
        record_url: continent[recordUrlFields.Continent],
        children: countryNodes
        });
    }
    return hierarchy;
}

function createRow(item, parentId = "") {
    const tr = document.createElement("tr");
    tr.className = `${item.level}`;
    tr.dataset.level = item.level;
    tr.dataset.id = item.id;
    if (parentId) tr.dataset.parent = parentId;

    const tdLevel = document.createElement("td");
    const icon = document.createElement("span");
    if (item.children && item.children.length > 0) {
        icon.className = "expand-icon collapsed";
        icon.textContent = "+";
        icon.onclick = (e) => {
        e.stopPropagation();
        toggleChildren(item.id, icon);
        };
    } else {
        icon.className = "no-icon";
        icon.textContent = "";
    }
    tdLevel.appendChild(icon);
    tdLevel.appendChild(document.createTextNode(" " + item.level));

    const tdId = document.createElement("td");
    tdId.textContent = item.id;

    const tdName = document.createElement("td");
    const link = document.createElement("a");
    link.href = item.record_url || "#";
    link.textContent = item.name;
    link.target = "_blank";
    // link.onclick = (e) => {
    //     e.preventDefault();
    //     if (item.record_url) {
    //     window.location.href = item.record_url; // Full page redirect
    //     }
    // };
    tdName.appendChild(link);

    tr.appendChild(tdLevel);
    tr.appendChild(tdId);
    tr.appendChild(tdName);

    return tr;
}

function toggleChildren(parentId, icon) {
    const rows = document.querySelectorAll(`tr[data-parent='${parentId}']`);
    const isCollapsed = icon.classList.contains("collapsed");
    icon.classList.toggle("collapsed", !isCollapsed);
    icon.classList.toggle("expanded", isCollapsed);
    icon.textContent = isCollapsed ? "-" : "+";
    rows.forEach(row => {
        row.style.display = isCollapsed ? "" : "none";
        if (!isCollapsed) collapseRecursively(row.dataset.id);
    });
}

function collapseRecursively(parentId) {
    const rows = document.querySelectorAll(`tr[data-parent='${parentId}']`);
    rows.forEach(row => {
        row.style.display = "none";
        collapseRecursively(row.dataset.id);
        const icon = row.querySelector(".expand-icon");
        if (icon) {
        icon.classList.remove("expanded");
        icon.classList.add("collapsed");
        icon.textContent = "+";
        }
    });
}

document.addEventListener("DOMContentLoaded", renderGrid);

async function renderGrid() {
    const tbody = document.getElementById("grid-body");
    const errorMessage = document.getElementById("errorMessage");
    tbody.innerHTML = "";
    errorMessage.textContent = "";
    try {
        const data = await buildHierarchy();
        data.forEach(level1 => {
        const row1 = createRow(level1);
        tbody.appendChild(row1);
        level1.children?.forEach(level2 => {
            const row2 = createRow(level2, level1.id);
            row2.style.display = "none";
            tbody.appendChild(row2);
            level2.children?.forEach(level3 => {
            const row3 = createRow(level3, level2.id);
            row3.style.display = "none";
            tbody.appendChild(row3);
            });
        });
        });
    } catch (e) {
        errorMessage.textContent = "Error loading data: " + e.message;
    }
}
