﻿//Utility to call Experlogix DLL and update Configuration. Expecting Quote should already be in 
//quote.statecode = 0(Draft)
//quote.statuscode = 1(In Progress)


using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
using Experlogix.Core.Utility.Xml;
using Experlogix.Services.WebConfigurator.Contracts;
using WebConfigServiceDemoConsole;
using NIQ.Experlogix.LegacyAssetGeneration.Model;

namespace NIQ.Experlogix.LegacyAssetGeneration.Model
{
    internal class Program
    {


        private static string myORG;
        private static string myELORG;
        private static string uri;
        private static string crmURL;

        private static string clientId;
        private static string clientSecret;

        private static string connectionString;
        private static string sqldbTableName;
        private static string sqlRowLimit;
        private static string QuoteStatusToPickupForProcessingFromSQL;
        private static string ExperlogixFailedStatus;
        private static string ExperlogixSuccessStatus;
        private static string CountofParallelThread;

        private static Boolean onlyFetchConfigToParseAgain;

        static void Main()
        {
            // Config value initiation
            myORG = ConfigurationManager.AppSettings["CRMInstance"];
            myELORG = ConfigurationManager.AppSettings["ELInstance"];
            uri = $"https://{myELORG}.experlogixonline.com/experlogix/services/WebConfigStatelessOperations.svc";
            clientId = ConfigurationManager.AppSettings["clientId"];
            clientSecret = ConfigurationManager.AppSettings["clientSecret"];
            crmURL = @"https://" + myORG + ".crm4.dynamics.com/";
            connectionString = $"Server={ConfigurationManager.AppSettings["SQLDBServerName"]};Database={ConfigurationManager.AppSettings["SQLDBName"]};User Id={ConfigurationManager.AppSettings["SQLUserName"]};Password={ConfigurationManager.AppSettings["SQLPassword"]};";
            QuoteStatusToPickupForProcessingFromSQL = ConfigurationManager.AppSettings["QuoteStatusToPickupForProcessingFromSQL"];
            sqldbTableName = ConfigurationManager.AppSettings["SQLDBTableName"];
            sqlRowLimit = ConfigurationManager.AppSettings["SQLRowLimit"];
            ExperlogixFailedStatus = ConfigurationManager.AppSettings["ExperlogixFailedStatus"];
            ExperlogixSuccessStatus = ConfigurationManager.AppSettings["ExperlogixSuccessStatus"];
            CountofParallelThread = ConfigurationManager.AppSettings["CountofParallelThread"];
            onlyFetchConfigToParseAgain = bool.Parse(ConfigurationManager.AppSettings["OnlyFetchConfigToParseAgain"]);

            List<SQLQuoteDetail> quoteList = new List<SQLQuoteDetail>();
         
            Console.WriteLine($"Running utility with onlyFetchConfigToParseAgain:- {onlyFetchConfigToParseAgain}");
            try
            {
                Console.WriteLine($"Connected to CRM Instance {myORG}");

                //quoteList.Add(new SQLQuoteDetail { QuoteID = "08a4dc42-70c4-f011-bbd3-7c1e525e830b" });
                //quoteList.Add(new SQLQuoteDetail { QuoteID = "dfa183df-qf22-ef43-943a-000d3ab5141d" });

                //Read QuoteList from SQL database to be processed
                Console.WriteLine($"Reading Quote List from DB with Row Limit: {sqlRowLimit}");
                quoteList = FetchQuoteListFromSQL();
                Console.WriteLine("Quote List fetched from DB");

                ParallelOptions parallelOptions = new ParallelOptions
                {
                    MaxDegreeOfParallelism = int.Parse(CountofParallelThread) // Number of threads
                };

                Console.WriteLine("Creating OAuth Token");
                OAuth2Helper oAuth2Helper = new OAuth2Helper();
                var token = oAuth2Helper.GetBearerToken(crmURL, clientId, clientSecret);
                Console.WriteLine("OAuth Token Obtained");


                // Making Experlogix DLL call to update configiguration
                Console.WriteLine($"Calling Experlogix WCS DLL with parallel thread {CountofParallelThread}");

                
                Parallel.ForEach(quoteList, parallelOptions, quoteDetail =>
                {
                    TriggerExperlogix(quoteDetail,token, onlyFetchConfigToParseAgain);

                });


                Console.WriteLine("Utility operation completed");
                Console.ReadKey();
                Console.WriteLine();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }


        
        private static List<SQLQuoteDetail> FetchQuoteListFromSQL()
        /// <summary>
        /// Read all quote from [dbo].MSD_MainQuote WHERE ProcessStage='ReOpened'
        /// </summary>
        /// <returns>List of SQLQuoteDetail</returns>
        {
            List<SQLQuoteDetail> QuoteList = new List<SQLQuoteDetail>();
            SQLQuoteDetail quoteDetail;
            try
            {
                string query = $"SELECT top {sqlRowLimit} quoteid, ProcessStage FROM [dbo].{sqldbTableName} WHERE ProcessStage='{QuoteStatusToPickupForProcessingFromSQL}' order by CreatedOn";
                //string query = $"SELECT top {sqlRowLimit} quoteid, ProcessStage FROM[dbo].MSD_MainQuote WHERE quoteid = 'c1a186df-4722-ef11-840a-000d3ab5161f'";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);

                    try
                    {

                        connection.Open();

                        SqlDataReader reader = command.ExecuteReader();

                        while (reader.Read())
                        {
                            quoteDetail = new SQLQuoteDetail();
                            quoteDetail.QuoteID = reader[0].ToString();
                            quoteDetail.ProcessStage = reader[1].ToString();
                            QuoteList.Add(quoteDetail);
                        }

                        reader.Close();
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine("FetchQuoteListFromSQL->SQLReader: Error: " + Environment.NewLine + ex.Message);
                        throw ex;
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("FetchQuoteListFromSQL-> Error: " + Environment.NewLine + ex.Message);
                throw ex;
            }
            return QuoteList;

        }
        

        private static void UpdateQuoteStatusinSQL(SQLQuoteDetail quoteDetail)
        /// <summary>
        /// Update Quote ProcessStage and ProcessLog back to SQL [dbo].MSD_MainQuote for all quotes passed in
        /// </summary>
        /// <param name="quoteDetail"></param>
        {
            try
            {

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string updateQuery = $"Update [dbo].{sqldbTableName} SET ProcessStage = @ProcessStage, ProcessLog = @ProcessLog where quoteid = @Id";
                    try
                    {
                        using (SqlCommand command = new SqlCommand(updateQuery, connection))
                        {
                            command.Parameters.AddWithValue("@ProcessStage", (string.IsNullOrEmpty(quoteDetail.ProcessStage) ? string.Empty : quoteDetail.ProcessStage));
                            command.Parameters.AddWithValue("@ProcessLog", (string.IsNullOrEmpty(quoteDetail.ProcessLog) ? string.Empty : quoteDetail.ProcessLog));
                            command.Parameters.AddWithValue("@Id", (string.IsNullOrEmpty(quoteDetail.QuoteID) ? string.Empty : quoteDetail.QuoteID));

                            command.ExecuteNonQuery();
                        }
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine("UpdateQuoteStatusinSQL Error: " + Environment.NewLine + ex.Message); 
                        Console.WriteLine("ProcessStage: " + Environment.NewLine + quoteDetail.ProcessStage);
                        Console.WriteLine("ProcessLog: " + Environment.NewLine + quoteDetail.ProcessLog);
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

    
        
        private static void UpsertParsedXML(List<SQLParsedXMLContent> parsedXMLContent)
        {
        /*<summary>
        Update Quote ProcessStage and ProcessLog back to SQL [dbo].MSD_MainQuote for all quotes passed in
        </summary>
        <param name="quoteDetailList"></param>
        */
            try
            {


                Console.WriteLine("Saving Asset Metadata in DB");
                foreach (var record in parsedXMLContent)
                {
                    //string updateQuery = $"INSERT INTO MSD_Main_ParsedELConfig (Quoteid,niq_elassetid) Values (@Qouteid, @ELAssetID)";
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {

                            using (SqlCommand cmd = new SqlCommand("Upsert_MSD_MainQuote_ParsedELConfig", connection))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;

                                cmd.Parameters.AddWithValue("@QuoteId", record.QuoteID ?? (object)DBNull.Value);
                                cmd.Parameters.AddWithValue("@RuntimeId", record.RuntimeId ?? (object)DBNull.Value);
                                cmd.Parameters.AddWithValue("@RecordId", record.RecordId ?? (object)DBNull.Value);
                                cmd.Parameters.AddWithValue("@Description", record.Description ?? (object)DBNull.Value);
                                cmd.Parameters.AddWithValue("@DBName", record.DBName ?? (object)DBNull.Value);
                                cmd.Parameters.AddWithValue("@ProductNumber", record.ProductNumber ?? (object)DBNull.Value);
                                cmd.Parameters.AddWithValue("@ContractProductName", record.ContractProductName ?? (object)DBNull.Value);
                                cmd.Parameters.AddWithValue("@ELAssetId", record.ELAssetID ?? (object)DBNull.Value);
                                cmd.Parameters.AddWithValue("@AssetPrimaryKey", record.AssetPrimaryKey ?? (object)DBNull.Value);
                                cmd.Parameters.AddWithValue("@RateCardId", record.RateCardId ?? (object)DBNull.Value);
                                cmd.Parameters.AddWithValue("@ProductDescription", record.ProductDescription ?? (object)DBNull.Value);
                                cmd.Parameters.AddWithValue("@IsDraft", record.IsDraft ?? (object)DBNull.Value);
                                cmd.Parameters.AddWithValue("@LineItemId", record.LineItemId ?? (object)DBNull.Value); 
                                connection.Open();
                                cmd.ExecuteNonQuery();
                                connection.Close();
                            }
                        }
                    }catch (SqlException ex)
                    {
                        Console.WriteLine("QuoteID: " + Environment.NewLine + record.QuoteID);
                        Console.WriteLine("UpdateParsedXMLinSQL Error: " + Environment.NewLine + ex.Message);
                        throw ex;
                    }
                }

                Console.WriteLine("Successfully Saved Asset Metadata in DB");

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw ex;
            }
        }

   
        private static void TriggerExperlogix(SQLQuoteDetail quoteDetail, string token, Boolean onlyFetchConfigToParseAgain)
        {
            try
            {
                Stopwatch ticker = new Stopwatch();
                ticker.Start();
                Console.WriteLine("Processing QuoteID: " + quoteDetail.QuoteID);

               // OAuth2Helper oAuth2Helper = new OAuth2Helper();
               // var token = oAuth2Helper.GetBearerToken(crmURL, clientId, clientSecret);

                LoadConfigurationAsync(token, quoteDetail.QuoteID, ref quoteDetail, onlyFetchConfigToParseAgain);
                ticker.Stop();

                quoteDetail.ProcessStage = ExperlogixSuccessStatus;
                quoteDetail.ProcessLog = "EL Cofig updated in " + ticker.Elapsed.TotalSeconds + "second(s)";
                Console.WriteLine("Processed QuoteID: " + quoteDetail.QuoteID + " in " + ticker.Elapsed.TotalSeconds + "second(s)");

            }
            catch (Exception ex)
            {
                quoteDetail.ProcessStage = ExperlogixFailedStatus;
                quoteDetail.ProcessLog += Environment.NewLine + "Failed to update configuration from TriggerExperlogix for Quote ID: " + quoteDetail.QuoteID + Environment.NewLine + ex.Message + Environment.NewLine + ex.StackTrace;
                Console.WriteLine("Update configuration failed for QuoteID: " + quoteDetail.QuoteID);
            }
            finally
            {
               UpdateQuoteStatusinSQL(quoteDetail);
            }
        }


        private static void LoadConfigurationAsync(string token, string quoteId, ref SQLQuoteDetail quoteDetail, Boolean onlyFetchToParseAgain)
        {
            try
            {
                MSCrmClientConnectInfo connectInfo = new MSCrmClientConnectInfo()
                {
                    OAuthToken = token,
                    CrmOrganizationName = myORG
                };

                var client = WebConfigOperationSvcClient.Create(new Uri(uri));


                //Specifies the specific entity type and entity in CRM that you want to add or load configurations from.
                ConfigHeader header = new ConfigHeader("quote", $"{quoteId}");

                //The following method called will load the specified configuration in the web config service's memory.
                //Saving the result of loading the configuration is helpful if you want to make sure the load was successful.

                if (!onlyFetchToParseAgain)
                {
                    Console.WriteLine("Fetching Config to update and save in Draft mode");
                    ConfigurationMetadata loadResult = client.GetMetadata(connectInfo, header);

                    XDocument masterConfig = XDocument.Parse(loadResult.ConfigurationXml);

                    List<XElement> lineItems = masterConfig.Root.Elements("lineitem").ToList();

                    foreach (XElement lineitem in lineItems)
                    {
                        UpdateConfigParameters updateConfigParameters = new UpdateConfigParameters()
                        {
                            AutoUpdateConfiguration = AutoUpdateConfigurationType.All,
                            //Changes = new ConfigChange[0],
                            Changes = new ConfigChange[] { new SetSettingChange() { Setting = ConfigSettingId.DraftMode, Value = false } }, /* Config changes in draft mode */
                            Header = header,
                            OperationBehaviors = new OperationBehaviors() { AutoSaveConfiguration = true },
                            IndividualizeChanges = true
                        };

                        int.TryParse(lineitem.Attribute("id")?.Value, out int lineItemId);

                        try
                        {
                            client.UpdateConfiguration(connectInfo, updateConfigParameters, lineItemId);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Config update in draft mode failed: {ex.Message}");
                            throw ex;
                        }
                    }

                    Console.WriteLine("Config successfully saved in Draft mode");
                }

                List<SQLParsedXMLContent> parsedXMLContent = new List<SQLParsedXMLContent>();

                Console.WriteLine("Fetching Draft Config to Parse Asset Metadata");
                ConfigurationMetadata draftMetadata = client.GetMetadata(connectInfo, header);

                XDocument masterConfigPost = XDocument.Parse(draftMetadata.ConfigurationXml);

                 //Console.WriteLine(masterConfigPost.ToString());
                //Create a set of properties with a certain ID and pull their values
                var matchesFromAllProductSummary = masterConfigPost
                    .Descendants("category").Where(x => (string)x.Attribute("id") == "AllProductSummary" || (string)x.Attribute("id") == "AllProductSummaryRC")
                    .Descendants("option");

                string[] propertyIdsToMatch = { "DBName", "CRM_ProductNum", "ContractProductName", "AssetGUID", "AssetPrimaryKey", "Asset_JSON", "RateCardID", "IsDraft", "LineItemId" };

                foreach (var item in matchesFromAllProductSummary)
                {

                    var properties = item.Descendants("property")
                        .Where(x => propertyIdsToMatch.Contains((string)x.Attribute("id")))
                            .ToDictionary(
                                    p => p.Attribute("id")?.Value,
                                    p => p.Value
                        );

                    //set if config is in draft mode
                    properties["IsDraft"] = item.Parent.Parent.GetAttrValue("isdraft","0");
                    properties["LineItemId"] = item.Parent.Parent.GetAttrValue("id", "-1");

                    foreach (var key in propertyIdsToMatch)
                    {
                        if (!properties.ContainsKey(key))
                        {
                            properties[key] = null;
                        }
                    }

                    
                    SQLParsedXMLContent record = new SQLParsedXMLContent
                    {
                        QuoteID = quoteDetail.QuoteID,
                        RuntimeId = item.Attribute("runtimeId").Value,
                        RecordId = item.Attribute("rid").Value,
                        Description = item.Descendants("description").FirstOrDefault().Value,
                        DBName = properties["DBName"],
                        ProductNumber = properties["CRM_ProductNum"],
                        ContractProductName = properties["ContractProductName"],
                        ELAssetID = properties["AssetGUID"],
                        AssetPrimaryKey = properties["AssetPrimaryKey"],
                        RateCardId = properties["RateCardID"],
                        ProductDescription = properties["Asset_JSON"],
                        IsDraft = properties["IsDraft"],
                        LineItemId = properties["LineItemId"]

                    };

                    parsedXMLContent.Add(record);

                }

                Console.WriteLine("Successfully Parsed Asset Metadata");
                

               UpsertParsedXML(parsedXMLContent);

            }
            catch (Exception ex)
            {
                quoteDetail.ProcessStage = "ELConfigUpdateFailed";
                quoteDetail.ProcessLog += Environment.NewLine + "LoadConfigurationAsync failed for Quote: " + quoteDetail.QuoteID;
                Console.WriteLine($"LoadConfigurationAsync failed for Quote: {ex.Message}");
                throw ex;
            }
        }

     

    }
}
