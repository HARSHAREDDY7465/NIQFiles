
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

public static class EntityToJsonConverter
{
    public static string ConvertToWebApiJson(Entity entity)
    {
        var dict = new Dictionary<string, object>();

        foreach (var attr in entity.Attributes)
        {
            switch (attr.Value)
            {
                case EntityReference er:
                    // Format: <navigation_property>@odata.bind
                    dict[$"{attr.Key}@odata.bind"] = $"/{er.LogicalName}s({er.Id})";
                    break;

                case OptionSetValue osv:
                    dict[attr.Key] = osv.Value;
                    break;

                case Money money:
                    dict[attr.Key] = money.Value;
                    break;

                case DateTime dt:
                    dict[attr.Key] = dt.ToString("o"); // ISO 8601 format
                    break;

                default:
                    dict[attr.Key] = attr.Value;
                    break;
            }
        }

        return JsonConvert.SerializeObject(dict, Formatting.Indented);
    }
}
