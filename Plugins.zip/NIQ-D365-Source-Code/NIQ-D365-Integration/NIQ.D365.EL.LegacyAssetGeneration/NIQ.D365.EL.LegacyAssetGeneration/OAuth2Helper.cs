﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System;
using Newtonsoft.Json;

namespace WebConfigServiceDemoConsole
{
    public class OAuth2Helper
    {
        public async Task<string> GetBearerTokenAsync(string crmURL, string clientId, string clientSecret)
        {
            using (var httpClient = new HttpClient())
            {
                var tokenRequest = new HttpRequestMessage(HttpMethod.Post, "https://login.microsoftonline.com/6ac7a1f4-5fb1-4153-bb4f-12d2020a1f7d/oauth2/token");

                var requestBody = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("grant_type", "client_credentials"),
                    new KeyValuePair<string, string>("client_id", clientId),
                    new KeyValuePair<string, string>("client_secret", clientSecret),
                    new KeyValuePair<string, string>("resource", crmURL)
                });
                tokenRequest.Content = requestBody;

                var tokenResponse = await httpClient.SendAsync(tokenRequest);

                if (tokenResponse.IsSuccessStatusCode)
                {

                    var responseContent = await tokenResponse.Content.ReadAsStringAsync();
                    dynamic responseData = JsonConvert.DeserializeObject(responseContent);
                    return responseData.access_token;
                }
                else
                {
                    Console.WriteLine($"Failed to obtain token. Status code: {tokenResponse.StatusCode}");
                    return null;
                }
            }
        }


        public string GetBearerToken(string crmURL, string clientId, string clientSecret)
        {
            try
            {
                using (var httpClient = new HttpClient())
                {
                    var tokenRequest = new HttpRequestMessage(HttpMethod.Post, "https://login.microsoftonline.com/6ac7a1f4-5fb1-4153-bb4f-12d2020a1f7d/oauth2/token");

                    var requestBody = new FormUrlEncodedContent(new[]
                    {
                     new KeyValuePair<string, string>("grant_type", "client_credentials"),
                     new KeyValuePair<string, string>("client_id", clientId),
                     new KeyValuePair<string, string>("client_secret", clientSecret),
                     new KeyValuePair<string, string>("resource", crmURL)
                     });
                    tokenRequest.Content = requestBody;

                    var tokenResponse = httpClient.SendAsync(tokenRequest).Result;

                    if (tokenResponse.IsSuccessStatusCode)
                    {
                        var responseContent = tokenResponse.Content.ReadAsStringAsync().Result;
                        dynamic responseData = JsonConvert.DeserializeObject(responseContent);
                        return responseData.access_token;
                    }
                    else
                    {
                        Console.WriteLine($"Failed to obtain token. Status code: {tokenResponse.StatusCode}");
                        return null;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception occurred: {ex.Message}");
                return null;
            }
        }

    }
}
