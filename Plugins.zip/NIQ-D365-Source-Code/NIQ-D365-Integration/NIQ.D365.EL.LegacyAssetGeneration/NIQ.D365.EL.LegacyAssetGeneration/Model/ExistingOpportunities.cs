﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NIQ.Experlogix.LegacyAssetGeneration.Model
{
    public class SQLQuoteDetail
    {
        public string QuoteID { get; set; }
        public string ProcessStage { get; set; }
        public string ProcessLog { get; set; }
    }
    public class SQLParsedXMLContent
    {
        public string QuoteID { get; set; }
        public string DBName { get; set; }
        public string ELAssetID { get; set; }
        public string RateCardId { get; set; }
        public string ProductDescription { get; set; }
        public string RecordId { get; set; }
        public string ProductNumber { get; set; }
        public string ContractProductName { get; set; }
        public string Description { get; set; }

        public string AssetPrimaryKey { get; set; }

        public string RuntimeId { get; set; }
        public string IsDraft { get;  set; }

        public string LineItemId { get; set; }
        
    }
}
