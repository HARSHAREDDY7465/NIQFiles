﻿using Azure.Security.KeyVault.Secrets;
using Microsoft.Data.SqlClient;
using NIQ.D365.EL.GFKDataMigration.Builder;
using NIQ.D365.EL.GFKDataMigration.ELWebServiceReference;
using NIQ.D365.EL.GFKDataMigration.Helper;
using NIQ.D365.EL.GFKDataMigration.Model;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.ServiceModel;
using System.Text;
using System.Xml;

namespace NIQ.D365.EL.GFKDataMigration {
   internal class GFKDataMigration
   {

      private static string? d365OrgName;
      private static string? crmURL;
      private static string? elURL;
      private static string? kvUrl;
      private static string? elWebserviceUri;

      private static string? clientId;
      private static string? clientSecret;
      private static string? dbServerName;
      private static string? dbName;
      private static string? dbUserName;
      private static string? dbPassword;
      private static string? connectionString;
      private static string? dbTableName;
      private static string? dbLogTableName;
      private static string? maxConnectionPoolLimit;
      private static string? token;

      private static string? processingBatchName;
      private static string? processingBatchSize;
      private static string? countofParallelThread;


      public static void Main(string[] args)
      {

            if (args.Length != 1 || (args[0] != "MPE" && args[0] != "RC")) {
                Console.WriteLine("Invalid argument. Please provide argument value for configuration Type (MPE or RC)");
                Console.WriteLine("Usage: NIQ.D365.EL.GFKDataMigration [ConfigurationType [MPE OR RC]]");
                return;
            }

            Stopwatch ticker = new();
            ticker.Start();

            // Config value initiation
            try
            {
                d365OrgName = ConfigurationDataReader.GetRequiredConfig("D365OrgName","string");
                crmURL = ConfigurationDataReader.GetRequiredConfig("D365Url", "url");
                elURL = ConfigurationDataReader.GetRequiredConfig("ELUrl", "url");
                kvUrl = ConfigurationDataReader.GetRequiredConfig("KVUrl", "url");

                clientId = ConfigurationDataReader.GetRequiredConfig("clientId", "string");

                dbServerName = ConfigurationDataReader.GetRequiredConfig("DBServerName", "string");
                dbName = ConfigurationDataReader.GetRequiredConfig("DBName", "string");
                dbUserName = ConfigurationDataReader.GetRequiredConfig("DBUserName", "string");
                dbTableName = ConfigurationDataReader.GetRequiredConfig("DBTableName", "string");
                dbLogTableName = ConfigurationDataReader.GetRequiredConfig("DBLogTableName", "string");
                maxConnectionPoolLimit = ConfigurationDataReader.GetRequiredConfig("MaxConnectionPoolLimit", "string");

                processingBatchName = ConfigurationDataReader.GetRequiredConfig("ProcessingBatchName", "string");
                processingBatchSize = ConfigurationDataReader.GetRequiredConfig("ProcessingBatchSize", "string");
                countofParallelThread = ConfigurationDataReader.GetRequiredConfig("CountofParallelThread", "string");

            }
            catch(InvalidOperationException ie)
            {
                Console.WriteLine(ie.Message);
                Console.WriteLine("Please make sure all configuration parameter values are provided.");
                return;
            }
            catch (ConfigurationErrorsException ex)
            {
                Console.WriteLine($"Error in config file: {ex.Filename}, Line: {ex.Line}. Please check if config file has valid XML content.");
                Console.WriteLine($"Exiting... ");
                return;
            }

            Console.WriteLine($"Processing utility on Environment: {crmURL}, ConfigType: {args[0]}, BatchName: {processingBatchName}, BatchSize:{processingBatchSize}, DatabaseName: {dbName}");

            try
            {
                Console.WriteLine("Connecting to Azure Key Vault to retrieve secrets and passwords. A browser window may open for authentication."); 
                var credential = AzureCredentialHelper.getSecret(kvUrl);
                var client = new SecretClient(new Uri(kvUrl), credential);
                // Get  secret
                KeyVaultSecret secret = client.GetSecret(clientId);
                clientSecret = secret.Value;

                KeyVaultSecret kvDBpassword = client.GetSecret(dbUserName);
                dbPassword = kvDBpassword.Value;

                Console.WriteLine($"Secret and DB Password fetched from keyvault.");
                //Console.WriteLine($"Secret Value: {clientSecret}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unable to read secret from Azure Keyvault. Exception {ex.Message}");
                Console.WriteLine($"Exiting... ");
                return;
            }


            elWebserviceUri = $"{elURL}experlogix/services/WebConfigStatelessOperations.svc";

            connectionString = $"Server={dbServerName};Database={dbName};User Id={dbUserName};Password={dbPassword};Pooling=true;Min Pool Size=5;Max Pool Size={maxConnectionPoolLimit};";
  
            ParallelOptions parallelOptions = new()
            {
               MaxDegreeOfParallelism = int.Parse(countofParallelThread) // Number of threads
            };

            List<SQLQuoteDetail> quoteList;

            
            try
            {
               
               //Read QuoteList from SQL database to be processed
               Console.WriteLine("Reading Quote List from Staging Database.");
               //uncomment following for testing using a single record
               //quoteList = new List<SQLQuoteDetail>{new SQLQuoteDetail(){ QuoteID = "29F1FC4B-C9AA-4E15-B218-975BEF146F81" } };
               quoteList = FetchQuoteListFromSQL(args[0]);

               if ( quoteList.Count > 0 ) {
                  Console.WriteLine($"Total count of Quote fetched {quoteList.Count}");
                  Console.WriteLine("Generating OAuth token");
                  token = AuthenticatorHelper.GetBearerToken(crmURL, clientId, clientSecret);

                  if (string.IsNullOrWhiteSpace(token))
                  {
                     throw new Exception($"Failed to retrieve bearer token for CRM URL: {crmURL}");
                  }

                  Console.WriteLine("OAuth Token Obtained");

                  Parallel.ForEach(quoteList, parallelOptions, quoteDetail => {
                     ProcessQuote(quoteDetail, token, args[0],connectionString,dbTableName);

                  });
               }else{
                  Console.WriteLine("0 records found in the input data table/view. Nothing to process.");
               }

            }
            catch ( Exception ex ) {
               Console.WriteLine(ex.Message);
               Console.WriteLine(ex.StackTrace);
            }

            Console.WriteLine(Environment.NewLine);
            ticker.Stop();
            Console.WriteLine($"Utility execution time: {ticker.Elapsed.TotalMinutes} Minutes.");
         
         return;
      }
     
      private static void ProcessQuote(SQLQuoteDetail quoteDetail, string token, string configType, string connectionString, string dbTableName) {
         try 
         {
            
            Stopwatch qticker = new();
            qticker.Start();
            Console.WriteLine($"Processing Quote: {quoteDetail.QuoteID}");
            var configXml = "";

            List<UtilityInputData> records = OptionListBuilder.GetUtilityInputData(quoteDetail.QuoteID, connectionString, dbTableName);
            var validGuid = OptionListBuilder.ValidQuoteGuid;
            if (!validGuid)
            {       quoteDetail.Status = "Failed";
                    quoteDetail.Message = "Invalid Guid or no records found, no WCS call done";
                    Console.WriteLine("No WCS Call Made, Guid entered was not valid.");
                    return;
            }


            var optionListTopLevel = OptionListBuilder.CreateOptionListForQuoteId_SelectProducts(records);
            var optionStringTopLevel = XmlBuilderUtility.CreateOptionXml_SelectProducts(optionListTopLevel);

            if ( configType == "MPE" ) {
               configXml = ConfigModel.configXmlBoilerplate.Replace("<!--Insert Here-->", optionStringTopLevel);
            }
            else {

               var optionListChildLevel = OptionListBuilder.CreateOptionListForQuoteId_ChildConfig(records);
               var optionStringChildLevel = XmlBuilderUtility.CreateOptionXml_ChildConfig(optionListChildLevel);

               var childConfigXml = ConfigModel.configXmlBoilerplateChildConfig.Replace("<!--Insert Child Options Here-->", optionStringChildLevel);
               var configXmlRateCard = ConfigModel.configXmlBoilerplateTopLevel.Replace("<!--Insert Rate Card Cat Here-->", ConfigModel.configXmlBoilerplateRateCard);
               var configXmlTopLevel = configXmlRateCard.Replace("<!--Insert Here-->", optionStringTopLevel);

               configXml = configXmlTopLevel.Replace("<!--Insert Child Config XML Here-->", childConfigXml);
            }

            //Console.WriteLine(configXml);

            quoteDetail.ConfigXML = configXml;
            quoteDetail.ConfigType = configType;

            XmlDocument configXmlDocument = new();
            configXmlDocument.LoadXml(configXml);

            var rootConfigLines = Utilities.GetXMLNodeList(configXmlDocument, "//mpcconfiguration/lineitem") ?? throw new InvalidOperationException($"Invalid configuration xml.");
            var connectInfo = new MSCrmClientConnectInfo() { OAuthToken = token, CrmOrganizationName = d365OrgName };
            var statelessClient = new WebConfigStatelessOperationsClient(BindingHelper.GetBasicHttpBinding(), new EndpointAddress(elWebserviceUri));

            foreach ( XmlNode rootConfigLine in rootConfigLines ) {

                var xmlConfigParams = new NewXmlConfigParameters(){
                      //This was hard coded for the sake of testing. Dynamic variable will be used.
                      //Header = new ConfigHeader() { Id = "370754b2-fc8c-4c64-a1e8-cfe51d45d9c2", Type = "quote" },
                      Header = new ConfigHeader() { Id = quoteDetail.QuoteID, Type = "quote" },
                      OperationBehaviors = new OperationBehaviors() { AutoSaveConfiguration = true },
                      AutoUpdateConfiguration = AutoUpdateConfigurationType.All,
                      LineItemXml = rootConfigLine.OuterXml
                };

                try {
                     var configResult = statelessClient.CreateConfigurationFromXmlAsync(connectInfo, xmlConfigParams).Result;

                     qticker.Stop();
                     if ( configResult.ResultCode == ConfigurationResultCode.Success ) {
                        Console.WriteLine($"Quote: {quoteDetail.QuoteID} processed successfully in {qticker.Elapsed.TotalSeconds} second(s)");
                        quoteDetail.Status = "Success";
                        quoteDetail.Message = $"Processed successfully in {qticker.Elapsed.TotalSeconds} second(s)";
                     }
                     else {
                        StringBuilder sb = new();
                        if ( configResult.ResultMessages.Length != 0 ) {
                           foreach ( var result in configResult.ResultMessages ) {
                              Console.WriteLine($"Quote: {quoteDetail.QuoteID}. Error Message: {result.Message}");
                              sb.AppendLine(result.Message);
                           }
                        }
                        Console.WriteLine($"Quote: {quoteDetail.QuoteID} processing was Unsuccessful. Processing time: {qticker.Elapsed.TotalSeconds} second(s)");
                        
                        quoteDetail.Status = "Failed";
                        quoteDetail.Message = $"Failed with error: {sb}. Processing time: {qticker.Elapsed.TotalSeconds} second(s).";
                        
                     }
                }
                catch ( Exception e ) {
                     Console.WriteLine(e);
                     throw;
                }
            }
            

         }
         catch ( Exception ex ) {
            quoteDetail.Status = "Failed";
            quoteDetail.Message += ". Failed to create configuration from ProcessQuote for Quote ID: " + quoteDetail.QuoteID + ". Exception message: " + ex.Message + ". " + ex.StackTrace;
            Console.WriteLine("create configuration failed for QuoteID: " + quoteDetail.QuoteID);
            Console.WriteLine(ex.Message + ex.StackTrace);
         }
         finally {
            UpdateQuoteListStatusinSQL(quoteDetail);
         }
      }

      /// <summary>
      /// </summary>
      /// <returns>List of SQLQuoteDetail</returns>
      private static List<SQLQuoteDetail> FetchQuoteListFromSQL(string configType) {
         List<SQLQuoteDetail> QuoteList = [];
         SQLQuoteDetail quoteDetail;
         try {
                /*string query = $@"SELECT distinct top {processingBatchSize} quoteid
                               FROM [dbo].[{dbTableName}]
                               where ELUtilityBatch = '{processingBatchName}'
                                  AND ELConfigType='{configType}'
                                  AND QuoteLoaded='Y' 
                                  AND isNULL(QPLoaded,'N') != 'Y'";
                */
                if (!ConfigurationDataReader.IsSafeIdentifier(dbTableName))
                {
                    throw new InvalidOperationException($"Unsafe table name: {dbTableName}");

                }
                var sql = $@"SELECT DISTINCT TOP (@top) quoteid 
                            FROM [dbo].[{dbTableName}] 
                            WHERE ELUtilityBatch = @batch
                                AND ELConfigType   = @config
                                AND QuoteLoaded    = 'Y'
                                AND ISNULL(QPLoaded, 'N') <> 'Y';";

                using SqlConnection connection = new(connectionString);
                SqlCommand cmd = new(sql, connection)
                {
                    CommandTimeout = 300
                };
                cmd.Parameters.Add("@top", SqlDbType.Int).Value = processingBatchSize;
                cmd.Parameters.Add("@batch", SqlDbType.NVarChar, 100).Value = processingBatchName;
                cmd.Parameters.Add("@config", SqlDbType.NVarChar, 50).Value = configType;

                try
                {
                    connection.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        if (!reader.IsDBNull(0))
                        {
                            quoteDetail = new()
                            {
                                QuoteID = reader.GetGuid(0).ToString() // Directly read as Guid
                            };
                            QuoteList.Add(quoteDetail);
                        }
                    }
                    reader.Close();
                }
                catch (SqlException ex)
                {
                    Console.WriteLine("FetchQuoteListFromSQL->SQLReader: Error: " + ex.Message);
                    throw;
                }
         }
         catch ( Exception ex ) {
            Console.WriteLine("FetchQuoteListFromSQL-> Error: " + ex.Message);
            throw;
         }
         return QuoteList;
      }


      /// <summary>
      /// Update Quote process updates to SQL quotes passed processed
      /// </summary>
      /// <param name="quoteDetail"></param>
      private static void UpdateQuoteListStatusinSQL(SQLQuoteDetail quote) {
         try {

                using SqlConnection connection = new(connectionString);
                connection.Open();

                string upsertQuery = $@"MERGE INTO {dbLogTableName} AS target 
                    USING (VALUES (@quoteid, @Status, @Message, @ConfigXML, @ConfigType)) AS source (quoteid, Status, Message, ConfigXML, ConfigType)
                    ON target.quoteid = source.quoteid
                    WHEN MATCHED THEN
                    UPDATE SET 
                         Status = source.Status,
                         Message = source.Message,
                         ConfigXML = source.ConfigXML,
                         ConfigType = source.ConfigType,
                         LastExecutionTime = CURRENT_TIMESTAMP 
                    WHEN NOT MATCHED THEN
                        INSERT (quoteid, Status, Message, ConfigXML, ConfigType, LastExecutionTime )
                        VALUES (source.quoteid, source.Status, source.Message, source.ConfigXML, source.ConfigType, CURRENT_TIMESTAMP);";
                try
                {
                    using SqlCommand command = new(upsertQuery, connection);
                    command.Parameters.AddWithValue("@quoteid", (string.IsNullOrEmpty(quote.QuoteID) ? string.Empty : quote.QuoteID));
                    command.Parameters.AddWithValue("@Status", (string.IsNullOrEmpty(quote.Status) ? string.Empty : quote.Status));
                    command.Parameters.AddWithValue("@Message", (string.IsNullOrEmpty(quote.Message) ? string.Empty : quote.Message));
                    command.Parameters.AddWithValue("@ConfigXML", (string.IsNullOrEmpty(quote.ConfigXML) ? string.Empty : quote.ConfigXML));
                    command.Parameters.AddWithValue("@ConfigType", (string.IsNullOrEmpty(quote.ConfigType) ? string.Empty : quote.ConfigType));

                    command.ExecuteNonQuery();
                }
                catch (SqlException ex)
                {
                    Console.WriteLine($"Failed to log Quote Stauts. Exception details: {ex.Message}");
                    Console.WriteLine($"Quote ID: {quote.QuoteID}");
                    Console.WriteLine($"Quote Status: {quote.Status}");
                    Console.WriteLine($"Status Message: {quote.Message}");
                    Console.WriteLine($"ConfigXML: {quote.ConfigXML}");
                }
                finally
                {
                    connection.Close();
                }

            }
         catch ( Exception ex ) {
            Console.WriteLine(ex.Message);
         }
      }
   }
}


