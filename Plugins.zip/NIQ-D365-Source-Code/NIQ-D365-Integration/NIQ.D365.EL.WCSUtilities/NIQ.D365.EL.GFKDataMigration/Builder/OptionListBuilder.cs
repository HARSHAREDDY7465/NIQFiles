﻿using Microsoft.Data.SqlClient;
using NIQ.D365.EL.GFKDataMigration.Helper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Reflection.PortableExecutable;
using Microsoft.IdentityModel.Tokens;
using NIQ.D365.EL.GFKDataMigration.Model;

namespace NIQ.D365.EL.GFKDataMigration.Builder
{
    internal static class OptionListBuilder
    {

        internal static bool ValidQuoteGuid { get; set; }

        internal static List<Option> CreateOptionListForQuoteId_ChildConfig(List<UtilityInputData> results)
        {

            var optionList = new List<Option>();
            var distinctResults = results
               .Where(x => x.ProductNumber == "MI PANEL INDUSTRY")
                .GroupBy(x => new { x.Country, x.L7ProductName })
                .Select(g => g.First())
                .ToList();

            if (distinctResults.Count == 0)
            {
                Console.WriteLine($"No Quote Products with Product 'MI PANEL INDUSTRY' found for QuoteId {results[0].QuoteId} in SQL view for RC configuration.");
                return optionList;
            }

            foreach (var item in distinctResults)
            {
                
                 try
                    {
                    if (string.IsNullOrEmpty(item.Country) || string.IsNullOrEmpty(item.L7ProductName))
                    {
                        throw new InvalidDataException($"Invalid data found on attempt to create RC options for {item.QuoteId}");
                    }
                    var option = new Option()
                        {
                            id = "DataSet",
                            runtimeId = item.L7ProductName,
                            description = "DataSet",
                            quantity = 1,
                            properties = new List<Property>(){

                           new Property(){id = "Country", value = item.Country},
                           new Property(){id = "ProductGroup", value = item.L7ProductName},
                           new Property(){id = "CountryVariant", value = item.CountryVariant__c ?? ""},
                           new Property(){id = "Frequency_Edit", value = item.PanelType__c ?? "" }

                        }
                        };
                        optionList.Add(option);
                    }
                    catch
                    {
                        Console.WriteLine($"Invalid data found on attempt to create RC options for {item.QuoteId}");
                        throw;
                    }
                

            }

            return optionList;
        }

        internal static List<Option> CreateOptionListForQuoteId_SelectProducts(List<UtilityInputData> results)
        {

            var optionList = new List<Option>();

            foreach (var item in results)
            {

                try
                {
                    var option = new Option()
                    {
                        id = "ProductPickerProducts",
                        runtimeId = item.ProductNumber!,
                        description = item.ProductName!,
                        quantity = 1,
                        properties = new List<Property>(){

                           new Property(){id = "ListPrice", value = item.ExtendedAmount.ToString()},
                           new Property(){id = "Remarks", value = item.NiqRemark!},
                           new Property(){id = "PlaceholderStartDate", value = DateTime.SpecifyKind(item.Start_Date__c!.Value, DateTimeKind.Utc).ToString("yyyy-MM-ddTHH:mm:ssZ")},
                           new Property(){id = "PlaceholderEndDate", value = DateTime.SpecifyKind(item.End_Date__c!.Value, DateTimeKind.Utc).ToString("yyyy-MM-ddTHH:mm:ssZ")},
                           new Property(){id = "niq_externalid", value = item.NiqExternalId! }

                        }
                    };
                    optionList.Add(option);
                }
                catch
                {
                    Console.WriteLine($"Invalid data found on attempt to create MPE options for {item.QuoteId}");
                    throw;
                }

            }

            return optionList;
        }

        internal static UtilityInputData MapUtilityInputData(SqlDataReader r)
        {
            return new UtilityInputData
            {
                QuoteId = (Guid)UtilityInputDataReader.GetGuid(r, "quoteid")!,
                ExtendedAmount = (decimal)UtilityInputDataReader.GetDecimal(r, "extendedamount")!,
                NiqExternalId = UtilityInputDataReader.GetString(r, "niq_externalid"),
                NiqRemark = UtilityInputDataReader.GetString(r, "niq_remark"),
                ProductName = UtilityInputDataReader.GetString(r, "productname"),
                ProductNumber = UtilityInputDataReader.GetString(r, "productnumber"),
                L7ProductName = UtilityInputDataReader.GetString(r, "L7_ProductName"),
                Country = UtilityInputDataReader.GetString(r, "Country"),
                CountryVariant__c = UtilityInputDataReader.GetString(r, "CountryVariant__c"),
                PanelType__c = UtilityInputDataReader.GetString(r, "PanelType__c"),
                Start_Date__c = (DateTime)UtilityInputDataReader.GetDateTime(r, "Start_Date__c")!,
                End_Date__c = (DateTime)UtilityInputDataReader.GetDateTime(r, "End_Date__c")!,
            };
        }

        internal static List<UtilityInputData> GetUtilityInputData(string quoteId, string connectionString, string inputdatatablename)
        {

            if (string.IsNullOrWhiteSpace(connectionString))
            {
                throw new ArgumentNullException(nameof(connectionString), "Database connection string cannot be null or empty.");
            }

            if (!ConfigurationDataReader.IsSafeIdentifier(inputdatatablename)) { 
                throw new InvalidOperationException($"Unsafe table name: {inputdatatablename}");

            }

            string sql = $@"SELECT [quoteid],[extendedamount],[niq_externalid],[niq_remark],[productname],[productnumber],
                [L7_ProductName],[Country],[CountryVariant__c],[PanelType__c],[Start_Date__c],[End_Date__c],[FullRemarks] 
                FROM [dbo].[{inputdatatablename}]
                WHERE [QuoteId] = @quoteId;";

            var records = new List<UtilityInputData>();

            if (!Guid.TryParse(quoteId, out Guid quoteIdGuid))
            {
                ValidQuoteGuid = false;
                Console.WriteLine($"Entered Quote ID {quoteId} is not a valid guid.");
                return records; // early return; nothing to fetch
            }

            // Valid GUID
            ValidQuoteGuid = true;

            try
            {
                using (var conn = new SqlConnection(connectionString))
                using (var cmd = new SqlCommand(sql, conn))
                {
                    // Prefer explicit parameter type/size for plan stability
                    var p = cmd.Parameters.Add("@quoteId", SqlDbType.UniqueIdentifier);
                    p.Value = quoteIdGuid;

                    cmd.CommandTimeout = 300;

                    conn.Open(); // synchronous
                    using (var r = cmd.ExecuteReader(CommandBehavior.Default))
                    {
                        while (r.Read())
                        {
                            records.Add(MapUtilityInputData(r));
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine("GetUtilityInputData -> SqlException: " + ex.Message);
                throw; // rethrow to preserve stack trace
            }
            if (records.Count == 0)
            {
                Console.WriteLine($"No Quote Products found for QuoteId {quoteIdGuid} in SQL view.");
                ValidQuoteGuid = false;
            }
            return records;
        }

    }
}
