﻿using System.Configuration;

namespace NIQ.D365.EL.GFKDataMigration.Helper
{
    internal class ConfigurationDataReader
    {
        // Helper method
        internal static string GetRequiredConfig(string key, string valuetype)
        {
            var value = ConfigurationManager.AppSettings[key];
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new InvalidOperationException($"Missing or empty configuration value for key: {key}");
            }
            if (valuetype == "url")
            {
                if (!Uri.IsWellFormedUriString(value, UriKind.Absolute))
                    throw new InvalidOperationException($"Invalid URL format for {key} - {value}");

                if (!value.EndsWith('/'))
                    throw new InvalidOperationException($"URL must end with '/' for {key} - {value}");
            }

            return value;
        }


        internal static bool IsSafeIdentifier(string? identifier)
        {
            if (string.IsNullOrWhiteSpace(identifier)) return false;
            foreach (var c in identifier)
                if (!(char.IsLetterOrDigit(c) || c == '_')) return false;
            return true;
        }
    }

}
