﻿using Azure.Core;
using Azure.Identity;

namespace NIQ.D365.EL.GFKDataMigration.Helper
{
    internal class AzureCredentialHelper
    {
        public static TokenCredential getSecret(string kvUrl) {
            TokenCredential credential;
            try
            {
                // Use DefaultAzureCredential to pick up logged-in user credentials
                credential = new DefaultAzureCredential();
                // Test by requesting a token
                var aztoken = credential.GetToken(new TokenRequestContext(new[] { $"{kvUrl}.default" }), new CancellationToken());
            }
            catch
            {
                credential = new InteractiveBrowserCredential();
            }
            return credential;
        }
        
        
    }
 }
        
