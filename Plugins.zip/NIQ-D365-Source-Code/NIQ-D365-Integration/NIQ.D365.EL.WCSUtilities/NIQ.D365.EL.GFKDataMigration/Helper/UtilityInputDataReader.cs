﻿using Microsoft.Data.SqlClient;

namespace NIQ.D365.EL.GFKDataMigration.Helper
{
    public static class UtilityInputDataReader
    {
        public static Guid? GetGuid(SqlDataReader r, string name) =>
            r[name] == DBNull.Value ? (Guid?)null : (Guid)r[name];

        public static int? GetInt32(SqlDataReader r, string name) =>
            r[name] == DBNull.Value ? (int?)null : Convert.ToInt32(r[name]);

        public static decimal? GetDecimal(SqlDataReader r, string name) =>
            r[name] == DBNull.Value ? (decimal)0 : Convert.ToDecimal(r[name]);

        public static string? GetString(SqlDataReader r, string name) =>
            r[name] == DBNull.Value ? null : Convert.ToString(r[name]);

        public static DateTime? GetDateTime(SqlDataReader r, string name) =>
            r[name] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(r[name]);

        public static bool? GetBoolean(SqlDataReader r, string name)
        {
            if (r[name] == DBNull.Value) return null;
            var val = r[name];
            // Handle BIT, int 0/1, or string "true"/"false"
            if (val is bool b) return b;
            if (val is byte by) return by != 0;
            if (val is short s) return s != 0;
            if (val is int i) return i != 0;
            if (val is long l) return l != 0;
            if (val is string s2) return bool.TryParse(s2, out var parsed) ? parsed : (bool?)null;
            return null;
        }
    }

}
