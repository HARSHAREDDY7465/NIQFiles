﻿
using System.ServiceModel;

namespace NIQ.D365.EL.GFKDataMigration.Helper
{
    internal class BindingHelper
    {
        internal static BasicHttpBinding GetBasicHttpBinding(bool useSsl = true)
        {
            var binding = new BasicHttpBinding
            {
                Name = "BasicHttpBinding_IWebConfigStatelessOperations",
                MessageEncoding = WSMessageEncoding.Mtom,
                ReceiveTimeout = TimeSpan.FromMinutes(5),
                SendTimeout = TimeSpan.FromMinutes(5),
                MaxBufferSize = int.MaxValue,
                MaxBufferPoolSize = long.MaxValue,
                MaxReceivedMessageSize = int.MaxValue,
                AllowCookies = true
            };

            binding.Security.Mode = useSsl
                ? BasicHttpSecurityMode.Transport
                : BasicHttpSecurityMode.None;

            binding.ReaderQuotas = new System.Xml.XmlDictionaryReaderQuotas
            {
                MaxArrayLength = int.MaxValue,
                MaxBytesPerRead = int.MaxValue,
                MaxDepth = int.MaxValue,
                MaxNameTableCharCount = int.MaxValue,
                MaxStringContentLength = int.MaxValue
            };

            return binding;
        }
    }
}
