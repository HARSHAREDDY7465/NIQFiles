﻿using System.Xml.Serialization;

namespace NIQ.D365.EL.GFKDataMigration.Model
{

   [XmlRoot("category")]
   public class Category {
      [XmlAttribute("id")]
      public string Id { get; set; }

      [XmlAttribute("catseqno")]
      public string CatSeqNo { get; set; }

      [XmlElement("description")]
      public string Description { get; set; }

      [XmlElement("option")]
      public List<Option> Options { get; set; }

      public Category() { }

      public Category(string id, string catSeqNo, string description, List<Option> options) {

         Id = id;

         CatSeqNo = catSeqNo;

         Description = description;

         Options = options;

      }
   }

   [XmlRoot("option")]
   public class Option {
      [XmlAttribute]
      public string id = "ProductPickerProducts";

      [XmlAttribute]
      public string runtimeId { get; set; }

      [XmlElement]
      public string description { get; set; }

      [XmlElement]
      public int unitprice { get; set; }

      [XmlElement]
      public int quantity { get; set; }

      [XmlElement("property")]
      public List<Property> properties { get; set; }

   }

   [XmlRoot("property")]
   public class Property {
      [XmlAttribute]
      public string id { get; set; }

      [XmlText]
      public string value { get; set; }

   }

}
