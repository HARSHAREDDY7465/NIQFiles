﻿using System;

namespace NIQ.D365.EL.GFKDataMigration.Model
{
   internal class SQLQuoteDetail {
      public string QuoteID { get; set; }
      public string Status { get; set; }
      public string Message { get; set; }
      public string ConfigXML { get; set; }
      public string ConfigType { get; set; }
   }
}
