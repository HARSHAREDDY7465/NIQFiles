﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace NIQ.D365.EL.GFKDataMigration.Model
{
    public static class Utilities
    {
        public static string Messages { get; private set; }

        static Utilities()
        {
            Messages = string.Empty;
        }

        public static XmlNodeList? GetXMLNodeList(XmlDocument xdoc, string xpath)
        {
            try
            {                
                return xdoc.SelectNodes(xpath); ;
            }
            catch (Exception ex)
            {
                Messages += $"Unable to get XML node list from sub-section of XML ({xpath}). {ex.Message}";
                return null;
            }
        }



    }
}
