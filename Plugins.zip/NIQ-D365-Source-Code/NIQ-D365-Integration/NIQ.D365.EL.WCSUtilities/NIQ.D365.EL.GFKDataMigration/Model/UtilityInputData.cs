﻿namespace NIQ.D365.EL.GFKDataMigration.Model
{

    public class UtilityInputData
    {
        public Guid QuoteId { get; set; }
        public decimal ExtendedAmount { get; set; }
        public string? NiqExternalId { get; set; }
        public string? NiqRemark { get; set; }
        public string? NiqDeliveryFrequency { get; set; }
        public string? ProductName { get; set; }
        public string? ProductNumber { get; set; }
        public string? L7ProductName { get; set; }
        public string? Country { get; set; }
        public string? CountryVariant__c { get; set; }
        public string? PanelType__c { get; set; }
        public DateTime? Start_Date__c { get; set; }
        public DateTime? End_Date__c { get; set; }
    }

}
