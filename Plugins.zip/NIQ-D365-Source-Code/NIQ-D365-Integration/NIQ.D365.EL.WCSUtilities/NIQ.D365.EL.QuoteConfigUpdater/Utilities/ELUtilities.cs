﻿using Newtonsoft.Json.Linq;
using NIQ.D365.EL.QuoteConfigUpdater.Helper;
using NIQ.D365.EL.QuoteConfigUpdater.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using NIQ.D365.EL.QuoteConfigUpdater.ELWebServiceReference;

namespace NIQ.D365.EL.QuoteConfigUpdater.Utilities
{
    internal class ELUtilities
    {

        internal static void FetchConfiguration(ref Quote quoteDetail, string token, string d365OrgName, string elWebserviceUri)
        {
            try
            {
                var connectInfo = new MSCrmClientConnectInfo()
                {
                    OAuthToken = token,
                    CrmOrganizationName = d365OrgName
                };

                var statelessClient = new WebConfigStatelessOperationsClient(
                        BindingHelper.GetBasicHttpBinding(),
                        new EndpointAddress(elWebserviceUri)
                );

                ConfigHeader header = new() { Id = quoteDetail.QuoteID, Type = "quote" };

                Console.WriteLine("Calling Webservice to fetch Configuration");
                ConfigurationMetadata loadResult = statelessClient.GetMetadataAsync(connectInfo, header).Result;
                quoteDetail.ConfigurationXml = loadResult.ConfigurationXml;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Fetching Configuration failed: {ex.Message}");
                throw;
            }
        }


        internal static void UpdateConfiguration(ref Quote quoteDetail, Boolean isDraft, string token, string d365OrgName, string elWebserviceUri)
        {
            Console.WriteLine("Fetching Configuration to Update.");
            FetchConfiguration(ref quoteDetail,token,d365OrgName,elWebserviceUri);

            try
            {
                Console.WriteLine("Updating Configuration");
                var connectInfo = new MSCrmClientConnectInfo()
                {
                    OAuthToken = token,
                    CrmOrganizationName = d365OrgName
                };

                var statelessClient = new WebConfigStatelessOperationsClient(
                        BindingHelper.GetBasicHttpBinding(),
                        new EndpointAddress(elWebserviceUri)
                );

                XDocument masterConfig = XDocument.Parse(quoteDetail.ConfigurationXml);
                //Console.WriteLine(masterConfig.ToString());

                List<XElement> lineItems = masterConfig?.Root?.Elements("lineitem").ToList() ?? [];

                foreach (XElement lineitem in lineItems)
                {
                    var updateConfigParameters = new UpdateConfigParameters()
                    {
                        AutoUpdateConfiguration = AutoUpdateConfigurationType.All,
                        Changes = new ConfigChange[] { new SetSettingChange() { Setting = ConfigSettingId.DraftMode, Value = isDraft } }, /* Config changes in draft mode */
                        Header = new ConfigHeader() { Id = quoteDetail.QuoteID, Type = "quote" },
                        OperationBehaviors = new OperationBehaviors() { AutoSaveConfiguration = true },
                        IndividualizeChanges = true
                    };

                    try
                    {
                        bool v = int.TryParse(lineitem.Attribute("id")?.Value, out int lineItemId);
                        var configResult = statelessClient.UpdateConfigurationAsync(connectInfo, updateConfigParameters, lineItemId).Result;

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Config update failed: {ex.Message}");
                        throw;
                    }
                }

                Console.WriteLine("Configuration has been updated");

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Update Configuration failed for Quote: {ex.Message}");
                throw;
            }
        }
    }
}
