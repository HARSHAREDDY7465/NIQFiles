﻿using Microsoft.Identity.Client;
using NIQ.D365.EL.QuoteConfigUpdater.Model;
using System.Collections.Concurrent;
using System.Net.Http.Headers;
using System.Text;
using static System.Formats.Asn1.AsnWriter;

namespace NIQ.D365.EL.QuoteConfigUpdater.Utilities
{
    internal class MSDUtilities
    {

        internal static async Task<QuoteProductUpdateResult> QuoteProductUpdateAsync(string baseUrl, string token, QuoteProductDetail quoteProductDetail)
        {
            using var http = new HttpClient();
            http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            http.DefaultRequestHeaders.Add("OData-MaxVersion", "4.0");
            http.DefaultRequestHeaders.Add("OData-Version", "4.0");
            http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            http.DefaultRequestHeaders.Add("If-Match", "*");
            http.DefaultRequestHeaders.Add("Prefer", "return=representation");

            baseUrl = baseUrl.TrimEnd('/');

            var requestUrl = $"{baseUrl}/api/data/v9.2/quotedetails({quoteProductDetail.Quotedetailid})";

            var payload = new
            {
                niq_elassetid = quoteProductDetail.Niq_elassetid,
                niq_ratecardid = quoteProductDetail.Niq_ratecardid,
                niq_productdescription = quoteProductDetail.Niq_productdescription
            };

            var content = new StringContent(System.Text.Json.JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
            var patch = new HttpRequestMessage(new HttpMethod("PATCH"), requestUrl) { Content = content };

            var response = await http.SendAsync(patch);

            if (response.IsSuccessStatusCode)
            {
                return new QuoteProductUpdateResult { QuoteDetailId = quoteProductDetail.Quotedetailid, UpdateStatus = "Success"};
            }

            return new QuoteProductUpdateResult
            {
                QuoteDetailId = quoteProductDetail.Quotedetailid,
                UpdateStatus = "Failed",
                ErrorCode = ((int)response.StatusCode).ToString(),
                ErrorMessage = await response.Content.ReadAsStringAsync()
            };

        }


        internal static async Task<IReadOnlyList<QuoteProductUpdateResult>> UpdateManyAsync(
                string baseUrl,
                string token,
                IReadOnlyList<QuoteProductDetail> items,
                int maxDegreeOfParallelism = 6)
        {
            if (items == null || items.Count == 0)
                return Array.Empty<QuoteProductUpdateResult>();

            var allResults = new ConcurrentBag<QuoteProductUpdateResult>();
            using var semaphore = new SemaphoreSlim(maxDegreeOfParallelism);
            var tasks = new List<Task>();

            foreach (var qp in items)
            {
                await semaphore.WaitAsync();

                tasks.Add(Task.Run(async () =>
                {
                    try
                    {
                        var result = await QuoteProductUpdateAsync(baseUrl, token, qp);
                        allResults.Add(result);
                    }
                    catch (Exception ex)
                    {
                        allResults.Add(new QuoteProductUpdateResult
                        {
                            QuoteDetailId = qp.Quotedetailid,
                            UpdateStatus = "Failed",
                            ErrorCode = "Exception",
                            ErrorMessage = ex.Message
                        });
                    }
                    finally
                    {
                        semaphore.Release();
                    }
                }));
            }

            await Task.WhenAll(tasks);

            return allResults
                .OrderBy(r => r.QuoteDetailId)
                .ToList()
                .AsReadOnly();
        }



    }
}
