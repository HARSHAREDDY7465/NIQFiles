﻿using NIQ.D365.EL.QuoteConfigUpdater.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace NIQ.D365.EL.QuoteConfigUpdater.Builder
{
    internal class ConfigurationXMLParser
    {

        internal static int ParseConfigXML(Quote quoteDetail, ref List<ParsedELXMLContent> parsedELXMLContentList)
        {

            XDocument masterConfig = XDocument.Parse(quoteDetail.ConfigurationXml);
            //Console.WriteLine(masterConfig.ToString());

            var matchesFromAllProductSummaryOptions =
                masterConfig?.Descendants("category")
                    .Where(x =>
                        x.Attribute("id")?.Value == "AllProductSummary" || x.Attribute("id")?.Value == "AllProductSummaryRC")
                    .Descendants("option")
                ?? [];

            //Create a set of properties with a certain ID and pull their values
            string[] propertyIdsToMatch = ["DBName", "CRM_ProductNum", "ContractProductName", "AssetGUID", "AssetPrimaryKey", "Asset_JSON", "RateCardID", "IsDraft", "LineItemId"];
            int isDraftInt = 0;

            foreach (var item in matchesFromAllProductSummaryOptions)
            {

                var ids = new HashSet<string>(propertyIdsToMatch, StringComparer.OrdinalIgnoreCase);


                Dictionary<string, string?> properties = item
                    .Descendants("property")
                    .Where(p =>
                    {
                        var id = p.Attribute("id")?.Value;
                        return !string.IsNullOrWhiteSpace(id) && ids.Contains(id!);
                    })
                    .ToDictionary(
                        p => p.Attribute("id")!.Value,
                        p => (string?)p.Value,                     
                        StringComparer.OrdinalIgnoreCase);


                var parent2 = item?.Parent?.Parent;

                properties["LineItemId"] = parent2?.Attribute("id")?.Value ?? string.Empty;
                //set if config is in draft mode
                properties["IsDraft"] = parent2?.Attribute("isdraft")?.Value ?? string.Empty;                
                isDraftInt = int.TryParse(parent2?.Attribute("isdraft")?.Value, out var n) ? n : 0;


                foreach (var key in propertyIdsToMatch)
                {
                    properties.TryAdd(key, null);
                }



                ParsedELXMLContent record = new()
                {
                    QuoteID = quoteDetail.QuoteID,
                    RuntimeId = item!.Attribute("runtimeId")!.Value,
                    RecordId = item!.Attribute("rid")!.Value,
                    Description = item!.Descendants("description")!.FirstOrDefault()!.Value,
                    DBName = properties["DBName"],
                    ProductNumber = properties["CRM_ProductNum"],
                    ContractProductName = properties["ContractProductName"],
                    ELAssetID = properties["AssetGUID"],
                    AssetPrimaryKey = properties["AssetPrimaryKey"],
                    RateCardId = properties["RateCardID"],
                    ProductDescription = properties["Asset_JSON"],
                    IsDraft = properties["IsDraft"],
                    LineItemId = properties["LineItemId"]

                };

                parsedELXMLContentList.Add(record);

            }

            Console.WriteLine("Successfully Parsed Asset Metadata");
            return isDraftInt;
        }
    }
}
