﻿using NIQ.D365.EL.QuoteConfigUpdater.Model;
using System.Net.Http.Headers;
using System.Text.Json;

namespace NIQ.D365.EL.QuoteConfigUpdater.Builder
{
    internal class QuoteDetailsBuilder
    {

        internal static async Task<string> GetQuoteDetailsByQuoteId(string baseUrl, string accessToken, string quoteId)
        {
            baseUrl = baseUrl.TrimEnd('/');

            var apiUrl = $"{baseUrl}/api/data/v9.2/quotes({quoteId})/quote_details" +
                         "?$select=quotedetailid,niq_databasename,exp_recordid,niq_elassetid,niq_ratecardid,niq_productdescription";

            using var http = new HttpClient();
            http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            http.DefaultRequestHeaders.Add("OData-MaxVersion", "4.0");
            http.DefaultRequestHeaders.Add("OData-Version", "4.0");
            http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            http.DefaultRequestHeaders.Add("Prefer", "odata.maxpagesize=500");

            var response = await http.GetAsync(apiUrl).ConfigureAwait(false);
            var content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

            if (!response.IsSuccessStatusCode)
            {
                throw new InvalidOperationException($"HTTP {(int)response.StatusCode}: {content}");
            }

            return content;

        }

        private static readonly JsonSerializerOptions jsonSerializerOptionsriteOptions = new()
        {
            PropertyNameCaseInsensitive = true,
            ReadCommentHandling = JsonCommentHandling.Skip,
        };

        internal static List<QuoteProductDetail>? ParseQuotedetails(string json)
        {
            var root = JsonSerializer.Deserialize<ODataQuoteResponse>(json, jsonSerializerOptionsriteOptions);

            // Safeguard
            if (root?.Value == null)
                return null;

            return [.. root.Value];
        }


        internal static void UpdateQuotedetailsFromParsedList(
                System.Collections.Generic.IEnumerable<ParsedELXMLContent> parsedList,
                System.Collections.Generic.IList<QuoteProductDetail> quotedetails,
                ref System.Collections.Generic.List<QuoteProductDetail> updatedQuoteDetails
        )
        {

            // Build a lookup for efficient case-insensitive matching
            var parsedDBNameLookup = parsedList
                .Where(p => !string.IsNullOrWhiteSpace(p.DBName))
                .GroupBy(p => p.DBName!, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.OrdinalIgnoreCase);

            // Build a lookup for efficient case-insensitive matching
            var parsedRecordIdLookup = parsedList
                .Where(p => !string.IsNullOrWhiteSpace(p.RecordId))
                .GroupBy(p => p.RecordId!, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.OrdinalIgnoreCase);


            var matchedIds = new HashSet<Guid>();

            // ---------- PASS 1: match by DBName ----------
            foreach (var qd in quotedetails)
            {
                var dbNameKey = qd.Niq_databasename;
                if (string.IsNullOrWhiteSpace(dbNameKey)) continue;

                if (parsedDBNameLookup.TryGetValue(dbNameKey, out var dbNameMatches) && dbNameMatches.Count > 0)
                {
                    // Prefer candidate with ProductDescription (or your own tie-break rule)
                    var p = dbNameMatches
                        .OrderByDescending(x => !string.IsNullOrWhiteSpace(x.ProductDescription))
                        .First();

                    updatedQuoteDetails.Add(new QuoteProductDetail
                    {
                        Quotedetailid = qd.Quotedetailid,
                        Niq_databasename = qd.Niq_databasename,
                        Exp_recordid = qd.Exp_recordid,
                        Niq_elassetid = p.ELAssetID ?? string.Empty,
                        Niq_ratecardid = p.RateCardId ?? string.Empty,
                        Niq_productdescription = p.ProductDescription ?? string.Empty
                    });

                    matchedIds.Add(qd.Quotedetailid);
                }
            }

            // ---------- PASS 2: match remaining by RecordId ----------
            foreach (var qd in quotedetails)
            {
                // Skip already matched in pass 1
                if (matchedIds.Contains(qd.Quotedetailid)) continue;

                var recordIdKey = qd.Exp_recordid;
                if (string.IsNullOrWhiteSpace(recordIdKey)) continue;

                if (parsedRecordIdLookup.TryGetValue(recordIdKey, out var recordMatches) && recordMatches.Count > 0)
                {
                    var p = recordMatches
                        .OrderByDescending(x => !string.IsNullOrWhiteSpace(x.ProductDescription))
                        .First();

                    updatedQuoteDetails.Add(new QuoteProductDetail
                    {
                        Quotedetailid = qd.Quotedetailid,
                        Niq_databasename = qd.Niq_databasename,
                        Exp_recordid = qd.Exp_recordid,
                        Niq_elassetid = p.ELAssetID ?? string.Empty,
                        Niq_ratecardid = p.RateCardId ?? string.Empty,
                        Niq_productdescription = p.ProductDescription ?? string.Empty
                    });

                    matchedIds.Add(qd.Quotedetailid);
                }
            }

        }

    }
}
