﻿
using Azure.Security.KeyVault.Secrets;
using NIQ.D365.EL.QuoteConfigUpdater.Builder;
using NIQ.D365.EL.QuoteConfigUpdater.Helper;
using NIQ.D365.EL.QuoteConfigUpdater.Model;
using NIQ.D365.EL.QuoteConfigUpdater.Utilities;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.ServiceModel;
using System.Xml.Linq;

namespace NIQ.D365.EL.QuoteConfigUpdater
{
    internal class QuoteConfigUpdater
    {

        private static string? d365OrgName;
        private static string? crmURL;
        private static string? elURL; 
        private static string? kvUrl;
        private static string? elWebserviceUri;

        private static string? clientId;
        private static string? clientSecret;
        private static string? token;
        
        private static Boolean onlyFetchConfig = true;
        private static Boolean draftMode = true;
        private static Boolean msdQPUpdate = false;

        static void Main(string[] args)
        {
            var validateMessage = ValidateArgs(args);
            if (validateMessage != null)
            {
                Console.Error.WriteLine(validateMessage);
                PrintUsage();
                return;
            }

            // Config value initiation
            try
            {
                d365OrgName = ConfigurationDataReadHelper.GetRequiredConfig("D365OrgName","string");
                crmURL = ConfigurationDataReadHelper.GetRequiredConfig("D365Url","url");
                elURL = ConfigurationDataReadHelper.GetRequiredConfig("ELUrl","url");
                kvUrl = ConfigurationDataReadHelper.GetRequiredConfig("KVUrl","url");
                clientId = ConfigurationDataReadHelper.GetRequiredConfig("clientId","string");

                elWebserviceUri = $"{elURL}experlogix/services/WebConfigStatelessOperations.svc";
            }
            catch (ConfigurationErrorsException ex)
            {
                Console.WriteLine($"Error in config file: {ex.Filename}, Line: {ex.Line}. Please check if config file has valid XML content.");
                Console.WriteLine($"Aborting. ");
                return;
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine(ex.Message.ToString());
                return;
            }

            var operationModeInput = args[1];
            if (operationModeInput.Equals("live", StringComparison.CurrentCultureIgnoreCase))
            {
                draftMode = false;
                onlyFetchConfig = false;
            }
            else if(operationModeInput.Equals("draft", StringComparison.CurrentCultureIgnoreCase))
            {
                draftMode = true;
                onlyFetchConfig = false;
            }
            else if (operationModeInput.Equals("parse", StringComparison.CurrentCultureIgnoreCase))
            {
                draftMode = false;
                onlyFetchConfig = true;
            }

            if (args.Length == 3 && (draftMode == true || onlyFetchConfig == true) && args[2].Equals("Yes", StringComparison.CurrentCultureIgnoreCase))
            {
                msdQPUpdate = true;
            }
            else
            {
                msdQPUpdate = false;
            }
            
            #region Retrieve Secrets
            try
            {
                Console.WriteLine("Connecting to Azure Key Vault to retrieve secrets and passwords. A browser window may open for authentication.");
                var credential = AzureCredentialHelper.getSecret(kvUrl);
                var client = new SecretClient(new Uri(kvUrl), credential);
                // Get  secret
                KeyVaultSecret secret = client.GetSecret(clientId);
                clientSecret = secret.Value;
                Console.WriteLine($"Secret fetched from keyvault.");
                //Console.WriteLine($"Secret Value: {clientSecret}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unable to read secret from Azure Keyvault. Exception {ex.Message}");
                Console.WriteLine($"Exiting... ");
                return;
            }
            #endregion Retrieve Secrets

            #region OAuth Token generation
            Console.WriteLine($"Creating OAuth Token for CRM Instance {crmURL}");
            OAuth2Helper oAuth2Helper = new();
            token = oAuth2Helper.GetBearerToken(crmURL, clientId, clientSecret);
            if (token == null)
            {
                Console.WriteLine("OAuth token is null. Aborting.");
                return;
            }
            else
            {
                Console.WriteLine("OAuth Token Obtained");
            }
            #endregion OAuth Token generation

            try
            {
                Console.WriteLine($"Connecting to CRM Instance {crmURL}");
                
                Quote quoteDetail = new()
                {
                    QuoteID = args[0]
                    //for developement testing
                    //QuoteID = "08a4dc42-70c4-f011-bbd3-7c1e525e830b"
                };

                //overwrite Command Line Arguments for developement testing
                //draftMode = true;
                //onlyFetchConfig = true;
                //msdQPUpdate = true;

                // Initialize export file details
                string baseDir = Path.Combine(AppContext.BaseDirectory, "DataExports");
                var safeQuoteId = (quoteDetail?.QuoteID ?? "UnknownQuote").Replace("-", "");

                #region EL Config Fetch & Update
                if (!onlyFetchConfig)
                {
                    ELUtilities.UpdateConfiguration(ref quoteDetail!, draftMode, token, d365OrgName, elWebserviceUri);
                    Console.WriteLine("Fetching Upated Configuration to Parse");
                }
                else
                {
                    Console.WriteLine($"Running utility with onlyFetchConfigToParseAgain:- {onlyFetchConfig}");
                }

                //Fetch again to parse
                ELUtilities.FetchConfiguration(ref quoteDetail!, token, d365OrgName, elWebserviceUri);
                #endregion EL Config Fetch & Update

                #region EL Config Parsing
                List<ParsedELXMLContent> parsedELXMLContents = [];
                int isDraftInt = ConfigurationXMLParser.ParseConfigXML(quoteDetail, ref parsedELXMLContents);
                //Console.WriteLine(XDocument.Parse(quoteDetail.ConfigurationXml));

                string xmlFileName = $"ConfigXML_{safeQuoteId}.xml";
                FileExportHelper.SaveToXml(XDocument.Parse(quoteDetail.ConfigurationXml), baseDir,xmlFileName);
                Console.WriteLine($"Config XML file saved at: {xmlFileName}");

                string csvFilePath = $"ParsedELXMLContents_{safeQuoteId}.csv";
                FileExportHelper.SaveToCsv(parsedELXMLContents, baseDir, csvFilePath);
                Console.WriteLine($"Parsed CSV file saved at: {csvFilePath}");
                #endregion EL Config Parsing

                #region MSD Qu0te Product Fetch & Update
                if (msdQPUpdate && isDraftInt == 1) {

                    List<QuoteProductDetail> quoteProductDetail =[];
                    // Call Dataverse synchronously
                    var responseData = QuoteDetailsBuilder.GetQuoteDetailsByQuoteId(crmURL, token, quoteDetail.QuoteID).GetAwaiter().GetResult();
                    quoteProductDetail = QuoteDetailsBuilder.ParseQuotedetails(responseData)!;
                    //Console.WriteLine(json);
                    string existingQuoteProductDetailFilePath = $"ExistingQuoteProductDetails_{safeQuoteId}.csv";
                    FileExportHelper.SaveToCsv(quoteProductDetail, baseDir , existingQuoteProductDetailFilePath,
                        ["Quotedetailid", "Exp_recordid", "Niq_databasename", "Niq_elassetid", "Niq_ratecardid", "Niq_productdescription" ]
                        );
                    Console.WriteLine($"Existing Quote Product details saved at: {existingQuoteProductDetailFilePath}");

                    //Prepare the update list
                    List<QuoteProductDetail> updatedQuoteProductDetail = [];
                    QuoteDetailsBuilder.UpdateQuotedetailsFromParsedList(parsedELXMLContents,quoteProductDetail, ref updatedQuoteProductDetail);
                    
                    if (updatedQuoteProductDetail.Count == 0)
                    {
                        Console.WriteLine($"Total Quote Product count: {quoteProductDetail.Count}, However no Quote Product details matched in the parsed XML. So nothing to be updated in MSD");
                        return;
                    }

                    var results = MSDUtilities.UpdateManyAsync(
                        baseUrl: crmURL,
                        token: token,
                        items: updatedQuoteProductDetail,
                        maxDegreeOfParallelism: 6).GetAwaiter().GetResult();

                    var success = results.Count(r => r.UpdateStatus == "Success");
                    var failed = results.Count - success;
                    Console.WriteLine($"Total Quote Product count: {quoteProductDetail.Count}, Updated Quote Product count: {success}, Failed count: {failed}");

                    // Index results by id for O(1) lookups
                    var resultById = results.ToDictionary(r => r.QuoteDetailId, r => r);

                    // Update your original items in-place
                    foreach (var item in updatedQuoteProductDetail)
                    {
                        if (resultById.TryGetValue(item.Quotedetailid, out var res))
                        {
                            item.Updatestatus = res.UpdateStatus;
                            item.Errorcode = res.ErrorCode;
                            item.Errormessage = res.ErrorMessage;
                        }
                    }
                    
                    string updatedQuoteProductDetailFilePath = $"UpdatedQuoteProductDetails_{safeQuoteId}.csv";
                    FileExportHelper.SaveToCsv(updatedQuoteProductDetail, baseDir , updatedQuoteProductDetailFilePath);
                    Console.WriteLine($"Updated Quote Product details saved at: {updatedQuoteProductDetailFilePath}");
                } else if(msdQPUpdate && isDraftInt != 1)
                {
                    Console.WriteLine("Configuration is not in draft mode. No MSD Update needed.");
                }
                #endregion MSD Quote Product Fetch & Update

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                Console.WriteLine("Utility execution completed.");
                Console.WriteLine();

            }
            return;
        } //end of main


        private static string? ValidateArgs(string[] args)
        {
            
            if (args == null) return "Please run with valid arguments.";
            if (args.Length < 2)
            {
                return "Too few arguments. Expecting at least 2 arguments";
            }

            if (args.Length > 3)
            {
                return "Too many arguments. Expecting at most 3 arguments";
            }

            // Check the second argument value
            var second = args[1]?.Trim();
            if (string.IsNullOrEmpty(second) || (!second.Equals("live", StringComparison.OrdinalIgnoreCase) 
                                                && !second.Equals("draft", StringComparison.OrdinalIgnoreCase) 
                                                && !second.Equals("parse", StringComparison.OrdinalIgnoreCase)
                                                )
            )
            {
                return "Second argument (draftmode) must be 'live' or 'draft' or 'parse'.";
            }

            bool requiresThird = second.Equals("draft", StringComparison.OrdinalIgnoreCase) || second.Equals("parse", StringComparison.OrdinalIgnoreCase);

            // If second is "yes", we require a 3rd argument
            if (requiresThird)
            {
                if (args.Length < 3)
                {
                    return "Third argument (msdupdate) is required when the second argument is 'draft' or 'parse'.";
                }
                // Optional: add additional checks on the third arg (non-empty, format, etc.)
                if (string.IsNullOrWhiteSpace(args[2]))
                {
                    return "Third argument (msdupdate) cannot be empty when the second argument is 'draft' or 'parse'.";
                }
                if(!args[2].Equals("yes", StringComparison.OrdinalIgnoreCase) && !args[2].Equals("no", StringComparison.OrdinalIgnoreCase)){
                    return "Third argument (msdupdate) must be 'yes' or 'no'.";
                }
            }
            else
            {
                // If second is not "yes", only 2 arguments should be provided
                if (args.Length != 2)
                {
                    return "Third argument (msdupdate) not needed when the second argument is not 'draft' or 'parse'.";
                }
            }

            // Passed all checks
            return null;
        }

        private static void PrintUsage()
        {
            string exePath = Environment.ProcessPath ?? "NIQ.D365.EL.QuoteConfigUpdater"; // the loaded image path
            string programName = Path.GetFileNameWithoutExtension(exePath);

            Console.WriteLine();
            Console.WriteLine("Usage:");
            Console.WriteLine($"  {programName} <quoteid> <operationmode[live|draft|parse]> [msdupdate[yes|no]]");
            Console.WriteLine();
            Console.WriteLine("Rules:");
            Console.WriteLine("  - Provide exactly 2 arguments if the second argument is 'live'.");
            Console.WriteLine("  - Provide exactly 3 arguments if the second argument is 'draft' or 'parse'; the third becomes required.");
            Console.WriteLine();
            Console.WriteLine("Examples:");
            Console.WriteLine($"  {programName} 00000000-0000-0000-0000-000000000000  live");
            Console.WriteLine($"  {programName} 00000000-0000-0000-0000-000000000000  draft yes");
            Console.WriteLine($"  {programName} 00000000-0000-0000-0000-000000000000  draft no");
            Console.WriteLine($"  {programName} 00000000-0000-0000-0000-000000000000  parse yes");
            Console.WriteLine($"  {programName} 00000000-0000-0000-0000-000000000000  parse no");
        }

    } //end of class

} //end of namespace
