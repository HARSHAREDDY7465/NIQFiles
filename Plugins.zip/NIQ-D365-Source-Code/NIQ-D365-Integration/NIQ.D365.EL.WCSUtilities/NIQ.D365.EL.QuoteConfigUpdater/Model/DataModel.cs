﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace NIQ.D365.EL.QuoteConfigUpdater.Model
{
    public class Quote
    {
        public string QuoteID { get; set; }
        public string ConfigurationXml { get; set; }
        public string ProcessLog { get; set; }
    }
    public class ParsedELXMLContent
    {
        public string QuoteID { get; set; }
        public string? DBName { get; set; }
        public string? ELAssetID { get; set; }
        public string? RateCardId { get; set; }
        public string? ProductDescription { get; set; }
        public string? RecordId { get; set; }
        public string? ProductNumber { get; set; }
        public string? ContractProductName { get; set; }
        public string? Description { get; set; }

        public string? AssetPrimaryKey { get; set; }

        public string? RuntimeId { get; set; }
        public string? IsDraft { get;  set; }

        public string? LineItemId { get; set; }
        
    }


    public class QuoteProductDetail
    {
        // Columns from Dataverse
        [JsonPropertyName("quotedetailid")]
        public Guid Quotedetailid { get; set; }

        [JsonPropertyName("exp_recordid")]
        public string Exp_recordid { get; set; }

        [JsonPropertyName("niq_databasename")]
        public string Niq_databasename { get; set; }

        [JsonPropertyName("niq_elassetid")]
        public string Niq_elassetid { get; set; }

        [JsonPropertyName("niq_ratecardid")]
        public string Niq_ratecardid { get; set; }

        [JsonPropertyName("niq_productdescription")]
        public string Niq_productdescription { get; set; } // JSON string, may be null

        public string Updatestatus {  get; set; }
        public string Errorcode { get; set; }
        public string Errormessage { get; set; }

    }


    public class ODataQuoteResponse
    {
        [JsonPropertyName("@odata.context")]
        public string ODataContext { get; set; }

        [JsonPropertyName("value")]
        public List<QuoteProductDetail> Value { get; set; } = [];
    }


    public sealed class QuoteProductUpdateResult
    {
        public Guid QuoteDetailId { get; init; }
        public string UpdateStatus { get; init; }
        public string ErrorCode { get; init; }
        public string ErrorMessage { get; init; }
    }


}
