﻿using System.ServiceModel;

namespace NIQ.D365.EL.QuoteConfigUpdater.Helper
{
    internal class BindingHelper
    {
        internal static BasicHttpBinding GetBasicHttpBinding(bool useSsl = true) 
        {
            BasicHttpBinding basicHttpBinding = new BasicHttpBinding();
            basicHttpBinding.Name = "BasicHttpBinding_IWebConfigStatelessOperations";
            basicHttpBinding.MessageEncoding = WSMessageEncoding.Mtom;
            basicHttpBinding.ReceiveTimeout = TimeSpan.FromMinutes(5);
            basicHttpBinding.SendTimeout = TimeSpan.FromMinutes(5);
            basicHttpBinding.MaxBufferSize = int.MaxValue;
            basicHttpBinding.MaxBufferPoolSize = long.MaxValue;
            basicHttpBinding.MaxReceivedMessageSize = int.MaxValue;
            basicHttpBinding.Security.Mode = useSsl ? BasicHttpSecurityMode.Transport : BasicHttpSecurityMode.None;

            basicHttpBinding.ReaderQuotas.MaxArrayLength = int.MaxValue;
            basicHttpBinding.ReaderQuotas.MaxBytesPerRead = int.MaxValue;
            basicHttpBinding.ReaderQuotas.MaxDepth = int.MaxValue;
            basicHttpBinding.ReaderQuotas.MaxNameTableCharCount = int.MaxValue;
            basicHttpBinding.ReaderQuotas.MaxStringContentLength = int.MaxValue;

            basicHttpBinding.AllowCookies = true;
            return basicHttpBinding;
        }
   }



     
}
