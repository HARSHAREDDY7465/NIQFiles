﻿using Azure.Core;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Identity.Client.Platforms.Features.DesktopOs.Kerberos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NIQ.D365.EL.QuoteConfigUpdater.Helper
{
    internal class AzureCredentialHelper
    {
        public static TokenCredential getSecret(string kvUrl) {
            TokenCredential credential;
            try
            {
                // Use DefaultAzureCredential to pick up logged-in user credentials
                credential = new DefaultAzureCredential();
                // Test by requesting a token
                var aztoken = credential.GetToken(new TokenRequestContext(new[] { $"{kvUrl}.default" }), new CancellationToken());
            }
            catch
            {
                credential = new InteractiveBrowserCredential();
            }
            return credential;
        }
        
        
    }
 }
        
