﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NIQ.D365.EL.QuoteConfigUpdater.Helper
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Text;
    using System.Xml.Linq;

    public static class FileExportHelper
    {
        internal static void SaveToCsv<T>(
            IEnumerable<T> rows,
            string baseDir,
            string fileName,
            IEnumerable<string>? propertyOrder = null,
            bool includeBom = true)
        {

            if (rows == null) throw new ArgumentNullException(nameof(rows), "No data to write");
            if (string.IsNullOrWhiteSpace(baseDir)) throw new ArgumentException("Base directory is required.", nameof(baseDir));
            if (string.IsNullOrWhiteSpace(fileName)) throw new ArgumentException("File name is required.", nameof(fileName));

            
            fileName = SanitizeFileName(fileName);
            string combined = Path.Combine(baseDir, fileName);
            string fullBase = Path.GetFullPath(baseDir);
            string filePath = Path.GetFullPath(combined);

            if (!filePath.StartsWith(fullBase, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException("Refusing to write outside of the export directory.");
            }
            Directory.CreateDirectory(fullBase);


            var props = typeof(T)
                .GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .Where(p => p.CanRead)
                .ToDictionary(p => p.Name, p => p);

            IEnumerable<PropertyInfo> orderedProps = props.Values;

            // If a custom order is supplied, honor it and include only those props
            if (propertyOrder != null)
            {
                orderedProps = propertyOrder
                    .Where(name => props.ContainsKey(name))
                    .Select(name => props[name]);
            }

            var sb = new StringBuilder();

            // Header
            sb.AppendLine(string.Join(",", orderedProps.Select(p => EscapeCsv(p.Name))));

            // Rows
            foreach (var row in rows)
            {
                if (row is null) continue;

                var values = orderedProps.Select(p =>
                {
                    var val = p.GetValue(row);
                    return EscapeCsv(ToStringInvariant(val));
                });

                sb.AppendLine(string.Join(",", values));
            }

            var encoding = includeBom ? new UTF8Encoding(true) : new UTF8Encoding(false);
            File.WriteAllText(filePath, sb.ToString(), encoding);
        }


        private static string SanitizeFileName(string name, int maxLength = 128)
        {
            // Trim and replace directory separators to block traversal in the file name.
            name = (name ?? string.Empty).Trim()
                .Replace("/", "_")
                .Replace("\\", "_");

            // Remove characters not allowed by the OS
            var invalid = Path.GetInvalidFileNameChars();
            var sanitized = new char[name.Length];
            var j = 0;
            foreach (var c in name)
            {
                if (!invalid.Contains(c))
                    sanitized[j++] = c;
            }

            var result = new string(sanitized, 0, j);


            if (result.Length == 0) result = "Unnamed";
            if (result.Length > maxLength) result = result[..maxLength];

            return result;
        }

        private static string ToStringInvariant(object? value)
        {
            if (value == null) return string.Empty;
            return value switch
            {
                IFormattable f => f.ToString(null, System.Globalization.CultureInfo.InvariantCulture),
                _ => value.ToString()
            } ?? string.Empty;
        }


        public static string EscapeCsv(string s)
        {
            if (string.IsNullOrEmpty(s)) return string.Empty;

            // Normalize CRLF/CR/LF to LF to avoid Excel quirks
            s = s.Replace("\r\n", "\n").Replace("\r", "\n");

            bool mustQuote = s.Contains(',') || s.Contains('"') || s.Contains('\n');
            if (!mustQuote) return s;

            var escaped = s.Replace("\"", "\"\"");
            return $"\"{escaped}\"";
        }

        internal static void SaveToXml(XDocument ConfigurationXml, string baseDir, string fileName)
        {

            if (ConfigurationXml == null) throw new ArgumentNullException(nameof(ConfigurationXml), "No data to write");
            if (string.IsNullOrWhiteSpace(baseDir)) throw new ArgumentException("Base directory is required.", nameof(baseDir));
            if (string.IsNullOrWhiteSpace(fileName)) throw new ArgumentException("File name is required.", nameof(fileName));


            fileName = SanitizeFileName(fileName);
            string combined = Path.Combine(baseDir, fileName);
            string fullBase = Path.GetFullPath(baseDir);
            string filePath = Path.GetFullPath(combined);

            if (!filePath.StartsWith(fullBase, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException("Refusing to write outside of the export directory.");
            }
            Directory.CreateDirectory(fullBase);

            ConfigurationXml.Save(filePath);
        }

    }

}
