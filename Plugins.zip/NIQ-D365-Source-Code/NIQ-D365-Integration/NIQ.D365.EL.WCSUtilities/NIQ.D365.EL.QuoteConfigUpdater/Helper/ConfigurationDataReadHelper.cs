﻿using System.Configuration;

namespace NIQ.D365.EL.QuoteConfigUpdater.Helper
{
    internal class ConfigurationDataReadHelper
    {
        // Helper method
        internal static string GetRequiredConfig(string key, string valuetype)
        {
            var value = ConfigurationManager.AppSettings[key];
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new InvalidOperationException($"Missing or empty configuration value for key: {key}. Aborting.");
            }
            if (valuetype == "url")
            {
                if (!Uri.IsWellFormedUriString(value, UriKind.Absolute))
                    throw new InvalidOperationException($"Invalid URL format for {key} - {value}. Aborting.");

                if (!value.EndsWith('/'))
                    throw new InvalidOperationException($"URL must end with '/' for {key} - {value}. Aborting.");
            }

            return value;
        }
    }
}
