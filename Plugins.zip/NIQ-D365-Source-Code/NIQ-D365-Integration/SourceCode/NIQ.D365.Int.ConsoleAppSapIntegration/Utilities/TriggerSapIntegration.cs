﻿using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using NIQ.D365.Int.ConsoleAppSapIntegration.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json.Nodes;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml;
using Microsoft.Xrm.Sdk.Messages;

namespace NIQ.D365.Int.ConsoleAppSapIntegration.Utilities
{
    public class TriggerSapIntegration
    {
        public string opportunityId;
        public TriggerSapIntegration(string _opportunityid)
        {
            this.opportunityId = _opportunityid;
        }
        public void uploadfiletoMSD(IOrganizationService service, string payload)
        {
            var query = new QueryExpression("niq_financeapprovalrequests")
            {
                TopCount = 1,
                ColumnSet = new ColumnSet(
                    "niq_approvalstatus",
                    "niq_financeapprovalrequests",
                    "niq_relatedopportunity",
                    "niq_sapintegrationdecision"),
                Criteria =
                {
                    Conditions =
                    {
                        new ConditionExpression("niq_approvalstatus", ConditionOperator.Equal, 100000002),
                        new ConditionExpression("niq_relatedopportunity", ConditionOperator.Equal, new Guid(opportunityId))
                    }
                },
                Orders =
                {
                    new OrderExpression("createdon", OrderType.Descending)
                }
            };
            Entity FAR = service.RetrieveMultiple(query).Entities.FirstOrDefault();

            Entity updateFAR = new Entity(FAR.LogicalName, FAR.Id);
            updateFAR["niq_sapintegrationdecision"] = new OptionSetValue(2);
            UpdateRequest updateRequest = new UpdateRequest()
            {
                Target = updateFAR
            };
            updateRequest.Parameters.Add("SuppressCallbackRegistrationExpanderJob", true);

            service.Execute(updateRequest);
            Console.WriteLine("SAP integration decision is updated on FAR.");


            //create the file at local system.
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(payload);

            XmlWriterSettings writerSettings = new XmlWriterSettings
            {
                Indent = true,
                IndentChars = "  ",
                NewLineOnAttributes = false
            };
            using (XmlWriter writer = XmlWriter.Create(@"..\..\OutputPayload\sapOutputPayload1.xml", writerSettings))
            {
                doc.Save(writer);
            }


            //upload the file to MSD directly.
            byte[] fileContext = Encoding.ASCII.GetBytes(payload);
            string encodedData = System.Convert.ToBase64String(fileContext);

            Entity attachment = new Entity("annotation");
            attachment["objectid"] = new EntityReference("niq_financeapprovalrequests", FAR.Id);
            attachment["objecttypecode"] = "niq_financeapprovalrequests";
            attachment["subject"] = "Console app";
            attachment["notetext"] = "The payload file is uploaded by console app";
            attachment["documentbody"] = encodedData;
            attachment["mimetype"] = @"text/xml";
            attachment["filename"] = opportunityId+".xml";
            service.Create(attachment);
            Console.WriteLine("Generated Payload is upload to FAR.");
        }
        public async Task<string> getQuoteDetailCharacteristicPayload(JsonObject opportunityDetails, string quoteProductJson)
        {

            Console.WriteLine("\n QUOTE PRODUCT CHARACTERISTICS\n─────────────────────────────");
            List<JsonObject> quoteProductCharacteristics = new List<JsonObject>();
            string query = "?$select=_niq_quoteproductid_value" +
                "&$filter=( niq_quoteproductid/_quoteid_value eq " + opportunityDetails["_niq_mainquoteid_value"] + "  and niq_quoteproductid/quantity gt 0  and niq_quoteproductid/niq_isrevshareline eq false )" +
                "&$expand=niq_materialcharacteristicvalueid($select=niq_characteristicvaluecode),niq_materialcharacteristicid($select=niq_characteristiccode)";
            JsonNode qpcRecords = await OAuthHelpher.RetrieveAllUsingODataQuery("niq_quoteproductcharacteristics", query);
            quoteProductCharacteristics.AddRange(qpcRecords.AsArray().Cast<JsonObject>());
            //Console.WriteLine(hostJsonContent);

            List<JsonObject> childOpportunites = new List<JsonObject>();
            string childOppsQuery = "?$select=_niq_mainquoteid_value,_niq_salesorgid_value,niq_opportunitynumber,niq_sapsalesdocumentid,_niq_hostopportunity_value,niq_revenuesharedeal" +
              "&$filter=(_niq_hostopportunity_value eq " + opportunityDetails["opportunityid"] + " and niq_stage ne 'Closed Lost')" +
              "&$expand=niq_salesorgid($select=niq_salesorgcode)";

            JsonNode childOpps = await OAuthHelpher.RetrieveAllUsingODataQuery("opportunities", childOppsQuery);
            childOpportunites.AddRange(childOpps.AsArray().Cast<JsonObject>());

            List<JsonObject> quoteProducts = new List<JsonObject>();
            JsonObject quoteProductJsonObject = JsonNode.Parse(quoteProductJson)?.AsObject();
            quoteProductJsonObject.TryGetPropertyValue("value", out JsonNode products);
            quoteProducts.AddRange(products.AsArray().Cast<JsonObject>());

            foreach (var item in childOpportunites)
            {
                //Console.WriteLine(item);
                Console.WriteLine($"Child Opportunity Number : {item["niq_opportunitynumber"]}, Guid : {item["opportunityid"]}");
                List<JsonObject> childQuoteProducts = quoteProducts.Where(p => p["ac.opportunityid"]?.GetValue<string>() == item["opportunityid"].GetValue<string>()).ToList<JsonObject>();
                Console.WriteLine("quote products count :" + childQuoteProducts.Count);
                foreach (var childQp in childQuoteProducts)
                {
                    //Console.WriteLine(childQp);
                    string revshareName = childQp["prpid.productnumber"]?.GetValue<string>();
                    //Console.WriteLine("Rev share Name :"+revshareName);
                    if (!string.IsNullOrEmpty(revshareName) && string.Equals(revshareName, "INTERCO REV SHARE"))
                    {
                        var dta = item["niq_salesorgid"]?["niq_salesorgcode"]?.GetValue<string>();
                        quoteProductCharacteristics.Add(new JsonObject
                        {
                            ["_niq_quoteproductid_value"] = childQp["quotedetailid"].GetValue<string>(),
                            ["niq_materialcharacteristicvalueid"] = new JsonObject
                            {
                                ["niq_characteristicvaluecode"] = "IC" + item["niq_salesorgid"]?["niq_salesorgcode"]?.GetValue<string>()
                            },
                            ["niq_materialcharacteristicid"] = new JsonObject
                            {
                                ["niq_characteristiccode"] = "Z_PARTICIPATINGCOMP"
                            }

                        });
                    }
                }

            }
            JsonObject data = new JsonObject()
            {
                ["value"] = System.Text.Json.JsonSerializer.SerializeToNode(quoteProductCharacteristics).AsArray()
            };
            string final = data.ToJsonString(new JsonSerializerOptions { WriteIndented = true });

            return final;
        }

        public async Task<JsonObject> getOpportunityDetails(string opportunityid)
        {
            Console.WriteLine("\n OPPORTUNITY DETAILS\n─────────────────────────────");
            string query = "?$select=_niq_mainquoteid_value,_niq_salesorgid_value,niq_opportunitynumber,niq_sapsalesdocumentid,_niq_hostopportunity_value,niq_revenuesharedeal" +
                "&$filter= opportunityid eq " + opportunityid +
                "&$expand=niq_salesorgid($select=niq_salesorgcode)";
            JsonNode jsonNode = await OAuthHelpher.RetrieveAllUsingODataQuery("opportunities", query);
            JsonObject jsonObject = jsonNode[0].AsObject();
            //Console.WriteLine(jsonObject);
            Console.WriteLine("Sales Org ID: " + jsonObject["_niq_salesorgid_value"]);
            Console.WriteLine("Quote ID    : " + jsonObject["_niq_mainquoteid_value"]);

            return jsonObject;
        }

        public async Task<string> getQuoteNOptyPayload(JsonObject opportunityDetails)
        {
            string query = "?$select=niq_termtype,niq_contractstartdate,niq_contractenddate,_pricelevelid_value" +
                "&$filter=(quoteid eq " + opportunityDetails["_niq_mainquoteid_value"] + ")" +
                "&$expand=transactioncurrencyid($select=isocurrencycode),opportunityid($select=name,niq_opportunitynumber,_niq_hostopportunity_value,niq_customerponumber,niq_customerpodate,niq_submissiontime,niq_billinginstructions;$expand=niq_salesorgid($select=niq_salesorgcode,niq_salesdocumenttype),niq_soldtoparty($select=niq_sap_id__c,_niq_countryid_value,address1_country),niq_billtoparty($select=niq_sap_id__c),niq_deliverytoparty($select=niq_sap_id__c),parentcontactid($select=niq_sapid),niq_nameoninvoiceifdifffrominvoicerecipient($select=niq_sapid),niq_invoicerecipient2($select=niq_sapid),niq_invoicerecipient3($select=niq_sapid),niq_invoicerecipient4($select=niq_sapid),niq_invoicerecipient5($select=niq_sapid),owninguser($select=niq_employeenumber)),niq_paymenttermsid($select=niq_paymenttermcode)";
            JsonNode jsonNode = await OAuthHelpher.RetrieveAllUsingODataQuery("quotes", query);
            JsonObject jsonObject = jsonNode[0].AsObject();

            string hostOpportunityid = jsonObject["opportunityid"]?["_niq_hostopportunity_value"]?.GetValue<string>();
            bool dd = jsonObject.ContainsKey("opportunityid._niq_hostopportunity_value");
            //Console.WriteLine(dd);
            if (string.IsNullOrEmpty(hostOpportunityid))
            {
                jsonObject["niq_host_revenuesharedeal"] = opportunityDetails["niq_revenuesharedeal"] != null ? opportunityDetails["niq_revenuesharedeal"].DeepClone() : false;
                jsonObject["niq_parent_salesorg"] = opportunityDetails["niq_salesorgid"].DeepClone();

            }
            else
            {
                Console.WriteLine("Current record is Child opportunity, so Host opportunity id: " + hostOpportunityid);
                string queryChild = "?$select=niq_revenuesharedeal,_niq_salesorgid_value" +
                "&$filter= opportunityid eq " + hostOpportunityid +
                "&$expand=niq_salesorgid($select=niq_salesorgcode)";
                JsonNode childOppJsonNode = await OAuthHelpher.RetrieveAllUsingODataQuery("opportunities", queryChild);
                JsonObject childOppDetails = childOppJsonNode[0].AsObject();
                Console.WriteLine(childOppDetails["niq_revenuesharedeal"]);
                jsonObject["niq_host_revenuesharedeal"] = childOppDetails["niq_revenuesharedeal"] != null ? childOppDetails["niq_revenuesharedeal"].DeepClone() : false;
                jsonObject["niq_parent_salesorg"] = childOppDetails["niq_salesorgid"].DeepClone();
            }
            return jsonObject.ToJsonString(new JsonSerializerOptions { WriteIndented = true }); ;
        }
        public async Task<string> getQuoteDetailPayload(JsonObject opportunityDetails)
        {
            Console.WriteLine("\n Retrieving Quote Products\n─────────────────────────────");
            string query = "?$select=pricelevelid" +
                "&$filter=_niq_salesorg_value eq " + opportunityDetails["_niq_salesorgid_value"] +
                "&$top=1";
            JsonNode pricelistJsonNode = await OAuthHelpher.RetrieveAllUsingODataQuery("pricelevels", query);
            JsonObject priceList = pricelistJsonNode[0].AsObject();
            Console.WriteLine("Price List ID : " + priceList["pricelevelid"]);


            var fetchData = new
            {
                pricelevelid = priceList["pricelevelid"],
                niq_itemcategorygroup = "100000002",
                pricelevelid2 = priceList["pricelevelid"],
                niq_itemcategorygroup2 = "100000002",
                quantity = "0",
                extendedamount = "0",
                niq_isrevshareline = "0",
                opportunityid = opportunityId,
                niq_hostopportunity = opportunityId
            };
            var fetchXml = $@"
                <fetch page=""1"">
                  <entity name=""quotedetail"">
                    <attribute name=""niq_lineitemnumberforsap"" />
                    <attribute name=""productnumber"" />
                    <attribute name=""niq_revshareline"" />
                    <attribute name=""quantity"" />
                    <attribute name=""priceperunit"" />
                    <attribute name=""baseamount"" />
                    <attribute name=""extendedamount"" />
                    <attribute name=""niq_lineitemstartdate"" />
                    <attribute name=""niq_lineitemenddate"" />
                    <attribute name=""niq_lagrevenuerecognition"" />
                    <attribute name=""niq_deliveryfrequency"" />
                    <attribute name=""niq_billingfrequency"" />
                    <attribute name=""description"" />
                    <attribute name=""niq_invoicetext"" />
                    <attribute name=""niq_fundtype"" />
                    <attribute name=""niq_fundamount"" />
                    <attribute name=""niq_wbs"" />
                    <attribute name=""niq_revshareproductid"" />
                    <attribute name=""niq_quoteproductnumber"" />
                    <link-entity name=""product"" from=""productid"" to=""niq_revshareproductid"" visible=""false"" link-type=""outer"" alias=""prpid"">
                      <attribute name=""productnumber"" />
                    </link-entity>
                    <link-entity name=""product"" from=""productid"" to=""productid"" visible=""false"" link-type=""outer"" alias=""pepid"">
                      <attribute name=""productnumber"" />
                      <attribute name=""description"" />
                    </link-entity>
                    <link-entity name=""productpricelevel"" from=""productid"" to=""productid"" link-type=""outer"" alias=""productpricelevel"">
                      <attribute name=""niq_itemcategorygroup"" />
                      <attribute name=""niq_producttype"" />
                      <filter>
                        <condition attribute=""pricelevelid"" operator=""eq"" value=""{fetchData.pricelevelid}"" />
                        <condition attribute=""niq_itemcategorygroup"" operator=""ne"" value=""{fetchData.niq_itemcategorygroup}"" />
                      </filter>
                    </link-entity>
                    <link-entity name=""productpricelevel"" from=""productid"" to=""niq_revshareproductid"" link-type=""outer"" alias=""revproductpricelevel"">
                      <attribute name=""niq_itemcategorygroup"" />
                      <attribute name=""niq_producttype"" />
                      <attribute name=""niq_profitcentrecode"" />
                      <filter>
                        <condition attribute=""pricelevelid"" operator=""eq"" value=""{fetchData.pricelevelid2}"" />
                        <condition attribute=""niq_itemcategorygroup"" operator=""ne"" value=""{fetchData.niq_itemcategorygroup2}"" />
                      </filter>
                    </link-entity>
                    <link-entity name=""niq_profitcentre"" to=""niq_profitcentreid"" from=""niq_profitcentreid"" alias=""niq_profitcentre"" link-type=""outer"">
                      <attribute name=""niq_profitcentrecode"" />
                    </link-entity>
                    <filter>
                      <condition attribute=""quantity"" operator=""gt"" value=""{fetchData.quantity/*0*/}"" />
                      <condition attribute=""extendedamount"" operator=""ne"" value=""{fetchData.extendedamount/*0*/}"" />
                      <condition attribute=""niq_isrevshareline"" operator=""eq"" value=""{fetchData.niq_isrevshareline/*0*/}"" />
                    </filter>
                    <link-entity name=""quote"" from=""quoteid"" to=""quoteid"" link-type=""inner"" alias=""ac"">
                      <attribute name=""opportunityid"" />
                      <link-entity name=""opportunity"" from=""opportunityid"" to=""opportunityid"" link-type=""inner"" alias=""am"">
                        <attribute name=""niq_hostopportunity"" />
                        <filter type=""and"">
                          <filter type=""or"">
                            <condition attribute=""opportunityid"" operator=""eq"" value=""{fetchData.opportunityid/*51aa7ec8-d6d5-45bb-89b3-939126c659b4*/}"" />
                            <condition attribute=""niq_hostopportunity"" operator=""eq"" value=""{fetchData.niq_hostopportunity/*51aa7ec8-d6d5-45bb-89b3-939126c659b4*/}"" />
                          </filter>
                          <filter type=""and"">
                            <condition attribute=""niq_stage"" operator=""ne"" value=""Closed Lost""/>
                          </filter>
                        </filter>
                      </link-entity>
                    </link-entity>
                  </entity>
                </fetch>";

            List<JsonObject> quotoProducts = await OAuthHelpher.RetrieveAllUsingFetchXML("quotedetails", fetchXml);
            JsonObject data = new JsonObject()
            {
                ["value"] = System.Text.Json.JsonSerializer.SerializeToNode(quotoProducts).AsArray()
            };
            string final = data.ToJsonString(new JsonSerializerOptions { WriteIndented = true });
            //Console.WriteLine(final);
            return final;
        }
        public async Task<string> getItemCategoryMtDtPayload()
        {
            Console.WriteLine("\n ITEM CATEGORY METADATA\n─────────────────────────────");
            string query = "?$select=niq_itemcategorygroup,niq_recurrent,niq_materialgroup4,niq_deliveryfrequency,niq_schedulelinedate,niq_orderquantity,niq_targetquantity,niq_fixedrate";
            JsonNode data = await OAuthHelpher.RetrieveAllUsingODataQuery("niq_itemcategorygroupmetadatas", query);
            JsonObject dat = new JsonObject()
            {
                ["value"] = data.DeepClone()
            };
            return dat.ToString();
        }

        public async Task<string> getQuoteDetailSchedulePayload()
        {
            Console.WriteLine("\n SCHEDULES\n─────────────────────────────");
            var fetchData = new
            {
                quantity = "0",
                niq_isrevshareline = "0",
                opportunityid = opportunityId,
                niq_hostopportunity = opportunityId
            };

            string fetchXml = $@"<fetch page=""1"">
                  <entity name=""niq_schedule"">
                    <attribute name=""niq_scheduleid"" />
                    <attribute name=""niq_amount"" />
                    <attribute name=""niq_amount_base"" />
                    <attribute name=""niq_name"" />
                    <attribute name=""niq_lineitemid"" />
                    <attribute name=""niq_scheduletype"" />
                    <attribute name=""niq_scheduledate"" />
                    <attribute name=""niq_calculatedscheduledate"" />
                    <order attribute=""niq_scheduledate"" descending=""false"" />
                    <link-entity name=""quotedetail"" from=""quotedetailid"" to=""niq_lineitemid"" link-type=""inner"" alias=""cg"">
                      <filter type=""and"">
                        <condition attribute=""quantity"" operator=""gt"" value=""{fetchData.quantity/*0*/}"" />
                        <condition attribute=""niq_isrevshareline"" operator=""eq"" value=""{fetchData.niq_isrevshareline/*0*/}"" />
                      </filter>
                      <link-entity name=""quote"" from=""quoteid"" to=""quoteid"" link-type=""inner"" alias=""ch"">
                        <link-entity name=""opportunity"" from=""opportunityid"" to=""opportunityid"" link-type=""inner"" alias=""ci"">
                          <filter type=""and"">
                            <filter type=""or"">
                              <condition attribute=""opportunityid"" operator=""eq"" value=""{fetchData.opportunityid}"" />
                              <condition attribute=""niq_hostopportunity"" operator=""eq"" value=""{fetchData.niq_hostopportunity}"" />
                            </filter>
                          </filter>
                        </link-entity>
                      </link-entity>
                    </link-entity>
                  </entity>
                </fetch>";

            List<JsonObject> entities = await OAuthHelpher.RetrieveAllUsingFetchXML("niq_schedules", fetchXml);
            //Console.WriteLine(entities.ToArray());
            JsonObject data = new JsonObject()
            {
                ["value"] = System.Text.Json.JsonSerializer.SerializeToNode(entities).AsArray()
            };
            string final = data.ToJsonString(new JsonSerializerOptions { WriteIndented = true });
            //Console.WriteLine(final);
            return final;
        }

        public string setOrganizationName(IOrganizationService service, string payload)
        {
            QueryExpression query = new QueryExpression("organization")
            {
                ColumnSet = new ColumnSet("name")
            };
            EntityCollection org = service.RetrieveMultiple(query);
            XElement finalpayload = XElement.Parse(payload);
            if (org.Entities.Count > 0)
            {
                string organizationName = org.Entities[0].GetAttributeValue<string>("name");
                Console.WriteLine("Organization Name :" + organizationName);
                XElement collectiveNumber = finalpayload.Element("CollectiveNumber");
                if (collectiveNumber != null)
                    collectiveNumber.Value = organizationName;
            }
            //Console.WriteLine(finalpayload.ToString());
            return
                "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:con=\"http://nielsen.com/MSDynamics-CRM/Contract\">" +
                "<soapenv:Header/>" +
                "<soapenv:Body>" +
                "<con:MT_MSDContractAsync_Req>" + finalpayload.ToString() +
                "</con:MT_MSDContractAsync_Req>" +
                "</soapenv:Body>" +
                "</soapenv:Envelope>";
        }
        public async Task<string> triggerIntegration(IOrganizationService service,string payload)
        {
            Console.WriteLine("\n TRIGGERING SAP INTEGRATION ... \n────────────────────────────-");
            string data = "";
            var query_niq_name = "PA_HTTP_Consoleapp_SapIntegration";
            var query = new QueryExpression("niq_configurationsetting");
            query.ColumnSet.AddColumn("niq_to");
            query.Criteria.AddCondition("niq_name", ConditionOperator.Equal, query_niq_name);
            EntityCollection configs = service.RetrieveMultiple(query);
            if (configs.Entities.Count > 0) { 
                Entity config = configs.Entities[0];
                string url = config.GetAttributeValue<string>("niq_to");
                if (!string.IsNullOrEmpty(url)) {
                    var client = new HttpClient();
                    var request = new HttpRequestMessage(HttpMethod.Post, "https://1c6b2725a831e086b1ce0a612480fc.4b.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/f3ee463ec8404593b7ae23c37f27b17d/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=YybPzUP9jClSIf4r94IWsIm4SKRsN9PpckuIEIeeooU");
                    var content = new StringContent(payload);
                    request.Content = content;
                    var response = await client.SendAsync(request);
                    response.EnsureSuccessStatusCode();
                    data = await response.Content.ReadAsStringAsync();
                    //Console.WriteLine(data);
                }
            }                      
            return data;
        }

    }
}
