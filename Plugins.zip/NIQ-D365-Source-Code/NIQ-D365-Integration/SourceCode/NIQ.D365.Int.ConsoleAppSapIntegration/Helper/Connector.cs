﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.PowerPlatform.Dataverse.Client;

namespace NIQ.D365.Int.ConsoleAppSapIntegration.Helper
{
    internal class Connector
    {
        public static IOrganizationService GetXrmRealContext()
        {
            Console.WriteLine("\n DYNAMICS CONNECTION STATUS ... \n────────────────────────────-");
            //string strConnectionString = ConfigurationManager.AppSettings["CRMConnection"];
            string envUrl = ConfigurationManager.AppSettings["EnvUrl"];
            string clientId = ConfigurationManager.AppSettings["ClientId"];
            string clientSecret = ConfigurationManager.AppSettings["ClientSecret"];
            string strConnectionString = $"AuthType=ClientSecret;url={envUrl};ClientId={clientId};ClientSecret={clientSecret}";
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            IOrganizationService service = new ServiceClient(strConnectionString);

            Guid orgid = ((WhoAmIResponse)service.Execute(new WhoAmIRequest())).OrganizationId;
            Console.WriteLine("Connected Successfully\nUser Id :" + orgid);
            return service;
        }
    }
}
