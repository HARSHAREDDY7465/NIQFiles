﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Linq;

namespace NIQ.D365.Int.ConsoleAppSapIntegration.Helper
{
    internal class AccessToken
    {
        public string token_type { get; set; }
        public int expires_in { get; set; }
        public int ext_expires_in { get; set; }
        public string access_token { get; set; }
    }

    public class OAuthHelpher
    {
        private static string accessToken;
        public async static Task<string> getAccessToken()
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "https://login.microsoftonline.com/6ac7a1f4-5fb1-4153-bb4f-12d2020a1f7d/oauth2/v2.0/token");
            //request.Headers.Add("Cookie", "fpc=AspCFemLDh9Dqf2RsazbCzVdM2KOAQAAAB1Fv-AOAAAA; stsservicecookie=estsfd; x-ms-gateway-slice=estsfd");
            string envUrl = ConfigurationManager.AppSettings["EnvUrl"];
            string clientId = ConfigurationManager.AppSettings["ClientId"];
            string clientSecret = ConfigurationManager.AppSettings["ClientSecret"];
            Dictionary<string, string> formData = new Dictionary<string, string>
            {
                {"grant_type", "client_credentials" },
                { "client_id", clientId},
                { "client_secret", clientSecret},
                { "Content-Type", "application/x-www-form-urlencoded"},
                {"scope", envUrl+".default" }
            };
            var content = new FormUrlEncodedContent(formData);
            request.Content = content;
            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();
            string result = await response.Content.ReadAsStringAsync();
            JsonNode json = JsonNode.Parse(result);
            //Console.WriteLine(json["access_token"]);
            //AccessToken accessToken = JsonConvert.DeserializeObject<AccessToken>(result);           
            Console.WriteLine("Access token acquired");
            accessToken = json["access_token"].ToString();
            return json["access_token"].ToString();

        }
        public async static Task<List<JsonObject>> RetrieveAllUsingFetchXML(string entityName, string fetchXml)
        {
            List<JsonObject> entities = new List<JsonObject>();
            XElement fetchNode = XElement.Parse(fetchXml);
            int page = 1;
            fetchNode.SetAttributeValue("page", page);
            //Console.WriteLine(fetchNode);
            HttpClient client = new HttpClient();

            while (true)
            {
                bool moreRecords = true;
                string pageCookie = null;
                HttpRequestMessage request = new HttpRequestMessage
                {
                    Method = HttpMethod.Get,
                    RequestUri = new Uri(
                        uriString: $"https://niqd365ceuat.crm4.dynamics.com/api/data/v9.0/{entityName}?fetchXml={HttpUtility.UrlEncode(fetchNode.ToString())}")
                };
                request.Headers.Add("Authorization", "Bearer " + accessToken);
                request.Headers.Add("OData-MaxVersion", "4.0");
                request.Headers.Add("OData-Version", "4.0");
                //request.Headers.Add("If-None-Match", "null");
                request.Headers.Add("Accept", "application/json;odata.metadata=minimal");
                //request.Headers.Add("Prefer", "odata.include-annotations=\"Microsoft.Dynamics.CRM.fetchxmlpagingcookie,Microsoft.Dynamics.CRM.morerecords,OData.Community.Display.V1.FormattedValue\"");
                request.Headers.Add("Prefer", "odata.include-annotations=\"*\"");

                var response = await client.SendAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    string jsonContent = await response.Content.ReadAsStringAsync();
                    JsonObject content = JsonNode.Parse(jsonContent)?.AsObject();
                    content.TryGetPropertyValue("value", out JsonNode records);
                    entities.AddRange(records.AsArray().Cast<JsonObject>());
                    Console.WriteLine($"Page: {page}  |  Retrieved records :" + entities.Count);

                    moreRecords = content.TryGetPropertyValue("@Microsoft.Dynamics.CRM.morerecords", out _);
                    if (moreRecords)
                    {
                        if (content.TryGetPropertyValue("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie", out JsonNode fetchXmlPageCookie))
                        {
                            pageCookie = fetchXmlPageCookie.AsValue().ToString();
                        }
                    }
                }
                else
                {
                    throw new Exception($"Web api call failed with status code :{response.StatusCode}");
                }

                if (!moreRecords)
                {
                    Console.WriteLine("Total Number of records retrieved :" + entities.Count);
                    break;
                }
                XElement cookieElement = XElement.Parse(pageCookie);
                XAttribute pagingCookieAttribute = cookieElement.Attribute("pagingcookie");
                pageCookie = HttpUtility.UrlDecode(pagingCookieAttribute.Value);

                //fetchNode.SetAttributeValue("paging-cookie", pageCookie);
                fetchNode.SetAttributeValue("page", ++page);

            }
            //JsonObject s = new

            //Console.WriteLine(new JsonObject().Add("value",new JsonArray(entities.ToArray())));


            return entities;
        }
        public async static Task<JsonNode> RetrieveAllUsingODataQuery(string entityName, string query)
        {
            JsonNode result = "";
            HttpClient client = new HttpClient();
            HttpRequestMessage request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri(
                    uriString: $"https://niqd365ceuat.crm4.dynamics.com/api/data/v9.0/{entityName}{query}")
            };
            request.Headers.Add("Authorization", "Bearer " + accessToken);
            request.Headers.Add("OData-MaxVersion", "4.0");
            request.Headers.Add("OData-Version", "4.0");
            //request.Headers.Add("If-None-Match", "null");
            request.Headers.Add("Accept", "application/json;odata.metadata=minimal");
            //request.Headers.Add("Prefer", "odata.include-annotations=\"Microsoft.Dynamics.CRM.fetchxmlpagingcookie,Microsoft.Dynamics.CRM.morerecords,OData.Community.Display.V1.FormattedValue\"");
            request.Headers.Add("Prefer", "odata.include-annotations=\"*\"");

            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                string jsonContent = await response.Content.ReadAsStringAsync();
                JsonObject content = JsonNode.Parse(jsonContent)?.AsObject();
                content.TryGetPropertyValue("value", out JsonNode records);
                Console.WriteLine("Number of " + entityName + " retrieved : " + records.AsArray().Count);
                result = records;
            }
            else
            {
                string errorContent = await response.Content.ReadAsStringAsync();
                if (!string.IsNullOrEmpty(errorContent))
                {
                    Console.WriteLine("Error message: " + errorContent);
                }
                throw new Exception($"Web api call failed with status code :{response.StatusCode}");
            }
            return result;
        }
    }
}
