﻿using Microsoft.Crm.Sdk.Messages;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using NIQ.D365.Int.Custom.WF;
using Microsoft.PowerPlatform.Dataverse.Client;
using FakeXrmEasy;
using NIQ.D365.Int.ConsoleAppSapIntegration.Helper;
using NIQ.D365.Int.ConsoleAppSapIntegration.Utilities;
using System.Diagnostics;
using System.Text.Json.Nodes;

namespace NIQ.D365.Int.ConsoleAppSapIntegration
{
    internal class Program
    {
        private static string opportunityid;
        async static Task Main(string[] args)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            
            Console.WriteLine("USER INPUT \n─────────────────────────────");
            Console.WriteLine("Provide the opportunity id:");
            opportunityid = Console.ReadLine();
            Console.WriteLine("Input Opportunity ID: " + new Guid(opportunityid));

            IOrganizationService service = Connector.GetXrmRealContext();
            XrmRealContext fakedContext = new XrmRealContext(service);

            string accessToken = await OAuthHelpher.getAccessToken();

            TriggerSapIntegration triggerSapIntegration = new TriggerSapIntegration(opportunityid);
            JsonObject opportunityDetails = await triggerSapIntegration.getOpportunityDetails(opportunityid);


            var strOptyNQuotePayload = await triggerSapIntegration.getQuoteNOptyPayload(opportunityDetails);
            var strQuoteDetailPayload = await triggerSapIntegration.getQuoteDetailPayload(opportunityDetails);
            var strItemCategoryGrpMtDtPayload = await triggerSapIntegration.getItemCategoryMtDtPayload();
            var strQuoteDetailCharPayload = await triggerSapIntegration.getQuoteDetailCharacteristicPayload(opportunityDetails, strQuoteDetailPayload);
            var strQuoteDetailSchedulePayload = await triggerSapIntegration.getQuoteDetailSchedulePayload();

            Dictionary<string, object> inputs = new Dictionary<string, object>()
            {
                { "OpportunityId", opportunityid },
                { "QuoteNOptyPayload", strOptyNQuotePayload },
                { "QuoteDetailPayload", strQuoteDetailPayload },
                { "QuoteDetailCharPayload", strQuoteDetailCharPayload },
                { "ItemCategoryGrpMtDtPayload", strItemCategoryGrpMtDtPayload },
                { "QuoteDetailSchedulePayload", strQuoteDetailSchedulePayload }
            };

            Console.WriteLine("\n SAP PAYLOAD\n─────────────────────────────");
            Console.WriteLine("Payload generation in progress...");
            var result = fakedContext.ExecuteCodeActivity<GetSAPContractPayload>(inputs, null);
            Console.WriteLine("Payload generation completed !!!");
            string payload = triggerSapIntegration.setOrganizationName(service, result["SAPContractPayload"].ToString());

            string aftersap = await triggerSapIntegration.triggerIntegration(service,payload);
            Console.WriteLine(aftersap);
            triggerSapIntegration.uploadfiletoMSD(service, payload);
            stopwatch.Stop();
            TimeSpan timeSpan = stopwatch.Elapsed;

            Console.WriteLine("\n TIME TAKEN BY CONSOLE APP\n─────────────────────────────");
            Console.WriteLine("Total minutes taken:" + timeSpan.TotalMinutes);
            Console.WriteLine("Total seconds taken:" + timeSpan.TotalSeconds);
            Console.WriteLine("\n SAP integration has been successfully initiated from MSD. Closing the console app will not affect the process.");
            Console.ReadLine();

        }
    }
}
