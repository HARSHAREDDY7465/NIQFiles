﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Microsoft.Xrm.Tooling.Connector;
using System.Windows;

namespace NIQ.D365.PAFlow.Manager
{
   
    public class Utility
    {
       public IOrganizationService service;
        ITracingService tracingService;

        public void Connection()
        {
            try
            {
                string strConnectionString = ConfigurationManager.AppSettings["CRMConnection"];

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                CrmServiceClient con = new CrmServiceClient(strConnectionString);

                if (con.OrganizationWebProxyClient != null)
                    service = con.OrganizationWebProxyClient;
                else
                    service = con.OrganizationServiceProxy;


                Guid orgid = ((WhoAmIResponse)service.Execute(new WhoAmIRequest())).OrganizationId;
               // this.lbl_CRMURL.Text = con.OrganizationDetail.Endpoints[EndpointType.WebApplication];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection is failed" + ex.Message);
                throw ex;
            }
        }
        public Utility()
        {
            Connection();
        }
        public Utility(IOrganizationService service, ITracingService tracingService)
        {
            this.service = service;
            this.tracingService = tracingService;
        }
        public List<Entity> GetRecordsbyFetchxml(string fetchXml)
        {
            try
            {
                EntityCollection objEntity = service.RetrieveMultiple(new FetchExpression(fetchXml));
                if (objEntity != null && objEntity.Entities != null && objEntity.Entities.Count > 0)
                    return objEntity.Entities.ToList();
                return null;
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetDatabyFetchxml=" + fetchXml);

                throw ex;
            }
        }

        public RetrieveCurrentOrganizationResponse GetCurrentOrgInfo()
        {

            try
            {
                RetrieveCurrentOrganizationRequest orgReq = new RetrieveCurrentOrganizationRequest();
                orgReq.AccessType = Microsoft.Xrm.Sdk.Organization.EndpointAccessType.Default;
                return service.Execute(orgReq) as RetrieveCurrentOrganizationResponse;

            }
            catch (Exception ex)
            {
                tracingService.Trace("GetCurrentOrgInfo");
                throw ex;
            }
        }
        public Entity GetRecordbyId(string entityName,Guid Id,string[] columns)
        {
            try
            {
                ColumnSet column = new ColumnSet();
                column.AddColumns(columns);
               return service.Retrieve(entityName, Id, column);
              
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetRecordbyId=" + entityName + "," + Id.ToString());
                throw ex;
            }
        }
    }
}
