﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NIQ.D365.PAFlow.Manager
{
    public partial class PAFlowManager : Form
    {
        public PAFlowManager()
        {
            InitializeComponent();
        }

        Utility objUtility;
        DataTable table ;
        private void btn_LoadPAflow_Click(object sender, EventArgs e)
        {
            try
            {
                table.Rows.Clear();
                this.chkSelectAll.Checked = false;
                string strsols = "";
                string strPAFlowstatus = "";
                foreach (var item in this.chklst_Solutions.CheckedItems)
                {
                    strsols = strsols + string.Format("<value>{0}</value>",item.ToString().Split(':')[1]);
                }
                if (strsols.Trim().Length <= 1)
                {
                    MessageBox.Show("Please select one Solution in the list.");
                    return;
                }
                if (rdbtnActive.Checked)
                    strPAFlowstatus = "<condition attribute='statecode' operator='eq' value='1' />";
                else if (rdbtndraft.Checked)
                    strPAFlowstatus = "<condition attribute='statecode' operator='eq' value='0' />";

                string strFetchxml = string.Format(@"<fetch><entity name='workflow' >
        <attribute name='statecode' />
        <attribute name='description' />
        <attribute name='name' />
        <attribute name='statuscode' />
        <filter>
            {0}
            <condition attribute='category' operator='eq' value='5' />
      </filter>
        <link-entity name='solutioncomponent' from='objectid' to='workflowid' link-type='inner' >
            <link-entity name='solution' from='solutionid' to='solutionid' link-type='inner' alias='solution' >
                <attribute name='friendlyname' />
                <filter>
                    <condition attribute='solutionid' operator='in' >{1}</condition>
                </filter>
            </link-entity>
        </link-entity>
    </entity>
</fetch>", strPAFlowstatus, strsols );
                List<Entity> lstent = objUtility.GetRecordsbyFetchxml(strFetchxml);
                this.loadGrid(lstent);
              
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);

            }
        }
            private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                objUtility  = new Utility();
               loadSolutions();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
               
            }
        }
        void loadSolutions()
        {
            try
            {
                string strFetchxml = @"<fetch><entity name='solution'>
                                <attribute name='friendlyname' />
                                <attribute name='solutionid' />
                                <attribute name='uniquename' />
                                <order attribute='uniquename' />
                                <link-entity name='publisher' from='publisherid' to='publisherid'>
                                  <filter>
                                    <condition attribute='uniquename' operator='like' value='niq%' />
                                  </filter>
                                </link-entity>
                              </entity>
                            </fetch>";
                List<Entity> lstEnt= objUtility.GetRecordsbyFetchxml(strFetchxml);
                if (lstEnt != null)
                {
                    foreach (var ent in lstEnt)
                    {
                        this.chklst_Solutions.Items.Add(string.Format("{0}:{1}", ent["uniquename"].ToString(), ent["solutionid"].ToString()));


                    }

                }

                table = new DataTable();
                table.Columns.Add("Select", typeof(bool));
                table.Columns.Add("Id", typeof(Guid));
                table.Columns.Add("Name", typeof(string));
                table.Columns.Add("Status", typeof(string));
                table.Columns.Add("SolutionName", typeof(string));
                table.Columns.Add("Error", typeof(string));

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        void loadGrid(List<Entity> lstent)
        {
            try
            {
               

                foreach (var entity in lstent)
                {
                    var row = table.NewRow();
                    row["Select"] = false;
                    row["Id"] = entity.Id;
                    row["Name"] = entity["name"].ToString();
                    row["Status"] = entity.FormattedValues["statuscode"].ToString();
                    row["SolutionName"] = (entity["solution.friendlyname"] as AliasedValue).Value;
                    row["Error"] = "";
                    table.Rows.Add(row);
                }
                dgvw.DataSource = table.DefaultView;
            }
            catch (Exception ex)
            {
                    throw ex;
            }
        }

        private void chkSelectAll_CheckedChanged(object sender, EventArgs e)
        {
           
            foreach (DataRowView item in table.DefaultView)
            {
                item.Row["Select"] = this.chkSelectAll.Checked;

            }
        }

        private void txtSearchPAFlow_TextChanged(object sender, EventArgs e)
        {
            try
            {
                table.DefaultView.RowFilter = string.Format("Name LIKE '%{0}%'", txtSearchPAFlow.Text.Trim());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }


        private void btn_On_PAFlow_Click(object sender, EventArgs e)
        {
            OnOffFlow(1, 2);
        }

        private void btn_OffPAFlow_Click(object sender, EventArgs e)
        {
            OnOffFlow(0, 1);
        }
        void OnOffFlow(int statecode,int statuscode)
        {
            try
            {
                int i = 0;

                foreach (var item in this.dgvw.Rows)
                {
                    try
                    {

                        this.lbl_processrowcount.Text = string.Format("Processed Row Count : {0} of {1}", i.ToString(), this.dgvw.Rows.Count);
                        if ((item as DataGridViewRow).Cells[0].Value.ToString() == "False")
                        { i++; continue; }
                        SetStateRequest request = new SetStateRequest();

                        request.EntityMoniker = new EntityReference("workflow", Guid.Parse((item as DataGridViewRow).Cells[1].Value.ToString()));
                        request.State = new OptionSetValue(statecode);
                        request.Status = new OptionSetValue(statuscode);

                        SetStateResponse resp = (SetStateResponse)objUtility.service.Execute(request);
                        (item as DataGridViewRow).Cells[3].Value = statecode == 1 ? "Activated" : "Draft";
                        i++;
                        this.lbl_processrowcount.Text = string.Format("Processed Row Count : {0} of {1}", i.ToString(), this.dgvw.Rows.Count);
                    }
                    catch (Exception innerex)
                    {
                        (item as DataGridViewRow).Cells[5].Value = innerex.Message;
                       
                    }
                }
                dgvw.RefreshEdit();
                MessageBox.Show("Completed");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
    }
}
