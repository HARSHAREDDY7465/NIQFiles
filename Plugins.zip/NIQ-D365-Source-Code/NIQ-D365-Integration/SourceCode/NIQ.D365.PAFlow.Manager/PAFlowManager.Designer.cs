﻿namespace NIQ.D365.PAFlow.Manager
{
    partial class PAFlowManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btn_LoadPAflow = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.chklst_Solutions = new System.Windows.Forms.CheckedListBox();
            this.dgvw = new System.Windows.Forms.DataGridView();
            this.rdbtnActive = new System.Windows.Forms.RadioButton();
            this.rdbtndraft = new System.Windows.Forms.RadioButton();
            this.rdbtnAll = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.chkSelectAll = new System.Windows.Forms.CheckBox();
            this.txtSearchPAFlow = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_OnPAFlow = new System.Windows.Forms.Button();
            this.btn_OffPAFlow = new System.Windows.Forms.Button();
            this.lbl_processrowcount = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvw)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_LoadPAflow
            // 
            this.btn_LoadPAflow.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_LoadPAflow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LoadPAflow.Location = new System.Drawing.Point(544, 25);
            this.btn_LoadPAflow.Name = "btn_LoadPAflow";
            this.btn_LoadPAflow.Size = new System.Drawing.Size(115, 38);
            this.btn_LoadPAflow.TabIndex = 0;
            this.btn_LoadPAflow.Text = "Load PA Flows";
            this.btn_LoadPAflow.UseVisualStyleBackColor = false;
            this.btn_LoadPAflow.Click += new System.EventHandler(this.btn_LoadPAflow_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Solutions :";
            // 
            // chklst_Solutions
            // 
            this.chklst_Solutions.CheckOnClick = true;
            this.chklst_Solutions.FormattingEnabled = true;
            this.chklst_Solutions.Location = new System.Drawing.Point(19, 25);
            this.chklst_Solutions.Name = "chklst_Solutions";
            this.chklst_Solutions.Size = new System.Drawing.Size(350, 94);
            this.chklst_Solutions.TabIndex = 2;
            // 
            // dgvw
            // 
            this.dgvw.AllowUserToAddRows = false;
            this.dgvw.AllowUserToDeleteRows = false;
            this.dgvw.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvw.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvw.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvw.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvw.Location = new System.Drawing.Point(19, 161);
            this.dgvw.Name = "dgvw";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvw.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvw.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvw.ShowEditingIcon = false;
            this.dgvw.Size = new System.Drawing.Size(849, 216);
            this.dgvw.TabIndex = 3;
            // 
            // rdbtnActive
            // 
            this.rdbtnActive.AutoSize = true;
            this.rdbtnActive.Checked = true;
            this.rdbtnActive.Location = new System.Drawing.Point(404, 46);
            this.rdbtnActive.Name = "rdbtnActive";
            this.rdbtnActive.Size = new System.Drawing.Size(55, 17);
            this.rdbtnActive.TabIndex = 4;
            this.rdbtnActive.TabStop = true;
            this.rdbtnActive.Text = "Active";
            this.rdbtnActive.UseVisualStyleBackColor = true;
            // 
            // rdbtndraft
            // 
            this.rdbtndraft.AutoSize = true;
            this.rdbtndraft.Location = new System.Drawing.Point(404, 69);
            this.rdbtndraft.Name = "rdbtndraft";
            this.rdbtndraft.Size = new System.Drawing.Size(48, 17);
            this.rdbtndraft.TabIndex = 5;
            this.rdbtndraft.Text = "Draft";
            this.rdbtndraft.UseVisualStyleBackColor = true;
            // 
            // rdbtnAll
            // 
            this.rdbtnAll.AutoSize = true;
            this.rdbtnAll.Location = new System.Drawing.Point(404, 92);
            this.rdbtnAll.Name = "rdbtnAll";
            this.rdbtnAll.Size = new System.Drawing.Size(36, 17);
            this.rdbtnAll.TabIndex = 6;
            this.rdbtnAll.Text = "All";
            this.rdbtnAll.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(401, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "PA Flow Status";
            // 
            // chkSelectAll
            // 
            this.chkSelectAll.AutoSize = true;
            this.chkSelectAll.Location = new System.Drawing.Point(21, 141);
            this.chkSelectAll.Name = "chkSelectAll";
            this.chkSelectAll.Size = new System.Drawing.Size(70, 17);
            this.chkSelectAll.TabIndex = 8;
            this.chkSelectAll.Text = "Select All";
            this.chkSelectAll.UseVisualStyleBackColor = true;
            this.chkSelectAll.CheckedChanged += new System.EventHandler(this.chkSelectAll_CheckedChanged);
            // 
            // txtSearchPAFlow
            // 
            this.txtSearchPAFlow.Location = new System.Drawing.Point(204, 138);
            this.txtSearchPAFlow.Name = "txtSearchPAFlow";
            this.txtSearchPAFlow.Size = new System.Drawing.Size(364, 20);
            this.txtSearchPAFlow.TabIndex = 9;
            this.txtSearchPAFlow.TextChanged += new System.EventHandler(this.txtSearchPAFlow_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(156, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Search";
            // 
            // btn_OnPAFlow
            // 
            this.btn_OnPAFlow.BackColor = System.Drawing.Color.DarkGreen;
            this.btn_OnPAFlow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_OnPAFlow.ForeColor = System.Drawing.SystemColors.Window;
            this.btn_OnPAFlow.Location = new System.Drawing.Point(597, 122);
            this.btn_OnPAFlow.Name = "btn_OnPAFlow";
            this.btn_OnPAFlow.Size = new System.Drawing.Size(127, 36);
            this.btn_OnPAFlow.TabIndex = 11;
            this.btn_OnPAFlow.Text = "ON - PA Flows";
            this.btn_OnPAFlow.UseVisualStyleBackColor = false;
            this.btn_OnPAFlow.Click += new System.EventHandler(this.btn_On_PAFlow_Click);
            // 
            // btn_OffPAFlow
            // 
            this.btn_OffPAFlow.BackColor = System.Drawing.Color.Brown;
            this.btn_OffPAFlow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_OffPAFlow.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_OffPAFlow.Location = new System.Drawing.Point(740, 122);
            this.btn_OffPAFlow.Name = "btn_OffPAFlow";
            this.btn_OffPAFlow.Size = new System.Drawing.Size(127, 36);
            this.btn_OffPAFlow.TabIndex = 12;
            this.btn_OffPAFlow.Text = "OFF - PA Flows";
            this.btn_OffPAFlow.UseVisualStyleBackColor = false;
            this.btn_OffPAFlow.Click += new System.EventHandler(this.btn_OffPAFlow_Click);
            // 
            // lbl_processrowcount
            // 
            this.lbl_processrowcount.AutoSize = true;
            this.lbl_processrowcount.Location = new System.Drawing.Point(597, 92);
            this.lbl_processrowcount.Name = "lbl_processrowcount";
            this.lbl_processrowcount.Size = new System.Drawing.Size(122, 13);
            this.lbl_processrowcount.TabIndex = 13;
            this.lbl_processrowcount.Text = "Processed Row Count : ";
            // 
            // PAFlowManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(880, 394);
            this.Controls.Add(this.lbl_processrowcount);
            this.Controls.Add(this.btn_OffPAFlow);
            this.Controls.Add(this.btn_OnPAFlow);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSearchPAFlow);
            this.Controls.Add(this.chkSelectAll);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.rdbtnAll);
            this.Controls.Add(this.rdbtndraft);
            this.Controls.Add(this.rdbtnActive);
            this.Controls.Add(this.dgvw);
            this.Controls.Add(this.chklst_Solutions);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_LoadPAflow);
            this.Name = "PAFlowManager";
            this.Text = "PowerAutomate Flow Manager";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvw)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_LoadPAflow;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckedListBox chklst_Solutions;
        private System.Windows.Forms.DataGridView dgvw;
        private System.Windows.Forms.RadioButton rdbtnActive;
        private System.Windows.Forms.RadioButton rdbtndraft;
        private System.Windows.Forms.RadioButton rdbtnAll;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chkSelectAll;
        private System.Windows.Forms.TextBox txtSearchPAFlow;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_OnPAFlow;
        private System.Windows.Forms.Button btn_OffPAFlow;
        private System.Windows.Forms.Label lbl_processrowcount;
    }
}

