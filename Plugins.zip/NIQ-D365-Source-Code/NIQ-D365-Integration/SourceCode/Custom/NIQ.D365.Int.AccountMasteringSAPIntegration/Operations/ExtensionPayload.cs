﻿using System;
using Newtonsoft.Json;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using NIQ.D365.Int.AccountMasteringSAPIntegration.ExtensionModel;
using System.Linq;

namespace NIQ.D365.Int.AccountMasteringSAPIntegration.ExtensionPayload
{
    public static class ExtensionPayload
    {
        static List<Entity> accountMasterSupportDataList = new List<Entity>();
        static IOrganizationService Service;
        public static string SetRequestModel(Entity accountEntity, IOrganizationService service)
        {
            try
            {
                Service = service;
                accountMasterSupportDataList = Common.Common.GetSAPAccountSupportMasterData(service);
                List<Entity> salesOrgExtensionRequestList = Common.Common.GetSalesOrgExtentionRequests(service, accountEntity);
                List<Entity> salesOrgExtensionTaxCategoryList = Common.Common.GetSalesOrgExtentionTaxCategories(service, accountEntity);

                Root objRoot = new Root();

                if (objRoot.ZsdfmCustomerCreateGfk == null)
                {
                    objRoot.ZsdfmCustomerCreateGfk = new ZsdfmCustomerCreateGfk();
                }

                if (objRoot.ZsdfmCustomerCreateGfk.Customerinput == null)
                {
                    objRoot.ZsdfmCustomerCreateGfk.Customerinput = new Customerinput();
                }

                objRoot.ZsdfmCustomerCreateGfk.Customerinput.CustomerNumber = accountEntity.Attributes.Contains("niq_customernumber") ? accountEntity.Attributes["niq_customernumber"].ToString() : "";
                objRoot.ZsdfmCustomerCreateGfk.Customerinput.UpdateIndicator = "I";
                EntityCollection salesOrgExtensionRequestEC = RetrieveSalesOrgExtensionRequestData(service, accountEntity);
                objRoot.ZsdfmCustomerCreateGfk.Customerinput.CentralData = GenerateCentralData(accountEntity, salesOrgExtensionRequestList, salesOrgExtensionTaxCategoryList);
                objRoot.ZsdfmCustomerCreateGfk.Customerinput.CompanyData = GenerateCompanyData(accountEntity, salesOrgExtensionRequestList, salesOrgExtensionTaxCategoryList);
                objRoot.ZsdfmCustomerCreateGfk.Customerinput.SalesAreaData = GenerateSalesAreaDataData(accountEntity, salesOrgExtensionRequestList, salesOrgExtensionTaxCategoryList);

                string payloadStr = JsonConvert.SerializeObject(objRoot, new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore,
                    Formatting = Formatting.Indented
                });
                payloadStr = Regex.Replace(payloadStr, @"\b(\w+)_Prop\b", "$1");
                payloadStr = payloadStr.Replace("ZsdfmCustomerCreateGfk", "n0:ZsdfmCustomerCreateGfk");
                return payloadStr;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private static CentralData GenerateCentralData(Entity AccountRequest, List<Entity> salesOrgExtensionRequestList, List<Entity> salesOrgExtensionTaxCategoryList)
        {
            try
            {
                CentralData objcentralData = new CentralData();
                TaxInd objTaxInd = new TaxInd();
                objTaxInd.TaxInd_Prop = new TaxInd();
                objTaxInd.TaxInd_Prop.item = new List<Item>();

                List<Item> taxIndList = new List<Item>();
                
                foreach (Entity entity in salesOrgExtensionTaxCategoryList)
                {
                    if (entity.Attributes.Contains("niq_salesorgextension"))
                    {
                        taxIndList.Add(new Item()
                        {
                            DepartureCountry = Common.Common.GetCountryCodeOfSalesOrgFromSalesOrgExtension(entity, salesOrgExtensionRequestList, Service),
                            TaxCategory = entity.Attributes.Contains("niq_taxcategory") ? ((EntityReference)entity.Attributes["niq_taxcategory"])?.Name : "",
                            TaxClassification = Common.Common.GetTaxClassificationCode(entity, "niq_taxclassification", Service)
                        });
                    }
                }
                objTaxInd.TaxInd_Prop.item = taxIndList;

                return new CentralData()
                {
                    TaxInd = objTaxInd
                };

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        private static CompanyData GenerateCompanyData(Entity AccountRequest, List<Entity> salesOrgExtensionRequestList, List<Entity> salesOrgExtensionTaxCategoryList)
        {
            try
            {
                CompanyData objcompanydata = new CompanyData();
                objcompanydata.item = new List<Item>();
                List<Item> companyDataItems = new List<Item>();

                foreach (Entity entity in salesOrgExtensionRequestList)
                {
                    Data data = new Data();
                    data.CompanyCode = Common.Common.GetSalesOrgCode(entity, "niq_salesorg", Service);
                    data.ReconciliationAccount = Common.Common.GetGlAccountNumber(entity, "niq_glaccount", Service);
                    data.PaymentTerms = GetValueFromSupportData(entity, "niq_paymentterms");
                    data.AccountingClerk = GetValueFromSupportData(entity, "niq_accountingclerk");
                    data.HouseBank = GetValueFromSupportData(entity, "niq_housebank");
                    data.PreviousNumber = entity.Attributes.Contains("niq_previousnumber") ? entity.Attributes["niq_previousnumber"].ToString() : "";
                    data.PeriodicAcctStatmnts = entity.Attributes.Contains("niq_periodicacctstatements") ? entity.Attributes["niq_periodicacctstatements"].ToString() : "";
                    data.RecordPaymentHistory = AccountRequest.Attributes.Contains("niq_recordpaymenthistory") ? AccountRequest.Attributes["niq_recordpaymenthistory"].ToString() : "";
                    data.ARPledgingIndi = GetValueFromSupportData(entity, "niq_arpledging");

                    //Dunning
                    List<Item> dunningItems = new List<Item>();
                    dunningItems.Add(new Item()
                    {
                        DunningProcedure = GetValueFromSupportData(entity, "niq_dunningprocedure"),
                        DunningClerk = ""
                    });

                    Dunning objDunning_Prop = new Dunning();
                    objDunning_Prop.item = dunningItems;

                    Dunning objDunning = new Dunning();
                    objDunning.Dunning_Prop = objDunning_Prop;


                    //Wtaxtype
                    List<Item> wtaxTypeItems = new List<Item>();
                    wtaxTypeItems.Add(new Item()
                    {
                        WithholdingTaxType = entity.Attributes.Contains("niq_withholdingtaxtype") ? entity.Attributes["niq_withholdingtaxtype"].ToString() : "",
                        WithholdingTaxCode = entity.Attributes.Contains("niq_withholdingtaxcode") ? entity.Attributes["niq_withholdingtaxcode"].ToString() : "",
                        WithholdingTaxAgent = entity.Attributes.Contains("niq_withholdingtaxagent") ? entity.Attributes["niq_withholdingtaxagent"].ToString() : "",
                        WithholdTaxValidFrom = Common.Common.GetFormattedDate(entity, "niq_withholdtaxvalidfrom"),
                        WithholdTaxValidTo = Common.Common.GetFormattedDate(entity, "niq_withholdtaxvalidto"),
                    });

                    WtaxType objWtaxType_Prop = new WtaxType();
                    objWtaxType_Prop.item = wtaxTypeItems;

                    WtaxType objWtaxType = new WtaxType();
                    objWtaxType.WtaxType_Prop = objWtaxType_Prop;

                    companyDataItems.Add(new Item()
                    {
                        Data = data,
                        Dunning = objDunning,
                        WtaxType = objWtaxType,
                    });

                }

                objcompanydata.item = companyDataItems;
                return objcompanydata;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private static SalesAreaData GenerateSalesAreaDataData(Entity AccountRequest, List<Entity> salesOrgExtensionRequestList, List<Entity> salesOrgExtensionTaxCategoryList)
        {
            try
            {
                SalesAreaData objSalesAreaData = new SalesAreaData();
                objSalesAreaData.item = new List<Item>();
                List<Item> salesAreaDataItems = new List<Item>();

                foreach (Entity entity in salesOrgExtensionRequestList)
                {

                    Data data = new Data();
                    data.SalesOrganization = Common.Common.GetSalesOrgCode(entity, "niq_salesorg", Service);
                    data.DistributionChannel = entity.Attributes.Contains("niq_distributionchannel") ? entity.Attributes["niq_distributionchannel"].ToString() : "";
                    data.Division = entity.Attributes.Contains("niq_division") ? entity.Attributes["niq_division"].ToString() : "";
                    data.CustomerOrderBlock = GetValueFromSupportData(entity, "niq_customerorderblock");
                    data.PricingProcedure = GetValueFromSupportData(entity, "niq_pricingprocedure");
                    data.ShipperAccountNo = entity.Attributes.Contains("niq_shipperaccountno") ? entity.Attributes["niq_shipperaccountno"].ToString() : "";
                    data.Currency = Common.Common.GetCurrencyCode(entity, "niq_currency", Service);
                    data.AcctAssignGroup = GetValueFromSupportData(entity, "niq_accountassigngroup");
                    data.PaymentTerms = GetValueFromSupportData(entity, "niq_paymentterms");
                    data.DeliveringPlant = Common.Common.GetSalesOrgCode(entity, "niq_deliveringplant", Service);
                    data.SalesGroup = Common.Common.GetSalesGroupCode(entity, "niq_salesgroup", Service);
                    data.SalesOffice = Common.Common.GetSalesOfficeCode(entity, "niq_salesoffice", Service);
                    data.CustomerGroup1 = GetValueFromSupportData(entity, "niq_customergroup1");
                    data.CustomerGroup2 = GetValueFromSupportData(entity, "niq_customergroup2");
                    data.CustomerGroup3 = GetValueFromSupportData(entity, "niq_customergroup3");
                    data.CustomerGroup4 = GetValueFromSupportData(entity, "niq_customergroup4");
                    data.CustomerGroup5 = GetValueFromSupportData(entity, "niq_customergroup5");

                    List<Item> functionsItemList = new List<Item>();
                    functionsItemList.Add(new Item()
                    {
                        PartnerFunction = GetValueFromSupportData(entity, "niq_partnerfunction"),
                        Partner = "0000001001" //entity.Attributes.Contains("niq_accountpayableapcontact") ? entity.GetAttributeValue<EntityReference>("niq_accountpayableapcontact").Id.ToString() : ""
                    });

                    Functions objFunctions_Prop = new Functions();
                    objFunctions_Prop.item = functionsItemList;

                    Functions objFunction = new Functions();
                    objFunction.Functions_Prop = objFunctions_Prop;

                    salesAreaDataItems.Add(new Item()
                    {
                        Data = data,
                        Functions = objFunction
                    });

                }

                objSalesAreaData.item = salesAreaDataItems;
                return objSalesAreaData;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static EntityCollection RetrieveSalesOrgExtensionRequestData(IOrganizationService service, Entity Accountrequest)
        {
            QueryExpression query = new QueryExpression("niq_salesorgextensionrequest")
            {
                ColumnSet = new ColumnSet(true),
                Criteria = new FilterExpression
                {
                    Conditions = { new ConditionExpression("niq_accountrequest", ConditionOperator.Equal, Accountrequest.Id) }
                }
            };
            EntityCollection salesOrgExtensionRequestEC = service.RetrieveMultiple(query);
            return salesOrgExtensionRequestEC.Entities.Count > 0 ? salesOrgExtensionRequestEC : null;
        }
        private static EntityCollection RetrieveSalesOrgExtensionRequestTaxClassificationData(IOrganizationService service, Entity salesOrgExtensionRequestEntity)
        {
            QueryExpression query = new QueryExpression("niq_salesorgextensiontaxcategory")
            {
                ColumnSet = new ColumnSet(true),
                Criteria = new FilterExpression
                {
                    Conditions = { new ConditionExpression("niq_salesorgextension", ConditionOperator.Equal, salesOrgExtensionRequestEntity.Id) }
                }
            };
            EntityCollection salesOrgExtensionRequestTaxClassificationEC = service.RetrieveMultiple(query);
            return salesOrgExtensionRequestTaxClassificationEC.Entities.Count > 0 ? salesOrgExtensionRequestTaxClassificationEC : null;
        }
        private static string GetEntityReferenceValue(IOrganizationService service, Entity Accountrequest, string attributeName, string masterValueAttributeName)
        {
            if (Accountrequest.Contains(attributeName))
            {
                EntityReference entityRef = Accountrequest.GetAttributeValue<EntityReference>(attributeName);
                if (entityRef != null)
                {
                    Entity retrievedEntity = service.Retrieve(entityRef.LogicalName, entityRef.Id, new ColumnSet(masterValueAttributeName));
                    return retrievedEntity.Contains(masterValueAttributeName) ? retrievedEntity.GetAttributeValue<string>(masterValueAttributeName) : "";
                }
            }
            return "";
        }
        private static string GetValueFromSupportData(Entity AccountRequest, string fieldLogicalName)
        {
            string masterValue = string.Empty;
            if (AccountRequest.Attributes.Contains(fieldLogicalName))
            {
                EntityReference SapAccountSupportMasterRef = AccountRequest.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity SapAccountSupportMasterEntity = accountMasterSupportDataList.Where(e => e.Id == SapAccountSupportMasterRef.Id).FirstOrDefault();
                if (SapAccountSupportMasterEntity != null && SapAccountSupportMasterEntity.Attributes.Contains("niq_mastervalue"))
                {
                    masterValue = SapAccountSupportMasterEntity.GetAttributeValue<string>("niq_mastervalue");
                }
            }

            if (masterValue == string.Empty)
                return "";
            else
                return masterValue;
        }
    }
}