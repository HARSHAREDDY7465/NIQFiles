﻿using NIQ.D365.Int.AccountMasteringSAPIntegration.CreationModel;
using NIQ.D365.Int.AccountMasteringSAPIntegration.Common;
using Microsoft.Xrm.Sdk;
using System;
using Newtonsoft.Json;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;
using System.Text.RegularExpressions;

namespace NIQ.D365.Int.AccountMasteringSAPIntegration.CreationPayload
{
    public static class CreationPayload
    {
        static List<Entity> accountMasterSupportDataList = new List<Entity>();
        static IOrganizationService Service;
        static ITracingService tracingService;

        public static string SetRequestModel(Entity accountEntity, IOrganizationService service, ITracingService tracing)
        {
            try
            {
                Service = service;
                tracingService = tracing;
                accountMasterSupportDataList = Common.Common.GetSAPAccountSupportMasterData(service);
                List<Entity> salesOrgExtensionRequestList = Common.Common.GetSalesOrgExtentionRequests(service, accountEntity);
                List<Entity> salesOrgExtensionTaxCategoryList = Common.Common.GetSalesOrgExtentionTaxCategories(service, accountEntity);
                Root objRoot = new Root();

                tracingService.Trace($@"accountMasterSupportDataList: {accountMasterSupportDataList.Count}");
                tracingService.Trace($@"salesOrgExtensionRequestList: {salesOrgExtensionRequestList.Count}");
                tracingService.Trace($@"salesOrgExtensionTaxCategoryList: {salesOrgExtensionTaxCategoryList.Count}");

                if (objRoot.n0ZsdfmCustomerCreateGfk == null)
                {
                    objRoot.n0ZsdfmCustomerCreateGfk = new N0ZsdfmCustomerCreateGfk();
                }

                if (objRoot.n0ZsdfmCustomerCreateGfk.Customerinput == null)
                {
                    objRoot.n0ZsdfmCustomerCreateGfk.Customerinput = new Customerinput();
                }

                objRoot.n0ZsdfmCustomerCreateGfk.Customerinput.CustomerNumber = accountEntity.Attributes.Contains("niq_customernumber") ? accountEntity.GetAttributeValue<string>("niq_customernumber") : "";
                objRoot.n0ZsdfmCustomerCreateGfk.Customerinput.SARNumber = accountEntity.Attributes.Contains("niq_name") ? accountEntity.GetAttributeValue<string>("niq_name") : null;
                objRoot.n0ZsdfmCustomerCreateGfk.Customerinput.UpdateIndicator = "I";
                objRoot.n0ZsdfmCustomerCreateGfk.Customerinput.CentralData = GenerateCentralData(accountEntity, salesOrgExtensionRequestList, salesOrgExtensionTaxCategoryList);
                objRoot.n0ZsdfmCustomerCreateGfk.Customerinput.CompanyData = GenerateCompanyData(accountEntity, salesOrgExtensionRequestList, salesOrgExtensionTaxCategoryList);
                objRoot.n0ZsdfmCustomerCreateGfk.Customerinput.SalesAreaData = GenerateSalesAreaDataData(accountEntity, salesOrgExtensionRequestList, salesOrgExtensionTaxCategoryList);

                string payloadStr = JsonConvert.SerializeObject(objRoot, new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore, // Removes null properties
                    Formatting = Formatting.Indented // Makes JSON output readable (optional)
                });
                payloadStr = payloadStr.Replace("n0ZsdfmCustomerCreateGfk", "n0:ZsdfmCustomerCreateGfk");
                payloadStr = Regex.Replace(payloadStr, @"\b(\w+)_Prop\b", "$1");
                return payloadStr;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static CentralData GenerateCentralData(Entity AccountRequest, List<Entity> salesOrgExtensionRequestList, List<Entity> salesOrgExtensionTaxCategoryList)
        {
            tracingService.Trace("GenerateCentralData Start");
            try
            {
                CentralData objcentralData = new CentralData();
                Central objCentral = new Central()
                {
                    Partnercategory = GetValueFromSupportData(AccountRequest, "niq_legalsapaccountgroup"),
                    Partnergroup = GetValueFromSupportData(AccountRequest, "niq_legalsapaccountgrouptype"),
                    Partnerrole = "",
                    Partnertype = GetValueFromSupportData(AccountRequest, "niq_legalsapaccounttype"),
                    TitleKey = "",
                    Industrysector = GetValueFromSupportData(AccountRequest, "niq_industrysector"),
                    ChkDigit = "",
                    GroupKey = Common.Common.GetHFMCode(AccountRequest, "niq_hfmclientcodeid", Service),
                    Taxtype1 = Common.Common.GetTaxNumberCategoryCode(AccountRequest, "niq_taxtype1", Service),
                    TaxNumber1 = AccountRequest.Attributes.Contains("niq_taxnumber1") ? AccountRequest.Attributes["niq_taxnumber1"].ToString() : "",
                    Taxtype2 = Common.Common.GetTaxNumberCategoryCode(AccountRequest, "niq_taxtype2", Service),
                    TaxNumber2 = AccountRequest.Attributes.Contains("niq_taxnumber2") ? AccountRequest.Attributes["niq_taxnumber2"].ToString() : "",
                    Taxtype3 = Common.Common.GetTaxNumberCategoryCode(AccountRequest, "niq_taxtype3", Service),
                    TaxNumber3 = AccountRequest.Attributes.Contains("niq_taxnumber3") ? AccountRequest.Attributes["niq_taxnumber3"].ToString() : "",
                    Taxtype4 = Common.Common.GetTaxNumberCategoryCode(AccountRequest, "niq_taxtype4", Service),
                    TaxNumber4 = AccountRequest.Attributes.Contains("niq_taxnumber4") ? AccountRequest.Attributes["niq_taxnumber4"].ToString() : "",
                    Taxtype5 = Common.Common.GetTaxNumberCategoryCode(AccountRequest, "niq_taxtype5", Service),
                    TaxNumber5 = AccountRequest.Attributes.Contains("niq_taxnumber5") ? AccountRequest.Attributes["niq_taxnumber5"].ToString() : "",
                    IndustryKey = "01",
                    IndustryCode1 = GetValueFromSupportData(AccountRequest, "niq_industrycode")
                };
                tracingService.Trace("Central End");

                string sapAccountName = AccountRequest.Attributes.Contains("niq_sapaccountname") ? AccountRequest.Attributes["niq_sapaccountname"].ToString() : "";
                string name1 = sapAccountName.Length > 40 ? sapAccountName.Substring(0, 40) : sapAccountName;
                string name2 = sapAccountName.Length > 80 ? sapAccountName.Substring(40, 40) : (sapAccountName.Length > 40 ? sapAccountName.Substring(40) : "");
                string name3 = sapAccountName.Length > 120 ? sapAccountName.Substring(80, 40) : (sapAccountName.Length > 80 ? sapAccountName.Substring(80) : "");
                string name4 = sapAccountName.Length > 140 ? sapAccountName.Substring(120, 20) : (sapAccountName.Length > 120 ? sapAccountName.Substring(120) : "");

                string countryCode = Common.Common.GetCountryCode(AccountRequest, "niq_country", Service);
                string districtStr = AccountRequest.Attributes.Contains("niq_district") ? AccountRequest.Attributes["niq_district"].ToString() : null;
                if (countryCode == "US")
                {
                    districtStr = "";
                }

                tracingService.Trace("AddressData Start");
                AddressData objAddressData = new AddressData()
                {
                    Nation = "",
                    DateTo = "",
                    Title = "",
                    Name1 = name1 != "" ? name1 : null,
                    Name2 = name2 != "" ? name2 : null,
                    Name3 = name3 != "" ? name3 : null,
                    Name4 = name4 != "" ? name4 : null,
                    NameCo = AccountRequest.Attributes.Contains("niq_nameco") ? AccountRequest.Attributes["niq_nameco"].ToString() : "",
                    City1 = AccountRequest.Attributes.Contains("niq_city") ? AccountRequest.Attributes["niq_city"].ToString() : "",
                    District = districtStr,
                    PostCode1 = AccountRequest.Attributes.Contains("niq_zipcode") ? AccountRequest.Attributes["niq_zipcode"].ToString() : "",
                    PoBox = "",
                    Street = AccountRequest.Attributes.Contains("niq_street") ? AccountRequest.Attributes["niq_street"].ToString() : "",
                    HouseNum1 = AccountRequest.Attributes.Contains("niq_housenumber") ? AccountRequest.Attributes["niq_housenumber"].ToString() : "",
                    HouseNum2 = "",
                    Street1 = AccountRequest.Attributes.Contains("niq_street1") ? AccountRequest.Attributes["niq_street1"].ToString() : "",
                    Street2 = AccountRequest.Attributes.Contains("niq_street2") ? AccountRequest.Attributes["niq_street2"].ToString() : "",
                    Street3 = AccountRequest.Attributes.Contains("niq_street3") ? AccountRequest.Attributes["niq_street3"].ToString() : "",
                    Location = AccountRequest.Attributes.Contains("niq_location") ? AccountRequest.Attributes["niq_location"].ToString() : "",
                    Building = "",
                    Floor = "",
                    Roomnumber = "",
                    Country = countryCode,
                    Langu = GetValueFromSupportData(AccountRequest, "niq_language"),
                    Region = Common.Common.GetRegionCode(AccountRequest, "niq_state", Service),
                    SearchTerm1 = AccountRequest.Attributes.Contains("niq_searchterm") ? AccountRequest.Attributes["niq_searchterm"].ToString() : "",
                    SearchTerm2 = "",
                    TelNumber = AccountRequest.Attributes.Contains("niq_telnumber") ? AccountRequest.Attributes["niq_telnumber"].ToString() : "",
                    TelExtens = "",
                    FaxNumber = AccountRequest.Attributes.Contains("niq_faxnumber") ? AccountRequest.Attributes["niq_faxnumber"].ToString() : "",
                    FaxExtens = "",
                    CommunicationMethod = GetValueFromSupportData(AccountRequest, "niq_communicationmethod"),
                    EmailId = AccountRequest.Attributes.Contains("niq_email") ? AccountRequest.Attributes["niq_email"].ToString() : "",
                    Taxjurcode = AccountRequest.Attributes.Contains("niq_taxjurcode") ? AccountRequest.Attributes["niq_taxjurcode"].ToString() : "",
                    County = "",
                    Township = ""

                };
                tracingService.Trace("AddressData End");

                //Text
                Texts objTexts = new Texts();
                objTexts.item = new List<Item>();
                objTexts.item.Add(new Item()
                {
                    TextId = "",
                    Langu = "",
                    Languiso = "",
                    Texts = ""
                });
                Text objText = new Text();
                objText.Texts = objTexts;


                tracingService.Trace("VatNumbers Start");
                //Check VAT Requirement from Country
                bool isVatRequired = Common.Common.GetIsVatRequiredFromCountry(AccountRequest, "niq_countrykey", Service);
                //VatNumbers
                VatNumbers objVatNumbers = new VatNumbers();
                objVatNumbers.item = new List<Item>();
                objVatNumbers.item.Add(new Item()
                {
                    CountryKey = isVatRequired ? Common.Common.GetCountryCode(AccountRequest, "niq_countrykey", Service) : "",
                    VatType = isVatRequired ? Common.Common.GetTaxNumberCategoryCode(AccountRequest, "niq_vattype", Service) : "",
                    VATRegistrationNumber = isVatRequired ? (AccountRequest.Attributes.Contains("niq_vatregistrationnumber") ? AccountRequest.Attributes["niq_vatregistrationnumber"].ToString() : "") : ""
                });
                VatNumber objVatNumber = new VatNumber();
                objVatNumber.VatNumbers = objVatNumbers;
                tracingService.Trace("VatNumbers End");

                //TaxInd
                TaxInd objTaxInd = new TaxInd();
                objTaxInd.TaxInd_Prop = new TaxInd();
                objTaxInd.TaxInd_Prop.item = new List<Item>();

                List<Item> taxIndList = new List<Item>();

                tracingService.Trace("TaxInd Start");
                foreach (Entity entity in salesOrgExtensionTaxCategoryList)
                {
                    if (entity.Attributes.Contains("niq_salesorgextension"))
                    {
                        taxIndList.Add(new Item()
                        {
                            DepartureCountry = Common.Common.GetCountryCodeOfSalesOrgFromSalesOrgExtension(entity, salesOrgExtensionRequestList, Service),
                            TaxCategory = entity.Attributes.Contains("niq_taxcategory") ? ((EntityReference)entity.Attributes["niq_taxcategory"])?.Name : "",
                            TaxClassification = Common.Common.GetTaxClassificationCode(entity, "niq_taxclassification", Service)
                        });
                    }
                }
                objTaxInd.TaxInd_Prop.item = taxIndList;
                tracingService.Trace("TaxInd End");


                //Bankdetails
                Bankdetails objBankDetails = new Bankdetails();
                objBankDetails.item = new List<Item>();
                objBankDetails.item.Add(new Item()
                {
                    BankCountryKey = Common.Common.GetCountryCode(AccountRequest, "niq_bankcountrykey", Service),
                    BankNumber = AccountRequest.Attributes.Contains("niq_banknumber") ? AccountRequest.Attributes["niq_banknumber"].ToString() : "",
                    BankAccountNo = AccountRequest.Attributes.Contains("niq_bankaccountno") ? AccountRequest.Attributes["niq_bankaccountno"].ToString() : "",
                    BankControlKey = AccountRequest.Attributes.Contains("niq_bankcontrolkey") ? AccountRequest.Attributes["niq_bankcontrolkey"].ToString() : "",
                    BankType = AccountRequest.Attributes.Contains("niq_banktype") ? AccountRequest.Attributes["niq_banktype"].ToString() : "",
                    CollectAuthorInd = "",
                    BankDetailsReference = "",
                    AccountHolderName = AccountRequest.Attributes.Contains("niq_accountholdername") ? AccountRequest.Attributes["niq_accountholdername"].ToString() : "",
                    IBAN = AccountRequest.Attributes.Contains("niq_iban") ? AccountRequest.Attributes["niq_iban"].ToString() : "",
                    IBANFromDate = ""
                });
                tracingService.Trace("Bankdetails End");
                Bankdetail objbankdetail = new Bankdetail();
                objbankdetail.Bankdetails = objBankDetails;

                //Creditdetail
                Creditdetail objcreditdetail = new Creditdetail()
                {
                    CreditStanding = "",
                    CredStndgStatus = "",
                    CredStndgText = "",
                    CredStndgInstitute = "",
                    CredStndgDate = "",
                    Rating = "",
                };

                tracingService.Trace("Collection Start");
                //Collection
                Collectiondetail objCollectionDetails = new Collectiondetail()
                {
                    CollectionProfile = GetValueFromSupportData(AccountRequest, "niq_collectionprofile"),
                    CollectionGroup = "",
                    CollectionSegment = "",
                    CollectionSpecialist = ""
                };

                tracingService.Trace("GenerateCentralData End");
                return new CentralData()
                {
                    Central = objCentral,
                    AddressData = objAddressData,
                    Text = objText,
                    VatNumber = objVatNumber,
                    TaxInd = objTaxInd,
                    Bankdetail = objbankdetail,
                    Creditdetail = objcreditdetail,
                    Collectiondetail = objCollectionDetails
                };

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private static CompanyData GenerateCompanyData(Entity AccountRequest, List<Entity> salesOrgExtensionRequestList, List<Entity> salesOrgExtensionTaxCategoryList)
        {
            try
            {
                tracingService.Trace("GenerateCompanyData Start");
                string countryCode = String.Empty;
                CompanyData objcompanydata = new CompanyData();
                objcompanydata.item = new List<Item>();
                List<Item> companyDataItems = new List<Item>();

                foreach (Entity entity in salesOrgExtensionRequestList)
                {
                    countryCode = Common.Common.GetCountryCodeOfSalesOrgFromSalesOrgExtension(entity, salesOrgExtensionRequestList, Service);
                    Data data = new Data();
                    data.CompanyCode = Common.Common.GetSalesOrgCode(entity, "niq_salesorg", Service);
                    data.PostingBlock = "";
                    data.DeletionFlag = "";
                    data.KeyForSorting = "";
                    data.ReconciliationAccount = Common.Common.GetGlAccountNumber(entity, "niq_glaccount", Service);
                    data.MalaysiaTinNumber = countryCode == "MY" ? (entity.Attributes.Contains("niq_malaysiatinnumber") ? entity.Attributes["niq_malaysiatinnumber"].ToString() : "") : "";
                    data.AuthorizationGroup = "";
                    data.InterestCalcInd = "";
                    data.PaymentMethods = "";
                    data.ClearingInd = "";
                    data.BlockKeyPayment = "";
                    data.PaymentTerms = GetValueFromSupportData(entity, "niq_paymentterms");
                    data.ShippersAccount = "";
                    data.VendorClerk = "";
                    data.Memo = "";
                    data.Planninggroup = "";
                    data.AccountingClerk = GetValueFromSupportData(entity, "niq_accountingclerk");
                    data.KeyDateIntCalc = "";
                    data.IntCalcFreq = "";
                    data.LastIntCalcDate = "";
                    data.LocalProcessing = "";
                    data.BillOfExchange = "";
                    data.ProbableTime = "";
                    data.ToleranceGroup = "";
                    data.HouseBank = GetValueFromSupportData(entity, "niq_housebank");
                    data.PayAllItemsInd = "";
                    data.SubsidyIndicator = "";
                    data.PreviousNumber = entity.Attributes.Contains("niq_previousnumber") ? entity.Attributes["niq_previousnumber"].ToString() : "";
                    data.PaymentGrouping = "";
                    data.ShortKeyLeave = "";
                    data.DunningGroupKey = "";
                    data.PaymentMethodSupp = "";
                    data.PaymentAdvicesInd = "";
                    data.ReleaseApprovalGroup = "";
                    data.ReasonCode = "";
                    data.AccountingClerkFax = "";
                    data.ClerkIntaddress = "";
                    data.CreditPaymentTerm = "";
                    data.GrossIncomeTaxCode = "";
                    data.TaxDistributionType = "";
                    data.PeriodicAcctStatmnts = "2";
                    data.PersonnelNumber = "";
                    data.DeletionBlock = "";
                    data.AccountingClerkTel = "";
                    data.HeadOfficeAccountnumber = "";
                    data.AcctNumberAltPayer = "";
                    data.CustwclPaymntNoticeInd = "";
                    data.SalesPaymntNoticeInd = "";
                    data.LegalPaymntNoticeInd = "";
                    data.AcctdeptPaymntNoticeInd = "";
                    data.CustwoclPaymntNoticeInd = "";
                    data.BillofexchPaymntTerms = "";
                    data.ExportCreditIns = "";
                    data.AmountInsured = "";
                    data.InsLeadMonths = "";
                    data.DeductiblePerRate = "";
                    data.InsuranceNumber = "";
                    data.InsuranceValidDate = "";
                    data.CollectiveInvoice = "";
                    data.NextPayee = "";
                    data.RecordPaymentHistory = "X";
                    data.BuyGroupAcctNumber = "";
                    data.SelectRulePaymntAdvice = "";
                    data.AlternatePayer = "";
                    data.LockboxKey = GetValueFromSupportData(entity, "niq_lockboxkey");
                    data.ValueAdjustmentKey = "";
                    data.ARPledgingIndi = GetValueFromSupportData(entity, "niq_arpledging");
                    data.BusinessPurposeFlag = "";
                    data.MainEconomicActivity = "";


                    //Dunning
                    List<Item> dunningItems = new List<Item>();
                    dunningItems.Add(new Item()
                    {
                        DunningArea = "",
                        DunningProcedure = GetValueFromSupportData(entity, "niq_dunningprocedure"),
                        DunningBlock = GetValueFromSupportData(entity, "niq_dunningblock"),
                        LastDateDunningNotice = "",
                        DunningLevel = "",
                        DunnRecpAccntNo = "",
                        LegalDunningDate = "",
                        DunningClerk = ""
                    });

                    Dunning objDunning_Prop = new Dunning();
                    objDunning_Prop.item = dunningItems;

                    Dunning objDunning = new Dunning();
                    objDunning.Dunning_Prop = objDunning_Prop;


                    //Wtaxtype
                    List<Item> wtaxTypeItems = new List<Item>();
                    wtaxTypeItems.Add(new Item()
                    {
                        WithholdingTaxType = entity.Attributes.Contains("niq_withholdingtaxtype") ? entity.Attributes["niq_withholdingtaxtype"].ToString() : "",
                        WithholdingTaxCode = entity.Attributes.Contains("niq_withholdingtaxcode") ? entity.Attributes["niq_withholdingtaxcode"].ToString() : "",
                        WithholdingTaxAgent = "X",
                        WithholdTaxValidFrom = Common.Common.GetFormattedDate(entity, "niq_withholdtaxvalidfrom"),
                        WithholdTaxValidTo = Common.Common.GetFormattedDate(entity, "niq_withholdtaxvalidto"),
                        WithholdTaxIdentNo = "",
                        ExemptCertNumber = "",
                        ExemptionRate = "",
                        ExemptionBeginDate = "",
                        ExemptionEndDate = "",
                        ExemptionReason = "",
                    });

                    WtaxType objWtaxType_Prop = new WtaxType();
                    objWtaxType_Prop.item = wtaxTypeItems;

                    WtaxType objWtaxType = new WtaxType();
                    objWtaxType.WtaxType_Prop = objWtaxType_Prop;


                    ////Texts
                    //List<Item> textsItems = new List<Item>();
                    //textsItems.Add(new Item()
                    //{
                    //    TextId = "",
                    //    Langu = "",
                    //    Languiso = "",
                    //    Texts = "",
                    //});

                    //Texts objTexts_Prop = new Texts();
                    //objTexts_Prop.item = textsItems;

                    //Texts objTexts = new Texts();
                    //objTexts.Texts_Prop = objTexts_Prop;


                    companyDataItems.Add(new Item()
                    {
                        Data = data,
                        Dunning = objDunning,
                        WtaxType = objWtaxType,
                        //Texts_Prop = objTexts
                    });

                }

                objcompanydata.item = companyDataItems;

                tracingService.Trace("GenerateCompanyData End");
                return objcompanydata;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static SalesAreaData GenerateSalesAreaDataData(Entity AccountRequest, List<Entity> salesOrgExtensionRequestList, List<Entity> salesOrgExtensionTaxCategoryList)
        {
            try
            {
                tracingService.Trace("GenerateSalesAreaDataData Start");
                SalesAreaData objSalesAreaData = new SalesAreaData();
                objSalesAreaData.item = new List<Item>();
                List<Item> salesAreaDataItems = new List<Item>();

                foreach (Entity entity in salesOrgExtensionRequestList)
                {

                    Data data = new Data();
                    data.SalesOrganization = Common.Common.GetSalesOrgCode(entity, "niq_salesorg", Service);
                    data.DistributionChannel = entity.Attributes.Contains("niq_distributionchannel") ? entity.Attributes["niq_distributionchannel"].ToString() : "";
                    data.Division = entity.Attributes.Contains("niq_division") ? entity.Attributes["niq_division"].ToString() : "";
                    data.DelFlagSales = "";
                    data.CustomerOrderBlock = GetValueFromSupportData(entity, "niq_customerorderblock");
                    data.PricingProcedure = "1";
                    data.CustomerGroup = "";
                    data.SalesDistrict = "";
                    data.Incoterms1 = "";
                    data.Incoterms2 = "";
                    data.DeliveryBlock = "";
                    data.ShipperAccountNo = entity.Attributes.Contains("niq_shipperaccountno") ? entity.Attributes["niq_shipperaccountno"].ToString() : "";
                    data.ShippingConditions = "";
                    data.BillingBlock = "";
                    data.Currency = Common.Common.GetCurrencyCode(entity, "niq_currency", Service);
                    data.AcctAssignGroup = "01";
                    data.PaymentTerms = GetValueFromSupportData(entity, "niq_paymentterms");
                    data.DeliveringPlant = Common.Common.GetSalesOrgCode(entity, "niq_deliveringplant", Service);
                    data.SalesGroup = Common.Common.GetSalesGroupCode(entity, "niq_salesgroup", Service);
                    data.SalesOffice = Common.Common.GetSalesOfficeCode(entity, "niq_salesoffice", Service);
                    data.CustomerGroup1 = GetValueFromSupportData(entity, "niq_customergroup1");
                    data.CustomerGroup2 = GetValueFromSupportData(entity, "niq_customergroup2");
                    data.CustomerGroup3 = GetValueFromSupportData(entity, "niq_customergroup3");
                    data.CustomerGroup4 = GetValueFromSupportData(entity, "niq_customergroup4");
                    data.CustomerGroup5 = GetValueFromSupportData(entity, "niq_customergroup5");
                    data.ExchangeRate = "";
                    data.CreditControlArea = "";
                    data.SalesBlock = "";

                    List<Item> functionsItemList = new List<Item>();
                    functionsItemList.Add(new Item()
                    {
                        PartnerFunction = GetValueFromSupportData(entity, "niq_partnerfunction"),
                        PartnerCounter = "",
                        DefaultPartner = "",
                        CustomerDescription = "",
                        Partner = "0000001001" //entity.Attributes.Contains("niq_accountpayableapcontact") ? entity.GetAttributeValue<EntityReference>("niq_accountpayableapcontact").Id.ToString() : ""
                    });

                    Functions objFunctions_Prop = new Functions();
                    objFunctions_Prop.item = functionsItemList;

                    Functions objFunction = new Functions();
                    objFunction.Functions_Prop = objFunctions_Prop;

                    salesAreaDataItems.Add(new Item()
                    {
                        Data = data,
                        Functions = objFunction,
                        //Texts_Prop = objTexts
                    });

                }

                objSalesAreaData.item = salesAreaDataItems;

                tracingService.Trace("GenerateSalesAreaDataData End");
                return objSalesAreaData;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static string GetValueFromSupportData(Entity AccountRequest, string fieldLogicalName)
        {
            string masterValue = string.Empty;
            if (AccountRequest.Attributes.Contains(fieldLogicalName))
            {
                EntityReference SapAccountSupportMasterRef = AccountRequest.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity SapAccountSupportMasterEntity = accountMasterSupportDataList.Where(e => e.Id == SapAccountSupportMasterRef.Id).FirstOrDefault();
                if (SapAccountSupportMasterEntity != null && SapAccountSupportMasterEntity.Attributes.Contains("niq_mastervalue"))
                {
                    masterValue = SapAccountSupportMasterEntity.GetAttributeValue<string>("niq_mastervalue");
                }
            }

            if (masterValue == string.Empty)
                return "";
            else
                return masterValue;
        }


    }
}
