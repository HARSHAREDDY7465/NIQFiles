﻿using System;
using Newtonsoft.Json;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Collections.Generic;
using NIQ.D365.Int.AccountMasteringSAPIntegration.UnblockingModel;


namespace NIQ.D365.Int.AccountMasteringSAPIntegration.UnblockingPayload
{
    public static class UnblockingPayload
    {
        public static string SetRequestModel(IOrganizationService service, Entity accountEntity, ITracingService tracing)
        {
            try
            {
                Root objRoot = new Root();

                if (objRoot.ZsdfmCustomerCreateGfk == null)
                {
                    objRoot.ZsdfmCustomerCreateGfk = new ZsdfmCustomerCreateGfk();
                }

                if (objRoot.ZsdfmCustomerCreateGfk.Customerinput == null)
                {
                    objRoot.ZsdfmCustomerCreateGfk.Customerinput = new Customerinput();
                }

                objRoot.ZsdfmCustomerCreateGfk.Customerinput.CustomerNumber = accountEntity.Attributes.Contains("niq_customernumber") ? accountEntity.Attributes["niq_customernumber"].ToString() : null;
                objRoot.ZsdfmCustomerCreateGfk.Customerinput.UpdateIndicator = "U";
                EntityCollection salesOrgExtensionRequestEntityCollection = RetrieveSalesOrgExtensionRequestData(service, accountEntity);
                objRoot.ZsdfmCustomerCreateGfk.Customerinput.CompanyData = GenerateCompanyData(service, tracing, accountEntity, salesOrgExtensionRequestEntityCollection);
                objRoot.ZsdfmCustomerCreateGfk.Customerinput.SalesAreaData = GenerateSalesAreaData(service, tracing, accountEntity, salesOrgExtensionRequestEntityCollection);

                string payloadStr = JsonConvert.SerializeObject(objRoot, new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore,
                    Formatting = Formatting.Indented
                });
                payloadStr = payloadStr.Replace("ZsdfmCustomerCreateGfk", "n0:ZsdfmCustomerCreateGfk");
                return payloadStr;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private static EntityCollection RetrieveSalesOrgExtensionRequestData(IOrganizationService service, Entity Accountrequest)
        {
            QueryExpression query = new QueryExpression("niq_salesorgextensionrequest")
            {
                ColumnSet = new ColumnSet(true),
                Criteria = new FilterExpression
                {
                    Conditions = { new ConditionExpression("niq_accountrequest", ConditionOperator.Equal, Accountrequest.Id) }
                }
            };

            EntityCollection salesOrgExtensionRequestEC = service.RetrieveMultiple(query);
            return salesOrgExtensionRequestEC.Entities.Count > 0 ? salesOrgExtensionRequestEC : null;
        }
        private static CompanyData GenerateCompanyData(IOrganizationService service, ITracingService tracing, Entity Accountrequest, EntityCollection salesOrgExtensionRequestEntityCollection)
        {
            try
            {
                tracing.Trace("Inside GenerateCompanyData");
                CompanyData objcompanydata = new CompanyData();
                if (objcompanydata.item == null)
                    objcompanydata.item = new List<Item>();

                if (salesOrgExtensionRequestEntityCollection != null)
                {
                    foreach (Entity entity in salesOrgExtensionRequestEntityCollection.Entities)
                    {
                        if (entity.Contains("niq_salesorg"))
                        {
                            tracing.Trace("Inside foreach..if");
                            EntityReference salesOrgEntityRef = entity.GetAttributeValue<EntityReference>("niq_salesorg");
                            Entity salesOrgEntity = (Entity)service.Retrieve(salesOrgEntityRef.LogicalName, salesOrgEntityRef.Id, new ColumnSet("niq_companycode"));

                            EntityReference companyCodeEntityRef = salesOrgEntity.GetAttributeValue<EntityReference>("niq_companycode");
                            Entity companyCodeEntity = (Entity)service.Retrieve(companyCodeEntityRef.LogicalName, companyCodeEntityRef.Id, new ColumnSet("niq_companycode"));

                            Item companyDataItem = new Item();
                            companyDataItem.Data = new Data
                            {
                                CompanyCode = companyCodeEntity.Contains("niq_companycode") ? companyCodeEntity.GetAttributeValue<string>("niq_companycode") : null,
                                PostingBlock = "N"
                            };
                            objcompanydata.item.Add(companyDataItem);
                        }
                    }
                }
                tracing.Trace("Exiting GenerateCompanyData");
                return objcompanydata;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private static SalesAreaData GenerateSalesAreaData(IOrganizationService service, ITracingService tracing, Entity Accountrequest, EntityCollection salesOrgExtensionRequestEntityCollection)
        {
            try
            {
                tracing.Trace("Inside GenerateSalesAreaData");
                SalesAreaData objSalesAreaData = new SalesAreaData();
                if (objSalesAreaData.item == null)
                    objSalesAreaData.item = new List<Item>();

                if (salesOrgExtensionRequestEntityCollection != null)
                {
                    foreach (Entity entity in salesOrgExtensionRequestEntityCollection.Entities)
                    {
                        if (entity.Contains("niq_salesorg"))
                        {
                            tracing.Trace("Inside foreach..if");
                            EntityReference salesOrgEntityRef = entity.GetAttributeValue<EntityReference>("niq_salesorg");
                            Entity salesOrgEntity = (Entity)service.Retrieve(salesOrgEntityRef.LogicalName, salesOrgEntityRef.Id, new ColumnSet("niq_salesorgcode"));

                            //EntityReference customerOrderBlockEntityRef = Accountrequest.GetAttributeValue<EntityReference>("niq_customerorderblock");
                            //Entity customerOrderBlockEntity = (Entity)service.Retrieve(customerOrderBlockEntityRef.LogicalName, customerOrderBlockEntityRef.Id, new ColumnSet("niq_mastervalue"));

                            Item salesAreaItem = new Item();
                            salesAreaItem.Data = new Data
                            {
                                SalesOrganization = salesOrgEntity.Contains("niq_salesorgcode") ? salesOrgEntity.GetAttributeValue<string>("niq_salesorgcode") : null,
                                DistributionChannel = entity.Attributes.Contains("niq_distributionchannel") ? entity.GetAttributeValue<string>("niq_distributionchannel").ToString() : null,
                                Division = entity.Attributes.Contains("niq_division") ? entity.GetAttributeValue<string>("niq_division").ToString() : null,
                                CustomerOrderBlock = GetValueFromSupportData(service, entity, "niq_customerorderblock")//"00"
                            };
                            objSalesAreaData.item.Add(salesAreaItem);
                        }
                    }
                }
                tracing.Trace("Exiting GenerateSalesAreaData");
                return objSalesAreaData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static string GetValueFromSupportData(IOrganizationService service, Entity entityName, string fieldLogicalName)
        {
            string masterValue = string.Empty;
            if (entityName.Attributes.Contains(fieldLogicalName))
            {
                EntityReference SapAccountSupportMasterRef = entityName.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity SapAccountSupportMasterEntity = (Entity)service.Retrieve(SapAccountSupportMasterRef.LogicalName, SapAccountSupportMasterRef.Id, new ColumnSet("niq_mastervalue"));
                if (SapAccountSupportMasterEntity != null && SapAccountSupportMasterEntity.Attributes.Contains("niq_mastervalue"))
                {
                    masterValue = SapAccountSupportMasterEntity.GetAttributeValue<string>("niq_mastervalue");
                }
            }

            if (masterValue == string.Empty)
                return "";
            else
                return masterValue;
        }
    }
}