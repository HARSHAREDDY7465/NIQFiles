﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NIQ.D365.Int.AccountMasteringSAPIntegration.CreationModel
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class AddressData
    {
        public string Nation { get; set; }
        public string DateTo { get; set; }
        public string Title { get; set; }
        public string Name1 { get; set; }
        public string Name2 { get; set; }
        public string Name3 { get; set; }
        public string Name4 { get; set; }
        public string NameCo { get; set; }
        public string City1 { get; set; }
        public string District { get; set; }
        public string PostCode1 { get; set; }
        public string PoBox { get; set; }
        public string Street { get; set; }
        public string HouseNum1 { get; set; }
        public string HouseNum2 { get; set; }
        public string Street1 { get; set; }
        public string Street2 { get; set; }
        public string Street3 { get; set; }
        public string Location { get; set; }
        public string Building { get; set; }
        public string Floor { get; set; }
        public string Roomnumber { get; set; }
        public string Country { get; set; }
        public string Langu { get; set; }
        public string Region { get; set; }
        public string SearchTerm1 { get; set; }
        public string SearchTerm2 { get; set; }
        public string TelNumber { get; set; }
        public string TelExtens { get; set; }
        public string FaxNumber { get; set; }
        public string FaxExtens { get; set; }
        public string CommunicationMethod { get; set; }
        public string EmailId { get; set; }
        public string Taxjurcode { get; set; }
        public string County { get; set; }
        public string Township { get; set; }
    }

    public class Bankdetail
    {
        public Bankdetails Bankdetails { get; set; }
    }
    public class Bankdetails
    {
        public List<Item> item { get; set; }
    }

    public class Central
    {
        public string Partnercategory { get; set; }
        public string Partnergroup { get; set; }
        public string Partnerrole { get; set; }
        public string Partnertype { get; set; }
        public string TitleKey { get; set; }
        public string Industrysector { get; set; }
        public string ChkDigit { get; set; }
        public string GroupKey { get; set; }
        public string Taxtype1 { get; set; }
        public string TaxNumber1 { get; set; }
        public string Taxtype2 { get; set; }
        public string TaxNumber2 { get; set; }
        public string Taxtype3 { get; set; }
        public string TaxNumber3 { get; set; }
        public string Taxtype4 { get; set; }
        public string TaxNumber4 { get; set; }
        public string Taxtype5 { get; set; }
        public string TaxNumber5 { get; set; }
        public string IndustryKey { get; set; }
        public string IndustryCode1 { get; set; }
    }

    public class CentralData
    {
        public Central Central { get; set; }
        public AddressData AddressData { get; set; }
        public Text Text { get; set; }
        public VatNumber VatNumber { get; set; }
        public TaxInd TaxInd { get; set; }
        public Contact Contact { get; set; }
        public Bankdetail Bankdetail { get; set; }
        public Creditdetail Creditdetail { get; set; }
        public Collectiondetail Collectiondetail { get; set; }
    }

    public class Collectiondetail
    {
        public string CollectionProfile { get; set; }
        public string CollectionGroup { get; set; }
        public string CollectionSegment { get; set; }
        public string CollectionSpecialist { get; set; }
    }

    public class CompanyData
    {
        public List<Item> item { get; set; }
    }

    public class Contact
    {
        public Contacts Contacts { get; set; }
    }

    public class Contacts
    {
        public Item item { get; set; }
    }

    public class Creditdetail
    {
        public string CreditStanding { get; set; }
        public string CredStndgStatus { get; set; }
        public string CredStndgText { get; set; }
        public string CredStndgInstitute { get; set; }
        public string CredStndgDate { get; set; }
        public string Rating { get; set; }
    }

    public class Customerinput
    {
        public string CustomerNumber { get; set; }
        public string SARNumber { get; set; }
        public string UpdateIndicator { get; set; }
        public CentralData CentralData { get; set; }
        public CompanyData CompanyData { get; set; }
        public SalesAreaData SalesAreaData { get; set; }
    }

    public class Data
    {
        public string CompanyCode { get; set; }
        public string PostingBlock { get; set; }
        public string DeletionFlag { get; set; }
        public string KeyForSorting { get; set; }
        public string ReconciliationAccount { get; set; }
        public string MalaysiaTinNumber { get; set; }
        public string AuthorizationGroup { get; set; }
        public string InterestCalcInd { get; set; }
        public string PaymentMethods { get; set; }
        public string ClearingInd { get; set; }
        public string BlockKeyPayment { get; set; }
        
        public string ShippersAccount { get; set; }
        public string VendorClerk { get; set; }
        public string Memo { get; set; }
        public string Planninggroup { get; set; }
        public string AccountingClerk { get; set; }
        public string KeyDateIntCalc { get; set; }
        public string IntCalcFreq { get; set; }
        public string LastIntCalcDate { get; set; }
        public string LocalProcessing { get; set; }
        public string BillOfExchange { get; set; }
        public string ProbableTime { get; set; }
        public string ToleranceGroup { get; set; }
        public string HouseBank { get; set; }
        public string PayAllItemsInd { get; set; }
        public string SubsidyIndicator { get; set; }
        public string PreviousNumber { get; set; }
        public string PaymentGrouping { get; set; }
        public string ShortKeyLeave { get; set; }
        public string DunningGroupKey { get; set; }
        public string PaymentMethodSupp { get; set; }
        public string PaymentAdvicesInd { get; set; }
        public string ReleaseApprovalGroup { get; set; }
        public string ReasonCode { get; set; }
        public string AccountingClerkFax { get; set; }
        public string ClerkIntaddress { get; set; }
        public string CreditPaymentTerm { get; set; }
        public string GrossIncomeTaxCode { get; set; }
        public string TaxDistributionType { get; set; }
        public string PeriodicAcctStatmnts { get; set; }
        public string PersonnelNumber { get; set; }
        public string DeletionBlock { get; set; }
        public string AccountingClerkTel { get; set; }
        public string HeadOfficeAccountnumber { get; set; }
        public string AcctNumberAltPayer { get; set; }
        public string CustwclPaymntNoticeInd { get; set; }
        public string SalesPaymntNoticeInd { get; set; }
        public string LegalPaymntNoticeInd { get; set; }
        public string AcctdeptPaymntNoticeInd { get; set; }
        public string CustwoclPaymntNoticeInd { get; set; }
        public string BillofexchPaymntTerms { get; set; }
        public string ExportCreditIns { get; set; }
        public string AmountInsured { get; set; }
        public string InsLeadMonths { get; set; }
        public string DeductiblePerRate { get; set; }
        public string InsuranceNumber { get; set; }
        public string InsuranceValidDate { get; set; }
        public string CollectiveInvoice { get; set; }
        public string NextPayee { get; set; }
        public string RecordPaymentHistory { get; set; }
        public string BuyGroupAcctNumber { get; set; }
        public string SelectRulePaymntAdvice { get; set; }
        public string AlternatePayer { get; set; }
        public string LockboxKey { get; set; }
        public string ValueAdjustmentKey { get; set; }
        public string ARPledgingIndi { get; set; }
        public string BusinessPurposeFlag { get; set; }
        public string MainEconomicActivity { get; set; }
        public string SalesOrganization { get; set; }
        public string DistributionChannel { get; set; }
        public string Division { get; set; }
        public string DelFlagSales { get; set; }
        public string CustomerOrderBlock { get; set; }
        public string PricingProcedure { get; set; }
        public string CustomerGroup { get; set; }
        public string SalesDistrict { get; set; }
        public string Incoterms1 { get; set; }
        public string Incoterms2 { get; set; }
        public string DeliveryBlock { get; set; }
        public string ShipperAccountNo { get; set; }
        public string ShippingConditions { get; set; }
        public string BillingBlock { get; set; }
        public string Currency { get; set; }
        public string AcctAssignGroup { get; set; }
        public string PaymentTerms { get; set; }
        public string DeliveringPlant { get; set; }
        public string SalesGroup { get; set; }
        public string SalesOffice { get; set; }
        public string CustomerGroup1 { get; set; }
        public string CustomerGroup2 { get; set; }
        public string CustomerGroup3 { get; set; }
        public string CustomerGroup4 { get; set; }
        public string CustomerGroup5 { get; set; }
        public string ExchangeRate { get; set; }
        public string CreditControlArea { get; set; }
        public string SalesBlock { get; set; }
    }

    public class Dunning
    {
        public Dunning Dunning_Prop { get; set; }
        public List<Item> item { get; set; }
    }

    public class Functions
    {
        public Functions Functions_Prop { get; set; }
        public List<Item> item { get; set; }
    }

    public class Item
    {
        public string TextId { get; set; }
        public string Langu { get; set; }
        public string Languiso { get; set; }
        public string PartnerFunction { get; set; }
        public string PartnerCounter { get; set; }
        public string DefaultPartner { get; set; }
        public string CustomerDescription { get; set; }
        public string Partner { get; set; }
        public string Texts { get; set; }
        public string CountryKey { get; set; }
        public string VatType { get; set; }
        public string VATRegistrationNumber { get; set; }
        public string DepartureCountry { get; set; }
        public string TaxCategory { get; set; }
        public string TaxClassification { get; set; }
        public string ContactPersonNo { get; set; }
        public string ContactPersonDept { get; set; }
        public string HigherLevelPartner { get; set; }
        public string ContactPersonFunct { get; set; }
        public string Sortfield { get; set; }
        public Data Data { get; set; }
        public Dunning Dunning { get; set; }
        public WtaxType WtaxType { get; set; }
        public string DunningArea { get; set; }
        public string DunningProcedure { get; set; }
        public string DunningBlock { get; set; }
        public string LastDateDunningNotice { get; set; }
        public string DunningLevel { get; set; }
        public string DunnRecpAccntNo { get; set; }
        public string LegalDunningDate { get; set; }
        public string DunningClerk { get; set; }
        public string WithholdingTaxType { get; set; }
        public string WithholdingTaxCode { get; set; }
        public string WithholdingTaxAgent { get; set; }
        public string WithholdTaxValidFrom { get; set; }
        public string WithholdTaxValidTo { get; set; }
        public string WithholdTaxIdentNo { get; set; }
        public string ExemptCertNumber { get; set; }
        public string ExemptionRate { get; set; }
        public string ExemptionBeginDate { get; set; }
        public string ExemptionEndDate { get; set; }
        public string ExemptionReason { get; set; }
        public Functions Functions { get; set; }

        public string BankCountryKey { get; set; }
        public string BankNumber { get; set; }
        public string BankAccountNo { get; set; }
        public string BankControlKey { get; set; }
        public string BankType { get; set; }
        public string CollectAuthorInd { get; set; }
        public string BankDetailsReference { get; set; }
        public string AccountHolderName { get; set; }
        public string IBAN { get; set; }
        public string IBANFromDate { get; set; }
        //public Texts Texts_Prop { get; set; }
    }

    public class N0ZsdfmCustomerCreateGfk
    {
        public Customerinput Customerinput { get; set; }
    }

    public class Root
    {
        public N0ZsdfmCustomerCreateGfk n0ZsdfmCustomerCreateGfk { get; set; }
    }

    public class SalesAreaData
    {
        public List<Item> item { get; set; }
    }

    public class TaxInd
    {
        public TaxInd TaxInd_Prop { get; set; }
        public List<Item> item { get; set; }
    }

    public class Text
    {
        public Texts Texts { get; set; }
    }

    public class Texts
    {
        public List<Item> item { get; set; }
        public Texts Texts_Prop { get; set; }
    }

    public class VatNumber
    {
        public VatNumbers VatNumbers { get; set; }
    }

    public class VatNumbers
    {
        public List<Item> item { get; set; }
    }

    public class WtaxType
    {
        public WtaxType WtaxType_Prop { get; set; }
        public List<Item> item { get; set; }
    }


}