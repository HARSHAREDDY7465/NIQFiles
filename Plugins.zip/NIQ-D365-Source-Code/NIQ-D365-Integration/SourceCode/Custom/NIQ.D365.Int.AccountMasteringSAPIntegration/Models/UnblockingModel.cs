﻿using System.Collections.Generic;

namespace NIQ.D365.Int.AccountMasteringSAPIntegration.UnblockingModel
{
    public class CompanyData
    {
        public List<Item> item { get; set; }
    }

    public class Customerinput
    {
        public string CustomerNumber { get; set; }
        public string UpdateIndicator { get; set; }
        public CompanyData CompanyData { get; set; }
        public SalesAreaData SalesAreaData { get; set; }
    }

    public class Data
    {
        public string CompanyCode { get; set; }
        public string PostingBlock { get; set; }
        public string SalesOrganization { get; set; }
        public string DistributionChannel { get; set; }
        public string Division { get; set; }
        public string CustomerOrderBlock { get; set; }
    }

    public class Item
    {
        public Data Data { get; set; }
    }

    public class Root
    {
        public ZsdfmCustomerCreateGfk ZsdfmCustomerCreateGfk { get; set; }
    }

    public class SalesAreaData
    {
        public List<Item> item { get; set; }
    }

    public class ZsdfmCustomerCreateGfk
    {
        public Customerinput Customerinput { get; set; }
    }
}