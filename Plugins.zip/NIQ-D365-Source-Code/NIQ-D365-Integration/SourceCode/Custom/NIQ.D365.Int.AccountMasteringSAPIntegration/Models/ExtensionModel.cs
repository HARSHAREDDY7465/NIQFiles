﻿using System.Collections.Generic;

namespace NIQ.D365.Int.AccountMasteringSAPIntegration.ExtensionModel
{
    public class CentralData
    {
        public TaxInd TaxInd { get; set; }
    }
    public class CompanyData
    {
        public List<Item> item { get; set; }
    }
    public class Customerinput
    {
        public string CustomerNumber { get; set; }
        public string UpdateIndicator { get; set; }
        public CentralData CentralData { get; set; }
        public CompanyData CompanyData { get; set; }
        public SalesAreaData SalesAreaData { get; set; }
    }
    public class Data
    {
        public string CompanyCode { get; set; }
        public string ReconciliationAccount { get; set; }
        public string AccountingClerk { get; set; }
        public string HouseBank { get; set; }
        public string PreviousNumber { get; set; }
        public string PeriodicAcctStatmnts { get; set; }
        public string RecordPaymentHistory { get; set; }
        public string ARPledgingIndi { get; set; }
        public string LockboxKey { get; set; }
        public string SalesOrganization { get; set; }
        public string DistributionChannel { get; set; }
        public string Division { get; set; }
        public string CustomerOrderBlock { get; set; }
        public string PricingProcedure { get; set; }
        public string ShipperAccountNo { get; set; }
        public string Currency { get; set; }
        public string AcctAssignGroup { get; set; }
        public string PaymentTerms { get; set; }
        public string DeliveringPlant { get; set; }
        public string SalesGroup { get; set; }
        public string SalesOffice { get; set; }
        public string CustomerGroup1 { get; set; }
        public string CustomerGroup2 { get; set; }
        public string CustomerGroup3 { get; set; }
        public string CustomerGroup4 { get; set; }
        public string CustomerGroup5 { get; set; }
    }
    public class Dunning
    {
        public Dunning Dunning_Prop { get; set; }
        public List<Item> item { get; set; }
    }
    public class Functions
    {
        public Functions Functions_Prop { get; set; }
        public List<Item> item { get; set; }
    }
    public class Item
    {
        public string DepartureCountry { get; set; }
        public string TaxCategory { get; set; }
        public string TaxClassification { get; set; }
        public Data Data { get; set; }
        public Dunning Dunning { get; set; }
        public WtaxType WtaxType { get; set; }
        public string DunningArea { get; set; }
        public string DunningProcedure { get; set; }
        public string DunningClerk { get; set; }
        public string WithholdingTaxType { get; set; }
        public string WithholdingTaxCode { get; set; }
        public string WithholdingTaxAgent { get; set; }
        public string WithholdTaxValidFrom { get; set; }
        public string WithholdTaxValidTo { get; set; }
        public Functions Functions { get; set; }
        public string PartnerFunction { get; set; }
        public string Partner { get; set; }
        public Texts Texts { get; set; }
        public string TextId { get; set; }
        public string Langu { get; set; }
        public string Languiso { get; set; }
        public string Texts_Prop { get; set; }
    }
    public class Root
    {
        public ZsdfmCustomerCreateGfk ZsdfmCustomerCreateGfk { get; set; }
    }
    public class SalesAreaData
    {
        public List<Item> item { get; set; }
    }
    public class TaxInd
    {
        public TaxInd TaxInd_Prop { get; set; }
        public List<Item> item { get; set; }
    }
    public class Texts
    {
        public Texts Texts_Prop { get; set; }
        public List<Item> item { get; set; }
    }
    public class WtaxType
    {
        public WtaxType WtaxType_Prop { get; set; }
        public List<Item> item { get; set; }
    }
    public class ZsdfmCustomerCreateGfk
    {
        public Customerinput Customerinput { get; set; }
    }
}