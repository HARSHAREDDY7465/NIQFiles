﻿using System;
using Newtonsoft.Json;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xrm.Sdk.Metadata;
using System.Globalization;

namespace NIQ.D365.Int.AccountMasteringSAPIntegration.Common
{
    public static class Common
    {
        public static List<Entity> GetSAPAccountSupportMasterData(IOrganizationService service)
        {
            string fetchquery = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='niq_sapaccountmastersupportdata'>
                                    <attribute name='niq_sapaccountmastersupportdataid' />
                                    <attribute name='niq_name' />
                                    <attribute name='niq_mastervalue' />
                                    <attribute name='niq_mastertype' />
                                    <attribute name='niq_masteridentity' />
                                    <order attribute='niq_name' descending='false' />
                                  </entity>
                                </fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchquery)).Entities.ToList();

        }

        public static string GetCountryCode(Entity AccountRequest, string fieldLogicalName, IOrganizationService service)
        {
            string countryCode = string.Empty;
            if (AccountRequest.Attributes.Contains(fieldLogicalName))
            {
                EntityReference CountryRef = AccountRequest.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity CountryEntity = service.Retrieve(CountryRef.LogicalName, CountryRef.Id, new ColumnSet("niq_countrycode"));
                if (CountryEntity != null && CountryEntity.Attributes.Contains("niq_countrycode"))
                {
                    countryCode = CountryEntity.GetAttributeValue<string>("niq_countrycode");
                }
            }
            return countryCode;
        }

        public static bool GetIsVatRequiredFromCountry(Entity AccountRequest, string fieldLogicalName, IOrganizationService service)
        {
            bool isVATRequired = false;
            if (AccountRequest.Attributes.Contains(fieldLogicalName))
            {
                EntityReference CountryRef = AccountRequest.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity CountryEntity = service.Retrieve(CountryRef.LogicalName, CountryRef.Id, new ColumnSet("niq_isvatrequired"));
                if (CountryEntity != null && CountryEntity.Attributes.Contains("niq_isvatrequired"))
                {
                    isVATRequired = CountryEntity.GetAttributeValue<bool>("niq_isvatrequired");
                }
            }
            return isVATRequired;
        }

        public static string GetCompanyCode(Entity AccountRequest, string fieldLogicalName, IOrganizationService service)
        {
            string companyCode = string.Empty;
            if (AccountRequest.Attributes.Contains(fieldLogicalName))
            {
                EntityReference CompanyCodeRef = AccountRequest.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity CompanyCodeEntity = service.Retrieve(CompanyCodeRef.LogicalName, CompanyCodeRef.Id, new ColumnSet("niq_companycode"));
                if (CompanyCodeEntity != null && CompanyCodeEntity.Attributes.Contains("niq_companycode"))
                {
                    companyCode = CompanyCodeEntity.GetAttributeValue<string>("niq_companycode");
                }
            }
            return companyCode;
        }

        public static string GetSalesOrgCode(Entity AccountRequest, string fieldLogicalName, IOrganizationService service)
        {
            string salesOrgCode = string.Empty;
            if (AccountRequest.Attributes.Contains(fieldLogicalName))
            {
                EntityReference SalesOrgRef = AccountRequest.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity SalesOrgEntity = service.Retrieve(SalesOrgRef.LogicalName, SalesOrgRef.Id, new ColumnSet("niq_salesorgcode"));
                if (SalesOrgEntity != null && SalesOrgEntity.Attributes.Contains("niq_salesorgcode"))
                {
                    salesOrgCode = SalesOrgEntity.GetAttributeValue<string>("niq_salesorgcode");
                }
            }
            return salesOrgCode;
        }

        public static string GetSalesGroupCode(Entity AccountRequest, string fieldLogicalName, IOrganizationService service)
        {
            string salesGroupCode = string.Empty;
            if (AccountRequest.Attributes.Contains(fieldLogicalName))
            {
                EntityReference SalesGroupRef = AccountRequest.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity SalesGroupEntity = service.Retrieve(SalesGroupRef.LogicalName, SalesGroupRef.Id, new ColumnSet("niq_salesgroupcode"));
                if (SalesGroupEntity != null && SalesGroupEntity.Attributes.Contains("niq_salesgroupcode"))
                {
                    salesGroupCode = SalesGroupEntity.GetAttributeValue<string>("niq_salesgroupcode");
                }
            }
            return salesGroupCode;
        }
        
        public static string GetSalesOfficeCode(Entity AccountRequest, string fieldLogicalName, IOrganizationService service)
        {
            string salesOfficeCode = string.Empty;
            if (AccountRequest.Attributes.Contains(fieldLogicalName))
            {
                EntityReference SalesOfficeRef = AccountRequest.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity SalesOfficeEntity = service.Retrieve(SalesOfficeRef.LogicalName, SalesOfficeRef.Id, new ColumnSet("niq_salesofficecode"));
                if (SalesOfficeEntity != null && SalesOfficeEntity.Attributes.Contains("niq_salesofficecode"))
                {
                    salesOfficeCode = SalesOfficeEntity.GetAttributeValue<string>("niq_salesofficecode");
                }
            }
            return salesOfficeCode;
        }

        public static string GetGlAccountNumber(Entity AccountRequest, string fieldLogicalName, IOrganizationService service)
        {
            string glAccountNumber = string.Empty;
            if (AccountRequest.Attributes.Contains(fieldLogicalName))
            {
                EntityReference GlAccountRef = AccountRequest.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity GlAccountEntity = service.Retrieve(GlAccountRef.LogicalName, GlAccountRef.Id, new ColumnSet("niq_glaccountnumber"));
                if (GlAccountEntity != null && GlAccountEntity.Attributes.Contains("niq_glaccountnumber"))
                {
                    glAccountNumber = GlAccountEntity.GetAttributeValue<string>("niq_glaccountnumber");
                }
            }
            return glAccountNumber;
        }

        public static string GetCurrencyCode(Entity AccountRequest, string fieldLogicalName, IOrganizationService service)
        {
            string currencyCode = string.Empty;
            if (AccountRequest.Attributes.Contains(fieldLogicalName))
            {
                EntityReference CurrencyRef = AccountRequest.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity CurrencyEntity = service.Retrieve(CurrencyRef.LogicalName, CurrencyRef.Id, new ColumnSet("isocurrencycode"));
                if (CurrencyEntity != null && CurrencyEntity.Attributes.Contains("isocurrencycode"))
                {
                    currencyCode = CurrencyEntity.GetAttributeValue<string>("isocurrencycode");
                }
            }
            return currencyCode;
        }

        public static string GetRegionCode(Entity AccountRequest, string fieldLogicalName, IOrganizationService service)
        {
            string regionCode = string.Empty;
            if (AccountRequest.Attributes.Contains(fieldLogicalName))
            {
                EntityReference CountryStateRef = AccountRequest.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity CountryStateEntity = service.Retrieve(CountryStateRef.LogicalName, CountryStateRef.Id, new ColumnSet("niq_statecode"));
                if (CountryStateEntity != null && CountryStateEntity.Attributes.Contains("niq_statecode"))
                {
                    regionCode = CountryStateEntity.GetAttributeValue<string>("niq_statecode");
                }
            }
            return regionCode;
        }

        public static string GetHFMCode(Entity AccountRequest, string fieldLogicalName, IOrganizationService service)
        {
            string hfmID = string.Empty;
            if (AccountRequest.Attributes.Contains(fieldLogicalName))
            {
                EntityReference HFMCodeRef = AccountRequest.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity HFMCodeEntity = service.Retrieve(HFMCodeRef.LogicalName, HFMCodeRef.Id, new ColumnSet("niq_hfmid"));
                if (HFMCodeEntity != null && HFMCodeEntity.Attributes.Contains("niq_hfmid"))
                {
                    hfmID = HFMCodeEntity.GetAttributeValue<string>("niq_hfmid");
                }
            }
            return hfmID;
        }

        public static string GetTaxNumberCategoryCode(Entity AccountRequest, string fieldLogicalName, IOrganizationService service)
        {
            string categoryCode = string.Empty;
            if (AccountRequest.Attributes.Contains(fieldLogicalName))
            {
                EntityReference TaxNumberRef = AccountRequest.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity TaxNumberEntity = service.Retrieve(TaxNumberRef.LogicalName, TaxNumberRef.Id, new ColumnSet("niq_category"));
                if (TaxNumberEntity != null && TaxNumberEntity.Attributes.Contains("niq_category"))
                {
                    categoryCode = TaxNumberEntity.GetAttributeValue<string>("niq_category");
                }
            }
            return categoryCode;
        }

        public static string GetTaxClassificationCode(Entity SalesOrgExtensionTaxCategoryEntity, string fieldLogicalName, IOrganizationService service)
        {
            string taxClassificationCode = string.Empty;
            if (SalesOrgExtensionTaxCategoryEntity.Attributes.Contains(fieldLogicalName))
            {
                EntityReference TaxClassificationRef = SalesOrgExtensionTaxCategoryEntity.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity TaxNumberEntity = service.Retrieve(TaxClassificationRef.LogicalName, TaxClassificationRef.Id, new ColumnSet("niq_taxclass"));
                if (TaxNumberEntity != null && TaxNumberEntity.Attributes.Contains("niq_taxclass"))
                {
                    taxClassificationCode = TaxNumberEntity.GetAttributeValue<string>("niq_taxclass");
                }
            }
            return taxClassificationCode;
        }

        public static string GetFormattedDate(Entity AccountRequest, string fieldLogicalName)
        {
            string dateStr = string.Empty;
            if (AccountRequest.Attributes.Contains(fieldLogicalName))
            {
                DateTime DateValue = AccountRequest.GetAttributeValue<DateTime>(fieldLogicalName);
                dateStr = DateValue.ToString("ddMMyyyy", CultureInfo.InvariantCulture);
            }
            return dateStr;
        }

        public static string GetCountryCodeOfSalesOrg(Entity AccountRequest, string fieldLogicalName, IOrganizationService service)
        {
            string countryCode = string.Empty;
            if (AccountRequest.Attributes.Contains(fieldLogicalName))
            {
                EntityReference SalesOrgRef = AccountRequest.GetAttributeValue<EntityReference>(fieldLogicalName);
                Entity SalesOrgEntity = service.Retrieve(SalesOrgRef.LogicalName, SalesOrgRef.Id, new ColumnSet("niq_operatingcountryid"));
                if (SalesOrgEntity != null && SalesOrgEntity.Attributes.Contains("niq_operatingcountryid"))
                {
                    EntityReference CountryRef = SalesOrgEntity.GetAttributeValue<EntityReference>("niq_operatingcountryid");
                    Entity CountryEntity = service.Retrieve(CountryRef.LogicalName, CountryRef.Id, new ColumnSet("niq_countrycode"));
                    if (CountryEntity != null && CountryEntity.Attributes.Contains("niq_countrycode"))
                    {
                        countryCode = CountryEntity.GetAttributeValue<string>("niq_countrycode");
                    }
                }
            }
            return countryCode;
        }

        public static string GetCountryCodeOfSalesOrgFromSalesOrgExtension(Entity SalesOrgTaxCatEntity, List<Entity> salesOrgExtensionRequestList, IOrganizationService service)
        {
            string countryCode = string.Empty;

            if (SalesOrgTaxCatEntity.Attributes.Contains("niq_salesorgextension"))
            {
                Entity SalesOrgExtensionEntity = salesOrgExtensionRequestList.Where(e => e.Id == SalesOrgTaxCatEntity.GetAttributeValue<EntityReference>("niq_salesorgextension").Id).FirstOrDefault();
                if (SalesOrgExtensionEntity != null && SalesOrgExtensionEntity.Attributes.Contains("niq_salesorg"))
                {
                    EntityReference SalesOrgRef = SalesOrgExtensionEntity.GetAttributeValue<EntityReference>("niq_salesorg");
                    Entity SalesOrgEntity = service.Retrieve(SalesOrgRef.LogicalName, SalesOrgRef.Id, new ColumnSet("niq_operatingcountryid"));
                    if (SalesOrgEntity != null && SalesOrgEntity.Attributes.Contains("niq_operatingcountryid"))
                    {
                        EntityReference CountryRef = SalesOrgEntity.GetAttributeValue<EntityReference>("niq_operatingcountryid");
                        Entity CountryEntity = service.Retrieve(CountryRef.LogicalName, CountryRef.Id, new ColumnSet("niq_countrycode"));
                        if (CountryEntity != null && CountryEntity.Attributes.Contains("niq_countrycode"))
                        {
                            countryCode = CountryEntity.GetAttributeValue<string>("niq_countrycode");
                        }
                    }
                }
            }
            return countryCode;
        }

        public static List<Entity> GetSalesOrgExtentionRequests(IOrganizationService service, Entity AccountRequestEntity)
        {
            QueryExpression query = new QueryExpression("niq_salesorgextensionrequest")
            {
                ColumnSet = new ColumnSet(true),
                Criteria = new FilterExpression
                {
                    Conditions = { new ConditionExpression("niq_accountrequest", ConditionOperator.Equal, AccountRequestEntity.Id) }
                }
            };

            return service.RetrieveMultiple(query).Entities.ToList();
        }

        public static List<Entity> GetSalesOrgExtentionTaxCategories(IOrganizationService service, Entity AccountRequestEntity)
        {
            QueryExpression query = new QueryExpression("niq_salesorgextensiontaxcategory")
            {
                ColumnSet = new ColumnSet(true),
                Criteria = new FilterExpression
                {
                    Conditions = { new ConditionExpression("niq_accountrequest", ConditionOperator.Equal, AccountRequestEntity.Id) }
                }
            };

            return service.RetrieveMultiple(query).Entities.ToList();
        }



    }
}