﻿using System;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Collections.Generic;

namespace NIQ.D365.Int.AccountMasteringSAPIntegration
{
    public class AccountMasteringSAPIntegrationAction : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = factory.CreateOrganizationService(context.UserId);
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            try
            {
                string accountRequestId = (string)context.InputParameters["AccountRequestId"];
                tracing.Trace($@"AccountRequestId: {accountRequestId}");

                Entity AccountRequestEntity = service.Retrieve("niq_accountrequest", new Guid(accountRequestId), new ColumnSet(true));

                int requestType = 1;
                if (AccountRequestEntity.Attributes.Contains("niq_requesttype"))
                    requestType = AccountRequestEntity.GetAttributeValue<OptionSetValue>("niq_requesttype").Value;

                tracing.Trace($@"requestType: {requestType}");
                string payloadData = string.Empty;
                switch (requestType)
                {
                    case 610570000: //Account Creation
                        payloadData = CreationPayload.CreationPayload.SetRequestModel(AccountRequestEntity, service, tracing);
                        break;
                    case 610570001: //Account Modification
                        payloadData = ModificationPayload.ModificationPayload.SetRequestModel(AccountRequestEntity, service, tracing);
                        break;
                    case 610570002:  // Account Extension
                        EntityCollection ARSalesOrg = new EntityCollection();
                        payloadData = ExtensionPayload.ExtensionPayload.SetRequestModel(AccountRequestEntity, service);
                        break;
                    case 610570003: // SAP Account Compliance Block
                    case 610570004: // SAP Account Financial Block
                        payloadData = BlockingPayload.BlockingPayload.SetRequestModel(service, AccountRequestEntity, tracing);
                        break;
                    //case 610570004:  // Account Unblocking
                    case 610570006:  // SAP Account Compliance / Financial Unblock
                        payloadData = UnblockingPayload.UnblockingPayload.SetRequestModel(service, AccountRequestEntity, tracing);
                        break;
                    default:
                        break;
                }

                context.OutputParameters["Payload"] = payloadData;
                context.OutputParameters["IsSuccess"] = true;
                context.OutputParameters["ErrorMessage"] = "";

            }
            catch (Exception ex)
            {
                context.OutputParameters["Payload"] = "";
                context.OutputParameters["IsSuccess"] = false;
                context.OutputParameters["ErrorMessage"] = ex.Message;
            }
        }

        private static List<Entity> GetSAPAccountSupportMasterData(IOrganizationService service)
        {
            string fetchquery = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='niq_sapaccountmastersupportdata'>
                                    <attribute name='niq_sapaccountmastersupportdataid' />
                                    <attribute name='niq_name' />
                                    <attribute name='niq_mastervalue' />
                                    <attribute name='niq_mastertype' />
                                    <attribute name='niq_masteridentity' />
                                    <order attribute='niq_name' descending='false' />
                                  </entity>
                                </fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchquery)).Entities.ToList();

        }
    }
}
