﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.ComponentModel;
using System.Configuration;
using System.Net;
using Microsoft.Xrm.Tooling.Connector;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace NIQ.D365.Int.Tester
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Connection();
        }
        static IOrganizationService service;
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string str = File.ReadAllText(@"C:\Work\Code\NIQ-D365-INT-DEV\SourceCode\Custom\NIQ.D365.Int.Custom.UnitTest\SAPContractSamples\QuoteDetailPayload.json");
                var jobjQuoteDetailPayload = JToken.Parse(str);
               var bb = jobjQuoteDetailPayload.SelectTokens("$.value[?(@.niq_lineitemnumberforsap == '000010')]") ;
                var cc = bb.First() as JObject;
              //  bb.Add("test", "dd");

                var jval = jobjQuoteDetailPayload["value"].First() as JObject;
                jval.Add("test", "dpe");

                var lstQuotedetail = jobjQuoteDetailPayload["value"].GroupBy(f => f["niq_lineitemnumberforsap"]).ToList();

                var item = lstQuotedetail[0].ToList().Where(f => Convert.ToString(f["niq_materialcharacteristic.niq_characteristiccode"]).ToString().Length > 0).ToList();


                return;
                IEnumerable<JToken> j= jobjQuoteDetailPayload.SelectTokens("$.value[?(@.niq_lineitemnumberforsap == '000020')]");
               // var jj = j.ToList();
                JToken a = j.First();
                var aaa = a.Contains("productpricelevel.niq_itemcategorygroup");
                var aa = Convert.ToString( a["productpricelevel.niq_itemcategorygroup"]);
                /*
                foreach (var item in j.First())
                {
                    Console.Write(item);
                }
               */
            }
            catch (Exception ex)
            {
                string str = ex.Message;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string str = File.ReadAllText(@"C:\Work\Code\NIQ-D365-INT-DEV\SourceCode\Custom\NIQ.D365.Int.Custom.UnitTest\SAPContractSamples\OptyNQuotePayload.json");
                var o = JToken.Parse(str);
            }
            catch (Exception ex)
            {
                string str = ex.Message;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

                string ss =  Environment.NewLine + "sdsd";
                string aaaaaa = ss.Trim();

                var en =  "100000006.07555";
                string b = decimal.Parse(en).ToString("F");
                 var val = ((BILLING_FREQUENCY)int.Parse( en));
                var a = Enum.IsDefined(typeof(BILLING_FREQUENCY), int.Parse(en));

                string str = File.ReadAllText(@"C:\Work\Code\NIQ-D365-INT-DEV\SourceCode\Custom\NIQ.D365.Int.Custom.UnitTest\SAPContractSamples\ItemCategoryGrpMtDtPayload.json");
                var jobjItemCtgryGrpMtdtPayloado = JToken.Parse(str);
                var jobjMTDT = jobjItemCtgryGrpMtdtPayloado.SelectTokens("$.value[?(@.niq_itemcategorygroup ==100000021)]").First();
                var aa = Convert.ToBoolean( jobjMTDT["niq_orderquantity"]);

            }
            catch (Exception ex)
            {
                string str = ex.Message;
            }
        }

      

        public enum BILLING_FREQUENCY //Billing Frequency
        {
            enum_50 = 100000000 | 100000006,  // Monthly , Monthly with Lag
            enum_54 = 100000002 | 100000008, //Quaterly ,Quaterly with Lag
            enum_55 = 100000001 | 100000007, //BI-Monthly ,BI-Monthly with Lag 
            enum_56 = 100000003,  //Half-Yearly
            enum_57 = 100000004,  //3 * Annually
            enum_58 = 100000004,  // Annually
        }

        private void btn_quotecreate_Click(object sender, EventArgs e)
        {
            ProcessQuote_QP();
        }

        private void ProcessQuote_QP()
        {
            Guid _opportunityId = Guid.Parse("a173b41a-2468-4873-94cc-a5092c577e6c");
            Guid _quoteId;
            try
            {
                // Convert the opportunity to a quote
                var genQuoteFromOppRequest = new GenerateQuoteFromOpportunityRequest
                {
                    OpportunityId = _opportunityId,
                    ColumnSet = new ColumnSet("quoteid", "name")
                };
                Entity quote=null;
              
    var genQuoteFromOppResponse = (GenerateQuoteFromOpportunityResponse)
                        service.Execute(genQuoteFromOppRequest);
                     quote = genQuoteFromOppResponse.Entity;
                    _quoteId = quote.Id;

                    Console.WriteLine("Quote generated from the Opportunity.");

                Guid _quoteDetailId;
                // 
                for (int i = 0; i < 450; i++)
                {

                    // Set the quote's product
                    Entity quoteDetail = new Entity("quotedetail");
                    quoteDetail["productid"] = new EntityReference("product", Guid.Parse("4aa8a4d8-5a41-ec11-8c60-0022480a48db"));
                    quoteDetail["quantity"] =(decimal) 1;
                    quoteDetail["quoteid"] = new EntityReference("quote", quote.Id);
                    quoteDetail["uomid"] = new EntityReference("uom", Guid.Parse("f454f101-780e-ed11-82e4-6045bd8e1d19"));
                    _quoteDetailId = service.Create(quoteDetail);
                };
                
                // Activate the quote
                SetStateRequest activateQuote = new SetStateRequest()
                {
                    EntityMoniker = quote.ToEntityReference(),
                    State = new OptionSetValue(1),
                    Status = new OptionSetValue(2)
                };
                service.Execute(activateQuote);
                Console.WriteLine("Winstart="+ DateTime.Now.ToString());

                WinQuoteRequest winQuoteRequest = new WinQuoteRequest();
                Entity quoteClose = new Entity("quoteclose");
                quoteClose.Attributes["quoteid"] = quote.ToEntityReference();
                quoteClose.Attributes["subject"] = string.Format("Quote Close-{0}_{1}", quote.Id, DateTime.Now.ToString());
                winQuoteRequest.QuoteClose = quoteClose;
                winQuoteRequest.Status = new OptionSetValue(-1);
                service.Execute(winQuoteRequest);
                
                Console.WriteLine("WinClose=" + DateTime.Now.ToString());
            }
            catch (Exception ex)
            {
                string str = ex.Message;
            }
        }

        public void Connection()
        {
            try
            {
                string strConnectionString = ConfigurationManager.AppSettings["CRMConnection"];

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                CrmServiceClient con = new CrmServiceClient(strConnectionString);

                if (con.OrganizationWebProxyClient != null)
                    service = con.OrganizationWebProxyClient;
                else
                    service = con.OrganizationServiceProxy;


                Guid orgid = ((WhoAmIResponse)service.Execute(new WhoAmIRequest())).OrganizationId;
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection is failed" + ex.Message);
                throw ex;
            }
        }

        private void btn_copyQP_Click(object sender, EventArgs e)
        {
            try
            {
                Guid QPid = Guid.Parse("a5133fe0-02fb-ed11-8849-000d3a20dec7");
                ColumnSet col = new ColumnSet(true);
                Entity quoteP = service.Retrieve("quotedetail", QPid, col);
                for (int i = 0; i < 2; i++)
                {
                    // Set the quote's product
                    Entity quoteDetail = new Entity("quotedetail");
                    quoteDetail["quoteid"] = quoteP["quoteid"];
                    quoteDetail["quantity"] = (decimal)1;
                    //quoteDetail["baseamount"] = new Money(8);
                    quoteDetail["ispriceoverridden"] = true;
                    quoteDetail["priceperunit"] = new Money(8);
                    quoteDetail["productid"] = quoteP["productid"];
                    quoteDetail["uomid"] = quoteP["uomid"];
                    quoteDetail["description"] = quoteP["description"];
                    // quoteDetail["niq_brandid"] = quoteP["niq_brandid"];
                    //quoteDetail["niq_subbrandid"] = quoteP["niq_subbrandid"];
                    service.Create(quoteDetail);
                };


            }
            catch (Exception ex)
            {
                string str = ex.Message;
            }
        }

        private void btn_wonopty_Click(object sender, EventArgs e)
        {
            try
            {
                Entity OpporClose = new Entity("opportunityclose");

                OpporClose["actualend"] = DateTime.Now;
                OpporClose["opportunityid"] = new EntityReference("opportunity",Guid.Parse("5f5dc7dd-44f9-46f4-a9f7-fbe2b02f06a8"));
                OpporClose["opportunitystatecode"] = new OptionSetValue(1);
                OpporClose["opportunitystatuscode"] = new OptionSetValue(3);
                service.Create(OpporClose);
              
            }
            catch (Exception ex)
            {
                string s = ex.Message;
            }
        }
    }

    public class ENUMS
    {
        public enum MATERIALGRP5 //TERM TYPE
        {
            enum_001 = 100000001,//Fixed
            enum_002 = 100000000,//Evergreen
        }
        public enum MATERIALGRP4 //Lag Revenue Recognition
        {
            enum_001 = 100000000,  // Delivery Schedule without Lag
            enum_002 = 100000001, //Delivery Schedule with Lag
            enum_003 = 100000002, //Delivery Schedule with Two month Lag 
            enum_004 = 100000003  //Custom Delivery
        }
        public enum BILLING_FREQUENCY //Billing Frequency
        {
            enum_50 = 100000000 | 100000006,  // Monthly , Monthly with Lag
            enum_54 = 100000002 | 100000008, //Quaterly ,Quaterly with Lag
            enum_55 = 100000001 | 100000007, //BI-Monthly ,BI-Monthly with Lag 
            enum_56 = 100000003,  //Half-Yearly
            enum_57 = 100000004,  //3 * Annually
            enum_58 = 100000005,  // Annually
        }
        public enum DELIVERY_FREQUENCY //Lag Revenue Recognition
        {
            enum_Z1 = 100000000,  // Monthly
            enum_Z2 = 100000001, //BI-Monthly
            enum_Z3 = 100000002, //Quarterly 
            enum_Z4 = 100000003,  //3 * Annually
            enum_Z5 = 100000004,  //Half-Yearly
            enum_Z6 = 100000005  // Annually
        }
    }

}
