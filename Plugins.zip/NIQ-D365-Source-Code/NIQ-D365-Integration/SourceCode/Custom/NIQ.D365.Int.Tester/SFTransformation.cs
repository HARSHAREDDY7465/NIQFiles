﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NIQ.D365.Int.Tester
{
    public partial class SFTransformation : Form
    {
        IOrganizationService service;
        List<string> lstLog=new List<string>();
        DataTable dtCSVUsers;
        public SFTransformation()
        {
            InitializeComponent();
        }

        private void btn_start_Click(object sender, EventArgs e)
        {
            try
            {
                btn_start.Enabled = false;
                
              
                lstLog = new List<string>();

              

                DataTable dtUserMapping = Util.GetTablefromCSV(this.txt_Mapping.Text);
                DataTable dtPermissionSet = this.GetDatatable("PermissionSetAssignment"); // Util.GetTablefromCSV(this.txt_PermissionSet.Text);
                DataTable dtUserData = this.GetDatatable("Users");
                DataTable dtSFProfileRoles = Util.GetTablefromCSV(this.txt_SFProfileRoles.Text);
                this.CreateDataTable();
                int i = 1;

                DataRow[] drUsers;
                if (this.chk_usertype.Checked)
                    drUsers = dtUserData.Select("(ContactId is NULL OR ContactId='') AND IsActive='TRUE' ");
                else
                    drUsers = dtUserData.Select("(ContactId is not NULL OR ContactId <>'') AND IsActive='TRUE' ");

                foreach (DataRow dr in drUsers)
                {
                    //Users
                    this.lbl_index.Text = i.ToString();
                    this.Refresh();
                    this.DoProcess(dr, dtUserMapping, dtPermissionSet, dtSFProfileRoles);
                   
                    i++;
                }

                Util.ToCSV(this.dtCSVUsers,this.txt_outputfile.Text);
                File.WriteAllLines(this.txt_logpath.Text+ @"\SFTranslog_"+DateTime.Now.ToString("yyyy-MM-ddTHHmmss") + ".csv", lstLog.ToArray());
             

            }
            catch (Exception ex)
            {
                string str = ex.Message + ex.StackTrace;
                MessageBox.Show(str);
            }
            finally
            {
                MessageBox.Show("Completed");
                btn_start.Enabled = true;
            }
        }

        public DataTable CreateDataTable()
        {
            dtCSVUsers = new DataTable("UserAssignment");
            dtCSVUsers.Columns.Add("FullName");
            dtCSVUsers.Columns.Add("Email");
            dtCSVUsers.Columns.Add("Roles");
            dtCSVUsers.Columns.Add("BU");
            dtCSVUsers.Columns.Add("BUGUID");
            dtCSVUsers.Columns.Add("Region");
            dtCSVUsers.Columns.Add("EmpNumber");
            dtCSVUsers.Columns.Add("Function");
            dtCSVUsers.Columns.Add("niq_geography");
            dtCSVUsers.Columns.Add("niq_customertype");
            dtCSVUsers.Columns.Add("niq_servicecategory");
            dtCSVUsers.Columns.Add("BookableResource");
            dtCSVUsers.Columns.Add("AdvanceQueue");
            dtCSVUsers.Columns.Add("ContactId");
            dtCSVUsers.Columns.Add("CSOEnhancedPrivacy");
            dtCSVUsers.Columns.Add("Marketing");
            return dtCSVUsers;
        }
        public void DoProcess(DataRow drUserData, DataTable dtUserMapping, DataTable dtPermissionSet, DataTable dtSFProfileRoles)
        {
            try
            {
                Dictionary<string, string> dic;
                DataRow drCsvData = dtCSVUsers.Rows.Add();
                drCsvData["FullName"] = drUserData["Name"];
                drCsvData["Email"] = drUserData["Email"];
                if (drUserData["ContactId"] != null && drUserData["ContactId"].ToString().Trim().Length > 2)
                {
                    dic = this.GetRolesandFieldUpdate(drUserData, dtUserMapping, dtPermissionSet, dtSFProfileRoles);
                    drCsvData["Roles"] = GetWebRoles(drUserData, dtSFProfileRoles);
                    drCsvData["ContactId"] = drUserData["ContactId"].ToString().Trim();
                }
                else { 
                     dic = this.GetRolesandFieldUpdate(drUserData, dtUserMapping, dtPermissionSet, dtSFProfileRoles);
                    drCsvData["Roles"] = dic["Roles"];
                    
                    if (drCsvData["Roles"].ToString().ToLower().Contains("china"))
                    {
                        drCsvData["BU"] = "China Retailers";
                        drCsvData["BUGUID"] = "1DD9EF2D-85FA-EB11-94EF-002248237F1B";
                    }
                    else
                    {
                        drCsvData["BU"] = "Standard";
                        drCsvData["BUGUID"] = "0A374A13-85FA-EB11-94EF-002248237F1B";
                    }
                    drCsvData["EmpNumber"] = drUserData["SAP_ID__c"];

                    drCsvData["Function"] = drUserData["Department__c"];
                    if (dic.ContainsKey("BookableResource"))
                        drCsvData["BookableResource"] = dic["BookableResource"];
                    if (dic.ContainsKey("AdvanceQueue"))
                        drCsvData["AdvanceQueue"] = dic["AdvanceQueue"];
                  
                    drCsvData["CSOEnhancedPrivacy"] = drUserData["CSO_Enhanced_Privacy__c"];
                    drCsvData["Marketing"] = drUserData["Marketing__c"];

                    string strRoles = drCsvData["Roles"].ToString().Trim().ToLower();
                    //Activity Tracker Add On
                    if (drCsvData["CSOEnhancedPrivacy"]!=null && drCsvData["CSOEnhancedPrivacy"].ToString().Trim().ToLower() == "false" &&
                        (strRoles.Contains("analytics agent") || strRoles.Contains("analytics manager") || strRoles.Contains("cr agent") || strRoles.Contains("client response manager") ||
                        strRoles.Contains("delegate agent") || strRoles.Contains("delegate manager") || strRoles.Contains("niq global helpline agent") || strRoles.Contains("niq global helpline manager")))
                    {
                        drCsvData["Roles"] += ";Activity Tracker Add-on Role";
                    }
                    
                    //Marketing
                    if (drCsvData["Marketing"]!=null && drCsvData["Marketing"].ToString().Trim().ToLower() == "true")
                    { 
                        drCsvData["Roles"] += ";Marketing Professional - Business;NIQ Marketing Add-on;NIQ Marketing User;Sales Enterprise app access";
                    }
                    
                }
                if (dic.ContainsKey("niq_geography"))
                    drCsvData["niq_geography"] = dic["niq_geography"];
                if (dic.ContainsKey("niq_customertype"))
                    drCsvData["niq_customertype"] = dic["niq_customertype"];
                if (dic.ContainsKey("niq_servicecategory"))
                    drCsvData["niq_servicecategory"] = dic["niq_servicecategory"];

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public Dictionary<string,string> GetRolesandFieldUpdate(DataRow drUserData, DataTable dtUserMapping, DataTable dtPermissionSet, DataTable dtSFProfileRoles)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            dic["Roles"] = "";

            try
            {
                // PermissionSet DataTable
                DataRow[] drPermissionSets = dtPermissionSet.Select(string.Format("AssigneeId='{0}'", drUserData["Id"]));
                if (drPermissionSets != null && drPermissionSets.Length > 0)
                {
                    foreach (DataRow drPermissionSet in drPermissionSets)
                    {
                        DataRow[] drUserMappings = dtUserMapping.Select(string.Format("[Field Value]='{0}'", drPermissionSet["PermissionSetId"]));
                        if (drUserMappings != null && drUserMappings.Length > 0)
                        {
                            foreach (DataRow drUserMapp in drUserMappings)
                            {

                                if (drUserMapp["Value"] != null && drUserMapp["Value"].ToString().Length > 0)
                                {
                                    //FieldUpdate
                                    if (drUserMapp["Type"] != null && drUserMapp["Type"].ToString().ToLower() == "field update" &&
                                    drUserMapp["Table (if applicable)"] != null &&
                                     drUserMapp["Table (if applicable)"].ToString().ToLower() == (this.chk_usertype.Checked? "systemuser":"contact")
                                    )
                                    {

                                        if (drUserMapp["Field (if applicable)"] != null && drUserMapp["Field (if applicable)"].ToString().Length > 0
                                            && dic.ContainsKey(drUserMapp["Field (if applicable)"].ToString()))
                                        {
                                            string fieldValue = dic[drUserMapp["Field (if applicable)"].ToString()];
                                            dic[drUserMapp["Field (if applicable)"].ToString()] = fieldValue + ";" + Convert.ToString(drUserMapp["Value"]);
                                        }
                                        else
                                            dic[drUserMapp["Field (if applicable)"].ToString()] = Convert.ToString(drUserMapp["Value"]);
                                    }

                                    // Role
                                    if ( this.chk_usertype.Checked && drUserMapp["Type"] != null && drUserMapp["Type"].ToString().ToLower().Contains("role"))
                                    {
                                        string fieldValue = dic["Roles"];
                                        if (!fieldValue.ToLower().Contains(drUserMapp["Value"].ToString().ToLower()))
                                        {
                                            if (fieldValue.Trim().Length > 1)
                                                fieldValue = fieldValue + ";";
                                            dic["Roles"] = fieldValue + Convert.ToString(drUserMapp["Value"]);
                                        }
                                    }

                                }


                            }
                        }
                    }
                }
                if (this.chk_usertype.Checked)
                {

                    //SF Profile Roles , Bookable Resource,Advance Queue
                    string filter = "Id='{0}' and (Action='Role' or Action='Role Addition' or Action='Make bookable resource' or  Action='Advance Queue')";
                    DataRow[] drSFProfileRoles = dtSFProfileRoles.Select(string.Format(filter, drUserData["ProfileId"]));
                    if (drSFProfileRoles != null && drSFProfileRoles.Length > 0)
                    {
                        foreach (DataRow drSFPRofile in drSFProfileRoles)
                        {
                            //Bookable Resource
                            if (drSFPRofile["Action"].ToString() == "Make bookable resource")
                            {
                                dic["BookableResource"] = "Yes";
                            }
                            else if (drSFPRofile["Action"].ToString() == "Advance Queue" && drSFPRofile["Value"] != null && drSFPRofile["Value"].ToString().Length > 0)
                            {
                                dic["AdvanceQueue"] = drSFPRofile["Value"].ToString();
                            }
                            //Roles
                            else if (drSFPRofile["Value"] != null && drSFPRofile["Value"].ToString().Length > 0 &&
                               (drSFPRofile["Action"].ToString() == "Role" || drSFPRofile["Action"].ToString() == "Role Addition"))
                            {
                                string fieldValue = dic["Roles"];
                                if (fieldValue.Trim().Length > 1)
                                    fieldValue = fieldValue + ";";
                                dic["Roles"] = fieldValue + Convert.ToString(drSFPRofile["Value"]);
                            }
                        }
                    }

                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dic;
        }

        public string GetWebRoles(DataRow drUserData, DataTable dtSFProfileRoles)
        {
            try
            {
                string strWebRole = "";
                //SF Profile WebRoles
                DataRow[] drSFProfileWebRoles = dtSFProfileRoles.Select(string.Format("Id='{0}' and Action='Web Role'", drUserData["ProfileId"]));
                if (drSFProfileWebRoles != null && drSFProfileWebRoles.Length > 0)
                {
                    foreach (DataRow drSFProfileWebRole in drSFProfileWebRoles)
                    {
                        if (drSFProfileWebRole["Value"] != null && drSFProfileWebRole["Value"].ToString().Length > 0)
                        {
                            string fieldValue = strWebRole;
                            if (fieldValue.Trim().Length > 1)
                                fieldValue = fieldValue + ";";
                            strWebRole = fieldValue + Convert.ToString(drSFProfileWebRole["Value"]);
                        }
                    }
                }
                return strWebRole;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public DataTable GetDatatable(string tablename)
        {
            try
            {
                string connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + this.txt_accessdb.Text;
                string strSQL = "SELECT * FROM " + tablename;
                // Create a connection    
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    // Create a command and set its connection    
                    OleDbCommand command = new OleDbCommand(strSQL, connection);
                    // Open the connection and execute the select command.    
                    try
                    {
                        // Open connecton    
                        connection.Open();
                        // Execute command    
                        using (OleDbDataAdapter da = new OleDbDataAdapter(command))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            connection.Close();
                            return dt;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    // The connection is automatically closed becasuse of using block.    
                }
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
