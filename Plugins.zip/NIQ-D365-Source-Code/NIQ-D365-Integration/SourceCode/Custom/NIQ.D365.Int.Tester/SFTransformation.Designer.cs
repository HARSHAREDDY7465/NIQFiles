﻿namespace NIQ.D365.Int.Tester
{
    partial class SFTransformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_start = new System.Windows.Forms.Button();
            this.txt_Mapping = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_logpath = new System.Windows.Forms.TextBox();
            this.lbl_index = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_UserData = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_PermissionSet = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_SFProfileRoles = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_outputfile = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_accessdb = new System.Windows.Forms.TextBox();
            this.chk_usertype = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // btn_start
            // 
            this.btn_start.Location = new System.Drawing.Point(28, 244);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(75, 23);
            this.btn_start.TabIndex = 0;
            this.btn_start.Text = "Start";
            this.btn_start.UseVisualStyleBackColor = true;
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
            // 
            // txt_Mapping
            // 
            this.txt_Mapping.Location = new System.Drawing.Point(99, 13);
            this.txt_Mapping.Name = "txt_Mapping";
            this.txt_Mapping.Size = new System.Drawing.Size(470, 20);
            this.txt_Mapping.TabIndex = 1;
            this.txt_Mapping.Text = "C:\\Work\\UserRoles\\SFTrans\\User Mapping Table_PermissionSet.csv";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Mapping Table";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "LogPath";
            // 
            // txt_logpath
            // 
            this.txt_logpath.Location = new System.Drawing.Point(100, 148);
            this.txt_logpath.Name = "txt_logpath";
            this.txt_logpath.Size = new System.Drawing.Size(470, 20);
            this.txt_logpath.TabIndex = 4;
            this.txt_logpath.Text = "C:\\Work\\UserRoles\\SFTrans";
            // 
            // lbl_index
            // 
            this.lbl_index.AutoSize = true;
            this.lbl_index.Location = new System.Drawing.Point(128, 249);
            this.lbl_index.Name = "lbl_index";
            this.lbl_index.Size = new System.Drawing.Size(33, 13);
            this.lbl_index.TabIndex = 5;
            this.lbl_index.Text = "Index";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "UserList Extract";
            // 
            // txt_UserData
            // 
            this.txt_UserData.Location = new System.Drawing.Point(100, 39);
            this.txt_UserData.Name = "txt_UserData";
            this.txt_UserData.Size = new System.Drawing.Size(470, 20);
            this.txt_UserData.TabIndex = 9;
            this.txt_UserData.Text = "C:\\Work\\UserRoles\\SFTrans\\Sample User Extract.csv";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "PermissionSet";
            // 
            // txt_PermissionSet
            // 
            this.txt_PermissionSet.Location = new System.Drawing.Point(99, 65);
            this.txt_PermissionSet.Name = "txt_PermissionSet";
            this.txt_PermissionSet.Size = new System.Drawing.Size(470, 20);
            this.txt_PermissionSet.TabIndex = 11;
            this.txt_PermissionSet.Text = "C:\\Work\\UserRoles\\SFTrans\\PermissionSetAssignment.csv";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 94);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "SF Profile Roles";
            // 
            // txt_SFProfileRoles
            // 
            this.txt_SFProfileRoles.Location = new System.Drawing.Point(100, 91);
            this.txt_SFProfileRoles.Name = "txt_SFProfileRoles";
            this.txt_SFProfileRoles.Size = new System.Drawing.Size(470, 20);
            this.txt_SFProfileRoles.TabIndex = 13;
            this.txt_SFProfileRoles.Text = "C:\\Work\\UserRoles\\SFTrans\\User Mapping Table_SFRoles.csv";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 189);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "OUTPUT FILE(Users)";
            // 
            // txt_outputfile
            // 
            this.txt_outputfile.Location = new System.Drawing.Point(126, 186);
            this.txt_outputfile.Name = "txt_outputfile";
            this.txt_outputfile.Size = new System.Drawing.Size(444, 20);
            this.txt_outputfile.TabIndex = 15;
            this.txt_outputfile.Text = "C:\\Work\\UserRoles\\Users_UAT_RoleAssignment_original.csv";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 120);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 13);
            this.label7.TabIndex = 18;
            this.label7.Text = "Access DB";
            // 
            // txt_accessdb
            // 
            this.txt_accessdb.Location = new System.Drawing.Point(100, 117);
            this.txt_accessdb.Name = "txt_accessdb";
            this.txt_accessdb.Size = new System.Drawing.Size(470, 20);
            this.txt_accessdb.TabIndex = 17;
            this.txt_accessdb.Text = "C:\\Work\\UserRoles\\UserRolesDB.mdb";
            // 
            // chk_usertype
            // 
            this.chk_usertype.AutoSize = true;
            this.chk_usertype.Location = new System.Drawing.Point(23, 221);
            this.chk_usertype.Name = "chk_usertype";
            this.chk_usertype.Size = new System.Drawing.Size(205, 17);
            this.chk_usertype.TabIndex = 19;
            this.chk_usertype.Text = "Internal User (Yes) , External User(No)";
            this.chk_usertype.UseVisualStyleBackColor = true;
            // 
            // SFTransformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 289);
            this.Controls.Add(this.chk_usertype);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_accessdb);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_outputfile);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_SFProfileRoles);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_PermissionSet);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_UserData);
            this.Controls.Add(this.lbl_index);
            this.Controls.Add(this.txt_logpath);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_Mapping);
            this.Controls.Add(this.btn_start);
            this.Name = "SFTransformation";
            this.Text = "SFTransformation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.TextBox txt_Mapping;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_logpath;
        private System.Windows.Forms.Label lbl_index;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_UserData;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_PermissionSet;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_SFProfileRoles;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_outputfile;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_accessdb;
        private System.Windows.Forms.CheckBox chk_usertype;
    }
}