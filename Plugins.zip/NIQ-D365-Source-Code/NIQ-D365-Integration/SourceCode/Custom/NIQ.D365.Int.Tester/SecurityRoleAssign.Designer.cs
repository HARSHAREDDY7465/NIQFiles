﻿namespace NIQ.D365.Int.Tester
{
    partial class SecurityRoleAssign
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_start = new System.Windows.Forms.Button();
            this.txt_Filepath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_logpath = new System.Windows.Forms.TextBox();
            this.lbl_index = new System.Windows.Forms.Label();
            this.chk_assignBU = new System.Windows.Forms.CheckBox();
            this.chk_UserUpdate = new System.Windows.Forms.CheckBox();
            this.chk_SecurityRole = new System.Windows.Forms.CheckBox();
            this.btn_Sftransformation = new System.Windows.Forms.Button();
            this.chk_bookableresource = new System.Windows.Forms.CheckBox();
            this.chk_AdvanceQ = new System.Windows.Forms.CheckBox();
            this.chk_ContactWebRole = new System.Windows.Forms.CheckBox();
            this.lbl_CRMURL = new System.Windows.Forms.Label();
            this.chk_contactfieldupdate = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_accessteam = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_accessteamindex = new System.Windows.Forms.Label();
            this.btn_Accessteam = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_tablename = new System.Windows.Forms.TextBox();
            this.txt_start = new System.Windows.Forms.TextBox();
            this.txt_End = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_start
            // 
            this.btn_start.Location = new System.Drawing.Point(32, 208);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(75, 23);
            this.btn_start.TabIndex = 0;
            this.btn_start.Text = "Start";
            this.btn_start.UseVisualStyleBackColor = true;
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
            // 
            // txt_Filepath
            // 
            this.txt_Filepath.Location = new System.Drawing.Point(88, 13);
            this.txt_Filepath.Name = "txt_Filepath";
            this.txt_Filepath.Size = new System.Drawing.Size(343, 20);
            this.txt_Filepath.TabIndex = 1;
            this.txt_Filepath.Text = "C:\\Work\\UserRoles\\Users_UAT_RoleAssignment_original.csv";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "UserList";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "LogPath";
            // 
            // txt_logpath
            // 
            this.txt_logpath.Location = new System.Drawing.Point(88, 52);
            this.txt_logpath.Name = "txt_logpath";
            this.txt_logpath.Size = new System.Drawing.Size(343, 20);
            this.txt_logpath.TabIndex = 4;
            this.txt_logpath.Text = "C:\\Work\\UserRoles";
            // 
            // lbl_index
            // 
            this.lbl_index.AutoSize = true;
            this.lbl_index.Location = new System.Drawing.Point(132, 213);
            this.lbl_index.Name = "lbl_index";
            this.lbl_index.Size = new System.Drawing.Size(33, 13);
            this.lbl_index.TabIndex = 5;
            this.lbl_index.Text = "Index";
            // 
            // chk_assignBU
            // 
            this.chk_assignBU.AutoSize = true;
            this.chk_assignBU.Location = new System.Drawing.Point(33, 99);
            this.chk_assignBU.Name = "chk_assignBU";
            this.chk_assignBU.Size = new System.Drawing.Size(124, 17);
            this.chk_assignBU.TabIndex = 6;
            this.chk_assignBU.Text = "Assign Business Unit";
            this.chk_assignBU.UseVisualStyleBackColor = true;
            // 
            // chk_UserUpdate
            // 
            this.chk_UserUpdate.AutoSize = true;
            this.chk_UserUpdate.Location = new System.Drawing.Point(360, 98);
            this.chk_UserUpdate.Name = "chk_UserUpdate";
            this.chk_UserUpdate.Size = new System.Drawing.Size(107, 17);
            this.chk_UserUpdate.TabIndex = 7;
            this.chk_UserUpdate.Text = "Update User Info";
            this.chk_UserUpdate.UseVisualStyleBackColor = true;
            // 
            // chk_SecurityRole
            // 
            this.chk_SecurityRole.AutoSize = true;
            this.chk_SecurityRole.Location = new System.Drawing.Point(215, 98);
            this.chk_SecurityRole.Name = "chk_SecurityRole";
            this.chk_SecurityRole.Size = new System.Drawing.Size(123, 17);
            this.chk_SecurityRole.TabIndex = 8;
            this.chk_SecurityRole.Text = "Assign Security Role";
            this.chk_SecurityRole.UseVisualStyleBackColor = true;
            // 
            // btn_Sftransformation
            // 
            this.btn_Sftransformation.Location = new System.Drawing.Point(242, 208);
            this.btn_Sftransformation.Name = "btn_Sftransformation";
            this.btn_Sftransformation.Size = new System.Drawing.Size(133, 23);
            this.btn_Sftransformation.TabIndex = 9;
            this.btn_Sftransformation.Text = "SF Transformation";
            this.btn_Sftransformation.UseVisualStyleBackColor = true;
            this.btn_Sftransformation.Click += new System.EventHandler(this.btn_Sftransformation_Click);
            // 
            // chk_bookableresource
            // 
            this.chk_bookableresource.AutoSize = true;
            this.chk_bookableresource.Location = new System.Drawing.Point(32, 133);
            this.chk_bookableresource.Name = "chk_bookableresource";
            this.chk_bookableresource.Size = new System.Drawing.Size(120, 17);
            this.chk_bookableresource.TabIndex = 12;
            this.chk_bookableresource.Text = "Bookable Resource";
            this.chk_bookableresource.UseVisualStyleBackColor = true;
            // 
            // chk_AdvanceQ
            // 
            this.chk_AdvanceQ.AutoSize = true;
            this.chk_AdvanceQ.Location = new System.Drawing.Point(215, 133);
            this.chk_AdvanceQ.Name = "chk_AdvanceQ";
            this.chk_AdvanceQ.Size = new System.Drawing.Size(104, 17);
            this.chk_AdvanceQ.TabIndex = 13;
            this.chk_AdvanceQ.Text = "Advance Queue";
            this.chk_AdvanceQ.UseVisualStyleBackColor = true;
            // 
            // chk_ContactWebRole
            // 
            this.chk_ContactWebRole.AutoSize = true;
            this.chk_ContactWebRole.Location = new System.Drawing.Point(32, 167);
            this.chk_ContactWebRole.Name = "chk_ContactWebRole";
            this.chk_ContactWebRole.Size = new System.Drawing.Size(111, 17);
            this.chk_ContactWebRole.TabIndex = 14;
            this.chk_ContactWebRole.Text = "Contact WebRole";
            this.chk_ContactWebRole.UseVisualStyleBackColor = true;
            // 
            // lbl_CRMURL
            // 
            this.lbl_CRMURL.AutoSize = true;
            this.lbl_CRMURL.Location = new System.Drawing.Point(29, 252);
            this.lbl_CRMURL.Name = "lbl_CRMURL";
            this.lbl_CRMURL.Size = new System.Drawing.Size(53, 13);
            this.lbl_CRMURL.TabIndex = 15;
            this.lbl_CRMURL.Text = "CRMURL";
            // 
            // chk_contactfieldupdate
            // 
            this.chk_contactfieldupdate.AutoSize = true;
            this.chk_contactfieldupdate.Location = new System.Drawing.Point(215, 167);
            this.chk_contactfieldupdate.Name = "chk_contactfieldupdate";
            this.chk_contactfieldupdate.Size = new System.Drawing.Size(122, 17);
            this.chk_contactfieldupdate.TabIndex = 16;
            this.chk_contactfieldupdate.Text = "Update Contact Info";
            this.chk_contactfieldupdate.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(341, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "UserList";
            // 
            // txt_accessteam
            // 
            this.txt_accessteam.Location = new System.Drawing.Point(702, 12);
            this.txt_accessteam.Name = "txt_accessteam";
            this.txt_accessteam.Size = new System.Drawing.Size(343, 20);
            this.txt_accessteam.TabIndex = 17;
            this.txt_accessteam.Text = "C:\\Work\\UserRoles\\AcessTeamDB.mdb";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(600, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "Access Team (mdb)";
            // 
            // lbl_accessteamindex
            // 
            this.lbl_accessteamindex.AutoSize = true;
            this.lbl_accessteamindex.Location = new System.Drawing.Point(703, 77);
            this.lbl_accessteamindex.Name = "lbl_accessteamindex";
            this.lbl_accessteamindex.Size = new System.Drawing.Size(33, 13);
            this.lbl_accessteamindex.TabIndex = 21;
            this.lbl_accessteamindex.Text = "Index";
            // 
            // btn_Accessteam
            // 
            this.btn_Accessteam.Location = new System.Drawing.Point(603, 72);
            this.btn_Accessteam.Name = "btn_Accessteam";
            this.btn_Accessteam.Size = new System.Drawing.Size(75, 23);
            this.btn_Accessteam.TabIndex = 20;
            this.btn_Accessteam.Text = "Start";
            this.btn_Accessteam.UseVisualStyleBackColor = true;
            this.btn_Accessteam.Click += new System.EventHandler(this.btn_Accessteam_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(600, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 23;
            this.label5.Text = "TableName";
            // 
            // txt_tablename
            // 
            this.txt_tablename.Location = new System.Drawing.Point(702, 38);
            this.txt_tablename.Name = "txt_tablename";
            this.txt_tablename.Size = new System.Drawing.Size(343, 20);
            this.txt_tablename.TabIndex = 22;
            this.txt_tablename.Text = "OpportunityAccessTeam";
            // 
            // txt_start
            // 
            this.txt_start.Location = new System.Drawing.Point(603, 101);
            this.txt_start.Name = "txt_start";
            this.txt_start.Size = new System.Drawing.Size(59, 20);
            this.txt_start.TabIndex = 24;
            this.txt_start.Text = "0";
            // 
            // txt_End
            // 
            this.txt_End.Location = new System.Drawing.Point(677, 101);
            this.txt_End.Name = "txt_End";
            this.txt_End.Size = new System.Drawing.Size(73, 20);
            this.txt_End.TabIndex = 25;
            this.txt_End.Text = "5000";
            // 
            // SecurityRoleAssign
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 289);
            this.Controls.Add(this.txt_End);
            this.Controls.Add(this.txt_start);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_tablename);
            this.Controls.Add(this.lbl_accessteamindex);
            this.Controls.Add(this.btn_Accessteam);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_accessteam);
            this.Controls.Add(this.chk_contactfieldupdate);
            this.Controls.Add(this.lbl_CRMURL);
            this.Controls.Add(this.chk_ContactWebRole);
            this.Controls.Add(this.chk_AdvanceQ);
            this.Controls.Add(this.chk_bookableresource);
            this.Controls.Add(this.btn_Sftransformation);
            this.Controls.Add(this.chk_SecurityRole);
            this.Controls.Add(this.chk_UserUpdate);
            this.Controls.Add(this.chk_assignBU);
            this.Controls.Add(this.lbl_index);
            this.Controls.Add(this.txt_logpath);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_Filepath);
            this.Controls.Add(this.btn_start);
            this.Name = "SecurityRoleAssign";
            this.Text = "SecurityRoleAssign";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.TextBox txt_Filepath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_logpath;
        private System.Windows.Forms.Label lbl_index;
        private System.Windows.Forms.CheckBox chk_assignBU;
        private System.Windows.Forms.CheckBox chk_UserUpdate;
        private System.Windows.Forms.CheckBox chk_SecurityRole;
        private System.Windows.Forms.Button btn_Sftransformation;
        private System.Windows.Forms.CheckBox chk_bookableresource;
        private System.Windows.Forms.CheckBox chk_AdvanceQ;
        private System.Windows.Forms.CheckBox chk_ContactWebRole;
        private System.Windows.Forms.Label lbl_CRMURL;
        private System.Windows.Forms.CheckBox chk_contactfieldupdate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_accessteam;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_accessteamindex;
        private System.Windows.Forms.Button btn_Accessteam;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_tablename;
        private System.Windows.Forms.TextBox txt_start;
        private System.Windows.Forms.TextBox txt_End;
    }
}