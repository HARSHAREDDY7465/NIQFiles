﻿namespace NIQ.D365.Int.Tester
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btn_quotecreate = new System.Windows.Forms.Button();
            this.btn_closeQuote = new System.Windows.Forms.Button();
            this.btn_copyQP = new System.Windows.Forms.Button();
            this.btn_wonopty = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(30, 25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Json Parse";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(120, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "opty";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(218, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "Mtdt";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_quotecreate
            // 
            this.btn_quotecreate.Location = new System.Drawing.Point(368, 11);
            this.btn_quotecreate.Name = "btn_quotecreate";
            this.btn_quotecreate.Size = new System.Drawing.Size(75, 23);
            this.btn_quotecreate.TabIndex = 3;
            this.btn_quotecreate.Text = "QuoteCreate";
            this.btn_quotecreate.UseVisualStyleBackColor = true;
            this.btn_quotecreate.Click += new System.EventHandler(this.btn_quotecreate_Click);
            // 
            // btn_closeQuote
            // 
            this.btn_closeQuote.Location = new System.Drawing.Point(368, 40);
            this.btn_closeQuote.Name = "btn_closeQuote";
            this.btn_closeQuote.Size = new System.Drawing.Size(75, 23);
            this.btn_closeQuote.TabIndex = 4;
            this.btn_closeQuote.Text = "Quote Close";
            this.btn_closeQuote.UseVisualStyleBackColor = true;
            // 
            // btn_copyQP
            // 
            this.btn_copyQP.Location = new System.Drawing.Point(55, 70);
            this.btn_copyQP.Name = "btn_copyQP";
            this.btn_copyQP.Size = new System.Drawing.Size(75, 23);
            this.btn_copyQP.TabIndex = 5;
            this.btn_copyQP.Text = "Copy QP";
            this.btn_copyQP.UseVisualStyleBackColor = true;
            this.btn_copyQP.Click += new System.EventHandler(this.btn_copyQP_Click);
            // 
            // btn_wonopty
            // 
            this.btn_wonopty.Location = new System.Drawing.Point(368, 69);
            this.btn_wonopty.Name = "btn_wonopty";
            this.btn_wonopty.Size = new System.Drawing.Size(75, 23);
            this.btn_wonopty.TabIndex = 6;
            this.btn_wonopty.Text = "Won Oppty";
            this.btn_wonopty.UseVisualStyleBackColor = true;
            this.btn_wonopty.Click += new System.EventHandler(this.btn_wonopty_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(692, 301);
            this.Controls.Add(this.btn_wonopty);
            this.Controls.Add(this.btn_copyQP);
            this.Controls.Add(this.btn_closeQuote);
            this.Controls.Add(this.btn_quotecreate);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btn_quotecreate;
        private System.Windows.Forms.Button btn_closeQuote;
        private System.Windows.Forms.Button btn_copyQP;
        private System.Windows.Forms.Button btn_wonopty;
    }
}

