﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NIQ.D365.Int.Tester
{
    public  class Util
    {
        public static DataTable GetTablefromCSV(string filepath)
        {
            DataTable dtCsv =new DataTable();
            try
            {
                var rows = File.ReadLines(filepath).ToList();

                for (int i = 0; i < rows.Count; i++)
                {
                    Console.WriteLine(i.ToString());
                    List<string> rowValues = rows[i].Split(',').ToList();
                    if (i == 0)
                    {
                        for (int j = 0; j < rowValues.Count(); j++)
                        {
                            dtCsv.Columns.Add(rowValues[j]); //add headers  
                            Console.WriteLine(j.ToString());
                        }
                    }
                    else
                    {
                        DataRow dr = dtCsv.NewRow();
                        int colQuoteIndex=-1;
                        int colIndex = 0;
                        for (int k = 0; k < rowValues.Count(); k++)
                        {

                            if (rowValues[k].ToString().StartsWith("\""))
                            {
                                colQuoteIndex = k;
                                dr[colQuoteIndex] += rowValues[k].ToString().Replace("\"", "");
                              
                                while (!rowValues[k].ToString().EndsWith("\""))
                                {
                                    k++;
                                    //if (!rowValues[k + 1].ToString().EndsWith("\"")) k++;
                                    dr[colQuoteIndex] += rowValues[k].ToString().Replace("\"", "");
                                }
                            }
                            else
                                dr[colIndex] = rowValues[k].ToString();
                            
                            Console.WriteLine(k.ToString());
                            colIndex++;
                        }
                        dtCsv.Rows.Add(dr); //add other rows  
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtCsv;
        }
        public static void ToCSV( DataTable dtDataTable, string strFilePath)
        {
            StreamWriter sw = new StreamWriter(strFilePath, false);
            //headers    
            for (int i = 0; i < dtDataTable.Columns.Count; i++)
            {
                sw.Write(dtDataTable.Columns[i]);
                if (i < dtDataTable.Columns.Count - 1)
                {
                    sw.Write(",");
                }
            }
            sw.Write(sw.NewLine);
            foreach (DataRow dr in dtDataTable.Rows)
            {
                for (int i = 0; i < dtDataTable.Columns.Count; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        string value = dr[i].ToString();
                        if (value.Contains(','))
                        {
                            value = String.Format("\"{0}\"", value);
                            sw.Write(value);
                        }
                        else
                        {
                            sw.Write(dr[i].ToString());
                        }
                    }
                    if (i < dtDataTable.Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
            }
            sw.Close();
        }

        public static DataTable GetDatatable(string tablename,string dbname)
        {
            try
            {
                string connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + dbname;
                string strSQL = "SELECT * FROM " + tablename;
                // Create a connection    
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    // Create a command and set its connection    
                    OleDbCommand command = new OleDbCommand(strSQL, connection);
                    // Open the connection and execute the select command.    
                    try
                    {
                        // Open connecton    
                        connection.Open();
                        // Execute command    
                        using (OleDbDataAdapter da = new OleDbDataAdapter(command))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            connection.Close();
                            return dt;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    // The connection is automatically closed becasuse of using block.    
                }
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
