﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NIQ.D365.Int.Tester
{
    public partial class SecurityRoleAssign : Form
    {
      static  IOrganizationService service;
       static List<string> lstLog=new List<string>();
        List<Entity> lstEntStringMap;
        string strCommKnowledgeOnly = "0cbe09f3-f8f0-eb11-bacb-0022480a5be8";
        string strCommKnowledgePlus = "76975a49-f9f0-eb11-bacb-0022480a5be8";
        List<Entity> lstEntSecurityrole;
        public SecurityRoleAssign()
        {
            InitializeComponent();
        }

        private void btn_start_Click(object sender, EventArgs e)
        {
            try
            {
                btn_start.Enabled = false;
                Connection();
                LoadStringMapData();
                loadSecurityroles();
                  lstLog = new List<string>();
                var filedata = File.ReadLines(this.txt_Filepath.Text).ToList();
                
                for (int i = 0; i < filedata.Count; i++)
                {
                    if (i == 0) continue;
                    if (filedata[i].Trim().Length <= 0) continue;
                    var lstuserinfo = filedata[i].Split(',').ToList();
                    this.lbl_index.Text = string.Format("{0} of {1}", i.ToString(), filedata.Count().ToString());
                    this.Refresh();
                    this.BUassignment(lstuserinfo);

                }
                File.WriteAllLines(this.txt_logpath.Text+ @"\log_"+DateTime.Now.ToString("yyyy-MM-ddTHHmmss") + ".csv", lstLog.ToArray());
             

            }
            catch (Exception ex)
            {
                string str = ex.Message + ex.StackTrace;
                MessageBox.Show(str);
            }
            finally
            {
                MessageBox.Show("Completed");
                btn_start.Enabled = true;
            }
        }

        public void Connection()
        {
            try
            {
            string strConnectionString = ConfigurationManager.AppSettings["CRMConnection"];

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            CrmServiceClient con = new CrmServiceClient(strConnectionString);
         
            if (con.OrganizationWebProxyClient != null)
                service = con.OrganizationWebProxyClient;
            else
                service = con.OrganizationServiceProxy;

                
            Guid orgid = ((WhoAmIResponse)service.Execute(new WhoAmIRequest())).OrganizationId;
                this.lbl_CRMURL.Text = con.OrganizationDetail.Endpoints[EndpointType.WebApplication];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection is failed" + ex.Message);
                throw ex;
            }
        }
        public void loadSecurityroles()
        {
            try
            {
                string strfetchXml = @"<fetch>
                              <entity name='role'>
                                <attribute name='name' />
                                <attribute name='roleid' />
                                <attribute name='businessunitid' />
                              </entity>
                            </fetch>";
                lstEntSecurityrole = this.GetRecordsbyFetchxml(strfetchXml);
                if (lstEntSecurityrole == null) lstEntSecurityrole = new List<Entity>();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void LoadStringMapData()
        {
            try
            {
                string strfetchXml = @"<fetch>
                      <entity name='stringmap'>
                        <attribute name='attributevalue' />
                        <attribute name='attributename' />
                        <attribute name='value' />
                        <filter>
                          <condition attribute='objecttypecode' operator='eq' value='8' />
                          <condition attribute='attributename' operator='in' value=''>
                            <value>niq_geography</value>
                            <value>niq_servicecategory</value>
                            <value>niq_customertype</value>
                            <value>niq_function</value>
                          </condition>
                        </filter>
                      </entity>
                    </fetch>";
                lstEntStringMap = this.GetRecordsbyFetchxml(strfetchXml);
                if (lstEntStringMap == null) lstEntStringMap = new List<Entity>();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void BUassignment(List<string> lstuserinfo)
        {
            try
            {
                string strfetchXml = "";
                string struserlog = "";
                if (lstuserinfo[13].Trim().Length <= 0)
                {
                     strfetchXml = string.Format(@"<fetch>  <entity name='systemuser'>
                        <filter type='and'>
                          <condition attribute='domainname' operator='eq' value='{0}' />
                        </filter>
                      </entity>
                    </fetch>", lstuserinfo[1].Trim());
                    List<Entity> entuserinfo = this.GetRecordsbyFetchxml(strfetchXml);
                     struserlog = "User->" + lstuserinfo[1];

                    if (entuserinfo != null)
                    {
                        if (this.chk_assignBU.Checked)
                        {
                            SetBusinessSystemUserRequest request = new SetBusinessSystemUserRequest();
                            request.BusinessId = Guid.Parse(lstuserinfo[4].Trim());
                            request.UserId = entuserinfo[0].Id;
                            request.ReassignPrincipal = new EntityReference("systemuser", entuserinfo[0].Id);
                            SetBusinessSystemUserResponse response = (SetBusinessSystemUserResponse)service.Execute(request);
                            struserlog += ",BU Assigned";
                        }
                        if (this.chk_SecurityRole.Checked)
                        {
                            var strroles = lstuserinfo[2].Trim().Split(';').ToList();

                            foreach (var strrole in strroles)
                            {
                                try
                                {
                                    if (strrole.Trim().Length <= 0) continue;

                                    List<Entity> entroles = lstEntSecurityrole.Where(f => f["name"].ToString().ToLower() == strrole.ToLower().Trim().Replace("cr agent", "client response agent")
                                    && (f["businessunitid"] as EntityReference).Id.ToString().ToLower().Equals(lstuserinfo[4].Trim().ToLower())).ToList();
                                    if (entroles != null && entroles.Count > 0)
                                    {
                                        service.Associate(
                                  "systemuser",
                                  entuserinfo[0].Id,
                                  new Relationship("systemuserroles_association"),
                                  new EntityReferenceCollection() { new EntityReference(entroles[0].LogicalName, entroles[0].Id) });

                                        Console.WriteLine("Role is associated with the user.");
                                    }


                                    /*
                                    strfetchXml = string.Format(@"<fetch ><entity name='role'>
                                <attribute name='roleid' />
                                 <filter>
                                  <condition attribute='name' operator='eq' value='{0}' />
                                  <condition attribute='businessunitid' operator='eq' value='{1}' />
                                </filter>
                              </entity>
                            </fetch>", strrole.Trim(), lstuserinfo[4].Trim());

                                    var entrole = this.GetRecordsbyFetchxml(strfetchXml);
                                    if (entrole != null && entrole.Count > 0)
                                    {
                                        service.Associate(
                                   "systemuser",
                                   entuserinfo[0].Id,
                                   new Relationship("systemuserroles_association"),
                                   new EntityReferenceCollection() { new EntityReference(entrole[0].LogicalName, entrole[0].Id) });

                                        Console.WriteLine("Role is associated with the user.");

                                    }*/

                                }
                                catch (Exception ex1)
                                {
                                    if (!ex1.Message.Contains("duplicate key"))
                                        throw ex1;
                                }
                            }
                            struserlog += ", Security Role Assigned";
                        }
                        if (this.chk_UserUpdate.Checked)
                        {
                            Entity entUser = new Entity("systemuser", entuserinfo[0].Id);
                            //entUser["niq_region"] = "";
                            //entUser["niq_officelocation"] = "";
                            entUser["niq_employeenumber"] = lstuserinfo[6].Trim();
                            // entUser["niq_department"] = "";
                            //entUser["niq_costcenter"] = "";
                            // entUser["niq_manageremail"] = "";
                            if (lstuserinfo[7].Trim().Length > 1)
                                entUser["niq_function"] = new OptionSetValue(this.GetOptionSetValue("niq_function", lstuserinfo[7].Trim()));
                            entUser["niq_geography"] = this.GetMultiOptionSet("niq_geography", lstuserinfo[8].Trim());
                            entUser["niq_customertype"] = this.GetMultiOptionSet("niq_customertype", lstuserinfo[9].Trim());
                            entUser["niq_servicecategory"] = this.GetMultiOptionSet("niq_servicecategory", lstuserinfo[10].Trim());
                            service.Update(entUser);
                            struserlog += ", User Info Updated";
                        }
                        if (chk_bookableresource.Checked == true && lstuserinfo[11].Trim().Length > 1)
                        {
                            string strfetch = @"<fetch>
                                  <entity name='bookableresource'>
                                    <attribute name='bookableresourceid' />
                                    <filter>
                                      <condition attribute='userid' operator='eq' value='{0}' />
                                    </filter>
                                  </entity>
                                </fetch>";
                            List<Entity> lstEnt = this.GetRecordsbyFetchxml(string.Format(strfetch, entuserinfo[0].Id));
                            if (lstEnt == null || (lstEnt != null && lstEnt.Count <= 0))
                            {
                                Entity entBookablresource = new Entity("bookableresource");
                                entBookablresource["resourcetype"] = new OptionSetValue(3);
                                entBookablresource["name"] = entuserinfo[0].Attributes["fullname"].ToString();
                                entBookablresource["userid"] = new EntityReference(entuserinfo[0].LogicalName, entuserinfo[0].Id);
                                service.Create(entBookablresource);
                                struserlog += ", Bookable Resource Created";
                            }
                            else
                                struserlog += ", Bookable Resource Existed";
                        }

                        //Advance Queue
                        if (chk_AdvanceQ.Checked == true && lstuserinfo[12].Trim().Length > 1)
                        {
                            try
                            {
                                //NON NGH Omnichannel Queue Standard
                                AddPrincipalToQueueRequest qNonNGHOmnichannel = new AddPrincipalToQueueRequest
                                {
                                    QueueId = new Guid("07779dbd-bf1a-ec11-b6e6-00224828cf0e"),
                                    Principal = entuserinfo[0]
                                };
                                service.Execute(qNonNGHOmnichannel);
                                //Non NGH China Retailer Queue
                                AddPrincipalToQueueRequest qNonNGHChinaRtl = new AddPrincipalToQueueRequest
                                {
                                    QueueId = new Guid("20f41dab-390b-ec11-b6e6-000d3a8d5730"),
                                    Principal = entuserinfo[0]
                                };
                                service.Execute(qNonNGHChinaRtl);
                                //NGH Routing Standard Omnichannel Queue
                                AddPrincipalToQueueRequest qNGHRouting = new AddPrincipalToQueueRequest
                                {
                                    QueueId = new Guid("dd03c621-bd1a-ec11-b6e6-00224828cf0e"),
                                    Principal = entuserinfo[0]
                                };
                                service.Execute(qNGHRouting);
                                //NGH Routing China Retailer Queue
                                AddPrincipalToQueueRequest qNGHRoutingChina = new AddPrincipalToQueueRequest
                                {
                                    QueueId = new Guid("6b8f7d30-d613-ec11-b6e6-000d3a1c2ff8"),
                                    Principal = entuserinfo[0]
                                };
                                service.Execute(qNGHRoutingChina);
                                struserlog += ", Advance Queue Assigned";
                            }
                            catch (Exception ex1)
                            {
                                //   throw;
                            }

                        }

                        lstLog.Add(struserlog + "->Success");

                    }
                    else
                        throw new Exception("User is not existed=");

                }
                //Contact
                if (lstuserinfo[13].Trim().Length > 1) 
                {
                    struserlog = "Contact->" + lstuserinfo[1];
                    strfetchXml = string.Format(@"<fetch>
                                      <entity name='contact'>
                                        <attribute name='contactid' />
                                        <filter type='or'>
                                          <condition attribute='emailaddress1' operator='eq' value='{0}' />
                                          <condition attribute='adx_identity_username' operator='eq' value='{0}' />
                                        </filter>
                                      </entity>
                                    </fetch>", lstuserinfo[1].Trim().Replace("'", "&apos"));

                    var entContact = this.GetRecordsbyFetchxml(strfetchXml);
                    if (entContact != null && entContact.Count > 0)
                    {
                        //WebRole
                        if (chk_ContactWebRole.Checked == true && lstuserinfo[2].Trim().Length > 1)
                        {
                            var strWroles = lstuserinfo[2].Trim().Split(';').ToList();

                            foreach (var strWrole in strWroles)
                            {
                                try
                                {
                                    if (strWrole.Trim().Length <= 0) continue;
                                    service.Associate("adx_webrole",
                           (strWrole.Trim().ToLower() == "community plus" ? Guid.Parse(strCommKnowledgePlus) : Guid.Parse(strCommKnowledgeOnly)),
                            new Relationship("adx_webrole_contact"),
                            new EntityReferenceCollection() { new EntityReference(entContact[0].LogicalName, entContact[0].Id) });
                                   // struserlog += strCommKnowledgeOnly + "- WebRole is associated with the user.";
                                  //  Console.WriteLine(strCommKnowledgeOnly + "- WebRole is associated with the user.");
                                }
                                catch (Exception ex1)
                                {
                                    if (!ex1.Message.Contains("duplicate"))
                                        throw ex1;
                                }
                            }
                            struserlog += ", Web Role Assigned";
                        }
                        //Filed Update
                         if (this.chk_contactfieldupdate.Checked)
                        {

                            entContact[0]["niq_geography"] = this.GetMultiOptionSet("niq_geography", lstuserinfo[8].Trim());
                            entContact[0]["niq_customertype"] = this.GetMultiOptionSet("niq_customertype", lstuserinfo[9].Trim());
                            entContact[0]["niq_servicecategory"] = this.GetMultiOptionSet("niq_servicecategory", lstuserinfo[10].Trim());
                            service.Update(entContact[0]);
                            struserlog += ", Contact Info Updated";
                        }
                        lstLog.Add(struserlog + "->Success");
                    }
                    else throw new Exception("Contact is not existed=");

                }
               
            }
            catch (Exception ex)
            {
                lstLog.Add(lstuserinfo[1] + ",=>Error " + ex.Message );
            }
        }
        public List<Entity> GetRecordsbyFetchxml(string fetchXml)
        {
            try
            {
                EntityCollection objEntity = service.RetrieveMultiple(new FetchExpression(fetchXml));
                if (objEntity != null && objEntity.Entities != null && objEntity.Entities.Count > 0)
                    return objEntity.Entities.ToList();
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public void productcheck()
        {
            Entity prod=null;
            try
            {
                string productnumber = "Product_><>*% &:\\/12";
                 prod = new Entity("product","productnumber", productnumber);
                prod["productnumber"] = productnumber;
                prod["name"] = "prd_test12";
                prod["defaultuomscheduleid"] = new EntityReference("uomschedule","name", "Each");
                prod["defaultuomid"] = new EntityReference("uom","name", "Each");
                prod["parentproductid"] = new EntityReference("product", "productnumber", "Family/2");
               
                UpsertRequest upsert = new UpsertRequest()
                { Target = prod };
                var result = service.Execute(upsert);
                Guid id = (result as UpsertResponse).Target.Id;
                updatestatusandupdaterecord(prod, true);
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Under Revision or Draft records"))
                {
                    updatestatusandupdaterecord(prod,false);
                }
                string st = ex.Message;
            }
        }

        public void updatestatusandupdaterecord(Entity prod,bool isactive)
        {
            try
            {
                SetStateRequest publishRequest = new SetStateRequest
                {
                    EntityMoniker = new EntityReference(prod.LogicalName, "productnumber",prod["productnumber"].ToString()),
                    State = new OptionSetValue(isactive ? 0 : 3),
                    Status = new OptionSetValue(isactive ? 1 : 3)
                };
                service.Execute(publishRequest);
                if (!isactive) productcheck();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public OptionSetValueCollection GetMultiOptionSet(string fieldname,string names)
        {
            OptionSetValueCollection Ops = new OptionSetValueCollection();
            try
            {
                List<string> lstnames = names.Split(';').ToList();
                foreach (var item in lstnames)
                {
                    int val = this.GetOptionSetValue(fieldname, item.Trim());
                    if (val >= 0)
                        Ops.Add(new OptionSetValue(val));
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Ops;
        }
        public int GetOptionSetValue(string fieldname,string value)
        {
            try
            {
              List<Entity> lstEnt=  lstEntStringMap.Where(f => f["attributename"].ToString() == fieldname && f["value"].ToString().ToLower() == value.ToLower()).ToList();
                if (lstEnt != null && lstEnt.Count > 0)
                {
                    return Convert.ToInt32(lstEnt[0]["attributevalue"].ToString());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return -1;
        }

        private void btn_Sftransformation_Click(object sender, EventArgs e)
        {
          
            SFTransformation sf = new SFTransformation();
            sf.ShowDialog();
        }

        private void btn_Accessteam_Click(object sender, EventArgs e)
        {
            try
            {
                btn_Accessteam.Enabled = false;
                Connection();

                DataTable dt = Util.GetDatatable(this.txt_tablename.Text, this.txt_accessteam.Text);
               
                lstLog = new List<string>();
                string strlog = "";
                for (int i = int.Parse(this.txt_start.Text); i < int.Parse(this.txt_End.Text); i++)
                {
                    strlog = dt.Rows[i][0].ToString() + "," + dt.Rows[i][1].ToString();
                    try
                    {
                        this.lbl_accessteamindex.Text = string.Format("{0} of {1}", i.ToString(), dt.Rows.Count.ToString());
                        this.Refresh();
                       // Console.WriteLine(string.Format("{0} of {1}", lstLog.Count.ToString(), dt.Rows.Count.ToString()));

                        AddUserToRecordTeamRequest adduser = new AddUserToRecordTeamRequest()
                        {
                            Record = new EntityReference(dt.Rows[i][3].ToString(), Guid.Parse(dt.Rows[i][0].ToString())),
                            SystemUserId = Guid.Parse(dt.Rows[i][1].ToString()),
                            TeamTemplateId = Guid.Parse(dt.Rows[i][2].ToString())
                        };
                        service.Execute(adduser);

                        strlog += ",Success";

                    }
                    catch (Exception ex)
                    {
                        strlog += ", Error- " + ex.Message;
                    }
                    lstLog.Add(strlog);
                }
                /*
                Thread[] tr = new Thread[5];
                int j = 0;
                for (int i = 0; i < 5; i++)
                {
                   
                    tr[i] = new Thread(() => Runmultithread((i*j), j+1000, dt, service));
                    tr[i].Start();
                   
                    j = j + 1000;

                }
                for (int i = 0; i < 5; i++)
                {
                    tr[i].Join();

                }
                */

                File.WriteAllLines(this.txt_logpath.Text + @"\log_" + DateTime.Now.ToString("yyyy-MM-ddTHHmmss") + "_Accessteam_" + this.txt_start.Text + ".csv", lstLog.ToArray());
            }
            catch (Exception ex)
            {
                string str = ex.Message + ex.StackTrace;
                MessageBox.Show(str);
            }
            finally
            {
                MessageBox.Show("Completed");
                btn_Accessteam.Enabled = true;
            }

        }

         static void Runmultithread(int start,int end,DataTable dt,IOrganizationService service)
        {
            string strlog = "";
            for (int i = start; i < end; i++)
            {
                 strlog = dt.Rows[i][0].ToString() + "," + dt.Rows[i][1].ToString();
                try
                {

                    Console.WriteLine(string.Format("{0} of {1}, {2}-{3}", lstLog.Count.ToString(), dt.Rows.Count.ToString(), start,end));

                    AddUserToRecordTeamRequest adduser = new AddUserToRecordTeamRequest()
                    {
                        Record = new EntityReference(dt.Rows[i][3].ToString(), Guid.Parse(dt.Rows[i][0].ToString())),
                        SystemUserId = Guid.Parse(dt.Rows[i][1].ToString()),
                        TeamTemplateId = Guid.Parse(dt.Rows[i][2].ToString())
                    };
                    service.Execute(adduser);

                    strlog += ",Success";

                }
                catch (Exception ex)
                {
                    strlog += ", Error- " + ex.Message;
                }
                lstLog.Add(strlog);
            }

        }
    }
}
