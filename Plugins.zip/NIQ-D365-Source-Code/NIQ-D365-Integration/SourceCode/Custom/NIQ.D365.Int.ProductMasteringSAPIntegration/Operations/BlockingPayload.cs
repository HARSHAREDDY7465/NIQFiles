﻿using System;
using Newtonsoft.Json;
using Microsoft.Xrm.Sdk;
using NIQ.D365.Int.ProductMasteringSAPIntegration.BlockingModel;
using NIQ.D365.Int.ProductMasteringSAPIntegration.Utilities;
using System.Collections.Generic;

namespace NIQ.D365.Int.ProductMasteringSAPIntegration.BlockingPayload
{
    public static class BlockingPayloads
    {
        public static string SetRequestModel(Entity productEntity, string productRequestId, IOrganizationService service, ITracingService tracing)
        {
            try
            {
                // Initialize Root object
                var root = new Root
                {
                    n0InputTab = new n0InputTab()
                    {
                        MaterialPairs = new List<MaterialPairs>()
                    }
                };

                // Fetch product information
                var productInfoList = Common.GetProductInfoList(productRequestId, service, tracing);
                var productDetails = Common.GetProductDetails(productRequestId, service, tracing);

                foreach (var dictionary in productInfoList)
                {
                    var materialPairs = new MaterialPairs
                    {
                        MaterialId = dictionary["niq_productid"],
                        Industry = productDetails["industry"] ?? "",
                        MaterialType = productDetails["materialType"] ?? "",
                        UpdateIndicator = "U",
                        OrgData = new OrgData
                        {
                            Plant = dictionary["niq_pricelist"],
                            SalesOrg = dictionary["niq_pricelist"],
                            DistributionChannel = Common.GetValue(productEntity, "niq_distributionchannel", "niq_masterfieldsapcode", service)
                        },
                        SalesOrg1 = new SalesOrg1
                        {
                            DChainspecstatus = dictionary.ContainsKey("niq_discontinuereason") ? dictionary["niq_discontinuereason"] : null,
                            ValidfromDate = dictionary.ContainsKey("niq_discontinueeffectivefrom") && !string.IsNullOrWhiteSpace(dictionary["niq_discontinueeffectivefrom"]) ? dictionary["niq_discontinueeffectivefrom"] : DateTime.Today.ToString("dd.MM.yyyy")
                },
                        DeliveringPlant = dictionary["niq_pricelist"]
                    };

                    root.n0InputTab.MaterialPairs.Add(materialPairs);
                }

                // Serialize the object to JSON and replace the namespace as required
                var payloadStr = JsonConvert.SerializeObject(root, Formatting.Indented)
                                 .Replace("n0InputTab", "n0:InputTab");

                return payloadStr;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("An error occurred while setting the request model.", ex);
            }
        }
    }
}