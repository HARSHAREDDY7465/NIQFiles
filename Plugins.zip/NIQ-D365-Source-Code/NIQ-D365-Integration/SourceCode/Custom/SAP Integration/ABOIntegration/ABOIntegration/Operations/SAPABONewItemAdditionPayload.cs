﻿using ABOIntegration.Class;
using ABOIntegration.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ABOIntegration.Common;

namespace ABOIntegration.Operations
{
    public class SAPABONewItemAdditionPayload
    {
        public static void createPayloadForAddedItems(IOrganizationService service, ITracingService tracing, List<Entity> adddedProducts, CONTRACTHEADER header, Entity NewOpportunity, Entity NewOppQuote, List<Item> contractLineItmes, List<Item> contractBillingLineItmes, List<Item> customResearchItems, List<Entity> OldOppQuoteProducts, Entity SalesDocTypeMetadata, Entity OldQuote, string sapId)
        {
            checkAndUpdateLineItemNumberForSAP(adddedProducts, service, OldOppQuoteProducts, tracing, OldQuote, sapId);
            createContractLineItemsForAddedProducts(adddedProducts, header, NewOpportunity, NewOppQuote, contractLineItmes, service, SalesDocTypeMetadata, tracing);
            tracing.Trace("contract line item node mapped for added products");
            createContractLineItemBillingForAddedProducts(adddedProducts, header, NewOpportunity, contractBillingLineItmes, service);
            tracing.Trace("Contract billing node mapped for added products");
            CommonHelper.createCustomResearchBillingSchedule(adddedProducts, header, NewOpportunity, customResearchItems, OldOppQuoteProducts, service, tracing, true, false);
            tracing.Trace("Custom Research node mapped for added products");
        }
        public static void createContractLineItemsForAddedProducts(List<Entity> addedProducts, CONTRACTHEADER header, Entity NewOpportunity, Entity NewQuote, List<Item> listItem, IOrganizationService service, Entity salesDocTypeMetadata, ITracingService tracingService)
        {
            List<Entity> QuoteCharacteristics = CommonHelper.getQuoteProductsCharacteristics(service, NewQuote.Id);
            bool ischild = NewOpportunity.GetAttributeValue<bool>("niq_ishostopportunity");
            foreach (Entity addedProduct in addedProducts)
            {
                bool isrevshare = addedProduct.GetAttributeValue<bool>("niq_isrevshareline");
                List<Entity> FilteredQuoteCharacteristics = QuoteCharacteristics.Where(e => e.Contains("niq_quoteproductid") &&
                        e["niq_quoteproductid"] is EntityReference && ((EntityReference)e["niq_quoteproductid"]).Id == addedProduct.Id).ToList();
                Entity itemCategoryGroupMetadata = CommonHelper.getItemCatecoryGroupMetadata(service, addedProduct.GetAttributeValue<string>("niq_pricelistitem"));
                var item = new Item();
                item.QUOTEPRODUCT_ID = addedProduct.Id.ToString();
                if (isrevshare)
                {
                    if (isrevshare && addedProduct.Attributes.Contains("niq_revshareline") && addedProduct.GetAttributeValue<EntityReference>("niq_revshareline") != null)
                        item.PQUOTEPRODUCT_ID = addedProduct.GetAttributeValue<EntityReference>("niq_revshareline").Id.ToString();
                    else
                        item.PQUOTEPRODUCT_ID = addedProduct.Id.ToString();
                }
                else
                {
                    item.PLANT = CommonHelper.getSalesOrgId(service, addedProduct.GetAttributeValue<EntityReference>("niq_salesorgcodeid").Id);
                }
                item.LINE_ITEM_NUMBER = NewOpportunity.GetAttributeValue<string>("niq_opportunitynumber");
                //item.SALES_DOC_ITEM = addedProduct.GetAttributeValue<string>("niq_lineitemnumberforsap");
                item.SALES_DOC_ITEM = service.Retrieve(addedProduct.LogicalName, addedProduct.Id, new ColumnSet("niq_lineitemnumberforsap")).GetAttributeValue<string>("niq_lineitemnumberforsap");
                item.MATERIAL_NUMBER = addedProduct.GetAttributeValue<string>("productnumber");
                item.CURRENCY_KEY = CommonHelper.getCurrencyCode(service, addedProduct.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                item.MATERIAL_DESCRIPTION = CommonHelper.getMaterialDescription(service, addedProduct.GetAttributeValue<EntityReference>("productid").Id);
                item.SALES_UNIT = "EA";
                item.CUSTOMER_PONUMBER = NewOpportunity.GetAttributeValue<string>("niq_customerponumber");
                item.WBSELEMENT = addedProduct.GetAttributeValue<string>("niq_wbs");
                item.MATERIAL_GRP4 = CommonHelper.getMaterialGroup4(addedProduct, itemCategoryGroupMetadata);
                item.MATERIAL_GRP5 = CommonHelper.getMaterialGroup5(NewQuote);
                item.DELIVERY_TIME = CommonHelper.getDeliveryFrequency(addedProduct, itemCategoryGroupMetadata);
                item.SHIP_TO_PO_DATE = CommonHelper.GetdateinddMMyyyy(NewOpportunity.GetAttributeValue<DateTime>("niq_submissiontime").ToString());
                item.CONDITION_TYPE = CommonHelper.getPricingCondition(salesDocTypeMetadata);
                //Target QTY,Order QTY
                if (CommonHelper.IsRequiredinItemCategoryGroupMetadata(itemCategoryGroupMetadata, "niq_targetquantity") == true)
                {
                    item.TARGET_QTY = addedProduct.GetAttributeValue<Money>("extendedamount").Value.ToString("F");
                    item.ORDER_QTY = addedProduct.GetAttributeValue<Money>("extendedamount").Value.ToString("F");
                }
                else if (CommonHelper.IsPeriodicinItemCategoryGroupMetadata(addedProduct, service))
                {
                    item.TARGET_QTY = addedProduct.GetAttributeValue<decimal>("quantity").ToString("F");
                    item.ORDER_QTY = addedProduct.GetAttributeValue<decimal>("quantity").ToString("F");
                }
                //Rate
                item.RATE = CommonHelper.GetRate(addedProduct, itemCategoryGroupMetadata, service, tracingService);
                if (FilteredQuoteCharacteristics.Count() > 0)
                {
                    item.CHARACTERSTICS = new PRODUCTCHARATERISTICS();
                    item.CHARACTERSTICS.item = new List<Item>();
                    foreach (Entity filteredQuoteCharacteristic in FilteredQuoteCharacteristics)
                    {
                        var ProductCharacteristic = new Item();
                        if (filteredQuoteCharacteristic.GetAttributeValue<EntityReference>("niq_materialcharacteristicid") != null)
                        {
                            ProductCharacteristic.CHARACTERSTIC_NAME = filteredQuoteCharacteristic.GetAttributeValue<AliasedValue>("niq_materialcharacteristicid.niq_characteristiccode").Value.ToString();
                            if (filteredQuoteCharacteristic.GetAttributeValue<EntityReference>("niq_materialcharacteristicvalueid") != null)
                            {
                                ProductCharacteristic.CHARACTERISTIC_VALUE = filteredQuoteCharacteristic.GetAttributeValue<AliasedValue>("niq_materialcharacteristicvalueid.niq_characteristicvaluecode").Value.ToString();
                            }
                        }
                        item.CHARACTERSTICS.item.Add(ProductCharacteristic);
                    }
                }
                listItem.Add(item);
            }
        }

        public static void createContractLineItemBillingForAddedProducts(List<Entity> addedProducts, CONTRACTHEADER header, Entity NewOpportunity, List<Item> contractBillingLineItmes, IOrganizationService service)
        {
            foreach (Entity addedProduct in addedProducts)
            {
                Item billItem = new Item();
                billItem.LINE_ITEM_NUMBER = NewOpportunity.GetAttributeValue<string>("niq_opportunitynumber");
                billItem.SALES_DOC_ITEM = addedProduct.GetAttributeValue<string>("niq_lineitemnumberforsap");
                billItem.SALES_DOC_ITEM = service.Retrieve(addedProduct.LogicalName, addedProduct.Id, new ColumnSet("niq_lineitemnumberforsap")).GetAttributeValue<string>("niq_lineitemnumberforsap");
                billItem.BILLING_FREQUENCY = CommonHelper.GetBillingFrequency(addedProduct, service);
                billItem.CONTRACT_START_DATE = CommonHelper.GetdateinddMMyyyy(addedProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate").ToString());
                billItem.CONTRACT_END_DATE = CommonHelper.GetdateinddMMyyyy(addedProduct.GetAttributeValue<DateTime>("niq_lineitemenddate").ToString());
                //Billing Deviation and Billing in Advance
                if (addedProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value == 100000006) //Monthly with Lag
                {
                    billItem.BILLING_DEVIATION = "61";
                    billItem.BILLING_IN_ADVANCE = "NO";
                }
                else if (addedProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value == 100000007) //Bi-Monthly with lag
                {
                    billItem.BILLING_DEVIATION = "A1";
                }
                else if (addedProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value == 100000008)  //Quaterly
                {
                    billItem.BILLING_DEVIATION = "A2";
                }
                else
                    billItem.BILLING_IN_ADVANCE = "X";
                contractBillingLineItmes.Add(billItem);
            }
        }

        public static void checkAndUpdateLineItemNumberForSAP(List<Entity> addedProducts, IOrganizationService service, List<Entity> OldQProducts, ITracingService tracing, Entity OldQuote, string SapId)
        {
            int OldQPCount = 0;
            List<Entity> OldProductList = getAllQuoteProductsfromSAPId(service, SapId);
            tracing.Trace("OLD PRODUCT COUNT: " + OldProductList.Count);
            foreach (Entity OldQp in OldProductList)
            {
                int lineItemNumber = Int32.Parse(OldQp.GetAttributeValue<string>("niq_lineitemnumberforsap"));
                tracing.Trace("LIENTIEM NUMBER: " + lineItemNumber + " and VAR COUNT: " + OldQPCount);

                if (lineItemNumber > OldQPCount)
                {
                    OldQPCount = lineItemNumber;
                }

            }
            OldQPCount = OldQPCount / 10;
            tracing.Trace("Count: " + OldQPCount);
            foreach (Entity addedProduct in addedProducts)
            {
                Entity Product = new Entity(addedProduct.LogicalName);
                Product.Id = addedProduct.Id;
                OldQPCount = Convert.ToInt32(OldQPCount) + 1;
                tracing.Trace("COUTN:::: " + OldQPCount);
                Product["niq_lineitemnumberforsap"] = getLineItemNumberForSAP(OldQPCount);
                tracing.Trace("MAPPED " + Product["niq_lineitemnumberforsap"]);
                Product["sequencenumber"] = OldQPCount;
                tracing.Trace("MAPPED SEQUENC NUMBER");
                service.Update(Product);
            }
            tracing.Trace("LEAVING checkAndUpdateLineItemNumberForSAP FN");
        }
        public static List<Entity> getAllQuoteProductsfromSAPId(IOrganizationService service, string SapId)
        {
            string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='quotedetail'>    
                                <attribute name='niq_lineitemnumberforsap' />
                                <order attribute='niq_brandid' descending='false' />
                                <link-entity name='quote' from='quoteid' to='quoteid' link-type='inner' alias='ac'>
                                  <filter type='and'>
                                    <condition attribute='niq_mainquote' operator='eq' value='1' />
                                  </filter>
                                  <link-entity name='opportunity' from='opportunityid' to='opportunityid' link-type='inner' alias='ad'>
                                    <filter type='and'>
                                      <condition attribute='niq_sapsalesdocumentid' operator='eq' value='{SapId}' />
                                    </filter>
                                  </link-entity>
                                </link-entity>
                              </entity>
                            </fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchXml)).Entities.ToList();
        }
        public static string getLineItemNumberForSAP(int Count)
        {
            if (Count < 10)
                return String.Concat("0000", Count.ToString(), "0");
            else if (Count < 100)
                return String.Concat("000", Count.ToString(), "0");
            else if (Count < 1000)
                return String.Concat("00", Count.ToString(), "0");
            else if (Count < 10000)
                return String.Concat("0", Count.ToString(), "0");
            else
                return String.Concat(Count.ToString(), "0");
        }
    }
}
