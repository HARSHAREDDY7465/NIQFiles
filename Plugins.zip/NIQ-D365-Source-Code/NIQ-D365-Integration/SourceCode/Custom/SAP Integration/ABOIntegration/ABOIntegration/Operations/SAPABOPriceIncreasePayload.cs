﻿using ABOIntegration.Class;
using ABOIntegration.Common;
using ABOIntegration.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ABOIntegration.Operations
{
    public class SAPABOPriceIncreasePayload
    {
        public static void createPayloadForPriceChangedItems(IOrganizationService service, ITracingService tracing, List<Entity> priceChangedProducts, CONTRACTHEADER header, Entity NewOpportunity, Entity NewOppQuote, List<Item> contractLineItmes, List<Item> contractBillingLineItmes, List<Item> customResearchItems, List<Entity> OldOppQuoteProducts, Entity SalesDocTypeMetadata, List<Guid> isContractEndDateOnlyExtendedGuids)
        {
            createContractLineItemsForPriceChangedProducts(priceChangedProducts, header, NewOpportunity, NewOppQuote, contractLineItmes, OldOppQuoteProducts, service, SalesDocTypeMetadata, tracing);
            createContractLineItemBillingForPriceChangedProducts(priceChangedProducts, header, NewOpportunity, contractBillingLineItmes, OldOppQuoteProducts, service, tracing, isContractEndDateOnlyExtendedGuids);
            CommonHelper.createCustomResearchBillingSchedule(priceChangedProducts, header, NewOpportunity, customResearchItems, OldOppQuoteProducts, service, tracing, false, true);
        }

        //Create Contract Line Item of the Product
        public static void createContractLineItemsForPriceChangedProducts(List<Entity> priceChangedProducts, CONTRACTHEADER header, Entity NewOpportunity, Entity NewQuote, List<Item> listItem, List<Entity> OldOppQuoteProducts, IOrganizationService service, Entity salesDocTypeMetadata, ITracingService tracing)
        {
            List<Entity> QuoteCharacteristics = CommonHelper.getQuoteProductsCharacteristics(service, NewQuote.Id);
            bool ischild = NewOpportunity.GetAttributeValue<bool>("niq_ishostopportunity");
            foreach (Entity priceChangedProduct in priceChangedProducts)
            {
                tracing.Trace("PRICE CHAGNE SCENARIO FOR : Product: " + priceChangedProduct.Id + "  " + priceChangedProduct.GetAttributeValue<string>("niq_contractproductname"));
                Entity ProductInExistingContract = null;
                var item = new Item();
                List<Entity> FilteredQuoteCharacteristics = QuoteCharacteristics.Where(e => e.Contains("niq_quoteproductid") &&
                        e["niq_quoteproductid"] is EntityReference && ((EntityReference)e["niq_quoteproductid"]).Id == priceChangedProduct.Id).ToList();
                Entity itemCategoryGroupMetadata = CommonHelper.getItemCatecoryGroupMetadata(service, priceChangedProduct.GetAttributeValue<string>("niq_pricelistitem"));
                bool isrevshare = priceChangedProduct.GetAttributeValue<bool>("niq_isrevshareline");
                if (isrevshare)
                {
                    EntityReference AmendedChildRef = priceChangedProduct.GetAttributeValue<EntityReference>("niq_correspondingchildopportunity");
                    Entity AmendedChild = service.Retrieve(AmendedChildRef.LogicalName, AmendedChildRef.Id, new ColumnSet("niq_amendedfromopportunity"));
                    EntityReference OriginalChild = AmendedChild.GetAttributeValue<EntityReference>("niq_amendedfromopportunity");
                    QueryExpression query = new QueryExpression("quotedetail")
                    {
                        ColumnSet = new ColumnSet(true)
                    };
                    query.Criteria.AddCondition("niq_correspondingchildopportunity", ConditionOperator.Equal, OriginalChild.Id);
                    ProductInExistingContract = service.RetrieveMultiple(query).Entities.FirstOrDefault();
                }
                else
                {
                    ProductInExistingContract = OldOppQuoteProducts.Where(OldQuoteProduct => OldQuoteProduct.GetAttributeValue<EntityReference>("productid").Id == priceChangedProduct.GetAttributeValue<EntityReference>("productid").Id && OldQuoteProduct.GetAttributeValue<string>("niq_contractproductname") == priceChangedProduct.GetAttributeValue<string>("niq_contractproductname") && Guid.Parse(OldQuoteProduct.GetAttributeValue<string>("niq_elassetid")) == Guid.Parse(priceChangedProduct.GetAttributeValue<string>("niq_elassetid"))).First();
                    item.PLANT = CommonHelper.getSalesOrgId(service, priceChangedProduct.GetAttributeValue<EntityReference>("niq_salesorgcodeid").Id);
                }
                item.QUOTEPRODUCT_ID = priceChangedProduct.Id.ToString();
                item.LINE_ITEM_NUMBER = NewOpportunity.GetAttributeValue<string>("niq_opportunitynumber");
                item.SALES_DOC_ITEM = ProductInExistingContract.GetAttributeValue<string>("niq_lineitemnumberforsap");
                item.MATERIAL_NUMBER = priceChangedProduct.GetAttributeValue<string>("productnumber");
                item.CURRENCY_KEY = CommonHelper.getCurrencyCode(service, priceChangedProduct.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                item.DELIVERY_TIME = CommonHelper.getDeliveryFrequency(priceChangedProduct, itemCategoryGroupMetadata);
                item.WBSELEMENT = priceChangedProduct.GetAttributeValue<string>("niq_wbs");
                //Target QTY,Order QTY 
                if (CommonHelper.IsRequiredinItemCategoryGroupMetadata(itemCategoryGroupMetadata, "niq_targetquantity") == true)
                {
                    item.TARGET_QTY = getTotalAmount(service, ProductInExistingContract, priceChangedProduct);
                    item.ORDER_QTY = getTotalAmount(service, ProductInExistingContract, priceChangedProduct);
                }
                else if (CommonHelper.IsPeriodicinItemCategoryGroupMetadata(priceChangedProduct, service))
                {
                    item.TARGET_QTY = priceChangedProduct.GetAttributeValue<decimal>("quantity").ToString("F");
                    item.ORDER_QTY = priceChangedProduct.GetAttributeValue<decimal>("quantity").ToString("F");
                }
                //Rate
                if (!CommonHelper.IsPeriodicinItemCategoryGroupMetadata(priceChangedProduct, service))
                {
                    tracing.Trace("RATE IF condition");
                    if (itemCategoryGroupMetadata.GetAttributeValue<string>("niq_fixedrate") != null)
                        item.RATE = itemCategoryGroupMetadata.GetAttributeValue<string>("niq_fixedrate");
                    else
                        item.RATE = getTotalAmount(service, ProductInExistingContract, priceChangedProduct);
                    item.CONDITION_TYPE = CommonHelper.getPricingCondition(salesDocTypeMetadata);
                    tracing.Trace("LEAVING RATE IF condition");
                }
                if (FilteredQuoteCharacteristics.Count() > 0)
                {
                    item.CHARACTERSTICS = new PRODUCTCHARATERISTICS();
                    item.CHARACTERSTICS.item = new List<Item>();
                    foreach (Entity filteredQuoteCharacteristic in FilteredQuoteCharacteristics)
                    {
                        var ProductCharacteristic = new Item();
                        if (filteredQuoteCharacteristic.GetAttributeValue<EntityReference>("niq_materialcharacteristicid") != null)
                        {
                            ProductCharacteristic.CHARACTERSTIC_NAME = filteredQuoteCharacteristic.GetAttributeValue<AliasedValue>("niq_materialcharacteristicid.niq_characteristiccode").Value.ToString();
                            if (filteredQuoteCharacteristic.GetAttributeValue<EntityReference>("niq_materialcharacteristicvalueid") != null)
                                ProductCharacteristic.CHARACTERISTIC_VALUE = filteredQuoteCharacteristic.GetAttributeValue<AliasedValue>("niq_materialcharacteristicvalueid.niq_characteristicvaluecode").Value.ToString();
                        }
                        item.CHARACTERSTICS.item.Add(ProductCharacteristic);
                    }
                }
                listItem.Add(item);
                mapLineItemNumber(ProductInExistingContract, priceChangedProduct, service,tracing);
            }
        }

        public static string getTotalAmount(IOrganizationService service, Entity existingProduct, Entity amendedProduct)
        {
            decimal totalAmount = 0;
            string existingFetchXml = $@"<fetch>
	                                    <entity name='niq_schedule'>
		                                    <attribute name='niq_scheduleid' />
		                                    <attribute name='niq_amount' />
		                                    <filter type='and'>
			                                    <condition attribute='niq_scheduledate' operator='lt' value='{CommonHelper.GetdateinMMddyyyy((amendedProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate")).ToString())}' />
                                                <condition attribute='niq_scheduletype' operator='eq' value='100000000' />
                                                <condition attribute='niq_lineitemid' operator='eq' value='{existingProduct.Id.ToString()}' />
		                                    </filter>
	                                    </entity>
                                    </fetch>";
            List<Entity> exisintgSchedules = service.RetrieveMultiple(new FetchExpression(existingFetchXml)).Entities.ToList();
            foreach (Entity schedule in exisintgSchedules)
                totalAmount += schedule.GetAttributeValue<Money>("niq_amount").Value;
            string amendedFetchXml = $@"<fetch>
	                                    <entity name='niq_schedule'>
		                                    <attribute name='niq_scheduleid' />
		                                    <attribute name='niq_amount' />
		                                    <filter type='and'>
                                                <condition attribute='niq_scheduletype' operator='eq' value='100000000' /> 
                                                <condition attribute='niq_lineitemid' operator='eq' value='{amendedProduct.Id.ToString()}' />
		                                    </filter>
	                                    </entity>
                                    </fetch>";
            List<Entity> AmendedSchedules = service.RetrieveMultiple(new FetchExpression(amendedFetchXml)).Entities.ToList();
            foreach (Entity amendedSchedule in AmendedSchedules)
                totalAmount += amendedSchedule.GetAttributeValue<Money>("niq_amount").Value;

            return totalAmount.ToString("F");
        }

        //Create Billing Item Of the Product
        public static void createContractLineItemBillingForPriceChangedProducts(List<Entity> priceChangedProducts, CONTRACTHEADER header, Entity NewOpportunity, List<Item> contractBillingLineItmes, List<Entity> OldOppQuoteProducts, IOrganizationService service, ITracingService tracing, List<Guid> isContractEndDateOnlyExtendedGuids)
        {
            foreach (Entity priceChangedProduct in priceChangedProducts)
            {
                Entity itemCategoryGroupMetadata = CommonHelper.getItemCatecoryGroupMetadata(service, priceChangedProduct.GetAttributeValue<string>("niq_pricelistitem"));
                tracing.Trace("ITEM CAT ID: " + itemCategoryGroupMetadata.Id);
                Entity ProductInExistingContract = null;
                bool isrevshare = priceChangedProduct.GetAttributeValue<bool>("niq_isrevshareline");
                if (isrevshare)
                {
                    EntityReference AmendedChildRef = priceChangedProduct.GetAttributeValue<EntityReference>("niq_correspondingchildopportunity");
                    Entity AmendedChild = service.Retrieve(AmendedChildRef.LogicalName, AmendedChildRef.Id, new ColumnSet("niq_amendedfromopportunity"));
                    EntityReference OriginalChild = AmendedChild.GetAttributeValue<EntityReference>("niq_amendedfromopportunity");
                    QueryExpression query = new QueryExpression("quotedetail")
                    {
                        ColumnSet = new ColumnSet(true)
                    };
                    query.Criteria.AddCondition("niq_correspondingchildopportunity", ConditionOperator.Equal, OriginalChild.Id);
                    ProductInExistingContract = service.RetrieveMultiple(query).Entities.FirstOrDefault();
                }
                else
                {
                    ProductInExistingContract = OldOppQuoteProducts.Where(OldQuoteProduct => OldQuoteProduct.GetAttributeValue<EntityReference>("productid").Id == priceChangedProduct.GetAttributeValue<EntityReference>("productid").Id && OldQuoteProduct.GetAttributeValue<string>("niq_contractproductname") == priceChangedProduct.GetAttributeValue<string>("niq_contractproductname") && Guid.Parse(OldQuoteProduct.GetAttributeValue<string>("niq_elassetid")) == Guid.Parse(priceChangedProduct.GetAttributeValue<string>("niq_elassetid"))).First();
                }
                tracing.Trace("product in existing contract: " + ProductInExistingContract.Id);
                Item billItem = new Item();
                billItem.LINE_ITEM_NUMBER = NewOpportunity.GetAttributeValue<string>("niq_opportunitynumber");
                billItem.SALES_DOC_ITEM = ProductInExistingContract.GetAttributeValue<string>("niq_lineitemnumberforsap");
                //billItem.CONTRACT_START_DATE = CommonHelper.GetdateinddMMyyyy(priceChangedProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate").ToString());
                if (ProductInExistingContract.Attributes.Contains("niq_originalcontractstartdate") && ProductInExistingContract.GetAttributeValue<DateTime>("niq_originalcontractstartdate") != null && ProductInExistingContract.GetAttributeValue<DateTime>("niq_originalcontractstartdate") != DateTime.MinValue)
                {
                    billItem.CONTRACT_START_DATE = CommonHelper.GetdateinddMMyyyy(ProductInExistingContract.GetAttributeValue<DateTime>("niq_originalcontractstartdate").ToString());
                }
                else
                {
                    billItem.CONTRACT_START_DATE = CommonHelper.GetdateinddMMyyyy(ProductInExistingContract.GetAttributeValue<DateTime>("niq_lineitemstartdate").ToString());
                }
                //billItem.CONTRACT_START_DATE = CommonHelper.GetdateinddMMyyyy(ProductInExistingContract.GetAttributeValue<DateTime>("niq_lineitemstartdate").ToString()); 
                billItem.CONTRACT_END_DATE = CommonHelper.GetdateinddMMyyyy(priceChangedProduct.GetAttributeValue<DateTime>("niq_lineitemenddate").ToString());
                billItem.BILLING_FREQUENCY = CommonHelper.GetBillingFrequency(priceChangedProduct, service);
                if (CommonHelper.IsPeriodicinItemCategoryGroupMetadata(priceChangedProduct, service))
                {
                    tracing.Trace("ITEMCATEGORY: " + itemCategoryGroupMetadata.Id);
                    var oldBillingFrequency = ProductInExistingContract.GetAttributeValue<OptionSetValue>("niq_billingfrequency");
                    var oldRevenueFrequency = ProductInExistingContract.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency");
                    var newBillingFrequency = priceChangedProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency");
                    var newRevenueFrequency = priceChangedProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency");
                    if (!isContractEndDateOnlyExtendedGuids.Contains(priceChangedProduct.Id) || oldBillingFrequency != newBillingFrequency ||oldRevenueFrequency != newRevenueFrequency)
                    {
                        billItem.PRICE_AFT_CHGIN_VALUE = CommonHelper.GetRate(priceChangedProduct, itemCategoryGroupMetadata, service, tracing);
                        if (NewOpportunity.GetAttributeValue<OptionSetValue>("niq_existingcontractaction").Value == 2) // For PE/COLA
                            billItem.PRICE_CHG_EFF_FROM = CommonHelper.GetdateinddMMyyyy(getNextScheduleDate(service, priceChangedProduct, NewOpportunity, tracing).ToString());
                        else if (NewOpportunity.GetAttributeValue<OptionSetValue>("niq_existingcontractaction").Value == 3)  // For Evergreen Renewal
                            billItem.PRICE_CHG_EFF_FROM = CommonHelper.GetdateinddMMyyyy(NewOpportunity.GetAttributeValue<DateTime>("niq_contractstartdate").ToString());
                        else
                            billItem.PRICE_CHG_EFF_FROM = CommonHelper.GetdateinddMMyyyy(priceChangedProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate").ToString());
                    }                    
                }
                contractBillingLineItmes.Add(billItem); 
            }
        }
        public static DateTime getNextScheduleDate(IOrganizationService service, Entity Product, Entity Opportunity, ITracingService tracing)
        {
            tracing.Trace("EFFECTIVE DATE: " + Opportunity.GetAttributeValue<DateTime>("niq_effectivedate"));
            string fetchXml = $@"<fetch top='1'>
	                            <entity name='niq_schedule'>
		                            <attribute name='niq_scheduleid' />
		                            <attribute name='niq_scheduledate' />
		                            <filter type='and'>
			                            <condition attribute='niq_lineitemid' operator='eq' value='{Product.Id}' />
			                            <condition attribute='niq_scheduletype' operator='eq' value='100000000' />
			                            <condition attribute='niq_scheduledate' operator='ge' value='{CommonHelper.GetdateinMMddyyyy(Opportunity.GetAttributeValue<DateTime>("niq_effectivedate").ToString())}' />
		                            </filter>
                                    <order attribute='niq_scheduledate' />
	                            </entity>
                            </fetch>";
            var results = service.RetrieveMultiple(new FetchExpression(fetchXml));
            return results.Entities.First().GetAttributeValue<DateTime>("niq_scheduledate");
        }
        public static void mapLineItemNumber(Entity oldProduct, Entity newProduct, IOrganizationService service, ITracingService tracing)
        {
           
            var oldLineItemNumber = oldProduct.GetAttributeValue<string>("niq_lineitemnumberforsap");
            int toBeLineItemNumber = Int32.Parse(oldLineItemNumber.Remove(oldLineItemNumber.Length - 1));
            Entity Product = new Entity("quotedetail", newProduct.Id);
            Product["sequencenumber"] = toBeLineItemNumber;
            //tracing.Trace("niq_originalcontractstartdate" + oldProduct.GetAttributeValue<DateTime>("niq_originalcontractstartdate"));
            if (oldProduct.Contains("niq_originalcontractstartdate") && oldProduct.GetAttributeValue<DateTime>("niq_originalcontractstartdate") != null && oldProduct.GetAttributeValue<DateTime>("niq_originalcontractstartdate")!= DateTime.MinValue)
            {
                Product["niq_originalcontractstartdate"] = oldProduct.GetAttributeValue<DateTime>("niq_originalcontractstartdate");
            }
            else
            {
                Product["niq_originalcontractstartdate"] = oldProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
            }
            
            Product["niq_lineitemnumberforsap"] = CommonHelper.getLineItemNumberForSap(toBeLineItemNumber);
            service.Update(Product);
        }
    }
}
