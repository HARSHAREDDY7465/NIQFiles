﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using ABOIntegration.Class;
using Newtonsoft.Json;
using ABOIntegration.Operations;
using ABOIntegration.Common;
using System.Diagnostics.Eventing.Reader;
using Microsoft.Xrm.Sdk.Metadata;
using System.Diagnostics;

namespace ABOIntegration
{
    public class SAPABOPayload : IPlugin
    {
        Entity salesDocTypeMetadata;
        ITracingService tracing;
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = factory.CreateOrganizationService(context.UserId);
            tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            try
            {
                string OldOpportunityId = (string)context.InputParameters["OriginalOpportunityId"];
                tracing.Trace($@"Old OpportunityId: {OldOpportunityId}");
                string NewOpportunityId = (string)context.InputParameters["NewOpportunityId"];
                tracing.Trace($@"New Opportunity: {NewOpportunityId}");
                Entity OldOpportunity = CommonHelper.getOpportunity(service, new Guid(OldOpportunityId));
                Entity NewOpportunity = CommonHelper.getOpportunity(service, new Guid(NewOpportunityId));
                Entity OldOppQuote = CommonHelper.getQuote(service, OldOpportunity.GetAttributeValue<EntityReference>("niq_mainquoteid").Id);
                Entity NewOppQuote = CommonHelper.getQuote(service, NewOpportunity.GetAttributeValue<EntityReference>("niq_mainquoteid").Id);
                tracing.Trace("QUOTE RETREIVED");
                List<Entity> OldOppQuoteProducts = CommonHelper.GetQuoteProduct(service, OldOppQuote);
                List<Entity> NewOppQuoteProducts = CommonHelper.GetQuoteProduct(service, NewOppQuote);
                bool isHost = NewOpportunity.GetAttributeValue<bool>("niq_ishostopportunity");
                if (NewOppQuoteProducts.Count > 0 || isHost)
                {
                   
                    List<Entity> removedProducts = new List<Entity>();
                    List<Entity> addedProducts = new List<Entity>();
                    List<Entity> PriceChangedProducts = new List<Entity>();
                    List<Guid> isContractEndDateOnlyExtendedGuids = new List<Guid>();
                    DateTime contractStartDate = new DateTime();
                    string commaSeperatedConfigIds = NewOpportunity.GetAttributeValue<string>("niq_assetconfigidinput");
                    string sapSalesDocId = OldOpportunity.GetAttributeValue<string>("niq_sapsalesdocumentid");
                    salesDocTypeMetadata = CommonHelper.GetSalesDocTypeMetadata(service, NewOpportunity);
                    if (NewOppQuoteProducts.Count > 0)
                    {
                        contractStartDate = NewOppQuoteProducts.Where(e => e.Contains("niq_lineitemstartdate") && e["niq_lineitemstartdate"] is DateTime).Min(e => (DateTime)e["niq_lineitemstartdate"]);
                        removedProducts = getRemovedProducts(OldOppQuoteProducts, NewOppQuoteProducts, commaSeperatedConfigIds, service, contractStartDate);
                        addedProducts = NewOppQuoteProducts.Where(NewQuoteProduct => !OldOppQuoteProducts.Any(OldQuoteProduct => OldQuoteProduct.GetAttributeValue<EntityReference>("productid")?.Id == NewQuoteProduct.GetAttributeValue<EntityReference>("productid")?.Id &&
                                                                           OldQuoteProduct.GetAttributeValue<string>("niq_contractproductname") == NewQuoteProduct.GetAttributeValue<string>("niq_contractproductname") &&
                                                                           NewQuoteProduct.GetAttributeValue<bool>("niq_isrevshareline") == false && OldQuoteProduct.GetAttributeValue<bool>("niq_isrevshareline") == false &&
                                                                           Guid.Parse(NewQuoteProduct.GetAttributeValue<string>("niq_elassetid")) == Guid.Parse(OldQuoteProduct.GetAttributeValue<string>("niq_elassetid")))).ToList();

                        PriceChangedProducts = getPriceChangedProducts(OldOppQuoteProducts, NewOppQuoteProducts, removedProducts, addedProducts, isContractEndDateOnlyExtendedGuids);
                    }
                    if(isHost)
                    {
                        contractStartDate = NewOpportunity.GetAttributeValue<DateTime>("niq_contractstartdate");
                        checkRevShareAsset(OldOppQuoteProducts, NewOppQuoteProducts, service, addedProducts, PriceChangedProducts, NewOppQuote, OldOppQuote);
                    }
                    tracing.Trace("contractStartDate:" + contractStartDate);
                    tracing.Trace("Products Retrived!");                   
                    tracing.Trace("Removed Products Count : " + removedProducts.Count());
                    tracing.Trace("Added Products Count : " + addedProducts.Count());
                    tracing.Trace("Price Changed Products Count : " + PriceChangedProducts.Count());
                    mapLineItemNumberforNoChangeProducts(NewOppQuoteProducts, OldOppQuoteProducts, removedProducts, addedProducts, PriceChangedProducts, service);
                    Body Contract = new Body();
                    Contract.ZSDFM_IC_CONT_CHANGE_SERVICE = new ZSDFMICCONTCHANGESERVICE();
                    INPUT payload = new INPUT();
                    payload.MT_ECCCONTRACT_ASYNC_REQ = new MTECCCONTRACTASYNCREQ();
                    HeaderItem MainItem = new HeaderItem();
                    MainItem.CONTRACT_HEADER = new CONTRACTHEADER();
                    MainItem.CONTRACT_HEADER.CONTRACT_NUMBER = OldOpportunity.GetAttributeValue<string>("niq_sapsalesdocumentid");
                    MainItem.CONTRACT_HEADER.OPPORTUNITY_NUMBER = NewOpportunity.Id.ToString();
                    string salesorgCode = CommonHelper.getSalesOrgId(service, NewOpportunity.GetAttributeValue<EntityReference>("niq_salesorgid").Id);
                    if (salesorgCode != null && (salesorgCode == "3411" || salesorgCode == "4411") && NewOpportunity.GetAttributeValue<bool>("niq_revenuesharedeal") == true)
                        MainItem.CONTRACT_HEADER.BILLING_BLOCK = "32";
                    else
                        MainItem.CONTRACT_HEADER.BILLING_BLOCK = "02";
                    CommonHelper.createHeaderPartnerFunction(MainItem.CONTRACT_HEADER, NewOpportunity, service, OldOpportunity, tracing);
                    List<Item> contractLineItmes = new List<Item>();
                    List<Item> contractBillingLineItmes = new List<Item>();
                    List<Item> customResearchItems = new List<Item>();
                    OptionSetValue existingContractAction = NewOpportunity.GetAttributeValue<OptionSetValue>("niq_existingcontractaction");
                    if (removedProducts.Count > 0 && existingContractAction.Value != 2)
                    {
                        tracing.Trace("Initiating item removal logic");
                        SAPABOItemRejectionPayload.createPayloadForRejectedItems(service, tracing, removedProducts, MainItem.CONTRACT_HEADER, OldOpportunity, OldOppQuote, contractLineItmes, contractBillingLineItmes, customResearchItems, NewOpportunity, OldOppQuoteProducts, contractStartDate);
                        tracing.Trace("Removed Products Done");
                    }
                    if (addedProducts.Count > 0)
                    {
                        tracing.Trace("Initiating item addition logic");
                        SAPABONewItemAdditionPayload.createPayloadForAddedItems(service, tracing, addedProducts, MainItem.CONTRACT_HEADER, NewOpportunity, NewOppQuote, contractLineItmes, contractBillingLineItmes, customResearchItems, OldOppQuoteProducts, salesDocTypeMetadata, OldOppQuote, sapSalesDocId);
                        tracing.Trace("Added Products Done");
                    }
                    if (PriceChangedProducts.Count > 0)
                    {
                        tracing.Trace("Initiating price chagne logic");
                        SAPABOPriceIncreasePayload.createPayloadForPriceChangedItems(service, tracing, PriceChangedProducts, MainItem.CONTRACT_HEADER, NewOpportunity, NewOppQuote, contractLineItmes, contractBillingLineItmes, customResearchItems, OldOppQuoteProducts, salesDocTypeMetadata, isContractEndDateOnlyExtendedGuids);
                        tracing.Trace("Price Chagned Products Done");
                    }
                    linkItemsToPayload(contractLineItmes, contractBillingLineItmes, customResearchItems, MainItem.CONTRACT_HEADER);
                    CommonHelper.getLineItemText(NewOppQuoteProducts, MainItem.CONTRACT_HEADER, NewOpportunity, tracing, service);
                    tracing.Trace("ITEM LINKED TO PAYLOAD!!");
                    Contract.ZSDFM_IC_CONT_CHANGE_SERVICE.INPUT = payload;
                    payload.MT_ECCCONTRACT_ASYNC_REQ.item = MainItem;

                    context.OutputParameters["Payload"] = JsonConvert.SerializeObject(Contract, Formatting.Indented, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }).Replace("ZSDFM_IC_CONT_CHANGE_SERVICE", "n0:ZSDFM_IC_CONT_CHANGE_SERVICE");
                    context.OutputParameters["IsSuccess"] = true;
                    context.OutputParameters["ErrorMessage"] = "";
                }
                else
                {
                    context.OutputParameters["IsSuccess"] = false;
                    context.OutputParameters["ErrorMessage"] = "No Quote Product was found associated to the Main Quote of the Related Opportunity inside FAR Request.";
                    tracing.Trace("No Quote Product was found associated to the Main Quote of the Related Opportunity inside FAR Request.");
                }
            }
            catch (Exception ex)
            {
                context.OutputParameters["IsSuccess"] = false;
                context.OutputParameters["ErrorMessage"] = ex.Message;
                tracing.Trace("ERROR: " + ex.Message);
            }
        }

        public List<Entity> getRemovedProducts(List<Entity> OldOppQuoteProducts, List<Entity> NewOppQuoteProducts, string commaSeperatedConfigIds, IOrganizationService service, DateTime contractStartDate)
        {
            List<Entity> removedProducts = OldOppQuoteProducts.Where(OldQuoteProduct => !NewOppQuoteProducts.Any(NewQuoteProduct => NewQuoteProduct.GetAttributeValue<EntityReference>("productid")?.Id == OldQuoteProduct.GetAttributeValue<EntityReference>("productid")?.Id &&
                                                                        NewQuoteProduct.GetAttributeValue<string>("niq_contractproductname") == OldQuoteProduct.GetAttributeValue<string>("niq_contractproductname") &&
                                                                        NewQuoteProduct.GetAttributeValue<bool>("niq_isrevshareline") == false && OldQuoteProduct.GetAttributeValue<bool>("niq_isrevshareline") == false &&
                                                                         Guid.Parse(NewQuoteProduct.GetAttributeValue<string>("niq_elassetid")) == Guid.Parse(OldQuoteProduct.GetAttributeValue<string>("niq_elassetid")))).ToList();
            removedProducts.RemoveAll(e => e.Contains("niq_lineitemenddate") && e.GetAttributeValue<DateTime>("niq_lineitemenddate") < contractStartDate);
            tracing.Trace("REMOVED PRODUCT COUNT: "+ removedProducts.Count);
            List<Entity> filteredRemovedProducts = new List<Entity>();
            if (removedProducts.Count > 0)
            {
                string[] configArray = commaSeperatedConfigIds.Split(',');
                string filter = string.Empty;
                foreach(Entity product in removedProducts)
                {
                    filter += $@"<condition attribute='niq_correspondingquoteproduct' operator='eq' value='{product.Id}' />";
                }

                string fetchXMl = $@"<fetch>
	                        <entity name='niq_assetmaterial'>
		                        <attribute name='niq_assetmaterialid' />
		                        <attribute name='niq_assetconfig' />
		                        <attribute name='niq_assetconfigname' />
		                        <attribute name='niq_correspondingquoteproduct' />
                                <filter type = 'or'>
		                        {filter}
                                </filter>
	                        </entity>
                        </fetch>";
                tracing.Trace("FETCHXML: "+fetchXMl);
                var records = service.RetrieveMultiple(new FetchExpression(fetchXMl));
                tracing.Trace("FILTERED Materials COUNT: "+records.Entities.Count());
                tracing.Trace("Comma Seperated GUID: "+commaSeperatedConfigIds);
                foreach(Entity record in records.Entities)
                {
                    string assetConfigId = record.GetAttributeValue<EntityReference>("niq_assetconfig").Id.ToString();
                    Guid CorrespondingQP = record.GetAttributeValue<EntityReference>("niq_correspondingquoteproduct").Id;
                    tracing.Trace("Asset ID in Config : "+assetConfigId);
                    if (commaSeperatedConfigIds.Contains(assetConfigId))
                    {
                        filteredRemovedProducts.Add(OldOppQuoteProducts.Where(oldQuoteProduct => oldQuoteProduct.Id == CorrespondingQP).FirstOrDefault());
                    }
                }
            }
            tracing.Trace("FILTERED REMOVED PRODUCTS: "+filteredRemovedProducts.Count);
            return filteredRemovedProducts;
        }


        //Get List of Price changed products of the amended opportunity
        public List<Entity> getPriceChangedProducts(List<Entity> OldOppQuoteProducts, List<Entity> NewOppQuoteProducts, List<Entity> removedProducts,List<Entity> addedProducts,List<Guid> isContractEndDateOnlyExtendedGuids)
        {
            var productsExcludingRevshareLine = NewOppQuoteProducts.Where(newQuoteProduct => newQuoteProduct.GetAttributeValue<bool>("niq_isrevshareline") == false);
            return productsExcludingRevshareLine.Where(newProduct =>
            {
                var newProductId = newProduct.GetAttributeValue<EntityReference>("productid")?.Id;
                var newAmount = newProduct.GetAttributeValue<Money>("extendedamount")?.Value ?? 0m;
                var newContractProductName = newProduct.GetAttributeValue<string>("niq_contractproductname");
                var newStartDate = newProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                var newEndDate = newProduct.GetAttributeValue<DateTime>("niq_lineitemenddate");
                var newElAssetId = newProduct.GetAttributeValue<string>("niq_elassetid");
                var newTermLength = newProduct.GetAttributeValue<double>("niq_termlength");
                var newBillingFrequency = newProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency");
                var newRevenueFrequency = newProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency");
                var productType = newProduct.GetAttributeValue<OptionSetValue>("niq_type");
                if (newTermLength < 1)
                {
                    DateTime startDate = newProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                    tracing.Trace("DIFF DAYS: "+ newEndDate.Subtract(startDate).Days);
                    if (newEndDate.Subtract(startDate).Days > 30)
                        newTermLength = newEndDate.Subtract(startDate).Days / 30;
                    else
                        newTermLength = 1;
                }
                tracing.Trace("New Term Length : "+newTermLength);
                var newRate = Math.Round(newAmount / Convert.ToDecimal(newTermLength),2);
                var oldProduct = OldOppQuoteProducts.FirstOrDefault(op => op.GetAttributeValue<EntityReference>("productid")?.Id == newProductId && op.GetAttributeValue<string>("niq_contractproductname") == newContractProductName && Guid.Parse(op.GetAttributeValue<string>("niq_elassetid")) == Guid.Parse(newElAssetId));
                if (oldProduct != null)
                {
                    var oldAmount = oldProduct.GetAttributeValue<Money>("extendedamount")?.Value ?? 0m;
                    var oldStartDate = oldProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                    var oldEndDate = oldProduct.GetAttributeValue<DateTime>("niq_lineitemenddate");
                    var oldTermLength = oldProduct.GetAttributeValue<double>("niq_termlength");
                    var oldBillingFrequency = oldProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency");
                    var oldRevenueFrequency = oldProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency");
                    if (oldTermLength < 1)
                    {
                        DateTime startDate = oldProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                        if (oldEndDate.Subtract(startDate).Days > 30)
                            oldTermLength = oldEndDate.Subtract(startDate).Days / 30;
                        else
                            oldTermLength = 1;
                    }

                    tracing.Trace("OLD TERM LENGTH: "+oldTermLength);
                    if(oldStartDate != newStartDate && (oldBillingFrequency.Value != newBillingFrequency.Value || newRevenueFrequency.Value != oldRevenueFrequency.Value))
                    {
                        tracing.Trace("PRODUCT: "+newProduct.GetAttributeValue<string>("niq_contractproductname"));
                        tracing.Trace("NEW BILL FREQ "+newBillingFrequency.Value);
                        tracing.Trace("OLD BILL FREQ "+oldBillingFrequency.Value);
                        tracing.Trace("NEW REV FREQ "+newRevenueFrequency.Value);
                        tracing.Trace("OLD REV FREQ "+oldRevenueFrequency.Value);
                        addedProducts.Add(newProduct);
                        if(oldEndDate >= newStartDate)
                        {
                            oldProduct.Attributes.Add("isTerminated", newStartDate);
                            removedProducts.Add(oldProduct);
                        }

                    }
                    else
                    {
                        var oldRate = Math.Round(oldAmount / Convert.ToDecimal(oldTermLength),2);
                        if(newStartDate > oldEndDate && (newStartDate - oldEndDate).TotalDays >1)
                            addedProducts.Add(newProduct);
                        else
                        {
                            if (oldRate == newRate)
                                isContractEndDateOnlyExtendedGuids.Add(newProduct.Id);
                            return newRate != oldRate || newEndDate != oldEndDate || (oldStartDate == newStartDate && (oldBillingFrequency.Value != newBillingFrequency.Value || newRevenueFrequency.Value != oldRevenueFrequency.Value));
                        }

                    }
                }
                return false;
            }).ToList();
        }
        public void checkRevShareAsset(List<Entity> OldProducts, List<Entity> NewProducts, IOrganizationService service, List<Entity> AddedProducts, List<Entity> priceChangeProducts, Entity NewOppQuote, Entity OldOppQuote)
        {
            List<Entity> NewProductList = CommonHelper.GetRevShareQuoteProduct(service, NewOppQuote.Id);
            List<Entity> OldProductList = CommonHelper.GetRevShareQuoteProduct(service, OldOppQuote.Id);

            tracing.Trace("NEW REVSHARE COUNT: "+NewProductList.Count);
            foreach (Entity newRevShareProduct in NewProductList)
            {
                EntityReference childOpportunity = newRevShareProduct.GetAttributeValue<EntityReference>("niq_correspondingchildopportunity");
                Entity OriginalChild = service.Retrieve(childOpportunity.LogicalName, childOpportunity.Id, new ColumnSet(true));
                tracing.Trace("ORIGINALL CHILD: "+ OriginalChild.Id);
                //tracing.Trace("CORRESPONDING CHILD : "+ OriginalChild.GetAttributeValue<EntityReference>("niq_amendedfromopportunity").Id);
                EntityReference originalAmendFrom = OriginalChild.GetAttributeValue<EntityReference>("niq_amendedfromopportunity");
                OptionSetValue opportunityType = OriginalChild.GetAttributeValue<OptionSetValue>("niq_opportunitytype");
                if(opportunityType.Value == 2)
                {
                    if (originalAmendFrom == null)
                        AddedProducts.Add(newRevShareProduct);
                    else
                    {
                        Entity filteredOldProduct = OldProductList.Where(OldProduct => OldProduct.GetAttributeValue<EntityReference>("niq_correspondingchildopportunity").Id == originalAmendFrom.Id).First();
                        var newAmount = newRevShareProduct.GetAttributeValue<Money>("extendedamount")?.Value ?? 0m;
                        var oldAmount = filteredOldProduct.GetAttributeValue<Money>("extendedamount")?.Value ?? 0m;
                        if (newAmount != oldAmount)
                        {
                            priceChangeProducts.Add(newRevShareProduct);
                        }
                    }
                }
                else
                    AddedProducts.Add(newRevShareProduct);
            }
        }

        // link all nodes to payload
        public void linkItemsToPayload(List<Item> contractLineItmes, List<Item> contractBillingLineItmes, List<Item> customResearchItems, CONTRACTHEADER header)
        {
            if(contractLineItmes.Count > 0 && customResearchItems.Count > 0)
            {
                CommonHelper.initializeArrayObjects(header);
                header.CONTRACT_LINE_ITEMS.item = contractLineItmes;
                tracing.Trace("CONTRACT LINE ITEMS ADDED TO PAYLOAD");
                header.CONTRACT_LINE_ITEM_BILLING.item = contractBillingLineItmes;
                tracing.Trace("CONTRACT LINE ITEM BILLING ADDED TO PAYLOAD");
            }
            if (customResearchItems.Count > 0)
            {
                tracing.Trace("INSIDE SCHEDULE MAPPING IF CONDITION");
                header.CUSTOM_RESEARCH_BILLING_SCHEDU = new CUSTOMRESEARCHITEM();
                header.CUSTOM_RESEARCH_BILLING_SCHEDU.item = customResearchItems;
                tracing.Trace("SCHEDULED ADDED TO PAYLOAD");
            }
        }

        public void mapLineItemNumberforNoChangeProducts(List<Entity> newOppProducts, List<Entity> oldOppProducts ,List<Entity> removedProducts, List<Entity> addedProducts, List<Entity> PriceChangedProducts, IOrganizationService service)
        {
            var filteredProducts = newOppProducts
            .Where(p => !removedProducts.Any(r => r.GetAttributeValue<EntityReference>("productid")?.Id == p.GetAttributeValue<EntityReference>("productid")?.Id && r.GetAttributeValue<string>("niq_contractproductname") == p.GetAttributeValue<string>("niq_contractproductname") && Guid.Parse(r.GetAttributeValue<string>("niq_elassetid")) == Guid.Parse(p.GetAttributeValue<string>("niq_elassetid")))
            && !addedProducts.Any(a => a.GetAttributeValue<EntityReference>("productid")?.Id == p.GetAttributeValue<EntityReference>("productid")?.Id && a.GetAttributeValue<string>("niq_contractproductname") == p.GetAttributeValue<string>("niq_contractproductname") && Guid.Parse(a.GetAttributeValue<string>("niq_elassetid")) == Guid.Parse(p.GetAttributeValue<string>("niq_elassetid")))
             && !PriceChangedProducts.Any(pc => pc.GetAttributeValue<EntityReference>("productid")?.Id == p.GetAttributeValue<EntityReference>("productid")?.Id && pc.GetAttributeValue<string>("niq_contractproductname") == p.GetAttributeValue<string>("niq_contractproductname") && Guid.Parse(pc.GetAttributeValue<string>("niq_elassetid")) == Guid.Parse(p.GetAttributeValue<string>("niq_elassetid"))))
            .ToList();
            if(filteredProducts.Count > 0)
            {
                foreach(Entity filteredProduct in filteredProducts)
                {
                    bool isRevShare = filteredProduct.GetAttributeValue<bool>("niq_isrevshareline");
                    if (isRevShare)
                    {
                        EntityReference AmendedChildRef = filteredProduct.GetAttributeValue<EntityReference>("niq_correspondingchildopportunity");
                        Entity AmendedChild = service.Retrieve(AmendedChildRef.LogicalName, AmendedChildRef.Id, new ColumnSet("niq_amendedfromopportunity"));
                        EntityReference OriginalChild = AmendedChild.GetAttributeValue<EntityReference>("niq_amendedfromopportunity");
                        var oldProduct = oldOppProducts.FirstOrDefault(op => op.GetAttributeValue<EntityReference>("niq_correspondingchildopportunity")?.Id == OriginalChild.Id);
                        if(oldProduct != null)
                        {
                            var oldLineItemNumber = oldProduct.GetAttributeValue<string>("niq_lineitemnumberforsap");
                            int toBeLineItemNumber = Int32.Parse(oldLineItemNumber.Remove(oldLineItemNumber.Length - 1));
                            Entity Product = new Entity("quotedetail", filteredProduct.Id);
                            Product["sequencenumber"] = toBeLineItemNumber;
                            Product["niq_lineitemnumberforsap"] = CommonHelper.getLineItemNumberForSap(toBeLineItemNumber);
                            service.Update(Product);
                        }
                    }
                    else
                    {
                        var newProductId = filteredProduct.GetAttributeValue<EntityReference>("productid")?.Id;
                        var newContractProductName = filteredProduct.GetAttributeValue<string>("niq_contractproductname");
                        var newElassetId = filteredProduct.GetAttributeValue<string>("niq_elassetid");
                        var oldProduct = oldOppProducts.FirstOrDefault(op => op.GetAttributeValue<EntityReference>("productid")?.Id == newProductId && op.GetAttributeValue<string>("niq_contractproductname") == newContractProductName && Guid.Parse(op.GetAttributeValue<string>("niq_elassetid")) == Guid.Parse(newElassetId));
                        var oldLineItemNumber = oldProduct.GetAttributeValue<string>("niq_lineitemnumberforsap");
                        int toBeLineItemNumber = Int32.Parse(oldLineItemNumber.Remove(oldLineItemNumber.Length - 1));
                        Entity Product = new Entity("quotedetail", filteredProduct.Id);
                        Product["sequencenumber"] = toBeLineItemNumber;
                        Product["niq_lineitemnumberforsap"] = CommonHelper.getLineItemNumberForSap(toBeLineItemNumber);
                        service.Update(Product);
                    }
                }
            }
        }
    }
}
