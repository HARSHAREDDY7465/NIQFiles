﻿using ABOIntegration.Class;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ABOIntegration.Common;
using System.Runtime.CompilerServices;
using Microsoft.Xrm.Sdk.Query;

namespace ABOIntegration.Operations
{
    public class SAPABOItemRejectionPayload
    {
        static ITracingService tracingservice;
        public static void createPayloadForRejectedItems(IOrganizationService service, ITracingService tracing, List<Entity> removedProducts, CONTRACTHEADER header, Entity OldOpportunity, Entity OldOppQuote, List<Item> contractLineItmes, List<Item> contractBillingLineItmes, List<Item> customResearchItems, Entity NewOpportunity, List<Entity> OldOppQuoteProducts, DateTime newContractStartDate)
        {
            tracingservice = tracing;
            createContractLineItemsForRemovedProducts(service, removedProducts, header, OldOpportunity, OldOppQuote, contractLineItmes);
            createContractLineItemBillingForRemovedProducts(removedProducts, header, OldOppQuote, OldOpportunity, contractBillingLineItmes, NewOpportunity, tracing, service, newContractStartDate);
            //CommonHelper.createCustomResearchBillingSchedule(removedProducts, header, OldOpportunity, customResearchItems, OldOppQuoteProducts, service, tracing, false, false);
        }

        // Create contract Line Item fo the product
        public static void createContractLineItemsForRemovedProducts(IOrganizationService service, List<Entity> removedProducts, CONTRACTHEADER header, Entity Opportuntiy, Entity OldQuote, List<Item> listItem)
        {
            tracingservice.Trace("Entering createContractLineItemsForRemovedProducts FN");
            EntityReference MainQuote = Opportuntiy.GetAttributeValue<EntityReference>("niq_mainquoteid");
            List<Entity> QuoteCharacteristics = CommonHelper.getQuoteProductsCharacteristics(service, MainQuote.Id);
            foreach (Entity removedProduct in removedProducts)
            {
                List<Entity> FilteredQuoteCharacteristics = QuoteCharacteristics.Where(e => e.Contains("niq_quoteproductid") &&
                        e["niq_quoteproductid"] is EntityReference && ((EntityReference)e["niq_quoteproductid"]).Id == removedProduct.Id).ToList();
                var item = new Item();
                item.LINE_ITEM_NUMBER = Opportuntiy.GetAttributeValue<string>("niq_opportunitynumber");
                item.SALES_DOC_ITEM = removedProduct.GetAttributeValue<string>("niq_lineitemnumberforsap");
                item.QUOTEPRODUCT_ID = removedProduct.Id.ToString();
                item.MATERIAL_NUMBER = removedProduct.GetAttributeValue<string>("productnumber");
                item.PLANT = CommonHelper.getSalesOrgId(service, Opportuntiy.GetAttributeValue<EntityReference>("niq_salesorgid").Id);
                //item.REJECTION_REASON = "06";
                item.CURRENCY_KEY = CommonHelper.getCurrencyCode(service, Opportuntiy.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                //if (FilteredQuoteCharacteristics.Count() > 0)
                //{
                //    item.CHARACTERSTICS = new PRODUCTCHARATERISTICS();
                //    item.CHARACTERSTICS.item = new List<Item>();
                //    foreach (Entity filteredQuoteCharacteristic in FilteredQuoteCharacteristics)
                //    {
                //        var ProductCharacteristic = new Item();
                //        if (filteredQuoteCharacteristic.GetAttributeValue<EntityReference>("niq_materialcharacteristicid") != null)
                //        {
                //            ProductCharacteristic.CHARACTERSTIC_NAME = filteredQuoteCharacteristic.GetAttributeValue<AliasedValue>("niq_materialcharacteristicid.niq_characteristiccode").Value.ToString();
                //            if (filteredQuoteCharacteristic.GetAttributeValue<EntityReference>("niq_materialcharacteristicvalueid") != null)
                //                ProductCharacteristic.CHARACTERISTIC_VALUE = filteredQuoteCharacteristic.GetAttributeValue<AliasedValue>("niq_materialcharacteristicvalueid.niq_characteristicvaluecode").Value.ToString();
                //        }
                //        item.CHARACTERSTICS.item.Add(ProductCharacteristic);
                //    }
                //}
                listItem.Add(item);
            }
            tracingservice.Trace("Leaving createContractLineItemsForRemovedProducts FN");

        }
        //Create Contract Billing Item of the Product
        public static void createContractLineItemBillingForRemovedProducts(List<Entity> removedProducts, CONTRACTHEADER header, Entity Quote, Entity Opportunity, List<Item> contractBillingLineItmes, Entity NewOpportunity, ITracingService tracing, IOrganizationService service, DateTime contractStartDate)
        {
            tracing.Trace("Entering createContractLineItemBillingForRemovedProducts FN");
            OptionSetValue termType = Quote.GetAttributeValue<OptionSetValue>("niq_termtype");
            DateTime CstartDate = DateTime.Now;
            Entity FARrecord = CommonHelper.getFAR(service, NewOpportunity.Id);
            tracing.Trace("FAR RETERIEVED");
            foreach (Entity removedProduct in removedProducts)
            {
                tracing.Trace("REJECTED DATE : " + removedProduct.GetAttributeValue<DateTime>("isTerminated"));
                tracing.Trace("contains : " + removedProduct.Attributes.Contains("isTerminated"));
                DateTime rejectionDate = DateTime.Now;
                if (removedProduct.Attributes.Contains("isTerminated"))
                    CstartDate = removedProduct.GetAttributeValue<DateTime>("isTerminated").AddDays(-1);
                else
                {
                    CstartDate = contractStartDate.AddDays(-1); // Fixed for DYNCRM-27794
                    if (removedProduct.GetAttributeValue<OptionSetValue>("niq_type").Value == 2) 
                    {
                        tracingservice.Trace("CstartDate before Rejection" + CstartDate);
                        //rejectionDate = getRejectiondate(service, CstartDate, removedProduct.Id);
                        rejectionDate = CstartDate;
                        tracing.Trace("rejectionDate:" + rejectionDate); 
                    }
                    else
                    {
                        tracing.Trace("2. rejectionDate:" + rejectionDate);
                        rejectionDate = contractStartDate.AddDays(-1);
                    }

                }
                //CstartDate = contractStartDate.AddDays(-1);
                
                tracing.Trace("REJECTION DATE: " + rejectionDate.ToString());
                Item billItem = new Item();
                billItem.LINE_ITEM_NUMBER = Opportunity.GetAttributeValue<string>("niq_opportunitynumber");
                billItem.SALES_DOC_ITEM = removedProduct.GetAttributeValue<string>("niq_lineitemnumberforsap");
                tracing.Trace("MAPPED TILL SALES DOC ITEM");
                if (removedProduct.Attributes.Contains("niq_originalcontractstartdate") && removedProduct.GetAttributeValue<DateTime>("niq_originalcontractstartdate") != null && removedProduct.GetAttributeValue<DateTime>("niq_originalcontractstartdate") != DateTime.MinValue)
                {
                    billItem.CONTRACT_START_DATE = CommonHelper.GetdateinddMMyyyy(removedProduct.GetAttributeValue<DateTime>("niq_originalcontractstartdate").ToString());
                }
                else
                {
                    billItem.CONTRACT_START_DATE = CommonHelper.GetdateinddMMyyyy(removedProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate").ToString());
                }
                tracing.Trace("MAPPED TILL START DATE");

                if (removedProduct.Attributes.Contains("isTerminated"))
                {
                    tracing.Trace("1:");
                    billItem.CONTRACT_END_DATE = CommonHelper.GetdateinddMMyyyy(CstartDate.ToString());
                }
                else
                {
                    tracing.Trace("2:" + CommonHelper.GetdateinddMMyyyy(rejectionDate.ToString()));
                    billItem.CONTRACT_END_DATE = CommonHelper.GetdateinddMMyyyy(rejectionDate.ToString());
                }
                //billItem.CONTRACT_END_DATE = CommonHelper.GetdateinddMMyyyy(removedProduct.GetAttributeValue<DateTime>("niq_lineitemenddate").ToString());
                tracing.Trace("MAPPED TILL END DATE");
                tracing.Trace("INSIDE EVERGREEN LOOP");
                billItem.CANCELLATION_PROC = "0006";
                billItem.CANCELLATION_REASON = CommonHelper.getCancellationReasons(NewOpportunity);
                tracing.Trace("MAPPED CANCELLATIONREASONS");
                billItem.CANCEL_RECEIVED_DATE = CommonHelper.GetdateinddMMyyyy(FARrecord.GetAttributeValue<DateTime>("createdon").ToString());
                tracing.Trace("MAPPED CANCEL_RECEIVED_DATE");

                if (removedProduct.Attributes.Contains("isTerminated"))
                {
                    tracing.Trace("1:");
                    billItem.CANCEL_REQUEST_DATE = CommonHelper.GetdateinddMMyyyy(CstartDate.ToString());
                }
                else
                {
                    tracing.Trace("2:" + CommonHelper.GetdateinddMMyyyy(rejectionDate.ToString()));
                    billItem.CANCEL_REQUEST_DATE = CommonHelper.GetdateinddMMyyyy(rejectionDate.ToString());
                }

                tracing.Trace("MAPPED CANCEL_REQUEST_DATE");
                contractBillingLineItmes.Add(billItem);
            }
            tracing.Trace("Leaving createContractLineItemBillingForRemovedProducts FN");
        }

        public static DateTime getRejectiondate(IOrganizationService service, DateTime contractStartDate, Guid ProductId)
        {
            tracingservice.Trace("REJECTION For: " + ProductId);

            string fetchxml = "";
            fetchxml = $@"<fetch top='1'>
	                            <entity name='niq_schedule'>
		                            <attribute name='niq_scheduleid' />
		                            <attribute name='niq_scheduledate' />
		                            <filter type='and'>
			                            <condition attribute='niq_lineitemid' operator='eq' value='{ProductId}' />
			                            <condition attribute='niq_scheduledate' operator='ge' value='{CommonHelper.GetdateinMMddyyyy(contractStartDate.ToString())}' />
			                            <condition attribute='niq_scheduletype' operator='eq' value='100000000' />
		                            </filter>
		                            <order attribute='niq_scheduledate' />
	                            </entity>
                            </fetch>";
            tracingservice.Trace("fetchxml:" + fetchxml);
            Entity schedule = service.RetrieveMultiple(new FetchExpression(fetchxml)).Entities.ToList().FirstOrDefault();
            tracingservice.Trace("END DATE: " + CommonHelper.GetdateinMMddyyyy(contractStartDate.ToString()));
            DateTime scheduleDate = schedule.GetAttributeValue<DateTime>("niq_scheduledate");
            tracingservice.Trace("schedule date: " + scheduleDate);
            tracingservice.Trace("contract date: " + contractStartDate);
            if (scheduleDate == contractStartDate)
            {
                tracingservice.Trace("11 :contractStartDate:" + contractStartDate);
                return contractStartDate;
            }
            else
            {
                tracingservice.Trace("12 :scheduleDate:" + scheduleDate.AddDays(-1));
                return scheduleDate.AddDays(-1);
            }

        }
    }
}
