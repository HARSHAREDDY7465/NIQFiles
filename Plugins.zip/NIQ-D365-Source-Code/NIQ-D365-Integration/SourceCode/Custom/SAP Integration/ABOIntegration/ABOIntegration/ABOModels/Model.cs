﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ABOIntegration.Class;

namespace ABOIntegration.Class
{


    public class Body
    {
        public ZSDFMICCONTCHANGESERVICE ZSDFM_IC_CONT_CHANGE_SERVICE { get; set; }
    }

    public class CONTRACTHEADER
    {
        public string CONTRACT_NUMBER { get; set; }
        public string OPPORTUNITY_NUMBER { get; set; }
        public string BILLING_BLOCK { get; set; }
        public HEADERPARTNERFUNCTIONS HEADER_PARTNER_FUNCTIONS { get; set; }
        public CONTRACTLINEITEMS CONTRACT_LINE_ITEMS { get; set; }
        public CONTRACTLINEITEMSBILLING CONTRACT_LINE_ITEM_BILLING { get; set; }
        public CUSTOMRESEARCHITEM CUSTOM_RESEARCH_BILLING_SCHEDU { get; set; }
        public LINEITEMTEXT LINE_ITEM_TEXT { get; set; } 


    }
    public class LINEITEMTEXT
    {
        public List<Item> item { get; set; }
    }

    public class CONTRACTLINEITEMS
    {
        public List<Item> item { get; set; }
    }

    public class CONTRACTLINEITEMSBILLING
    {
        public List<Item> item { get; set; }
    }
    public class CUSTOMRESEARCHITEM
    {
        public List<Item> item { get; set; }
    }

    public class PRODUCTCHARATERISTICS
    {
        public string CHRACTERISTIC_NAME { get; set; }
        public string CHRACTERISTIC_VALUE { get; set; }

        public List<Item> item { get; set; }
    }

    public class CustomResearchItem
    {
        public string LineItemNumber { get; set; }
        public string SalesDocItem { get; set; }
        public string ContractRefNumber { get; set; }
        public string GRNNumber { get; set; }
        public string BillingDate { get; set; }
        public string ScheduleLine_date { get; set; }
        public string BilingValue { get; set; }
        public string Order_QTY { get; set; }
    }

    public class Header
    {
        public string __prefix { get; set; }
    }

    public class HEADERPARTNERFUNCTIONS
    {
        public SOLDTOPARTY SOLD_TO_PARTY { get; set; }
        public SHIPTOPARTY SHIP_TO_PARTY { get; set; }
        public BILLTOPARTY BILL_TO_PARTY { get; set; }
        public POSALESEMPLOYEE POSALES_EMPLOYEE { get; set; }
        public INVOICERECIPIPENT INVOICE_RECIPIPENT { get; set; }
        public INVOICERECIPIPENT INVOICE_RECIPIPENT1 { get; set; }
        public INVOICERECIPIPENT INVOICE_RECIPIPENT2 { get; set; }
        public INVOICERECIPIPENT INVOICE_RECIPIPENT3 { get; set; }
        public INVOICERECIPIPENT INVOICE_RECIPIPENT4 { get; set; }
        public INVOICERECIPIPENT INVOICE_RECIPIPENT5 { get; set; }
    }
    public class INVOICERECIPIPENT
    {
        public string VALUE { get; set; }
        public string CUSTOMER_NUMBER { get; set; }
    }

    public class POSALESEMPLOYEE
    {
        public string VALUE { get; set; }
        public string CUSTOMER_NUMBER { get; set; }
    }

    public class INPUT
    {
        public MTECCCONTRACTASYNCREQ MT_ECCCONTRACT_ASYNC_REQ { get; set; }
    }

    public class Item
    {
        public string SALES_DOC_ITEM { get; set; }
        public string LINE_ITEM_NUMBER { get; set; }
        public string SAPFREE_TEXT_ID { get; set; }
        public string LANGUAGE_KEY { get; set; }
        public string SAPTEXT_OBJ_NAME { get; set; }
        public string FREE_TEXT { get; set; }
        public string QUOTEPRODUCT_ID { get; set; }
        public string PQUOTEPRODUCT_ID { get; set; }
        public string MATERIAL_NUMBER { get; set; }
        public string MATERIAL_DESCRIPTION { get; set; }
        public string PLANT { get; set; }
        public string TARGET_QTY { get; set; }
        public string TARGET_UOM { get; set; }
        public string ORDER_QTY { get; set; }
        public string SALES_UNIT { get; set; }
        public string WBSELEMENT { get; set; }
        public string CUSTOMER_PONUMBER { get; set; }
        public string SHIP_TO_PONUMBER { get; set; }
        public string REJECTION_REASON { get; set; }
        public string ITEM_CATEGORY { get; set; }
        public string MATERIAL_GRP4 { get; set; }
        public string MATERIAL_GRP5 { get; set; }
        public string DELIVERY_TIME { get; set; }
        public string PROFIT_CENTER { get; set; }
        public string SHIP_TO_PO_DATE { get; set; }
        public string CONDITION_TYPE { get; set; }
        public string RATE { get; set; }
        public string CURRENCY_KEY { get; set; }
        public string CONTRACT_START_DATE { get; set; }
        public string CONTRACT_END_DATE { get; set; }
        public string POEXPIRY_DATE { get; set; }
        public string BILLING_FREQUENCY { get; set; }
        public string BILLING_DATE { get; set; }
        public string BILING_VALUE { get; set; }
        public string CONTRACT_REF_NUMBER { get; set; }
        public string DELIVERY_ITEM_NUMBER { get; set; }
        public string SCHEDULE_LINE_DATE { get; set; }
        public PRODUCTCHARATERISTICS CHARACTERSTICS { get; set; }
        public string PRICE_AFT_CHGIN_VALUE { get; set; }
        public string PRICE_CHG_EFF_FROM { get; set; }
        public string CANCELLATION_PROC { get; set; }
        public string CANCELLATION_REASON { get; set; }
        public string CANCEL_RECEIVED_DATE { get; set; }
        public string CANCEL_REQUEST_DATE { get; set; }

        public string BILLING_PLAN_NUMBER { get; set; }
        public string BILLING_PLAN_ITEM_NUMBER { get; set; }
        public string BILLING_DEVIATION { get; set; }
        public string BILLING_IN_ADVANCE { get; set; }
        public string GRNNUMBER { get; set; }
        public string Order_QTY { get; set; }
        public string CHARACTERSTIC_NAME { get; set; }
        public string CHARACTERISTIC_VALUE { get; set; }

    }

    public class HeaderItem
    {
        public CONTRACTHEADER CONTRACT_HEADER { get; set; }
    }

    public class MTECCCONTRACTASYNCREQ
    {
        public HeaderItem item { get; set; }
    }

    public class SHIPTOPARTY
    {
        public string VALUE { get; set; }
        public string CUSTOMER_NUMBER { get; set; }
    }

    public class SOLDTOPARTY
    {
        public string VALUE { get; set; }
        public string CUSTOMER_NUMBER { get; set; }
    }
    public class BILLTOPARTY
    {
        public string VALUE { get; set; }
        public string CUSTOMER_NUMBER { get; set; }
    }

    public class ZSDFMICCONTCHANGESERVICE
    {
        public INPUT INPUT { get; set; }
    }

    public class Billingitem
    {
        public string LINE_ITEM_NUMBER { get; set; }
        public string SALES_DOC_ITEM { get; set; }
        public string CONTRACT_START_DATE { get; set; }
        public string CONTRACT_END_DATE { get; set; }
        public string PRICE_AFT_CHGIN_VALUE { get; set; }
        public string PRICE_CHG_EFF_FROM { get; set; }
        public string CANCELLATION_PROC { get; set; }
        public string CANCELLATION_REASON { get; set; }
        public string CANCEL_RECEIVED_DATE { get; set; }
        public string CANCEL_REQUEST_DATE { get; set; }
        public string BILLING_FREQUENCY { get; set; }
        public string BILLING_DEVIATION { get; set; }
        public string BILLING_IN_ADVANCE { get; set; }
    }

}
