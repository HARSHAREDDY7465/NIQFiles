﻿using ABOIntegration.Class;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Security.Cryptography;
using static ABOIntegration.Class.ENUM;

namespace ABOIntegration.Common
{
    public class CommonHelper
    {
        public static bool IsCustomResearchNodeInitialized = false; 
        public static List<Entity> getQuoteProductsCharacteristics(IOrganizationService service, Guid QuoteId)
        {
            string FetchXML = $@"<fetch>
                                <entity name='niq_quoteproductcharacteristic'>
                                    <attribute name='niq_quoteproductcharacteristicid' />
                                    <attribute name='niq_quoteproductid' />
                                    <attribute name='niq_quoteproductidname' />
                                    <attribute name='niq_materialcharacteristicid' />
                                    <attribute name='niq_materialcharacteristicvalueid' />
                                    <filter type='and'>
                                        <condition entityname='niq_quoteproductid' attribute='quoteid' operator='eq' value='{QuoteId}' />
                                        <condition entityname='niq_quoteproductid' attribute='quantity' operator='gt' value='0' />
                                        <condition attribute='niq_materialcharacteristicvalueid' operator='not-null' />
                                    </filter>
                                    <link-entity name='niq_characteristicvalue' from='niq_characteristicvalueid' to='niq_materialcharacteristicvalueid' alias='niq_materialcharacteristicvalueid' link-type='outer'>
                                        <attribute name='niq_characteristicvaluecode' />
                                    </link-entity>
                                    <link-entity name='niq_materialcharacteristic' from='niq_materialcharacteristicid' to='niq_materialcharacteristicid' alias='niq_materialcharacteristicid' link-type='outer'>
                                        <attribute name='niq_characteristiccode' />
                                    </link-entity>
                                    <link-entity name='quotedetail' from='quotedetailid' to='niq_quoteproductid' alias='niq_quoteproductid' link-type='outer'>
                                        <attribute name='quotedetailid' />
                                    </link-entity>
                                </entity>
                            </fetch>";
            return service.RetrieveMultiple(new FetchExpression(FetchXML)).Entities.ToList();
        }
        public static string getSalesOrgId(IOrganizationService service, Guid salesOrgId)
        {
            return service.Retrieve("niq_salesorg", salesOrgId, new ColumnSet("niq_salesorgcode")).GetAttributeValue<string>("niq_salesorgcode");
        }

        public static string getCurrencyCode(IOrganizationService service, Guid CurrencyId)
        {
            return service.Retrieve("transactioncurrency", CurrencyId, new ColumnSet("isocurrencycode")).GetAttributeValue<string>("isocurrencycode");
        }

        public static string GetdateinddMMyyyy(string date)
        {
            if (date != null && Convert.ToString(date).Trim().Length > 0)
                return Convert.ToDateTime(date).ToString("ddMMyyyy");
            return "";
        }
        public static string GetdateinMMddyyyy(string date)
        {
            if (date != null && Convert.ToString(date).Trim().Length > 0)
                return Convert.ToDateTime(date).ToString("MM-dd-yyyy");
            return "";
        }
        public static Entity getFAR(IOrganizationService service, Guid OppId)
        {
            string FetchXML = $@"<fetch top='1'>
                                <entity name='niq_financeapprovalrequests'>
                                    <attribute name='niq_financeapprovalrequestsid' />
                                    <attribute name='createdon' />
                                    <filter type='and'>
                                        <condition attribute='niq_relatedopportunity' operator='eq' value='{OppId}' />
                                    </filter>
                                    <order attribute='createdon' descending='true' />
                                </entity>
                            </fetch>";
            return service.RetrieveMultiple(new FetchExpression(FetchXML)).Entities.First();
        }

        public static string getCancellationReasons(Entity Opportunity)
        {
            OptionSetValue ExistingAction = Opportunity.GetAttributeValue<OptionSetValue>("niq_existingcontractaction");
            OptionSetValue iscancelled = Opportunity.GetAttributeValue<OptionSetValue>("niq_iscanceled");
            if (ExistingAction.Value == (Int32)ExistingContractAction.Renewal) // Renewal
                return "08";
            else if (ExistingAction == new OptionSetValue((Int32)ExistingContractAction.Amendment) && iscancelled == new OptionSetValue((Int32)isCancelled.Canceled)) // Amendment
                return "15";
            else if (ExistingAction == new OptionSetValue((Int32)ExistingContractAction.Amendment) && iscancelled == new OptionSetValue((Int32)isCancelled.No)) // Amendment
                return "27";
            else
                return "08";
        }
        //Common funtion to create Custom schedules node for adhoc products
        public static void createCustomResearchBillingSchedule(List<Entity> Products, CONTRACTHEADER header, Entity Opportunity, List<Item> customResearchItems, List<Entity> OldOppQuoteProducts, IOrganizationService service, ITracingService tracing, bool isAdded, bool isPriceChanged)
        {
            foreach (Entity adhocProduct in Products)
            {
                Entity itemCategoryGroupMetadata = getItemCatecoryGroupMetadata(service, adhocProduct.GetAttributeValue<string>("niq_pricelistitem"));
                tracing.Trace("ITEM CATEGORY ID: " + itemCategoryGroupMetadata.Id);
                if (!IsPeriodicinItemCategoryGroupMetadata(adhocProduct, service)) //ADHOC
                {
                    OptionSetValue existingContractAction = Opportunity.GetAttributeValue<OptionSetValue>("niq_existingcontractaction");
                    tracing.Trace("INSIDKE ADHOC IF CONDITION");
                    List<Entity> schedules = getSchedules(service, itemCategoryGroupMetadata, adhocProduct, tracing);
                    tracing.Trace("schedules fetched! COUNT: " + schedules.Count());
                    var oldProduct = new Entity();
                    if (isPriceChanged)
                    {
                        bool isrevshare = adhocProduct.GetAttributeValue<bool>("niq_isrevshareline");
                        if (isrevshare)
                        {
                            EntityReference AmendedChildRef = adhocProduct.GetAttributeValue<EntityReference>("niq_correspondingchildopportunity");
                            Entity AmendedChild = service.Retrieve(AmendedChildRef.LogicalName, AmendedChildRef.Id, new ColumnSet("niq_amendedfromopportunity"));
                            EntityReference OriginalChild = AmendedChild.GetAttributeValue<EntityReference>("niq_amendedfromopportunity");
                            QueryExpression query = new QueryExpression("quotedetail")
                            {
                                ColumnSet = new ColumnSet(true)
                            };
                            query.Criteria.AddCondition("niq_correspondingchildopportunity", ConditionOperator.Equal, OriginalChild.Id);
                            oldProduct = service.RetrieveMultiple(query).Entities.FirstOrDefault();
                        }
                        else
                        {
                            oldProduct = OldOppQuoteProducts.FirstOrDefault(op => op.GetAttributeValue<EntityReference>("productid")?.Id == adhocProduct.GetAttributeValue<EntityReference>("productid")?.Id && op.GetAttributeValue<string>("niq_contractproductname") == adhocProduct.GetAttributeValue<string>("niq_contractproductname") && Guid.Parse(op.GetAttributeValue<string>("niq_elassetid")) == Guid.Parse(adhocProduct.GetAttributeValue<string>("niq_elassetid")));
                        }
                        if (existingContractAction.Value == 4)
                        {
                            DateTime newStartDate = adhocProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                            string lineitmeNumber = oldProduct.GetAttributeValue<string>("niq_lineitemnumberforsap");
                            List<Entity> schedulesToDelete = getSchedulesToDelete(service, itemCategoryGroupMetadata, oldProduct, tracing, newStartDate);
                            foreach (Entity schedule in schedulesToDelete)
                            {
                                DateTime scheduleDate = schedule.GetAttributeValue<DateTime>("niq_scheduledate");
                                OptionSetValue scheduleType = schedule.GetAttributeValue<OptionSetValue>("niq_scheduletype");
                                if (!schedules.Any(e => e.GetAttributeValue<DateTime>("niq_scheduledate") == scheduleDate && ((e.GetAttributeValue<OptionSetValue>("niq_scheduletype").Value == 100000000 && e.GetAttributeValue<OptionSetValue>("niq_scheduletype").Value == scheduleType.Value) || (e.GetAttributeValue<OptionSetValue>("niq_scheduletype").Value == 100000001 || e.GetAttributeValue<OptionSetValue>("niq_scheduletype").Value == 100000002) && (scheduleType.Value == 100000001 || scheduleType.Value == 100000002))))
                                {
                                    Item customResearchBillingItem = new Item();
                                    tracing.Trace("Schedule to delete");
                                    customResearchBillingItem.LINE_ITEM_NUMBER = Opportunity.GetAttributeValue<string>("niq_opportunitynumber");
                                    customResearchBillingItem.SALES_DOC_ITEM = oldProduct.GetAttributeValue<string>("niq_lineitemnumberforsap");
                                    customResearchBillingItem.CONTRACT_REF_NUMBER = Opportunity.Id.ToString();
                                    customResearchBillingItem.GRNNUMBER = "02";
                                    customResearchBillingItem.BILLING_DATE = GetdateinddMMyyyy(schedule["niq_scheduledate"].ToString());
                                    customResearchBillingItem.SCHEDULE_LINE_DATE = GetdateinddMMyyyy(schedule["niq_scheduledate"].ToString());
                                    if ((IsRequiredinItemCategoryGroupMetadata(itemCategoryGroupMetadata, "niq_schedulelinedate") || IsRequiredinItemCategoryGroupMetadata(itemCategoryGroupMetadata, "niq_orderquantity")) && ((schedule.GetAttributeValue<OptionSetValue>("niq_scheduletype").Value == 100000001 || schedule.GetAttributeValue<OptionSetValue>("niq_scheduletype").Value == 100000002)))
                                    {
                                        customResearchBillingItem.ORDER_QTY = "X";
                                        customResearchBillingItem.BILING_VALUE = "0.00";
                                    }
                                    else
                                    {
                                        customResearchBillingItem.BILING_VALUE = "X";
                                        customResearchBillingItem.ORDER_QTY = "0.00";
                                    }
                                    customResearchItems.Add(customResearchBillingItem);
                                    tracing.Trace("Custom Schedule deleted");
                                }
                            }
                        }
                    }
                    tracing.Trace("OLD PRODUCT FETCHED IN CUSTOM RESEARCH: " + oldProduct.Id);

                    DateTime effectiveDate = Opportunity.GetAttributeValue<DateTime>("niq_effectivedate");
                    if (existingContractAction.Value == 2)
                    {
                        //DateTime nextBillingCycle = getNextBillingDate(effectiveDate, schedules);
                        tracing.Trace("BILLING CYCLE DATE FOR PE COLA: " + effectiveDate.ToString());
                        schedules.RemoveAll(e => !e.Contains("niq_scheduledate") || !(e["niq_scheduledate"] is DateTime date) || date < effectiveDate);
                    }

                    foreach (var scheduleitem in schedules)
                    {
                        Item customResearchBillingItem = new Item();
                        tracing.Trace("NEW CUSTOME ITEM");
                        customResearchBillingItem.LINE_ITEM_NUMBER = Opportunity.GetAttributeValue<string>("niq_opportunitynumber");
                        if (!isAdded)
                        {
                            customResearchBillingItem.SALES_DOC_ITEM = oldProduct.GetAttributeValue<string>("niq_lineitemnumberforsap");
                        }
                        else
                        {
                            //customResearchBillingItem.SALES_DOC_ITEM = adhocProduct.GetAttributeValue<string>("niq_lineitemnumberforsap");
                            customResearchBillingItem.SALES_DOC_ITEM = service.Retrieve(adhocProduct.LogicalName, adhocProduct.Id, new ColumnSet("niq_lineitemnumberforsap")).GetAttributeValue<string>("niq_lineitemnumberforsap");
                        }
                        customResearchBillingItem.CONTRACT_REF_NUMBER = Opportunity.Id.ToString();
                        customResearchBillingItem.GRNNUMBER = "02";
                        customResearchBillingItem.BILLING_DATE = GetdateinddMMyyyy(scheduleitem["niq_scheduledate"].ToString());
                        customResearchBillingItem.SCHEDULE_LINE_DATE = GetdateinddMMyyyy(scheduleitem["niq_scheduledate"].ToString());
                        if ((IsRequiredinItemCategoryGroupMetadata(itemCategoryGroupMetadata, "niq_schedulelinedate") || IsRequiredinItemCategoryGroupMetadata(itemCategoryGroupMetadata, "niq_orderquantity")) && ((scheduleitem.GetAttributeValue<OptionSetValue>("niq_scheduletype").Value == 100000001 || scheduleitem.GetAttributeValue<OptionSetValue>("niq_scheduletype").Value == 100000002)))
                        {
                            customResearchBillingItem.ORDER_QTY = scheduleitem.GetAttributeValue<Money>("niq_amount").Value.ToString("F");
                            customResearchBillingItem.BILING_VALUE = "0.00";
                        }
                        else
                        {
                            customResearchBillingItem.BILING_VALUE = scheduleitem.GetAttributeValue<Money>("niq_amount").Value.ToString("F");
                            customResearchBillingItem.ORDER_QTY = "0.00";
                        }
                        customResearchItems.Add(customResearchBillingItem);
                        tracing.Trace("Custom Schedule added");
                    }
                }
            }
        }

        public static DateTime getNextBillingDate(DateTime effectiveDate, List<Entity> schedules)
        {

            var firstSchedule = schedules.Where(s => s.Contains("niq_scheduledate") && s.Contains("niq_scheduletype")).Where(s => ((DateTime)s["niq_scheduledate"]) > effectiveDate && ((OptionSetValue)s["niq_scheduletype"]).Value == 100000000).OrderBy(s => (DateTime)s["niq_scheduledate"]).FirstOrDefault();
            return firstSchedule.GetAttributeValue<DateTime>("niq_scheduledate");
        }

        // retreive Item Category base on Product and sales org
        public static Entity getItemCatecoryGroupMetadata(IOrganizationService service, string pricelistId)
        {
            Entity pricelevel = service.Retrieve("productpricelevel", new Guid(pricelistId), new ColumnSet("niq_itemcategorygroup"));
            string itemGroupFetchXML = $@"<fetch top='1'>
                                         <entity name='niq_itemcategorygroupmetadata'>
                                          <attribute name='niq_itemcategorygroupmetadataid' />
                                          <attribute name='niq_orderquantity' />
                                                <attribute name='niq_targetquantity' />
                                          <attribute name='niq_schedulelinedate' />
                                          <attribute name='niq_recurrent' />
                                          <attribute name='niq_fixedrate' />
                                                <attribute name='niq_materialgroup4' />
                                                <attribute name='niq_deliveryfrequency' />
                                          <filter type='and'>
                                           <condition attribute='niq_itemcategorygroup' operator='eq' value='{pricelevel.GetAttributeValue<OptionSetValue>("niq_itemcategorygroup").Value}' />
                                          </filter>
                                         </entity>
                                        </fetch>";
            EntityCollection ItemCategoryGroupMetadata = service.RetrieveMultiple(new FetchExpression(itemGroupFetchXML));
            return ItemCategoryGroupMetadata.Entities.First();
        }

        // check if product is periodic in Item category configuration
        public static bool IsPeriodicinItemCategoryGroupMetadata(Entity addedProduct, IOrganizationService service)
        {
            try
            {
                Entity itemCategoryGroupMetadata = getItemCatecoryGroupMetadata(service, addedProduct.GetAttributeValue<string>("niq_pricelistitem"));
                if (itemCategoryGroupMetadata.GetAttributeValue<string>("niq_recurrent").ToLower() == "periodic")
                    return true;
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public static bool IsRequiredinItemCategoryGroupMetadata(Entity itemCategoryGroupMetadata, string fieldname)
        {
            try
            {
                if (Convert.ToBoolean(itemCategoryGroupMetadata[fieldname]))
                {
                    return true;
                }
                else
                {
                    return false;

                }
            }
            catch
            {
                return false;
            }

        }

        public static List<Entity> getSchedulesToDelete(IOrganizationService service, Entity itemCatecoryGroupMetadata, Entity product, ITracingService tracing, DateTime startDate)
        {
            try
            {
                string fetchXML = "";
                tracing.Trace("Getting schedules for product: " + product.Id);
                tracing.Trace("scheduels item category: : " + itemCatecoryGroupMetadata.Id);
                if (IsRequiredinItemCategoryGroupMetadata(itemCatecoryGroupMetadata, "niq_schedulelinedate") || IsRequiredinItemCategoryGroupMetadata(itemCatecoryGroupMetadata, "niq_orderquantity"))
                {
                    tracing.Trace("inside if condition of getSchedules FN!!");
                    fetchXML = $@"<fetch>
	                            <entity name='niq_schedule'>
		                            <attribute name='niq_scheduleid' />
		                            <attribute name='niq_amount' />
		                            <attribute name='niq_scheduledate' />
		                            <attribute name='niq_scheduletype' />
                                    <order attribute='niq_scheduledate' />
		                            <filter type='and'>
			                            <condition attribute='niq_lineitemid' operator='eq' value='{product.Id}' />
                                        <condition attribute='niq_scheduledate' operator='ge' value='{startDate}' />
		                            </filter>
	                            </entity>
                            </fetch>";
                }
                else
                {
                    tracing.Trace("Inside else condirtion of getSchedules condition");
                    fetchXML = $@"<fetch>
	                            <entity name='niq_schedule'>
		                            <attribute name='niq_scheduleid' />
		                            <attribute name='niq_amount' />
		                            <attribute name='niq_scheduledate' />
		                            <attribute name='niq_scheduletype' />
                                    <order attribute='niq_scheduledate' />
		                            <filter type='and'>
			                            <condition attribute='niq_lineitemid' operator='eq' value='{product.Id}' />
			                            <condition attribute='niq_scheduletype' operator='eq' value='100000000' />  
                                        <condition attribute='niq_scheduledate' operator='ge' value='{startDate}' />
		                            </filter>
	                            </entity>
                            </fetch>";
                }
                List<Entity> schedules = service.RetrieveMultiple(new FetchExpression(fetchXML)).Entities.ToList();
                tracing.Trace("SCHEDULES COUNT: " + schedules.Count());
                return schedules;
            }
            catch
            {
                return null;
            }
        }

        // get schedules for the quote product
        public static List<Entity> getSchedules(IOrganizationService service, Entity itemCatecoryGroupMetadata, Entity product, ITracingService tracing)
        {
            try
            {
                string fetchXML = "";
                tracing.Trace("Getting schedules for product: " + product.Id);
                tracing.Trace("scheduels item category: : " + itemCatecoryGroupMetadata.Id);
                if (IsRequiredinItemCategoryGroupMetadata(itemCatecoryGroupMetadata, "niq_schedulelinedate") || IsRequiredinItemCategoryGroupMetadata(itemCatecoryGroupMetadata, "niq_orderquantity"))
                {
                    tracing.Trace("inside if condition of getSchedules FN!!");
                    fetchXML = $@"<fetch>
	                            <entity name='niq_schedule'>
		                            <attribute name='niq_scheduleid' />
		                            <attribute name='niq_amount' />
		                            <attribute name='niq_scheduledate' />
		                            <attribute name='niq_scheduletype' />
                                    <order attribute='niq_scheduledate' />
		                            <filter type='and'>
			                            <condition attribute='niq_lineitemid' operator='eq' value='{product.Id}' />
		                            </filter>
	                            </entity>
                            </fetch>";
                }
                else
                {
                    tracing.Trace("Inside else condirtion of getSchedules condition");
                    fetchXML = $@"<fetch>
	                            <entity name='niq_schedule'>
		                            <attribute name='niq_scheduleid' />
		                            <attribute name='niq_amount' />
		                            <attribute name='niq_scheduledate' />
		                            <attribute name='niq_scheduletype' />
                                    <order attribute='niq_scheduledate' />
		                            <filter type='and'>
			                            <condition attribute='niq_lineitemid' operator='eq' value='{product.Id}' />
			                            <condition attribute='niq_scheduletype' operator='eq' value='100000000' />
		                            </filter>
	                            </entity>
                            </fetch>";
                }
                List<Entity> schedules = service.RetrieveMultiple(new FetchExpression(fetchXML)).Entities.ToList();
                tracing.Trace("SCHEDULES COUNT: " + schedules.Count());
                return schedules;
            }
            catch
            {
                return null;
            }
        }

        public static string getMaterialDescription(IOrganizationService service, Guid productId)
        {
            return service.Retrieve("product", productId, new ColumnSet("description")).GetAttributeValue<string>("description");
        }

        public static string getMaterialGroup4(Entity Product, Entity ItemCategoryGroupMetadata)
        {
            //Material Group 4
            if (Product.GetAttributeValue<OptionSetValue>("niq_lagrevenuerecognition") != null && IsRequiredinItemCategoryGroupMetadata(ItemCategoryGroupMetadata, "niq_materialgroup4") == true)
            {
                if (Enum.IsDefined(typeof(ENUM.MATERIALGRP4), Product.GetAttributeValue<OptionSetValue>("niq_lagrevenuerecognition").Value) == true)
                {
                    return Enum.GetName(typeof(ENUM.MATERIALGRP4), Product.GetAttributeValue<OptionSetValue>("niq_lagrevenuerecognition").Value).ToString().Replace("enum_", "");
                }
            }
            return null;
        }

        //check Term Type 
        public static string getMaterialGroup5(Entity Quote)
        {
            OptionSetValue termtype;
            if (Quote.GetAttributeValue<OptionSetValue>("niq_termtype").Value == 100000002 || Quote.GetAttributeValue<OptionSetValue>("niq_termtype").Value == 100000003)
            {
                termtype = new OptionSetValue(100000000);
            }
            else
            {
                termtype = Quote.GetAttributeValue<OptionSetValue>("niq_termtype");
            }
            if (Enum.IsDefined(typeof(ENUM.MATERIALGRP5), termtype.Value))
            {
                return Enum.GetName(typeof(ENUM.MATERIALGRP5), termtype.Value).ToString().Replace("enum_", "");
            }
            return null;
        }
        // get delivery frequency for the product
        public static string getDeliveryFrequency(Entity Product, Entity ItemCategoryGroupMetadata)
        {
            if (Product.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency") != null && IsRequiredinItemCategoryGroupMetadata(ItemCategoryGroupMetadata, "niq_deliveryfrequency") == true)
            {
                int valDelFrqValue = Product.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency").Value;
                if (valDelFrqValue == 100000006 || valDelFrqValue == 100000007 || valDelFrqValue == 100000008)
                    valDelFrqValue = 100000000;
                if (Enum.IsDefined(typeof(ENUM.DELIVERY_FREQUENCY), valDelFrqValue))
                {
                    return Enum.GetName(typeof(ENUM.DELIVERY_FREQUENCY), Product.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency").Value).ToString().Replace("enum_", "");
                }
            }
            return null;
        }

        public static string getPricingCondition(Entity salesDocTypeMetadata)
        {
            if (salesDocTypeMetadata != null && salesDocTypeMetadata.Attributes.Contains("niq_pricingconditiontype"))
                return salesDocTypeMetadata.GetAttributeValue<string>("niq_pricingconditiontype");
            else
                return "ZNPR";
        }
        // get Rate of the Product based on item category
        public static string GetRate(Entity Product, Entity itemCategoryGroupMetadata, IOrganizationService service, ITracingService tracing)
        {
            try
            {
                string strRate = "";
                tracing.Trace("RATE FOR PRODUCT ::" + Product.GetAttributeValue<string>("niq_contractproductname"));
                if (IsPeriodicinItemCategoryGroupMetadata(Product, service) == true)
                {
                    strRate = GetRateforPeriodicSchedule(itemCategoryGroupMetadata, Product, service, tracing);
                    tracing.Trace("IF RATE: " + strRate);
                }
                else if (itemCategoryGroupMetadata.Attributes.Contains("niq_fixedrate") && itemCategoryGroupMetadata.GetAttributeValue<string>("niq_fixedrate") != null)
                {
                    tracing.Trace("ENTERING ELSE IF OF RATE FN");
                    if (Product.GetAttributeValue<Money>("extendedamount").Value < 0)
                        strRate = "-" + (itemCategoryGroupMetadata["niq_fixedrate"].ToString().Trim());
                    else
                        strRate = itemCategoryGroupMetadata["niq_fixedrate"].ToString().Trim();
                    tracing.Trace("ELSE IF RATE: " + strRate);
                }
                else
                    strRate = Product.GetAttributeValue<Money>("extendedamount").Value.ToString("F");

                if (strRate.Length > 0)
                    return strRate;
                return null;
            }
            catch
            {
                tracing.Trace("CATCH BLOCK OF GETRATE FN!!");
                return null;
            }

        }

        public static string GetRateforPeriodicSchedule(Entity itemCategoryGroupMetadata, Entity product, IOrganizationService service, ITracingService tracing)
        {
            try
            {
                var jobjSchedules = CommonHelper.getSchedules(service, itemCategoryGroupMetadata, product, tracing);
                if (jobjSchedules != null)
                {
                    if (jobjSchedules.Count == 1 || jobjSchedules.Count == 2)
                        return jobjSchedules[jobjSchedules.Count - 1].GetAttributeValue<Money>("niq_amount").Value.ToString();
                    else
                        return jobjSchedules[jobjSchedules.Count - 2].GetAttributeValue<Money>("niq_amount").Value.ToString();
                }
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static Entity getOpportunity(IOrganizationService service, Guid opportunityID)
        {
            return service.Retrieve("opportunity", opportunityID, new ColumnSet(true));
        }

        public static Entity getQuote(IOrganizationService service, Guid quoteId)
        {
            return service.Retrieve("quote", quoteId, new ColumnSet(true));
        }

        public static List<Entity> GetQuoteProduct(IOrganizationService service, Entity MainQuote)
        {
            Guid PriceListId = getPriceListId(MainQuote, service);
            QueryExpression query = new QueryExpression("quotedetail")
            {
                ColumnSet = new ColumnSet(true)
            };
            query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, MainQuote.Id);
            query.Criteria.AddCondition("niq_isrevshareline", ConditionOperator.Equal, false);
            query.Criteria.AddCondition("productname", ConditionOperator.NotEqual, "SAP Deferred Revenue reconciliation placeholder");
            query.Criteria.AddCondition("quantity", ConditionOperator.GreaterThan, 0);
            query.Criteria.AddCondition("extendedamount", ConditionOperator.NotEqual, 0);
            LinkEntity productPriceLink = new LinkEntity("quotedetail", "productpricelevel", "productid", "productid", JoinOperator.Inner);
            productPriceLink.LinkCriteria.AddCondition("pricelevelid", ConditionOperator.Equal, PriceListId);
            productPriceLink.LinkCriteria.AddCondition("niq_itemcategorygroup", ConditionOperator.NotEqual, 100000002);

            // Attach Link Entity to Query
            query.LinkEntities.Add(productPriceLink);
            return service.RetrieveMultiple(query).Entities.ToList();
        }

        public static List<Entity> GetRevShareQuoteProduct(IOrganizationService service, Guid MainQuote)
        {
            QueryExpression query = new QueryExpression("quotedetail")
            {
                ColumnSet = new ColumnSet(true)
            };
            query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, MainQuote);
            query.Criteria.AddCondition("niq_isrevshareline", ConditionOperator.Equal, true);
            return service.RetrieveMultiple(query).Entities.ToList();
        }

        public static List<Entity> GetAllQuoteProduct(IOrganizationService service, Entity MainQuote)
        {
            QueryExpression query = new QueryExpression("quotedetail")
            {
                ColumnSet = new ColumnSet(true)
            };
            query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, MainQuote.Id);
            return service.RetrieveMultiple(query).Entities.ToList();
        }

        public static Guid getPriceListId(Entity MainQuote, IOrganizationService service)
        {
            string fetchXMl = $@"<fetch top='1'>
	                            <entity name='pricelevel'>
		                            <attribute name='pricelevelid' />
		                            <filter type='and'>
			                            <condition attribute='niq_salesorg' operator='eq' value='{MainQuote.GetAttributeValue<EntityReference>("niq_salesorgid").Id}' />
		                            </filter>
	                            </entity>
                            </fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchXMl)).Entities.First().Id;
        }
        public static Entity GetSalesDocTypeMetadata(IOrganizationService service, Entity Opportunity)
        {
            Guid SalesOrgId = Opportunity.GetAttributeValue<EntityReference>("niq_salesorgid").Id;
            string fetchXml = $@"<fetch>
	                            <entity name='niq_salesdoctypemetadata'>
		                            <attribute name='niq_salesdoctypemetadataid' />
		                            <attribute name='niq_pricingconditiontype' />
		                            <attribute name='niq_country' />
		                            <filter type='and'>
			                            <condition attribute='niq_salesorg' operator='eq' value='{SalesOrgId}' />
		                            </filter>
	                            </entity>
                            </fetch>";
            List<Entity> SalesDocMetaData = service.RetrieveMultiple(new FetchExpression(fetchXml)).Entities.ToList();
            if (SalesDocMetaData.Count() > 0)
            {
                if (Opportunity.GetAttributeValue<EntityReference>("niq_soldtoparty") != null)
                {
                    Entity SoldTo = service.Retrieve("account", Opportunity.GetAttributeValue<EntityReference>("niq_soldtoparty").Id, new ColumnSet("niq_countryid"));
                    if (SoldTo.GetAttributeValue<EntityReference>("niq_countryid") != null)
                    {
                        Guid SoldToCountryId = SoldTo.GetAttributeValue<EntityReference>("niq_countryid").Id;
                        foreach (Entity item in SalesDocMetaData)
                        {
                            if (item.GetAttributeValue<EntityReference>("niq_country") != null)
                            {
                                Guid salesDocCountryID = item.GetAttributeValue<EntityReference>("niq_country").Id;
                                if (salesDocCountryID == SoldToCountryId)
                                    return item;
                            }
                        }
                    }
                }
                return SalesDocMetaData.Where(salesdoc => salesdoc.Contains("niq_country") == false || (salesdoc.Contains("niq_country") && salesdoc["niq_country"] == null)).First();
            }
            else
                return null;
        }

        // Initialize Array Object for the Payload
        public static void initializeArrayObjects(CONTRACTHEADER header)
        {
            header.CONTRACT_LINE_ITEMS = new CONTRACTLINEITEMS();
            header.CONTRACT_LINE_ITEM_BILLING = new CONTRACTLINEITEMSBILLING();
        }
        // Create Header Partner node of payload
        public static void createHeaderPartnerFunction(CONTRACTHEADER header, Entity Opportunity, IOrganizationService service, Entity OldOpportunity, ITracingService tracing)
        {
            try
            {
                var HeaderPartnerDetails = getHeaderPartnerDetails(service, Opportunity.Id);
                var OldOpportuniyDetails = getHeaderPartnerDetails(service, OldOpportunity.Id);
                tracing.Trace("NEW ID: " + HeaderPartnerDetails.Id);
                tracing.Trace("OLD ID: " + OldOpportuniyDetails.Id);
                header.HEADER_PARTNER_FUNCTIONS = new HEADERPARTNERFUNCTIONS();
                if (HeaderPartnerDetails.Attributes.Contains("niq_soldtoparty") && HeaderPartnerDetails.GetAttributeValue<EntityReference>("niq_soldtoparty") != null)
                {
                    header.HEADER_PARTNER_FUNCTIONS.SOLD_TO_PARTY = new SOLDTOPARTY();
                    header.HEADER_PARTNER_FUNCTIONS.SOLD_TO_PARTY.VALUE = "AG";
                    header.HEADER_PARTNER_FUNCTIONS.SOLD_TO_PARTY.CUSTOMER_NUMBER = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_soldtoparty.niq_sap_id__c").Value.ToString();
                }
                if (HeaderPartnerDetails.Attributes.Contains("niq_deliverytoparty") && HeaderPartnerDetails.GetAttributeValue<EntityReference>("niq_deliverytoparty") != null)
                {
                    header.HEADER_PARTNER_FUNCTIONS.SHIP_TO_PARTY = new SHIPTOPARTY();
                    header.HEADER_PARTNER_FUNCTIONS.SHIP_TO_PARTY.VALUE = "WE";
                    header.HEADER_PARTNER_FUNCTIONS.SHIP_TO_PARTY.CUSTOMER_NUMBER = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_deliverytoparty.niq_sap_id__c").Value.ToString();
                }
                if (HeaderPartnerDetails.Attributes.Contains("niq_billtoparty") && HeaderPartnerDetails.GetAttributeValue<EntityReference>("niq_billtoparty") != null)
                {
                    header.HEADER_PARTNER_FUNCTIONS.BILL_TO_PARTY = new BILLTOPARTY();
                    header.HEADER_PARTNER_FUNCTIONS.BILL_TO_PARTY.VALUE = "RE";
                    header.HEADER_PARTNER_FUNCTIONS.BILL_TO_PARTY.CUSTOMER_NUMBER = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_billtoparty.niq_sap_id__c").Value.ToString();
                }
                if (HeaderPartnerDetails.GetAttributeValue<AliasedValue>("ownerid.niq_employeenumber") != null && HeaderPartnerDetails.GetAttributeValue<AliasedValue>("ownerid.niq_employeenumber").Value != null)
                {
                    tracing.Trace("POSALES EMP");
                    var newValue = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("ownerid.niq_employeenumber").Value.ToString();
                    string oldValue = null;
                    if (OldOpportuniyDetails.GetAttributeValue<AliasedValue>("ownerid.niq_employeenumber") != null)
                        oldValue = OldOpportuniyDetails.GetAttributeValue<AliasedValue>("ownerid.niq_employeenumber").Value.ToString();
                    if (newValue != oldValue)
                    {
                        header.HEADER_PARTNER_FUNCTIONS.POSALES_EMPLOYEE = new POSALESEMPLOYEE();
                        header.HEADER_PARTNER_FUNCTIONS.POSALES_EMPLOYEE.VALUE = "P0";
                        header.HEADER_PARTNER_FUNCTIONS.POSALES_EMPLOYEE.CUSTOMER_NUMBER = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("ownerid.niq_employeenumber").Value.ToString();
                    }
                }
                if (HeaderPartnerDetails.Attributes.Contains("parentcontactid") && HeaderPartnerDetails.GetAttributeValue<EntityReference>("parentcontactid") != null && HeaderPartnerDetails.GetAttributeValue<AliasedValue>("parentcontactid.niq_sapid").Value != null)
                {
                    tracing.Trace("INVOICE_RECIPIPENT EMP");
                    var newValue = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("parentcontactid.niq_sapid").Value.ToString();
                    string oldValue = null;
                    if (OldOpportuniyDetails.GetAttributeValue<AliasedValue>("parentcontactid.niq_sapid") != null)
                        oldValue = OldOpportuniyDetails.GetAttributeValue<AliasedValue>("parentcontactid.niq_sapid").Value.ToString();
                    if (newValue != oldValue)
                    {
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT = new INVOICERECIPIPENT();
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT.VALUE = "ZI";
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT.CUSTOMER_NUMBER = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("parentcontactid.niq_sapid").Value.ToString();
                    }
                }
                if (HeaderPartnerDetails.Attributes.Contains("niq_nameoninvoiceifdifffrominvoicerecipient") && HeaderPartnerDetails.GetAttributeValue<EntityReference>("niq_nameoninvoiceifdifffrominvoicerecipient") != null && HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_nameoninvoiceifdifffrominvoicerecipient.niq_sapid").Value != null)
                {
                    tracing.Trace("INVOICE_RECIPIPENT1 EMP");
                    var newValue = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_nameoninvoiceifdifffrominvoicerecipient.niq_sapid").Value.ToString();
                    string oldValue = null;
                    tracing.Trace("Old NAME ON INVOICE: " + (OldOpportuniyDetails.GetAttributeValue<AliasedValue>("niq_nameoninvoiceifdifffrominvoicerecipient.niq_sapid") != null).ToString());
                    if (OldOpportuniyDetails.GetAttributeValue<AliasedValue>("niq_nameoninvoiceifdifffrominvoicerecipient.niq_sapid") != null)
                        oldValue = OldOpportuniyDetails.GetAttributeValue<AliasedValue>("niq_nameoninvoiceifdifffrominvoicerecipient.niq_sapid").Value.ToString();
                    if (newValue != oldValue)
                    {
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT1 = new INVOICERECIPIPENT();
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT1.VALUE = "Z1";
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT1.CUSTOMER_NUMBER = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_nameoninvoiceifdifffrominvoicerecipient.niq_sapid").Value.ToString();
                    }
                }
                if (HeaderPartnerDetails.Attributes.Contains("niq_invoicerecipient2") && HeaderPartnerDetails.GetAttributeValue<EntityReference>("niq_invoicerecipient2") != null && HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient2.niq_sapid").Value != null)
                {
                    tracing.Trace("INVOICE_RECIPIPENT2 EMP");
                    var newValue = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient2.niq_sapid").Value.ToString();
                    string oldValue = null;
                    if (OldOpportuniyDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient2.niq_sapid") != null)
                        oldValue = OldOpportuniyDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient2.niq_sapid").Value.ToString();
                    if (newValue != oldValue)
                    {
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT2 = new INVOICERECIPIPENT();
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT2.VALUE = "Z2";
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT2.CUSTOMER_NUMBER = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient2.niq_sapid").Value.ToString();
                    }
                }
                if (HeaderPartnerDetails.Attributes.Contains("niq_invoicerecipient3") && HeaderPartnerDetails.GetAttributeValue<EntityReference>("niq_invoicerecipient3") != null && HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient3.niq_sapid").Value != null)
                {
                    tracing.Trace("INVOICE_RECIPIPENT3 EMP");
                    tracing.Trace("NEW VALUE: ");

                    var newValue = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient3.niq_sapid").Value.ToString();
                    tracing.Trace("NEW VALUE: " + newValue);
                    string oldValue = null;
                    if (OldOpportuniyDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient3.niq_sapid") != null)
                        oldValue = OldOpportuniyDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient3.niq_sapid").Value.ToString();
                    if (newValue != oldValue)
                    {
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT3 = new INVOICERECIPIPENT();
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT3.VALUE = "Z3";
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT3.CUSTOMER_NUMBER = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient3.niq_sapid").Value.ToString();
                    }
                }
                if (HeaderPartnerDetails.Attributes.Contains("niq_invoicerecipient4") && HeaderPartnerDetails.GetAttributeValue<EntityReference>("niq_invoicerecipient4") != null && HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient4.niq_sapid").Value != null)
                {
                    tracing.Trace("INVOICE_RECIPIPENT4 EMP");
                    var newValue = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient4.niq_sapid").Value.ToString();
                    string oldValue = null;
                    if (OldOpportuniyDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient4.niq_sapid") != null)
                        oldValue = OldOpportuniyDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient4.niq_sapid").Value.ToString();
                    if (newValue != oldValue)
                    {
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT4 = new INVOICERECIPIPENT();
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT4.VALUE = "Z4";
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT4.CUSTOMER_NUMBER = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient4.niq_sapid").Value.ToString();
                    }
                }
                if (HeaderPartnerDetails.Attributes.Contains("niq_invoicerecipient5") && HeaderPartnerDetails.GetAttributeValue<EntityReference>("niq_invoicerecipient5") != null && HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient5.niq_sapid").Value != null)
                {
                    tracing.Trace("INVOICE_RECIPIPENT5 EMP");
                    var newValue = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient5.niq_sapid").Value.ToString();
                    string oldValue = null;
                    tracing.Trace("newvalue " + newValue);
                    if (OldOpportuniyDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient5.niq_sapid") != null)
                        oldValue = OldOpportuniyDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient5.niq_sapid").Value.ToString();
                    tracing.Trace("old VAlue : " + oldValue);
                    if (newValue != oldValue)
                    {
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT5 = new INVOICERECIPIPENT();
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT5.VALUE = "Z5";
                        header.HEADER_PARTNER_FUNCTIONS.INVOICE_RECIPIPENT5.CUSTOMER_NUMBER = HeaderPartnerDetails.GetAttributeValue<AliasedValue>("niq_invoicerecipient5.niq_sapid").Value.ToString();
                    }
                }
            }
            catch
            {
                tracing.Trace("CATCH BLOCK OF HEADER PARTNER FUNCTION!");
            }

        }

        public static Entity getHeaderPartnerDetails(IOrganizationService service, Guid OpportunityId)
        {
            string fetchXML = $@"<fetch top='1'>
                                    <entity name='opportunity'>
                                        <attribute name='niq_deliverytoparty' />
                                        <attribute name='niq_billtoparty' />
                                        <attribute name='niq_soldtoparty' />
                                        <attribute name='niq_invoicerecipient5' />
                                        <attribute name='niq_invoicerecipient4' />
                                        <attribute name='niq_invoicerecipient3' />
                                        <attribute name='niq_invoicerecipient2' />
                                        <attribute name='niq_nameoninvoiceifdifffrominvoicerecipient' />
                                        <attribute name='parentcontactid' />
                                        <attribute name='ownerid' />

                                        <filter type='and'>
                                            <condition attribute='opportunityid' operator='eq' value='{OpportunityId}' />
                                        </filter>
                                        <link-entity name='account' from='accountid' to='niq_deliverytoparty' alias='niq_deliverytoparty' link-type='outer'>
                                            <attribute name='niq_sap_id__c' />
                                        </link-entity>
                                        <link-entity name='account' from='accountid' to='niq_billtoparty' alias='niq_billtoparty' link-type='outer'>
                                            <attribute name='niq_sap_id__c' />
                                        </link-entity>
                                        <link-entity name='account' from='accountid' to='niq_soldtoparty' alias='niq_soldtoparty' link-type='outer'>
                                            <attribute name='niq_sap_id__c' />
                                        </link-entity>
                                        <link-entity name='systemuser' from='systemuserid' to='ownerid' alias='ownerid' link-type='outer'>
	                                        <attribute name='niq_employeenumber' />
                                        </link-entity>
                                        <link-entity name='contact' from='contactid' to='parentcontactid' alias='parentcontactid' link-type='outer'>
	                                        <attribute name='niq_sapid' />
                                        </link-entity>
                                        <link-entity name='contact' from='contactid' to='niq_nameoninvoiceifdifffrominvoicerecipient' alias='niq_nameoninvoiceifdifffrominvoicerecipient' link-type='outer'>
	                                        <attribute name='niq_sapid' />
                                        </link-entity>
                                        <link-entity name='contact' from='contactid' to='niq_invoicerecipient2' alias='niq_invoicerecipient2' link-type='outer'>
	                                        <attribute name='niq_sapid' />
                                        </link-entity>
                                        <link-entity name='contact' from='contactid' to='niq_invoicerecipient3' alias='niq_invoicerecipient3' link-type='outer'>
	                                        <attribute name='niq_sapid' />
                                        </link-entity>
                                        <link-entity name='contact' from='contactid' to='niq_invoicerecipient4' alias='niq_invoicerecipient4' link-type='outer'>
	                                        <attribute name='niq_sapid' />
                                        </link-entity>
                                        <link-entity name='contact' from='contactid' to='niq_invoicerecipient5' alias='niq_invoicerecipient5' link-type='outer'>
	                                        <attribute name='niq_sapid' />
                                        </link-entity>
                                    </entity>
                                </fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchXML)).Entities.First();
        }

        // Get Billing Frequency of the product
        public static string GetBillingFrequency(Entity addedProduct, IOrganizationService service)
        {
            try
            {
                var enumBillingFrqVal = "";
                if (addedProduct.Attributes.Contains("niq_billingfrequency") && addedProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value != null && IsPeriodicinItemCategoryGroupMetadata(addedProduct, service) == true)
                {
                    int valOptionsetVal = addedProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value;
                    if (valOptionsetVal == 100000006) valOptionsetVal = 100000000;
                    else if (valOptionsetVal == 100000007) valOptionsetVal = 100000001;
                    else if (valOptionsetVal == 100000008) valOptionsetVal = 100000002;
                    if (Enum.IsDefined(typeof(ENUM.BILLING_FREQUENCY), valOptionsetVal))
                    {
                        enumBillingFrqVal = ((ENUM.BILLING_FREQUENCY)valOptionsetVal).ToString().Replace("enum_", "");
                        return Enum.GetName(typeof(ENUM.BILLING_FREQUENCY), valOptionsetVal).ToString().Replace("enum_", "");
                    }
                }
                return null;
            }
            catch
            {
                return null;
            }
        }
        public static string getLineItemNumberForSap(int Count)
        {
            if (Count < 10)
                return String.Concat("0000", Count.ToString(), "0");
            else if (Count < 100)
                return String.Concat("000", Count.ToString(), "0");
            else if (Count < 1000)
                return String.Concat("00", Count.ToString(), "0");
            else if (Count < 10000)
                return String.Concat("0", Count.ToString(), "0");
            else
                return String.Concat(Count.ToString(), "0");
        }
        public static void getLineItemText(List<Entity> NewOppQuoteProducts, CONTRACTHEADER header, Entity opportunity, ITracingService tracing, IOrganizationService service)
        {
            tracing.Trace("Total products for Line Item Text: "+ NewOppQuoteProducts.Count);
            header.LINE_ITEM_TEXT = new LINEITEMTEXT();
            string billingInstruction = opportunity.GetAttributeValue<string>("niq_billinginstructions");
            string opportunityNumber = opportunity.GetAttributeValue<string>("niq_opportunitynumber");
            string freetext = string.Empty;
            header.LINE_ITEM_TEXT.item = new List<Item>();
            if (billingInstruction != null && billingInstruction.Length > 0)
            {
                Item item = new Item();
                item.LINE_ITEM_NUMBER = opportunityNumber;
                item.SALES_DOC_ITEM = "00000";
                item.SAPFREE_TEXT_ID = "0001";
                item.LANGUAGE_KEY = "E";
                item.FREE_TEXT = SecurityElement.Escape(billingInstruction);
                if (!string.IsNullOrEmpty(item.FREE_TEXT))
                {
                    header.LINE_ITEM_TEXT.item.Add(item);
                }
            }
            tracing.Trace("sap 00 line item mapped");
            foreach (Entity product in NewOppQuoteProducts)
            {
                freetext = "";
                tracing.Trace("LINE ITEM TEXT FOR : "+product.GetAttributeValue<string>("niq_contractproductname"));
                Item item = new Item();
                item.LINE_ITEM_NUMBER = opportunityNumber;
                item.SALES_DOC_ITEM = service.Retrieve(product.LogicalName, product.Id, new ColumnSet("niq_lineitemnumberforsap")).GetAttributeValue<string>("niq_lineitemnumberforsap");
                item.SAPFREE_TEXT_ID = "Z03";
                item.LANGUAGE_KEY = "E";
                if (product.GetAttributeValue<string>("niq_invoicetext") != null && product.GetAttributeValue<string>("niq_invoicetext").Length > 0)
                    freetext = product.GetAttributeValue<string>("niq_invoicetext");
                if (freetext.Length > 0)
                    item.FREE_TEXT = SecurityElement.Escape(freetext);
                if(!string.IsNullOrEmpty(item.FREE_TEXT))
                {
                    header.LINE_ITEM_TEXT.item.Add(item);
                }
            }
        }
    }
}
