﻿using FakeXrmEasy;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace NIQ.D365.Int.Custom.UnitTest
{
    [TestClass]
    public class UtilityTest
    {
       
        public static XrmRealContext GetXrmRealContext()
        {
            string strConnectionString = ConfigurationManager.AppSettings["CRMConnection"];

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            CrmServiceClient con = new CrmServiceClient(strConnectionString);
            IOrganizationService service;
            if (con.OrganizationWebProxyClient != null)
                service = con.OrganizationWebProxyClient;
            else
                service = con.OrganizationServiceProxy;

            var fakedContext = new XrmRealContext(service);
        
            Guid orgid = ((WhoAmIResponse)service.Execute(new WhoAmIRequest())).OrganizationId;
            return fakedContext;
        }

    }
}
