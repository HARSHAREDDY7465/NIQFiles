﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FakeXrmEasy;
using System.IO;
using System.Collections.Generic;
using NIQ.D365.Int.Custom.WF;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Data;
using Microsoft.Crm.Sdk.Messages;
using System.Text.Json;
using Microsoft.Xrm.Sdk;

namespace NIQ.D365.Int.Custom.UnitTest
{
    [TestClass]
    public class WorkflowActivityTest
    {
        [TestMethod]
        public void ExecuteGetSAPContractPayloadTest()
        {
            var fakedContext = UtilityTest.GetXrmRealContext();

            var strOptyNQuotePayload = File.ReadAllText(@"..\..\SAPContractSamples\OptyNQuotePayload.json");
            var strQuoteDetailPayload = File.ReadAllText(@"..\..\SAPContractSamples\QuoteDetailPayload.json");
            var strItemCategoryGrpMtDtPayload = File.ReadAllText(@"..\..\SAPContractSamples\ItemCategoryGrpMtDtPayload.json");
            var strQuoteDetailCharPayload = File.ReadAllText(@"..\..\SAPContractSamples\QuoteDetailCharacteristicPayload.json");
            var strQuoteDetailSchedulePayload = File.ReadAllText(@"..\..\SAPContractSamples\QuoteDetailSchedulePayload.json");

            var inputs = new Dictionary<string, object>()
            {
                { "OpportunityId", "7b03a8d8-11df-4fdc-8f86-126fc06d3c6e" },
                { "QuoteNOptyPayload", strOptyNQuotePayload },
                { "QuoteDetailPayload", strQuoteDetailPayload },
                { "QuoteDetailCharPayload", strQuoteDetailCharPayload },
                { "ItemCategoryGrpMtDtPayload", strItemCategoryGrpMtDtPayload },
                { "QuoteDetailSchedulePayload", strQuoteDetailSchedulePayload }
            };
            var results = fakedContext.ExecuteCodeActivity<GetSAPContractPayload>(inputs, null);
        }


        [TestMethod]
        public void ExecuteGlobalCIOpportunityTest()
        {
            var fakedContext = UtilityTest.GetXrmRealContext();

            var inputs = new Dictionary<string, object>()
            {
                { "OpportunityNumber", "OP-000100244" },
               { "Brand", "CI" },
            };

            Guid userid = ((WhoAmIResponse)fakedContext.GetOrganizationService().Execute(new WhoAmIRequest())).UserId;
            XrmFakedWorkflowContext wfcontext = new XrmFakedWorkflowContext();
            wfcontext.InitiatingUserId = userid;
            var results = fakedContext.ExecuteCodeActivity<NIQ.D365.Int.Custom.WF.GlobalCIOpportunity>(wfcontext, inputs, null);

        }
        [TestMethod]
        public void RunAction_GlobalCICopportunity()
        {
            try
            {
                var fakedContext = UtilityTest.GetXrmRealContext();
                //Run Action
                IOrganizationService service = fakedContext.GetOrganizationService();

                OrganizationRequest orgreq = new OrganizationRequest("niq_GlobalCIOpportunity");
                orgreq["Opportunity_Number"] = "OP-000100034";

                OrganizationResponse orgRes = service.Execute(orgreq);

                var result = JsonDocument.Parse(orgRes["Result"].ToString());

            }
            catch (Exception ex)
            {
                string error = ex.Message;

            }

        }

        [TestMethod]
        public void ExecuteGlobalCIQuoteLineItemTest()
        {
            var fakedContext = UtilityTest.GetXrmRealContext();

            var inputs = new Dictionary<string, object>()
            {
                { "ProjectID", "SF1000985" }
            };

            Guid userid = ((WhoAmIResponse)fakedContext.GetOrganizationService().Execute(new WhoAmIRequest())).UserId;
            XrmFakedWorkflowContext wfcontext = new XrmFakedWorkflowContext();
            wfcontext.InitiatingUserId = userid;
            var results = fakedContext.ExecuteCodeActivity<NIQ.D365.Int.Custom.WF.GlobalCIQuoteLineItem>(wfcontext, inputs, null);
        }

        [TestMethod]
        public void ExecuteGlobalCIGinkgoOpportunityTest()
        {
            var fakedContext = UtilityTest.GetXrmRealContext();

            var inputs = new Dictionary<string, object>()
            {
                //{ "OpportunityNumber", "OP-000100034" },
                { "OpportunityNumber", "OP10000001" },
               { "Brand", "CI" },
            };

            Guid userid = ((WhoAmIResponse)fakedContext.GetOrganizationService().Execute(new WhoAmIRequest())).UserId;
            XrmFakedWorkflowContext wfcontext = new XrmFakedWorkflowContext();
            wfcontext.InitiatingUserId = userid;
            var results = fakedContext.ExecuteCodeActivity<NIQ.D365.Int.Custom.WF.GlobalCIGinkgoOpportunity>(wfcontext, inputs, null);

        }
        [TestMethod]
        public void ExecuteUpsertProductBySAP()
        {
            var fakedContext = UtilityTest.GetXrmRealContext();

            var inputs = new Dictionary<string, object>()
            {
                 { "ProductNumber", "CI-AD/PCK/PRD/CPT" },
               { "ProductName", "CI-AD/PCK/PRD/CPT-Name" },
                { "ProductStructure", "Product" },
                { "Active",true },
                { "CanUseQuantitySchedule",false },
                 { "CanUseRevenueSchedule",true },
                   { "Parent",@"CI\CI"}
            };
            XrmFakedWorkflowContext wfcontext = new XrmFakedWorkflowContext();
            var results = fakedContext.ExecuteCodeActivity<NIQ.D365.Int.Custom.WF.UpsertProductBySAP>(wfcontext, inputs, null);
        }
        [TestMethod]
        public void ExecuteUpsertSubBrandProductBySAP()
        {
            var fakedContext = UtilityTest.GetXrmRealContext();

            var inputs = new Dictionary<string, object>()
            {
                 { "ProductNumber", "CI-SB" },
               { "ProductName", "CI-SubBrandName" },
                { "ProductStructure", "SubBrand" },
                                   { "Parent",@"CI1"}
            };
            XrmFakedWorkflowContext wfcontext = new XrmFakedWorkflowContext();
            var results = fakedContext.ExecuteCodeActivity<NIQ.D365.Int.Custom.WF.UpsertProductBySAP>(wfcontext, inputs, null);

         
            //Run Action
            IOrganizationService service = fakedContext.GetOrganizationService();

            OrganizationRequest orgreq = new OrganizationRequest("niq_UpsertSubBrandProductBySAP");
            orgreq["SubBrandCode"] = "CI-SB";
            orgreq["SubBrandName"] = "CI-SubBrandName";
            orgreq["Brand"] = "CI1";
            OrganizationResponse orgRes = service.Execute(orgreq);

            var result = JsonDocument.Parse(orgRes["Result"].ToString());

        }


        [TestMethod]
        public void ExecuteUpsertPriceListItemsBySAP()
        {
            var fakedContext = UtilityTest.GetXrmRealContext();

            var inputs = new Dictionary<string, object>()
            {
                 { "PriceListItemId", "1200" },
               { "GLAccountNumber", "CI-AD/PCK/PRD/CPT-Name" },
                { "GLAccountName", "Product" },
                { "Blocked",true },
                { "ItemCategoryGroup",100000001 },
                 { "ProductNumber","CI-AD/PCK/PRD/<>CPT" },
                   { "ProfitCentreCode","0000002300"},
                   { "ProfitCentreName","Advanced Analytics"},
                   { "PriceListCode","0002"},
                   { "Amount",1250.50m}
            };
            XrmFakedWorkflowContext wfcontext = new XrmFakedWorkflowContext();
            var results = fakedContext.ExecuteCodeActivity<NIQ.D365.Int.Custom.WF.UpsertPriceListItemsBySAP>(wfcontext, inputs, null);
        }

        [TestMethod]
        public void ExecuteUpsertProductCharacteristicBySAP()
        {
            var fakedContext = UtilityTest.GetXrmRealContext();

            var inputs = new Dictionary<string, object>()
            {
                 { "Name", "Momo" },
               
                 { "ProductNumber","CI-AD/PCK/PRD/<>CPT" },
                   { "MaterialCharacteristic","1234"},
                  
            };
            XrmFakedWorkflowContext wfcontext = new XrmFakedWorkflowContext();
            var results = fakedContext.ExecuteCodeActivity<NIQ.D365.Int.Custom.WF.UpsertProductCharacteristicBySAP>(wfcontext, inputs, null);
        }
    }
}
