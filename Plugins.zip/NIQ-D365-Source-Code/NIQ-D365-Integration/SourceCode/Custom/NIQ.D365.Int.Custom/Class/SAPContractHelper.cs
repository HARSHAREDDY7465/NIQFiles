﻿using Microsoft.Xrm.Sdk;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace NIQ.D365.Int.Custom.Class
{
    public class SAPContractHelper
    {

        private ITracingService tracingService;
        private string strOrgName;
        private List<Entity> lstEntSalesDocTypeMetdata;
        private Entity entSalesDoctypemtdt;

        public SAPContractHelper(ITracingService tracingService, string strOrgName, List<Entity> lstEntSalesDocTypeMetdata)
        {
            this.tracingService = tracingService;
            this.strOrgName = strOrgName;
            this.lstEntSalesDocTypeMetdata = lstEntSalesDocTypeMetdata;
        }
        public string BuildSAPContractPayload(JObject jobjQuoteNOptyPayload, JObject jobjQuoteDetailPayload, JObject jobjItemCtgryGrpMtdtPayload, JObject jobjQuoteDetailCharPayload, JObject jobjQuoteDetailSchedulePayload, IOrganizationService service)
        {
            StringBuilder sbPayload = new StringBuilder();
            try
            {
                //GetSalesDocType recordbased on salesorgid and country code
                if (Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_soldtoparty"]).Trim().Length > 0)
                {
                    entSalesDoctypemtdt = this.GetSalesDocumentTypemetadata(Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_salesorgid"]["niq_salesorgid"]).Trim(),
                       Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_soldtoparty"]["_niq_countryid_value"])
                    );
                }
                else
                    entSalesDoctypemtdt = this.GetSalesDocumentTypemetadata(Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_salesorgid"]["niq_salesorgid"]).Trim(), "");

                sbPayload.Append("<ContractHeader>");
                sbPayload.Append(BuildContractHeader(jobjQuoteNOptyPayload, service)); // Contract Header

                var strheaderpartnerfunction = BuildHeaderPartnerFunction(jobjQuoteNOptyPayload); // HeaderPartnerfunction
                sbPayload.Append("<HeaderPartnerFunctions>" + strheaderpartnerfunction + "</HeaderPartnerFunctions>");
                sbPayload.Append(BuildHeaderBillingPlanDetail(jobjQuoteNOptyPayload)); // HeaderBillingPlanDetails
                sbPayload.Append(BuildItemPartnerFunctions(jobjQuoteNOptyPayload, jobjQuoteDetailPayload, strheaderpartnerfunction, jobjItemCtgryGrpMtdtPayload)); // ItemPartnerFunctions

                sbPayload.Append(this.BuildQuoteProductsforeach(jobjQuoteNOptyPayload, jobjQuoteDetailPayload, jobjQuoteDetailCharPayload, jobjQuoteDetailSchedulePayload));

                sbPayload.Append("</ContractHeader>");
                return sbPayload.ToString();
            }
            catch (Exception ex)
            {
                tracingService.Trace("BuildSAPContractPayload");
                throw ex;
            }
        }

        private string BuildContractHeader(JObject jobjQuoteNOptyPayload, IOrganizationService service)
        {
            StringBuilder sbcontractheader = new StringBuilder();
            try
            {
                sbcontractheader.Append("<ContractNumber></ContractNumber>");
                //SalesDocType

                if (entSalesDoctypemtdt != null && entSalesDoctypemtdt.Contains("niq_salesdocumenttype") &&
                    entSalesDoctypemtdt["niq_salesdocumenttype"].ToString().Trim().Length > 0)
                {
                    sbcontractheader.Append(string.Format("<SalesDocType>{0}</SalesDocType>", entSalesDoctypemtdt["niq_salesdocumenttype"].ToString().Trim()));
                }
                else if (Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_salesorgid"]["niq_salesdocumenttype"]).Trim().Length > 0)
                    sbcontractheader.Append(string.Format("<SalesDocType>{0}</SalesDocType>",
                                    jobjQuoteNOptyPayload["opportunityid"]["niq_salesorgid"]["niq_salesdocumenttype@OData.Community.Display.V1.FormattedValue"]));
                else
                    sbcontractheader.Append("<SalesDocType>ZM05</SalesDocType>");
                //SalesOrg
                sbcontractheader.Append(string.Format("<SalesOrg>{0}</SalesOrg>", Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_salesorgid"]["niq_salesorgcode"]).Trim()));
                sbcontractheader.Append("<DistributionChannel>10</DistributionChannel>");
                sbcontractheader.Append("<Division>10</Division>");
                sbcontractheader.Append(string.Format("<CustPONumber>{0}</CustPONumber>", SecurityElement.Escape(Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_customerponumber"]))));
                sbcontractheader.Append(string.Format("<CustPODate>{0}</CustPODate>", GetdateinddMMyyyy(Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_customerpodate"]))));
                sbcontractheader.Append(string.Format("<CollectiveNumber>{0}</CollectiveNumber>", this.strOrgName));

                if (jobjQuoteNOptyPayload["transactioncurrencyid"]["isocurrencycode"].ToString() == "CLF")
                    jobjQuoteNOptyPayload["transactioncurrencyid"]["isocurrencycode"] = "UF";

                sbcontractheader.Append(string.Format("<CurrencyCode>{0}</CurrencyCode>", jobjQuoteNOptyPayload["transactioncurrencyid"]["isocurrencycode"].ToString()));
                if (jobjQuoteNOptyPayload.ContainsKey("niq_contractstartdate"))
                    sbcontractheader.Append(string.Format("<AgreementDate>{0}</AgreementDate>", GetdateinddMMyyyy(Convert.ToString(jobjQuoteNOptyPayload["niq_contractstartdate"]))));

                if (jobjQuoteNOptyPayload["niq_parent_salesorg"]["niq_salesorgcode"] != null &&
                    (jobjQuoteNOptyPayload["niq_parent_salesorg"]["niq_salesorgcode"].ToString() == "3411" || jobjQuoteNOptyPayload["niq_parent_salesorg"]["niq_salesorgcode"].ToString() == "4411") &&
                    (jobjQuoteNOptyPayload["niq_host_revenuesharedeal"] != null && (bool)jobjQuoteNOptyPayload["niq_host_revenuesharedeal"]))
                {
                    sbcontractheader.Append("<BillingBlock>32</BillingBlock>");
                }
                else
                {
                    sbcontractheader.Append("<BillingBlock>02</BillingBlock>");
                }
                sbcontractheader.Append(string.Format("<OpportunityNumber>{0}</OpportunityNumber>", jobjQuoteNOptyPayload["opportunityid"]["opportunityid"].ToString()));
                sbcontractheader.Append(string.Format("<MSD_OpportunityNumber>{0}</MSD_OpportunityNumber>", jobjQuoteNOptyPayload["opportunityid"]["niq_opportunitynumber"].ToString()));
                sbcontractheader.Append(string.Format("<TermsOfPayKey>{0}</TermsOfPayKey>", jobjQuoteNOptyPayload["niq_paymenttermsid"]["niq_paymenttermcode"].ToString()));


                //logic is only applicable when revenue share deal is true
                if (jobjQuoteNOptyPayload["niq_host_revenuesharedeal"] != null && (bool)jobjQuoteNOptyPayload["niq_host_revenuesharedeal"])
                {
                    //child opportunity
                    if (!string.IsNullOrEmpty(jobjQuoteNOptyPayload["opportunityid"]["_niq_hostopportunity_value"].ToString()))
                    {
                        string salesOrgCode = Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_salesorgid"]["niq_salesorgcode"]).Trim();
                        string hostOppGuid = jobjQuoteNOptyPayload["opportunityid"]["_niq_hostopportunity_value"].ToString();
                        string hostOppNumber = service.Retrieve("opportunity", new Guid(hostOppGuid), new Microsoft.Xrm.Sdk.Query.ColumnSet("niq_opportunitynumber")).GetAttributeValue<string>("niq_opportunitynumber");
                        sbcontractheader.Append(string.Format("<ShipToRefNumber>{0}</ShipToRefNumber>", hostOppNumber + salesOrgCode));
                        sbcontractheader.Append(string.Format("<SoldToRefNumber>{0}</SoldToRefNumber>", hostOppNumber));
                    }
                    //parent opportunity
                    else
                    {
                        sbcontractheader.Append(string.Format("<ShipToRefNumber>{0}</ShipToRefNumber>", jobjQuoteNOptyPayload["opportunityid"]["niq_opportunitynumber"].ToString()));
                    }
                }

                return sbcontractheader.ToString();
            }
            catch (Exception ex)
            {
                tracingService.Trace("BuildContractHeader");
                throw ex;
            }
        }
        private string BuildHeaderPartnerFunction(JObject jobjQuoteNOptyPayload)
        {
            StringBuilder sbHeaderPartnerFunction = new StringBuilder();
            try
            {
                //SoldToParty
                if (Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_soldtoparty"]).Trim().Length > 0
                    &&
                    Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_soldtoparty"]["niq_sap_id__c"]).Trim().Length > 0
                    )
                {
                    sbHeaderPartnerFunction.Append(string.Format("<SoldToParty><Value>AG</Value>" +
                        "<CustomerNumber>{0}</CustomerNumber></SoldToParty>",
                         jobjQuoteNOptyPayload["opportunityid"]["niq_soldtoparty"]["niq_sap_id__c"].ToString().Trim()));
                }

                //ShipToParty or DeliveryToParty
                if (Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_deliverytoparty"]).Trim().Length > 0
                    &&
                    Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_deliverytoparty"]["niq_sap_id__c"]).Trim().Length > 0
                    )
                {
                    sbHeaderPartnerFunction.Append(string.Format("<ShipToParty><Value>WE</Value>" +
                        "<CustomerNumber>{0}</CustomerNumber></ShipToParty>",
                         jobjQuoteNOptyPayload["opportunityid"]["niq_deliverytoparty"]["niq_sap_id__c"].ToString().Trim()));
                }

                //BillToParty
                if (Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_billtoparty"]).Trim().Length > 0
                    &&
                    Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_billtoparty"]["niq_sap_id__c"]).Trim().Length > 0
                    )
                {
                    sbHeaderPartnerFunction.Append(string.Format("<BillToParty><Value>RE</Value>" +
                        "<CustomerNumber>{0}</CustomerNumber></BillToParty>",
                         jobjQuoteNOptyPayload["opportunityid"]["niq_billtoparty"]["niq_sap_id__c"].ToString().Trim()));
                }

                //POSalesEmployee OR Opportunity Owner
                if (Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["owninguser"]).Trim().Length > 0
                    &&
                    Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["owninguser"]["niq_employeenumber"]).Trim().Length > 0
                    )
                {
                    sbHeaderPartnerFunction.Append(string.Format("<POSalesEmployee><Value>P0</Value>" +
                        "<CustomerNumber>{0}</CustomerNumber></POSalesEmployee>",
                         jobjQuoteNOptyPayload["opportunityid"]["owninguser"]["niq_employeenumber"].ToString().Trim()));
                }

                //InvoiceRecipipent
                if (Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["parentcontactid"]).Trim().Length > 0
                    &&
                    Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["parentcontactid"]["niq_sapid"]).Trim().Length > 0
                    )
                {
                    sbHeaderPartnerFunction.Append(string.Format("<InvoiceRecipipent><Value>ZI</Value>" +
                        "<CustomerNumber>{0}</CustomerNumber></InvoiceRecipipent>",
                         jobjQuoteNOptyPayload["opportunityid"]["parentcontactid"]["niq_sapid"].ToString().Trim()));
                }

                //Name of Invoice 
                if (Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_nameoninvoiceifdifffrominvoicerecipient"]).Trim().Length > 0
                    &&
                    Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_nameoninvoiceifdifffrominvoicerecipient"]["niq_sapid"]).Trim().Length > 0
                    )
                {
                    sbHeaderPartnerFunction.Append(string.Format("<InvoiceRecipipent1><Value>Z1</Value>" +
                        "<CustomerNumber>{0}</CustomerNumber></InvoiceRecipipent1>",
                         jobjQuoteNOptyPayload["opportunityid"]["niq_nameoninvoiceifdifffrominvoicerecipient"]["niq_sapid"].ToString().Trim()));
                }

                //InvoiceRecipipent 2
                if (Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_invoicerecipient2"]).Trim().Length > 0
                    &&
                    Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_invoicerecipient2"]["niq_sapid"]).Trim().Length > 0
                    )
                {
                    sbHeaderPartnerFunction.Append(string.Format("<InvoiceRecipipent2><Value>Z2</Value>" +
                        "<CustomerNumber>{0}</CustomerNumber></InvoiceRecipipent2>",
                         jobjQuoteNOptyPayload["opportunityid"]["niq_invoicerecipient2"]["niq_sapid"].ToString().Trim()));
                }

                //InvoiceRecipipent 3
                if (Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_invoicerecipient3"]).Trim().Length > 0
                    &&
                    Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_invoicerecipient3"]["niq_sapid"]).Trim().Length > 0
                    )
                {
                    sbHeaderPartnerFunction.Append(string.Format("<InvoiceRecipipent3><Value>Z3</Value>" +
                        "<CustomerNumber>{0}</CustomerNumber></InvoiceRecipipent3>",
                         jobjQuoteNOptyPayload["opportunityid"]["niq_invoicerecipient3"]["niq_sapid"].ToString().Trim()));
                }

                //InvoiceRecipipent 4
                if (Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_invoicerecipient4"]).Trim().Length > 0
                    &&
                    Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_invoicerecipient4"]["niq_sapid"]).Trim().Length > 0
                    )
                {
                    sbHeaderPartnerFunction.Append(string.Format("<InvoiceRecipipent4><Value>Z4</Value>" +
                        "<CustomerNumber>{0}</CustomerNumber></InvoiceRecipipent4>",
                         jobjQuoteNOptyPayload["opportunityid"]["niq_invoicerecipient4"]["niq_sapid"].ToString().Trim()));
                }

                //InvoiceRecipipent 5
                if (Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_invoicerecipient5"]).Trim().Length > 0
                    &&
                    Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_invoicerecipient5"]["niq_sapid"]).Trim().Length > 0
                    )
                {
                    sbHeaderPartnerFunction.Append(string.Format("<InvoiceRecipipent5><Value>Z5</Value>" +
                        "<CustomerNumber>{0}</CustomerNumber></InvoiceRecipipent5>",
                         jobjQuoteNOptyPayload["opportunityid"]["niq_invoicerecipient5"]["niq_sapid"].ToString().Trim()));
                }



                return sbHeaderPartnerFunction.ToString();
            }
            catch (Exception ex)
            {
                tracingService.Trace("BuildHeaderPartnerFunction");
                throw ex;
            }
        }

        private string BuildHeaderBillingPlanDetail(JObject jobjQuoteNOptyPayload)
        {
            StringBuilder sbHeaderBillingPlanDetail = new StringBuilder();
            try
            {
                sbHeaderBillingPlanDetail.Append("<HeaderBillingPlanDetails>");
                sbHeaderBillingPlanDetail.Append(string.Format("<ContractRefNumber>{0}</ContractRefNumber>", jobjQuoteNOptyPayload["opportunityid"]["opportunityid"].ToString().Trim()));
                if (jobjQuoteNOptyPayload.ContainsKey("niq_contractstartdate"))
                    sbHeaderBillingPlanDetail.Append(string.Format("<ContractStartDate>{0}</ContractStartDate>", this.GetdateinddMMyyyy(jobjQuoteNOptyPayload["niq_contractstartdate"].ToString().Trim())));
                if (jobjQuoteNOptyPayload.ContainsKey("niq_contractenddate"))
                    sbHeaderBillingPlanDetail.Append(string.Format("<ContractEndDate>{0}</ContractEndDate>", this.GetdateinddMMyyyy(jobjQuoteNOptyPayload["niq_contractenddate"].ToString().Trim())));

                sbHeaderBillingPlanDetail.Append(string.Format("<Description>{0}</Description>", SecurityElement.Escape(Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["name"]).Trim())));
                sbHeaderBillingPlanDetail.Append(string.Format("<SaleOrganization>{0}</SaleOrganization>", Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_salesorgid"]["niq_salesorgcode"])));
                sbHeaderBillingPlanDetail.Append("</HeaderBillingPlanDetails>");
                return sbHeaderBillingPlanDetail.ToString();
            }
            catch (Exception ex)
            {
                tracingService.Trace("BuildHeaderBillingPlanDetail");
                throw ex;
            }
        }

        private string BuildItemPartnerFunctions(JObject jobjQuoteNOptyPayload, JObject jobjQuoteDetailPayload, string strHeaderPartnerFunction, JObject jobjItemCtgryGrpMtdtPayload)
        {
            StringBuilder sbItemPartnerFunctions = new StringBuilder();
            try
            {

                var lstQuotedetail = jobjQuoteDetailPayload["value"].ToList<JToken>();
                if (lstQuotedetail.Count > 0)
                {

                    foreach (var quoteProduct in lstQuotedetail)
                    {
                        sbItemPartnerFunctions.Append("<ItemPartnerFunctions>");
                        sbItemPartnerFunctions.Append(string.Format("<SalesDocItemNumber>{0}</SalesDocItemNumber>", quoteProduct["niq_lineitemnumberforsap"].ToString()));
                        sbItemPartnerFunctions.Append(strHeaderPartnerFunction);
                        sbItemPartnerFunctions.Append("</ItemPartnerFunctions>");
                        MergeItemCategoryMetadatatoQuoteProduct(jobjQuoteNOptyPayload, quoteProduct as JObject, jobjItemCtgryGrpMtdtPayload);
                    }

                }
                return sbItemPartnerFunctions.ToString();
            }
            catch (Exception ex)
            {
                tracingService.Trace("BuildItemPartnerFunctions");
                throw ex;
            }
        }

        private void MergeItemCategoryMetadatatoQuoteProduct(JObject jobjQuoteNOptyPayload, JObject quoteProduct, JObject jobjItemCtgryGrpMtdtPayload)
        {
            try
            {
                IEnumerable<JToken> jobjMTDT = null;
                if (IsRevHostOpportunityWithChildQP(jobjQuoteNOptyPayload, quoteProduct))
                {
                    if (Convert.ToString(quoteProduct["revproductpricelevel.niq_itemcategorygroup"]).Trim().Length > 0)
                    {
                        var itemcategorygroupvalue = quoteProduct["revproductpricelevel.niq_itemcategorygroup"].ToString().Trim();
                        jobjMTDT = jobjItemCtgryGrpMtdtPayload.SelectTokens("$.value[?(@.niq_itemcategorygroup == " + itemcategorygroupvalue + ")]");
                    }
                }
                else
                {
                    if (Convert.ToString(quoteProduct["productpricelevel.niq_itemcategorygroup"]).Trim().Length > 0)
                    {
                        var itemcategorygroupvalue = quoteProduct["productpricelevel.niq_itemcategorygroup"].ToString().Trim();
                        jobjMTDT = jobjItemCtgryGrpMtdtPayload.SelectTokens("$.value[?(@.niq_itemcategorygroup == " + itemcategorygroupvalue + ")]");
                    }
                }
                if (jobjMTDT != null)
                {
                    foreach (var itemjObjMTDT in jobjMTDT)
                    {
                        quoteProduct.Add("ItemCategoryGrpMTDT", itemjObjMTDT);
                        return;
                    }

                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("MergeItemCategoryMetadatatoQuoteProduct");
                throw ex;
            }
        }

        private string BuildQuoteProductsforeach(JObject jobjQuoteNOptyPayload, JObject jobjQuoteDetailPayload, JObject jobjQuoteDetailCharPayload, JObject jobjQuoteDetailSchedulePayload)
        {
            StringBuilder sbQuoteProductsforeach = new StringBuilder();
            string lineItemNo = String.Empty;
            try
            {
                var lstQuotedetail = jobjQuoteDetailPayload["value"].ToList<JToken>();
                if (lstQuotedetail.Count > 0)
                {
                    StringBuilder sbContractlineitem = new StringBuilder();
                    StringBuilder sbContractLineItemBilling = new StringBuilder();
                    StringBuilder sbCustomResearchBillingSchedule = new StringBuilder();
                    StringBuilder sbLineItemText = new StringBuilder();
                    foreach (var quoteProduct in lstQuotedetail)
                    {
                        lineItemNo = quoteProduct["niq_lineitemnumberforsap"].ToString();

                        var quoteProductCharacteristic = jobjQuoteDetailCharPayload.SelectTokens("$.value[?(@._niq_quoteproductid_value == '" + quoteProduct["quotedetailid"].ToString() + "')]");
                        // BuildContractLineItem
                        sbContractlineitem.Append(this.BuildContractLineItem(jobjQuoteNOptyPayload, quoteProduct, quoteProductCharacteristic.ToList(), jobjQuoteDetailSchedulePayload));

                        //BuildContractLineItemBilling
                        sbContractLineItemBilling.Append(this.BuildContractLineItemBilling(jobjQuoteNOptyPayload, quoteProduct));

                        //BuildCustomResearchBillingSchedule
                        if (!this.IsPeriodicinItemCategoryGroupMetadata(quoteProduct)) // Ad-hoc
                        {
                            sbCustomResearchBillingSchedule.Append(this.BuildCustomResearchBillingSchedule(jobjQuoteNOptyPayload, quoteProduct, jobjQuoteDetailSchedulePayload));
                        }
                        //BuildLineItemText
                        sbLineItemText.Append(this.BuildLineItemText(jobjQuoteNOptyPayload, quoteProduct, sbLineItemText.ToString()));

                    }
                    sbQuoteProductsforeach.Append(sbContractlineitem.ToString()); // BuildContractLineItem
                    sbQuoteProductsforeach.Append(sbContractLineItemBilling.ToString()); //BuildContractLineItemBilling
                    if (sbCustomResearchBillingSchedule.ToString().Trim().Length > 0)
                    {
                        //sbQuoteProductsforeach.Append(string.Format("<CustomResearchBillingSchedule>{0}</CustomResearchBillingSchedule>", sbCustomResearchBillingSchedule.ToString())); //BuildCustomResearchBillingSchedule
                        sbQuoteProductsforeach.Append(sbCustomResearchBillingSchedule.ToString()); //BuildCustomResearchBillingSchedule
                    }
                    sbQuoteProductsforeach.Append(sbLineItemText.ToString());//BuildLineItemText

                }
                return sbQuoteProductsforeach.ToString();

            }
            catch (Exception ex)
            {
                tracingService.Trace("BuildQuoteProductsforeach" + lineItemNo);
                throw ex;
            }
        }
        public string BuildContractLineItem(JObject jobjQuoteNOptyPayload, JToken quoteProduct, List<JToken> quoteProductwithMatChar, JObject jobjQuoteDetailSchedulePayload)
        {
            StringBuilder sbContractLineItem = new StringBuilder();
            try
            {
                sbContractLineItem.Append("<ContractLineItems>");
                //sbContractLineItem.Append(string.Format("<QuoteproductId>{0}</QuoteproductId>", quoteProduct["quotedetailid"].ToString()));
                //niq_host_revenuesharedeal - contains the details of parent opportunity or host opportunity's revenue share deal value.
                if (jobjQuoteNOptyPayload["niq_host_revenuesharedeal"] != null)
                {
                    //if rev share is true
                    if ((bool)jobjQuoteNOptyPayload["niq_host_revenuesharedeal"])
                    {
                        //child opportunity
                        if (!string.IsNullOrEmpty(jobjQuoteNOptyPayload["opportunityid"]["_niq_hostopportunity_value"].ToString()) && quoteProduct["_niq_revshareline_value"] != null)
                        {
                            if (quoteProduct["niq_quoteproductnumber"] != null && !string.IsNullOrEmpty(quoteProduct["niq_quoteproductnumber"].ToString()) && DateTime.Parse(DateTime.Parse(jobjQuoteNOptyPayload["opportunityid"]["createdon"].ToString()).ToString("yyyy-MM-dd")) > new DateTime(2026,02,08))                            
                                sbContractLineItem.Append(string.Format("<QuoteproductId>{0}</QuoteproductId>", quoteProduct["niq_quoteproductnumber"].ToString()));                            
                            else
                                sbContractLineItem.Append(string.Format("<QuoteproductId>{0}</QuoteproductId>", quoteProduct["quotedetailid"].ToString()));


                            sbContractLineItem.Append(string.Format("<PquoteproductId>{0}</PquoteproductId>", quoteProduct["quotedetailid"].ToString()));// only for rev child
                        }
                        //parent opportunity
                        else
                        {
                            if (quoteProduct["_niq_revshareline_value"] != null)
                            {
                                sbContractLineItem.Append(string.Format("<QuoteproductId>{0}</QuoteproductId>", quoteProduct["quotedetailid"].ToString()));
                                sbContractLineItem.Append(string.Format("<PquoteproductId>{0}</PquoteproductId>", quoteProduct["quotedetailid"].ToString()));
                            }
                            else
                            {
                                if (quoteProduct["niq_quoteproductnumber"] != null && !string.IsNullOrEmpty(quoteProduct["niq_quoteproductnumber"].ToString()) && DateTime.Parse(DateTime.Parse(jobjQuoteNOptyPayload["opportunityid"]["createdon"].ToString()).ToString("yyyy-MM-dd")) > new DateTime(2026,02,08))
                                {
                                    sbContractLineItem.Append(string.Format("<QuoteproductId>{0}</QuoteproductId>", quoteProduct["niq_quoteproductnumber"].ToString()));
                                    sbContractLineItem.Append(string.Format("<PquoteproductId>{0}</PquoteproductId>", quoteProduct["niq_quoteproductnumber"].ToString()));
                                }
                                else
                                {
                                    sbContractLineItem.Append(string.Format("<QuoteproductId>{0}</QuoteproductId>", quoteProduct["quotedetailid"].ToString()));
                                    sbContractLineItem.Append(string.Format("<PquoteproductId>{0}</PquoteproductId>", quoteProduct["quotedetailid"].ToString()));
                                }
                            }
                        }
                    }
                    else
                    {
                        if (quoteProduct["niq_quoteproductnumber"] != null && !string.IsNullOrEmpty(quoteProduct["niq_quoteproductnumber"].ToString()) && DateTime.Parse(DateTime.Parse(jobjQuoteNOptyPayload["opportunityid"]["createdon"].ToString()).ToString("yyyy-MM-dd")) > new DateTime(2026,02,08))
                            sbContractLineItem.Append(string.Format("<QuoteproductId>{0}</QuoteproductId>", quoteProduct["niq_quoteproductnumber"].ToString()));
                        else
                            sbContractLineItem.Append(string.Format("<QuoteproductId>{0}</QuoteproductId>", quoteProduct["quotedetailid"].ToString()));
                        //sbContractLineItem.Append(string.Format("<PquoteproductId>{0}</PquoteproductId>", quoteProduct["niq_quoteproductnumber"].ToString()));
                    }
                }
                else
                {
                    if (quoteProduct["niq_quoteproductnumber"] != null && !string.IsNullOrEmpty(quoteProduct["niq_quoteproductnumber"].ToString()) && DateTime.Parse(DateTime.Parse(jobjQuoteNOptyPayload["opportunityid"]["createdon"].ToString()).ToString("yyyy-MM-dd")) > new DateTime(2026,02,08))
                        sbContractLineItem.Append(string.Format("<QuoteproductId>{0}</QuoteproductId>", quoteProduct["niq_quoteproductnumber"].ToString()));
                    else
                        sbContractLineItem.Append(string.Format("<QuoteproductId>{0}</QuoteproductId>", quoteProduct["quotedetailid"].ToString()));
                    //sbContractLineItem.Append(string.Format("<PquoteproductId>{0}</PquoteproductId>", quoteProduct["niq_quoteproductnumber"].ToString()));
                }

                if (quoteProduct["niq_quoteproductnumber"] != null && !string.IsNullOrEmpty(quoteProduct["niq_quoteproductnumber"].ToString()) && DateTime.Parse(DateTime.Parse(jobjQuoteNOptyPayload["opportunityid"]["createdon"].ToString()).ToString("yyyy-MM-dd")) > new DateTime(2026,02,08))
                    sbContractLineItem.Append(string.Format("<LineItemNumber>{0}</LineItemNumber>", quoteProduct["niq_quoteproductnumber"].ToString()));
                else
                    sbContractLineItem.Append(string.Format("<LineItemNumber>{0}</LineItemNumber>", jobjQuoteNOptyPayload["opportunityid"]["niq_opportunitynumber"].ToString()));


                sbContractLineItem.Append(string.Format("<SalesDocItem>{0}</SalesDocItem>", quoteProduct["niq_lineitemnumberforsap"].ToString()));

                if (IsRevHostOpportunityWithChildQP(jobjQuoteNOptyPayload, quoteProduct))
                    sbContractLineItem.Append(string.Format("<MaterialNumber>{0}</MaterialNumber>", SecurityElement.Escape(quoteProduct["prpid.productnumber"].ToString().Trim())));
                else
                    sbContractLineItem.Append(string.Format("<MaterialNumber>{0}</MaterialNumber>", SecurityElement.Escape(quoteProduct["productnumber"].ToString().Trim())));

                sbContractLineItem.Append(string.Format("<Plant>{0}</Plant>", jobjQuoteNOptyPayload["opportunityid"]["niq_salesorgid"]["niq_salesorgcode"]).Trim());

                //Target QTY,Order QTY 
                if (this.IsRequiredinItemCategoryGroupMetadata(quoteProduct, "niq_targetquantity") == true)
                {
                    sbContractLineItem.Append(string.Format("<TargetQty>{0}</TargetQty><TargetUOM>EA</TargetUOM><OrderQty>{0}</OrderQty><SalesUnit>EA</SalesUnit>",
                 Math.Abs(decimal.Parse(quoteProduct["extendedamount"].ToString())).ToString("F")));
                }
                else if (this.IsPeriodicinItemCategoryGroupMetadata(quoteProduct) == true)
                {
                    sbContractLineItem.Append(string.Format("<TargetQty>{0}</TargetQty><TargetUOM>EA</TargetUOM><OrderQty>{0}</OrderQty><SalesUnit>EA</SalesUnit>",
                 Math.Abs(decimal.Parse(quoteProduct["quantity"].ToString())).ToString("F")));
                }

                sbContractLineItem.Append(string.Format("<CustomerPONumber>{0}</CustomerPONumber>", SecurityElement.Escape(Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_customerponumber"]))));
                sbContractLineItem.Append("<BillingBlock/>");

                //for rev share child opportunity quote products, the wbs code will not be passed for sap integration
                if (!IsRevHostOpportunityWithChildQP(jobjQuoteNOptyPayload, quoteProduct) && quoteProduct["niq_wbs"] != null && quoteProduct["niq_wbs"].ToString().Trim().Length > 0)
                    sbContractLineItem.Append(string.Format("<WBSElement>{0}</WBSElement>", SecurityElement.Escape(Convert.ToString(quoteProduct["niq_wbs"]).Trim())));


                //Material Group 4
                if (Convert.ToString(quoteProduct["niq_lagrevenuerecognition"]).Trim().Length > 0 &&
                    this.IsRequiredinItemCategoryGroupMetadata(quoteProduct, "niq_materialgroup4") == true)
                {
                    if (Enum.IsDefined(typeof(ENUMS.MATERIALGRP4), int.Parse(quoteProduct["niq_lagrevenuerecognition"].ToString())) == true)
                    {
                        sbContractLineItem.Append(string.Format("<MaterialGrp4>{0}</MaterialGrp4>",
                            ((ENUMS.MATERIALGRP4)int.Parse(quoteProduct["niq_lagrevenuerecognition"].ToString())).ToString().Replace("enum_", "")));
                    }
                }
                // Material Group 5
                if (Convert.ToString(jobjQuoteNOptyPayload["niq_termtype"]).Trim().Length > 0)
                {
                    if (Convert.ToString(jobjQuoteNOptyPayload["niq_termtype"]).Trim() == "100000002" || Convert.ToString(jobjQuoteNOptyPayload["niq_termtype"]).Trim() == "100000003"
                        || Convert.ToString(jobjQuoteNOptyPayload["niq_termtype"]).Trim() == "100000004")
                    {
                        jobjQuoteNOptyPayload["niq_termtype"] = "100000000";
                    }
                    if (Enum.IsDefined(typeof(ENUMS.MATERIALGRP5), int.Parse(jobjQuoteNOptyPayload["niq_termtype"].ToString())) == true)
                    {
                        sbContractLineItem.Append(string.Format("<MaterialGrp5>{0}</MaterialGrp5>",
                            ((ENUMS.MATERIALGRP5)int.Parse(jobjQuoteNOptyPayload["niq_termtype"].ToString())).ToString().Replace("enum_", "")));
                    }
                }
                //Delivery Frequency
                var enumDeliveryFrqVal = "";
                if (Convert.ToString(quoteProduct["niq_deliveryfrequency"]).Trim().Length > 0 &&
                    this.IsRequiredinItemCategoryGroupMetadata(quoteProduct, "niq_deliveryfrequency") == true)
                {
                    int valDelFrqValue = int.Parse(quoteProduct["niq_deliveryfrequency"].ToString());
                    if (valDelFrqValue == 100000006 || valDelFrqValue == 100000007 || valDelFrqValue == 100000008)
                        valDelFrqValue = 100000000;  // Bi-Monthly- Monthly Rev Rec  , Quarterly- Monthly Rev Rec, monthly timebased

                    if (Enum.IsDefined(typeof(ENUMS.DELIVERY_FREQUENCY), valDelFrqValue) == true)
                    {
                        enumDeliveryFrqVal = ((ENUMS.DELIVERY_FREQUENCY)valDelFrqValue).ToString().Replace("enum_", "");
                        sbContractLineItem.Append(string.Format("<DeliveryTime>{0}</DeliveryTime>", enumDeliveryFrqVal));
                    }
                }
                if (IsRevHostOpportunityWithChildQP(jobjQuoteNOptyPayload, quoteProduct))
                {
                    if (Convert.ToString(quoteProduct["revproductpricelevel.niq_profitcentrecode"]).Trim().Length > 0)
                    {
                        sbContractLineItem.Append(string.Format("<ProfitCenter>{0}</ProfitCenter>", quoteProduct["revproductpricelevel.niq_profitcentrecode"].ToString().Trim()));
                    }
                }
                else
                {
                    if (Convert.ToString(quoteProduct["niq_profitcentre.niq_profitcentrecode"]).Trim().Length > 0)
                    {
                        sbContractLineItem.Append(string.Format("<ProfitCenter>{0}</ProfitCenter>", quoteProduct["niq_profitcentre.niq_profitcentrecode"].ToString().Trim()));
                    }
                }

                sbContractLineItem.Append(string.Format("<ShipToPoDate>{0}</ShipToPoDate>", this.GetdateinddMMyyyy(jobjQuoteNOptyPayload["opportunityid"]["niq_submissiontime"].ToString())));

                if (entSalesDoctypemtdt != null && entSalesDoctypemtdt.Contains("niq_pricingconditiontype") &&
                    entSalesDoctypemtdt["niq_pricingconditiontype"].ToString().Trim().Length > 0)
                {
                    sbContractLineItem.Append(string.Format("<ConditionType>{0}</ConditionType>", entSalesDoctypemtdt["niq_pricingconditiontype"].ToString().Trim()));
                }
                else
                    sbContractLineItem.Append("<ConditionType>ZNPR</ConditionType>");

                //RATE
                string strRate = "";
                if (this.IsPeriodicinItemCategoryGroupMetadata(quoteProduct) == true)
                {
                    strRate = this.GetRateforPeriodicSchedule(quoteProduct, jobjQuoteDetailSchedulePayload);
                }
                else if (quoteProduct["ItemCategoryGrpMTDT"] != null && quoteProduct["ItemCategoryGrpMTDT"]["niq_fixedrate"] != null
                        && quoteProduct["ItemCategoryGrpMTDT"]["niq_fixedrate"].ToString().Trim().Length > 0)
                {
                    if (decimal.Parse(quoteProduct["extendedamount"].ToString()) < 0)
                        strRate = "-" + (quoteProduct["ItemCategoryGrpMTDT"]["niq_fixedrate"].ToString().Trim());
                    else
                        strRate = quoteProduct["ItemCategoryGrpMTDT"]["niq_fixedrate"].ToString().Trim();

                }
                else
                    strRate = decimal.Parse(quoteProduct["extendedamount"].ToString()).ToString("F");

                if (strRate.Length > 0)
                {
                    sbContractLineItem.Append(string.Format("<Rate>{0}</Rate>", strRate));
                }

                sbContractLineItem.Append(string.Format("<CurrencyKey>{0}</CurrencyKey>", jobjQuoteNOptyPayload["transactioncurrencyid"]["isocurrencycode"].ToString()));
                // Quote Product Characteristic
                foreach (var item in quoteProductwithMatChar)
                {
                    //CharacteristicName ,CharacteristicValue
                    if (item["niq_materialcharacteristicid"] != null && item["niq_materialcharacteristicid"]["niq_characteristiccode"] != null
                        && item["niq_materialcharacteristicid"]["niq_characteristiccode"].ToString().Length > 0)
                    {
                        sbContractLineItem.Append(string.Format("<CharacteristicName>{0}</CharacteristicName>", item["niq_materialcharacteristicid"]["niq_characteristiccode"].ToString()));
                        if (item["niq_materialcharacteristicvalueid"] != null && !string.IsNullOrEmpty(item["niq_materialcharacteristicvalueid"].ToString()) && item["niq_materialcharacteristicvalueid"]["niq_characteristicvaluecode"] != null && item["niq_materialcharacteristicvalueid"]["niq_characteristicvaluecode"].ToString().Length > 0)
                            sbContractLineItem.Append(string.Format("<CharacteristicValue>{0}</CharacteristicValue>", item["niq_materialcharacteristicvalueid"]["niq_characteristicvaluecode"].ToString()));
                        else
                            sbContractLineItem.Append("<CharacteristicValue></CharacteristicValue>");
                    }
                }

                sbContractLineItem.Append("</ContractLineItems>");
                return sbContractLineItem.ToString();
            }
            catch (Exception ex)
            {
                tracingService.Trace("BuildContractLineItem");
                throw ex;
            }
        }

        public string BuildContractLineItemBilling(JObject jobjQuoteNOptyPayload, JToken quoteProduct)
        {
            StringBuilder sbContractLineItemBilling = new StringBuilder();
            try
            {
                sbContractLineItemBilling.Append("<ContractLineItemBilling>");
                if (quoteProduct["niq_quoteproductnumber"] != null && !string.IsNullOrEmpty(quoteProduct["niq_quoteproductnumber"].ToString()) && DateTime.Parse(DateTime.Parse(jobjQuoteNOptyPayload["opportunityid"]["createdon"].ToString()).ToString("yyyy-MM-dd")) > new DateTime(2026,02,08))
                    sbContractLineItemBilling.Append(string.Format("<LineItemNumber>{0}</LineItemNumber>", quoteProduct["niq_quoteproductnumber"].ToString()));
                else
                    sbContractLineItemBilling.Append(string.Format("<LineItemNumber>{0}</LineItemNumber>", jobjQuoteNOptyPayload["opportunityid"]["niq_opportunitynumber"].ToString()));
                //sbContractLineItemBilling.Append(string.Format("<LineItemNumber>{0}</LineItemNumber>", quoteProduct["niq_quoteproductnumber"].ToString()));
                sbContractLineItemBilling.Append(string.Format("<SalesDocItem>{0}</SalesDocItem>", quoteProduct["niq_lineitemnumberforsap"].ToString()));
                sbContractLineItemBilling.Append(string.Format("<ContractStartDate>{0}</ContractStartDate>", this.GetdateinddMMyyyy(Convert.ToString(quoteProduct["niq_lineitemstartdate"]))));
                sbContractLineItemBilling.Append(string.Format("<ContractEndDate>{0}</ContractEndDate>", this.GetdateinddMMyyyy(Convert.ToString(quoteProduct["niq_lineitemenddate"]))));
                sbContractLineItemBilling.Append(string.Format("<POExpiryDate>{0}</POExpiryDate>", GetdateinddMMyyyy(Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_customerpodate"]))));
                //Billing Frequency
                var enumBillingFrqVal = "";
                if (Convert.ToString(quoteProduct["niq_billingfrequency"]).Trim().Length > 0 &&
                    this.IsPeriodicinItemCategoryGroupMetadata(quoteProduct) == true)
                {
                    int valOptionsetVal = int.Parse(quoteProduct["niq_billingfrequency"].ToString());
                    if (valOptionsetVal == 100000006) valOptionsetVal = 100000000;  // Monthly , Monthly with Lag
                    else if (valOptionsetVal == 100000007) valOptionsetVal = 100000001; //BI-Monthly ,BI-Monthly with Lag
                    else if (valOptionsetVal == 100000008) valOptionsetVal = 100000002; //Quaterly ,Quaterly with Lag

                    if (Enum.IsDefined(typeof(ENUMS.BILLING_FREQUENCY), valOptionsetVal) == true)
                    {
                        enumBillingFrqVal = ((ENUMS.BILLING_FREQUENCY)valOptionsetVal).ToString().Replace("enum_", "");
                        sbContractLineItemBilling.Append(string.Format("<BillingFrequency>{0}</BillingFrequency>", enumBillingFrqVal));
                    }
                }

                //Billing Deviation and Billing in Advance
                if (Convert.ToString(quoteProduct["niq_billingfrequency"]).Trim() == "100000006") //Monthly with Lag
                {
                    sbContractLineItemBilling.Append("<BillingDeviation>61</BillingDeviation>"); //Plus 1 day
                    sbContractLineItemBilling.Append("<BillingInAdvance>NO</BillingInAdvance>");  //False
                }
                else if (Convert.ToString(quoteProduct["niq_billingfrequency"]).Trim() == "100000007") //Bi-Monthly with lag
                {
                    sbContractLineItemBilling.Append("<BillingDeviation>A1</BillingDeviation>"); //Plus 2 month
                }
                else if (Convert.ToString(quoteProduct["niq_billingfrequency"]).Trim() == "100000008")  //Quaterly
                {
                    sbContractLineItemBilling.Append("<BillingDeviation>A2</BillingDeviation>"); //Plus 3 month
                }
                else
                    sbContractLineItemBilling.Append("<BillingInAdvance>X</BillingInAdvance>");  //True

                sbContractLineItemBilling.Append("</ContractLineItemBilling>");
                return sbContractLineItemBilling.ToString();
            }
            catch (Exception ex)
            {
                tracingService.Trace("BuildContractLineItemBilling");
                throw ex;
            }
        }

        public string BuildCustomResearchBillingSchedule(JObject jobjQuoteNOptyPayload, JToken quoteProduct, JObject jobjQuoteDetailSchedulePayload)
        {
            StringBuilder sbCustomResearchBillingSchedule = new StringBuilder();
            try
            {
                //Billing Type and Amount>0
                IEnumerable<JToken> jobjSchedules = null;
                bool blIncludeRevenue = false;
                if (this.IsRequiredinItemCategoryGroupMetadata(quoteProduct, "niq_schedulelinedate") || this.IsRequiredinItemCategoryGroupMetadata(quoteProduct, "niq_orderquantity"))
                {
                    blIncludeRevenue = true;
                    jobjSchedules = jobjQuoteDetailSchedulePayload.SelectTokens("$.value[?(@.niq_amount != 0  && @._niq_lineitemid_value == '" + quoteProduct["quotedetailid"].ToString() + "')]").ToList();
                }
                else
                    jobjSchedules = jobjQuoteDetailSchedulePayload.SelectTokens("$.value[?(@.niq_scheduletype ==100000000 && @.niq_amount != 0  && @._niq_lineitemid_value == '" + quoteProduct["quotedetailid"].ToString() + "')]").ToList();

                foreach (var scheduleitem in jobjSchedules)
                {
                    sbCustomResearchBillingSchedule.Append("<CustomResearchBillingSchedule>");
                    if (quoteProduct["niq_quoteproductnumber"] != null && !string.IsNullOrEmpty(quoteProduct["niq_quoteproductnumber"].ToString()) && DateTime.Parse(DateTime.Parse(jobjQuoteNOptyPayload["opportunityid"]["createdon"].ToString()).ToString("yyyy-MM-dd")) > new DateTime(2026,02,08))
                        sbCustomResearchBillingSchedule.Append(string.Format("<LineItemNumber>{0}</LineItemNumber>", quoteProduct["niq_quoteproductnumber"].ToString()));
                    else
                        sbCustomResearchBillingSchedule.Append(string.Format("<LineItemNumber>{0}</LineItemNumber>", jobjQuoteNOptyPayload["opportunityid"]["niq_opportunitynumber"].ToString()));
                    //sbCustomResearchBillingSchedule.Append(string.Format("<LineItemNumber>{0}</LineItemNumber>", quoteProduct["niq_quoteproductnumber"].ToString()));
                    sbCustomResearchBillingSchedule.Append(string.Format("<SalesDocItem>{0}</SalesDocItem>", quoteProduct["niq_lineitemnumberforsap"].ToString()));
                    sbCustomResearchBillingSchedule.Append(string.Format("<ContractRefNumber>{0}</ContractRefNumber>", jobjQuoteNOptyPayload["opportunityid"]["opportunityid"].ToString()));
                    sbCustomResearchBillingSchedule.Append("<GRNNumber>02</GRNNumber>");

                    if (!string.IsNullOrEmpty(scheduleitem["niq_scheduletype"].ToString()) && int.Parse(scheduleitem["niq_scheduletype"].ToString()) == 100000000)
                    {
                        sbCustomResearchBillingSchedule.Append(string.Format("<BillingDate>{0}</BillingDate>", this.GetdateinddMMyyyy(scheduleitem["niq_scheduledate"].ToString())));
                        sbCustomResearchBillingSchedule.Append(string.Format("<ScheduleLine_date>{0}</ScheduleLine_date>", this.GetdateinddMMyyyy(scheduleitem["niq_scheduledate"].ToString())));
                    }
                    else if (scheduleitem["niq_calculatedscheduledate"] != null && !string.IsNullOrEmpty(scheduleitem["niq_calculatedscheduledate"].ToString()))
                    {
                        sbCustomResearchBillingSchedule.Append(string.Format("<BillingDate>{0}</BillingDate>", this.GetdateinddMMyyyy(scheduleitem["niq_calculatedscheduledate"].ToString())));
                        sbCustomResearchBillingSchedule.Append(string.Format("<ScheduleLine_date>{0}</ScheduleLine_date>", this.GetdateinddMMyyyy(scheduleitem["niq_calculatedscheduledate"].ToString())));
                    }                    

                    // if (blIncludeRevenue)
                    //   sbCustomResearchBillingSchedule.Append(string.Format("<ScheduleLine_date>{0}</ScheduleLine_date>", this.GetdateinddMMyyyy(scheduleitem["niq_scheduledate"].ToString())));
                    //if (blIncludeRevenue && scheduleitem["niq_scheduletype"].ToString() == "100000001") // revenue
                    //Added condition for story DYNCRM-2091 to send revenue schedules to SAP
                    if (blIncludeRevenue && (scheduleitem["niq_scheduletype"].ToString() == "100000001" || scheduleitem["niq_scheduletype"].ToString() == "100000002"))
                    {
                        sbCustomResearchBillingSchedule.Append(string.Format("<Order_QTY>{0}</Order_QTY>", decimal.Parse(scheduleitem["niq_amount"].ToString()).ToString("F")));
                        sbCustomResearchBillingSchedule.Append("<BilingValue>0.00</BilingValue>");
                    }
                    else
                    {
                        sbCustomResearchBillingSchedule.Append(string.Format("<BilingValue>{0}</BilingValue>", decimal.Parse(scheduleitem["niq_amount"].ToString()).ToString("F")));
                        sbCustomResearchBillingSchedule.Append("<Order_QTY>0.00</Order_QTY>");
                    }
                    sbCustomResearchBillingSchedule.Append("</CustomResearchBillingSchedule>");
                }

                return sbCustomResearchBillingSchedule.ToString();
            }
            catch (Exception ex)
            {
                tracingService.Trace("BuildCustomResearchBillingSchedule");
                throw ex;
            }
        }

        public string BuildLineItemText(JObject jobjQuoteNOptyPayload, JToken quoteProduct, string strLineItemText)
        {
            StringBuilder sbLineItemText = new StringBuilder();
            try
            {
                if (strLineItemText.Trim().Length <= 0 && Convert.ToString(jobjQuoteNOptyPayload["opportunityid"]["niq_billinginstructions"]).ToString().Trim().Length > 0)
                {
                    sbLineItemText.Append("<LineItemText>");
                    if (quoteProduct["niq_quoteproductnumber"] != null && !string.IsNullOrEmpty(quoteProduct["niq_quoteproductnumber"].ToString()) && DateTime.Parse(DateTime.Parse(jobjQuoteNOptyPayload["opportunityid"]["createdon"].ToString()).ToString("yyyy-MM-dd")) > new DateTime(2026,02,08))
                        sbLineItemText.Append(string.Format("<LineItemNumber>{0}</LineItemNumber>", quoteProduct["niq_quoteproductnumber"].ToString()));
                    else
                        sbLineItemText.Append(string.Format("<LineItemNumber>{0}</LineItemNumber>", jobjQuoteNOptyPayload["opportunityid"]["niq_opportunitynumber"].ToString()));
                    //sbLineItemText.Append(string.Format("<LineItemNumber>{0}</LineItemNumber>", quoteProduct["niq_quoteproductnumber"].ToString()));
                    sbLineItemText.Append("<SalesDocItem>000000</SalesDocItem>");
                    sbLineItemText.Append("<SAPFreeTextID>0001</SAPFreeTextID>");
                    sbLineItemText.Append("<LanguageKey>E</LanguageKey>");
                    sbLineItemText.Append(string.Format("<FreeText>{0}</FreeText>", SecurityElement.Escape(jobjQuoteNOptyPayload["opportunityid"]["niq_billinginstructions"].ToString().Trim())));
                    sbLineItemText.Append("</LineItemText>");
                }
                sbLineItemText.Append("<LineItemText>");
                if (quoteProduct["niq_quoteproductnumber"] != null && !string.IsNullOrEmpty(quoteProduct["niq_quoteproductnumber"].ToString()) && DateTime.Parse(DateTime.Parse(jobjQuoteNOptyPayload["opportunityid"]["createdon"].ToString()).ToString("yyyy-MM-dd")) > new DateTime(2026,02,08))
                    sbLineItemText.Append(string.Format("<LineItemNumber>{0}</LineItemNumber>", quoteProduct["niq_quoteproductnumber"].ToString()));
                else
                    sbLineItemText.Append(string.Format("<LineItemNumber>{0}</LineItemNumber>", jobjQuoteNOptyPayload["opportunityid"]["niq_opportunitynumber"].ToString()));
                //sbLineItemText.Append(string.Format("<LineItemNumber>{0}</LineItemNumber>", quoteProduct["niq_quoteproductnumber"].ToString()));
                sbLineItemText.Append(string.Format("<SalesDocItem>{0}</SalesDocItem>", quoteProduct["niq_lineitemnumberforsap"].ToString()));
                sbLineItemText.Append("<SAPFreeTextID>Z03</SAPFreeTextID>");
                sbLineItemText.Append("<LanguageKey>E</LanguageKey>");

                string freetext = ""; // Invoice text, fund type and fund amount
                if (quoteProduct["niq_invoicetext"] != null && quoteProduct["niq_invoicetext"].ToString().Trim().Length > 0)
                    freetext = quoteProduct["niq_invoicetext"].ToString().Trim();
                else if (IsRevHostOpportunityWithChildQP(jobjQuoteNOptyPayload, quoteProduct))
                {
                    freetext = quoteProduct["pepid.description"] != null ? quoteProduct["pepid.description"].ToString().Trim() : "";
                }
                if (quoteProduct["niq_fundtype"] != null && quoteProduct["niq_fundtype"].ToString().Trim().Length > 0)
                {
                    freetext += (Environment.NewLine + quoteProduct["niq_fundtype"].ToString().Trim());
                    if (quoteProduct["niq_fundamount"] != null && quoteProduct["niq_fundamount"].ToString().Length > 0)
                        freetext += (" - " + jobjQuoteNOptyPayload["transactioncurrencyid"]["isocurrencycode"].ToString() + " " + decimal.Parse(quoteProduct["niq_fundamount"].ToString()).ToString("F"));
                }
                if (freetext.Trim().Length > 0)
                    sbLineItemText.Append(string.Format("<FreeText>{0}</FreeText>", SecurityElement.Escape(freetext.Trim())));
                sbLineItemText.Append("</LineItemText>");

                return sbLineItemText.ToString();
            }
            catch (Exception ex)
            {
                tracingService.Trace("BuildLineItemText");
                throw ex;
            }
        }

        /// <summary>
        /// DYNCRM-29242: it will check the whether the it is quote product of child opportunity which is retrieved for rev share host opportunity integration
        /// </summary>
        /// <param name="jobjQuoteNOptyPayload">revshare flag field on opportunity</param>
        /// <param name="quoteProduct"></param>
        /// <returns></returns>
        public bool IsRevHostOpportunityWithChildQP(JObject jobjQuoteNOptyPayload, JToken quoteProduct)
        {

            if (string.IsNullOrEmpty(jobjQuoteNOptyPayload["opportunityid"]["_niq_hostopportunity_value"].ToString()) &&
                jobjQuoteNOptyPayload["niq_host_revenuesharedeal"] != null && (bool)jobjQuoteNOptyPayload["niq_host_revenuesharedeal"] &&
                quoteProduct["_niq_revshareproductid_value"] != null)
            {
                return true;
            }
            return false;
        }
        public bool IsRequiredinItemCategoryGroupMetadata(JToken quoteProduct, string fieldname)
        {
            try
            {
                if (quoteProduct["ItemCategoryGrpMTDT"] != null && Convert.ToBoolean(quoteProduct["ItemCategoryGrpMTDT"][fieldname].ToString()))
                    return true;
                /*
            if (Convert.ToString(quoteProduct["productpricelevel.niq_itemcategorygroup"]).Trim().Length > 0)
            {
                var itemcategorygroupvalue = quoteProduct["productpricelevel.niq_itemcategorygroup"].ToString().Trim();

                var jobjMTDT = this.jobjItemCtgryGrpMtdtPayload.SelectTokens("$.value[?(@.niq_itemcategorygroup == " + itemcategorygroupvalue + ")]").First();
                if (Convert.ToBoolean(jobjMTDT[fieldname].ToString()))
                    return true;
            }
            */
                return false;
            }
            catch (Exception ex)
            {
                tracingService.Trace("IsRequiredinItemCategoryGroupMetadata");
                throw ex;
            }
        }

        public bool IsPeriodicinItemCategoryGroupMetadata(JToken quoteProduct)
        {
            try
            {
                if (quoteProduct["ItemCategoryGrpMTDT"] != null &&
                   quoteProduct["ItemCategoryGrpMTDT"]["niq_recurrent"].ToString().Trim().Equals("Periodic", StringComparison.InvariantCultureIgnoreCase))
                    return true;

                /*
                if (Convert.ToString(quoteProduct["productpricelevel.niq_itemcategorygroup"]).Trim().Length > 0)
                {
                    var itemcategorygroupvalue = quoteProduct["productpricelevel.niq_itemcategorygroup"].ToString().Trim();
                    var jobjMTDT = this.jobjItemCtgryGrpMtdtPayload.SelectTokens("$.value[?(@.niq_itemcategorygroup == " + itemcategorygroupvalue + ")]").First();
                    if (jobjMTDT["niq_recurrent"].ToString().Trim().Equals("Periodic", StringComparison.InvariantCultureIgnoreCase))
                        return true;
                }
                */
                return false;
            }
            catch (Exception ex)
            {
                tracingService.Trace("IsPeriodicinItemCategoryGroupMetadata");
                throw ex;
            }
        }

        public string GetdateinddMMyyyy(string date)
        {
            if (Convert.ToString(date).Trim().Length > 0)
            {
                return Convert.ToDateTime(date).ToString("ddMMyyyy");
            }
            return "";
        }
        public string GetRateforPeriodicSchedule(JToken quoteProduct, JObject jobjQuoteDetailSchedulePayload)
        {
            try
            {
                //Billing Type and Amount!=0
                var jobjSchedules = jobjQuoteDetailSchedulePayload.SelectTokens("$.value[?(@.niq_scheduletype ==100000000 && @.niq_amount != 0  && @._niq_lineitemid_value == '" + quoteProduct["quotedetailid"].ToString() + "')]");
                //if (jobjSchedules != null && jobjSchedules.Count() > 0)
                // return decimal.Parse(jobjSchedules.First()["niq_amount"].ToString()).ToString("F");

                if (jobjSchedules != null)
                {
                    foreach (var jobjSchedule in jobjSchedules)
                    {
                        return decimal.Parse(jobjSchedule["niq_amount"].ToString()).ToString("F");
                    }
                }

                return "";
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetRateforPeriodicSchedule");
                throw ex;
            }

        }

        public Entity GetSalesDocumentTypemetadata(string SalesorgId, string countryid)
        {
            try
            {
                List<Entity> lstEnt = lstEntSalesDocTypeMetdata.Where(f => (f["niq_salesorg"] as EntityReference).Id.Equals(Guid.Parse(SalesorgId))).ToList();
                if (lstEnt != null && lstEnt.Count > 0)
                {

                    foreach (Entity item in lstEnt)
                    {
                        if (!string.IsNullOrEmpty(countryid) && countryid.Trim().Length > 0 && item.Contains("niq_country") &&
                            (item["niq_country"] as EntityReference).Id.Equals(Guid.Parse(countryid)))
                        {
                            return item;
                        }

                    }
                    return lstEnt.Where(f => f.Contains("niq_country") == false || (f.Contains("niq_country") && f["niq_country"] == null)).First();

                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetSalesDocumentTypemetadata");
                throw ex;
            }
            return null;
        }
    }
}
