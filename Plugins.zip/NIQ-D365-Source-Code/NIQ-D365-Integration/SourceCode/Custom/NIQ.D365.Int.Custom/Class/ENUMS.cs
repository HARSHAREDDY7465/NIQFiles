﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NIQ.D365.Int.Custom.Class
{
    public class ENUMS
    {
        public enum MATERIALGRP5 //TERM TYPE
        {
            enum_001 = 100000001,//Fixed
            enum_002 = 100000000,//Evergreen
            //enum_003 = 100000004,//Perpetual
            //enum_004 = 100000002,//Indefinite
            //enum_005 = 100000003,//Perpetual
        }
        public enum MATERIALGRP4 //Lag Revenue Recognition
        {
            enum_001 = 100000000,  // Delivery Schedule without Lag
            enum_002 = 100000001, //Delivery Schedule with Lag
            enum_003 = 100000002, //Delivery Schedule with Two month Lag 
            enum_004 = 100000003  //Custom Delivery
        }
        public enum BILLING_FREQUENCY //Billing Frequency
        {
            enum_50 = 100000000 ,  // Monthly , Monthly with Lag
            enum_54 = 100000002 , //Quaterly ,Quaterly with Lag
            enum_55 = 100000001 , //BI-Monthly ,BI-Monthly with Lag 
            enum_56 = 100000003,  //Half-Yearly
            enum_57 = 100000004,  //3 * Annually
            enum_58 = 100000005,  // Annually
        }
        public enum DELIVERY_FREQUENCY //Lag Revenue Recognition
        {
            enum_Z1 = 100000000,  // Monthly
            enum_Z2 = 100000001, //BI-Monthly
            enum_Z3 = 100000002, //Quarterly 
            enum_Z4 = 100000003,  //3 * Annually
            enum_Z5 = 100000004,  //Half-Yearly
            enum_Z6 = 100000005  // Annually
        }
    }
}