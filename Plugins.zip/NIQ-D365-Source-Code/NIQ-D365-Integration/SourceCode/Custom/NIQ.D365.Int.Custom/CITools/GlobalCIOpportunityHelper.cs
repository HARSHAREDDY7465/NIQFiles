﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NIQ.D365.Int.Custom.CITools
{
    public class GlobalCIOpportunityHelper
    {
        private ITracingService tracingService;
        public GlobalCIOpportunityHelper(ITracingService tracingService)
        {
            this.tracingService = tracingService;
        }

        public Opportunity GetResultPayload(Entity objOptyNQuoteInfo, List<Entity> lstQuoteProduct, List<Entity> lstOptyTeamMember, List<Entity> lstQPCharacteristic, List<Entity> lstOptyContactRoles, bool isdev, Utility objUtil)
        {
            string strResult = "";
            Opportunity opty = new Opportunity();
            try
            {
                opty.successMessage = "SUCCESS";
                opty.OpportunityID = objOptyNQuoteInfo.Id.ToString();
                opty.errorMessage = null;
                opty.isDev = isdev;
                if (objOptyNQuoteInfo.Contains("niq_opportunitynumber"))
                    opty.OpportunityNumber = objOptyNQuoteInfo["niq_opportunitynumber"].ToString().Trim();
                if (objOptyNQuoteInfo.Contains("name"))
                    opty.OpportunityName = objOptyNQuoteInfo["name"].ToString().Trim();
                if (objOptyNQuoteInfo.Contains("owner.fullname"))
                    opty.OpportunityOwnerName = (objOptyNQuoteInfo["owner.fullname"] as AliasedValue).Value.ToString();
                if (objOptyNQuoteInfo.Contains("owner.domainname"))
                    opty.OpportunityOwnerEmail = (objOptyNQuoteInfo["owner.domainname"] as AliasedValue).Value.ToString();
                if (objOptyNQuoteInfo.FormattedValues.Contains("niq_opportunitytype"))
                    opty.OpportunityRecordType = objOptyNQuoteInfo.FormattedValues["niq_opportunitytype"].ToString();
                if (objOptyNQuoteInfo.Contains("niq_stage"))
                    opty.Stage = objOptyNQuoteInfo["niq_stage"].ToString();
                if (objOptyNQuoteInfo.Contains("transactioncurrency.isocurrencycode"))
                    opty.AmountCurrency = (objOptyNQuoteInfo["transactioncurrency.isocurrencycode"] as AliasedValue).Value.ToString();
                if (objOptyNQuoteInfo.Contains("quote.totalamount"))
                {
                    opty.Amount = Convert.ToDecimal(((objOptyNQuoteInfo["quote.totalamount"] as AliasedValue).Value as Money).Value);
                    opty.AmountUSD = Convert.ToDecimal(((objOptyNQuoteInfo["quote.totalamount_base"] as AliasedValue).Value as Money).Value);
                }
                if (objOptyNQuoteInfo.FormattedValues.Contains("niq_closeprobability"))
                    opty.Probability = int.Parse(objOptyNQuoteInfo.FormattedValues["niq_closeprobability"].ToString().Replace("%", ""));
                if (objOptyNQuoteInfo.Contains("quote.niq_contractstartdate"))
                    opty.StartofDelivery = Convert.ToDateTime((objOptyNQuoteInfo["quote.niq_contractstartdate"] as AliasedValue).Value);
                if (objOptyNQuoteInfo.Contains("quote.niq_contractenddate"))
                    opty.EndofDelivery = Convert.ToDateTime((objOptyNQuoteInfo["quote.niq_contractenddate"] as AliasedValue).Value);
                opty.CreatedDate = Convert.ToDateTime(objOptyNQuoteInfo["createdon"]);
                if (objOptyNQuoteInfo.Contains("estimatedclosedate"))
                    opty.CloseDate = Convert.ToDateTime(objOptyNQuoteInfo["estimatedclosedate"]);
                opty.LastModifiedDate = Convert.ToDateTime(objOptyNQuoteInfo["modifiedon"]);
                if (objOptyNQuoteInfo.FormattedValues.Contains("niq_contractdecision"))
                    opty.ContractType = objOptyNQuoteInfo.FormattedValues["niq_contractdecision"].ToString();
                if (objOptyNQuoteInfo.Contains("niq_salesorg.niq_salesorgcode"))
                    opty.SalesOrgcode = (objOptyNQuoteInfo["niq_salesorg.niq_salesorgcode"] as AliasedValue).Value.ToString();
                if (objOptyNQuoteInfo.Contains("niq_salesorg.niq_name"))
                    opty.SalesOrgName = (objOptyNQuoteInfo["niq_salesorg.niq_name"] as AliasedValue).Value.ToString();
                if (objOptyNQuoteInfo.FormattedValues.Contains("niq_fieldingcountryci"))
                    opty.FieldingCountryCI = objOptyNQuoteInfo.FormattedValues["niq_fieldingcountryci"].ToString();
                opty.isClosed = (objOptyNQuoteInfo.FormattedValues["statecode"].ToString() == "Open") ? false : true;
                if (objOptyNQuoteInfo.Contains("niq_sapsalesdocumentid"))
                    opty.SalesDocumentId = objOptyNQuoteInfo["niq_sapsalesdocumentid"].ToString();

                opty.accountDetails = new AccountInfo()
                {
                    AccountName = (objOptyNQuoteInfo["account.name"] as AliasedValue).Value.ToString(),
                    Industry = (objOptyNQuoteInfo.FormattedValues.Contains("account.niq_industry")) ? objOptyNQuoteInfo.FormattedValues["account.niq_industry"].ToString() : null
                };

                //Opportunity Team members
                opty.opportunityTeamMemberDetails = this.GetOptyTeamMember(lstOptyTeamMember);
                //Opportunity Contact Roles
                opty.opportunityContactTeamDetails = this.GetOptyContactRoles(lstOptyContactRoles);
                opty.opportunityLineItemDetails = this.GetQuoteProducts(lstQuoteProduct, lstQPCharacteristic, objUtil);
                return opty;
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetResultPayload");
                throw ex;
            }
        }
        private List<OpportunityTeamMember> GetOptyTeamMember(List<Entity> lstOptyTeamMember)
        {
            try
            {
                if (lstOptyTeamMember != null)
                {
                    List<OpportunityTeamMember> lst = new List<OpportunityTeamMember>();
                    foreach (Entity ent in lstOptyTeamMember)
                    {
                        lst.Add(
                          new OpportunityTeamMember()
                          {
                              EmailAddresses = (ent["u.domainname"] as AliasedValue).Value.ToString(),
                              Names = (ent["u.fullname"] as AliasedValue).Value.ToString()
                          }
                          );

                    }
                    return lst;
                }
                return null;
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetOptyTeamMember");
                throw ex;
            }
        }
        private List<OptyContactTeamMember> GetOptyContactRoles(List<Entity> lstOptyContactRoles)
        {
            try
            {
                if (lstOptyContactRoles != null)
                {
                    List<OptyContactTeamMember> lst = new List<OptyContactTeamMember>();
                    string fullname = "";
                    foreach (Entity ent in lstOptyContactRoles)
                    {
                        if (ent.Contains("fullname"))
                        {
                            fullname = ent["fullname"].ToString();
                        }
                        lst.Add(
                          new OptyContactTeamMember()
                          {
                              ContactName = fullname,
                              Role = (ent["con.name"] as AliasedValue).Value.ToString(),
                              EmailAddress = ent.Contains("emailaddress1") ? ent["emailaddress1"].ToString() : null,
                              Firstname = ent.Contains("firstname") ? ent["firstname"].ToString() : null
                          }
                          );

                    }
                    return lst;
                }
                return null;
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetOptyContactRoles");
                throw ex;
            }
        }

        private List<QuoteLineItem> GetQuoteProducts(List<Entity> lstQuoteProduct, List<Entity> lstQPCharacteristic, Utility objUtil)
        {
            try
            {
                if (lstQuoteProduct != null && lstQuoteProduct.Count > 0)
                {
                    var lst = new List<QuoteLineItem>();
                    foreach (var item in lstQuoteProduct)
                    {
                        QuoteLineItem qp = new QuoteLineItem();
                        if (item.Contains("productid"))
                        {
                            qp.PracticeArea = objUtil.GetRecordbyId((item["productid"] as EntityReference).LogicalName, (item["productid"] as EntityReference).Id, new string[] { "hierarchypath" })["hierarchypath"].ToString();
                        }

                        qp.OpportunityLineItemID = item.Id.ToString();
                        if (item.Contains("productnumber"))
                            qp.MaterialID = item["productnumber"].ToString();
                        if (item.Contains("productname"))
                            qp.ProductDescription = item["productname"].ToString();
                        if (item.Contains("niq_projectid"))
                            qp.ProjectID = item["niq_projectid"].ToString();
                        qp.TotalPriceUSD = (item["extendedamount_base"] as Money).Value;
                        if (item.Contains("prod.name"))
                            qp.SubBrand = (item["prod.name"] as AliasedValue).Value.ToString();
                        if (item.Contains("niq_glaccountid"))
                            qp.GLAccount = (item["niq_glaccountid"] as EntityReference).Name;
                        if (item.Contains("niq_profitcentreid"))
                            qp.ProfitCentre = (item["niq_profitcentreid"] as EntityReference).Name;
                        if (item.Contains("niq_wbs"))
                            qp.WBSNumber = item["niq_wbs"].ToString();
                        if (item.Contains("niq_expectedthirdpartycost"))
                            qp.ExpectedThirdPartyCost = (item["niq_expectedthirdpartycost"] as Money).Value;
                        if (item.Contains("niq_lineitemstartdate"))
                            qp.StartDate = Convert.ToDateTime(item["niq_lineitemstartdate"]);
                        if (item.Contains("niq_lineitemenddate"))
                            qp.EndDate = Convert.ToDateTime(item["niq_lineitemenddate"]);
                        if (item.Contains("quotedetailname"))
                            qp.QuoteDetailName = item["quotedetailname"].ToString();
                        if (item.Contains("niq_reconciliationamount"))
                            qp.ReconciliationAmount = (item["niq_reconciliationamount"] as Money).Value;
                        qp.CharacteristicValues = this.GetQPCharacteristic(item.Id, lstQPCharacteristic);
                        lst.Add(qp);


                    }
                    return lst;
                }
                return null;
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetQuoteProducts");
                throw ex;
            }
        }

        private QuoteProductCharacteristic GetQPCharacteristic(Guid quoteProductId, List<Entity> lstQPCharacteristic)
        {
            try
            {
                if (lstQPCharacteristic != null && lstQPCharacteristic.Count > 0)
                {
                    var lstCharVal = lstQPCharacteristic.Where(f => (f["niq_quoteproductid"] as EntityReference).Id.Equals(quoteProductId)).ToList();
                    if (lstCharVal != null && lstCharVal.Count > 0)
                    {

                        var QPChar = new QuoteProductCharacteristic();
                        foreach (var item in lstCharVal)
                        {
                            if ((item["char.niq_characteristiccode"] as AliasedValue).Value.ToString() == "Z_DATATYPE")
                            {
                                QPChar.Z_DATATYPE = new List<string>(){
                                        (item["charval.niq_characteristicvaluedescription"] as AliasedValue).Value.ToString() };
                            }
                            if ((item["char.niq_characteristiccode"] as AliasedValue).Value.ToString() == "Z_FIELDINGMETHOD")
                            {
                                QPChar.Z_FIELDINGMETHOD = new List<string>() {
                                         (item["charval.niq_characteristicvaluedescription"] as AliasedValue).Value.ToString() };
                            }
                            if ((item["char.niq_characteristiccode"] as AliasedValue).Value.ToString() == "Z_FREQUENCY")
                            {
                                QPChar.Z_FREQUENCY = new List<string>() {
                                        (item["charval.niq_characteristicvaluedescription"] as AliasedValue).Value.ToString() };

                            }
                            if ((item["char.niq_characteristiccode"] as AliasedValue).Value.ToString() == "Z_MULTI-COUNTRY")
                            {
                                QPChar.Z_MULTI_COUNTRY = new List<string>() {
                                         (item["charval.niq_characteristicvaluedescription"] as AliasedValue).Value.ToString() };
                            }
                        }
                        return QPChar;
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetQPCharacteristic");
                throw ex;
            }
        }

        //object
        #region Classes
        public class Opportunity
        {
            public string successMessage { get; set; }
            public string errorMessage { get; set; }
            public string OpportunityID { get; set; }
            public Boolean isDev { get; set; }
            public string OpportunityNumber { get; set; }
            public string OpportunityName { get; set; }
            public string OpportunityOwnerEmail { get; set; }
            public string OpportunityOwnerName { get; set; }
            public string OpportunityRecordType { get; set; }
            public string AmountCurrency { get; set; }
            public Decimal Amount { get; set; }
            public Decimal AmountUSD { get; set; }
            public string Stage { get; set; }
            public int Probability { get; set; }
            public DateTime StartofDelivery { get; set; }
            public DateTime EndofDelivery { get; set; }
            public DateTime CreatedDate { get; set; }
            public DateTime CloseDate { get; set; }
            public DateTime LastModifiedDate { get; set; }
            public string ContractType { get; set; }
            public string SalesOrgcode { get; set; }
            public string SalesOrgName { get; set; }
            public string FieldingCountryCI { get; set; }
            public Boolean isClosed { get; set; }
            public string SalesDocumentId { get; set; }
            public AccountInfo accountDetails;
            public List<OpportunityTeamMember> opportunityTeamMemberDetails;
            public List<QuoteLineItem> opportunityLineItemDetails;
            public List<OptyContactTeamMember> opportunityContactTeamDetails;
        }
        public class AccountInfo
        {
            public string AccountName { get; set; }
            public string Industry { get; set; }
        }
        public class QuoteLineItem
        {

            public string OpportunityLineItemID { get; set; }
            public string MaterialID { get; set; }
            public string ProductDescription { get; set; }
            public string PracticeArea { get; set; }
            public string SubBrand { get; set; }
            public string GLAccount { get; set; }
            public string ProfitCentre { get; set; }
            public string ProjectID { get; set; }
            public decimal TotalPriceUSD { get; set; }

            public string WBSNumber { get; set; }
            public decimal ReconciliationAmount { get; set; }
            public string QuoteDetailName { get; set; }

            public decimal ExpectedThirdPartyCost { get; set; }
            public DateTime StartDate { get; set; }
            public DateTime EndDate { get; set; }
            public QuoteProductCharacteristic CharacteristicValues;

        }
        public class QuoteProductCharacteristic
        {
            public List<String> Z_DATATYPE;
            public List<String> Z_FIELDINGMETHOD;
            public List<String> Z_FREQUENCY;
            public List<String> Z_MULTI_COUNTRY;
        }
        public class OpportunityTeamMember
        {
            public string Names { get; set; }
            public string EmailAddresses { get; set; }
        }

        public class OptyContactTeamMember
        {
            public string ContactName { get; set; }
            public string Firstname { get; set; }
            public string EmailAddress { get; set; }
            public string Role { get; set; }
        }
        #endregion
    }


}
