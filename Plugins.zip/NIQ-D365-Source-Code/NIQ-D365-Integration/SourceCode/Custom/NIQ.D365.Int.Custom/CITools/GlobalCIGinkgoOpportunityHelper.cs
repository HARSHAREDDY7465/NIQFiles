﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NIQ.D365.Int.Custom.CITools
{
    public class GlobalCIGinkgoOpportunityHelper
    {
        private ITracingService tracingService;
        public GlobalCIGinkgoOpportunityHelper(ITracingService tracingService)
        {
            this.tracingService = tracingService;
        }

        public Opportunity GetResultPayload(Entity objOptyNQuoteInfo, List<Entity> lstQuoteProduct, List<Entity> lstOptyTeamMember, List<Entity> lstQPCharacteristic, List<Entity> lstAccTeamMember, bool isdev, string instanceurl)
        {

            Opportunity opty = new Opportunity();
            try
            {
                opty.successMessage = "SUCCESS";
                opty.OpportunityID = objOptyNQuoteInfo.Id.ToString();
                opty.errorMessage = null;
                opty.isDev = isdev;
                opty.OpportunityURLlink = instanceurl + objOptyNQuoteInfo.Id.ToString();
                if (objOptyNQuoteInfo.Contains("niq_opportunitynumber"))
                    opty.OpportunityNumber = objOptyNQuoteInfo["niq_opportunitynumber"].ToString().Trim();
                if (objOptyNQuoteInfo.Contains("name"))
                    opty.OpportunityName = objOptyNQuoteInfo["name"].ToString().Trim();
                if (objOptyNQuoteInfo.Contains("owner.fullname"))
                    opty.OpportunityOwnerName = (objOptyNQuoteInfo["owner.fullname"] as AliasedValue).Value.ToString();
                if (objOptyNQuoteInfo.Contains("owner.domainname"))
                    opty.OpportunityOwnerEmail = (objOptyNQuoteInfo["owner.domainname"] as AliasedValue).Value.ToString();
                if (objOptyNQuoteInfo.FormattedValues.Contains("niq_opportunitytype"))
                    opty.OpportunityType = objOptyNQuoteInfo.FormattedValues["niq_opportunitytype"].ToString();
                if (objOptyNQuoteInfo.Contains("niq_stage"))
                    opty.Stage = objOptyNQuoteInfo["niq_stage"].ToString();
                if (objOptyNQuoteInfo.Contains("transactioncurrency.isocurrencycode"))
                    opty.OpportunityCurrency = (objOptyNQuoteInfo["transactioncurrency.isocurrencycode"] as AliasedValue).Value.ToString();
                if (objOptyNQuoteInfo.Contains("quote.totalamount"))
                    opty.Amount = Convert.ToDecimal(((objOptyNQuoteInfo["quote.totalamount"] as AliasedValue).Value as Money).Value);
                if (objOptyNQuoteInfo.FormattedValues.Contains("niq_closeprobability"))
                    opty.Probability = int.Parse(objOptyNQuoteInfo.FormattedValues["niq_closeprobability"].ToString().Replace("%", ""));
                if (objOptyNQuoteInfo.Contains("quote.niq_contractstartdate"))
                    opty.StartofDelivery = Convert.ToDateTime((objOptyNQuoteInfo["quote.niq_contractstartdate"] as AliasedValue).Value);
                if (objOptyNQuoteInfo.Contains("quote.niq_contractenddate"))
                    opty.EndofDelivery = Convert.ToDateTime((objOptyNQuoteInfo["quote.niq_contractenddate"] as AliasedValue).Value);
                if (objOptyNQuoteInfo.Contains("estimatedclosedate"))
                    opty.CloseDate = Convert.ToDateTime(objOptyNQuoteInfo["estimatedclosedate"]);
                if (objOptyNQuoteInfo.Contains("niq_salesorg.niq_salesorgcode"))
                    opty.SalesOrgcode = (objOptyNQuoteInfo["niq_salesorg.niq_salesorgcode"] as AliasedValue).Value.ToString();
                if (objOptyNQuoteInfo.Contains("niq_salesorg.niq_name"))
                    opty.SalesOrgName = (objOptyNQuoteInfo["niq_salesorg.niq_name"] as AliasedValue).Value.ToString();
                if (objOptyNQuoteInfo.Contains("niq_name.niq_salesgroup"))
                    opty.SalesGroup = (objOptyNQuoteInfo["niq_name.niq_salesgroup"] as AliasedValue).Value.ToString();
                if (objOptyNQuoteInfo.Contains("sp.name"))
                    opty.SoldToParty = (objOptyNQuoteInfo["sp.name"] as AliasedValue).Value.ToString();
                if (objOptyNQuoteInfo.Contains("bp.name"))
                    opty.BillToParty = (objOptyNQuoteInfo["bp.name"] as AliasedValue).Value.ToString();
                if (objOptyNQuoteInfo.Contains("dp.name"))
                    opty.DeliverToParty = (objOptyNQuoteInfo["dp.name"] as AliasedValue).Value.ToString();
                if (objOptyNQuoteInfo.Contains("description"))
                    opty.Outlineofsolutiondesign = objOptyNQuoteInfo["description"].ToString().Trim();
                opty.CreatedDate = Convert.ToDateTime(objOptyNQuoteInfo["createdon"]);

                opty.accountDetails = new AccountInfo()
                {
                    AccountName = (objOptyNQuoteInfo["account.name"] as AliasedValue).Value.ToString(),
                    Industry = objOptyNQuoteInfo.FormattedValues.Contains("account.niq_industry") ? objOptyNQuoteInfo.FormattedValues["account.niq_industry"].ToString() : null,
                    AccountOwnerEmail = objOptyNQuoteInfo.Contains("accountsystemuser.domainname") ? (objOptyNQuoteInfo["accountsystemuser.domainname"] as AliasedValue).Value.ToString() : null,
                    AccountOwnerName = objOptyNQuoteInfo.Contains("accountsystemuser.fullname") ? (objOptyNQuoteInfo["accountsystemuser.fullname"] as AliasedValue).Value.ToString() : null,
                    accountTeamMemberDetails = this.GetAccountTeamMember(lstAccTeamMember)
                };

                //Opportunity Team members
                opty.opportunityTeamMemberDetails = this.GetOptyTeamMember(lstOptyTeamMember);
                opty.opportunityLineItemDetails = this.GetQuoteProducts(lstQuoteProduct, lstQPCharacteristic);
                return opty;
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetResultPayload");
                throw ex;
            }
        }
        private List<OpportunityTeamMember> GetOptyTeamMember(List<Entity> lstOptyTeamMember)
        {
            try
            {
                if (lstOptyTeamMember != null)
                {
                    List<OpportunityTeamMember> lst = new List<OpportunityTeamMember>();
                    foreach (Entity ent in lstOptyTeamMember)
                    {
                        lst.Add(
                          new OpportunityTeamMember()
                          {
                              EmailAddresses = (ent["u.domainname"] as AliasedValue).Value.ToString(),
                              Names = (ent["u.fullname"] as AliasedValue).Value.ToString()
                          }
                          );

                    }
                    return lst;
                }
                return null;
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetOptyTeamMember");
                throw ex;
            }
        }

        private List<AccountTeamMember> GetAccountTeamMember(List<Entity> lstAccountTeamMember)
        {
            try
            {
                if (lstAccountTeamMember != null)
                {
                    List<AccountTeamMember> lst = new List<AccountTeamMember>();
                    foreach (Entity ent in lstAccountTeamMember)
                    {
                        lst.Add(
                          new AccountTeamMember()
                          {
                              EmailAddresses = (ent["u.domainname"] as AliasedValue).Value.ToString(),
                              Names = (ent["u.fullname"] as AliasedValue).Value.ToString()
                          }
                          );

                    }
                    return lst;
                }
                return null;
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetAccountTeamMember");
                throw ex;
            }
        }

        private List<QuoteLineItem> GetQuoteProducts(List<Entity> lstQuoteProduct, List<Entity> lstQPCharacteristic)
        {
            try
            {
                if (lstQuoteProduct != null && lstQuoteProduct.Count > 0)
                {
                    var lst = new List<QuoteLineItem>();
                    foreach (var item in lstQuoteProduct)
                    {
                        QuoteLineItem qp = new QuoteLineItem();

                        qp.OpportunityLineItemID = item.Id.ToString();
                        qp.Product = item["productname"].ToString();
                        qp.MaterialID = item["productnumber"].ToString();
                        if (item.Contains("productid"))
                            qp.ProductID = ((EntityReference)item["productid"]).Id.ToString();
                        qp.TotalValue = (item["baseamount"] as Money).Value;
                        if (item.Contains("niq_lineitemstartdate"))
                            qp.StartDate = Convert.ToDateTime(item["niq_lineitemstartdate"]);
                        if (item.Contains("niq_lineitemenddate"))
                            qp.EndDate = Convert.ToDateTime(item["niq_lineitemenddate"]);
                        qp.PracticeArea = (item["p.hierarchypath"] as AliasedValue).Value.ToString();
                        if (item.Contains("p2.name"))
                            qp.SubBrand = (item["p2.name"] as AliasedValue).Value.ToString();
                        if (item.Contains("niq_invoicetext"))
                            qp.Invoicetext = item["niq_invoicetext"].ToString();
                        if (item.Contains("niq_projectid"))
                            qp.ProjectID = item["niq_projectid"].ToString();
                        if (item.Contains("niq_deliveryfrequency"))
                            qp.DeliveryFrequency = item.FormattedValues.Contains("niq_deliveryfrequency") ? item.FormattedValues["niq_deliveryfrequency"].ToString() : null;
                        if (item.Contains("niq_lagrevenuerecognition"))
                            qp.LagRevenueRecognition = item.FormattedValues.Contains("niq_lagrevenuerecognition") ? item.FormattedValues["niq_lagrevenuerecognition"].ToString() : null;
                        if (item.Contains("niq_wbs"))
                            qp.WBS = item["niq_wbs"].ToString();

                        qp.CharacteristicValues = this.GetQPCharacteristic(item.Id, lstQPCharacteristic);
                        lst.Add(qp);


                    }
                    return lst;
                }
                return null;
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetQuoteProducts");
                throw ex;
            }
        }

        private List<QuoteProductCharacteristic> GetQPCharacteristic(Guid quoteProductId, List<Entity> lstQPCharacteristic)
        {
            try
            {
                List<QuoteProductCharacteristic> lstQPChar = new List<QuoteProductCharacteristic>();

                if (lstQPCharacteristic != null && lstQPCharacteristic.Count > 0)
                {
                    var lstCharVal = lstQPCharacteristic.Where(f => (f["niq_quoteproductid"] as EntityReference).Id.Equals(quoteProductId)).ToList();
                    if (lstCharVal != null && lstCharVal.Count > 0)
                    {

                        var QPChar = new QuoteProductCharacteristic();
                        foreach (var item in lstCharVal)
                        {
                            if ((item["char.niq_characteristiccode"] as AliasedValue).Value.ToString() == "Z_SERVICES")
                            {
                                QPChar.SERVICES = (item["charval.niq_characteristicvaluedescription"] as AliasedValue).Value.ToString();
                            }
                            if ((item["char.niq_characteristiccode"] as AliasedValue).Value.ToString() == "Z_FIELDINGMETHOD")
                            {
                                QPChar.FIELDINGMETHOD = (item["charval.niq_characteristicvaluedescription"] as AliasedValue).Value.ToString();
                            }
                            if ((item["char.niq_characteristiccode"] as AliasedValue).Value.ToString() == "Z_MULTI-COUNTRY")
                            {
                                QPChar.MULTI_COUNTRY = (item["charval.niq_characteristicvaluedescription"] as AliasedValue).Value.ToString();
                            }

                        }
                        //return QPChar;
                        lstQPChar.Add(QPChar);
                        return lstQPChar;
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetQPCharacteristic");
                throw ex;
            }
        }
        //object
        #region Classes
        public class Opportunity
        {
            public string successMessage { get; set; }
            public string errorMessage { get; set; }
            public string OpportunityID { get; set; }
            public Boolean isDev { get; set; }
            public string OpportunityNumber { get; set; }
            public string OpportunityName { get; set; }
            public string OpportunityOwnerEmail { get; set; }
            public string OpportunityOwnerName { get; set; }
            public string OpportunityType { get; set; }
            public string OpportunityCurrency { get; set; }
            public Decimal Amount { get; set; }
            public string Outlineofsolutiondesign { get; set; }
            public string OpportunityURLlink { get; set; }

            public string Stage { get; set; }
            public int Probability { get; set; }
            public DateTime StartofDelivery { get; set; }
            public DateTime EndofDelivery { get; set; }
            public DateTime CreatedDate { get; set; }
            public DateTime CloseDate { get; set; }
            public string SalesOrgcode { get; set; }
            public string SalesOrgName { get; set; }
            public string SalesGroup { get; set; }
            public string SoldToParty { get; set; }
            public string BillToParty { get; set; }
            public string DeliverToParty { get; set; }

            public AccountInfo accountDetails;
            public List<OpportunityTeamMember> opportunityTeamMemberDetails;
            public List<QuoteLineItem> opportunityLineItemDetails;
            //public List<AccountTeamMember> accountTeamMemberDetails;
        }
        public class AccountInfo
        {
            public string AccountName { get; set; }
            public string Industry { get; set; }
            public string AccountOwnerName { get; set; }
            public string AccountOwnerEmail { get; set; }
            public List<AccountTeamMember> accountTeamMemberDetails;
        }
        public class QuoteLineItem
        {
            public string OpportunityLineItemID { get; set; }
            public string MaterialID { get; set; }
            public string Product { get; set; }
            public string PracticeArea { get; set; }
            public string SubBrand { get; set; }
            public string ProductID { get; set; }
            public Decimal TotalValue { get; set; }
            public string ProjectID { get; set; }
            public string Invoicetext { get; set; }
            public string DeliveryFrequency { get; set; }
            public string LagRevenueRecognition { get; set; }
            public string WBS { get; set; }
            public DateTime StartDate { get; set; }
            public DateTime EndDate { get; set; }
            //public QuoteProductCharacteristic CharacteristicValues;
            public List<QuoteProductCharacteristic> CharacteristicValues;
        }
        public class QuoteProductCharacteristic
        {
            //public List<String> SERVICES;
            //public List<String> FIELDINGMETHOD;
            //public List<String> MULTI_COUNTRY;
            public string SERVICES;
            public string FIELDINGMETHOD;
            public string MULTI_COUNTRY;
        }
        public class OpportunityTeamMember
        {
            public string Names { get; set; }
            public string EmailAddresses { get; set; }
        }

        public class AccountTeamMember
        {
            public string Names { get; set; }
            public string EmailAddresses { get; set; }
        }
        #endregion
    }


}
