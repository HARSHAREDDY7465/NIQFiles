﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NIQ.D365.Int.Custom.CITools
{
    public class GlobalCIQuoteLineItemHelper
    {
        private ITracingService tracingService;
        public GlobalCIQuoteLineItemHelper(ITracingService tracingService)
        {
            this.tracingService = tracingService;
        }

        public List<QuoteLineItem> GetResultPayload(List<Entity> lstQuoteProduct, List<Entity> lstOptyTeamMember, List<Entity> lstQPCharacteristic, string instanceurl, string practiceArea)
        {

            List<QuoteLineItem> lstQP = new List<QuoteLineItem>();

            try
            {
                foreach (var itemQP in lstQuoteProduct)
                {
                    QuoteLineItem quoteproduct = new QuoteLineItem();
                    if (itemQP.Contains("productid"))
                    {
                        quoteproduct.PracticeArea = practiceArea;
                    }

                    string optyid = (itemQP["opty.opportunityid"] as AliasedValue).Value.ToString();
                    quoteproduct.successMessage = "SUCCESS";
                    quoteproduct.OpportunityURLlink = instanceurl + optyid;
                    quoteproduct.QuoteLineItemID = itemQP.Id.ToString();
                    if (itemQP.Contains("productnumber"))
                        quoteproduct.MaterialID = itemQP["productnumber"].ToString();
                    if (itemQP.FormattedValues.Contains("opty.niq_opportunitytype"))
                        quoteproduct.OpportunityType = itemQP.FormattedValues["opty.niq_opportunitytype"].ToString();
                    if (itemQP.Contains("opty.niq_opportunitynumber"))
                        quoteproduct.OpportunityNumber = (itemQP["opty.niq_opportunitynumber"] as AliasedValue).Value.ToString();
                    if (itemQP.Contains("opty.name"))
                        quoteproduct.OpportunityName = (itemQP["opty.name"] as AliasedValue).Value.ToString();
                    if (itemQP.Contains("owner.fullname"))
                        quoteproduct.OpportunityOwner = (itemQP["owner.fullname"] as AliasedValue).Value.ToString();
                    if (itemQP.Contains("owner.domainname"))
                        quoteproduct.OpportunityOwnerEmail = (itemQP["owner.domainname"] as AliasedValue).Value.ToString();
                    if (itemQP.FormattedValues.Contains("opty.niq_closeprobability"))
                        quoteproduct.Probability = int.Parse(itemQP.FormattedValues["opty.niq_closeprobability"].ToString().Replace("%", ""));
                    if (itemQP.FormattedValues.Contains("opty.niq_fieldingcountryci"))
                        quoteproduct.FieldingCountryCI = itemQP.FormattedValues["opty.niq_fieldingcountryci"].ToString();
                    if (itemQP.FormattedValues.Contains("opty.parentaccountid"))
                        quoteproduct.AccountName = itemQP.FormattedValues["opty.parentaccountid"].ToString();
                    if (itemQP.FormattedValues.Contains("opty.niq_salesgroupid"))
                        quoteproduct.Salesgroup = itemQP.FormattedValues["opty.niq_salesgroupid"].ToString();
                    if (itemQP.Contains("opty.description"))
                        quoteproduct.Outlineofsolutiondesign = (itemQP["opty.description"] as AliasedValue).Value.ToString();
                    quoteproduct.ProjectID = itemQP["niq_projectid"].ToString();
                    if (itemQP.Contains("niq_invoicetext"))
                        quoteproduct.Invoicetext = itemQP["niq_invoicetext"].ToString();
                    if (itemQP.Contains("extendedamount"))
                        quoteproduct.Productamount = (itemQP["extendedamount"] as Money).Value;
                    if (itemQP.Contains("productnumber"))
                        quoteproduct.Product = itemQP["productnumber"].ToString();
                    if (itemQP.Contains("niq_lineitemstartdate"))
                        quoteproduct.StartDate = Convert.ToDateTime(itemQP["niq_lineitemstartdate"]);
                    if (itemQP.Contains("niq_lineitemenddate"))
                        quoteproduct.Enddate = Convert.ToDateTime(itemQP["niq_lineitemenddate"]);
                    if (itemQP.Contains("currency.isocurrencycode"))
                        quoteproduct.OpportunityCurrency = (itemQP["currency.isocurrencycode"] as AliasedValue).Value.ToString();
                    if (itemQP.Contains("niq_wbs"))
                        quoteproduct.WBS = itemQP["niq_wbs"].ToString();
                    if (itemQP.Contains("opty.niq_stage"))
                        quoteproduct.OpportunityStage = (itemQP["opty.niq_stage"] as AliasedValue).Value.ToString();
                    if (itemQP.Contains("prod.name"))
                        quoteproduct.SubBrand = (itemQP["prod.name"] as AliasedValue).Value.ToString();
                    if (itemQP.Contains("niq_profitcentreid"))
                        quoteproduct.ProfitCentre = (itemQP["niq_profitcentreid"] as EntityReference).Name;
                    if (itemQP.Contains("niq_expectedthirdpartycost"))
                        quoteproduct.ExpectedThirdPartyCost = (itemQP["niq_expectedthirdpartycost"] as Money).Value;
                    if (itemQP.Contains("niq_glaccountid"))
                        quoteproduct.GLAccount = (itemQP["niq_glaccountid"] as EntityReference).Name;
                    if (itemQP.Contains("niq_reconciliationamount"))
                        quoteproduct.ReconciliationAmount = (itemQP["niq_reconciliationamount"] as Money).Value;
                    if (itemQP.Contains("extendedamount_base"))
                        quoteproduct.TotalPriceUSD = (itemQP["extendedamount_base"] as Money).Value;
                    if (itemQP.Contains("quotedetailname"))
                        quoteproduct.QuoteDetailName = itemQP["quotedetailname"].ToString();
                    if (itemQP.Contains("productname"))
                        quoteproduct.ProductDescription = itemQP["productname"].ToString();




                    quoteproduct.opportunityTeamMemberDetails = this.GetOptyTeamMember(optyid, lstOptyTeamMember);
                    quoteproduct.CharacteristicValues = this.GetQPCharacteristic(itemQP.Id, lstQPCharacteristic, quoteproduct);

                    lstQP.Add(quoteproduct);
                }

                return lstQP;
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetResultPayload");
                throw ex;
            }
        }
        private List<OpportunityTeamMember> GetOptyTeamMember(string opporuntiyid, List<Entity> lstOptyTeamMember)
        {
            try
            {
                if (lstOptyTeamMember != null)
                {
                    List<Entity> lstTeamMember = lstOptyTeamMember.Where(f => (f["opportunity.opportunityid"] as AliasedValue).Value.ToString().Equals(opporuntiyid)).ToList();
                    if (lstTeamMember != null && lstTeamMember.Count > 0)
                    {
                        List<OpportunityTeamMember> lst = new List<OpportunityTeamMember>();
                        foreach (Entity ent in lstTeamMember)
                        {
                            lst.Add(
                              new OpportunityTeamMember()
                              {
                                  EmailAddresses = (ent["u.domainname"] as AliasedValue).Value.ToString(),
                                  Names = (ent["u.fullname"] as AliasedValue).Value.ToString()
                              }
                              );
                        }
                        return lst;
                    }

                }
                return null;
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetOptyTeamMember");
                throw ex;
            }
        }

        private QuoteProductCharacteristic GetQPCharacteristic(Guid quoteProductId, List<Entity> lstQPCharacteristic, QuoteLineItem quoteProduct)
        {
            try
            {
                if (lstQPCharacteristic != null && lstQPCharacteristic.Count > 0)
                {
                    var lstCharVal = lstQPCharacteristic.Where(f => (f["niq_quoteproductid"] as EntityReference).Id.Equals(quoteProductId)).ToList();
                    if (lstCharVal != null && lstCharVal.Count > 0)
                    {
                        // var lst = new List<QuoteProductCharacteristic>();
                        QuoteProductCharacteristic qpChar = new QuoteProductCharacteristic();
                        foreach (var item in lstCharVal)
                        {
                            if ((item["char.niq_characteristiccode"] as AliasedValue).Value.ToString() == "Z_FIELDINGMETHOD")
                            {
                                quoteProduct.Fieldingmethod = (item["charval.niq_characteristicvaluedescription"] as AliasedValue).Value.ToString();
                            }
                            if ((item["char.niq_characteristiccode"] as AliasedValue).Value.ToString() == "Z_SERVICES")
                            {
                                qpChar.Z_SERVICES = new List<string>() {
                                        (item["charval.niq_characteristicvaluedescription"] as AliasedValue).Value.ToString() };
                            }
                            if ((item["char.niq_characteristiccode"] as AliasedValue).Value.ToString() == "Z_MULTI-COUNTRY")
                            {
                                qpChar.Z_MULTI_COUNTRY = new List<string>() {
                                         (item["charval.niq_characteristicvaluedescription"] as AliasedValue).Value.ToString() };
                            }
                        }
                        return qpChar;
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetQPCharacteristic");
                throw ex;
            }
        }


        //object
        #region Classes
        public class QuoteLineItem
        {
            public string successMessage { get; set; }
            public string errorMessage { get; set; }
            public string QuoteLineItemID { get; set; }
            public string OpportunityType { get; set; }
            public string OpportunityNumber { get; set; }
            public string OpportunityName { get; set; }
            public string OpportunityOwner { get; set; }
            public string OpportunityOwnerEmail { get; set; }
            public Decimal Probability { get; set; }
            public string FieldingCountryCI { get; set; }
            public string AccountName { get; set; }
            public string Salesgroup { get; set; }
            public string OpportunityURLlink { get; set; }
            public string Outlineofsolutiondesign { get; set; }
            public string ProjectID { get; set; }
            public string Invoicetext { get; set; }
            public Decimal Productamount { get; set; }
            public string Fieldingmethod { get; set; }
            public string Product { get; set; }
            public DateTime StartDate { get; set; }
            public DateTime Enddate { get; set; }
            public string OpportunityCurrency { get; set; }
            public string OpportunityStage { get; set; }
            public string WBS { get; set; }
            public string MaterialID { get; set; }
            public decimal TotalPriceUSD { get; set; }
            public string SubBrand { get; set; }
            public string PracticeArea { get; set; }
            public string GLAccount { get; set; }
            public decimal ReconciliationAmount { get; set; }
            public string ProfitCentre { get; set; }
            public string ProductDescription { get; set; }
            public string QuoteDetailName { get; set; }
            public decimal ExpectedThirdPartyCost { get; set; }
            public QuoteProductCharacteristic CharacteristicValues;
            public List<OpportunityTeamMember> opportunityTeamMemberDetails;

        }
        public class QuoteProductCharacteristic
        {
            public List<String> Z_SERVICES;
            public List<String> Z_MULTI_COUNTRY;
        }
        public class OpportunityTeamMember
        {
            public string Names { get; set; }
            public string EmailAddresses { get; set; }
        }

        #endregion
    }


}
