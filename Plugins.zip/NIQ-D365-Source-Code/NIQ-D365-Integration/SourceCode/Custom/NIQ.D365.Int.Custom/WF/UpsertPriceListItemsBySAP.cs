﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.ComponentModel;

namespace NIQ.D365.Int.Custom.WF
{
    public class UpsertPriceListItemsBySAP : CodeActivity
    {
        [RequiredArgument]
        [Input("Price List Item Id")]
        public InArgument<string> PriceListItemId { get; set; }


        [Input("GL Account Number")]
        public InArgument<string> GLAccountNumber { get; set; }

        [Input("GL Account Name")]
        public InArgument<string> GLAccountName { get; set; }

        [Input("Blocked")]
        [DefaultValue(false)]
        public InArgument<Boolean> Blocked { get; set; }

        [Input("Item Category Group")]
        public InArgument<int> ItemCategoryGroup { get; set; }

        [RequiredArgument]
        [Input("ProductNumber")]
        public InArgument<string> ProductNumber { get; set; }


        [Input("Profit Centre Code")]
        public InArgument<string> ProfitCentreCode { get; set; }


        [Input("Profit Centre Name")]
        public InArgument<string> ProfitCentreName { get; set; }

        [RequiredArgument]
        [Input("Price List Code")]
        public InArgument<string> PriceListCode { get; set; }


        [Input("Amount")]
        [DefaultValue("0")]
        public InArgument<Decimal> Amount { get; set; }

        [RequiredArgument]
        [Output("Response")]
        [ReferenceTarget("productpricelevel")]
        public OutArgument<EntityReference> Response { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            IWorkflowContext workflowContext = context.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
            ITracingService tracingService = context.GetExtension<ITracingService>();

            try
            {
                if (PriceListItemId.Get(context) == null || (PriceListItemId.Get(context) != null && PriceListItemId.Get(context).Trim().Length <= 0))
                    throw new Exception("PriceListItemId is required and must have proper value.");
                else if (PriceListCode.Get(context) == null || (PriceListCode.Get(context) != null && PriceListCode.Get(context).Trim().Length <= 0))
                    throw new Exception("PriceListCode is required and must have proper value.");
                else if (ProductNumber.Get(context) == null || (ProductNumber.Get(context) != null && ProductNumber.Get(context).Trim().Length <= 0))
                    throw new Exception("ProductNumber is required and must have proper value.");
                else
                    this.UpsertPriceListItems(service, tracingService, context);

            }
            catch (Exception ex)
            {
                tracingService.Trace(string.Format("Execute-{0}-{1} ", PriceListItemId.Get(context), ex.Message));
                throw new InvalidPluginExecutionException(OperationStatus.Failed, ex.Message);
            }
        }

        private void UpsertPriceListItems(IOrganizationService service, ITracingService tracingService, CodeActivityContext context)
        {

            Entity entPriceListItems = null;

            try
            {
                tracingService.Trace("Inside UpsertPriceListItems");

                entPriceListItems = new Entity("productpricelevel", "niq_pricelistitemid", PriceListItemId.Get(context));

                entPriceListItems["niq_blocked"] = Blocked.Get(context);
                entPriceListItems["niq_pricelistitemid"] = PriceListItemId.Get(context);
                entPriceListItems["niq_glaccountnumber"] = string.IsNullOrEmpty(GLAccountNumber.Get(context)) ? null : GLAccountNumber.Get(context).Trim();
                entPriceListItems["niq_glaccountname"] = string.IsNullOrEmpty(GLAccountName.Get(context)) ? null : GLAccountName.Get(context).Trim();
                entPriceListItems["niq_profitcentrecode"] = string.IsNullOrEmpty(ProfitCentreCode.Get(context)) ? null : ProfitCentreCode.Get(context).Trim();
                entPriceListItems["niq_profitcentrename"] = string.IsNullOrEmpty(ProfitCentreName.Get(context)) ? null : ProfitCentreName.Get(context).Trim();
                entPriceListItems["niq_itemcategorygroup"] = string.IsNullOrEmpty(ItemCategoryGroup.Get(context).ToString()) ? null : new OptionSetValue(ItemCategoryGroup.Get(context));
                entPriceListItems["amount"] = Convert.ToDecimal(Amount.Get(context));
                entPriceListItems["productid"] = new EntityReference("product", "productnumber", ProductNumber.Get(context));
                entPriceListItems["uomid"] = new EntityReference("uom", "name", "Each");
                entPriceListItems["pricelevelid"] = new EntityReference("pricelevel", "niq_pricelistcode", PriceListCode.Get(context));

                UpsertRequest upsert = new UpsertRequest()
                { Target = entPriceListItems };
                UpsertResponse result = service.Execute(upsert) as UpsertResponse;
                Response.Set(context, result.Target);
                tracingService.Trace(result.Target.Id.ToString());
                tracingService.Trace("End UpsertPriceListItems");
            }
            catch (Exception ex)
            {
                tracingService.Trace("UpsertPriceListItems" + ex.Message);
                throw ex;
            }
        }


    }
}
