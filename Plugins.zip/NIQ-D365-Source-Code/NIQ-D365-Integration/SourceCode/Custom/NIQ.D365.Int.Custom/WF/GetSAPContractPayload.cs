﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using System.Activities.Statements;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Data;
using NIQ.D365.Int.Custom.Class;
using Microsoft.Xrm.Sdk.Query;

namespace NIQ.D365.Int.Custom.WF
{
    public class GetSAPContractPayload : CodeActivity
    {
        [RequiredArgument]
        [Input("OpportunityId")]
        public InArgument<string> OpportunityId { get; set; }

        [RequiredArgument]
        [Input("QuoteNOpty Payload")]
        public InArgument<string> QuoteNOptyPayload { get; set; }

        [RequiredArgument]
        [Input("QuoteDetail Payload")]
        public InArgument<string> QuoteDetailPayload { get; set; }

        [RequiredArgument]
        [Input("QuoteDetail Characteristic Payload")]
        public InArgument<string> QuoteDetailCharPayload { get; set; }

        [RequiredArgument]
        [Input("Item Category Grp Metadata Payload")]
        public InArgument<string> ItemCategoryGrpMtDtPayload { get; set; }

        [RequiredArgument]
        [Input("QuoteDetail Schedules Payload")]
        public InArgument<string> QuoteDetailSchedulePayload { get; set; }

        [RequiredArgument]
        [Output("SAP Contract Payload")]
        public OutArgument<string> SAPContractPayload { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            IWorkflowContext workflowContext = context.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
            ITracingService tracingService = context.GetExtension<ITracingService>();
          
            try
            {

                var jobjQuoteNOptyPayload = JObject.Parse(QuoteNOptyPayload.Get(context));
                var jobjQuoteDetailPayload = JObject.Parse(QuoteDetailPayload.Get(context));
                var jobjQuoteDetailCharPayload = JObject.Parse(QuoteDetailCharPayload.Get(context));
                var jobjItemCtgryGrpMtdtPayload = JObject.Parse(ItemCategoryGrpMtDtPayload.Get(context));
                var jobjQuoteDetailSchedulePayload = JObject.Parse(QuoteDetailSchedulePayload.Get(context));

                //GEtSalesDoctypeMetadata
                List<Entity> lstEntSalesDoctypeMtdt = this.GetSalesDocTypeMetadata(service, tracingService);
                SAPContractHelper objSAPContracthelper = new SAPContractHelper(tracingService, workflowContext.OrganizationName, lstEntSalesDoctypeMtdt);
             
                var strpayload = objSAPContracthelper.BuildSAPContractPayload(jobjQuoteNOptyPayload, jobjQuoteDetailPayload, jobjItemCtgryGrpMtdtPayload, jobjQuoteDetailCharPayload, jobjQuoteDetailSchedulePayload, service);
                SAPContractPayload.Set(context, strpayload);

            }
            catch (Exception ex)
            {
                tracingService.Trace("Execute");
                throw ex;
            }
        }
        private List<Entity> GetSalesDocTypeMetadata( IOrganizationService service,ITracingService tracingService)
        {
            try
            {
                string fetchXml = string.Format(@"<fetch>
                                  <entity name='niq_salesdoctypemetadata'>
                                    <attribute name='niq_country' />
                                    <attribute name='niq_pricingconditiontype' />
                                    <attribute name='niq_salesdocumenttype' />
                                    <attribute name='niq_salesorg' />
                                  </entity>
                                </fetch>");
                EntityCollection objEntity = service.RetrieveMultiple(new FetchExpression(fetchXml));
                if (objEntity != null && objEntity.Entities != null && objEntity.Entities.Count > 0)
                    return objEntity.Entities.ToList();
                return null;

            }
            catch (Exception ex)
            {
                tracingService.Trace("Execute");
                throw ex;
            }
          
        }
    }
}
