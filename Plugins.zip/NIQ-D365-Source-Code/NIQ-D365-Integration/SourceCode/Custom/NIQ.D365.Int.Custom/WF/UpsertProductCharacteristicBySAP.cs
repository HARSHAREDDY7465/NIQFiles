﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.ComponentModel;

namespace NIQ.D365.Int.Custom.WF
{
    public class UpsertProductCharacteristicBySAP : CodeActivity
    {
        [RequiredArgument]
        [Input("Material Characteristic")]
        public InArgument<string> MaterialCharacteristic { get; set; }

        [RequiredArgument]
        [Input("ProductNumber")]
        public InArgument<string> ProductNumber { get; set; }

        [RequiredArgument]
        [Input("Name")]
        public InArgument<string> Name { get; set; }


        [RequiredArgument]
        [Output("Response")]
        [ReferenceTarget("niq_productcharacteristic")]
        public OutArgument<EntityReference> Response { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            IWorkflowContext workflowContext = context.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
            ITracingService tracingService = context.GetExtension<ITracingService>();

            try
            {
                if (Name.Get(context) == null || (Name.Get(context) != null && Name.Get(context).Trim().Length <= 0))
                    throw new Exception("Name is required and must have proper value.");
                else if (ProductNumber.Get(context) == null || (ProductNumber.Get(context) != null && ProductNumber.Get(context).Trim().Length <= 0))
                    throw new Exception("ProductNumber is required and must have proper value.");
                else if (MaterialCharacteristic.Get(context) == null || (MaterialCharacteristic.Get(context) != null && MaterialCharacteristic.Get(context).Trim().Length <= 0))
                    throw new Exception("MaterialCharacteristicCode is required and must have proper value.");
                else
                    this.UpsertProductCharacteristic(service, tracingService, context);
                
            }
            catch (Exception ex)
            {
                tracingService.Trace(string.Format("Execute-{0}-{1} ", Name.Get(context), ex.Message));
                throw new InvalidPluginExecutionException(OperationStatus.Failed, ex.Message);
            }
        }

        private void UpsertProductCharacteristic(IOrganizationService service, ITracingService tracingService, CodeActivityContext context)
        {

            Entity entProductCharacteristic = null;

            try
            {
                tracingService.Trace("Inside UpsertProductCharacteristic");

                entProductCharacteristic = new Entity("niq_productcharacteristic", "niq_name", Name.Get(context));


                entProductCharacteristic["niq_name"] = Name.Get(context);

                entProductCharacteristic["niq_product"] = new EntityReference("product", "productnumber", ProductNumber.Get(context));
               
                entProductCharacteristic["niq_materialcharacteristic"] = new EntityReference("niq_materialcharacteristic", "niq_characteristiccode", MaterialCharacteristic.Get(context));

                UpsertRequest upsert = new UpsertRequest()
                { Target = entProductCharacteristic };
                UpsertResponse result = service.Execute(upsert) as UpsertResponse;
                Response.Set(context, result.Target);
                tracingService.Trace(result.Target.Id.ToString());
                tracingService.Trace("End UpsertProductCharacteristic");
            }
            catch (Exception ex)
            {
                tracingService.Trace("UpsertProductCharacteristic" + ex.Message);
                throw ex;
            }
        }


    }
}
