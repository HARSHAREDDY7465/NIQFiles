﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using System.Activities.Statements;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Data;
using NIQ.D365.Int.Custom.Class;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using System.ComponentModel;
using System.Web;

namespace NIQ.D365.Int.Custom.WF
{
    public class UpsertProductBySAP : CodeActivity
    {
        [RequiredArgument]
        [Input("ProductNumber")]
        public InArgument<string> ProductNumber { get; set; }

        [RequiredArgument]
        [Input("Product Name")]
        public InArgument<string> ProductName { get; set; }

        [Input("Active")]      
        public InArgument<Boolean> Active { get; set; }

        [Input("Parent")]
        public InArgument<string> Parent { get; set; }
        
        [Input("CanUseQuantitySchedule")]
        [DefaultValue(true)]
        public InArgument<Boolean> CanUseQuantitySchedule { get; set; }

     
        [Input("CanUseRevenueSchedule")]
        [DefaultValue(true)]
        public InArgument<Boolean> CanUseRevenueSchedule { get; set; } 

        [RequiredArgument]
        [Input("ProductStructure")]
        public InArgument<string> ProductStructure { get; set; } 

        [RequiredArgument]
        [Output("Response")]
        [ReferenceTarget("product")]
        public OutArgument<EntityReference> Response { get; set; }
     
        protected override void Execute(CodeActivityContext context)
        {
            IWorkflowContext workflowContext = context.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
            ITracingService tracingService = context.GetExtension<ITracingService>();

            try
            {

                if (ProductNumber.Get(context) == null || (ProductNumber.Get(context) != null && ProductNumber.Get(context).Trim().Length <= 0))
                    throw new Exception("BrandCode/SubBrandCode/ProductNumber is required and must have proper value.");
                else if (ProductName.Get(context) == null || (ProductName.Get(context) != null && ProductName.Get(context).Trim().Length <= 0))
                    throw new Exception("BrandName/SubBrandName/ProductName is required and must have proper value.");
                else
                {
                    tracingService.Trace("Productnumber=" + ProductNumber.Get(context).Trim());
                    this.UpsertProduct(service, tracingService, context);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(string.Format("Execute-{0}-{1} ", ProductStructure.Get(context), ex.Message));
                throw new InvalidPluginExecutionException(OperationStatus.Failed, ex.Message);
            }
        }

        private void UpsertProduct(IOrganizationService service, ITracingService tracingService, CodeActivityContext context)
        {

            Entity entProduct = null;
            bool isRequiredUnderRevision = false;
            try
            {
                entProduct = new Entity("product", "productnumber", ProductNumber.Get(context));

                entProduct["productnumber"] = ProductNumber.Get(context);
                entProduct["name"] = ProductName.Get(context);
                entProduct["description"] = ProductName.Get(context);
                if (ProductStructure.Get(context).ToLower() == "product")
                {
                    entProduct["niq_active"] = Active.Get(context);
                    entProduct["niq_quantityschedulingenabled"] = CanUseQuantitySchedule.Get(context);
                    entProduct["niq_revenueschedulingenabled"] = CanUseRevenueSchedule.Get(context);
                    entProduct["defaultuomscheduleid"] = new EntityReference("uomschedule", "name", "Each");
                    entProduct["defaultuomid"] = new EntityReference("uom", "name", "Each");
                    entProduct["productstructure"] = new OptionSetValue(1);
                }
                else entProduct["productstructure"] = new OptionSetValue(2);

                if (ProductStructure.Get(context).ToLower() != "brand")
                {
                    if (Parent.Get(context) != null && Parent.Get(context).Trim().Length > 1)
                        entProduct["parentproductid"] = new EntityReference("product", "productnumber", Parent.Get(context).Trim());
                    else
                        entProduct["parentproductid"] = null;


                    if (IsrequiredToUnderRevision(entProduct, service, tracingService) == true)
                    {
                        isRequiredUnderRevision = true;
                        UpdateStatusandUpdateRecord(entProduct, false, service, tracingService);
                    }
                }

                tracingService.Trace("isRequiredUnderRevision=" + isRequiredUnderRevision);

                UpsertRequest upsert = new UpsertRequest()
                { Target = entProduct };
                UpsertResponse result = service.Execute(upsert) as UpsertResponse;

                if (result.RecordCreated == true || ProductStructure.Get(context).ToLower() == "product")
                {
                    UpdateStatusandUpdateRecord(entProduct, true, service, tracingService);
                }
                else if (ProductStructure.Get(context).ToLower() == "subbrand" && isRequiredUnderRevision == true)
                {
                    PublishProductHierarchyRequest Req = new PublishProductHierarchyRequest
                    {
                        Target = new EntityReference(entProduct.LogicalName, result.Target.Id)
                    };
                    service.Execute(Req);
                }

                Response.Set(context, result.Target);
                tracingService.Trace(result.Target.Id.ToString());
            }
            catch (Exception ex)
            {
                tracingService.Trace("UpsertProduct-" + ex.Message);
                throw ex;
            }
        }
        public void UpdateStatusandUpdateRecord(Entity entProduct, bool isactive, IOrganizationService service, ITracingService tracingService)
        {
            try
            {
                SetStateRequest publishRequest = new SetStateRequest
                {
                    EntityMoniker = new EntityReference(entProduct.LogicalName, "productnumber", entProduct["productnumber"].ToString()),
                    State = new OptionSetValue(isactive ? 0 : 3),
                    Status = new OptionSetValue(isactive ? 1 : 3)
                };
                service.Execute(publishRequest);
            }
            catch (Exception ex)
            {
                tracingService.Trace("UpdateStatusandUpdateRecord");
                throw ex;
            }
        }
        public bool IsrequiredToUnderRevision(Entity entProduct, IOrganizationService service, ITracingService tracingService)
        {
            try
            {
                Utility objUtil = new Utility(service, tracingService);
                string strFetchXml = string.Format(@"<fetch><entity name='product'>
                                            <attribute name='statecode' />
                                    <link-entity name='product' to='parentproductid' from='productid' alias='parent' link-type='outer'>
                                      <attribute name='productnumber' />
                                    </link-entity>
                                    <filter>
                                      <condition attribute='productnumber' operator='eq' value='{0}' />
                                    </filter>
                                  </entity>
                                  </fetch>", HttpUtility.HtmlEncode(entProduct["productnumber"].ToString()));
                var entResult = objUtil.GetRecordsbyFetchxml(strFetchXml);
                if (entResult != null && entResult.Count > 0)
                {
                    var ent = entResult[0];
                    if ( ent.FormattedValues["statecode"].ToString() == "Active")
                    {
                        if (entProduct["parentproductid"] != null && ent.Contains("parent.productnumber") &&
                            ((entProduct["parentproductid"] as EntityReference).KeyAttributes["productnumber"].ToString().Trim().Equals(
                                (ent["parent.productnumber"] as AliasedValue).Value.ToString().Trim(), StringComparison.InvariantCultureIgnoreCase)))
                        {
                            return false;
                        }
                        return true;
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                tracingService.Trace("IsrequiredToUnderRevision");
                throw ex;
            }
        }

        
    }
}
