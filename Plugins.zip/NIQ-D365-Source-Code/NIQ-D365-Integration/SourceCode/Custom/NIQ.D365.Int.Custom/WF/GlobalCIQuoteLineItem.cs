﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using System.Activities.Statements;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Data;
using NIQ.D365.Int.Custom.Class;
using NIQ.D365.Int.Custom.CITools;
using Microsoft.Xrm.Sdk.Query;
using static NIQ.D365.Int.Custom.CITools.GlobalCIQuoteLineItemHelper;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Organization;

namespace NIQ.D365.Int.Custom.WF
{
    public class GlobalCIQuoteLineItem : CodeActivity
    {
        [RequiredArgument]
        [Input("ProjectID")]
        public InArgument<string> ProjectID { get; set; }


        [RequiredArgument]
        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        public string practiceArea = "";
        protected override void Execute(CodeActivityContext context)
        {
            IWorkflowContext workflowContext = context.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
            ITracingService tracingService = context.GetExtension<ITracingService>();
            List<QuoteLineItem> lstQuoteLineItem = new List<QuoteLineItem>();
            bool iserror = false;
            try
            {

                GlobalCIQuoteLineItemHelper objQuoteProductHelper = new GlobalCIQuoteLineItemHelper(tracingService);
                Utility objUtil = new Utility(service, tracingService);

                List<Entity> lstQuoteProduct = this.GetQuoteProducts(ProjectID.Get(context), objUtil);
                List<Entity> lstOptyTeamMember = null, lstQPCharacteristic = null;

                if (lstQuoteProduct != null && lstQuoteProduct.Count > 0)
                {
                    foreach (var item in lstQuoteProduct)
                    {
                        if (item.Contains("productid"))
                        {
                            practiceArea = (service.Retrieve((item["productid"] as EntityReference).LogicalName, (item["productid"] as EntityReference).Id, new ColumnSet("hierarchypath")))["hierarchypath"].ToString();
                        }
                    }

                    lstQPCharacteristic = this.GetQPCharacteristics(lstQuoteProduct, objUtil);
                    lstOptyTeamMember = this.GetOptyTeamMember(lstQuoteProduct, objUtil);


                    string strinstanceURL = this.GetInstanceURL(objUtil);
                    lstQuoteLineItem = objQuoteProductHelper.GetResultPayload(lstQuoteProduct, lstOptyTeamMember, lstQPCharacteristic, strinstanceURL, practiceArea);
                }
                else
                {
                    lstQuoteLineItem.Add(new QuoteLineItem()
                    {
                        errorMessage = "Microsoft Dynamics 365:Exception: Exception:No Lineitem with the requested Project id :" + ProjectID.Get(context)
                    });
                    iserror = true;
                }

            }
            catch (Exception ex)
            {
                iserror = true;
                lstQuoteLineItem.Add(new QuoteLineItem()
                {
                    errorMessage = "Microsoft Dynamics 365:Exception while retrieving product :" + ex.Message + " " + ex.StackTrace
                });
                tracingService.Trace("Execute-" + ex.Message + ex.StackTrace);
                //  throw ex;
            }
            finally
            {
                string strResult = "";
                if (iserror)
                {
                    strResult = JsonConvert.SerializeObject(lstQuoteLineItem, Formatting.None, new JsonSerializerSettings()
                    { NullValueHandling = NullValueHandling.Ignore, DefaultValueHandling = DefaultValueHandling.Ignore });
                }
                else
                    strResult = JsonConvert.SerializeObject(lstQuoteLineItem, Formatting.None);

                Result.Set(context, strResult);
            }
        }

        private List<Entity> GetQuoteProducts(string projectid, Utility objUtil)
        {
            try
            {
                string strFetchxml = string.Format(@"<fetch> <entity name='quotedetail'>
                                        <attribute name='productname' />
                                        <attribute name='productid' />
                                        <attribute name='productnumber' />                                      
                                        <attribute name='quotedetailname' />
                                        <attribute name='niq_reconciliationamount'/>
                                        <attribute name='niq_glaccountid' />
                                        <attribute name='niq_profitcentreid' />
                                        <attribute name='niq_expectedthirdpartycost' />
                                        <attribute name='description' />
                                        <attribute name='niq_projectid' />
                                        <attribute name='niq_invoicetext' />
                                        <attribute name='extendedamount' />
                                        <attribute name='extendedamount_base' />
                                        <attribute name='niq_lineitemstartdate' />
                                        <attribute name='niq_lineitemenddate' />
                                        <attribute name='niq_wbs' />
                                        <link-entity name='product' to='niq_subbrandid' from='productid' alias='prod' link-type='inner'>
                                          <attribute name='name' />
                                        </link-entity>
                                         <link-entity name='quote' to='quoteid' from='quoteid' alias='q' link-type='inner'>
                                          <attribute name='quoteid' />
                                          <link-entity name='opportunity' to='opportunityid' from='opportunityid' alias='opty' link-type='inner'>
                                            <attribute name='opportunityid' />                                            
                                            <attribute name='niq_opportunitytype' />
                                            <attribute name='niq_opportunitynumber' />
                                            <attribute name='name' />
                                            <attribute name='niq_closeprobability' />
                                            <attribute name='parentaccountid' />
                                            <attribute name='niq_salesgroupid' />
                                            <attribute name='description' />
                                            <attribute name='niq_stage' />
                                            <attribute name='niq_fieldingcountryci' />
                                            <link-entity name='systemuser' to='owninguser' from='systemuserid' alias='owner' link-type='outer'>
                                              <attribute name='domainname' />
                                              <attribute name='fullname' />
                                            </link-entity>
                                          </link-entity>
                                          <link-entity name='transactioncurrency' to='transactioncurrencyid' from='transactioncurrencyid' alias='currency' link-type='inner'>
                                            <attribute name='isocurrencycode' />
                                          </link-entity>
                                        </link-entity>
                                        <filter>
                                            <filter>
                                              <condition attribute='niq_projectid' operator='eq' value='{0}' />
                                              <condition attribute='niq_mainquote' entityname='q' operator='eq' value='1' />
                                            </filter>
                                        <condition attribute='opportunityid' entityname='opty' operator='not-null' />
                                        </filter>
                                      </entity>
                                    </fetch>", projectid);
                var lstEnt = objUtil.GetRecordsbyFetchxml(strFetchxml);
                if (lstEnt != null) return lstEnt.ToList();
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private List<Entity> GetOptyTeamMember(List<Entity> lstQuoteProduct, Utility objUtil)
        {
            try
            {
                if (lstQuoteProduct != null)
                {
                    StringBuilder sbQuoteProduct = new StringBuilder();
                    foreach (var item in lstQuoteProduct)
                    {

                        if (!sbQuoteProduct.ToString().Contains((item["opty.opportunityid"] as AliasedValue).Value.ToString()))
                            sbQuoteProduct.Append("<value>" + (item["opty.opportunityid"] as AliasedValue).Value.ToString() + "</value>");
                    }

                    string strFetchxml = string.Format(@"<fetch>
                      <entity name='principalobjectaccess'>
                            <link-entity name='opportunity' to='objectid' from='opportunityid' alias='opportunity' link-type='inner'>
                              <attribute name='opportunityid' />
                            </link-entity>
                            <link-entity name='team' to='principalid' from='teamid' alias='t' link-type='inner'>
                              <link-entity name='teammembership' to='teamid' from='teamid' alias='tm' link-type='inner'>
                                <link-entity name='systemuser' to='systemuserid' from='systemuserid' alias='u' link-type='inner'>
                                  <attribute name='fullname' />
                                  <attribute name='domainname' />
                                </link-entity>
                              </link-entity>
                              <link-entity name='teamtemplate' to='teamtemplateid' from='teamtemplateid' alias='teamtemplate' link-type='inner' />
                            </link-entity>
                            <filter>
                              <condition attribute='opportunityid' entityname='opportunity' operator='in'>{0}</condition>
                            </filter>
                          </entity>
                        </fetch>", sbQuoteProduct.ToString());
                    var lstEnt = objUtil.GetRecordsbyFetchxml(strFetchxml);
                    if (lstEnt != null) return lstEnt.ToList();
                }
                return null;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private List<Entity> GetQPCharacteristics(List<Entity> lstQuoteProduct, Utility objUtil)
        {
            try
            {
                if (lstQuoteProduct != null)
                {
                    StringBuilder sbQuoteProduct = new StringBuilder();
                    foreach (var item in lstQuoteProduct)
                    {
                        sbQuoteProduct.Append("<value>" + item.Id.ToString() + "</value>");
                    }

                    string strFetchxml = string.Format(@"<fetch> <entity name='niq_quoteproductcharacteristic'>
                        <attribute name='niq_quoteproductid' />
                        <link-entity name='niq_materialcharacteristic' from='niq_materialcharacteristicid' to='niq_materialcharacteristicid' link-type='inner' alias='char'>
                          <attribute name='niq_characteristiccode' />
                          <filter>
                            <condition attribute='niq_characteristiccode' operator='in'>
                              <value>Z_MULTI-COUNTRY</value>
                              <value>Z_SERVICES</value>
                              <value>Z_FIELDINGMETHOD</value>
                            </condition>
                          </filter>
                        </link-entity>
                        <link-entity name='niq_characteristicvalue' from='niq_characteristicvalueid' to='niq_materialcharacteristicvalueid' link-type='inner' alias='charval'>
                          <attribute name='niq_characteristicvaluedescription' />
                        </link-entity>
	                    <filter type='and'>
                          <condition attribute='niq_quoteproductid' operator='in'>
                            {0}
                          </condition>
                        </filter>
                      </entity>
                    </fetch>", sbQuoteProduct.ToString());


                    var lstEnt = objUtil.GetRecordsbyFetchxml(strFetchxml);
                    if (lstEnt != null) return lstEnt.ToList();
                }
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string GetInstanceURL(Utility objUtil)
        {
            RetrieveCurrentOrganizationResponse orgRes = objUtil.GetCurrentOrgInfo();
            string recordurl = string.Format("{0}main.aspx?pagetype=entityrecord&etn=opportunity&id=",
                ((orgRes.Results["Detail"] as OrganizationDetail).Endpoints as EndpointCollection)[EndpointType.WebApplication].ToString());

            return recordurl;
        }
    }
}
