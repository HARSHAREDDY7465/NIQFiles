﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Organization;
using Microsoft.Xrm.Sdk.Workflow;
using Newtonsoft.Json;
using NIQ.D365.Int.Custom.CITools;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static NIQ.D365.Int.Custom.CITools.GlobalCIGinkgoOpportunityHelper;

namespace NIQ.D365.Int.Custom.WF
{
    public class GlobalCIGinkgoOpportunity : CodeActivity
    {
        [RequiredArgument]
        [Input("OpportunityNumber")]
        public InArgument<string> OpportunityNumber { get; set; }


        [RequiredArgument]
        [Input("Brand")]
        public InArgument<string> Brand { get; set; }


        [RequiredArgument]
        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            IWorkflowContext workflowContext = context.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
            ITracingService tracingService = context.GetExtension<ITracingService>();
            Opportunity opty = null;
            try
            {

                GlobalCIGinkgoOpportunityHelper objCIGinkgoOptyHelper = new GlobalCIGinkgoOpportunityHelper(tracingService);
                Utility objUtil = new Utility(service, tracingService);

                Entity objOptyNQuoteInfo = this.GetOptyNQuoteInfo(OpportunityNumber.Get(context), objUtil);
                List<Entity> lstQuoteProduct = null, lstOptyTeamMember = null, lstQPCharacteristic = null, lstOptyContactRoles = null, lstAccTeamMember = null;

                if (objOptyNQuoteInfo != null)
                {
                    if (objOptyNQuoteInfo.Contains("niq_mainquoteid") && objOptyNQuoteInfo["niq_mainquoteid"] != null)
                    {
                        lstQuoteProduct = this.GetQuoteProducts((objOptyNQuoteInfo["niq_mainquoteid"] as EntityReference).Id.ToString(), Brand.Get(context), objUtil);
                        lstQPCharacteristic = this.GetQPCharacteristics(lstQuoteProduct, objUtil);
                    }
                    lstOptyTeamMember = this.GetOptyTeamMember(OpportunityNumber.Get(context), objUtil);
                    lstAccTeamMember = this.GetAccountTeamMember(OpportunityNumber.Get(context), objUtil);
                    bool isdev = this.isDevinstance(workflowContext.InitiatingUserId, objUtil);
                    string strinstanceURL = this.GetInstanceURL(objUtil);
                    opty = objCIGinkgoOptyHelper.GetResultPayload(objOptyNQuoteInfo, lstQuoteProduct, lstOptyTeamMember, lstQPCharacteristic, lstAccTeamMember, isdev, strinstanceURL);
                }
                else
                {
                    opty = new Opportunity();
                    opty.errorMessage = "Microsoft Dynamics 365:Exception: No Opportunity found with the requested Opportunity number :" + OpportunityNumber.Get(context);
                }

            }
            catch (Exception ex)
            {
                opty = new Opportunity();
                opty.errorMessage = "Microsoft Dynamics 365:Exception while retrieving product :" + ex.Message + " " + ex.StackTrace;
                tracingService.Trace("Execute-" + ex.Message + ex.StackTrace);
                //  throw ex;
            }
            finally
            {
                string strResult = "";
                if (opty.errorMessage != null && opty.errorMessage.Trim().Length > 0)
                {
                    strResult = JsonConvert.SerializeObject(opty, Formatting.None, new JsonSerializerSettings()
                    { NullValueHandling = NullValueHandling.Ignore, DefaultValueHandling = DefaultValueHandling.Ignore });
                }
                else
                    strResult = JsonConvert.SerializeObject(opty, Formatting.None);

                Result.Set(context, strResult);
            }
        }

        private Entity GetOptyNQuoteInfo(string opportunityNumber, Utility objUtil)
        {
            try
            {
                string strFetchxml = string.Format(@"<fetch><entity name='opportunity' >
        <attribute name='opportunityid' />
        <attribute name='niq_mainquoteid' />
        <attribute name='niq_salesorgid' />
        <attribute name='niq_opportunitynumber' />
        <attribute name='name' />
        <attribute name='niq_stage' />
        <attribute name='niq_closeprobability' />
        <attribute name='niq_opportunitytype' />
        <attribute name='createdon' />
        <attribute name='modifiedon' />
        <attribute name='estimatedclosedate' />
        <attribute name='niq_contractdecision' />
        <attribute name='niq_sapsalesdocumentid' />
        <attribute name='statecode' />
        <attribute name='description' />
        <link-entity name='account' to='niq_billtoparty' from='accountid' alias='bp' link-type='inner' >
            <attribute name='name' />
        </link-entity>
        <link-entity name='account' to='niq_soldtoparty' from='accountid' alias='sp' link-type='inner' >
            <attribute name='name' />
        </link-entity>
        <link-entity name='account' to='niq_deliverytoparty' from='accountid' alias='dp' link-type='inner' >
            <attribute name='name' />
        </link-entity>
        <link-entity name='niq_salesgroup' to='niq_salesgroupid' from='niq_salesgroupid' alias='niq_salesgroup' link-type='outer' >
            <attribute name='niq_name' />
        </link-entity>
        <link-entity name='systemuser' to='owninguser' from='systemuserid' alias='owner' link-type='outer' >
            <attribute name='domainname' />
            <attribute name='fullname' />
        </link-entity>
        <link-entity name='quote' to='niq_mainquoteid' from='quoteid' alias='quote' link-type='outer' >
            <attribute name='totalamount' />
            <attribute name='totalamount_base' />
            <attribute name='niq_contractstartdate' />
            <attribute name='niq_contractenddate' />
             <link-entity name='niq_salesorg' to='niq_salesorgid' from='niq_salesorgid' alias='niq_salesorg' link-type='inner'>
                    <attribute name='niq_salesorgcode' />
                    <attribute name='niq_name' />
             </link-entity>
            <link-entity name='transactioncurrency' to='transactioncurrencyid' from='transactioncurrencyid' alias='transactioncurrency' link-type='inner' >
                <attribute name='isocurrencycode' />
            </link-entity>
        </link-entity>
        <link-entity name='account' to='parentaccountid' from='accountid' alias='account' link-type='inner' >
            <attribute name='name' />
            <attribute name='niq_industry' />
            <link-entity name='systemuser' to='owninguser' from='systemuserid' alias='accountsystemuser' link-type='inner' >
                <attribute name='domainname' />
                <attribute name='fullname' />
            </link-entity>
        </link-entity>
        <filter>
            <condition attribute='niq_opportunitynumber' operator='eq' value='{0}' />
        </filter>
    </entity>
</fetch>", opportunityNumber);

                var objEnt = objUtil.GetRecordsbyFetchxml(strFetchxml);
                if (objEnt != null) return objEnt[0];
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private List<Entity> GetQuoteProducts(string quoteid, string brand, Utility objUtil)
        {
            try
            {
                string strFetchxml = string.Format(@"<fetch>
                                  <entity name='quotedetail'>
                                    <attribute name='quotedetailid' />
                                    <attribute name='productid' />
                                    <attribute name='productnumber' />
                                    <attribute name='productname' />
                                    <attribute name='niq_projectid' />
                                    <attribute name='niq_wbs' />
                                    <attribute name='niq_lineitemstartdate' />
                                    <attribute name='niq_lineitemenddate' />
                                    <attribute name='baseamount' />
                                    <attribute name='niq_invoicetext' />
                                    <attribute name='niq_deliveryfrequency' />
                                    <attribute name='niq_lagrevenuerecognition' />
                                    <link-entity name='product' to='productid' from='productid' alias='p' link-type='inner'>
                                      <attribute name='hierarchypath' />
                                      <link-entity name='product' to='parentproductid' from='productid' alias='p2' link-type='inner'>
                                        <attribute name='name' />
                                        <link-entity name='product' to='parentproductid' from='productid' alias='p3' link-type='inner' />
                                      </link-entity>
                                    </link-entity>
                                    <filter>
                                      <condition attribute='quoteid' operator='eq' value='{0}' />
                                      <condition attribute='name' entityname='p3' operator='eq' value='{1}' />
                                    </filter>
                                  </entity>
                                </fetch>", quoteid, brand);
                var lstEnt = objUtil.GetRecordsbyFetchxml(strFetchxml);
                if (lstEnt != null) return lstEnt.ToList();
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private List<Entity> GetOptyTeamMember(string opportunityNumber, Utility objUtil)
        {
            try
            {
                string strFetchxml = string.Format(@"<fetch>
                      <entity name='principalobjectaccess'>
                        <link-entity name='opportunity' to='objectid' from='opportunityid' alias='opportunity' link-type='inner' />
                        <link-entity name='team' to='principalid' from='teamid' alias='t' link-type='inner'>
                          <link-entity name='teammembership' to='teamid' from='teamid' alias='tm' link-type='inner'>
                            <link-entity name='systemuser' to='systemuserid' from='systemuserid' alias='u' link-type='inner'>
                              <attribute name='fullname' />
                              <attribute name='domainname' />
                            </link-entity>
                          </link-entity>
                          <link-entity name='teamtemplate' to='teamtemplateid' from='teamtemplateid' alias='teamtemplate' link-type='inner' />
                        </link-entity>
                        <filter>
                          <condition attribute='niq_opportunitynumber' entityname='opportunity' operator='eq' value='{0}' />
                        </filter>
                      </entity>
                    </fetch>", opportunityNumber);
                var lstEnt = objUtil.GetRecordsbyFetchxml(strFetchxml);
                if (lstEnt != null) return lstEnt.ToList();
                return null;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private List<Entity> GetAccountTeamMember(string opportunityNumber, Utility objUtil)
        {
            try
            {
                string strFetchxml = string.Format(@"<fetch>
  <entity name='principalobjectaccess'>
    <link-entity name='opportunity' to='objectid' from='opportunityid' alias='opportunity' link-type='inner' />
    <link-entity name='team' to='principalid' from='teamid' alias='t' link-type='inner'>
      <link-entity name='teammembership' to='teamid' from='teamid' alias='tm' link-type='inner'>
        <link-entity name='systemuser' to='systemuserid' from='systemuserid' alias='u' link-type='inner'>
          <attribute name='fullname' />
          <attribute name='domainname' />
        </link-entity>
      </link-entity>
      <link-entity name='teamtemplate' to='teamtemplateid' from='teamtemplateid' alias='teamtemplate' link-type='inner' />
    </link-entity>
    <filter>
      <condition attribute='niq_opportunitynumber' entityname='opportunity' operator='eq' value='{0}' />
    </filter>
  </entity>
</fetch>", opportunityNumber);
                var lstEnt = objUtil.GetRecordsbyFetchxml(strFetchxml);
                if (lstEnt != null) return lstEnt.ToList();
                return null;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private List<Entity> GetOptyContactroles(string opportunityNumber, Utility objUtil)
        {
            try
            {
                string strFetchxml = string.Format(@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                          <entity name='contact'>
                            <attribute name='fullname' />
                            <attribute name='emailaddress1' />
                            <attribute name='firstname' />
                            <link-entity name='connection' from='record2id' to='contactid'>
                              <link-entity name='opportunity' from='opportunityid' to='record1id'>
                                <filter type='and'>
                                  <condition attribute='niq_opportunitynumber' operator='eq' value='{0}' />
                                </filter>
                              </link-entity>
                              <link-entity name='connectionrole' from='connectionroleid' to='record2roleid' link-type='inner' alias='con'>
                                <attribute name='name' />
                              </link-entity>
                            </link-entity>
                          </entity>
                        </fetch>", opportunityNumber);
                var lstEnt = objUtil.GetRecordsbyFetchxml(strFetchxml);
                if (lstEnt != null) return lstEnt.ToList();
                return null;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private List<Entity> GetQPCharacteristics(List<Entity> lstQuoteProduct, Utility objUtil)
        {
            try
            {
                if (lstQuoteProduct != null)
                {
                    StringBuilder sbQuoteProduct = new StringBuilder();
                    foreach (var item in lstQuoteProduct)
                    {
                        sbQuoteProduct.Append("<value>" + item.Id.ToString() + "</value>");
                    }

                    string strFetchxml = string.Format(@"<fetch> <entity name='niq_quoteproductcharacteristic'>
                        <attribute name='niq_quoteproductid' />
                        <link-entity name='niq_materialcharacteristic' from='niq_materialcharacteristicid' to='niq_materialcharacteristicid' link-type='inner' alias='char'>
                          <attribute name='niq_characteristiccode' />
                          <filter>
                            <condition attribute='niq_characteristiccode' operator='in'>
                              <value>Z_MULTI-COUNTRY</value>
                              <value>Z_SERVICES</value>
                              <value>Z_FIELDINGMETHOD</value>
                            </condition>
                          </filter>
                        </link-entity>
                        <link-entity name='niq_characteristicvalue' from='niq_characteristicvalueid' to='niq_materialcharacteristicvalueid' link-type='inner' alias='charval'>
                          <attribute name='niq_characteristicvaluedescription' />
                        </link-entity>
	                    <filter type='and'>
                          <condition attribute='niq_quoteproductid' operator='in'>
                            {0}
                          </condition>
                        </filter>
                      </entity>
                    </fetch>", sbQuoteProduct.ToString());


                    var lstEnt = objUtil.GetRecordsbyFetchxml(strFetchxml);
                    if (lstEnt != null) return lstEnt.ToList();
                }
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private bool isDevinstance(Guid userId, Utility objUtil)
        {
            Entity userInfo = objUtil.GetRecordbyId("systemuser", userId, new string[] { "fullname", "applicationid" });
            if (userInfo != null)
            {
                if (userInfo.Contains("applicationid") && userInfo["applicationid"].ToString().Trim() == "64c61ed8-97db-4273-99b4-458f0a7f6f33")
                    return true;
                else if (userInfo.Contains("fullname") && userInfo["fullname"].ToString().ToLower().Contains("nonprod"))
                    return true;
            }

            return false;
        }

        private string GetInstanceURL(Utility objUtil)
        {
            RetrieveCurrentOrganizationResponse orgRes = objUtil.GetCurrentOrgInfo();
            string recordurl = string.Format("{0}main.aspx?pagetype=entityrecord&etn=opportunity&id=",
                ((orgRes.Results["Detail"] as OrganizationDetail).Endpoints as EndpointCollection)[EndpointType.WebApplication].ToString());

            return recordurl;
        }
    }
}
