﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NIQ.D365.Int.Custom
{
   
    public class Utility
    {
        IOrganizationService service;
        ITracingService tracingService;
        public Utility(IOrganizationService service, ITracingService tracingService)
        {
            this.service = service;
            this.tracingService = tracingService;
        }
        public DataCollection<Entity> GetRecordsbyFetchxml(string fetchXml)
        {
            try
            {
                EntityCollection objEntity = service.RetrieveMultiple(new FetchExpression(fetchXml));
                if (objEntity != null && objEntity.Entities != null && objEntity.Entities.Count > 0)
                    return objEntity.Entities;
                return null;
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetDatabyFetchxml=" + fetchXml);

                throw ex;
            }
        }

        public RetrieveCurrentOrganizationResponse GetCurrentOrgInfo()
        {

            try
            {
                RetrieveCurrentOrganizationRequest orgReq = new RetrieveCurrentOrganizationRequest();
                orgReq.AccessType = Microsoft.Xrm.Sdk.Organization.EndpointAccessType.Default;
                return service.Execute(orgReq) as RetrieveCurrentOrganizationResponse;

            }
            catch (Exception ex)
            {
                tracingService.Trace("GetCurrentOrgInfo");
                throw ex;
            }
        }
        public Entity GetRecordbyId(string entityName,Guid Id,string[] columns)
        {
            try
            {
                ColumnSet column = new ColumnSet();
                column.AddColumns(columns);
               return service.Retrieve(entityName, Id, column);
              
            }
            catch (Exception ex)
            {
                tracingService.Trace("GetRecordbyId=" + entityName + "," + Id.ToString());
                throw ex;
            }
        }
    }
}
