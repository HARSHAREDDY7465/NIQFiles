if (typeof (DealDeskRibbon) === "undefined") {
    DealDeskRibbon = {
        _namespace: true
    };
}

DealDeskRibbon.Events = {

    OnClickSenddealdeskreviewresultbacktosales: function (executionContext) {
        'use strict';
        var formContext = executionContext;

        var confirmStrings = { text: "Do you wish to Send deal desk review result back to sales", cancelButtonLabel: "No", confirmButtonLabel: "Yes" };
        var confirmOptions = { height: 200, width: 450 };
        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {

                    var ddarId = formContext.data.entity.getId().replace('{', '').replace('}', '');
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_overalldealdeskapproval") && (formContext.getAttribute("niq_overalldealdeskapproval").getValue() === 6 || formContext.getAttribute("niq_overalldealdeskapproval").getValue() === 8) && CommonForm.Events.CheckValueExists(formContext, "niq_quoteid")) {
                        if (formContext.getAttribute("niq_overalldealdeskapproval").getValue() === 8)
                            formContext.getAttribute("niq_approvalstatus").setValue(3);
                        else
                            formContext.getAttribute("niq_approvalstatus").setValue(4);
                        formContext.getAttribute("statecode").setValue(1);
                        formContext.data.save().then(
                            function success(result) {
                                var quoteId = formContext.getAttribute("niq_quoteid").getValue()[0] != null ? formContext.getAttribute("niq_quoteid").getValue()[0].id : null;
                                var pricingApp = formContext.getAttribute("niq_pricingapproval") != null ? formContext.getAttribute("niq_pricingapproval").getValue() : null;
                                var fundUsageApp = formContext.getAttribute("niq_fundusageapproval") != null ? formContext.getAttribute("niq_fundusageapproval").getValue() : null;
                                var quoteHeaderApp = formContext.getAttribute("niq_quoteheaderdetailsapproval") != null ? formContext.getAttribute("niq_quoteheaderdetailsapproval").getValue() : null;
                                if (quoteId != null && pricingApp != null && fundUsageApp != null && quoteHeaderApp != null) {
                                    var entity = {};
                                    entity.niq_dealdeskapproval = pricingApp;
                                    entity.niq_quoteheaderdetailsapproval = quoteHeaderApp;
                                    entity.niq_fundusageapproval = fundUsageApp;

                                    Xrm.WebApi.online.updateRecord("quote", quoteId, entity).then(
                                        function success(result) {
                                            var updatedEntityId = result.id;
                                        },
                                        function (error) {
                                            Xrm.Utility.alertDialog(error.message);
                                        }
                                    );
                                }

                            },
                            function (error) {
                                Xrm.Utility.alertDialog(error.message);
                            }
                        );
                    }
                }


            });
    },
    SenddealdeskreviewresultbacktosalesButtonVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User")) {
            return true;
        }
        else {
            return false;
        }
    }
}