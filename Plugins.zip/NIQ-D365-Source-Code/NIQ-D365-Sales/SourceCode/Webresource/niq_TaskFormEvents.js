if (typeof (TaskForm) === "undefined") {
    TaskForm = {
        __namespace: true
    };
}

TaskForm.Events = {
    //Method for onload functions
    FormOnload: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        TaskForm.Events.ShowHideSectionsBasedonType(executionContext);
        formContext.getAttribute("niq_type").addOnChange(this.ShowHideSectionsBasedonType);

        TaskForm.Events.updateForTaskStatus(executionContext);
        formContext.getAttribute("niq_type").addOnChange(this.updateForTaskStatus);


        TaskForm.Events.ShowHideForRegarding(executionContext)
        formContext.getAttribute("regardingobjectid").addOnChange(this.ShowHideForRegarding);

        formContext.getAttribute("niq_type").addOnChange(this.ClearValidationError);
        formContext.getAttribute("niq_acknowledgepodoc").addOnChange(this.ClearValidationError);
        formContext.getAttribute("niq_acknowledgeeoaupload").addOnChange(this.ClearValidationError);
        formContext.getAttribute("niq_acknowledgefundapprovalemail").addOnChange(this.ClearValidationError);
        formContext.getAttribute("niq_acknowledgecancellationapprovalemail").addOnChange(this.ClearValidationError);
    },

    //Function to ShowHide fields based on "regarding" field
    ShowHideForRegarding: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var relatedProjectControl = formContext.getControl("niq_relatedproject");
        var regardingValue = CommonForm.Events.GetFieldValue(formContext, "regardingobjectid");

        if (regardingValue && regardingValue[0].entityType === 'opportunity') {
            const fetchXml = '<filter type="and"><condition attribute="niq_opportunityid" operator="eq" uiname="' + regardingValue[0].name + '" uitype="opportunity" value="' + regardingValue[0].id + '"/></filter>'

            Xrm.WebApi.retrieveRecord('opportunity', regardingValue[0].id).then(
                (result) => {
                    //check business area = BASES
                    if (result.niq_businessarea === 100000000) {
                        //DYNCRM-2604
                        if (pageType == 'quickcreate') {
                            CommonForm.Events.ShowHideFields(formContext, ["niq_requesttaskname", "statuscode", "niq_comments"], false);
                            CommonForm.Events.ShowHideFields(formContext, ["description"], false);
                        } else {
                            CommonForm.Events.ShowHideFields(formContext, ["niq_comments"], true);
                        }
                        //DYNCRM-2202
                        formContext.ui.setFormNotification("Use this form to submit changes to the BASES Finance Coordinator team at the point in the process where they own updates (e.g. after Negotiation). BASES FCs will take action on the specified \"BASES\" Tasks (indicated by the Type field). Please do not send these changes to the FC inbox. Submit one Task per Opportunity/request.", "INFO", "DYNCRM-2202");
                        CommonForm.Events.ShowHideFields(formContext, ["niq_relatedproject", "niq_type"], true);
                        CommonForm.Events.ShowHideFields(formContext, ["description", "prioritycode", "scheduledend", "ownerid"], false);
                        relatedProjectControl.addPreSearch(() => {
                            relatedProjectControl.addCustomFilter(fetchXml)
                        });
                        //DYNCRM-2085
                        TaskForm.Events.retrieveRelatedProjects(regardingValue, function (relatedProjects) {
                            if (relatedProjects.length === 1) {
                                formContext.getAttribute("niq_relatedproject").setRequiredLevel("required");
                                var lookupRelatedProjectValue = new Array();
                                lookupRelatedProjectValue[0] = new Object();
                                lookupRelatedProjectValue[0].id = relatedProjects[0]["msdyn_projectid"];
                                lookupRelatedProjectValue[0].name = relatedProjects[0]["msdyn_subject"];
                                lookupRelatedProjectValue[0].entityType = "msdyn_project";
                                formContext.getAttribute("niq_relatedproject").setValue(lookupRelatedProjectValue);
                            } else if (relatedProjects.length > 1) {
                                // Set the field as mandatory  if there are more than 1 active projects
                                formContext.getAttribute("niq_relatedproject").setRequiredLevel("required");

                            } else {
                                // Set the field as optional if there are no active projects
                                formContext.getAttribute("niq_relatedproject").setRequiredLevel("none");

                            }

                        });

                    } else {
                        //DYNCRM-2604
                        if (pageType == 'quickcreate') {
                            CommonForm.Events.ShowHideFields(formContext, ["niq_requesttaskname", "statuscode", "niq_comments"], true);
                            CommonForm.Events.ShowHideFields(formContext, ["description"], false);
                        } else {
                            CommonForm.Events.ShowHideFields(formContext, ["niq_comments"], false);
                        }
                        formContext.ui.clearFormNotification("DYNCRM-2202");
                        CommonForm.Events.ShowHideFields(formContext, ["niq_relatedproject", "niq_type", "statuscode"], false);
                        CommonForm.Events.ShowHideFields(formContext, ["prioritycode", "scheduledend", "ownerid", "header_ownerid"], true);
                    }
                },
                (error) => {
                    console.log(error)
                }
            )
        } else {
            //reset all fields if regarding is blank
            if (pageType == 'quickcreate') {
                CommonForm.Events.ShowHideFields(formContext, ["niq_requesttaskname", "statuscode", "niq_comments"], true);
                CommonForm.Events.ShowHideFields(formContext, ["description"], false);
            } else {
                CommonForm.Events.ShowHideFields(formContext, ["statuscode", "niq_comments"], false);
                CommonForm.Events.ShowHideFields(formContext, ["description"], true);
            }
            formContext.ui.clearFormNotification("DYNCRM-2202");
            CommonForm.Events.ShowHideFields(formContext, ["niq_relatedproject", "niq_type"], false);
            CommonForm.Events.ShowHideFields(formContext, ["prioritycode", "scheduledend", "ownerid", "header_ownerid"], true);
            CommonForm.Events.SetFieldValue(formContext, "niq_type", 100000000); //reset to global
            CommonForm.Events.ShowHideFields(formContext, ["niq_ponumber", "niq_billinginstructionsnote", "niq_acknowledgepodoc"], false);
            CommonForm.Events.ShowHideFields(formContext, ["niq_newstudyprice", "niq_scopechangereason", "niq_pricechangereason", "niq_changeincurrency", "niq_newcurrency", "niq_acknowledgeeoaupload"], false);
            CommonForm.Events.ShowHideFields(formContext, ["niq_billinginstructions", "niq_newbilltocliententity", "niq_sharethenewinvoicerecipients", "niq_newinvoicinginstructions"], false);
            CommonForm.Events.ShowHideFields(formContext, ["niq_fundchangesneeded", "niq_fundusagedetails", "niq_acknowledgefundapprovalemail"], false);
            CommonForm.Events.ShowHideFields(formContext, ["niq_cancellationreason", "niq_isthereacancellationfee", "niq_feeamount", "niq_acknowledgecancellationapprovalemail"], false);
            CommonForm.Events.SetRequiredFieldLevels(formContext, ["niq_billinginstructions"], "none");
            CommonForm.Events.SetFieldValue(formContext, "niq_billinginstructions", null); //remove all values
            CommonForm.Events.SetFieldValue(formContext, "niq_changeincurrency", false); //set to no
            CommonForm.Events.SetFieldValue(formContext, "niq_isthereacancellationfee", false); //set to no

        }
    },


    //Function to ShowHide sections based on "type" field
    ShowHideSectionsBasedonType: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var type = CommonForm.Events.GetFieldValue(formContext, "niq_type");

        CommonForm.Events.ShowHideFields(formContext, ["niq_ponumber", "niq_billinginstructionsnote", "niq_acknowledgepodoc"], false);
        CommonForm.Events.ShowHideFields(formContext, ["niq_newstudyprice", "niq_scopechangereason", "niq_pricechangereason", "niq_changeincurrency", "niq_newcurrency", "niq_acknowledgeeoaupload"], false);
        CommonForm.Events.ShowHideFields(formContext, ["niq_billinginstructions", "niq_newbilltocliententity", "niq_sharethenewinvoicerecipients", "niq_newinvoicinginstructions"], false);
        CommonForm.Events.ShowHideFields(formContext, ["niq_fundchangesneeded", "niq_fundusagedetails", "niq_acknowledgefundapprovalemail"], false);
        CommonForm.Events.ShowHideFields(formContext, ["niq_cancellationreason", "niq_isthereacancellationfee", "niq_feeamount", "niq_acknowledgecancellationapprovalemail"], false);
        CommonForm.Events.SetRequiredFieldLevels(formContext, ["niq_billinginstructions"], "none");
        //CommonForm.Events.SetFieldValue(formContext, "niq_billinginstructions", null); //remove all values
        CommonForm.Events.SetFieldValue(formContext, "niq_changeincurrency", false); //set to no
        CommonForm.Events.SetFieldValue(formContext, "niq_isthereacancellationfee", false); //set to no


        if (type !== null) {
            if (type == 100000001) {
                CommonForm.Events.ShowHideFields(formContext, ["niq_ponumber", "niq_billinginstructionsnote", "niq_acknowledgepodoc"], true);
            }
            else if (type == 100000002) {
                CommonForm.Events.ShowHideFields(formContext, ["niq_newstudyprice", "niq_scopechangereason", "niq_pricechangereason", "niq_changeincurrency", "niq_acknowledgeeoaupload"], true);
            }
            else if (type == 100000003) {
                CommonForm.Events.ShowHideFields(formContext, ["niq_billinginstructions"], true);
                CommonForm.Events.SetRequiredFieldLevels(formContext, ["niq_billinginstructions"], "required");
                TaskForm.Events.OnchangeBillingInstructions(executionContext);

            }
            else if (type == 100000004) {
                CommonForm.Events.ShowHideFields(formContext, ["niq_fundchangesneeded", "niq_fundusagedetails", "niq_acknowledgefundapprovalemail"], true);
            }
            else if (type == 100000005) {
                CommonForm.Events.ShowHideFields(formContext, ["niq_cancellationreason", "niq_isthereacancellationfee"], true);
            }

        }

    },

    //method to verify both "New-currency" and "parent opporunity currency" values are same or not
    validateChangeinCurrency: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var OppVal = CommonForm.Events.GetFieldValue(formContext, "regardingobjectid");
        var TaskCurrency = CommonForm.Events.GetFieldValue(formContext, "niq_newcurrency");

        //checks whether the regarding is "opportunity" or not
        if (OppVal != null && TaskCurrency != null && OppVal[0].entityType == "opportunity") {
            OppId = OppVal[0].id.replace("{", "").replace("}", "")
            Xrm.WebApi.online.retrieveRecord("opportunity", OppId, "?$select=totalamount,transactioncurrencyid").then(
                function success(result) {
                    var OppCurrencyVal = result["_transactioncurrencyid_value@OData.Community.Display.V1.FormattedValue"];
                    var TaskCurrencyVal = TaskCurrency[0].name;

                    if (OppCurrencyVal == TaskCurrencyVal) {
                        //  alert("There is no currency change, kindly recheck");

                        Xrm.Navigation.openErrorDialog({ message: "There is no currency change, kindly recheck" }).then(
                            function (success) {
                                console.log(success);
                            },
                            function (error) {
                                console.log(error);
                            });

                    }
                },
                function (error) {
                    console.log(error.message);
                }
            );
        }

    },

    //Function to ShowHide/Required "Invoice Billing Instruction" Section fields based on "Billing Instructions" multiselect field value
    OnchangeBillingInstructions: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var SelectedBillingInstructionVal = CommonForm.Events.GetFieldValue(formContext, "niq_billinginstructions");

        CommonForm.Events.SetRequiredFieldLevels(formContext, ["niq_newbilltocliententity", "niq_sharethenewinvoicerecipients", "niq_newinvoicinginstructions"], "none");
        CommonForm.Events.ShowHideFields(formContext, ["niq_newbilltocliententity", "niq_sharethenewinvoicerecipients", "niq_newinvoicinginstructions"], false);

        const RequiredfieldList = [
            { id: 100000000, field: ["niq_newbilltocliententity"] },
            { id: 100000001, field: ["niq_sharethenewinvoicerecipients"] },
            { id: 100000002, field: ["niq_newinvoicinginstructions"] }
        ];
        const showfieldList = [
            { id: 100000000, field: ["niq_newbilltocliententity"] },
            { id: 100000001, field: ["niq_sharethenewinvoicerecipients"] },
            { id: 100000002, field: ["niq_newinvoicinginstructions"] }
        ];
        if (SelectedBillingInstructionVal != null) {


            showfieldList.forEach(k => {
                var isVisible = SelectedBillingInstructionVal.includes(k.id) ? true : false;
                CommonForm.Events.ShowHideFields(formContext, k.field, isVisible);
            });

            RequiredfieldList.forEach(s => {
                var requireLevel = SelectedBillingInstructionVal.includes(s.id) ? "required" : "none";
                CommonForm.Events.SetRequiredFieldLevels(formContext, s.field, requireLevel);
            });
        }
    },
    //DYNCRM-2085
    retrieveRelatedProjects: function (regardingValue, callback) {
        Xrm.WebApi.retrieveMultipleRecords("msdyn_project", "?$select=msdyn_projectid, msdyn_subject&$filter=(_niq_opportunityid_value eq '" + regardingValue[0].id + "' and statuscode eq 1)").then(
            function success(results) {
                callback(results.entities);
            },
            function (error) {
                console.error("Error retrieving related projects: " + error.message);
                callback([]); // Return an empty array in case of an error
            }
        );
    },

    //DYNCRM-2204
    ShowValidationError: function (executionContext) {
        "use strict";
      
        var formContext = executionContext.getFormContext();
        var activityStatus = CommonForm.Events.GetFieldValue(formContext, "statecode");
        var type = CommonForm.Events.GetFieldValue(formContext, "niq_type");

        if (activityStatus === 0 && type != null) {
            if (type == 100000001 && CommonForm.Events.GetFieldValue(formContext, "niq_acknowledgepodoc") != true) {
                formContext.getControl("niq_acknowledgepodoc").setNotification("Select Yes to confirm documentation has or will be uploaded to proceed.", "ackPOError");

                executionContext.getEventArgs().preventDefault();
            } else if (type == 100000002 && CommonForm.Events.GetFieldValue(formContext, "niq_acknowledgeeoaupload") != true) {
                formContext.getControl("niq_acknowledgeeoaupload").setNotification("Select Yes to confirm documentation has or will be uploaded to proceed.", "eoaError");

                executionContext.getEventArgs().preventDefault();
            } else if (type == 100000004 && CommonForm.Events.GetFieldValue(formContext, "niq_acknowledgefundapprovalemail") != true) {
                formContext.getControl("niq_acknowledgefundapprovalemail").setNotification("Select Yes to confirm documentation has or will be uploaded to proceed.", "fundError");

                executionContext.getEventArgs().preventDefault();
            } else if (type == 100000005 && CommonForm.Events.GetFieldValue(formContext, "niq_isthereacancellationfee") == true && CommonForm.Events.GetFieldValue(formContext, "niq_acknowledgecancellationapprovalemail") != true) {
                formContext.getControl("niq_acknowledgecancellationapprovalemail").setNotification("Select Yes to confirm documentation has or will be uploaded to proceed.", "feeError");

                executionContext.getEventArgs().preventDefault();
            }
        }
    },

    ClearValidationError: function (executionContext) {
        "use strict";
        
        var formContext = executionContext.getFormContext();

        formContext.getControl("niq_acknowledgepodoc").clearNotification();
        formContext.getControl("niq_acknowledgeeoaupload").clearNotification();
        formContext.getControl("niq_acknowledgefundapprovalemail").clearNotification();
        formContext.getControl("niq_acknowledgecancellationapprovalemail").clearNotification();

        var type = CommonForm.Events.GetFieldValue(formContext, "niq_type");
        var ackPO = CommonForm.Events.GetFieldValue(formContext, "niq_acknowledgepodoc");
        var eoaUpload = CommonForm.Events.GetFieldValue(formContext, "niq_acknowledgeeoaupload");
        var fundApproval = CommonForm.Events.GetFieldValue(formContext, "niq_acknowledgefundapprovalemail");
        var cancellationApproval = CommonForm.Events.GetFieldValue(formContext, "niq_acknowledgecancellationapprovalemail");

        if (type == 100000001 && ackPO === true) {
            formContext.getControl("niq_acknowledgepodoc").clearNotification();
        }
        if (type == 100000002 && eoaUpload === true) {
            formContext.getControl("niq_acknowledgeeoaupload").clearNotification();
        }
        if (type == 100000004 && fundApproval === true) {
            formContext.getControl("niq_acknowledgefundapprovalemail").clearNotification();
        }
        if (type == 100000005 && cancellationApproval === true) {
            formContext.getControl("niq_acknowledgecancellationapprovalemail").clearNotification();
        }
    },
    updateForTaskStatus: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var type = CommonForm.Events.GetFieldValue(formContext, "niq_type");
        var taskStatus = formContext.getControl("statuscode");
        var pageType = Xrm.Utility.getGlobalContext().getQueryStringParameters().pageType; //quickcreate or entityrecord


        if (type != null) {
            //check if type = Global
            if (type == 100000000) {
                //non Bases
                //check if form = quick create
                if (pageType == 'quickcreate') {
                    //CommonForm.Events.ShowHideFields(formContext, ["statuscode"], true);

                } else {
                    //DYNCRM_2606
                    CommonForm.Events.ShowHideFields(formContext, ["header_prioritycode", "header_scheduledend"], true);
                    CommonForm.Events.ShowHideFields(formContext, ["statuscode"], false);
                }

            }
            else {
                //Bases
                if (pageType == 'quickcreate') {
                    CommonForm.Events.ShowHideFields(formContext, ["statuscode"], false);
                } else {
                    //DYNCRM_2606us
                    CommonForm.Events.ShowHideFields(formContext, ["header_prioritycode", "header_scheduledend"], false);
                    CommonForm.Events.ShowHideFields(formContext, ["statuscode"], true);
                    if (taskStatus != null) {
                        taskStatus.removeOption(4);
                        taskStatus.removeOption(7);
                    }
                }
            }
        }
    }
}