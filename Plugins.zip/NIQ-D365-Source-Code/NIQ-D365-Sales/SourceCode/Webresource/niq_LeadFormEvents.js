if (typeof (LeadForm) === "undefined") {
    LeadForm = {
        __namespace: true
    };
}

LeadForm.Events = {
    OnLoad: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        if (formType === 1) {
            formContext.data.entity.addOnPostSave(this.OnCreateReload);
            if ((CommonForm.Events.CheckFieldExists(formContext, "niq_industry")) && (CommonForm.Events.CheckValueExists(formContext, "niq_industry"))) {
                var value = formContext.getAttribute("niq_industry").getValue();
                if (value === 0) {
                    formContext.getAttribute("niq_industry").setValue(null);
                }
            }
        }
        formContext.data.process.addOnPreStageChange(this.OnStageChange);
        formContext.data.process.addOnStageChange(this.InfoNotification);
        this.InfoNotification(executionContext);
        this.LockUnlockCampaignCode(executionContext);
        this.ClearCurrency(executionContext);
        this.SalesGroupRequired(executionContext);
        this.ShowHideContactQuickViewForm(executionContext);
        this.PopulateFieldsfromDefaultSettings(executionContext);
    },
    OnStageChange: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var activeProcess = (formContext.data.process.getActiveProcess() !== null) ? (formContext.data.process.getActiveProcess().getName()) : null;
        var activeStage = (formContext.data.process.getActiveStage() !== null) ? (formContext.data.process.getActiveStage().getName()) : null;
        var direction = executionContext.getEventArgs().getDirection();
        if ((activeProcess === "Lead to Opportunity Process") && (direction === "Next") && (activeStage === "Engaging")) {

            var contactView = formContext.getControl("parentcontactid1");

            // var quickViewControl = formContext.ui.quickForms.get("ContactQuickView")

            var message = " ";
            if (contactView !== undefined) {
                var len = contactView.getControl().length;
                if (len > 0) {
                    if (contactView.getVisible()) {
                        var preLanguage = contactView.getControl().find(control => control._controlName === "niq_preferredlanguage").getAttribute();
                        if (preLanguage !== null && preLanguage.getValue() === null) {
                            message += "Preferred Language";
                        }
                        if (message !== " ") {
                            executionContext.getEventArgs().preventDefault();
                            var alertStrings = {
                                text: "Lead cannot be moved to Sales Ready until parent contact has the following details:" + message
                            };
                            Xrm.Navigation.openAlertDialog(alertStrings).then(function (success) { }, function (error) { });
                        }
                        return;
                    } else {
                        // Wait for some time and check again
                        setTimeout(getAttributeValue, 15, executionContext);
                        executionContext.getEventArgs().preventDefault();
                    }
                }
            }
        }
        if ((activeProcess === "Lead to Opportunity Process") && (direction === "Next") && (activeStage === "Sales Ready")) {
            var lead_id = formContext.data.entity.getId().replace('{', '').replace('}', '');

            var contactView = formContext.getControl("parentcontactid1");

            //  var quickViewControl = formContext.ui.quickForms.get("ContactQuickView");
            var message = " ";
            if (contactView !== undefined) {
                var len = contactView.getControl().length;
                if (len > 0) {
                    if (contactView.getVisible()) {
                        var jobTitle = contactView.getControl().find(control => control._controlName === "jobtitle").getAttribute();
                        if (jobTitle !== null && jobTitle.getValue() === null) {
                            message += "Title,";
                        }
                        var managementLevel = contactView.getControl().find(control => control._controlName === "niq_managementlevel").getAttribute();
                        if (managementLevel !== null && managementLevel.getValue() === null) {
                            message += "Management Level,";
                        }
                        var functionalArea = contactView.getControl().find(control => control._controlName === "niq_functionalarea").getAttribute();
                        if (functionalArea !== null && functionalArea.getValue() === null) {
                            message += "Functional Area,";
                        }
                        var preLanguage = contactView.getControl().find(control => control._controlName === "niq_preferredlanguage").getAttribute();
                        if (preLanguage !== null && preLanguage.getValue() === null) {
                            message += "Preferred Language,";
                        }
                        var parentAccount = contactView.getControl().find(control => control._controlName === "parentcustomerid").getAttribute();
                        if (parentAccount !== null && parentAccount.getValue() === null) {
                            message += "Account";
                        }
                        if (message !== " ") {
                            executionContext.getEventArgs().preventDefault();
                            var alertStrings = {
                                text: "Lead cannot be moved to the next stage until parent contact has the following details:" + message
                            };
                            Xrm.Navigation.openAlertDialog(alertStrings).then(function (success) { }, function (error) { });
                        } else {
                            var parameters = {};
                            var entity = {};
                            entity.id = lead_id;
                            entity.entityType = "lead";
                            parameters.entity = entity;
                            parameters.CreateAccount = false;
                            parameters.CreateContact = false;
                            parameters.CreateOpportunity = true;
                            parameters.Status = 3;
                            var qualifyLeadRequest = {
                                entity: parameters.entity,
                                CreateAccount: parameters.CreateAccount,
                                CreateContact: parameters.CreateContact,
                                CreateOpportunity: parameters.CreateOpportunity,
                                Status: parameters.Status,
                                getMetadata: function () {
                                    return {
                                        boundParameter: "entity",
                                        parameterTypes: {
                                            "entity": {
                                                "typeName": "mscrm.lead",
                                                "structuralProperty": 5
                                            },
                                            "CreateAccount": {
                                                "typeName": "Edm.Boolean",
                                                "structuralProperty": 1
                                            },
                                            "CreateContact": {
                                                "typeName": "Edm.Boolean",
                                                "structuralProperty": 1
                                            },
                                            "CreateOpportunity": {
                                                "typeName": "Edm.Boolean",
                                                "structuralProperty": 1
                                            },
                                            "Status": {
                                                "typeName": "Edm.Int32",
                                                "structuralProperty": 1
                                            }
                                        },
                                        operationType: 0,
                                        operationName: "QualifyLead"
                                    };
                                }
                            };
                            Xrm.WebApi.online.execute(qualifyLeadRequest).then(function success(result) {
                                if (result.ok) {
                                    //formContext.data.process.setStatus("finished");
                                    result.json().then(function (data) {
                                        var output = data.value[0];
                                        var oppId = output.opportunityid;
                                        var entityFormOptions = {};
                                        entityFormOptions["entityName"] = "opportunity";
                                        entityFormOptions["entityId"] = oppId;
                                        // Open the form.
                                        Xrm.Navigation.openForm(entityFormOptions).then(function (success) { }, function (error) { });
                                    });
                                }
                            }, function (error) {
                                Xrm.Navigation.openAlertDialog(error.message).then(function (success) { }, function (error) { });
                            });
                        }
                        return;
                    } else {
                        // Wait for some time and check again
                        setTimeout(getAttributeValue, 15, executionContext);
                    }
                }
            }
        }
    },
    OnCreateReload: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "firstname")) {
            var leadId = formContext.data.entity.getId().replace("{", "").replace("}", "");
            formContext.data.refresh(true).then(function refreshLead() {
                var entityFormOptions = {};
                entityFormOptions["entityName"] = "lead";
                entityFormOptions["entityId"] = leadId;

                // Open the form.
                Xrm.Navigation.openForm(entityFormOptions);
            });
        }
    },
    InfoNotification: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var activeProcess = (formContext.data.process.getActiveProcess() !== null) ? (formContext.data.process.getActiveProcess().getName()) : null;
        var activeStage = (formContext.data.process.getActiveStage() !== null) ? (formContext.data.process.getActiveStage().getName()) : null;
        if ((activeProcess === "Lead to Opportunity Process") && (activeStage === "Engaging")) {
            formContext.ui.setFormNotification("By moving the lead to the Sales Ready stage you confirm that you are ready to pass it on to a sales executive (when applicable)", "INFO", "Tele-Qualify");
        }
        else {
            formContext.ui.clearFormNotification("Tele-Qualify");
        }
        if ((activeProcess === "Lead to Opportunity Process") && (activeStage === "Sales Ready")) {
            formContext.ui.setFormNotification("By moving the lead to the Sales Qualified stage you confirm that you are ready to convert lead record into an opportunity", "INFO", "Sales Ready");
        }
        else {
            formContext.ui.clearFormNotification("Sales Ready");
        }
    },
    LockUnlockCampaignCode: function (executionContext) {
        'use strict';
        //function to to lock Campaign Code field on Lead form for all users except marketing users and admins
        var formContext = executionContext.getFormContext();
        //get formcontext
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_campaigncode")) {
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Marketing User,NIQ Business Admin,System Administrator,System Customizer")) {
                formContext.getControl("niq_campaigncode").setDisabled(false);
            }
            else {
                formContext.getControl("niq_campaigncode").setDisabled(true);
            }
        }
    },
    OnChangeCampaign: function (executionContext) {
        "use strict";
        //On change of Campaign clear Campaign Code
        var formContext = executionContext.getFormContext();
        if ((CommonForm.Events.CheckValueExists(formContext, "campaignid")) && (CommonForm.Events.CheckValueExists(formContext, "niq_campaigncode"))) {
            var campaign = formContext.getAttribute("campaignid").getValue();
            if (campaign !== null) {
                formContext.getAttribute("niq_campaigncode").setValue(null);
                formContext.getControl("niq_campaigncode").setDisabled(true);
            }
        }
    },
    OnChangeCampaignCode: function (executionContext) {
        "use strict";
        //On change of Campaign Code clear Campaign
        var formContext = executionContext.getFormContext();
        if ((CommonForm.Events.CheckValueExists(formContext, "campaignid")) && (CommonForm.Events.CheckValueExists(formContext, "niq_campaigncode"))) {
            var campaignCode = formContext.getAttribute("niq_campaigncode").getValue();
            if (campaignCode !== null) {
                formContext.getAttribute("campaignid").setValue(null);
                formContext.getControl("campaignid").setDisabled(true);
            }
        }
    },
    ClearCurrency: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        if (formType === 1) {
            formContext.getAttribute("transactioncurrencyid").setValue(null);
        }
    },

    setDefaultCurrencyView: function (executionContext) {
        var formContext = executionContext.getFormContext();
        //formContext.getControl("header_process_transactioncurrencyid");
        var defaultView = formContext.getControl("transactioncurrencyid").getDefaultView();
        try {
            formContext.getControl("header_process_transactioncurrencyid").setDefaultView(defaultView);
        } catch (err) { console.log(err); }
    },

    SalesGroupRequired: function (executionContext) {
        "use strict";
        //make Sales Org-Sales Group field required for valid Sales Org
        // get the form context
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_salesorgid") && (CommonForm.Events.CheckFieldExists(formContext, "niq_salesgroupsalesorgid")) && (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_salesgroupverified"))) {

            formContext.getAttribute("niq_salesgroupsalesorgid").setRequiredLevel("none");
            formContext.getControl("header_process_niq_salesgroupverified").getAttribute().setRequiredLevel("none");
            formContext.getControl("header_process_niq_salesgroupverified").setDisabled(true);
            if (CommonForm.Events.CheckValueExists(formContext, "niq_salesorgid")) {
                var salesOrg = formContext.getAttribute("niq_salesorgid").getValue();
                var salesOrg_id = salesOrg[0].id.replace('{', '').replace('}', '');
                // retrieve salesorgcode
                Xrm.WebApi.retrieveRecord("niq_salesorg", salesOrg_id, "?$select=niq_salesorgcode").then(
                    function success(result) {
                        if (result["niq_salesorgcode"] !== null) {
                            var salesOrgCode = result.niq_salesorgcode;
                            //retrieve Sales Org List_Oppoortunity_Lead configurationsetting
                            Xrm.WebApi.online.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_to&$filter=niq_name eq 'Sales%20Org%20List_Oppoortunity_Lead'").then(
                                function success(results) {
                                    if (result["niq_salesorgcode"] !== null) {
                                        var niq_to = results.entities[0]["niq_to"];
                                        if (niq_to !== null) {
                                            if (niq_to.includes(salesOrgCode)) {
                                                formContext.getAttribute("niq_salesgroupsalesorgid").setRequiredLevel("required");
                                                formContext.getControl("header_process_niq_salesgroupverified").getAttribute().setRequiredLevel("required");
                                                //formContext.getControl("header_process_niq_salesgroupverified").setDisabled(false);
                                                if (CommonForm.Events.CheckValueExists(formContext, "niq_salesgroupsalesorgid")) {
                                                    formContext.getControl("header_process_niq_salesgroupverified").getAttribute().setValue(true);
                                                }
                                                else {

                                                    formContext.getControl("header_process_niq_salesgroupverified").getAttribute().setValue(false);
                                                }
                                            }
                                            else {
                                                formContext.getAttribute("niq_salesgroupsalesorgid").setRequiredLevel("none");
                                                formContext.getControl("header_process_niq_salesgroupverified").getAttribute().setRequiredLevel("none");
                                                //formContext.getControl("header_process_niq_salesgroupverified").setDisabled(false);
                                                formContext.getControl("header_process_niq_salesgroupverified").getAttribute().setValue(true);
                                                //formContext.getAttribute("niq_salesgroupsalesorgid").setValue(true);
                                            }
                                        }
                                    }
                                },
                                function (error) {

                                }
                            );
                        }
                    },
                    function (error) {

                    }
                );
            }
            else {
                formContext.getControl("header_process_niq_salesgroupverified").getAttribute().setValue(false);
            }
        }
    },

    ShowHideContactQuickViewForm: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var parentContact = formContext.getAttribute("parentcontactid").getValue();

        if (parentContact != null && formContext.getAttribute('parentcontactid') != null) {
            formContext.getControl("parentcontactid1").setVisible(true);
        } else {
            formContext.getControl("parentcontactid1").setVisible(false);
        }

    },
    //DYNCRM-2090 and DYNCRM-2668 start line
    PopulateFieldsfromDefaultSettings: function (executionContext) { 
        var formContext = executionContext.getFormContext();
        if(formContext.getAttribute("niq_futureopportunitydecision").getValue()!=100000000)return;
        var userid = Xrm.Utility.getGlobalContext().userSettings.userId;
        userid = userid.substring(1, userid.length - 1);
 
        var ownerid = formContext.getAttribute("ownerid").getValue()[0].id;
        ownerid = ownerid.substring(1, ownerid.length - 1);
 
        if(ownerid==userid){
 
            Xrm.WebApi.retrieveMultipleRecords("niq_salesuserdefaultsettings", "?$select=_niq_defaultcurrency_value,niq_defaultsalescycleindaysnewsale,_niq_defaultsalesgroupsalesorg_value,_niq_defaultsalesorg_value,_niq_user_value&$filter=_owninguser_value eq "+userid).then(
            function success(results) {
                results = results.entities[0]; 
 
                let reqdate = new Date();
                reqdate.setDate(new Date().getDate()+results["niq_defaultsalescycleindaysnewsale"]);
                formContext.getAttribute("estimatedclosedate").setValue(reqdate);
                if (results["_niq_defaultcurrency_value"] != null) {
                    var currency = {
                        "entityType": results["_niq_defaultcurrency_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                        "id": results["_niq_defaultcurrency_value"],
                        "name": results["_niq_defaultcurrency_value@OData.Community.Display.V1.FormattedValue"]
                    };
                    formContext.getAttribute("transactioncurrencyid").setValue([currency]);
                }
                else {
                    formContext.getAttribute("transactioncurrencyid").setValue(null);
                }
                if (results["_niq_defaultsalesorg_value"] != null) {
                    var salesorg = {
                        "entityType": results["_niq_defaultsalesorg_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                        "id": results["_niq_defaultsalesorg_value"],
                        "name": results["_niq_defaultsalesorg_value@OData.Community.Display.V1.FormattedValue"]
                    };
                    formContext.getAttribute("niq_salesorgid").setValue([salesorg]);
                    LeadForm.Events.SalesGroupRequired(executionContext);
                    if (results["_niq_defaultsalesgroupsalesorg_value"]) {
                        var salesgroupsalesorg = {
                            "entityType": results["_niq_defaultsalesgroupsalesorg_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                            "id": results["_niq_defaultsalesgroupsalesorg_value"],
                            "name": results["_niq_defaultsalesgroupsalesorg_value@OData.Community.Display.V1.FormattedValue"]
                        };
                        formContext.getAttribute("niq_salesgroupsalesorgid").setValue([salesgroupsalesorg]);
                        formContext.getControl("niq_salesgroupsalesorgid").setDisabled(false);
                    }
                }
                else {
                    formContext.getAttribute("niq_salesorgid").setValue(null);
                    formContext.getAttribute("niq_salesgroupsalesorgid").setRequiredLevel("none");
                    formContext.getControl("niq_salesgroupsalesorgid").setDisabled(true);
                }
            },
            function(error) {
                console.log(error.message);
            }
            );
        }
    }
    //DYNCRM-2090 and DYNCRM-2668 end line
}
