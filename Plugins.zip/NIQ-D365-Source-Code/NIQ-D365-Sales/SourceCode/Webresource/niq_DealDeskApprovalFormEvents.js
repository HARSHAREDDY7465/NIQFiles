if (typeof (DealDeskForm) === "undefined") {
    DealDeskForm = {
        __namespace: true
    };
}

DealDeskForm.Events = {
    OnLoad: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        this.LockQuoteHeaderDetailsApprovalRequired(executionContext);
        this.RemoveOptionSet(executionContext);
        this.DisplayPaymentTermName(executionContext);
        this.setFieldAccessibility(executionContext);
        formContext.getAttribute("niq_agreementpaymenttermsid").addOnChange(this.DisplayPaymentTermName);
        //DYNCRM-22351 - Set Annual API as mandatory
        this.checkAnnualApiMandatory(executionContext);
        formContext.getAttribute("niq_apicolastructure").addOnChange(this.setaAnnualApiMandatory);
        this.hideDropdownOption(executionContext);

    },
    LockQuoteHeaderDetailsApprovalRequired: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if ((CommonForm.Events.CheckValueExists(formContext, "niq_quoteheaderdetailsapproval")) && ((formContext.getAttribute("niq_quoteheaderdetailsapproval").getValue() === 3) || (formContext.getAttribute("niq_quoteheaderdetailsapproval").getValue() === 4))) {
            CommonForm.Events.EnableOrDisableSection(formContext, "Summary", "Quote Header Values Approved By Deal Desk", true);
        }
        else {
            CommonForm.Events.EnableOrDisableSection(formContext, "Summary", "Quote Header Values Approved By Deal Desk", false);
        }
    },
    RemoveOptionSet: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckControlExists(formContext, "niq_pricingapproval")) {
            formContext.getControl("niq_pricingapproval").removeOption(100000000);
            formContext.getControl("niq_pricingapproval").removeOption(100000001);
            formContext.getControl("niq_pricingapproval").removeOption(100000002);
        }
        if (CommonForm.Events.CheckControlExists(formContext, "niq_fundusageapproval")) {
            formContext.getControl("niq_fundusageapproval").removeOption(1);
            formContext.getControl("niq_fundusageapproval").removeOption(2);
        }
        if (CommonForm.Events.CheckControlExists(formContext, "niq_quoteheaderdetailsapproval")) {
            formContext.getControl("niq_quoteheaderdetailsapproval").removeOption(1);
            formContext.getControl("niq_quoteheaderdetailsapproval").removeOption(2);
        }       
    },
    SetApprovalRejectionRequired: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var A = formContext.getAttribute("niq_pricingapproval").getValue();
        var B = formContext.getAttribute("niq_fundusageapproval").getValue();
        var C = formContext.getAttribute("niq_quoteheaderdetailsapproval").getValue();
        if (A != null || B != null || C != null) {

            formContext.getAttribute("niq_approvalrejectioncomments").setRequiredLevel("required");
        }
        else {

            formContext.getAttribute("niq_approvalrejectioncomments").setRequiredLevel("none");
        }
    },
    DisplayPaymentTermName: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var payTermId = formContext.getAttribute("niq_agreementpaymenttermsid").getValue();
        var Code = null;
        if (payTermId != null) {
            Code = payTermId[0].name;
        }
        if (Code != null) {
            var globalContext = Xrm.Utility.getGlobalContext();
            var serverUrl = globalContext.getClientUrl();
            var fetchPayterm = "<fetch top='1'><entity name='niq_paymentterm'><attribute       name='niq_paymenttermname' /><filter><condition attribute='niq_paymenttermcode' operator='eq' value='" + Code + "' />   </filter></entity></fetch>";
            var fetchResults = GetCRMWebAPI.Methods.GetFetchRecords(serverUrl, fetchPayterm, "niq_paymentterms");
            if (fetchResults !== null && fetchResults.value.length > 0 && fetchResults.value[0]['niq_paymenttermname'] !== null) {
                var Name = fetchResults.value[0]['niq_paymenttermname'];
                if (Name != null) {
                    formContext.getAttribute("niq_paymenttermdescription").setValue(Name);
                }
                else {
                    formContext.getAttribute("niq_paymenttermdescription").setValue(Code);
                }
            }
            else {
                formContext.getAttribute("niq_paymenttermdescription").setValue(Code);
            }
        }
        else {
            formContext.getAttribute("niq_paymenttermdescription").setValue();
        }
    },
    SetCurrentDateforOverallDealDeskApproval: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (formContext.getAttribute("niq_overalldealdeskapproval").getValue() == null) {
            formContext.getAttribute("niq_overalldealdeskapprovalstatusdate").setValue(null);
        }
        else {
            formContext.getAttribute("niq_overalldealdeskapprovalstatusdate").setValue(new Date());
        }
    },
    SetCurrentDateforPricingApproval: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (formContext.getAttribute("niq_pricingapproval").getValue() == null) {
            formContext.getAttribute("niq_pricingapprovalstatusdate").setValue(null);
        }
        else {
            formContext.getAttribute("niq_pricingapprovalstatusdate").setValue(new Date());
        }
    },
    SetCurrentDateforQuoteHeaderDetailsApproval: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (formContext.getAttribute("niq_quoteheaderdetailsapproval").getValue() == null) {
            formContext.getAttribute("niq_quoteheaderdetailsapprovalstatusdate").setValue(null);
        }
        else {
            formContext.getAttribute("niq_quoteheaderdetailsapprovalstatusdate").setValue(new Date());
        }
    },

    /**
     * Locking the  field for all systemadmin
     * 
     * @param {any} executionContext - The execution context provided by Dynamics 365 CRM Form
     */
    setFieldAccessibility: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var userRoles = CommonForm?.Events?.CheckIfLoggedInUserRoles?.("System Administrator,NIQ Add-on Deal Desk Approver");
        var fieldExists = CommonForm?.Events?.CheckFieldExists?.(formContext, "niq_reapprovalforanydiscountchange");
        if (userRoles && fieldExists) {
            formContext.getControl("niq_reapprovalforanydiscountchange")?.setDisabled(false);
        } else {
            formContext.getControl("niq_reapprovalforanydiscountchange")?.setDisabled(true);

        }

    },

    /**
     * Updates the (Re-approval will be needed for any Discount % change) field 
     * based on previous requests field related to the same quote entity.
     * This is an async function
     * @param {any} executionContext - The execution context provided by Dynamics 365 CRM Form
     */
    updateFieldBasedOnPreviousRequests: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var currentQuoteId = formContext.getAttribute("niq_quoteid")?.getValue()?.[0]['id'];

        // Define the FetchXML query to get existing DDAR records
        const fetchXml = `
        <fetch>
            <entity name="niq_dealdeskapprovalrequest">
                <attribute name="niq_reapprovalforanydiscountchange" />
                <filter type="and">
                    <condition attribute="niq_quoteid" operator="eq" value="${currentQuoteId}" />
                    <condition attribute="niq_reapprovalforanydiscountchange" operator="eq" value="1" />
                </filter>
            </entity>
        </fetch>
    `;

        // Fetch existing DDAR records using FetchXML
        const response = await Xrm.WebApi.retrieveMultipleRecords("niq_dealdeskapprovalrequest", `?fetchXml=${encodeURIComponent(fetchXml)}`);

        if (response.entities.length > 0) {
            formContext.getAttribute("niq_reapprovalforanydiscountchange")?.setValue(true);
        }
    },

    // Make Annual Api % mandatory if API/COLA Structure is Fixed annual percent increase.
    checkAnnualApiMandatory: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var apicolaStructure = formContext.getAttribute("niq_apicolastructure").getValue();
        if (apicolaStructure == 100000005) {
            formContext.getAttribute("niq_annualapicola").setRequiredLevel("required");
        } else {
            formContext.getAttribute("niq_annualapicola").setRequiredLevel("none");
        }
    },

    // Make Annual Api % empty when API/COLA Structure changes and make mandatory if Fixed annual percent increase is selected.
    setaAnnualApiMandatory: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var apicolaStructure = formContext.getAttribute("niq_apicolastructure").getValue();
        if (apicolaStructure == 100000005) {
            formContext.getAttribute("niq_annualapicola").setRequiredLevel("required");
            formContext.getAttribute("niq_annualapicola").setValue(null);
        } else {
            formContext.getAttribute("niq_annualapicola").setRequiredLevel("none");
            formContext.getAttribute("niq_annualapicola").setValue(null);
        }
    },

    // Hide Standard local index, discount factor option if todays date is greater then config date.
    hideDropdownOption: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var res = await Xrm.WebApi.retrieveRecord("niq_configurationsetting", "9b6c4806-ec9c-ef11-8a69-7c1e524e097b", "?$select=niq_date");
        var configDate = new Date(res["niq_date"]);
        var dateFieldValue = new Date();
        var year = dateFieldValue.getFullYear(); 
        var month = dateFieldValue.getMonth(); 
        var day = dateFieldValue.getDate(); 
        var todaysDate = new Date(year,month,day);
        var apicolaStructure = formContext.getAttribute("niq_apicolastructure").getValue();    
        var colaControl = formContext.getControl("niq_apicolastructure");
        if(formContext.ui.getFormType() == 1 || ((todaysDate > configDate)  && colaControl.getDisabled() == false)) {
            if (apicolaStructure == 100000000) {
                formContext.getAttribute("niq_apicolastructure").setValue(100000003);
            }
            formContext.getControl("niq_apicolastructure").removeOption(100000000);
        }

        // US-22627 remoing perpetual and Indefinite options
        var termType = formContext.getAttribute("niq_termtype").getValue();
        var termTypeControl = formContext.getControl("niq_termtype");
        if(formContext.ui.getFormType() == 1 || ((termType == null || termType == 100000000 || termType == 100000001) && termTypeControl.getDisabled() == false)){    // retaining value for historical records
            formContext.getControl("niq_termtype").removeOption(100000002);
            formContext.getControl("niq_termtype").removeOption(100000003);
        }
        else if (formContext.ui.getFormType() != 1 && ((termType == 100000002 || termType == 100000003) && termTypeControl.getDisabled() == false)){
            formContext.getAttribute("niq_termtype").setValue(100000000);
            formContext.getControl("niq_termtype").removeOption(100000002);
            formContext.getControl("niq_termtype").removeOption(100000003);
        }
    },
    
}