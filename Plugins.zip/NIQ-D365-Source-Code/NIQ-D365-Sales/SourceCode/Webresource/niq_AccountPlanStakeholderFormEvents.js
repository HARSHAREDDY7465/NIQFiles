if (typeof (AccountPlanStakeholderForm) === "undefined") {
    AccountPlanStakeholderForm =
        {
            __namespace: true
        };
}

AccountPlanStakeholderForm.Events =
    {
        RefreshRibbon: function (executionContext) {
            "use strict";
            var formContext = executionContext.getFormContext();
            formContext.ui.refreshRibbon();
        },
        CustomViewContact: function (executionContext) {
            "use strict";            
            var formContext = executionContext.getFormContext();

            if (CommonForm.Events.CheckFieldExists(formContext, "niq_accountname") &&
                CommonForm.Events.CheckValueExists(formContext, "niq_accountname")) {
                var parentaccountId = formContext.getAttribute("niq_accountname").getValue()[0].id;
                var viewId = formContext.getControl("niq_contact").getDefaultView();

                var entity = "contact";
                var ViewDisplayName = "All Contacts";
                var layout = "<grid name='resultset' object='2' jump='lastname' select='1' icon='1' preview='1'>" +
                    "<row name='result' id='contactid'>" +
                    "<cell name='fullname' width='300'/>" +
                    "<cell name='emailaddress1' width='100'/>" +
                    "</row>" +
                    "</grid>";

                var fetchXML = "";
                Xrm.WebApi.online.retrieveRecord("account", parentaccountId, "?$select=_niq_ultimateparentid_value").then(
                    function success(result) {
                        var ultimateParentId = result["_niq_ultimateparentid_value"];

                        if (ultimateParentId !== null) {
                            fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                "<entity name='contact'>" +
                                "<attribute name='fullname' />" +
                                "<attribute name='contactid' />" +
                                "<attribute name='emailaddress1' />" +
                                "<order attribute='fullname' descending='false' />" +
                                "<link-entity name='account' from='accountid' to='parentcustomerid' link-type='inner' alias='ac'>" +
                                "<filter type='and'>" +
                                "<condition attribute='accountid' operator='eq-or-under' uitype='account' value='{" + ultimateParentId + "}' />" +
                                "</filter>" +
                                "</link-entity>" +
                                "</entity>" +
                                "</fetch>";



                        }
                        else {

                            fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                "<entity name='contact'>" +
                                "<attribute name='fullname' />" +
                                "<attribute name='contactid' />" +
                                "<attribute name='emailaddress1' />" +
                                "<order attribute='fullname' descending='false' />" +
                                "<link-entity name='account' from='accountid' to='parentcustomerid' link-type='inner' alias='ac'>" +
                                "<filter type='and'>" +
                                "<condition attribute='accountid' operator='eq-or-under' uitype='account' value='" + parentaccountId + "' />" +
                                "</filter>" +
                                "</link-entity>" +
                                "</entity>" +
                                "</fetch>";



                        }


                        formContext.getControl("niq_contact").addCustomView(viewId, entity, ViewDisplayName, fetchXML, layout, false);

                    },
                    function (error) {
                        Xrm.Utility.alertDialog(error.message);
                    }
                );

            }
        },
    }