if (typeof (QuoteForm) === "undefined") {
    QuoteForm = {
        __namespace: true
    };
}

QuoteForm.Events = {
    FormOnload: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext(); // getting FormContext
        formContext.getAttribute("niq_elrevenueschedulecomplete").addOnChange(this.showNotificationonQuoteFormRevenueSchedule)
        formContext.getAttribute("niq_ddgpricingapprovallevel").addOnChange(this.HidingSectionifDDGPricingApprovalHasnoData)
        formContext.getAttribute("niq_ddgpricingapprovallevel").addOnChange(this.showPopupIfDDGApprovalLevelHasData)
        var formType = formContext.ui.getFormType();
        if (formType !== 1 && formType !== 4) {
            if (CommonForm.Events.CheckValueExists(formContext, "niq_dealdeskapproval")) {
                var approvalStatus = formContext.getAttribute("niq_dealdeskapproval").getValue();
                if (approvalStatus === 100000003) {
                    //CommonForm.Events.disableFormFields(true, formContext);
                    this.RefreshRibbon(executionContext);
                }
            }
            if (formContext.getAttribute("opportunityid") !== undefined && formContext.getAttribute("opportunityid") != null &&
                formContext.getAttribute("opportunityid").getValue() !== null && formContext.getAttribute("opportunityid").getValue().length > 0 &&
                formContext.getAttribute("opportunityid").getValue()[0].id !== undefined && formContext.getAttribute("opportunityid").getValue()[0].id != null)
                this.checkQPCLocking(executionContext);
        }
        this.SetMandatoryLevel(executionContext);
        //this.agreementTypeRequirementLevel(executionContext);
        this.MakeAgreementTypeAndAgreementLangmandatory(executionContext);
        this.DisclaimersLockSectionForSalesUser(executionContext);
        this.LockFormOnPendingDDAR(executionContext);
        this.showNotificationOnForm(executionContext);
        //this.OnOwnerChangePullSalesRepDetails(executionContext);
        if (formContext.getControl("RelatedRevenueSchedules") !== null)
            formContext.getControl("RelatedRevenueSchedules").setDisabled(true);
        if (formContext.getControl("RelatedBillingSchedules") !== null)
            formContext.getControl("RelatedBillingSchedules").setDisabled(true);
        //this.HideCongaSectionForNonPilot(executionContext);
        this.ParentMSAQuoteVisibility(executionContext);
        this.CustomViewParentMSAQuote(executionContext);
        this.lockNumberofFTE(executionContext);
        this.hideModeledDaysSalesOutstanding(executionContext);
        this.HideAdhocProductsonlyQuote(executionContext);
        this.displayMessageBlockedProduct(executionContext);
        this.lockunlockNonStandardBillingTerm(executionContext);
        this.showNotificationonQuoteFormRevenueSchedule(executionContext);
        this.setRequiredAgreementType(executionContext);
        this.hideAndShowDealGuidanceTab(executionContext);
        this.HidingSectionifDDGPricingApprovalHasnoData(executionContext);
        //this.showFormNotificationBasedOnPricingApproval(executionContext);
        this.hideAndShowDealDeskReviewAdditionalInformationSection(executionContext);
        this.showPopupIfDDGApprovalLevelHasData(executionContext);
        this.NotifyAlertMessage(executionContext);
        this.SetScheduleCompleted(executionContext);
        this.ShowNotificationOnceAysncInProgress(executionContext);
        this.UpdateNonStandardInquote(executionContext);
        this.SetPricingApproval(executionContext);
        this.HideDropdownOptionsAndFields(executionContext);
        this.hideAnnualIncreaseType(executionContext);
        this.HideIncentiveFields(executionContext);
    },
    HideAdhocProductsonlyQuote: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("System Administrator", "System Customizer", "NIQ Business Admin")) {
            formContext.getControl("niq_adhocproductsonlyquote").setVisible(true);
        }
        else {
            formContext.getControl("niq_adhocproductsonlyquote").setVisible(false);
        }
    },
    OnDealDeskApprovalChange: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_dealdeskapproval")) {
            var quoteId = formContext.data.entity.getId().replace("{", "").replace("}", "");
            formContext.data.refresh(true).then(function refreshQuote() {
                var entityFormOptions = {};
                entityFormOptions["entityName"] = "quote";
                entityFormOptions["entityId"] = quoteId;

                // Open the form.
                Xrm.Navigation.openForm(entityFormOptions);
            });
        }
    },
    hideAndShowDealGuidanceTab: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        if ((CommonForm.Events.CheckValueExists(formContext, "niq_ddgpricingapprovallevel")) || (CommonForm.Events.CheckValueExists(formContext, "niq_dealsaboveyourquotedpriceattainment")) || (CommonForm.Events.CheckValueExists(formContext, "niq_overalldealscore"))) {
            CommonForm.Events.ShowHideTabs(formContext, "tab_8", true);
            if (CommonForm.Events.CheckIfLoggedInUserRole("System Administrator")) {
                formContext.getControl("niq_embbededcanvasappforquotelist").setVisible(true);
                formContext.ui.tabs.get("tab_8").sections.get("tab_8_section_9").setVisible(true)
            }
            else if (CommonForm.Events.CheckIfLoggedInUserRole("NIQ Add-on Deal Desk Approver")) {
                formContext.getControl("niq_embbededcanvasappforquotelist").setVisible(true);
                formContext.ui.tabs.get("tab_8").sections.get("tab_8_section_9").setVisible(true)
            }
            else {
                formContext.getControl("niq_embbededcanvasappforquotelist").setVisible(false);
                formContext.ui.tabs.get("tab_8").sections.get("tab_8_section_9").setVisible(false);
            }
        }
        else {
            CommonForm.Events.ShowHideTabs(formContext, "tab_8", false);
        }
    },
    RefreshRibbon: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        formContext.ui.refreshRibbon();
    },
    checkQPCLocking: function (executionContext) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            if (formContext.getControl("QuoteProductCharacteristics") !== undefined && formContext.getControl("QuoteProductCharacteristics") !== null) {
                var fetch = "<fetch top='1' distinct='true' no-lock='true'>" +
                    "<entity name='opportunity'>" +
                    "<attribute name='niq_approvalstatus' />" +
                    "<attribute name='opportunityid' />" +
                    "<filter>" +
                    "<condition attribute='opportunityid' operator='eq' value='" + formContext.getAttribute("opportunityid").getValue()[0].id + "' />" +
                    "</filter>" +
                    "<link-entity name='niq_bpf_opportunity' from='bpf_opportunityid' to='opportunityid' link-type='inner' alias='bpf'>" +
                    "<attribute name='activestageid' />" +
                    "<link-entity name='processstage' from='processstageid' to='activestageid' alias='ps'>" +
                    "<attribute name='stagename' />" +
                    "<filter>" +
                    "<condition attribute='stagename' operator='eq' value='closed won - in review' />" +
                    "</filter>" +
                    "</link-entity>" +
                    "</link-entity>" +
                    "</entity>" +
                    "</fetch>";
                var fetchResults = GetCRMWebAPI.Methods.GetFetchRecords(Xrm.Utility.getGlobalContext().getClientUrl(), fetch, "opportunities");
                if (fetchResults !== null && fetchResults.value.length > 0 && fetchResults.value[0]['niq_approvalstatus'] !== undefined &&
                    fetchResults.value[0]['niq_approvalstatus'] !== null && (fetchResults.value[0]['niq_approvalstatus'] === 100000001 || fetchResults.value[0]['niq_approvalstatus'] === 100000000)) {
                    formContext.getControl("QuoteProductCharacteristics").setDisabled(true);
                    CommonForm.Events.EnableOrDisableSection(formContext, "Summary_tab", "Summary_tab_section_10", true);
                    CommonForm.Events.disableFormFields(true, formContext);
                }
                if (fetchResults !== null && fetchResults.value.length > 0 && fetchResults.value[0]['niq_approvalstatus'] !== undefined &&
                    fetchResults.value[0]['niq_approvalstatus'] !== null && fetchResults.value[0]['niq_approvalstatus'] === 100000002) {
                    CommonForm.Events.disableFormFields(true, formContext);
                }
            }
        }
        catch (e) {
            Xrm.Navigation.openErrorDialog(
                {
                    message: "Error occurd in QuoteForm.Events.checkQPCLocking method.",
                    details: e
                });
        }
    },


    SetDefaultValues: function (executionContext) {
        "use strict";
        // getting formcontext
        var formContext = executionContext.getFormContext();
        //based on conditions set values
        if ((CommonForm.Events.CheckValueExists(formContext, "niq_termtype")) && (CommonForm.Events.CheckValueExists(formContext, "niq_contractstartdate")) && (CommonForm.Events.CheckValueExists(formContext, "niq_contractenddate")) && (CommonForm.Events.CheckValueExists(formContext, "niq_salesorgid"))) {
            var termType = formContext.getAttribute("niq_termtype").getValue();
            var quoteId = formContext.data.entity.getId().replace("{", "").replace("}", "");
            var contractDuration = QuoteForm.Events.calculateContractDuration(quoteId);
            var salesOrg = formContext.getAttribute("niq_salesorgid").getValue()[0].name;
            if ((CommonForm.Events.CheckFieldExists(formContext, "niq_annualapicola")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_apistructure")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_evergreenautorenewalannualapi")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_terminationnotificationmonths"))) {
                if ((termType === 100000000 || termType === 100000001) && (contractDuration >= 13)) {
                    // formContext.getAttribute("niq_annualincreasetype").setRequiredLevel("required");
                    // if (formContext.getAttribute("niq_annualincreasetype").getValue() === null) {
                    //     if (salesOrg.includes("0500")) {
                    //         formContext.getAttribute("niq_annualincreasetype").setValue(100000001);
                    //     }
                    //     else {
                    //         formContext.getAttribute("niq_annualincreasetype").setValue(100000000);
                    //     }
                    // }

                    // if (formContext.getAttribute("niq_annualincreasetype").getValue() === 100000000) {
                    //     formContext.getAttribute("niq_annualapicola").setRequiredLevel("required");
                    //     formContext.getAttribute("niq_annualapicola").setValue(3);
                    // }
                    // else {
                    //     formContext.getAttribute("niq_annualapicola").setRequiredLevel("none");
                    //     formContext.getAttribute("niq_annualapicola").setValue(null);
                    // }

                    formContext.getAttribute("niq_apistructure").setRequiredLevel("required");
                    formContext.getAttribute("niq_apistructure").setValue(100000003);
                }
                else {
                    // formContext.getAttribute("niq_annualincreasetype").setRequiredLevel("none");
                    // formContext.getAttribute("niq_annualincreasetype").setValue(null);
                    formContext.getAttribute("niq_annualapicola").setRequiredLevel("none");
                    formContext.getAttribute("niq_annualapicola").setValue(null);
                    formContext.getAttribute("niq_apistructure").setRequiredLevel("none");
                    formContext.getAttribute("niq_apistructure").setValue(null);
                }
                if (termType === 100000000) {
                    formContext.getAttribute("niq_terminationnotificationmonths").setRequiredLevel("required");
                    if (contractDuration < 24) {
                        formContext.getAttribute("niq_terminationnotificationmonths").setValue(4);
                    }
                    else if (contractDuration >= 24 && contractDuration < 36) {
                        formContext.getAttribute("niq_terminationnotificationmonths").setValue(6);
                    }
                    else {
                        formContext.getAttribute("niq_terminationnotificationmonths").setValue(12);
                    }
                }
                else {
                    formContext.getAttribute("niq_terminationnotificationmonths").setRequiredLevel("none");
                    formContext.getAttribute("niq_terminationnotificationmonths").setValue(null);
                }
                if (termType === 100000000) {
                    formContext.getAttribute("niq_evergreenautorenewalannualapi").setRequiredLevel("required");
                    formContext.getAttribute("niq_evergreenautorenewalannualapi").setValue(5);
                }
                else {
                    formContext.getAttribute("niq_evergreenautorenewalannualapi").setRequiredLevel("none");
                    formContext.getAttribute("niq_evergreenautorenewalannualapi").setValue(null);
                }
            }
        }
    },
    DisclaimersLockSectionForSalesUser: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_overalldealdeskapproval")) {
            formContext.ui.clearFormNotification("PlaceholderDetermined");
            formContext.ui.clearFormNotification("ApprovalRequired");
            formContext.ui.clearFormNotification("NoApprovalRequired");
            formContext.ui.clearFormNotification("Approved");
            formContext.ui.clearFormNotification("SubmittedForApproval");
            formContext.ui.clearFormNotification("Rejected");
            if ((formContext.getAttribute("niq_overalldealdeskapproval").getValue() === 1) || (formContext.getAttribute("niq_overalldealdeskapproval").getValue() === 2)) {
                formContext.ui.setFormNotification("Before you share any commercial proposal based on this quote with your client, this quote needs to have 'Approved' or 'No Approval Required' status in the 'Overall Deal Desk Approval' field. The system will evaluate automatically if this quote requires approval or is auto-approved as soon as you delete any placeholder products related to it, enter real products and pricing details in Experlogix and complete the 'Quote header details' section. The result of this evaluation will be shown in 'Deal Desk Approval Status' section.", "INFO", "PlaceholderDetermined");
            }
            if ((formContext.getAttribute("niq_overalldealdeskapproval").getValue() === 3) || (formContext.getAttribute("niq_overalldealdeskapproval").getValue() === 4)) {
                formContext.ui.setFormNotification("The requested pricing on this quote is not in line with NIQ's policies and therefore requires an approval before you can share a respective commercial proposal with the client. Please refer to 'Deal Desk Approval Status' section for more information. You can either change quote details to be in line with standard rate card or submit this quote for deal desk approval when ready.", "INFO", "ApprovalRequired");
            }
            if (formContext.getAttribute("niq_overalldealdeskapproval").getValue() === 5) {
                formContext.ui.setFormNotification("This quote is in line with NIQ's policies and doesn't require additional approval. If this quote is finalized, you can share a commercial proposal based on this quote with your client when appropriate. If changes are made to this quote or its product and pricing details, the system will re-evaluate automatically and if any approval is needed, this will be reflected in the 'Deal Desk Approval Status' section.", "INFO", "NoApprovalRequired");
            }
            if (formContext.getAttribute("niq_overalldealdeskapproval").getValue() === 6) {
                formContext.ui.setFormNotification("This quote was approved by the deal desk.  You can share a commercial proposal based on this quote with your client when appropriate. If changes are made to this quote or its product and pricing details, the system will re-evaluate automatically and if any approval is needed, this will be reflected in the 'Deal Desk Approval Status' section.", "INFO", "Approved");
            }
            if (formContext.getAttribute("niq_overalldealdeskapproval").getValue() === 7) {
                formContext.ui.setFormNotification("This quote is submitted to deal desk for approval and is locked for editing. This quote will become editable again once deal desk approval/rejection is received. If deal desk review is no longer relevant for this quote, you can recall it from the deal desk queue.", "INFO", "SubmittedForApproval");
                if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User,NIQ Business Admin,System Administrator,System Customizer")) {
                    CommonForm.Events.EnableOrDisableSection(formContext, "Summary_tab", "Summary_tab_section_10", false);
                }
                else {
                    CommonForm.Events.EnableOrDisableSection(formContext, "Summary_tab", "Summary_tab_section_10", true);
                }
            }
            if (formContext.getAttribute("niq_overalldealdeskapproval").getValue() === 8) {
                formContext.ui.setFormNotification("This quote was rejected by deal desk.  Prior to any commercial proposal being shared with your client, a revision and possible re-submission for approval is required based on feedback provided by deal desk.", "INFO", "Rejected");
            }
        }
    },
    SetMandatoryLevel: function (executionContext) {
        "use strict";
        // getting formcontext
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_termtype")) {
            formContext.getAttribute("niq_termtype").setRequiredLevel("required");
        }
        if ((CommonForm.Events.CheckValueExists(formContext, "niq_termtype")) && (CommonForm.Events.CheckValueExists(formContext, "niq_contractstartdate")) && (CommonForm.Events.CheckValueExists(formContext, "niq_contractenddate")) && (CommonForm.Events.CheckValueExists(formContext, "niq_salesorgid"))) {
            var termType = formContext.getAttribute("niq_termtype").getValue();
            var quoteId = formContext.data.entity.getId().replace("{", "").replace("}", "");
            var contractDuration = QuoteForm.Events.calculateContractDuration(quoteId);
            //var contractDuration = parseInt(((endDate.getDate() - startDate.getDate()) / 30)) + (endDate.getMonth() - startDate.getMonth()) + (12 * (endDate.getFullYear() - startDate.getFullYear()));
            var salesOrg = formContext.getAttribute("niq_salesorgid").getValue()[0].name;
            if ((CommonForm.Events.CheckFieldExists(formContext, "niq_annualapicola")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_apistructure")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_evergreenautorenewalannualapi")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_terminationnotificationmonths"))) {
                if (termType === 100000000 || termType === 100000001) {
                    if (contractDuration >= 13) {
                        // formContext.getAttribute("niq_annualincreasetype").setRequiredLevel("required");
                        // if (formContext.getAttribute("niq_annualincreasetype").getValue() !== null && formContext.getAttribute("niq_annualincreasetype").getValue() === 100000000) {
                        //     formContext.getAttribute("niq_annualapicola").setRequiredLevel("required");
                        // }
                        // else {
                        //     formContext.getAttribute("niq_annualapicola").setRequiredLevel("none");
                        // }
                        formContext.getAttribute("niq_apistructure").setRequiredLevel("required");
                    }
                    if (termType === 100000000) {
                        formContext.getAttribute("niq_terminationnotificationmonths").setRequiredLevel("required");
                    }

                    // US-DYNCRM-22351
                    // set Annual API % field to required if API Structure is "Fixed annual percent increase"
                    if (CommonForm.Events.CheckFieldExists(formContext, "niq_apistructure")) {
                        var apiStructure = formContext.getAttribute("niq_apistructure").getValue();
                        if (apiStructure == 100000005) {
                            formContext.getAttribute("niq_annualapicola").setRequiredLevel("required");
                        }
                        else {
                            formContext.getAttribute("niq_annualapicola").setRequiredLevel("none");
                        }
                    }

                }
                else {
                    // formContext.getAttribute("niq_annualincreasetype").setRequiredLevel("none");
                    formContext.getAttribute("niq_annualapicola").setRequiredLevel("none");
                    formContext.getAttribute("niq_apistructure").setRequiredLevel("none");
                    formContext.getAttribute("niq_terminationnotificationmonths").setRequiredLevel("none");
                }
                if (termType === 100000000) {
                    formContext.getAttribute("niq_evergreenautorenewalannualapi").setRequiredLevel("required");
                }
                else {
                    formContext.getAttribute("niq_evergreenautorenewalannualapi").setRequiredLevel("none");
                }
            }
        }
    },
    showNotificationOnForm: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_congaagreementstatus")) {
            var status = formContext.getAttribute("niq_congaagreementstatus").getValue();
            if (status === 100000003) {
                formContext.ui.setFormNotification("Quote is currently locked for editing for one to two minutes until cancelation is completed in Conga. Refresh screen in one to two minutes to check again.", "INFO", "onclickofbutton1");
            }
            else {
                formContext.ui.clearFormNotification("onclickofbutton1");
            }
        }
    },
    LockFormOnPendingDDAR: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var quote = formContext.data.entity.getId().replace("{", "").replace("}", "");
        var globalContext = Xrm.Utility.getGlobalContext();
        var serverUrl = globalContext.getClientUrl();
        var fetcthDDAR = " ";
        fetcthDDAR = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
            "  <entity name='niq_dealdeskapprovalrequest'>" +
            "    <attribute name='niq_name' />" +
            "    <attribute name='createdon' />" +
            "    <attribute name='niq_quoteid' />" +
            "    <attribute name='ownerid' />" +
            "    <attribute name='niq_opportunityid' />" +
            "    <attribute name='niq_approvalstatus' />" +
            "    <attribute name='niq_dealdeskapprovalrequestid' />" +
            "    <order attribute='createdon' descending='true' />" +
            "    <filter type='and'>" +
            "      <condition attribute='niq_quoteid' operator='eq' uiname='1111139' uitype='quote' value='" + quote + "' />" +
            "      <condition attribute='niq_approvalstatus' operator='eq' value='1' />" +
            "    </filter>" +
            "    <link-entity name='quote' from='quoteid' to='niq_quoteid' visible='false' link-type='outer' alias='a_d96f887e7c52ec118c62000d3a5bc8e4'>" +
            "      <attribute name='totalamount' />" +
            "    </link-entity>" +
            "    <link-entity name='opportunity' from='opportunityid' to='niq_opportunityid' visible='false' link-type='outer' alias='a_115cf1557c52ec118c62000d3a5bc8e4'>" +
            "      <attribute name='parentaccountid' />" +
            "      <attribute name='niq_salesorgid' />" +
            "    </link-entity>" +
            "  </entity>" +
            "</fetch>";
        var fetcthDDARResults = GetCRMWebAPI.Methods.GetFetchRecords(serverUrl, fetcthDDAR, "niq_dealdeskapprovalrequests");
        if (fetcthDDARResults !== null && fetcthDDARResults.value.length > 0) {
            CommonForm.Events.disableFormFields(true, formContext);
        } else {
            CommonForm.Events.disableFormFields(false, formContext);
        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_congaagreementstatus")) {
            var congaStatus = formContext.getAttribute("niq_congaagreementstatus").getValue();
            if (congaStatus === 100000002) {
                CommonForm.Events.disableFormFields(true, formContext);
            } else if (congaStatus === 100000000) {
                CommonForm.Events.disableFormFields(false, formContext);
            } else if (congaStatus === 100000003) {
                CommonForm.Events.disableFormFields(false, formContext);
            } else if (congaStatus === 100000004) {
                CommonForm.Events.disableFormFields(false, formContext);
            } else if (congaStatus === 100000007) {
                CommonForm.Events.disableFormFields(true, formContext);
            } else {
                CommonForm.Events.disableFormFields(true, formContext);
            }
        }
    },
    /* HideCongaSectionForNonPilot: function (executionContext) {
         var formContext = executionContext.getFormContext();
         var clmgate1 = formContext.getAttribute("niq_clmgate1").getValue();
         var clmgate2 = formContext.getAttribute("niq_clmgate2").getValue();
         var agreementtypeandlanguage = ["niq_agreementlanguage"];
         var otherthanagreementfields = ["niq_agreementautomation", "niq_docusigncontactid", "niq_agreementnumber", "niq_congaagreementstatus", "niq_congasyncstatus", "niq_canceledreason", "niq_originalquoteid"];
         if (clmgate1 !== null && clmgate1 === true && clmgate2 !== true) {
             CommonForm.Events.ShowHideFields(formContext, agreementtypeandlanguage, true);
             CommonForm.Events.ShowHideFields(formContext, otherthanagreementfields, false);
         }
         else if (clmgate1 !== null && clmgate1 === true && clmgate2 !== null && clmgate2 === true) {
             CommonForm.Events.ShowHideFields(formContext, agreementtypeandlanguage, true);
             CommonForm.Events.ShowHideFields(formContext, otherthanagreementfields, true);
         }
         else {
             CommonForm.Events.ShowHideFields(formContext, agreementtypeandlanguage, false);
             CommonForm.Events.ShowHideFields(formContext, otherthanagreementfields, false);
         }
     },*/
    ParentMSAQuoteVisibility: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if ((CommonForm.Events.CheckFieldExists(formContext, "niq_agreementtype")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_parentmsaquoteid"))) {
            if (CommonForm.Events.CheckValueExists(formContext, "niq_agreementtype") && formContext.getAttribute("niq_agreementtype").getValue() === 100000002) {
                formContext.getControl("niq_parentmsaquoteid").setVisible(true);
            }
            else {
                formContext.getControl("niq_parentmsaquoteid").setVisible(false);
                formContext.getAttribute("niq_parentmsaquoteid").setValue(null);
            }
        }
    },
    MakeAgreementTypeAndAgreementLangmandatory: function (executionContext) {
        formContext = executionContext.getFormContext();
        var stageName;
        var isMainQuote = formContext.getAttribute("niq_mainquote").getValue();
        var opportunity = formContext.getAttribute("opportunityid").getValue();
        if (opportunity != null) {
            var OpportunityId = opportunity[0].id;
            if (isMainQuote) {
                Xrm.WebApi.retrieveRecord("opportunity", OpportunityId, "?$select=niq_stage").then(
                    function success(result) {
                        stageName = result.niq_stage;
                        if (stageName != "Pre-Proposal" && stageName != "Proposal" && stageName != null) {
                            formContext.getAttribute("niq_agreementlanguage").setRequiredLevel("required");
                        }
                        else {
                            formContext.getAttribute("niq_agreementlanguage").setRequiredLevel("none");
                        }
                    },
                    function (error) {
                        console.log(error.message);
                    }
                );

            }
        }


    },
    OnChangeofAgreementTypeAndLanguage: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var agreementType = CommonForm.Events.CheckValueExists(formContext, "niq_agreementtype") ? formContext.getAttribute("niq_agreementtype").getValue() : null;
        var agreementLanguage = CommonForm.Events.CheckValueExists(formContext, "niq_agreementlanguage") ? formContext.getAttribute("niq_agreementlanguage").getValue() : "";
        if (agreementType != null && agreementType != null) {
            var fetchXml = "?fetchXml=<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'><entity name='niq_clmgate2'><attribute name='niq_clmgate2id' /><attribute name='niq_agreementtype' /><attribute name='niq_agreementlanguage' /><order attribute='niq_agreementtype' descending='false' /><filter type='and'><condition attribute='niq_agreementlanguage' operator='eq' value='" + agreementLanguage + "' /><condition attribute='niq_agreementtype' operator='eq' value='" + agreementType + "' /></filter></entity></fetch>";

            Xrm.WebApi.retrieveMultipleRecords("niq_clmgate2", fetchXml).then(
                function success(result) {
                    if (result.entities.length > 0) {
                        formContext.getAttribute("niq_clmgate2").setValue(true);
                    }
                    else {
                        formContext.getAttribute("niq_clmgate2").setValue(false);
                    }


                },
                function (error) {
                    console.log(error.message);
                    // handle error conditions
                }
            );


        }
        else {
            formContext.getAttribute("niq_clmgate2").setValue(false);
        }
    },
    CustomViewParentMSAQuote: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "opportunityid") && CommonForm.Events.CheckFieldExists(formContext, "niq_parentmsaquoteid")) {
            var entityName = "quote";
            var viewName = "All Quotes";
            var viewId = "d25ac69d-ffc7-4f96-83b1-ea1b5ec06b58";
            var viewLayout = "<grid name='resultset' object='10101' jump='name' select='1' icon='1' preview='1'>" +
                "<row name='result' id='quoteid'>" +
                "<cell name='name' width='200'/>" +
                "<cell name='niq_agreementnumber' width='100'/>" +
                "<cell name='opportunityid' width='100'/>" +
                "<cell name='a_8722b5f2a2eceb11bacb000d3a35ee6d.parentaccountid' width='100'/>" +
                "<cell name='totalamount' width='100'/>" +
                "</row>" +
                "</grid>";
            var opportunityid = formContext.getAttribute("opportunityid").getValue()[0].id;
            var reqQuoteResult = "";
            Xrm.WebApi.online.retrieveRecord("opportunity", opportunityid, "?$expand=parentaccountid($select=accountid,_niq_ultimateparentid_value)").then(
                function success(result) {
                    if (result.hasOwnProperty("parentaccountid")) {
                        var accountId = result["parentaccountid"]["accountid"];
                        var ultimateParentId = result["parentaccountid"]["_niq_ultimateparentid_value"];
                    }
                    if (accountId !== null) {
                        if (ultimateParentId !== null) {
                            reqQuoteResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                "<entity name='quote'>" +
                                "<attribute name='name' />" +
                                "<attribute name='totalamount' />" +
                                "<attribute name='opportunityid' />" +
                                "<attribute name='quoteid' />" +
                                "<attribute name='niq_agreementnumber' />" +
                                "<order attribute='name' descending='false' />" +
                                "<filter type='and'>" +
                                "<condition attribute='niq_agreementtype' operator='eq' value='100000003' />" +
                                "<condition attribute='niq_agreementnumber' operator='not-null' />" +
                                "</filter>" +
                                "<link-entity name='opportunity' from='opportunityid' to='opportunityid' link-type='inner' alias='a_8722b5f2a2eceb11bacb000d3a35ee6d'>" +
                                "<attribute name='parentaccountid' />" +
                                "<link-entity name='account' from='accountid' to='parentaccountid' link-type='inner' alias='af'>" +
                                "<filter type='and'>" +
                                "<filter type='or'>" +
                                "<condition attribute='niq_ultimateparentid' operator='eq' uitype='account' value='" + ultimateParentId + "' />" +
                                "<condition attribute='accountid' operator='eq' uitype='account' value='" + ultimateParentId + "' />" +
                                "</filter>" +
                                "</filter>" +
                                "</link-entity>" +
                                "</link-entity>" +
                                "</entity>" +
                                "</fetch>"
                        }
                        else {
                            reqQuoteResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                "<entity name='quote'>" +
                                "<attribute name='name' />" +
                                "<attribute name='totalamount' />" +
                                "<attribute name='opportunityid' />" +
                                "<attribute name='quoteid' />" +
                                "<attribute name='niq_agreementnumber' />" +
                                "<order attribute='name' descending='false' />" +
                                "<filter type='and'>" +
                                "<condition attribute='niq_agreementtype' operator='eq' value='100000003' />" +
                                "<condition attribute='niq_agreementnumber' operator='not-null' />" +
                                "</filter>" +
                                "<link-entity name='opportunity' from='opportunityid' to='opportunityid' link-type='inner' alias='a_8722b5f2a2eceb11bacb000d3a35ee6d'>" +
                                "<attribute name='parentaccountid' />" +
                                "<link-entity name='account' from='accountid' to='parentaccountid' link-type='inner' alias='af'>" +
                                "<filter type='and'>" +
                                "<filter type='or'>" +
                                "<condition attribute='niq_ultimateparentid' operator='eq' uitype='account' value='" + accountId + "' />" +
                                "<condition attribute='accountid' operator='eq' uitype='account' value='" + accountId + "' />" +
                                "</filter>" +
                                "</filter>" +
                                "</link-entity>" +
                                "</link-entity>" +
                                "</entity>" +
                                "</fetch>"
                        }
                        formContext.getControl("niq_parentmsaquoteid").addCustomView(viewId, entityName, viewName, reqQuoteResult, viewLayout, true);
                    }
                },
                function (error) {

                }
            );
        }
    },
    agreementTypeRequirementLevel: function (executionContext) {
        formContext = executionContext.getFormContext();

        if (formContext.getAttribute("niq_mainquote").getValue() !== "" || formContext.getAttribute("niq_mainquote").getValue() !== null || formContext.getAttribute("niq_mainquote").getValue() !== undefined) {
            var isMainQuote = formContext.getAttribute("niq_mainquote").getValue();
            if (isMainQuote) {
                formContext.getControl("niq_agreementtype").setVisible(true);
                formContext.getAttribute("niq_agreementtype").setRequiredLevel("required");
            }
            else {
                formContext.getControl("niq_agreementtype").setVisible(false);
                formContext.getAttribute("niq_agreementtype").setRequiredLevel("none");
            }
        }
    },

    displayPaymentTermName: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var payTermId = formContext.getAttribute("niq_paymenttermsid").getValue();
        var Code = null;
        if (payTermId != null) {
            var Id = payTermId[0].id;
            Code = payTermId[0].name;
            var EntityType = payTermId[0].entityType;
        }

        if (Code != null) {
            var globalContext = Xrm.Utility.getGlobalContext();
            var serverUrl = globalContext.getClientUrl();
            var fetchPayterm = "<fetch top='1'><entity name='niq_paymentterm'><attribute name='niq_paymenttermname' /><filter><condition attribute='niq_paymenttermcode' operator='eq' value='" + Code + "' />   </filter></entity></fetch>";
            var fetchResults = GetCRMWebAPI.Methods.GetFetchRecords(serverUrl, fetchPayterm, "niq_paymentterms");
            if (fetchResults !== null && fetchResults.value.length > 0 && fetchResults.value[0]['niq_paymenttermname'] !== null) {
                var Name = fetchResults.value[0]['niq_paymenttermname'];
                if (Name != null) {
                    formContext.getAttribute("niq_paymenttermdescription").setValue(Name);
                }
                else {
                    formContext.getAttribute("niq_paymenttermdescription").setValue(Code);
                }
            }
            else {
                formContext.getAttribute("niq_paymenttermdescription").setValue(Code);
            }
        }
        if (!CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator")) {
            formContext.getControl("niq_paymenttermdescription").setDisabled(true);
        }
    },
    lockNumberofFTE: function (executionContext) {
        var formContext = executionContext.getFormContext();

        if (!CommonForm.Events.CheckIfLoggedInUserRole("System Administrator")) {
            formContext.getControl("niq_numberofftes").setDisabled(true);
        }
    },

    hideModeledDaysSalesOutstanding: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRole("NIQ Sales User")) {
            formContext.getControl("niq_modeleddayssalesoutstanding").setVisible(false);
        }
    },

    displayMessageBlockedProduct: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        formContext.getControl("niq_blockedproductdesc").setVisible(false);
        var blockedProdDesc = formContext.getAttribute("niq_blockedproductdesc").getValue();
        if (blockedProdDesc != null) {
            Xrm.Page.ui.setFormNotification("This cloned opportunity contains the following blocked products which must be removed in Experlogix before this opportunity can be closed to avoid SAP integration failure: " + blockedProdDesc, "WARNING");
        }
    },
    lockunlockNonStandardBillingTerm: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        if (!CommonForm.Events.CheckIfLoggedInUserRole("System Administrator")) {
            formContext.getControl("niq_nonstandardbillingterm").setDisabled(true);
        }
    },
    showNotificationonQuoteFormRevenueSchedule: function (executionContext) {
        "use strict";

        var formContext = executionContext.getFormContext();
        var revenueSchedule = formContext.getAttribute("niq_elrevenueschedulecomplete").getValue();
        var date = formContext.getAttribute("niq_contractstartdate").getValue();

        if (revenueSchedule === false && revenueSchedule !== null && date !== null) {
            formContext.ui.setFormNotification("There is still unscheduled revenue on at least one product within the main Quote, which is negatively impacting the accuracy of NIQ pipeline and revenue forecast numbers. Please return to Quote Product tab to close this gap asap and also to be able to proceed to the next stage.", "ERROR", "revenueSchedule");
        }
        else {
            formContext.ui.clearFormNotification("revenueSchedule");
        }
    },
    setRequiredAgreementType: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        var opportunity = formContext.getAttribute("opportunityid").getValue();
        var isMainQuote = formContext.getAttribute("niq_mainquote").getValue();
        if (opportunity != null) {
            var OpportunityId = opportunity[0].id;
            if (isMainQuote) {
                Xrm.WebApi.retrieveRecord("opportunity", OpportunityId, "?$select=niq_stage").then(
                    function success(result) {
                        var stageName = result["niq_stage"];
                        if (stageName === "Negotiation" || stageName === "Closed Won - In Review") {
                            formContext.getAttribute("niq_agreementtype").setRequiredLevel("required");
                        }
                        else {
                            formContext.getAttribute("niq_agreementtype").setRequiredLevel("none");
                        }
                    },
                    function (error) {
                        console.log(error.message);
                    }
                );

            }
        }
    },
    // Populate Contract Start and End Date in Quote
    setContractStartAndEndDate: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var currentQuoteId = formContext.data.entity.getId();
        var currentEntityName = formContext.data.entity.getEntityName();
        var currentStartDate = formContext.getAttribute("niq_contractstartdate")?.getValue();
        var currentEndDate = formContext.getAttribute("niq_contractenddate")?.getValue();
        var startDate = null;
        var endDate = null;

        if (currentQuoteId != null) {
            startDate = await QuoteForm.Events.quoteProductStartDate(currentQuoteId);
            endDate = await QuoteForm.Events.quoteProductEndDate(currentQuoteId);

            if (startDate != null && endDate != null && currentStartDate != null && currentEndDate != null && currentStartDate.toISOString().slice(0, 10) === startDate.slice(0, 10) && currentEndDate.toISOString().slice(0, 10) === endDate.slice(0, 10)) {
                return;
            } else {
                if (startDate != null && endDate != null) {
                    var data =
                    {
                        "niq_contractstartdate": startDate,
                        "niq_contractenddate": endDate
                    }
                    await Xrm.WebApi.updateRecord(currentEntityName, currentQuoteId, data);
                    formContext.data.refresh(true)
                }

                if (startDate != null && endDate != null) {
                    let opportunity = formContext.getAttribute("opportunityid")?.getValue();
                    var record = {};
                    record.niq_contractstartdate = startDate; // Strat Time
                    record.niq_contractenddate = endDate; // End Time
                    //update the Contract Start and end date on opportunity
                    await Xrm.WebApi.updateRecord("opportunity", opportunity[0].id.replace("{", "").replace("}", ""), record);
                }
                //formContext.data.save();
            }
        }
    },
    /**
 * show/Hide if DDG PricingApprovallevel field is Populated.!
 * @param {any} executionContext - The execution context provided by the Dynamics 365 CRM form.
 */
    HidingSectionifDDGPricingApprovalHasnoData: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        const ddgPricingApprovalLevelField = formContext.getAttribute("niq_ddgpricingapprovallevel")?.getValue();

        if (!ddgPricingApprovalLevelField) {
            formContext.ui.tabs.get("Summary_tab")?.sections.get("Summary_tab_section_15")?.setVisible(false);
        } else if (ddgPricingApprovalLevelField) {
            formContext.ui.tabs.get("Summary_tab")?.sections.get("Summary_tab_section_15")?.setVisible(true);
        }
    },

    /**
     * Notification if Pricing Approval as To be Determined
     * @param {any} executionContext - The execution context provided by the Dynamics 365 CRM form.
     */
    /* showFormNotificationBasedOnPricingApproval: function (executionContext) {
         "use strict";
         var formContext = executionContext.getFormContext();
         var pricingApprovalValue = formContext.getAttribute("niq_dealdeskapproval")?.getValue();
 
         if (pricingApprovalValue === 100000000) {
             var notificationMessage = "This Quote might qualify for the Deal Guidance. If yes, the information will be available in up to 30 seconds in the new Deal Guidance tab. If not, please proceed with your standard process.";
             formContext.ui.setFormNotification(notificationMessage, "INFO", "pricingApprovalNotification");
         } else {
             formContext.ui.clearFormNotification("pricingApprovalNotification");
         }
     },*/
    /**
 * show/Hide DealDeskReviewAdditionalInformation section based on the user role, this section would be visible only to the users who has "NIQ Add-on Deal Desk Approver,System Administrator" roles.!
 * @param {any} executionContext - The execution context provided by the Dynamics 365 CRM form.
 */

    hideAndShowDealDeskReviewAdditionalInformationSection: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add-on Deal Desk Approver,System Administrator")) {
            formContext.ui.tabs.get("tab_8").sections.get("niq_dealdesk")?.setVisible(true);
        } else {
            formContext.ui.tabs.get("tab_8").sections.get("niq_dealdesk")?.setVisible(false);
        }
    },

    /**
     * POP-UP if DDGpricingApprovallevel has Data
     * @param {any} executionContext - The execution context provided by the Dynamics 365 CRM form.
     */
    showPopupIfDDGApprovalLevelHasData: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var ddgPricingApprovalLevelField = formContext.getAttribute("niq_ddgpricingapprovallevel");
        var alertFlagField = formContext.getAttribute("niq_alertflag");

        // Ensure ddgPricingApprovalLevelField and alertFlagField are accessible
        if (!ddgPricingApprovalLevelField || !alertFlagField) {
            console.error("One or more required fields are missing or not accessible on the form.");
            return;
        }

        // Function to handle the popup display
        function handlePopup() {
            var ddgPricingApprovalLevelValue = ddgPricingApprovalLevelField.getValue();
            var alertFlagValue = alertFlagField.getValue();

            // Check conditions and show the popup if criteria are met
            if (ddgPricingApprovalLevelValue !== null && !alertFlagValue) {
                var message = "Deal Guidance result is available! Click on the Deal Guidance tab to see more.";
                Xrm.Navigation.openAlertDialog({
                    text: message,
                    confirmButtonLabel: "OK"
                }).then(
                    function () {
                        alertFlagField.setValue(true); // Set niq_alertflag to true
                        formContext.data.entity.save(); // Save the form after setting the flag
                    },
                    function (error) {
                        console.log("Error: " + error.message); // Log any errors
                    }
                );
            }
        }

        // Reset alertFlagField to false when ddgPricingApprovalLevelField changes
        ddgPricingApprovalLevelField.addOnChange(function () {
            alertFlagField.setValue(false);
            formContext.data.entity.save();
            handlePopup(); // Call handlePopup after the field changes
        });

        // Call handlePopup initially when the form loads

        handlePopup();

    },
    quoteProductStartDate: async function (quoteGuid) {
        var returnStartDate = null;
        var result = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", "?$select=quotedetailid,productname,niq_lineitemstartdate&$filter=(productname ne 'SAP Deferred Revenue reconciliation placeholder' and niq_lineitemstartdate ne null and _quoteid_value eq '" + quoteGuid + "')&$orderby=niq_lineitemstartdate asc&$top=1");
        if (result.entities.length > 0) {
            if (QuoteForm.Events.IsValid(result) && QuoteForm.Events.IsValid(result.entities[0]) && QuoteForm.Events.IsValid(result.entities[0].niq_lineitemstartdate)) {
                returnStartDate = result.entities[0].niq_lineitemstartdate;
            }

            return returnStartDate;
        }
    },
    quoteProductEndDate: async function (quoteGuid) {
        var returnEndDate = null;
        var result = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", "?$select=quotedetailid,productname,niq_lineitemenddate&$filter=(productname ne 'SAP Deferred Revenue reconciliation placeholder' and niq_lineitemenddate ne null and _quoteid_value eq '" + quoteGuid + "')&$orderby=niq_lineitemenddate desc&$top=1");
        if (result.entities.length > 0) {
            if (QuoteForm.Events.IsValid(result) && QuoteForm.Events.IsValid(result.entities[0]) && QuoteForm.Events.IsValid(result.entities[0].niq_lineitemenddate)) {
                returnEndDate = result.entities[0].niq_lineitemenddate;
            }
            return returnEndDate;
        }
    },
    RegisterMessageListener: function (executionContext) {
        const formContext = executionContext.getFormContext();
        window.addEventListener("message", (e) => {
            console.log("registered OnMessage", e);
            if (e.data?.messageName === "QuoteProduct.SidePaneChanged") {
                const data = e.data.data;
                console.log(data);
                if (formContext.data.entity.getEntityName() == data.entityName && formContext.data.entity.getId() == data.recordId) {
                    formContext.data.refresh(true);
                }
                else {
                    //to do: check if it's the subgrid entityName
                    formContext.ui.controls.get("QuoteProduct")?.refresh();
                }
            }
        });
    },
    IsValid: function (attr) {
        "use strict";
        let isValidAttribute = false;
        if (attr !== null && attr !== "null" && attr !== "undefind" && attr !== undefined) {
            isValidAttribute = true;
        }
        return isValidAttribute;
    },
    //Alert notify message if the date change in quote product schedule
    NotifyAlertMessage: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var booleanField = formContext.getAttribute("niq_notifydatechangeforcustomschedule").getValue();

        if (booleanField && booleanField != null) {  // If the boolean field value is Yes (true)
            var alertStrings = {
                confirmButtonLabel: "OK",
                text: 'There exists a "Custom Schedule" on the quote,  please review to make sure they are accurate.',
                title: "Confirmation"
            };
            var alertOptions = { height: 200, width: 450 };

            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions).then(
                function (success) {
                    // Set the boolean field to No
                    formContext.getAttribute("niq_notifydatechangeforcustomschedule").setValue(false);
                    // Save the record
                    formContext.data.save();
                    //formContext.data.refresh();
                    //formContext.getAttribute("niq_notifydatechangeforcustomschedule").setSubmitMode("always");
                },
                function (error) {
                    console.log(error.message);
                }
            );
        }
    }, SetScheduleCompleted: async function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var currentQuoteId = formContext.data.entity.getId();
        let isRevenueSchedulesComplete = false;
        let isBillingScheduleComplete = false;
        let QuoteProductCount = await QuoteForm.Events.GetAllQuoteRecordsCount(currentQuoteId);
        let elBillingScheduleComplete = formContext.getAttribute("niq_elbillingschedulecomplete");
        let elRevenueScheduleComplete = formContext.getAttribute("niq_elrevenueschedulecomplete");
        if (QuoteProductCount === 0) {
            elBillingScheduleComplete.setValue(false);
            elBillingScheduleComplete.setSubmitMode("always");
            elRevenueScheduleComplete.setValue(false);
            elRevenueScheduleComplete.setSubmitMode("always");
            return;
        }
        if (currentQuoteId != null && QuoteForm.Events.IsValid(currentQuoteId)) {
            isRevenueSchedulesComplete = await QuoteForm.Events.GetAllRevenueschedulecompleteQuote(currentQuoteId.replace("{", "").replace("}", ""));
            if (isRevenueSchedulesComplete != null && isRevenueSchedulesComplete) {

                if (QuoteForm.Events.IsValid(elRevenueScheduleComplete)) {
                    elRevenueScheduleComplete.setValue(isRevenueSchedulesComplete);
                    elRevenueScheduleComplete.setSubmitMode("always");
                } else {
                    elRevenueScheduleComplete.setValue(isRevenueSchedulesComplete);
                    elRevenueScheduleComplete.setSubmitMode("always");
                }
            } else {
                if (QuoteForm.Events.IsValid(elRevenueScheduleComplete)) {
                    elRevenueScheduleComplete.setValue(isRevenueSchedulesComplete);
                    elRevenueScheduleComplete.setSubmitMode("always");
                } else {
                    elRevenueScheduleComplete.setValue(isRevenueSchedulesComplete);
                    elRevenueScheduleComplete.setSubmitMode("always");
                }
            }
            isBillingScheduleComplete = await QuoteForm.Events.GetAllBillingschedulecompleteQuote(currentQuoteId.replace("{", "").replace("}", ""));
            if (isBillingScheduleComplete != null && isBillingScheduleComplete) {
                if (QuoteForm.Events.IsValid(elBillingScheduleComplete)) {
                    elBillingScheduleComplete.setValue(isBillingScheduleComplete);
                    elBillingScheduleComplete.setSubmitMode("always");
                } else {
                    elBillingScheduleComplete.setValue(isBillingScheduleComplete);
                    elBillingScheduleComplete.setSubmitMode("always");
                }
            } else {
                if (QuoteForm.Events.IsValid(elBillingScheduleComplete)) {
                    elBillingScheduleComplete.setValue(isBillingScheduleComplete);
                    elBillingScheduleComplete.setSubmitMode("always");
                } else {
                    elBillingScheduleComplete.setValue(isBillingScheduleComplete);
                    elBillingScheduleComplete.setSubmitMode("always");
                }
            }
        }
    },

    GetAllRevenueschedulecompleteQuote: async function (quoteId) {
        "use strict";
        let isRevenueCompleted = false;
        var fetchXml = `
        <fetch aggregate="true">
            <entity name="quotedetail">
                <attribute name="niq_revenueschedulecomplete" aggregate="count" alias="countOfRecords"/>
                <filter type="and">
                    <condition attribute="quoteid" operator="eq" value="${quoteId}" />
                    <condition attribute="niq_revenueschedulecomplete" operator="eq" value="0" />
                </filter>
            </entity>
        </fetch>`;

        // Encode the FetchXML query for the API request
        //  var encodedFetchXml = encodeURIComponent(fetchXml);
        var fetchXmlRequest = "?fetchXml=" + encodeURIComponent(fetchXml);

        // Make the Web API call
        var result = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", fetchXmlRequest);

        if (QuoteForm.Events.IsValid(result) && QuoteForm.Events.IsValid(result.entities[0]) && QuoteForm.Events.IsValid(result.entities[0].countOfRecords) && result.entities[0].countOfRecords === 0) {
            isRevenueCompleted = true;
        }
        return isRevenueCompleted;
    },
    GetAllBillingschedulecompleteQuote: async function (quoteId) {
        "use strict";
        let isRevenueCompleted = false;
        var fetchXml = `
         <fetch aggregate="true">
             <entity name="quotedetail">
                 <attribute name="niq_billingschedulecomplete" aggregate="count" alias="countOfRecords"/>
                 <filter type="and">
                     <condition attribute="quoteid" operator="eq" value="${quoteId}" />
                     <condition attribute="niq_billingschedulecomplete" operator="eq" value="0" />
                 </filter>
             </entity>
         </fetch>`;

        // Encode the FetchXML query for the API request
        //  var encodedFetchXml = encodeURIComponent(fetchXml);
        var fetchXmlRequest = "?fetchXml=" + encodeURIComponent(fetchXml);

        // Make the Web API call
        var result = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", fetchXmlRequest);

        if (QuoteForm.Events.IsValid(result) && QuoteForm.Events.IsValid(result.entities[0]) && QuoteForm.Events.IsValid(result.entities[0].countOfRecords) && result.entities[0].countOfRecords === 0) {
            isRevenueCompleted = true;
        }
        return isRevenueCompleted;
    },
    GetAllQuoteRecordsCount: async function (quoteId) {
        let totalRecordCount = 0;
        "use strict";
        var fetchXml = `
         <fetch aggregate="true">
             <entity name="quotedetail">
                 <attribute name="quotedetailid" aggregate="count" alias="totalCount"/>
                 <filter type="and">
                     <condition attribute="quoteid" operator="eq" value="${quoteId}" />
                 </filter>
             </entity>
         </fetch>`;

        // Encode the FetchXML query for the API request
        //  var encodedFetchXml = encodeURIComponent(fetchXml);
        var fetchXmlRequest = "?fetchXml=" + encodeURIComponent(fetchXml);

        // Make the Web API call
        var result = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", fetchXmlRequest);

        if (QuoteForm.Events.IsValid(result) && QuoteForm.Events.IsValid(result.entities[0]) && QuoteForm.Events.IsValid(result.entities[0].totalCount) && result.entities[0].totalCount > 0) {
            totalRecordCount = result.entities[0].totalCount;
        }
        return totalRecordCount;
    },
    calculateContractDuration: function (quoteId) {
        var contractDuration = 0;
        var fetchTermLength = "<fetch aggregate='true'>" +
            "<entity name='quotedetail'>" +
            "<attribute name='niq_termlength' alias='term_max' aggregate='max'/>" +
            "<attribute name='niq_calculatedtermlength' alias='calc_max' aggregate='max'/>" +
            "<filter type='and'>" +
            "<condition attribute='quoteid' operator='eq' value='" + quoteId + "' />" +
            "</filter>" +
            "</entity>" +
            "</fetch>";
        var fetchTermResults = GetCRMWebAPI.Methods.GetFetchRecords(Xrm.Utility.getGlobalContext().getClientUrl(), fetchTermLength, "quotedetails");
        if (fetchTermResults !== null && fetchTermResults.value.length > 0 && fetchTermResults.value[0]['term_max'] !== undefined &&
            fetchTermResults.value[0]['term_max'] !== null) {
            contractDuration = fetchTermResults.value[0]['term_max'];
        }
        if (fetchTermResults !== null && fetchTermResults.value.length > 0 && fetchTermResults.value[0]['calc_max'] !== undefined &&
            fetchTermResults.value[0]['calc_max'] !== null && fetchTermResults.value[0]['calc_max'] > contractDuration) {
            contractDuration = fetchTermResults.value[0]['calc_max'];
        }
        return contractDuration;
    },
    ShowNotificationOnceAysncInProgress: function (executionContext) {
        //Get fromContext
        var formContext = executionContext.getFormContext();
        var field = formContext.getAttribute("niq_asyncprocessinprogress");
        if (field != null && field.getValue()) {
            formContext.ui.setFormNotification("Please wait system is working on updating values for you", "WARNING", "1");
        }
    },
    UpdateNonStandardInquote: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        let quoteId = formContext.data.entity.getId().replace("{", "").replace("}", "");
        if (!QuoteForm.Events.IsValid(quoteId)) { return; }
        var result = await Xrm.WebApi.retrieveRecord("niq_configurationsetting", "9223fcba-ec3c-ef11-8409-6045bd9afcc1", "?$select=niq_to")
        var thresholdValue = result["niq_to"];

        var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
            "  <entity name='quotedetail'>" +
            "    <filter type='and'>" +
            "      <filter type='or'>" +
            "        <filter type='and'>" +
            "          <condition attribute='niq_type' operator='eq' value='2' />" +
            "          <filter type='or'>" +
            "            <condition attribute='niq_billingfrequency' operator='eq' value='100000007' />" +
            "            <condition attribute='niq_billingfrequency' operator='eq' value='100000006' />" +
            "            <condition attribute='niq_billingfrequency' operator='eq' value='100000008' />" +
            "          </filter>" +
            "        </filter>" +
            "        <filter type='and'>" +
            "          <condition attribute='niq_type' operator='eq' value='1' />" +
            "          <filter type='or'>" +
            "            <condition attribute='niq_billingfrequency' operator='eq' value='100000009' />" +
            "            <filter type='and'>" +
            "              <condition attribute='niq_billingfrequency' operator='eq' value='100000012' />" +
            "              <condition attribute='niq_brandidname' operator='ne' value='BASES' />" +
            "              <filter type='or'>" +
            "                <condition attribute='extendedamount_base' operator='gt' value='" + Number(thresholdValue) + "' />" +
            "                <condition attribute='niq_tenureindays' operator='gt' value='28' />" +
            "              </filter>" +
            "            </filter>" +
            "          </filter>" +
            "        </filter>" +
            "      </filter>" +
            "    </filter>" +
            "    <link-entity name='quote' from='quoteid' to='quoteid' link-type='inner' alias='af'>" +
            "      <filter type='and'>" +
            "        <condition attribute='quoteid' operator='eq' value='{" + quoteId + "}' />" +
            "      </filter>" +
            "    </link-entity>" +
            "  </entity>" +
            "</fetch>";
        var results = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", "?fetchXml=" + encodeURIComponent(fetchXml));

        if (results.entities.length > 0) {
            var record = {};
            if (formContext.getAttribute("niq_nonstandardbillingterm").getValue() != true) { //21247
                record.niq_nonstandardbillingterm = true; // Boolean
                await Xrm.WebApi.updateRecord("quote", quoteId, record);
                return;
            }

        }
        else {
            var record = {};
            if (formContext.getAttribute("niq_nonstandardbillingterm").getValue() != false) {//21247
                record.niq_nonstandardbillingterm = false; // Boolean
                await Xrm.WebApi.updateRecord("quote", quoteId, record);
                return;
            }
        }
    },
    //US-20428
    // Change Pricing Approval field "Not Require Approval" to "Require Approval" if Total Amount is less than Rate Card Price
    SetPricingApproval: function (executionContext) {
        "use strict";
        let formContext = executionContext.getFormContext();
        let formType = formContext.ui.getFormType();
        let pricingApproval = formContext.getAttribute("niq_dealdeskapproval")?.getValue();
        let totalAmount = formContext.getAttribute("totalamount")?.getValue();
        let rateCardPrice = formContext.getAttribute("niq_ratecardprice")?.getValue();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add-on Deal Desk Approver,System Administrator")) {
            if (pricingApproval !== null && totalAmount !== null && rateCardPrice !== null && pricingApproval === 100000003 && totalAmount < rateCardPrice && formType === 2) {
                formContext.getAttribute("niq_dealdeskapproval").setValue(100000002);
                formContext.data.save();
            }
        }
    },
    //US-DYNCRM-21864
    //Picklist values of 'Indefinite' or 'Perpetual' will no longer be available for selection for new quotes and amendments for all users on Term Type field.
    HideDropdownOptionsAndFields: async function (executionContext) {  // hides Perpetual and Indefinte options from Term Type Field and some fields
        var formContext = executionContext.getFormContext();
        var result = await Xrm.WebApi.retrieveRecord("niq_configurationsetting", "2170bd22-938f-ef11-8a6a-6045bd890e15", "?$select=niq_date");
        var cutOffDate = new Date(result["niq_date"]);
        var dateFieldValue = new Date();
        var year = dateFieldValue.getFullYear();
        var month = dateFieldValue.getMonth();
        var day = dateFieldValue.getDate();
        var todaysDate = new Date(year, month, day);
        var statusCode = formContext.getAttribute("statuscode").getValue();
        var termTypeControl = formContext.getControl("niq_termtype");
        if (formContext.ui.getFormType() == 1 || ((todaysDate > cutOffDate) && (statusCode == 1 || statusCode == 2 || statusCode == 3) && termTypeControl.getDisabled() == false)) {
            var termtype = formContext.getAttribute("niq_termtype").getValue();
            if (termtype == 100000002 || termtype == 100000003)
                formContext.getAttribute("niq_termtype").setValue(100000000);
            var optionsToRemove = [100000002, 100000003];
            optionsToRemove.forEach(function (item) {
                formContext.getControl("niq_termtype").removeOption(item);
            });
        }

        // US-DYNCRM-22351
        //Hide "Standard Local Index, Discount Factor" Option from "API/COLA Structure" Field

        var res = await Xrm.WebApi.retrieveRecord("niq_configurationsetting", "9b6c4806-ec9c-ef11-8a69-7c1e524e097b", "?$select=niq_date");

        var configDate = new Date(res["niq_date"]);
        var colaControl = formContext.getControl("niq_apistructure");
        if (formContext.ui.getFormType() == 1 || ((todaysDate > configDate) && colaControl.getDisabled() == false)) {
            var apistructure = formContext.getAttribute("niq_apistructure").getValue();
            if (apistructure == 100000000)
                formContext.getAttribute("niq_apistructure").setValue(100000003);
            formContext.getControl("niq_apistructure").removeOption(100000000);
        }
    },

    // US-DYNCRM-22351
    // Hide Annual Increase Type Field
    hideAnnualIncreaseType: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.getControl("niq_annualincreasetype").setVisible(false);
    },


    // US-DYNCRM-22351
    // Set annual API % required and set it to null on change of API/COLA structure
    ApiStructureOnChange: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        if ((CommonForm.Events.CheckFieldExists(formContext, "niq_apistructure")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_annualapicola")) && formContext.getAttribute("niq_apistructure").getValue() != null) {
            formContext.getAttribute("niq_annualapicola").setValue(null);
            var apiStructure = formContext.getAttribute("niq_apistructure").getValue();
            if (apiStructure == 100000005) {
                formContext.getAttribute("niq_annualapicola").setRequiredLevel("required");
            }
            else {
                formContext.getAttribute("niq_annualapicola").setRequiredLevel("none");
            }
        }
    },

    HideIncentiveFields: async function(executionContext){
        var formContext = executionContext.getFormContext();
        var res = await Xrm.WebApi.retrieveRecord("niq_configurationsetting", "9b6c4806-ec9c-ef11-8a69-7c1e524e097b", "?$select=niq_date");

        var configDate = new Date(res["niq_date"]);
        var dateFieldValue = new Date();
        var year = dateFieldValue.getFullYear();
        var month = dateFieldValue.getMonth();
        var day = dateFieldValue.getDate();
        var todaysDate = new Date(year, month, day);
        if (formContext.ui.getFormType() == 1 || (todaysDate > configDate)) {
            var fieldsToRemove = ["niq_incentivetype", "niq_incentivevalueniqannualimpact", "niq_incentivecomments"];
            fieldsToRemove.forEach(function (item) {
                formContext.getControl(item).setVisible(false);
            });
        }
    }
}