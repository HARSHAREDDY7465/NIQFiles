if (typeof (QuoteProductForm) === "undefined") {
    QuoteProductForm = {
        __namespace: true
    };
}

QuoteProductForm.Events = {
    opportunityType: null,
    opportunityApprovalStatus: null,
    intialOppCheckflag: false,
    isFinanceorAdminUserflag: false,
    isFinanceorAdminUserCheckflag: false,

    OnFormLoad: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        this.LockBasesSolutionFormerName(executionContext);
        this.isFinanceorAdminUserflag = CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User,NIQ Business Admin,System Administrator,System Customizer");
        this.isFinanceorAdminUserCheckflag = true;
        if (formContext.getAttribute('quoteid').getValue() !== undefined && formContext.getAttribute('quoteid').getValue() !== null &&
            formContext.getAttribute('quoteid').getValue().length > 0 && formContext.getAttribute('quoteid').getValue()[0].id !== undefined &&
            formContext.getAttribute('quoteid').getValue()[0].id !== null)
            this.checkOpportunityInfo(executionContext, formContext.getAttribute('quoteid').getValue()[0].id);
        this.LockUnlockProjectReferenceID(executionContext);
        this.LockBasesStudyNumber(executionContext);
        /*this.LockUnlockInvoicetext(executionContext);*/
        this.WbsFieldEditableForSales(executionContext);
        var formType = formContext.ui.getFormType();
        if (formType != 0 && formType != 1) {
            this.ShowHideForAdmins(executionContext);
        }
    },
    LockBasesSolutionFormerName: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (!CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator")) {
            formContext.getControl("niq_basessolutionformername").setDisabled(true);
        }

    },
    LockUnlockProjectReferenceID: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (!this.intialOppCheckflag) {
            this.checkOpportunityInfo(executionContext, (Xrm.Utility.getPageContext() !== undefined && Xrm.Utility.getPageContext() !== null &&
                Xrm.Utility.getPageContext().input !== undefined && Xrm.Utility.getPageContext().input !== null &&
                Xrm.Utility.getPageContext().input.entityName != undefined && Xrm.Utility.getPageContext().input.entityName != null &&
                Xrm.Utility.getPageContext().input.entityName === 'quote') ?
                Xrm.Utility.getPageContext().input.entityId : formContext.getAttribute('quoteid').getValue()[0].id);
        }
        if (!this.isFinanceorAdminUserCheckflag) {
            this.isFinanceorAdminUserflag = CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User,NIQ Business Admin,System Administrator,System Customizer");
            this.isFinanceorAdminUserCheckflag = true;
        }

        if (this.opportunityType !== null && this.opportunityType === 1) {
            this.SetDisableGridColumn(formContext.getAttribute("niq_projectid"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_databasename"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_contractproductname"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_fundusagetype"), true);
        }
        else {
            this.SetDisableGridColumn(formContext.getAttribute("niq_projectid"), false);
            this.SetDisableGridColumn(formContext.getAttribute("niq_databasename"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_contractproductname"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_fundusagetype"), true);
        }
        if (this.opportunityType !== null && this.opportunityType === 1)
            if (this.opportunityApprovalStatus !== null && this.opportunityApprovalStatus === 100000001) {
                this.SetDisableGridColumn(formContext.getAttribute("niq_invoicetext"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_databasename"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_contractproductname"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_fundusagetype"), true);


                if (!this.isFinanceorAdminUserflag)
                    this.SetDisableGridColumn(formContext.getAttribute("niq_wbs"), true);
                //this.SetDisableGridColumn(formContext.getAttribute("niq_remark"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_databasename"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_contractproductname"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_fundusagetype"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_basesstudynumber"), true);

            }
            else {
                this.SetDisableGridColumn(formContext.getAttribute("niq_invoicetext"), false);
                this.SetDisableGridColumn(formContext.getAttribute("niq_wbs"), false);
                //this.SetDisableGridColumn(formContext.getAttribute("niq_remark"), false);
                this.SetDisableGridColumn(formContext.getAttribute("niq_databasename"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_contractproductname"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_fundusagetype"), true);
            }

    },
    SetDisableGridColumn: function (attrCtrl, isDisable) {
        "use strict";
        try {
            attrCtrl.controls.forEach(function (control) {
                control.setDisabled(isDisable);
            });
        }
        catch (ex) {
            Xrm.Navigation.openErrorDialog({ message: "Error occurd in QuoteProductForm.Events.SetDisableGridColumn method.", details: ex });
        }
    },

    LockUnlockInvoicetext: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_invoicetext") && CommonForm.Events.CheckValueExists(formContext, "quoteid")) {
            var quote = formContext.getAttribute("quoteid").getValue();
            var quote_id = quote[0].id.replace('{', '').replace('}', '');
            Xrm.WebApi.online.retrieveRecord("quote", quote_id, "?$select=_opportunityid_value&$expand=opportunityid($select=niq_approvalstatus)").then(
                function success(result) {
                    var oppoValue = result["_opportunityid_value"];
                    if (oppoValue !== null) {
                        if (result.hasOwnProperty("opportunityid")) {
                            var approvalstatus = result["opportunityid"]["niq_approvalstatus"];

                            if (approvalstatus === 100000001) {
                                formContext.getControl("niq_invoicetext").setDisabled(true);
                            }
                        }
                    }
                },
                function (error) {

                }
            );
        }
    },
    WbsFieldEditableForSales: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User")) {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_wbs") && CommonForm.Events.CheckValueExists(formContext, "quoteid")) {
                var quote = formContext.getAttribute("quoteid").getValue();
                var quote_id = quote[0].id.replace('{', '').replace('}', '');
                Xrm.WebApi.online.retrieveRecord("quote", quote_id, "?$select=_opportunityid_value&$expand=opportunityid($select=niq_approvalstatus,statecode)").then(
                    function success(result) {
                        var _opportunityid_value = result["_opportunityid_value"];
                        if (result.hasOwnProperty("opportunityid")) {
                            var opportunityApprovalStatus = result["opportunityid"]["niq_approvalstatus"];
                            var opportunityStatus = result["opportunityid"]["statecode"];
                            if ((opportunityStatus === 1 || opportunityStatus === 2) || opportunityApprovalStatus === 100000001) {
                                formContext.getControl("niq_wbs").setDisabled(true);
                            }
                            if (opportunityStatus === 1) {
                                CommonForm.Events.disableFormFields(true, formContext);
                            }
                        }
                    },
                    function (error) { }
                );
            }
        }
        //DYNCRM - 1112 Start Line
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User") || (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User"))) {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_wbs") && CommonForm.Events.CheckValueExists(formContext, "quoteid")) {
                var quote = formContext.getAttribute("quoteid").getValue();
                var quote_id = quote[0].id.replace('{', '').replace('}', '');
                Xrm.WebApi.online.retrieveRecord("quote", quote_id, "?$select=_opportunityid_value&$expand=opportunityid($select=niq_approvalstatus,statecode)").then(
                    function success(result) {
                        var _opportunityid_value = result["_opportunityid_value"];
                        if (result.hasOwnProperty("opportunityid")) {
                            var opportunityApprovalStatus = result["opportunityid"]["niq_approvalstatus"];
                            var opportunityStatus = result["opportunityid"]["statecode"];
                            if (opportunityApprovalStatus != 100000002) {
                                formContext.getControl("niq_wbs").setDisabled(false);
                            }
                            else {
                                formContext.getControl("niq_wbs").setDisabled(true);
                            }
                            if (opportunityStatus === 1) {
                                CommonForm.Events.disableFormFields(true, formContext);
                            }
                        }
                    },
                    function (error) { }
                );
            }
        }
        //DYNCRM - 1112 End Line
    },
    checkOpportunityInfo: function (executionContext, quoteId) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var fetch = "<fetch top='1' distinct='true' no-lock='true'>" +
                "<entity name='opportunity'>" +
                "<attribute name='opportunityid' />" +
                "<attribute name='niq_approvalstatus' />" +
                "<attribute name='niq_opportunitytype' />" +
                "<link-entity name='quote' to='opportunityid' from='opportunityid' link-type='inner' alias='aa'>" +
                "<filter type='and'><condition attribute='quoteid' operator='eq' value='" + quoteId + "' /></filter>" +
                "</link-entity>" +
                "</entity>" +
                "</fetch>";
            var fetchResults = GetCRMWebAPI.Methods.GetFetchRecords(Xrm.Utility.getGlobalContext().getClientUrl(), fetch, "opportunities");
            if (fetchResults !== null && fetchResults.value.length > 0) {
                QuoteProductForm.Events.intialOppCheckflag = true;
                if (fetchResults.value[0]['niq_opportunitytype'] !== undefined && fetchResults.value[0]['niq_opportunitytype'] !== null)
                    QuoteProductForm.Events.opportunityType = fetchResults.value[0]['niq_opportunitytype'];
                if (fetchResults.value[0]['niq_approvalstatus'] !== undefined && fetchResults.value[0]['niq_approvalstatus'] !== null)
                    QuoteProductForm.Events.opportunityApprovalStatus = fetchResults.value[0]['niq_approvalstatus'];
            }
        }
        catch (e) {
            Xrm.Navigation.openErrorDialog({
                message: "Error occurd in QuoteForm.Events.checkQPCLocking method.",
                details: e
            });
        }
    },
    ShowHideForAdmins: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer")) {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_iscreatedrun")) {
                formContext.getControl("niq_iscreatedrun").setVisible(true);
            }
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_ismodified")) {
                formContext.getControl("niq_ismodified").setVisible(true);

            }
        }
    },
    OnSelectQuoteProduct: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var listofColumns = ["quotedetailname", "isproductoverridden", "producttypecode", "niq_lineitemstartdate", "niq_lineitemenddate", "niq_lagrevenuerecognition",
            "niq_deliveryfrequency", "niq_remark", "niq_billingfrequency", "niq_fundamount", "extendedamount", "niq_subbrandid", "niq_brandid", "productname", "productdescription",
            "productid", "manualdiscountamount", "baseamount", "niq_reconciliationamount", "niq_discountqp", "niq_lineitemnumberforsap"];
        try {
            for (var i = 0; i < listofColumns.length; i++)
                if (listofColumns[i] !== undefined && listofColumns[i] !== null && formContext.getAttribute(listofColumns[i]) !== null)
                    this.SetDisableGridColumn(formContext.getAttribute(listofColumns[i]), true);
        }
        catch (ex) {
            Xrm.Navigation.openErrorDialog({ message: "Error occurd in QuoteProductForm.Events.OnSelectQuoteProduct method.", details: ex });
        }
    },
    LockBasesStudyNumber: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator")) {
            formContext.getControl("niq_basesstudynumber").setDisabled(false);
            this.SetDisableGridColumn(formContext.getAttribute("niq_basesstudynumber"), false);
        }
        else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User")) {
            {
                formContext.getControl("niq_basesstudynumber").setDisabled(true);
            }
        }
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User") && this.opportunityType === 1) {
            this.SetDisableGridColumn(formContext.getAttribute("niq_basesstudynumber"), true);
            formContext.getControl("niq_basesstudynumber").setDisabled(true);
        }
        else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User") && this.opportunityType === 2) {
            this.SetDisableGridColumn(formContext.getAttribute("niq_basesstudynumber"), false);
            formContext.getControl("niq_basesstudynumber").setDisabled(false);
        }

    }
}