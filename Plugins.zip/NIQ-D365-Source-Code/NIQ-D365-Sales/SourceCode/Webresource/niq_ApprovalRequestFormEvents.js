if (typeof (ApprovalRequestForm) === "undefined") {
    ApprovalRequestForm = {
        __namespace: true
    };
}

ApprovalRequestForm.Events = {
    OnFormLoad: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        this.RemoveRecalledOption(executionContext);
        this.TradeAndBarterRequired(executionContext);
        //this.OnsalesOpsChange(executionContext);
        this.RemoveSAPDecisionOption(executionContext);
        this.ShowAndHideQuoteTAB(executionContext);
        this.HideOption(executionContext);
        if (CommonForm.Events.CheckValueExists(formContext, "niq_approvaltype")) {
            var formType = formContext.ui.getFormType();
            if (formType === 1) {
                if (formContext.getAttribute("niq_approvalstatus") !== null) {
                    formContext.getControl("niq_approvalstatus").setDisabled(true);
                }
                if (formContext.getAttribute("niq_subtype") !== null) {
                    formContext.getControl("niq_subtype").setDisabled(false);
                }
            }
            var farType = formContext.getAttribute("niq_approvaltype").getValue();
            if (farType === 100000000) {
                // FAR Type is Opportunty
                CommonForm.Events.ShowHideSections(formContext, "Summary", "Opportunity_Approval_Section1", true);
                CommonForm.Events.ShowHideSections(formContext, "Summary", "Opportunity_Approval_Section2", true);
                formContext.getControl("niq_createdinsalesforceby").setVisible(false);
            }
            else {
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_subtype")) {
                    formContext.getAttribute("niq_subtype").setRequiredLevel('required');
                    formContext.getControl("niq_subtype").setVisible(true);
                }
                if (formContext.getAttribute("niq_salesorg") !== null && formContext.getAttribute("niq_salesorg").getValue() === null) {
                    formContext.getControl("niq_salesorg").setDisabled(false);
                }
            }
            if (formContext.getAttribute("niq_relatedaccount") !== null && formContext.getAttribute("niq_relatedaccount").getValue() === null) {
                formContext.getControl("niq_relatedaccount").setDisabled(false);
            }
            if (farType === 100000001) {
                // FAR type is SAP Account Change request
                CommonForm.Events.ShowHideSections(formContext, "Summary", "SAPAccount_Approval_Section", true);
                formContext.getControl("niq_createdinsalesforceby").setVisible(true);
            } else {
                formContext.getControl("niq_createdinsalesforceby").setVisible(false);
            }

        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_salesopsreviewresult")) {
            var salesResult = formContext.getAttribute("niq_salesopsreviewresult").getValue();
            if (salesResult === 1) {
                formContext.getAttribute("niq_rejectionreasonfar").setRequiredLevel("none");
                formContext.getAttribute("niq_comments").setRequiredLevel("none");
                formContext.getControl("niq_rejectionreasonfar").setVisible(false);
                formContext.getAttribute("niq_rejectionreasonfar").setValue(null);
            } else if (salesResult === 2 || salesResult === 3) {
                formContext.getAttribute("niq_rejectionreasonfar").setRequiredLevel("required");
                formContext.getAttribute("niq_comments").setRequiredLevel("required");
                formContext.getControl("niq_rejectionreasonfar").setVisible(true);
            }
        }
    },
    ApprovalFieldsAccess: function (executionContext) {
        'use strict';
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        if (formType != 4) {
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add On Sales Ops Approver")) {
                formContext.getControl("niq_approvalstatus").setDisabled(true);
                formContext.getControl("niq_salesopsreviewresult").setDisabled(false);
            }
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add-On Finance Gatekeeper")) {
                formContext.getControl("niq_approvalstatus").setDisabled(false);
                formContext.getControl("niq_salesopsreviewresult").setDisabled(true);
            }

            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer")) {
                formContext.getControl("niq_approvalstatus").setDisabled(false);
                formContext.getControl("niq_salesopsreviewresult").setDisabled(false);
            }
        }
    },
    HideOption: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        var Type = formContext.getAttribute("niq_approvaltype").getValue();
        var ApprovalStatus = formContext.getAttribute("niq_approvalstatus").getValue();

        if (Type === 100000000 || Type === 100000002) {
            formContext.getControl("niq_approvalstatus").removeOption(100000000);
        }
    },
    RemoveRecalledOption: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_approvaltype") && CommonForm.Events.CheckValueExists(formContext, "niq_approvalstatus")) {
            var requestType = formContext.getAttribute("niq_approvaltype").getValue();
            var approvalStatus = formContext.getAttribute("niq_approvalstatus").getValue();
            if (requestType === 100000001) {
                formContext.getControl("niq_approvalstatus").removeOption(100000004);
            }
            if (requestType === 100000000 && (approvalStatus === 100000003 || approvalStatus === 100000006)) {
                formContext.getAttribute("niq_rejectionreasonfar").setRequiredLevel("required");
                formContext.getControl("niq_rejectionreasonfar").setVisible(true);
            } else {
                formContext.getAttribute("niq_rejectionreasonfar").setRequiredLevel("none");
                formContext.getControl("niq_rejectionreasonfar").setVisible(false);
                formContext.getAttribute("niq_rejectionreasonfar").setValue(null);
            }
        }
    },
    TradeAndBarterRequired: function (executionContext) {
        "use strict";
        //make Trade and Barter field required for valid Sales Org
        // get the form context
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_approvaltype") && (CommonForm.Events.CheckFieldExists(formContext, "niq_tradebarter"))) {
            var approvalRequestType = formContext.getAttribute("niq_approvaltype").getValue();
            formContext.getAttribute("niq_tradebarter").setRequiredLevel("none");
            if (CommonForm.Events.CheckValueExists(formContext, "niq_salesorg")) {
                var salesOrg = formContext.getAttribute("niq_salesorg").getValue();
                var salesOrg_id = salesOrg[0].id.replace('{', '').replace('}', '');
                // retrieve salesorgcode
                Xrm.WebApi.retrieveRecord("niq_salesorg", salesOrg_id, "?$select=niq_salesorgcode").then(
                    function success(result) {
                        if (result["niq_salesorgcode"] !== null) {
                            var salesOrgCode = result.niq_salesorgcode;
                            //retrieve Sales Org List_SAP Change Account Request configurationsetting
                            Xrm.WebApi.online.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_to&$filter=niq_name eq 'Sales%20Org%20List_SAP%20Account%20Change%20Request'").then(
                                function success(results) {
                                    var niq_to = results.entities[0]["niq_to"];
                                    if (niq_to !== null) {
                                        if ((niq_to.includes(salesOrgCode)) && (approvalRequestType === 100000001)) {
                                            formContext.getAttribute("niq_tradebarter").setRequiredLevel("required");
                                        }
                                    }
                                },
                                function (error) {

                                }
                            );
                        }
                    },
                    function (error) {

                    }
                );
            }
        }
    },
    SetSAPIntegrationDecision: function (executionContext) {
        "use strict";
        //Set SAP Integration Decision to send to SAP if Contract Decision in Opportunity is New Contract Will Be Signed
        //based SAP Integration Decision if existing sales documnet id in opportunity contains data set in salesdocumentidtobeupdated
        var formContext = executionContext.getFormContext();
        if ((CommonForm.Events.CheckFieldExists(formContext, "niq_sapintegrationdecision")) && (CommonForm.Events.CheckValueExists(formContext, "niq_approvaltype")) && (CommonForm.Events.CheckValueExists(formContext, "niq_approvalstatus")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_salesdocumentidtobeupdatedinsap"))) {
            var sapIntegrationDecision = formContext.getAttribute("niq_sapintegrationdecision").getValue();
            var approvalType = formContext.getAttribute("niq_approvaltype").getValue();
            var approvalStatus = formContext.getAttribute("niq_approvalstatus").getValue();
            if ((approvalType === 100000000) && (approvalStatus === 100000002)) {
                if (CommonForm.Events.CheckValueExists(formContext, "niq_relatedopportunity")) {
                    var opportunity = formContext.getAttribute("niq_relatedopportunity").getValue();
                    var opportunityid = opportunity[0].id.replace('{', '').replace('}', '');
                    Xrm.WebApi.retrieveRecord("opportunity", opportunityid, "?$select=niq_contractdecision,niq_existingsapsalesdocumentid").then(
                        function success(result) {
                            if ((result["niq_contractdecision"] !== null)) {
                                if ((result.niq_contractdecision === 100000001)) {
                                    formContext.getAttribute("niq_sapintegrationdecision").setValue(2);
                                    formContext.getAttribute("niq_salesdocumentidtobeupdatedinsap").setValue(null);
                                    formContext.getAttribute("niq_salesdocumentidtobeupdatedinsap").setRequiredLevel("none");
                                    formContext.getControl("niq_salesdocumentidtobeupdatedinsap").setVisible(false);
                                }
                                else {
                                    formContext.getAttribute("niq_sapintegrationdecision").setValue(1);
                                    formContext.getAttribute("niq_salesdocumentidtobeupdatedinsap").setRequiredLevel("required");
                                    formContext.getControl("niq_salesdocumentidtobeupdatedinsap").setVisible(true);
                                    if (result["niq_existingsapsalesdocumentid"] !== null) {
                                        var existingSapsalesdocumentid = result["niq_existingsapsalesdocumentid"];
                                        formContext.getAttribute("niq_salesdocumentidtobeupdatedinsap").setValue(existingSapsalesdocumentid);
                                    }
                                }
                            }
                            else {
                                formContext.getAttribute("niq_sapintegrationdecision").setValue(1);
                                formContext.getAttribute("niq_salesdocumentidtobeupdatedinsap").setRequiredLevel("required");
                                formContext.getControl("niq_salesdocumentidtobeupdatedinsap").setVisible(true);
                                if (result["niq_existingsapsalesdocumentid"] !== null) {
                                    var existingSapsalesdocumentid = result["niq_existingsapsalesdocumentid"];
                                    formContext.getAttribute("niq_salesdocumentidtobeupdatedinsap").setValue(existingSapsalesdocumentid);
                                }
                            }
                        },
                        function (error) {

                        }
                    );
                }
            }
        }
    },
    OnChangeOfSAPIntegrationDecision: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if ((CommonForm.Events.CheckValueExists(formContext, "niq_sapintegrationdecision")) && (CommonForm.Events.CheckValueExists(formContext, "niq_approvaltype"))) {

            var sapintegrationdecision = formContext.getAttribute("niq_sapintegrationdecision").getValue();
            var approvalType = formContext.getAttribute("niq_approvaltype").getValue();
            if (approvalType === 100000000) {
                if (CommonForm.Events.CheckValueExists(formContext, "niq_relatedopportunity")) {

                    var relOppo = formContext.getAttribute("niq_relatedopportunity").getValue();
                    var relOppoId = relOppo[0].id.replace('{', '').replace('}', '');
                    Xrm.WebApi.online.retrieveRecord("opportunity", relOppoId, "?$select=niq_existingsapsalesdocumentid").then(

                        function success(result) {
                            if (sapintegrationdecision === 1) {
                                if (CommonForm.Events.CheckFieldExists(formContext, "niq_salesdocumentidtobeupdatedinsap")) {
                                    var salesdocumentidtobeupdatedinSap = formContext.getAttribute("niq_salesdocumentidtobeupdatedinsap").getValue();
                                    if (salesdocumentidtobeupdatedinSap === null) {
                                        if (result["niq_existingsapsalesdocumentid"] !== null) {
                                            var existingSapsalesdocumentid = result["niq_existingsapsalesdocumentid"];
                                            if (existingSapsalesdocumentid !== null) {
                                                formContext.getAttribute("niq_salesdocumentidtobeupdatedinsap").setValue(existingSapsalesdocumentid);
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        function (error) { });
                }
            }
        }
    },
    //OnsalesOpsChange: function (executionContext) {
    //    "use strict";
    //    var formContext = executionContext.getFormContext();
    //    if (CommonForm.Events.CheckValueExists(formContext, "niq_approvaltype") && (formContext.getAttribute("niq_approvaltype").getValue() === 100000000)) {
    //        formContext.getControl("niq_salesopsreviewrequired").setVisible(true);
    //        if ((formContext.getAttribute("niq_approvaltype").getValue() === 100000000) && CommonForm.Events.CheckValueExists(formContext, "niq_salesopsreviewrequired") && formContext.getAttribute("niq_salesopsreviewrequired").getValue() === true) {
    //            formContext.getControl("niq_salesopsreviewresult").setVisible(true);
    //        } else {
    //            formContext.getControl("niq_salesopsreviewresult").setVisible(false);
    //            formContext.getAttribute("niq_salesopsreviewresult").setValue(null);
    //        }
    //    } else {
    //        formContext.getControl("niq_salesopsreviewrequired").setVisible(false);
    //        formContext.getAttribute("niq_salesopsreviewrequired").setValue(null);
    //        formContext.getControl("niq_salesopsreviewresult").setVisible(false);
    //        formContext.getAttribute("niq_salesopsreviewresult").setValue(null);
    //    }
    //},
    OnApprovalStatusChange: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_salesopsreviewresult")) {
            var salesResult = formContext.getAttribute("niq_salesopsreviewresult").getValue();
            if (salesResult === 1) {
                formContext.getAttribute("niq_approvalstatus").setValue(100000001);
                formContext.getAttribute("niq_rejectionreasonfar").setRequiredLevel("none");
                formContext.getAttribute("niq_comments").setRequiredLevel("none");
                formContext.getControl("niq_rejectionreasonfar").setVisible(false);
                formContext.getAttribute("niq_rejectionreasonfar").setValue(null);
            } else if (salesResult === 2) {
                formContext.getAttribute("niq_approvalstatus").setValue(100000003);
                formContext.getAttribute("niq_rejectionreasonfar").setRequiredLevel("required");
                formContext.getAttribute("niq_comments").setRequiredLevel("required");
                formContext.getControl("niq_rejectionreasonfar").setVisible(true);
            } else if (salesResult === 3) {
                formContext.getAttribute("niq_approvalstatus").setValue(100000007);
                formContext.getAttribute("niq_rejectionreasonfar").setRequiredLevel("required");
                formContext.getAttribute("niq_comments").setRequiredLevel("required");
                formContext.getControl("niq_rejectionreasonfar").setVisible(true);
            }
        }
    },
    ShowAndHideQuoteTAB: function (executionContext) {
        "use strict";

        var formContext = executionContext.getFormContext();
        if ((CommonForm.Events.CheckFieldExists(formContext, "niq_approvaltype")) && (CommonForm.Events.CheckValueExists(formContext, "niq_approvaltype"))) {
            var approvalRequestType = formContext.getAttribute("niq_approvaltype").getValue();
            if (approvalRequestType === 100000000) {
                CommonForm.Events.ShowHideTabs(formContext, "tab_2", true);
            }
            else {
                CommonForm.Events.ShowHideTabs(formContext, "tab_2", false);
            }
        }
    },
    RemoveSAPDecisionOption: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        //Remove SAP Integration Decision Failed option for Non Admins
        if ((CommonForm.Events.CheckFieldExists(formContext, "niq_sapintegrationdecision")) && (!(CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer")))) {
            formContext.getControl("niq_sapintegrationdecision").removeOption(3);
        }
    },
    PreventAutosave: function (executionContext) {
        "use strict";
        var eventArgs = executionContext.getEventArgs();
        if (eventArgs.getSaveMode() == 70 || eventArgs.getSaveMode() == 2) {
            eventArgs.preventDefault();
        }
    },
    RestrictStageChangeToCloseWon: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        var approvalType = formContext.getAttribute("niq_approvaltype").getValue();
        var approvalStatus = formContext.getAttribute("niq_approvalstatus").getValue();
        if ((approvalType === 100000000) && (approvalStatus === 100000002)) {
            var opportunity = formContext.getAttribute("niq_relatedopportunity").getValue();
            var opportunityid = opportunity[0].id.replace('{', '').replace('}', '');
            var quote = formContext.getAttribute("niq_mainquoteid").getValue();
            var quoteId = quote[0].id.replace('{', '').replace('}', '');
            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'><entity name='quotedetail'><attribute name='niq_brandid' /><attribute name='quotedetailname' /><attribute name='quotedetailid' /><attribute name='niq_wbs' /><order attribute='niq_brandid' descending='false' /><filter type='and'><condition attribute='quoteid' operator='eq' uitype='quote' value='" + quoteId + "' /><condition attribute='niq_wbs' operator='null' /><condition attribute='niq_brandid' operator='in'><value uiname='BASES' uitype='product'>{FCABAF82-A13F-EC11-8C62-002248098DAF}</value><value uiname='BASES' uitype='product'>{E47CD76D-993F-EC11-8C60-0022480A4E68}</value><value uiname='CI' uitype='product'>{bb84a1a5-9c3f-ec11-8c60-0022480a48ee}</value><value uiname='CI' uitype='product'>{e27cd76d-993f-ec11-8c60-0022480a4e68}</value></condition></filter><link-entity name='product' from='productid' to='niq_brandid' visible='false' link-type='outer' alias='a_baebf37edc0ced1182e4002248830b23'><attribute name='name' /></link-entity></entity></fetch>";
            var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
            var result = GetCRMWebAPI.Methods.GetFetchRecords(clienturl, fetchXml, "quotedetails");

            var eventArgs = executionContext.getEventArgs();
            if (result != null && result.value.length > 0 && eventArgs.getSaveMode() == 1) {
                var alertStrings = { message: "ERROR:WBS# needs to be populated on every quote product for CI and BASES that is on the main quote. This is required before an opportunity can be moved to Closed Won - Approved ", details: "WBS# needs to be populated on every quote product for CI and BASES that is on the main quote. This is required before an opportunity can be moved to Closed Won - Approved" };
                var alertOptions = { height: 200, width: 300 };
                Xrm.Navigation.openErrorDialog(alertStrings).then(
                    function (sucess) {
                        console.log(success);
                    },
                    function (error) {
                        console.log(error);
                    });
                var eventArgs = executionContext.getEventArgs();
                if (eventArgs.getSaveMode() == 1) {
                    eventArgs.preventDefault();
                }

            }
            else if (eventArgs.getSaveMode() == 70 || eventArgs.getSaveMode() == 2) { eventArgs.preventDefault(); }

        }

    }
}