if (typeof (OpportunityProductEnhancementRibbon) === "undefined") {
    OpportunityProductEnhancementRibbon = {
        __namespace: true
    };
}
OpportunityProductEnhancementRibbon.Events = {
    NewButtonVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer")) {
            return true;
        }
        else {
            return false;
        }
    }
}