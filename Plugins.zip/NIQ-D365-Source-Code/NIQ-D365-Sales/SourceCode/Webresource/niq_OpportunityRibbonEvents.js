if (typeof (OpportunityRibbon) === "undefined") {
    OpportunityRibbon = {
        __namespace: true
    };
}

OpportunityRibbon.Events = {

    onClickSubmitForApproval: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var confirmStrings = { text: "Do you wish to Submit the Opportunity for Approval", cancelButtonLabel: "No", confirmButtonLabel: "Yes" };
        var confirmOptions = { height: 200, width: 450 };
        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {

                    if (CommonForm.Events.CheckFieldExists(formContext, "niq_approvalstatus")) {
                        formContext.getAttribute("niq_approvalstatus").setValue(100000001);
                        formContext.data.entity.save();
                    }
                }


            });
    },
    ResubmitForApprovalVisibility: function (executionContext) {

        "use strict";
        var formContext = executionContext;
        var negotiation = false;
        var preProposal = false;
        var approvalStatus = false;
        var open = false;
        var TypeForm = false;
        var ClosedWOn = false;
        if ((formContext.getAttribute("niq_billtopartyverified").getValue() === true) && (formContext.getAttribute("niq_soldtopartyverified").getValue() === true) && (formContext.getAttribute("niq_delivertopartyverified").getValue() === true)) {
            negotiation = true;
        }

        if ((formContext.getAttribute("totalamount").getValue() !== null) && (formContext.getAttribute("niq_contractstartdate").getValue() !== null) && (formContext.getAttribute("niq_contractenddate").getValue() !== null) && (formContext.getAttribute("niq_salesorgid").getValue() !== null) && (formContext.getAttribute("description").getValue() !== null)) {
            preProposal = true;
        }

        if ((formContext.getAttribute("niq_approvalstatus").getValue() !== null) && (formContext.getAttribute("niq_approvalstatus").getValue() === 100000003) || (formContext.getAttribute("niq_approvalstatus").getValue() === 100000004) || (formContext.getAttribute("niq_approvalstatus").getValue() === 100000005) || (formContext.getAttribute("niq_approvalstatus").getValue() === 100000006)) {
            approvalStatus = true;
        }

        if (formContext.getAttribute("statecode").getValue() === 0) {
            open = true;
        }
        if ((formContext.ui.getFormType() === 2)) {
            TypeForm = true;
        }
        if (formContext.getAttribute("niq_stage").getValue() == "Closed Won - In Review") {
            ClosedWOn = true;
        }

        if ((negotiation === true) && (preProposal === true) && (approvalStatus === true) && (open === true) && (TypeForm === true) && (ClosedWOn === true)) {
            return true;
        }

        else {
            return false;
        }
    },
    onClickReSubmit: function (executionContext) {

        "use strict";
        var formContext = executionContext;
        var revenueSchedule;
        var billingSchedule;
        var agreementType;
        var quote = formContext.getAttribute("niq_mainquoteid").getValue();
        var opportunityId = formContext.data.entity.getId().replace("{", "").replace("}", "");
        var quoteId = quote[0].id;
        quoteId = quoteId.replace("{", "");
        quoteId = quoteId.replace("}", "");
        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/quotes(" + quoteId + ")?$select=niq_elrevenueschedulecomplete,niq_elbillingschedulecomplete", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var result = JSON.parse(this.response);
                    revenueSchedule = result["niq_elrevenueschedulecomplete"];
                    billingSchedule = result["niq_elbillingschedulecomplete"];
                    agreementType = result["niq_agreementtype"];
                    if (!agreementType) {
                        agreementType.setRequiredLevel("required");
                        formContext.ui.setFormNotification("Please enter the Value for Agreement Type to proceed further", "ERROR", "error");
                    }
                    else {
                        formContext.ui.clearFormNotification("error");
                    }
                }
                else {
                    Xrm.Utility.alertDialog(this.statusText);
                }

            }
        };
        req.send();
        if ((revenueSchedule != null && revenueSchedule == false) || (billingSchedule != null && billingSchedule == false)) {
            Xrm.Navigation.openErrorDialog({ message: "Please return to Experlogix and complete your Revenue or Billing schedule inputs prior to proceeding further." });
        }
        else {
            var confirmStrings = { text: "Do you wish to Re-Submit the Opportunity for Approval", cancelButtonLabel: "No", confirmButtonLabel: "Yes" };
            var confirmOptions = { height: 200, width: 450 };
            Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
                function (success) {
                    if (success.confirmed) {
                        var errorMessage = " ";

                        if (CommonForm.Events.CheckValueExists(formContext, "niq_opportunitytype")) {
                            var oppoType = formContext.getAttribute("niq_opportunitytype").getValue();
                            if (oppoType !== 1) {
                                if (CommonForm.Events.CheckValueExists(formContext, "niq_existingcontractaction")) {
                                    var existingContractAction = formContext.getAttribute("niq_existingcontractaction").getValue();
                                    if (existingContractAction !== 3) {
                                        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete")) {
                                            var hasRevWalk = formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().getValue();
                                            if (hasRevWalk === null || hasRevWalk === false) {
                                                errorMessage += "Has Revenue Walk analysis been completed ,";
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_soldtopartyverified")) {
                            var soldTo = formContext.getControl("header_process_niq_soldtopartyverified").getAttribute().getValue();
                            if (soldTo === null || soldTo === false) {
                                errorMessage += "Sold To Party - Verified ,";
                            }
                        }
                        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_billtopartyverified")) {
                            var billTo = formContext.getControl("header_process_niq_billtopartyverified").getAttribute().getValue();
                            if (billTo === null || billTo === false) {
                                errorMessage += "Bill To Party - Verified ,";
                            }
                        }
                        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_delivertopartyverified")) {
                            var deliverTo = formContext.getControl("header_process_niq_delivertopartyverified").getAttribute().getValue();
                            if (deliverTo === null || deliverTo === false) {
                                errorMessage += "Deliver To Party - Verified ,";
                            }
                        }
                        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_tempeoafinallyexecutedagreementprovided")) {
                            var tempUrl = formContext.getControl("header_process_niq_tempeoafinallyexecutedagreementprovided").getAttribute().getValue();
                            if (tempUrl === null || tempUrl === false) {
                                errorMessage += "Temp EOA or Finally Executed Agreement Provide ,";
                            }
                        }
                        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_contractdecision")) {
                            if (formContext.getControl("header_process_niq_contractdecision").getAttribute().getValue() === null) {
                                errorMessage += "How will this deal be handled contract wise? ,";
                            }
                        }
                        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_mandatorycharvaluesadded")) {
                            if (formContext.getControl("header_process_niq_mandatorycharvaluesadded").getAttribute().getValue() === false) {
                                errorMessage += "Please proceed to the main quote first and select values for all the mandatory Quote product characteristics for the quote products ,";
                            }
                        }
                        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_mainquotesdealdeskapprovalobtained")) {
                            var mainquotedealdesk = formContext.getControl("header_process_niq_mainquotesdealdeskapprovalobtained").getAttribute().getValue();
                            if (mainquotedealdesk === null || mainquotedealdesk === false) {
                                errorMessage += "Main Quote's Deal Desk Approval Obtained ,";
                            }
                        }
                        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_invoiceinformationverified")) {
                            var invoiceInfoVerified = formContext.getControl("header_process_niq_invoiceinformationverified").getAttribute().getValue();
                            if (invoiceInfoVerified === null || invoiceInfoVerified === false) {
                                errorMessage += "Invoice Information Verified ,";
                            }
                        }
                        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_competitor1")) {
                            var competitor1 = formContext.getControl("header_process_niq_competitor1").getAttribute().getValue();
                            if (competitor1 === null || competitor1 === false) {
                                errorMessage += "Competitor 1 ";
                            }
                        }

                        if (errorMessage !== " ") {
                            if (errorMessage !== " ") {
                                var confirmStrings = { confirmButtonLabel: "Ok", text: "Please revise this opportunity to solve for the following validation error:" + errorMessage + ". You will be able to resubmit it to Gatekeeper after that." };
                                var confirmOptions = { height: 200, width: 450 };
                                Xrm.Navigation.openAlertDialog(confirmStrings, confirmOptions).then(
                                    function (success) { }
                                );
                            }

                        }
                        else {
                            if (formContext.getAttribute("niq_hostopportunity").getValue() === null && formContext.getAttribute("niq_revenuesharedeal").getValue() === true) {
                                var errormsg = " ";
                                Xrm.WebApi.retrieveMultipleRecords("opportunity", "?$select=niq_approvalstatus,_niq_hostopportunity_value,niq_opportunitynumber&$filter=(_niq_hostopportunity_value eq " + opportunityId + " and niq_approvalstatus ne 100000001)").then(
                                    function success(results) {
                                        console.log(results);
                                        for (var i = 0; i < results.entities.length; i++) {
                                            var result = results.entities[i];
                                            // Columns
                                            var opportunityid = result["opportunityid"]; // Guid
                                            var niq_approvalstatus = result["niq_approvalstatus"]; // Choice
                                            var niq_opportunitynumber = result["niq_opportunitynumber"]; // Text
                                            errormsg = errormsg + niq_opportunitynumber + ","; // Text
                                        }
                                        if (errormsg !== " ") {
                                            const error1 = errormsg.replace(/,*$/, '');
                                            var confirmStrings = { confirmButtonLabel: "Ok", text: "These child opportunities " + error1 + " have not been submitted to gatekeeper. Please send all child opportunities to the gatekeeper before sending the host opportunity to gatekeeper" };
                                            var confirmOptions = { height: 200, width: 450 };
                                            Xrm.Navigation.openAlertDialog(confirmStrings, confirmOptions).then(
                                                function (success) { }
                                            );
                                        }
                                        else {

                                            if (CommonForm.Events.CheckFieldExists(formContext, "niq_approvalstatus")) {
                                                formContext.getAttribute("niq_approvalstatus").setValue(100000001);
                                                formContext.data.entity.save();
                                            }
                                        }
                                    },
                                    function (error) {
                                        console.log(error.message);
                                    }
                                );
                            }
                            else {
                                if (CommonForm.Events.CheckFieldExists(formContext, "niq_approvalstatus")) {
                                    formContext.getAttribute("niq_approvalstatus").setValue(100000001);
                                    formContext.data.entity.save();
                                }
                            }

                        }
                    }
                });
        }
    },

    onClickRecall: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var revenuesharedeal = formContext.getAttribute("niq_revenuesharedeal").getValue();
        var confirmStrings = { text: "Do you wish to Recall the Opportunity ", cancelButtonLabel: "No", confirmButtonLabel: "Yes" };
        var confirmOptions = { height: 200, width: 450 };
        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {

                    if (CommonForm.Events.CheckFieldExists(formContext, "niq_approvalstatus")) {
                        formContext.getAttribute("niq_approvalstatus").setValue(100000004);
                        formContext.data.entity.save();
                    }
                    if (revenuesharedeal === true)
                    {
                        var execute_niq_Action_Opportunity_Recall_Resubmit_Request =
                        {
                            // Parameters
                            Host_OpportunityID: formContext.data.entity.getId().replace("{", "").replace("}", ""), // Edm.String
                            getMetadata: function () {
                                return {
                                    boundParameter: null,
                                    parameterTypes: {
                                        Host_OpportunityID: { typeName: "Edm.String", structuralProperty: 1 }
                                    },
                                    operationType: 0, operationName: "niq_Action_Opportunity_Recall_Resubmit"
                                };
                            }
                        };

                        Xrm.WebApi.execute(execute_niq_Action_Opportunity_Recall_Resubmit_Request).then(
                            function success(response) {
                                if (response.ok) { console.log("Success"); }
                            }
                        ).catch(function (error) {
                            console.log(error.message);
                        });
                    }
                }

            });

    },
    RecallVisibility: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var approvalStatus = false;
        var Open = false;
        var opportunityId = formContext.data.entity.getId();
        var FARGenerated = false;
        var TypeForm = false;
        var GKCheck = true;
        if ((formContext.getAttribute("niq_approvalstatus").getValue() !== null) && (formContext.getAttribute("niq_approvalstatus").getValue() === 100000001)) {
            approvalStatus = true;
        }
        if (formContext.getAttribute("statecode").getValue() === 0) {
            Open = true;
        }
        if ((formContext.ui.getFormType() === 2)) {
            TypeForm = true;
        }
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator")) {
         GKCheck=true;
        }
        else if(CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add-On Finance Gatekeeper")) {
            GKCheck=false;
        }
        if ((approvalStatus === true) && (Open === true) && (TypeForm === true) && (GKCheck ===true)) {
            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'><entity name='niq_financeapprovalrequests'><attribute name='niq_financeapprovalrequestsid' /><order attribute='niq_financeapprovalrequests' descending='false' /><filter type='and'><condition attribute='statecode' operator='eq' value='0' /><condition attribute='niq_relatedopportunity' operator='eq' uitype='opportunity' value='" + opportunityId + "' /><condition attribute='niq_approvalstatus' operator='eq' value='100000001' /><condition attribute='niq_approvaltype' operator='eq' value='100000000' /></filter></entity></fetch>";
            var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
            var result = GetCRMWebAPI.Methods.GetFetchRecords(clienturl, fetchXml, "niq_financeapprovalrequestses");
            if (result != null && result.value.length > 0) {
                FARGenerated = true;
            }
            if (FARGenerated === true) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    },
    OnClickOfNewSAPAccountRequest: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var formParameters = {};
        var oppoData = new Array();
        oppoData[0] = new Object();
        oppoData[0].id = formContext.data.entity.getId();
        oppoData[0].name = formContext.getAttribute("name").getValue();
        oppoData[0].entityType = "opportunity";
        formParameters["niq_opportunityid"] = oppoData;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_sapaccountrequest";
        entityFormOptions["useQuickCreateForm"] = true;
        entityFormOptions["createFromEntity"] = oppoData[0];
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );
    },
    ManageExistingContractOnClick: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        var opportunityId = formContext.data.entity.getId().replace("{", "").replace("}", "");
        var globalContext = Xrm.Utility.getGlobalContext();
        var serverUrl = globalContext.getClientUrl();
        var fetchOppo = " ";
        var originalOppo = new Array();
        originalOppo[0] = new Object();
        originalOppo[0].id = formContext.data.entity.getId();
        originalOppo[0].name = formContext.getAttribute("name").getValue();
        originalOppo[0].entityType = "opportunity";
        if (CommonForm.Events.CheckValueExists(formContext, "statecode")) {
            fetchOppo = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                "<entity name='opportunity'>" +
                "<attribute name='name' />" +
                "<attribute name='customerid' />" +
                "<attribute name='estimatedvalue' />" +
                "<attribute name='statuscode'/>" +
                "<attribute name='statecode'/>" +
                "<attribute name='niq_stage'/>" +
                "<attribute name='niq_originalopportunityid'/>" +
                "<attribute name='niq_newcontractannualvalue'/>" +
                "<attribute name='opportunityid' />" +
                "<order attribute='name' descending='false' />" +
                "<filter type='and'>" +
                "<condition attribute='statecode' operator='ne' value='2' />" +
                "<condition attribute='niq_originalopportunityid' operator='eq' uitype='opportunity' value='" + opportunityId + "' />" +
                "</filter>" +
                "</entity>" +
                "</fetch>";
            var fetchOppoResults = GetCRMWebAPI.Methods.GetFetchRecords(serverUrl, fetchOppo, "opportunities");
            if (fetchOppoResults !== null && fetchOppoResults.value.length > 0) {
                var existingContract = fetchOppoResults.value[0].opportunityid;
                var existingContractformatedvalue = fetchOppoResults.value[0].name;
                var oppoStatus = fetchOppoResults.value[0].statecode;
                var stageName = fetchOppoResults.value[0].niq_stage;
                if (existingContract !== null && existingContract !== "undefined") {
                    var opportunityObj = new Array();
                    opportunityObj[0] = new Object();
                    opportunityObj[0].id = existingContract;
                    opportunityObj[0].name = existingContractformatedvalue;
                    opportunityObj[0].entityType = "opportunity";
                    if (oppoStatus !== null && oppoStatus === 0) {
                        var confirmStrings = { text: "There is already an open opportunity '" + existingContractformatedvalue + "' created by manage existing contract action from this opportunity. Please proceed with adjusting this opportunity instead of creating a new one or move that open opportunity to Closed Lost to be able to trigger manage existing contract action from the current opportunity", cancelButtonLabel: "Cancel", confirmButtonLabel: "Open " + existingContractformatedvalue };
                        var confirmOptions = { height: 200, width: 450 };
                        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
                            function (success) {
                                if (success.confirmed) {
                                    var entityFormOptions = {};
                                    entityFormOptions["entityName"] = "opportunity";
                                    entityFormOptions["entityId"] = existingContract;
                                    Xrm.Navigation.openForm(entityFormOptions).then(
                                        function (success) { },
                                        function (error) { });
                                }
                            });
                    } else if (oppoStatus !== null && oppoStatus === 1 && stageName === "Closed Won - Approved") {
                        var confirmStrings = { text: "There is a Closed-Won Approved opportunity '" + existingContractformatedvalue + "' reflecting a more recent version of the same contract. Please proceed to this opportunity to trigger manage existing contract action from there.", cancelButtonLabel: "Cancel", confirmButtonLabel: "Open " + existingContractformatedvalue };
                        var confirmOptions = { height: 200, width: 450 };
                        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
                            function (success) {
                                if (success.confirmed) {
                                    var entityFormOptions = {};
                                    entityFormOptions["entityName"] = "opportunity";
                                    entityFormOptions["entityId"] = existingContract;
                                    Xrm.Navigation.openForm(entityFormOptions).then(
                                        function (success) { },
                                        function (error) { });
                                }
                            });
                    }
                }
            }
            else {
                var entityFormOptions = {};
                entityFormOptions["entityName"] = "opportunity";
                var formParameters = {};
                if (CommonForm.Events.CheckValueExists(formContext, "niq_billingtype")) {
                    formParameters["niq_billingtype"] = formContext.getAttribute("niq_billingtype").getValue();
                }
                if (CommonForm.Events.CheckValueExists(formContext, "parentaccountid")) {
                    var accountName = new Array();
                    accountName[0] = new Object();
                    accountName[0].id = formContext.getAttribute("parentaccountid").getValue()[0].id;
                    accountName[0].name = formContext.getAttribute("parentaccountid").getValue()[0].name;
                    accountName[0].entityType = "account";
                    formParameters["parentaccountid"] = accountName;
                }
                if (CommonForm.Events.CheckValueExists(formContext, "niq_salesorgid")) {
                    var salesOrg = new Array();
                    salesOrg[0] = new Object();
                    salesOrg[0].id = formContext.getAttribute("niq_salesorgid").getValue()[0].id;
                    salesOrg[0].name = formContext.getAttribute("niq_salesorgid").getValue()[0].name;
                    salesOrg[0].entityType = "niq_salesorg";
                    formParameters["niq_salesorgid"] = salesOrg;
                }
                if (CommonForm.Events.CheckValueExists(formContext, "niq_salesgroupsalesorgid")) {
                    var salesGroup = new Array();
                    salesGroup[0] = new Object();
                    salesGroup[0].id = formContext.getAttribute("niq_salesgroupsalesorgid").getValue()[0].id;
                    salesGroup[0].name = formContext.getAttribute("niq_salesgroupsalesorgid").getValue()[0].name;
                    salesGroup[0].entityType = "niq_salesgroupsalesorg";
                    formParameters["niq_salesgroupsalesorgid"] = salesGroup;
                }
                if (CommonForm.Events.CheckValueExists(formContext, "niq_billinginstructions")) {
                    formParameters["niq_billinginstructions"] = formContext.getAttribute("niq_billinginstructions").getValue();
                }
                if (CommonForm.Events.CheckValueExists(formContext, "transactioncurrencyid")) {
                    formParameters["transactioncurrencyid"] = formContext.getAttribute("transactioncurrencyid").getValue();
                }
                if (CommonForm.Events.CheckValueExists(formContext, "niq_billtoparty")) {
                    var billTo = new Array();
                    billTo[0] = new Object();
                    billTo[0].id = formContext.getAttribute("niq_billtoparty").getValue()[0].id;
                    billTo[0].name = formContext.getAttribute("niq_billtoparty").getValue()[0].name;
                    billTo[0].entityType = "account";
                    formParameters["niq_billtoparty"] = billTo;
                }
                if (CommonForm.Events.CheckValueExists(formContext, "niq_soldtoparty")) {
                    var soldTo = new Array();
                    soldTo[0] = new Object();
                    soldTo[0].id = formContext.getAttribute("niq_soldtoparty").getValue()[0].id;
                    soldTo[0].name = formContext.getAttribute("niq_soldtoparty").getValue()[0].name;
                    soldTo[0].entityType = "account";
                    formParameters["niq_soldtoparty"] = soldTo;
                }
                if (CommonForm.Events.CheckValueExists(formContext, "niq_deliverytoparty")) {
                    var deliverTo = new Array();
                    deliverTo[0] = new Object();
                    deliverTo[0].id = formContext.getAttribute("niq_deliverytoparty").getValue()[0].id;
                    deliverTo[0].name = formContext.getAttribute("niq_deliverytoparty").getValue()[0].name;
                    deliverTo[0].entityType = "account";
                    formParameters["niq_deliverytoparty"] = deliverTo;
                }
                if (CommonForm.Events.CheckValueExists(formContext, "parentcontactid")) {
                    var invoiceRec = new Array();
                    invoiceRec[0] = new Object();
                    invoiceRec[0].id = formContext.getAttribute("parentcontactid").getValue()[0].id;
                    invoiceRec[0].name = formContext.getAttribute("parentcontactid").getValue()[0].name;
                    invoiceRec[0].entityType = "contact";
                    formParameters["parentcontactid"] = invoiceRec;
                }
                if (CommonForm.Events.CheckValueExists(formContext, "niq_sapsalesdocumentid")) {
                    formParameters["niq_existingsapsalesdocumentid"] = formContext.getAttribute("niq_sapsalesdocumentid").getValue();
                } else if (CommonForm.Events.CheckValueExists(formContext, "niq_existingsapsalesdocumentid")) {
                    formParameters["niq_existingsapsalesdocumentid"] = formContext.getAttribute("niq_existingsapsalesdocumentid").getValue();
                }
                /*if (CommonForm.Events.CheckValueExists(formContext, "niq_existingcontractaction")) {
                    var existingContAct = formContext.getAttribute("niq_existingcontractaction").getValue();
                    if (existingContAct === 3 || existingContAct === 2) {
                        if (CommonForm.Events.CheckValueExists(formContext, "niq_finallyexecutedagreementurl")) {
                            formParameters["niq_finallyexecutedagreementurl"] = formContext.getAttribute("niq_finallyexecutedagreementurl").getValue();
                        }
                    }
                }*/
                if (CommonForm.Events.CheckValueExists(formContext, "niq_contractenddate")) {
                    formParameters["niq_existingcontractexpirationdate"] = formContext.getAttribute("niq_contractenddate").getValue();
                }
                /*if (CommonForm.Events.CheckValueExists(formContext, "niq_newcontractannualvalue")) {
                    formParameters["niq_existingcontractannualvalue"] = formContext.getAttribute("niq_newcontractannualvalue").getValue();
                } 
               */
                formParameters["niq_opportunitytype"] = "2";
                formParameters["ownerid"] = Xrm.Utility.getGlobalContext().userSettings.userName;
                formParameters["niq_originalopportunityid"] = originalOppo;
                Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
                    function (success) { },
                    function (error) { }
                );
            }
        }
    },
    ViewARForThisOpportunityVisibility: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        if ((CommonForm.Events.CheckValueExists(formContext, "niq_sapsalesdocumentid")) && (CommonForm.Events.CheckValueExists(formContext, "statecode")) && (CommonForm.Events.CheckValueExists(formContext, "niq_stage"))) {
            if ((formContext.getAttribute("statecode").getValue() === 1) && (formContext.getAttribute("niq_stage").getValue() === "Closed Won - Approved")) {
                return true;
            }
            else
                return false;

        }
        else
            return false;

    },
    onClickCloseOpenQuotes: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var confirmStrings = { text: "Do you want to close open Quotes for this Opportunity? For markets using Conga contract processes, this would also close any related agreements in Conga. This cannot be undone." };
        var confirmOptions = { height: 200, width: 450 };
        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    var oppoId = formContext.data.entity.getId().replace("{", "").replace("}", "");

                    Xrm.WebApi.online.retrieveMultipleRecords("quote", "?$select=quoteid&$filter=_opportunityid_value eq " + oppoId + " and  statecode eq 0").then(
                        function success(results) {
                            for (var i = 0; i < results.entities.length; i++) {
                                var quoteid = results.entities[i]["quoteid"];

                                var entity = {};
                                entity.statecode = 1;

                                Xrm.WebApi.online.updateRecord("quote", quoteid, entity).then(
                                    function success(result) {
                                        var updatedEntityId = result.id;

                                        var QuoteID = updatedEntityId.replace("{", "").replace("}", "");

                                        var quoteclose = {
                                            "quoteid@odata.bind": "/quotes(" + QuoteID + ")",
                                            "subject": "Quote Close Subject",
                                            "actualend": new Date(),
                                            "description": "Your description here"
                                        };

                                        var closeQuoteRequest = {
                                            QuoteClose: quoteclose,
                                            Status: 5,

                                            getMetadata: function () {
                                                return {
                                                    boundParameter: null,
                                                    parameterTypes: {
                                                        "QuoteClose": {
                                                            "typeName": "mscrm.quoteclose",
                                                            "structuralProperty": 5
                                                        },
                                                        "Status": {
                                                            "typeName": "Edm.Int32",
                                                            "structuralProperty": 1
                                                        }
                                                    },
                                                    operationType: 0,
                                                    operationName: "CloseQuote"
                                                };
                                            }
                                        };

                                        Xrm.WebApi.online.execute(closeQuoteRequest).then(
                                            function success(result) {
                                                if (result.ok) {
                                                }
                                            },
                                            function (error) {
                                                Xrm.Utility.alertDialog(error.message);
                                            }
                                        );


                                    },
                                    function (error) {
                                        Xrm.Utility.alertDialog(error.message);
                                    }
                                );

                            }
                        },
                        function (error) {
                            Xrm.Utility.alertDialog(error.message);
                        }
                    );

                    Xrm.WebApi.online.retrieveMultipleRecords("quote", "?$select=quoteid&$filter=_opportunityid_value eq " + oppoId + " and  statecode eq 1").then(
                        function success(results) {
                            for (var i = 0; i < results.entities.length; i++) {
                                var quoteid = results.entities[i]["quoteid"];

                                var QuoteID = quoteid.replace("{", "").replace("}", "");

                                var quoteclose = {
                                    "quoteid@odata.bind": "/quotes(" + QuoteID + ")",
                                    "subject": "Quote Close Subject",
                                    "actualend": new Date(),
                                    "description": "Your description here"
                                };

                                var closeQuoteRequest = {
                                    QuoteClose: quoteclose,
                                    Status: 5,

                                    getMetadata: function () {
                                        return {
                                            boundParameter: null,
                                            parameterTypes: {
                                                "QuoteClose": {
                                                    "typeName": "mscrm.quoteclose",
                                                    "structuralProperty": 5
                                                },
                                                "Status": {
                                                    "typeName": "Edm.Int32",
                                                    "structuralProperty": 1
                                                }
                                            },
                                            operationType: 0,
                                            operationName: "CloseQuote"
                                        };
                                    }
                                };

                                Xrm.WebApi.online.execute(closeQuoteRequest).then(
                                    function success(result) {
                                        if (result.ok) {
                                        }
                                    },
                                    function (error) {
                                        Xrm.Utility.alertDialog(error.message);
                                    }
                                );
                            }
                        },
                        function (error) {
                            Xrm.Utility.alertDialog(error.message);
                        }
                    );
                }
                else { }
            });
    },
    RaiseChangeRequestButtonVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User,NIQ Business Admin,System Administrator,System Customizer")) {
            return true;
        }
        else {
            return false;
        }
    },
	onClickBillToClientChange: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_postopportunity";
        entityFormOptions["useQuickCreateForm"] = true;

        // Set default values for the Contact form
        var formParameters = {};

        var oppoData = new Array();
        oppoData[0] = new Object();
        oppoData[0].id = formContext.data.entity.getEntityReference().id.replace("{", "").replace("}", "");
        oppoData[0].name = formContext.data.entity.getEntityReference().name;
        oppoData[0].entityType = formContext.data.entity.getEntityReference().entityType;
        formParameters["niq_opportunity"] = oppoData;
        formParameters["niq_typeofchange"] = "100000002";
        formParameters["niq_descriptionofchange"] = "Bill To / Deliver To Party change based on the provided documentation";

        if (CommonForm.Events.CheckValueExists(formContext, "niq_billtoparty")){
            var billToParty = new Array();
            billToParty[0] = new Object();
            billToParty[0].id = formContext.getAttribute("niq_billtoparty").getValue()[0].id;
            billToParty[0].name = formContext.getAttribute("niq_billtoparty").getValue()[0].name;
            billToParty[0].entityType = "account";
            formParameters["niq_currentbilltoparty"] = billToParty;
        }

        if (CommonForm.Events.CheckValueExists(formContext, "niq_deliverytoparty")){
            var billToParty = new Array();
            billToParty[0] = new Object();
            billToParty[0].id = formContext.getAttribute("niq_deliverytoparty").getValue()[0].id;
            billToParty[0].name = formContext.getAttribute("niq_deliverytoparty").getValue()[0].name;
            billToParty[0].entityType = "account";
            formParameters["niq_currentdelivertoparty"] = billToParty;
        }

        if (CommonForm.Events.CheckValueExists(formContext, "niq_billtoparty")){
            var billToParty = new Array();
            billToParty[0] = new Object();
            billToParty[0].id = formContext.getAttribute("niq_billtoparty").getValue()[0].id;
            billToParty[0].name = formContext.getAttribute("niq_billtoparty").getValue()[0].name;
            billToParty[0].entityType = "account";
            formParameters["niq_newbilltopartyid"] = billToParty;
        }

        if (CommonForm.Events.CheckValueExists(formContext, "niq_deliverytoparty")){
            var billToParty = new Array();
            billToParty[0] = new Object();
            billToParty[0].id = formContext.getAttribute("niq_deliverytoparty").getValue()[0].id;
            billToParty[0].name = formContext.getAttribute("niq_deliverytoparty").getValue()[0].name;
            billToParty[0].entityType = "account";
            formParameters["niq_newdeliverytoparty"] = billToParty;
        }
        
        // Open the form.

        //Story - 2220
        // get the billToDeliverToChnage field value from backend
        var opportunityId = Xrm.Page.data.entity.getId();
        var billToDeliverToChnage = "niq_billtodelivertochangepocrdocument";
        var query = "/api/data/v9.1/opportunities(" + opportunityId.slice(1, -1) + ")?$select=" + billToDeliverToChnage;

        // Execute the Request
        var req = new XMLHttpRequest();
                req.open("GET", Xrm.Page.context.getClientUrl() + query, true);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var data = JSON.parse(this.response);
                            var billToDeliverToChnageValue = data[billToDeliverToChnage];


                            //If billToDeliverToChnageValue has Value...
                            if(billToDeliverToChnageValue !== null && billToDeliverToChnageValue !== undefined){
                                formParameters["niq_documentationconfirmingthechange"] = billToDeliverToChnageValue;
                            }
                        }
                        else {
                            Xrm.Utility.alertDialog(this.statusText);
                        }

                    }
                };
                req.send();
            

        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });
    },
    //DYNMSM-5162: creating onClickInvoiceRecipientUpdates function as per story HLS
    onClickInvoiceRecipientUpdates: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_postopportunity";
        entityFormOptions["useQuickCreateForm"] = true;

        var formParameters = {};

        var oppoData = new Array();
        oppoData[0] = new Object();
        oppoData[0].id = formContext.data.entity.getEntityReference().id.replace("{", "").replace("}", "");
        oppoData[0].name = formContext.data.entity.getEntityReference().name;
        oppoData[0].entityType = formContext.data.entity.getEntityReference().entityType;
        formParameters["niq_opportunity"] = oppoData;
        formParameters["niq_typeofchange"] = "100000010";
        if (CommonForm.Events.CheckValueExists(formContext, "parentcontactid")) {
            var invoiceRecipient = new Array();
            invoiceRecipient[0] = new Object();
            invoiceRecipient[0].id = formContext.getAttribute("parentcontactid").getValue()[0].id;
            invoiceRecipient[0].name = formContext.getAttribute("parentcontactid").getValue()[0].name;
            invoiceRecipient[0].entityType = "contact";
            formParameters["niq_parentcontactid"] = invoiceRecipient;
        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_invoicerecipient2")) {
            var invoiceRecipient2 = new Array();
            invoiceRecipient2[0] = new Object();
            invoiceRecipient2[0].id = formContext.getAttribute("niq_invoicerecipient2").getValue()[0].id;
            invoiceRecipient2[0].name = formContext.getAttribute("niq_invoicerecipient2").getValue()[0].name;
            invoiceRecipient2[0].entityType = "contact";
            formParameters["niq_invoicerecipient2"] = invoiceRecipient2;
        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_invoicerecipient3")) {
            var invoiceRecipient3 = new Array();
            invoiceRecipient3[0] = new Object();
            invoiceRecipient3[0].id = formContext.getAttribute("niq_invoicerecipient3").getValue()[0].id;
            invoiceRecipient3[0].name = formContext.getAttribute("niq_invoicerecipient3").getValue()[0].name;
            invoiceRecipient3[0].entityType = "contact";
            formParameters["niq_invoicerecipient3"] = invoiceRecipient3;
        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_invoicerecipient4")) {
            var invoiceRecipient4 = new Array();
            invoiceRecipient4[0] = new Object();
            invoiceRecipient4[0].id = formContext.getAttribute("niq_invoicerecipient4").getValue()[0].id;
            invoiceRecipient4[0].name = formContext.getAttribute("niq_invoicerecipient4").getValue()[0].name;
            invoiceRecipient4[0].entityType = "contact";
            formParameters["niq_invoicerecipient4"] = invoiceRecipient4;
        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_invoicerecipient5")) {
            var invoiceRecipient5 = new Array();
            invoiceRecipient5[0] = new Object();
            invoiceRecipient5[0].id = formContext.getAttribute("niq_invoicerecipient5").getValue()[0].id;
            invoiceRecipient5[0].name = formContext.getAttribute("niq_invoicerecipient5").getValue()[0].name;
            invoiceRecipient5[0].entityType = "contact";
            formParameters["niq_invoicerecipient5"] = invoiceRecipient5;
        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_nameoninvoiceifdifffrominvoicerecipient")) {
            var nameOnInvoice = new Array();
            nameOnInvoice[0] = new Object();
            nameOnInvoice[0].id = formContext.getAttribute("niq_nameoninvoiceifdifffrominvoicerecipient").getValue()[0].id;
            nameOnInvoice[0].name = formContext.getAttribute("niq_nameoninvoiceifdifffrominvoicerecipient").getValue()[0].name;
            nameOnInvoice[0].entityType = "contact";
            formParameters["niq_nameoninvoiceifdifffrominvoicerecipient"] = nameOnInvoice;
        }
        // Open the form.
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });
    },
    //onClickFinallyExecutedAgreementPaymentTermsSubmission: function (executionContext) {
    //    'use strict';
    //    var formContext = executionContext;
    //  var entityFormOptions = {};
    //  entityFormOptions["entityName"] = "niq_postopportunity";
    // entityFormOptions["useQuickCreateForm"] = true;

    // Set default values for the Contact form
    // var formParameters = {};

    // var oppoData = new Array();
    // oppoData[0] = new Object();
    // oppoData[0].id = formContext.data.entity.getEntityReference().id.replace("{", "").replace("}", "");
    // oppoData[0].name = formContext.data.entity.getEntityReference().name;
    // oppoData[0].entityType = formContext.data.entity.getEntityReference().entityType;
    //  formParameters["niq_opportunity"] = oppoData;
    //  formParameters["niq_typeofchange"] = "100000000";
    // Open the form.
    // Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
    //   function (success) {
    //     console.log(success);
    // },
    //  function (error) {
    //    console.log(error);
    //  });
    //  },

    //onClickPODetailsSubmission: function (executionContext) {
    //  'use strict';
    // var formContext = executionContext;
    // var entityFormOptions = {};
    // entityFormOptions["entityName"] = "niq_postopportunity";
    // entityFormOptions["useQuickCreateForm"] = true;

    // Set default values for the Contact form
    // var formParameters = {};

    //  var oppoData = new Array();
    // oppoData[0] = new Object();
    // oppoData[0].id = formContext.data.entity.getEntityReference().id.replace("{", "").replace("}", "");
    // oppoData[0].name = formContext.data.entity.getEntityReference().name;
    // oppoData[0].entityType = formContext.data.entity.getEntityReference().entityType;
    // formParameters["niq_opportunity"] = oppoData;
    // formParameters["niq_typeofchange"] = "100000001";
    // Open the form.
    // Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
    //   function (success) {
    //     console.log(success);
    //  },
    //  function (error) {
    //    console.log(error);
    // });
    // },
    onClickInvoiceRecipientUpdates: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_postopportunity";
        entityFormOptions["useQuickCreateForm"] = true;

        // Set default values for the Contact form
        var formParameters = {};

        var oppoData = new Array();
        oppoData[0] = new Object();
        oppoData[0].id = formContext.data.entity.getEntityReference().id.replace("{", "").replace("}", "");
        oppoData[0].name = formContext.data.entity.getEntityReference().name;
        oppoData[0].entityType = formContext.data.entity.getEntityReference().entityType;
        formParameters["niq_opportunity"] = oppoData;
        formParameters["niq_typeofchange"] = "100000010";

        // Open the form.
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });
    },

    onClickOtherChanges: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_postopportunity";
        entityFormOptions["useQuickCreateForm"] = true;


        var formParameters = {};

        var oppoData = new Array();
        oppoData[0] = new Object();
        oppoData[0].id = formContext.data.entity.getEntityReference().id.replace("{", "").replace("}", "");
        oppoData[0].name = formContext.data.entity.getEntityReference().name;
        oppoData[0].entityType = formContext.data.entity.getEntityReference().entityType;
        formParameters["niq_opportunity"] = oppoData;
        formParameters["niq_typeofchange"] = "100000006";
        // Open the form.
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });
    },

    onClickBusinessSegmentationChange: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_postopportunity";
        entityFormOptions["useQuickCreateForm"] = true;
        var formParameters = {};
        var oppoData = new Array();
        oppoData[0] = new Object();
        oppoData[0].id = formContext.data.entity.getEntityReference().id.replace("{", "").replace("}", "");
        oppoData[0].name = formContext.data.entity.getEntityReference().name;
        oppoData[0].entityType = formContext.data.entity.getEntityReference().entityType;
        formParameters["niq_opportunity"] = oppoData;
        formParameters["niq_typeofchange"] = "100000005";
        if (CommonForm.Events.CheckValueExists(formContext, "niq_internalinitiative")) {
            var internalIntiative = new Array();
            internalIntiative[0] = new Object();
            internalIntiative[0].id = formContext.getAttribute("niq_internalinitiative").getValue()[0].id;
            internalIntiative[0].name = formContext.getAttribute("niq_internalinitiative").getValue()[0].name;
            internalIntiative[0].entityType = "niq_internalinitiative";
            formParameters["niq_internalinitiative"] = internalIntiative;
        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_accountgoalid")) {
            var accountGoal = new Array();
            accountGoal[0] = new Object();
            accountGoal[0].id = formContext.getAttribute("niq_accountgoalid").getValue()[0].id;
            accountGoal[0].name = formContext.getAttribute("niq_accountgoalid").getValue()[0].name;
            accountGoal[0].entityType = "niq_niqaccountgoal";
            formParameters["niq_niqaccountgoalid"] = accountGoal;
        }
        if (CommonForm.Events.CheckValueExists(formContext, "campaignid")) {
            var primaryCampaign = new Array();
            primaryCampaign[0] = new Object();
            primaryCampaign[0].id = formContext.getAttribute("campaignid").getValue()[0].id;
            primaryCampaign[0].name = formContext.getAttribute("campaignid").getValue()[0].name;
            primaryCampaign[0].entityType = "campaign";
            formParameters["niq_primarymarketingcampaignid"] = primaryCampaign;
        }

        //Changes for DYNCRM-2662----Begin
        var comp1 = new Array();
        comp1[0] = new Object();
        if (formContext.getAttribute("niq_competitor1").getValue() != null)
        {
            comp1[0].id = formContext.getAttribute("niq_competitor1").getValue()[0].id;
            comp1[0].name = formContext.getAttribute("niq_competitor1").getValue()[0].name;
            comp1[0].entityType = "competitor"
            formParameters["niq_competitor1"] = comp1;
        }        

        var comp2 = new Array();
        comp2[0] = new Object();
        if (formContext.getAttribute("niq_competitor2").getValue() != null)
        {
            comp2[0].id = formContext.getAttribute("niq_competitor2").getValue()[0].id;
            comp2[0].name = formContext.getAttribute("niq_competitor2").getValue()[0].name;
            comp2[0].entityType = "competitor"
            formParameters["niq_competitor2"] = comp2;
        }               

        var comp3 = new Array();
        comp3[0] = new Object();
        if (formContext.getAttribute("niq_competitor3").getValue() != null)
        {
            comp3[0].id = formContext.getAttribute("niq_competitor3").getValue()[0].id;
            comp3[0].name = formContext.getAttribute("niq_competitor3").getValue()[0].name;
            comp3[0].entityType = "competitor"
            formParameters["niq_competitor3"] = comp3;
        }        
        
        var comp4 = new Array();
        comp4[0] = new Object();
        if (formContext.getAttribute("niq_competitor4").getValue() != null)
        {
            comp4[0].id = formContext.getAttribute("niq_competitor4").getValue()[0].id;
            comp4[0].name = formContext.getAttribute("niq_competitor4").getValue()[0].name;
            comp4[0].entityType = "competitor"
            formParameters["niq_competitor4"] = comp4; 
        }

        var comp5 = new Array();
        comp5[0] = new Object();
        if (formContext.getAttribute("niq_competitor5").getValue() != null)
        {
            comp5[0].id = formContext.getAttribute("niq_competitor5").getValue()[0].id;
            comp5[0].name = formContext.getAttribute("niq_competitor5").getValue()[0].name;
            comp5[0].entityType = "competitor"
            formParameters["niq_competitor5"] = comp5;
        }        

        var comp6 = new Array();
        comp6[0] = new Object();
        if (formContext.getAttribute("niq_competitor6").getValue() != null)
        {
            comp6[0].id = formContext.getAttribute("niq_competitor6").getValue()[0].id;
            comp6[0].name = formContext.getAttribute("niq_competitor6").getValue()[0].name;
            comp6[0].entityType = "competitor"
            formParameters["niq_competitor6"] = comp6;
        }
        
        if (formContext.getAttribute("niq_competitorsdetails").getValue() !== null)
        {
            formParameters["niq_competitorsdetails"] = formContext.getAttribute("niq_competitorsdetails").getValue();
        }
        if (formContext.getAttribute("niq_othercompetitor").getValue() !== null)
        {
            formParameters["niq_othercompetitor"] = formContext.getAttribute("niq_othercompetitor").getValue();
        }
        //Changes for DYNCRM-2662----End

        // Open the form.
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });
    },

    onClickCloneOpportunityDataPopulate: function (PrimaryControl) {
        "use strict";
        var formContext = PrimaryControl;
        var recid = formContext.data.entity.getId().replace("{", "").replace("}", "");
        var recordName = formContext.getAttribute("name").getValue();
        var recordType = "opportunity"

        var entityFormOptions = {};
        entityFormOptions["entityName"] = "opportunity";
        entityFormOptions["useQuickCreateForm"] = true;

        var targetData = new Array();
        targetData[0] = new Object();

        targetData[0].id = recid;
        targetData[0].name = recordName;
        targetData[0].entityType = recordType;

        var formParameters = {};
        formParameters["niq_cloneopportunity"] = targetData;
        formParameters["niq_opportunitytype"] = 1;

        // Open the form.       
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
                console.log(success);
            },
            function (error) {
                console.log(error);
            });
    },

    NewSAPAccountRequestButtonVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckValueExists(formContext, "parentaccountid") && CommonForm.Events.CheckValueExists(formContext, "niq_salesorgid")) {
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User,NIQ Business Admin,System Administrator,System Customizer")) {
                return true;
            }
        }
        else {
            return false;
        }
    },
    ViewARForThisOpportunityButtonOnClick: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        Xrm.WebApi.online.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_name,niq_to&$filter=niq_name eq 'View%20AR%20for%20this%20opportunity%20button%20link'").then(
            function success(results) {
                for (var i = 0; i < results.entities.length; i++) {
                    var niq_to = results.entities[i]["niq_to"];
                    if ((niq_to !== null) && (CommonForm.Events.CheckFieldExists(formContext, "niq_sapsalesdocumentid"))) {
                        var salesDocId = formContext.getAttribute("niq_sapsalesdocumentid").getValue();
                        var url = niq_to.replace("{", salesDocId)
                        Xrm.Navigation.openUrl(url)
                    }
                }
            },
            function (error) {
            }
        );
    },
    ViewUnBilledForThisOpportunityVisibility: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        if ((CommonForm.Events.CheckValueExists(formContext, "niq_sapsalesdocumentid")) && (CommonForm.Events.CheckValueExists(formContext, "statecode")) && (CommonForm.Events.CheckValueExists(formContext, "niq_stage"))) {
            if ((formContext.getAttribute("statecode").getValue() === 1) && (formContext.getAttribute("niq_stage").getValue() === "Closed Won - Approved")) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    },
    ViewUnBilledForThisOpportunityButtonOnClick: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        Xrm.WebApi.online.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_name,niq_to&$filter=niq_name eq 'View%20Unbilled%20for%20this%20Opportunity%20Button%20Link'").then(
            function success(results) {
                for (var i = 0; i < results.entities.length; i++) {
                    var niq_to = results.entities[i]["niq_to"];
                    if ((niq_to !== null) && (CommonForm.Events.CheckValueExists(formContext, "niq_sapsalesdocumentid"))) {
                        var salesDocId = formContext.getAttribute("niq_sapsalesdocumentid").getValue();
                        var url = niq_to.replace("{", salesDocId)
                        Xrm.Navigation.openUrl(url)
                    }
                }
            },
            function (error) {
            }
        );
    },
    CloseLostForOpportunityForm: function (primaryControl) {
        var formContext = primaryControl;

        if (formContext.data.entity.getId() != null && formContext.data.entity.getId() != '') {
            var recId = formContext.data.entity.getId().replace("{", "").replace("}", "");
            OpportunityRibbon.Events.CloseLostForMultipleRecords(primaryControl, recId);

        }
    },

    CloseLostForMultipleRecords: function (primaryControl, selectedIds) {
        //alert('CloseLostForMultipleRecords');

        if (selectedIds != null && selectedIds != '') {
            var strIds = selectedIds.toString();
            //alert(strIds);
            var arrIds = strIds.split(',');
        }
        var condition = null;
        for (let i = 0; i < arrIds.length; i++)
        //arrIds.forEach(function (id) {
        {
            var id = arrIds[i];
            if (condition == null)
                condition = '<condition attribute="opportunityid" operator="eq" value="' + id + '" />';
            else
                condition = condition + '<condition attribute="opportunityid" operator="eq" value="' + id + '" />';

        }
        //);
        //alert(condition);

        var fetchXmlQuery = '<fetch version= "1.0" output-format="xml-platform" mapping= "logical" distinct= "false">' +
            '<entity name= "opportunity">' +
            '<attribute name="opportunityid"/>' +
            '<attribute name="niq_approvalstatus"/>' +
            '<attribute name="niq_approvalstatusname"/>' +
            '<attribute name="niq_opportunitynumber"/>' +
            '<attribute name="statecode"/>' +
            '<attribute name="statecodename"/>' +
            '<filter type="or">' + condition + ' </filter>' +
            '</entity>  ' +
            '</fetch>';
        //alert(fetchXmlQuery);
        var FARrecords = null;
        var req = new XMLHttpRequest();
        req.open(
            "GET",
            Xrm.Page.context.getClientUrl() +
            "/api/data/v9.0/opportunities?fetchXml=" +
            encodeURIComponent(fetchXmlQuery),
            false
        );
        req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    // console.dir(results);
                    // console.log(results);
                    for (var i = 0; i < results.value.length; i++) {
                        var result = results.value[i];
                        // Columns
                        var opportunityid = result["opportunityid"]; // Guid
                        var niq_approvalstatus = result["niq_approvalstatus"]; // Choice
                        var niq_approvalstatus_formatted = result["niq_approvalstatus@OData.Community.Display.V1.FormattedValue"];
                        //alert('approvalstatus ' + niq_approvalstatus_formatted);
                        var niq_opportunitynumber = result["niq_opportunitynumber"]; // Text
                        var statecode = result["statecode"]; // State
                        var statecode_formatted = result["statecode@OData.Community.Display.V1.FormattedValue"];
                        //alert('statecode ' + statecode_formatted);
                        if (niq_approvalstatus_formatted == 'In Progress' || niq_approvalstatus_formatted == 'Pending' || statecode_formatted == 'Won' || statecode_formatted == 'Lost') {
                            if (FARrecords == null) {
                                FARrecords = niq_opportunitynumber;
                            }
                            else {
                                FARrecords = FARrecords + ',' + niq_opportunitynumber;
                            }
                        }

                    }
                    //alert('FARrecords: Opp numbers ' + FARrecords);
                    if (FARrecords != null) {
                        var confirmStrings = {
                            confirmButtonLabel: "Ok", text: "Opportunities displayed below can not be closed as Lost because they either are in Closed Won-in Review stage awaiting Gatekeeper approval or have been Lost or Won already. You need to recall opportunities pending Gatekeeper review first to be able to proceed with closing them as Lost. As to already Won or Lost opportunities, they can not be closed as Lost and should not be selected when using 'Close Opportunities As Lost' button.\n" + FARrecords
                        };
                        var confirmOptions = { height: 400, width: 650 };
                        Xrm.Navigation.openAlertDialog(confirmStrings, confirmOptions).then(
                            function (success) { }
                        );
                        return false;
                    } // 4870
                    else if (FARrecords == null) {
                        //alert('FARrecords == null');
                        OpportunityRibbon.Events.OpenCustomPageDialog(primaryControl, selectedIds);
                    } //4870
                } else {
                    alert(this.statusText);
                }
            }
        };
        req.send();

    },
    OpenCustomPageDialog: function (primaryControl, selectedRecordIds) {

        // Centered Dialog
        var pageInput = {
            pageType: "custom",
            name: "niq_closelostopportunity_66401",
            recordId: selectedRecordIds  // "{087AA308-B321-E811-A845-000D3A33A3AC}",
        };
        var navigationOptions = {
            target: 2,
            position: 1,
            height: {
                value: 560,
                unit: "px"
            },

            width: {
                value: 700,
                unit: "px"
            },
            title: "Close Lost Opportunity"
        };
        Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
            function () {
                // Refresh the main form when the dialog is closed
                //primaryControl.data.refresh();
            }

        ).catch(
            function (error) {
                // Handle error
            }
            );
    },// get the Access to the backup users
    GetBackupAccessOnClickAction: function () {
        var globalcontext = Xrm.Utility.getGlobalContext();
        var serverURL = globalcontext.getClientUrl();
        var actionName = "niq_GiveBackupAccessToUsersAction";//"59213340-4A7E-4486-AE80-9593CD58F79B";
        var opportunitycurrentuser = globalcontext.userSettings.userId.substring(1, 37);
        var OpportunityOwner = formContext.getAttribute("ownerid").getValue()[0].id.substring(1, 37);
        // alert('OpportunityOwner ' + OpportunityOwner);
        // alert('opportunitycurrentuser' + opportunitycurrentuser);
        var OpportunityId = formContext.data.entity.getId().substring(1, 37);
        //alert('id' + OpportunityId);
        // var query = entityName + "(" + entityId + ")/Microsoft.Dynamics.CRM." + actionName;
        var data = {
            "OpportunityUser": opportunitycurrentuser,
            "OpportunityId": OpportunityId,
            "OpportunityOwner": OpportunityOwner
        };

        var req = new XMLHttpRequest();
        req.open("POST", serverURL + "/api/data/v9.2/" + "niq_GiveBackupAccessToUsersAction", true);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");

        req.onreadystatechange = function () {
            if (this.readyState == 4) {
                req.onreadystatechange = null;
                if (this.status == 200 || this.status == 204) {
                    //alert("action is working");
                    result = JSON.parse(this.response);
                    var texts = result.Message;
                    if (texts.length > 0 && texts != "Ok") {


                        var confirmStrings = { text: texts, title: "Confirmation Dialog for User" };
                        var confirmOptions = { height: 200, width: 450 };
                        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions);
                    }
                }


            }
        };
        req.send(window.JSON.stringify(data));

    },

    LaunchQuoteConfiguration: function (primaryControl, opportunityid) {
        var formContext = primaryControl;
        if (opportunityid != null)
        {
            Xrm.WebApi.online.retrieveRecord("opportunity", opportunityid, "?$select=_niq_mainquoteid_value").then(
                function success(result) {
                    var mainquoteId = result["_niq_mainquoteid_value"];
                    if (mainquoteId !== null) {
                        Experlogix.launchConfigurator("quote", "1084", mainquoteId, primaryControl);
                    }
                },
                function (error) {
                    Xrm.Utility.alertDialog(error.message);
                }
            );
        }        
    },
    LaunchQuoteConfigurationForForm: function (primaryControl) {
        var opportunityid = primaryControl.data.entity._entityId.guid;
        OpportunityRibbon.Events.LaunchQuoteConfiguration(primaryControl, opportunityid);       
    },

}