if (typeof (QuoteProductCharacteristicsForm) === "undefined") {
    QuoteProductCharacteristicsForm = {
        __namespace: true
    };
}

QuoteProductCharacteristicsForm.Events = {
    OnFormLoad: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        this.LockUnlockCharValue(executionContext);
    },
    LockUnlockCharValue: function (executionContext) {
        "use strict";
        //based on the opportunity approval status or status lock material characteristic value
        var formContext = executionContext.getFormContext();
        // getting formcontext
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_materialcharacteristicvalueid") && CommonForm.Events.CheckValueExists(formContext, "niq_quoteid")) {
            var quote = formContext.getAttribute("niq_quoteid").getValue();
            var quote_id = quote[0].id.replace('{', '').replace('}', '');
            Xrm.WebApi.online.retrieveRecord("quote", quote_id, "?$select=_opportunityid_value&$expand=opportunityid($select=niq_approvalstatus,statecode)").then(
                function success(result) {
                    var oppovalue = result["_opportunityid_value"];
                    if (oppovalue !== null) {
                        if (result.hasOwnProperty("opportunityid")) {
                            var approvalstatus = result["opportunityid"]["niq_approvalstatus"];
                            var statecode = result["opportunityid"]["statecode"];
                            if ((approvalstatus !== null && approvalstatus === 100000001) || (statecode !== null && statecode === 1) || (statecode !== null && statecode === 2)) {
                                formContext.getControl("niq_materialcharacteristicvalueid").setDisabled(true);
                            }
                        }
                    }
                },
                function (error) {

                }
            );
        }
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales")) {
            formContext.getControl("niq_quoteid").setDisabled(true);
            formContext.getControl("niq_quoteproductid").setDisabled(true);
            formContext.getControl("niq_materialcharacteristicid").setDisabled(true);
            formContext.getControl("niq_mandatory").setDisabled(true);
        }
    }
}