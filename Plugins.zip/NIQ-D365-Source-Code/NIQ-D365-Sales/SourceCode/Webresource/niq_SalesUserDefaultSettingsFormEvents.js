if (typeof (SalesUserDefaultSettingsFormEvents) === "undefined") {
    SalesUserDefaultSettingsFormEvents = {
        __namespace: true
    };
}

SalesUserDefaultSettingsFormEvents.Events = {
    SetFormNotificationOnLoad: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.ui.clearFormNotification("NotificationMessageForUser");
        formContext.ui.setFormNotification("All the users listed in this section will be able to get edit access to the opportunities owned by you by clicking \"Get backup access\" button displayed on each opportunity. Removing a user from this list will prevent them from using \"Get backup access\" button to your opportunities in the future but will not remove the edit access they have gained before the removal from this section", "WARNING", "NotificationMessageForUser");
        this.unlockUser(executionContext);

    },
    unlockUser: function (executionContext) {
        //Getting formContext 
        var formContext = executionContext.getFormContext();


        //Store Security Roles
        var loggedUserRoles = Xrm.Utility.getGlobalContext().userSettings.roles;

        //Looping Through User's Security Roles.
        loggedUserRoles.forEach(function hasRoleName(item, index) {
            //Printing User Security Roles.
            if (item.name == "System Administrator" || item.name == "System Customizer" || item.name == "NIQ Business Admin") {
                formContext.getControl("niq_user").setDisabled(false);
                return;
            }
        });
    }
}
