if (typeof (QuoteProductCharteristicsEditableGrid) === "undefined") {
    QuoteProductCharteristicsEditableGrid = {
        __namespace: true
    };
}
QuoteProductCharteristicsEditableGrid.Events = {
    OnSelect: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        try {
            this.SetDisableGridColumn(formContext.getAttribute("niq_quoteproductid"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_materialcharacteristicid"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_mandatory"), true);
            if (formContext.getAttribute("niq_mandatory").getValue() === true)
                formContext.getAttribute("niq_materialcharacteristicvalueid").setRequiredLevel("required");
            else
                formContext.getAttribute("niq_materialcharacteristicvalueid").setRequiredLevel("none");
        }
        catch (ex) {
            Xrm.Navigation.openErrorDialog({ message: "Error occurd in QuoteProductCharteristicsEditableGrid.Events.OnSelect method.", details: ex });
        }
    },
    SetDisableGridColumn: function (attrCtrl, isDisable) {
        "use strict";
        try {
            attrCtrl.controls.forEach(function (control) {
                control.setDisabled(isDisable);
            });
        }
        catch (ex) {
            Xrm.Navigation.openErrorDialog({ message: "Error occurd in QuoteProductCharteristicsEditableGrid.Events.SetDisableGridColumn method.", details: ex });
        }
    }
};