if (typeof (DeliveryForm) === "undefined") {
    DeliveryForm = {
        __namespace: true
    };
}
DeliveryForm.Events = {
    formOnLoadFields: function (executionContext) {
        this.CustomViewForQuoteLineItem(executionContext);   
      
     
        
        var formContext = executionContext.getFormContext();
              
        var formType = formContext.ui.getFormType();
        // if (formType === 1) {
        //    formContext.data.entity.addOnSave(OnSaveChangeCurrencyAndOwner);
        // }
    
       
    },
   
/**
* Locking Delivery status field for non-admin users
* 
* @param {any} executionContext - The execution context provided by Dynamics 365 CRM Form
*/  

LockDeliveryStatusField: function (executionContext) {
    "use strict";

    var formContext = executionContext.getFormContext();

    var isUserAdmin = CommonForm?.Events?.CheckIfLoggedInUserRoles?.("NIQ Business Admin,System Administrator,System Customizer");

    var fieldExists = CommonForm?.Events?.CheckFieldExists?.(formContext, "niq_deliverystatus");

    if (isUserAdmin && fieldExists) {
       
        formContext.getControl("niq_deliverystatus")?.setDisabled(false);
    } else {
        formContext.getControl("niq_deliverystatus")?.setDisabled(true);
    }

    var statecode = formContext.getAttribute("statecode")?.getValue();
    if (statecode === 1) {
        CommonForm?.Events?.disableFormFields?.(true, formContext);
    }
},


  OnFormSaveAutopopulateFieldValue: function (executionContext) {
        var formContext = executionContext.getFormContext();
		/*if (CommonForm.Events.CheckFieldExists(formContext, "niq_dateofdelivery") && CommonForm.Events.CheckFieldExists(formContext, "niq_proposeddeliverydate"))
		{
			var forcastedDate = formContext.getAttribute("niq_proposeddeliverydate").getValue();
			if (forcastedDate !== null)
			{
				formContext.getAttribute("niq_dateofdelivery").setValue(forcastedDate);
			}
		}*/
        // this.OnSaveChangeCurrencyAndOwner(executionContext);
    },
    OnSaveChangeCurrencyAndOwner: function (executionContext) {
        'use strict';
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_opportunityid") && CommonForm.Events.CheckValueExists(formContext, "niq_opportunityid") &&
            CommonForm.Events.CheckFieldExists(formContext, "ownerid") && CommonForm.Events.CheckFieldExists(formContext, "transactioncurrencyid") &&
            formContext.ui.quickForms.get("OpportunityQuickView") !== undefined && formContext.ui.quickForms.get("OpportunityQuickView") !== null) {
            if (formContext.ui.quickForms.get("OpportunityQuickView").getControl("ownerid") !== undefined && formContext.ui.quickForms.get("OpportunityQuickView").getControl("ownerid") !== null &&
                formContext.getAttribute("ownerid").getValue() !== formContext.ui.quickForms.get("OpportunityQuickView").getControl("ownerid").getAttribute().getValue())
                formContext.getAttribute("ownerid").setValue(formContext.ui.quickForms.get("OpportunityQuickView").getControl("ownerid").getAttribute().getValue());
            if (formContext.ui.quickForms.get("OpportunityQuickView").getControl("transactioncurrencyid") !== undefined && formContext.ui.quickForms.get("OpportunityQuickView").getControl("transactioncurrencyid") !== null &&
                formContext.getAttribute("transactioncurrencyid").getValue() !== formContext.ui.quickForms.get("OpportunityQuickView").getControl("transactioncurrencyid").getAttribute().getValue())
                formContext.getAttribute("transactioncurrencyid").setValue(formContext.ui.quickForms.get("OpportunityQuickView").getControl("transactioncurrencyid").getAttribute().getValue());
        }
    },
    PreventAutosave: function (executionContext) {
        "use strict";
        var eventArgs = executionContext.getEventArgs();
        if (eventArgs.getSaveMode() == 70 || eventArgs.getSaveMode() == 2) {
            eventArgs.preventDefault();
        }
    },
    CustomViewForQuoteLineItem: function (executionContext) {
        'use strict';
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_opportunityid") && CommonForm.Events.CheckValueExists(formContext, "niq_opportunityid")) {
            var opportunityid = formContext.getAttribute("niq_opportunityid").getValue()[0].id;
            //var viewId = "{00000000-0000-0000-0000-000100000001}";
            var viewId = formContext.getControl("niq_relatedquotelineitemid").getDefaultView();
            var entity = "quotedetail";
            var ViewDisplayName = "Related Quote Products";
            var norecords = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                "<entity name='quotedetail'>" +
                "<attribute name='productdescription' />" +
                "<attribute name='priceperunit' />" +
                "<attribute name='quantity' />" +
                "<attribute name='extendedamount' />" +
                "<attribute name='niq_lineitemstartdate' />" +
                "<attribute name='niq_lineitemenddate' />" +
                "<attribute name='niq_subbrandid' />" +
                "<attribute name='niq_brandid' />" +
                "<attribute name='quotedetailname' />" +
                "<attribute name='quotedetailid' />" +
                "<attribute name='niq_remark' />" +
                "<attribute name='productname' />" +
                "<order attribute='niq_brandid' descending='false' />" +
                "<link-entity name='quote' from='quoteid' to='quoteid' link-type='inner' alias='ae'>" +
                "<link-entity name='opportunity' from='niq_mainquoteid' to='quoteid' link-type='inner' alias='af'>" +
                "<filter type='and'>" +
                "<condition attribute='opportunityid' operator='eq' uitype='opportunity' value='7' />" +
                "</filter>" +
                "</link-entity>" +
                "</link-entity>" +
                "</entity>" +
                "</fetch>";
            var layout = "<grid name='resultset' object='2' jump='quotedetailname' select='1' icon='1' preview='1'>" +
                "<row name='result' id='quotedetailid'>" +
                "<cell name='productname' width='100'/>" +
                "<cell name='extendedamount' width='100'/>" +
                "<cell name='niq_remark' width='300'/>" +
                "</row>" +
                "</grid>";
            var fetchXML = "";
            Xrm.WebApi.online.retrieveRecord("opportunity", opportunityid, "?$select=_niq_mainquoteid_value").then(

                function success(result) {
                    var mainquoteId = result["_niq_mainquoteid_value"];
                    if (mainquoteId !== null) {
                        fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                            "<entity name='quotedetail'>" +
                            "<attribute name='productdescription' />" +
                            "<attribute name='priceperunit' />" +
                            "<attribute name='quantity' />" +
                            "<attribute name='extendedamount' />" +
                            "<attribute name='niq_lineitemstartdate' />" +
                            "<attribute name='niq_lineitemenddate' />" +
                            "<attribute name='niq_subbrandid' />" +
                            "<attribute name='niq_brandid' />" +
                            "<attribute name='quotedetailname' />" +
                            "<attribute name='quotedetailid' />" +
                            "<attribute name='niq_remark' />" +
                            "<attribute name='productname' />" +
                            "<order attribute='niq_brandid' descending='false' />" +
                            "<link-entity name='quote' from='quoteid' to='quoteid' link-type='inner' alias='ae'>" +
                            "<link-entity name='opportunity' from='niq_mainquoteid' to='quoteid' link-type='inner' alias='af'>" +
                            "<filter type='and'>" +
                            "<condition attribute='opportunityid' operator='eq' uitype='opportunity' value='" + opportunityid + "' />" +
                            "</filter>" +
                            "</link-entity>" +
                            "</link-entity>" +
                            "</entity>" +
                            "</fetch>";
                    }
                    else {
                        norecords = fetchXML
                    }

                    formContext.getControl("niq_relatedquotelineitemid").addCustomView(viewId, entity, ViewDisplayName, fetchXML, layout, false);
                },

                function (error) {
                    Xrm.Utility.alertDialog(error.message);
                });
        }
    },
    MakeEODDocumentationURLRequired: function (executionContext) {
        'use strict';
        var formContext = executionContext.getFormContext();
        var deliveryStatus = formContext.getAttribute("niq_deliverystatus").getValue();
        var Opportunity = formContext.getAttribute("niq_opportunityid").getValue();
        if (Opportunity != null && Opportunity != undefined) {
            var opportunityId = formContext.getAttribute("niq_opportunityid").getValue()[0].id;
            var deliverToClient = false;
            var SalesOrg = true;
            if (deliveryStatus == 100000002) {
                deliverToClient = true;
                var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'><entity name='opportunity'><attribute name='name' /><attribute name='opportunityid' /><filter type='and'><condition attribute='niq_salesorgid' operator='eq' uitype='niq_salesorg' value='{27DC1570-7179-4286-AEB6-689FD1371DEB}' /><condition attribute='opportunityid' operator='eq'  uitype='opportunity' value='" + opportunityId + "' /></filter></entity></fetch>";
                var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
                var result = GetCRMWebAPI.Methods.GetFetchRecords(clienturl, fetchXml, "opportunities");
                if (result != null && result.value.length > 0) {
                    SalesOrg = false;
                }

            }
            if (deliverToClient == true && SalesOrg == true) {
                formContext.getAttribute("niq_eoddocumentationurl").setRequiredLevel("required");
            }
            else {
                formContext.getAttribute("niq_eoddocumentationurl").setRequiredLevel("none");
            }
        }

    },
     deliveryStatusNotification: function (executionContext) {
        var formContext = executionContext.getFormContext();
        
	formContext.ui.setFormNotification("By uploading an Evidence of Delivery (EOD) file to this Delivery you certify that this Evidence of Delivery is true, accurate & reflects the delivery requirements per the contractual terms and conditions. Falsification of evidence of delivery is subject to disciplinary action per NIQ's Code of Conduct.", "INFO", "deliverystatusnotify");
    },

    CheckDeliveryStatus: function (executionContext) {
        //niq_deliverystatus
        var formContext = executionContext.getFormContext();
var pickListDeliveryStatus = formContext.getControl("niq_deliverystatus");
//pickListDeliveryStatus.removeOption(NaN);
        if (formContext.getAttribute("niq_deliverystatus") != null && formContext.getAttribute("niq_deliverystatus").getValue() != null) {
            var deliverystatus = formContext .getAttribute("niq_deliverystatus").getValue();
            //var pickListDeliveryStatus = formContext.getControl("niq_deliverystatus");
            //100000001, 100000000, 100000002 - Inprocess, Not started, Delivered to Client
            if (deliverystatus == 100000002) {
                //Remove 100000003, 100000004, 100000005, 100000006 - EOD pending approval,  EOD Recalled, EOD Rejected, EOD Approved
                pickListDeliveryStatus.removeOption(100000003);
                pickListDeliveryStatus.removeOption(100000004);
                pickListDeliveryStatus.removeOption(100000005);
                pickListDeliveryStatus.removeOption(100000006);
            }
            else if (deliverystatus == 100000000 || deliverystatus == 100000001) {
                //Remove 100000003, 100000004, 100000005, 100000006 - EOD pending approval,  EOD Recalled, EOD Rejected, EOD Approved
                pickListDeliveryStatus.removeOption(100000002);
                pickListDeliveryStatus.removeOption(100000003);
                pickListDeliveryStatus.removeOption(100000004);
                pickListDeliveryStatus.removeOption(100000005);
                pickListDeliveryStatus.removeOption(100000006);
            }
            else {
                formContext.getControl("niq_deliverystatus").setDisabled(true);
                pickListDeliveryStatus.removeOption(100000002);
            }
        }

    },


//Make a Form Readyonly when delivery status=EOD pending approval.
 MakeFormReadonly: function (executionContext){
        'use strict';
        var formContext = executionContext.getFormContext();       
       var deliverystatus = formContext.getAttribute("niq_deliverystatus").getValue();
if(formContext.ui.getFormType() != 4){
    if (deliverystatus == 100000003){
     CommonForm.Events.disableFormFields(true, formContext);
    }
else{
  //formContext.getControl("niq_deliveryamount").setDisabled(false);
  //formContext.getControl("niq_proposeddeliverydate").setDisabled(false);
  //formContext.getControl("niq_deliverystatus").setDisabled(false);
  //formContext.getControl("niq_startofwork").setDisabled(false);
  //formContext.getControl("niq_eoddocumentationurl").setDisabled(false);
}
}
}
}