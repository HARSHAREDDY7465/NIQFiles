if (typeof (FARRibbon) === "undefined") {
    FARRibbon = {
        __namespace: true
    };
}
FARRibbon.Events = {
    OnClickNewSAPChangeRequest: function (executionContext) {
        "use strict";        
        var formContext = executionContext;
      
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_financeapprovalrequests";

        // Set default values for the FAR form
        var formParameters = {};
        formParameters["niq_approvaltype"] = 100000001; // NEW SAP Account Change Request        
        if (formContext.getAttribute("niq_salesorgid") !== null && formContext.getAttribute("niq_salesorgid").getValue() !== null) {
            var salesOrg = formContext.getAttribute("niq_salesorgid").getValue();
            formParameters["niq_salesorg"] = salesOrg;
        }
        if (formContext.getAttribute("parentaccountid") !== null && formContext.getAttribute("parentaccountid").getValue() !== null) {
            var relAccount = formContext.getAttribute("parentaccountid").getValue();
            formParameters["niq_relatedaccount"] = relAccount;
        }
        var lookupValue = new Array();
        lookupValue[0] = new Object();
        lookupValue[0].id = formContext.data.entity.getId(); // GUID of the lookup id
        lookupValue[0].name = formContext.getAttribute("name").getValue(); // Name of the lookup
        lookupValue[0].entityType = "opportunity"; //Entity Type of the lookup entity
        formParameters["niq_relatedopportunity"] = lookupValue;


        // Open the form.
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
              
            },
            function (error) {
               
            });
    },
    OnClickNewSAPRequest: function (executionContext) {
        var formContext = executionContext;
        
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_financeapprovalrequests";

        // Set default values for the FAR form
        var formParameters = {};
        formParameters["niq_approvaltype"] = 100000002; // NEW SAP Account Request
        if (formContext.getAttribute("niq_salesorgid") !== null && formContext.getAttribute("niq_salesorgid").getValue() !== null) {
            var salesOrg = formContext.getAttribute("niq_salesorgid").getValue();
            formParameters["niq_salesorg"] = salesOrg;
        }
        var lookupValue = new Array();
        lookupValue[0] = new Object();
        lookupValue[0].id = formContext.data.entity.getId(); // GUID of the lookup id
        lookupValue[0].name = formContext.getAttribute("name").getValue(); // Name of the lookup
        lookupValue[0].entityType = "opportunity"; //Entity Type of the lookup entity
        formParameters["niq_relatedopportunity"] = lookupValue;


        // Open the form.
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
               
            },
            function (error) {
               
            });
    },
    RetriggerSAPIntegrationVisibility: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        //On Click function for Retrigger SAP Integration button
        var adminFlag = false;
        var farFlag = false;
        var farid = formContext.data.entity.getId().replace("{", "").replace("}", "");
        var fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
            "<entity name='niq_financeapprovalrequests'>" +
            "<attribute name='niq_financeapprovalrequests' />" +
            "<attribute name='createdon' />" +
            "<attribute name='modifiedby' />" +
            "<attribute name='niq_financeapprovalrequestsid' />" +
            "<order attribute='niq_financeapprovalrequests' descending='false' />" +
            "<filter type='and'>" +
            "<condition attribute='niq_approvalstatus' operator='eq' value='100000002' />" +
            "<condition attribute='niq_approvaltype' operator='eq' value='100000000' />" +
            "<condition attribute='niq_financeapprovalrequestsid' operator='eq' value='" + farid + "' />" +
            "<condition attribute='niq_sapintegrationdecision' operator='eq' value='3' />" +
            "</filter>" +
            "<link-entity name='opportunity' from='opportunityid' to='niq_relatedopportunity' link-type='inner' alias='ag'>" +
            "<filter type='and'>" +
            "<condition attribute='niq_approvalstatus' operator='eq' value='100000002' />" +
            "<condition attribute='niq_sapintegrationstatus' operator='eq' value='100000001' />" +
            "</filter>" +
            "<link-entity name='niq_bpf_opportunity' from='bpf_opportunityid' to='opportunityid' link-type='inner' alias='ah'>" +
            "<link-entity name='processstage' from='processstageid' to='activestageid' link-type='inner' alias='ai'>" +
            "<filter type='and'>" +
            "<condition attribute='stagename' operator='eq' value='Closed Won - In Review' />" +
            "</filter>" +
            "</link-entity>" +
            "</link-entity>" +
            "</link-entity>" +
            "</entity>" +
            "</fetch>";
        var fetchResults = GetCRMWebAPI.Methods.GetFetchRecords(Xrm.Utility.getGlobalContext().getClientUrl(), fetchXML, "niq_financeapprovalrequestses");
        if (fetchResults !== null && fetchResults.value.length > 0) {
            farFlag = true;
        }
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer")) {
            adminFlag = true;
        }
        if (farFlag === true && adminFlag === true) {
            return true;
        }
        else {
            return false;
        }
    },
    OnClickRetriggerSAPIntegration: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        //On Click function for Retrigger SAP Integration button
        var confirmStrings = { text: "Are you sure you want to retrigger SAP Integration?", cancelButtonLabel: "No", confirmButtonLabel: "Yes" };
        var confirmOptions = { height: 200, width: 450 };
        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    if (CommonForm.Events.CheckFieldExists(formContext, "niq_sapintegrationdecision")) {
                        formContext.getAttribute("niq_sapintegrationdecision").setValue(2);
                        formContext.data.entity.save();
                    }
                }
            });
    }
}