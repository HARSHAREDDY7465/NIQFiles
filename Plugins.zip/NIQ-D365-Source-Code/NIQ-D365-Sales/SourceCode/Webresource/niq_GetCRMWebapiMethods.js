if (typeof (GetCRMWebAPI) === "undefined") { GetCRMWebAPI = { __namespace: true }; }
// Namespace container for functions in this library.
GetCRMWebAPI.Methods = {
    //synchronous method to fetch record from the application
    GetFetchRecords: function (clientURL, fetchXmlQuery, ename) {
        "use strict";
        var req = new XMLHttpRequest();
        var resultVal = null;
        req.open(
            "GET",
            clientURL +
            "/api/data/v9.0/" + ename + "?fetchXml=" +
            encodeURIComponent(fetchXmlQuery),
            false
        );
        req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    resultVal = results;
                } else {
                    resultVal = null;
                }
            }
        };
        req.send();
        return resultVal;
    }
}
