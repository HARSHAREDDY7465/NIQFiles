if (typeof (DeliveryRibbon) === "undefined") {
    DeliveryRibbon = {
        _namespace: true
    };
}

DeliveryRibbon.Events = {
    NewActivateDeactivateButtonVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User,NIQ Business Admin,System Administrator,System Customizer")) {
            return true;
        }
        else {
            return false;
        }
    }
}
