if (typeof (AccountPlanRibbon) === "undefined") {
    AccountPlanRibbon = {
        __namespace: true
    };
}
AccountPlanRibbon.Events = {

    RefreshRibbon: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        formContext.ui.refreshRibbon();
    },

    OnCLickofCloneButton: function (executionContext) {
        var formContext = executionContext;

        var confirmStrings = { text: "Are you sure you want to clone? Once proceeded, a new Account Plan will be created by cloning this one.", title: "Confirmation Dialog" };
        var confirmOptions = { height: 200, width: 450 };
        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    var entity = {};
                    if (CommonForm.Events.CheckValueExists(formContext, "ownerid")) {
                        var ownerid = formContext.getAttribute("ownerid").getValue()[0].id.replace("{", "").replace("}", "");
                        entity["ownerid@odata.bind"] = "/systemusers(" + ownerid + ")";
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "ownerid")) {
                        var accountname = formContext.getAttribute("niq_accountname").getValue()[0].id.replace("{", "").replace("}", "");
                        entity["niq_AccountName@odata.bind"] = "/accounts(" + accountname + ")";
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_clientengagement")) {
                        var clientEngagement = formContext.getAttribute("niq_clientengagement").getValue();
                        entity.niq_clientengagement = clientEngagement;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_clientorgchange")) {
                        var clientOrgchange = formContext.getAttribute("niq_clientorgchange").getValue();
                        entity.niq_clientorgchange = clientOrgchange;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_competitivepenetration")) {
                        var competitivePenetration = formContext.getAttribute("niq_competitivepenetration").getValue();
                        entity.niq_competitivepenetration = competitivePenetration;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_contractterms")) {
                        var contractTerms = formContext.getAttribute("niq_contractterms").getValue();
                        entity.niq_contractterms = contractTerms;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_highlevelstrategicpriorities")) {
                        var niq_highlevelstrategicpriorities = formContext.getAttribute("niq_highlevelstrategicpriorities").getValue();
                        entity.niq_highlevelstrategicpriorities = niq_highlevelstrategicpriorities;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_keyfinancialperformancehighlights")) {
                        var niq_keyfinancialperformancehighlights = formContext.getAttribute("niq_keyfinancialperformancehighlights").getValue();
                        entity.niq_keyfinancialperformancehighlights = niq_keyfinancialperformancehighlights;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_keyopportunitiestopursue")) {
                        var niq_keyopportunitiestopursue = formContext.getAttribute("niq_keyopportunitiestopursue").getValue();
                        entity.niq_keyopportunitiestopursue = niq_keyopportunitiestopursue;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_keyrfphighlights")) {
                        var niq_keyrfphighlights = formContext.getAttribute("niq_keyrfphighlights").getValue();
                        entity.niq_keyrfphighlights = niq_keyrfphighlights;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_keywinslosses")) {
                        var niq_keywinslosses = formContext.getAttribute("niq_keywinslosses").getValue();
                        entity.niq_keywinslosses = niq_keywinslosses;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_marketplaceperformance")) {
                        var niq_marketplaceperformance = formContext.getAttribute("niq_marketplaceperformance").getValue();
                        entity.niq_marketplaceperformance = niq_marketplaceperformance;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_name")) {
                        var niq_name = formContext.getAttribute("niq_name").getValue();
                        entity.niq_name = niq_name;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_needsasks")) {
                        var niq_needsasks = formContext.getAttribute("niq_needsasks").getValue();
                        entity.niq_needsasks = niq_needsasks;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_npsscorekeycustomerfeedbackhighlights")) {
                        var niq_npsscorekeycustomerfeedbackhighlights = formContext.getAttribute("niq_npsscorekeycustomerfeedbackhighlights").getValue();
                        entity.niq_npsscorekeycustomerfeedbackhighlights = niq_npsscorekeycustomerfeedbackhighlights;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_ourofferingcomparetoacompetitiveoffer")) {
                        var niq_ourofferingcomparetoacompetitiveoffer = formContext.getAttribute("niq_ourofferingcomparetoacompetitiveoffer").getValue();
                        entity.niq_ourofferingcomparetoacompetitiveoffer = niq_ourofferingcomparetoacompetitiveoffer;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_partnershipmodel")) {
                        var niq_partnershipmodel = formContext.getAttribute("niq_partnershipmodel").getValue();
                        entity.niq_partnershipmodel = niq_partnershipmodel;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_qualityissues")) {
                        var niq_qualityissues = formContext.getAttribute("niq_qualityissues").getValue();
                        entity.niq_qualityissues = niq_qualityissues;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_recentsuccessfullaunches")) {
                        var niq_recentsuccessfullaunches = formContext.getAttribute("niq_recentsuccessfullaunches").getValue();
                        entity.niq_recentsuccessfullaunches = niq_recentsuccessfullaunches;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_strategicimportanceofthisclientwinloss")) {
                        var niq_strategicimportanceofthisclientwinloss = formContext.getAttribute("niq_strategicimportanceofthisclientwinloss").getValue();
                        entity.niq_strategicimportanceofthisclientwinloss = niq_strategicimportanceofthisclientwinloss;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_totakeovertheclientwhattodotoneutralize")) {
                        var niq_totakeovertheclientwhattodotoneutralize = formContext.getAttribute("niq_totakeovertheclientwhattodotoneutralize").getValue();
                        entity.niq_totakeovertheclientwhattodotoneutralize = niq_totakeovertheclientwhattodotoneutralize;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_totalspendofcurrentversusnewproposal")) {
                        var niq_totalspendofcurrentversusnewproposal = formContext.getAttribute("niq_totalspendofcurrentversusnewproposal").getValue();
                        entity.niq_totalspendofcurrentversusnewproposal = niq_totalspendofcurrentversusnewproposal;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_whatcriteriawillourclientusetochoose")) {
                        var niq_whatcriteriawillourclientusetochoose = formContext.getAttribute("niq_whatcriteriawillourclientusetochoose").getValue();
                        entity.niq_whatcriteriawillourclientusetochoose = niq_whatcriteriawillourclientusetochoose;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_wheredoesnielseniqstandagainsteachcriteri")) {
                        var niq_wheredoesnielseniqstandagainsteachcriteri = formContext.getAttribute("niq_wheredoesnielseniqstandagainsteachcriteri").getValue();
                        entity.niq_wheredoesnielseniqstandagainsteachcriteri = niq_wheredoesnielseniqstandagainsteachcriteri;
                    }
                    if (CommonForm.Events.CheckValueExists(formContext, "niq_whetherwearegoingagainstcompetitiveoffers")) {
                        var niq_whetherwearegoingagainstcompetitiveoffers = formContext.getAttribute("niq_whetherwearegoingagainstcompetitiveoffers").getValue();
                        entity.niq_whetherwearegoingagainstcompetitiveoffers = niq_whetherwearegoingagainstcompetitiveoffers;
                    }

                    Xrm.WebApi.online.createRecord("niq_accountplan", entity).then(
                        function success(result) {
                            var newEntityId = result.id;
                            var entityFormOptions = {};
                            entityFormOptions["entityName"] = "niq_accountplan";
                            entityFormOptions["entityId"] = newEntityId;

                            // Open the form.
                            Xrm.Navigation.openForm(entityFormOptions).then(
                                function (success) {

                                },
                                function (error) {

                                });

                        },
                        function (error) {
                            Xrm.Utility.alertDialog(error.message);
                        }
                    );
                }

            });
    }
}

var AccountPlanRibbonShow = (function () {

    //this variable stores if async operation was already completed
    var isAsyncOperationCompleted = false;
    //this variable stores the result - if button enabled or not
    var isButtonEnabled = false;

    function IsButtonEnabled(formContext) {
        //If async operation was already completed I just return the result of it
        if (isAsyncOperationCompleted) {
            return isButtonEnabled;
        }


        //var formContext = executionContext;
        var currentUser = Xrm.Utility.getGlobalContext().userSettings.userId.replace('{', '').replace('}', '');
        if (CommonForm.Events.CheckValueExists(formContext, "niq_accountname")) {
            var accountRecord = formContext.getAttribute("niq_accountname").getValue();
            var accountRecordId = accountRecord[0].id.replace('{', '').replace('}', '');


            Xrm.WebApi.online.retrieveRecord("account", accountRecordId, "?$select=_ownerid_value").then(
                function success(result) {
                    isAsyncOperationCompleted = true;
                    var ownerId = result["_ownerid_value"];
                    if ((ownerId.toLowerCase() === currentUser.toLowerCase()) && (formContext.ui.getFormType() !== 1)) {

                        isButtonEnabled = true;
                        if (isButtonEnabled) {
                            formContext.ui.refreshRibbon();
                        }
                    }

                },
                function (error) {
                    isAsyncOperationCompleted = true;
                    Xrm.Utility.alertDialog(error.message);
                }
            );


        }
        //Just a stub that hides button by default

        return false;
    }

    return {
        IsButtonEnabled: IsButtonEnabled
    };
})();

