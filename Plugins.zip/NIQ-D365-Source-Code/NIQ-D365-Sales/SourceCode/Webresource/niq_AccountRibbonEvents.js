if (typeof (AccountRibbon) === "undefined") {
    AccountRibbon = {
        __namespace: true
    };
}
var serviceReqCreateRolesWithKnowledgeRoles = "System Administrator,NIQ Global Helpline Agent,NIQ Global Helpline Manager,NIQ Ops Solution Provider,NIQ Analytics Agent,NIQ Analytics Manager,NIQ Ops Submitter,"
    + "NIQ Knowledge Contributor,NIQ Knowledge Publisher,NIQ Delegate Agent,NIQ Delegate Manager,NIQ Delegate Submitter,NIQ Client Response Agent,NIQ Client Response Manager";
var secondaryContactVisibilityRoles = "System Administrator , NIQ Analytics Manager, NIQ Client Response Manager , NIQ Analytics Agent , NIQ Client Response Agent";
AccountRibbon.Events = {
    OnClickNewApprovalRequest: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var AccountId = formContext.data.entity.getId();
        var AccountName = formContext.getAttribute("name").getValue();
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_financeapprovalrequests";
        var formParameters = {};
        formParameters["niq_approvaltype"] = "100000002";
        formParameters["niq_relatedaccount"] = AccountId;
        formParameters["niq_relatedaccountname"] = AccountName;
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );
    },
    AccountPlanVisibility: function (executionContext) {
        var formContext = executionContext;
        var CurrentUser = Xrm.Utility.getGlobalContext().userSettings.userName;
        var AccountOwner = formContext.getAttribute("ownerid").getValue();
        if (AccountOwner !== null) {
            var OwnerName = AccountOwner[0].name;
            if (OwnerName === CurrentUser) {
                return true;
            }
            else {
                return false;
            }
        }
    },
    AcivateButtonVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckValueExists(formContext, "niq_accounttype")) {
            var accounttype = formContext.getAttribute("niq_accounttype").getValue();

            if (accounttype === 2) {
                return false;
            }
            else {
                return true;
            }
        }

    },
    OnClickOpenNewAccountPlan: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var lookupValue = new Array();
        lookupValue[0] = new Object();
        lookupValue[0].id = formContext.data.entity.getId(); // GUID of the lookup id
        lookupValue[0].name = formContext.getAttribute("name").getValue(); // Name of the lookup
        lookupValue[0].entityType = "account"; //Entity Type of the lookup entity        
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_accountplan";
        var formParameters = {};
        formParameters["niq_accountname"] = lookupValue;
        formParameters["niq_name"] = formContext.getAttribute("name").getValue();
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );
    },
    OnClickOfNewSAPChangeRequest: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var accountData = new Array();
        accountData[0] = new Object();
        accountData[0].id = formContext.data.entity.getId();
        accountData[0].name = formContext.getAttribute("name").getValue();
        accountData[0].entityType = "account";
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_financeapprovalrequests";
        var formParameters = {};
        formParameters["niq_approvaltype"] = "100000001";
        formParameters["niq_relatedaccount"] = accountData;
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );
    },
    OnClickOfNewSAPAccountRequest: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var accountData = new Array();
        accountData[0] = new Object();
        accountData[0].id = formContext.data.entity.getId();
        accountData[0].name = formContext.getAttribute("name").getValue();
        accountData[0].entityType = "account";
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_sapaccountrequest";
        entityFormOptions["useQuickCreateForm"] = true;
        var formParameters = {};

        formParameters["niq_customeraccountid"] = accountData;
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) { },
            function (error) { }
        );
    },
    NewSAPAccountRequestButtonVisibility: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User,System Administrator,System Customizer")) {
            return true;
        } else {
            return false;
        }
    },
    ShowHideCopyLinkBtn: function (primaryctrl) {
        "use strict";

        if (primaryctrl.ui.getFormType() !== 1 && CommonForm.Events.CheckIfLoggedInUserRoles(serviceReqCreateRolesWithKnowledgeRoles)) {
            return true;
        }
        else {
            return false;
        }
    },
    copyRecordUrl: function (primaryCtrl) {
        var url = primaryCtrl.getUrl();
        var tempTag = document.createElement('textarea');
        tempTag.value = url;
        tempTag.setAttribute('readonly', '');
        tempTag.style = {
            position: 'absolute',
            left: '-9999px'
        };
        document.body.appendChild(tempTag);
        tempTag.select();
        document.execCommand('copy');
        document.body.removeChild(tempTag);
        //Xrm.Utility.alertDialog("Link copied to clipboard");
        if (url !== null || url !== undefined) {
            alert("Link copied to clipboard");
        }
    },
    SecondaryAccountVisibilty: function (primaryctrl) {
        "use strict";
        debugger;
        var entityType = Xrm.Page.getControl("SecondaryAccountsGrid").getGrid().getTotalRecordCount();  //Entity which you want to hide the button of subgrid
        if (entityType == null || entityType <= 0 || entityType >= 0) {
            if (CommonForm.Events.CheckIfLoggedInUserRoles(secondaryContactVisibilityRoles)) {
                return true;
            }
            else {
                return false;
            }
        }
    },
    NewAccountAndExistingButtonVisibility: function (executionContext) {
        'use strict';

        var formContext = executionContext;

        if (CommonForm.Events.CheckValueExists(formContext, "niq_accounttype")) {
            var accounttype = formContext.getAttribute("niq_accounttype").getValue();
            if (accounttype === 2) {
                return false;
            }
            else {
                return true;
            }
        }
    }

}