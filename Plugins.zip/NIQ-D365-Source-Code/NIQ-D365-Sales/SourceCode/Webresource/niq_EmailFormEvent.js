function setSubjectForRequestEntity(executionContext) {
    var formContext = executionContext.getFormContext();
    var regarding = formContext.getAttribute("regardingobjectid").getValue();
    if (formContext.ui.getFormType() === 1 && regarding !== null && regarding.length === 1) {
        if (regarding[0].entityType === 'incident') {
            var req = new XMLHttpRequest();
            req.open("GET", formContext.context.getClientUrl() + "/api/data/v9.1/incidents(" + regarding[0].id.substring(1, 37) + ")?$select=ticketnumber,title", true);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var result = JSON.parse(this.response);

                        var ticketnumber = result["ticketnumber"];

                        var subject = result["title"];

                        //formContext.getAttribute("subject").setValue(ticketnumber);
                        //formContext.getAttribute("subject").setValue(title);
                        formContext.getAttribute("subject").setValue(ticketnumber + "-" + subject)

                    } else {
                        Xrm.Utility.alertDialog(this.statusText);
                    }
                }
            };
            req.send();
        }

    }
}



function emailStatusNotification(executionContext) {

    var formContext = executionContext.getFormContext();
    var deliveryEmail = formContext.getAttribute("cr2d3_deliveryemail").getValue();
    if (deliveryEmail == true) {
        formContext.ui.setFormNotification("Certifying that this email represents evidence of delivery means it is true, accurate and reflects the delivery requirements per the contractual terms and conditions. Falsification of evidence of delivery is subject to disciplinary action per NIQ's Code of Conduct.", "INFO", "emailstatusnotify");
    } else {
        formContext.ui.clearFormNotification("emailstatusnotify");
    }
}

//DYNCRM-1963: <start line> setting Contact(eodepr01@nha.nielseniq.com) on Bcc if Regarding entitytype=project and status reason=Draft
function setContactOnBcc(executionContext) {

    var formContext = executionContext.getFormContext();
    var regarding = formContext.getAttribute("regardingobjectid").getValue();
    var emailStatus = formContext.getAttribute("statuscode").getValue();

    if (regarding !== null && regarding[0].entityType === 'msdyn_project' && emailStatus === 1) {
        Xrm.WebApi.retrieveMultipleRecords("contact", "?$select=contactid,fullname,emailaddress1 &$filter=emailaddress1 eq 'eodepr01@nha.nielseniq.com'").then(
            function success(result) {
                if (result.entities.length) {
                    //setting contact record On Bcc
                    var contactRecord = new Array();
                    contactRecord[0] = new Object();
                    contactRecord[0].id = result.entities[0]["contactid"];
                    contactRecord[0].name = result.entities[0]["fullname"];
                    contactRecord[0].entityType = "contact";
                    formContext.getAttribute("bcc").setValue(contactRecord);
                }
            },
            function (error) {
                console.log(error.message);
            }
        );

    }
}
//DYNCRM-1963: <end line>