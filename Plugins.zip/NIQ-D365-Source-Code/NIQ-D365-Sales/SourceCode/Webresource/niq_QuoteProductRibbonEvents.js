if (typeof (QuoteProductRibbon) === "undefined") {
    QuoteProductRibbon = {
        __namespace: true
    };
}
QuoteProductRibbon.Events = {
    DeleteButtonVisibilityOnQuoteProduct: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer")) {
            return true;
        } else {
            return false;
        }
    }
}