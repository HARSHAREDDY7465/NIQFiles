if (typeof (ContactRibbon) === "undefined") {
	ContactRibbon = {
		__namespace: true
	};
}
var serviceReqCreateRolesWithKnowledgeRoles = "System Administrator,NIQ Global Helpline Agent,NIQ Global Helpline Manager,NIQ Ops Solution Provider,NIQ Analytics Agent,NIQ Analytics Manager,NIQ Ops Submitter,"
	+ "NIQ Knowledge Contributor,NIQ Knowledge Publisher,NIQ Delegate Agent,NIQ Delegate Manager,NIQ Delegate Submitter,NIQ Client Response Agent,NIQ Client Response Manager";
ContactRibbon.Events = {
	ShowHideCopyLinkBtn: function (primaryctrl) {
		"use strict";

		if (primaryctrl.ui.getFormType() !== 1 && CommonForm.Events.CheckIfLoggedInUserRoles(serviceReqCreateRolesWithKnowledgeRoles)) {
			return true;
		}
		else {
			return false;
		}
	},
	copyRecordUrl: function (primaryCtrl) {
		var url = primaryCtrl.getUrl();
		var tempTag = document.createElement('textarea');
		tempTag.value = url;
		tempTag.setAttribute('readonly', '');
		tempTag.style = {
			position: 'absolute',
			left: '-9999px'
		};
		document.body.appendChild(tempTag);
		tempTag.select();
		document.execCommand('copy');
		document.body.removeChild(tempTag);
		//Xrm.Utility.alertDialog("Link copied to clipboard");
		if (url !== null || url !== undefined) {
			alert("Link copied to clipboard");
		}
	},
	checkExternalIdentitiesByContact: function (primaryCtrl) {
		debugger;
		var isExternalIdentitiesExists = false;
		formContext = primaryCtrl;
		var contactId = formContext.data.entity.getId();
		if (contactId != null) {
			var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
				"<entity name='adx_externalidentity'>" +
				"<attribute name='adx_username' />" +
				"<attribute name='createdon' />" +
				"<attribute name='adx_identityprovidername' />" +
				"<attribute name='adx_contactid' />" +
				"<attribute name='adx_externalidentityid' />" +
				"<order attribute='adx_identityprovidername' descending='false' />" +
				"<filter type='and'>" +
				"<condition attribute='adx_contactid' operator='eq' uitype='contact' value='" + contactId + "' />" +
				"</filter>" +
				"</entity>" +
				"</fetch>";
			var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
			var result = GetCRMWebAPI.Methods.GetFetchRecords(clienturl, fetchXml, "adx_externalidentities");
			if (result != null && result.value.length > 0)
				isExternalIdentitiesExists = true;
		}
		return isExternalIdentitiesExists;
	}
}