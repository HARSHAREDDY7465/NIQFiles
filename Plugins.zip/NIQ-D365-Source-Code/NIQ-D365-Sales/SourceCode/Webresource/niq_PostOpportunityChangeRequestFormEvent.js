if (typeof (PostOpportunityChangeRequestForm) === "undefined") {
    PostOpportunityChangeRequestForm = {
        __namespace: true
    };
}

//Global Variables Start
var typeOfChange = "niq_typeofchange";
var deliveryDateChange = 100000003;
var evidenceofDeliveryEoDSubmission = 100000004;
var newForm = 1;
//Global Variables End

PostOpportunityChangeRequestForm.Events = {
    //form onload of Post Opportunity Change Request Form realted functional logic.
    OnFormLoad: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        this.FilterTypeofChangeOptions(executionContext);
        this.CommentFieldsAccess(executionContext);
        this.CommentFieldsAccess(executionContext);
        this.showHideChangeSubType(executionContext);
        this.showHideCurrentNewPartySectionsBasedOnChangeType(executionContext);
        if (CommonForm.Events.CheckValueExists(formContext, "niq_opportunity") && CommonForm.Events.CheckFieldExists(formContext, "niq_newbilltopartyid")) {
            var oppoId = formContext.getAttribute("niq_opportunity").getValue()[0].id.replace("{", "").replace("}", "");
            this.CustomViewCommon(formContext, "niq_newbilltopartyid", oppoId);
        }

    },
    //DYNCRM-2221,2222 start line
    showHideCurrentNewPartySectionsBasedOnChangeType: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var globalContext = Xrm.Utility.getGlobalContext();
        globalContext.getCurrentAppName().then(
            function successCallback(appDetails) {
                //getting app name;
                var appname = appDetails;
                //if Type of change = Bill to/Deliver to Party change
                if (formContext.getAttribute("niq_typeofchange").getValue() === 100000002) {
                    if (appname === 'Sales Hub') {
                        CommonForm.Events.ShowHideSections(formContext, "Summary", "niq_section_currentbilltoparty", false);
                        CommonForm.Events.ShowHideSections(formContext, "Summary", "niq_section_currentdelivertoparty", false);
                        CommonForm.Events.ShowHideSections(formContext, "Summary", "niq_section_newbilltoparty", true);
                        CommonForm.Events.ShowHideSections(formContext, "Summary", "niq_section_newdelivertoparty", true);
                        formContext.getControl("niq_currentbilltoparty").setVisible(false);
                        formContext.getControl("niq_currentdelivertoparty").setVisible(false);
                    }
                    else if (appname === 'Finance App') {
                        CommonForm.Events.ShowHideSections(formContext, "Summary", "niq_section_currentbilltoparty", true);
                        CommonForm.Events.ShowHideSections(formContext, "Summary", "niq_section_currentdelivertoparty", true);
                        CommonForm.Events.ShowHideSections(formContext, "Summary", "niq_section_newbilltoparty", true);
                        CommonForm.Events.ShowHideSections(formContext, "Summary", "niq_section_newdelivertoparty", true);
                    }
                }
                // DYNCRM-2222 for type of Changes as Finally eoa and PO 
                //if Type of change = Finally executed agreement & payment terms submission(100000000)
                else if (formContext.getAttribute("niq_typeofchange").getValue() === 100000000) {
                    if (appname === 'Sales Hub') {
                        formContext.getControl("niq_currentpaymentterms").setVisible(false);
                    }
                    else {
                        formContext.getControl("niq_currentpaymentterms").setVisible(true);
                    }
                }
                //Type of Change = PO Details submission (100000001)
                else if (formContext.getAttribute("niq_typeofchange").getValue() === 100000001) {
                    if (appname === 'Sales Hub') {
                        formContext.getControl("niq_currentbilltoparty").setVisible(false);
                        formContext.getControl("niq_currentdelivertoparty").setVisible(false);
                        CommonForm.Events.ShowHideSections(formContext, "Summary", "niq_section_currentbilltoparty", false);
                        CommonForm.Events.ShowHideSections(formContext, "Summary", "niq_section_currentdelivertoparty", false);
                    }
                    else {
                        formContext.getControl("niq_currentbilltoparty").setVisible(true);
                        formContext.getControl("niq_currentdelivertoparty").setVisible(true);
                        CommonForm.Events.ShowHideSections(formContext, "Summary", "niq_section_currentbilltoparty", true);
                        CommonForm.Events.ShowHideSections(formContext, "Summary", "niq_section_currentdelivertoparty", true);
                    }
                }
            }, function errorCallback() {
                alert('Error');
            }
        );
    },
    //DYNCRM-2221,2222 end line
    //Remove Options Delivery date change and Evidence of Delivery (EoD) Submission based on conditions.
    FilterTypeofChangeOptions: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        //form type is equals to new/create(1).
        if (formContext.ui.getFormType() === newForm && formContext.getAttribute(typeOfChange) !== undefined && formContext.getAttribute(typeOfChange) !== null) {
            formContext.getControl(typeOfChange).removeOption(deliveryDateChange);
            formContext.getControl(typeOfChange).removeOption(evidenceofDeliveryEoDSubmission);
        }
        //form type is not equals to new/create(1). 
        else if (formContext.ui.getFormType() !== newForm && formContext.getAttribute(typeOfChange) !== undefined && formContext.getAttribute(typeOfChange) !== null) {
            if (formContext.getAttribute(typeOfChange).getValue() !== undefined && formContext.getAttribute(typeOfChange).getValue() !== null) {
                if (formContext.getAttribute(typeOfChange).getValue() !== deliveryDateChange)
                    formContext.getControl(typeOfChange).removeOption(deliveryDateChange);
                if (formContext.getAttribute(typeOfChange).getValue() !== evidenceofDeliveryEoDSubmission)
                    formContext.getControl(typeOfChange).removeOption(evidenceofDeliveryEoDSubmission);
            }
            else {
                formContext.getControl(typeOfChange).removeOption(deliveryDateChange);
                formContext.getControl(typeOfChange).removeOption(evidenceofDeliveryEoDSubmission);
            }
        }
    },
    CommentFieldsAccess: function (executionContext) {
        'use strict';
        var formContext = executionContext.getFormContext();

        if (CommonForm.Events.CheckValueExists(formContext, "niq_approvalstatus") && CommonForm.Events.CheckFieldExists(formContext, "niq_comments")) {
            var approvalvalue = formContext.getAttribute("niq_approvalstatus").getValue();
            if (approvalvalue === 2 || approvalvalue === 3) {
                if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User,NIQ Business Admin,System Administrator,System Customizer")) {

                    formContext.getControl("niq_comments").setDisabled(false);
                }
                else {
                    formContext.getControl("niq_comments").setDisabled(true);
                }
            }
        }

    },

    CustomViewCommon: function (formContext, fieldName, oppoId) {
        "use strict";
        Xrm.WebApi.online.retrieveRecord("opportunity", oppoId, "?$select=_parentaccountid_value,_niq_salesorgid_value").then(
            function success(result) {
                var accountId = result["_parentaccountid_value"];
                var salesorgId = result["_niq_salesorgid_value"];

                var entName = "account";
                var vwNic = "NIC SAP Accounts(internal)";
                var vwNicId = "{00000000-0000-0000-0000-000000000023}";
                var resLayout = "<grid name='resultset' object='1' jump='name' select='1' icon='1' preview='1'>" +
                    "<row name='result' id='accountid'>" +
                    "<cell name='name' width='300'/>" +
                    "<cell name='address1_line1' width='100'/>" +
                    "<cell name='address1_city' width='100'/>" +
                    "<cell name='niq_countryid' width='100'/>" +
                    "<cell name='niq_sap_id__c' width='100'/>" +
                    "<cell name='niq_vatregistrationnumber' width='100'/>" +
                    "</row>" +
                    "</grid>";
                var sapNicResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                    "<entity name='account'>" +
                    "<attribute name='name' />" +
                    "<attribute name='address1_line1' />" +
                    "<attribute name='address1_city' />" +
                    "<attribute name='niq_countryid' />" +
                    "<attribute name='niq_sap_id__c' />" +
                    "<attribute name='niq_vatregistrationnumber' />" +
                    "<attribute name='accountid' />" +
                    "<order attribute='name' descending='false' />" +
                    "<filter type='and'>" +
                    "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                    "<condition attribute='niq_sap_id__c' operator='like' value='%NIC%' />" +
                    "</filter>" +
                    "</entity>" +
                    "</fetch>";
                if (salesorgId !== null && accountId !== null && CommonForm.Events.CheckFieldExists(formContext, fieldName)) {
                    PostOpportunityChangeRequestForm.Events.ValidateNewBillToParty(formContext, fieldName, "New Bill To Party", salesorgId)
					PostOpportunityChangeRequestForm.Events.ValidateNewBillToParty(formContext, fieldName, "New Deliver To Party", salesorgId)
                    var relSAPResult = "";
                    var sapExtResult = "";
                    var vwSAPExtId = "{00000000-0000-0000-0000-000000000001}";
                    var vwSAPExt = "Related SAP Accounts ext to sales org";
                    var vwRelSAPId = formContext.getControl(fieldName).getDefaultView();

                    var vwRelSAP = "Related SAP Accounts";

                    var noResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                        "<entity name='account'>" +
                        "<attribute name='name' />" +
                        "<attribute name='primarycontactid' />" +
                        "<attribute name='telephone1' />" +
                        "<attribute name='accountid' />" +
                        "<order attribute='name' descending='false' />" +
                        "<filter type='and'>" +
                        "<condition attribute='niq_accounttype' operator='eq' value='21' />" +
                        "</filter>" +
                        "</entity>" +
                        "</fetch>";

                    if (accountId != null) {
                        Xrm.WebApi.online.retrieveRecord("account", accountId, "?$select=_niq_ultimateparentid_value").then(
                            function success(result) {
                                var ultimateParentId = result["_niq_ultimateparentid_value"];

                                if (ultimateParentId !== null) {
                                    relSAPResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                        "<entity name='account'>" +
                                        "<attribute name='name' />" +
                                        "<attribute name='accountid' />" +
                                        "<attribute name='address1_line1' />" +
                                        "<attribute name='niq_vatregistrationnumber' />" +
                                        "<attribute name='niq_sap_id__c' />" +
                                        "<attribute name='niq_countryid' />" +
                                        "<attribute name='address1_city' />" +
                                        "<order attribute='name' descending='false' />" +
                                        "<filter type='and'>" +
                                        "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                        "<condition attribute='niq_ultimateparentid' operator='eq'  uitype='account' value='{" + ultimateParentId + "}' />" +
                                        "<condition attribute='statuscode' operator='eq' value='1'/>" +
                                        "</filter>" +
                                        "</entity>" +
                                        "</fetch>";
                                    if (salesorgId != null) {


                                        sapExtResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                                            "<entity name='account'>" +
                                            "<attribute name='name' />" +
                                            "<attribute name='accountid' />" +
                                            "<attribute name='address1_line1' />" +
                                            "<attribute name='niq_vatregistrationnumber' />" +
                                            "<attribute name='niq_sap_id__c' />" +
                                            "<attribute name='niq_countryid' />" +
                                            "<attribute name='address1_city' />" +
                                            "<order attribute='name' descending='false' />" +
                                            "<filter type='and'>" +
                                            "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                            "<condition attribute='niq_ultimateparentid' operator='eq' uitype='account' value='{" + ultimateParentId + "}' />" +
                                            "</filter>" +
                                            "<link-entity name='niq_saleorgassignment' from='niq_account' to='accountid' link-type='inner' alias='ac'>" +
                                            "<filter type='and'>" +
                                            "<condition attribute='niq_salesorg' operator='eq' uitype='niq_salesorg' value='" + salesorgId + "' />" +
                                            "<condition attribute='niq_accountblocked' operator='eq' value='0' />" +
                                            "</filter>" +
                                            "</link-entity>" +
                                            "</entity>" +
                                            "</fetch>";


                                    }
                                }
                                else {
                                    relSAPResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                        "<entity name='account'>" +
                                        "<attribute name='name' />" +
                                        "<attribute name='accountid' />" +
                                        "<attribute name='address1_line1' />" +
                                        "<attribute name='niq_vatregistrationnumber' />" +
                                        "<attribute name='niq_sap_id__c' />" +
                                        "<attribute name='niq_countryid' />" +
                                        "<attribute name='address1_city' />" +
                                        "<order attribute='name' descending='false' />" +
                                        "<filter type='and'>" +
                                        "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                        "<condition attribute='niq_ultimateparentid' operator='eq'  uitype='account' value='" + accountId + "' />" +
                                        "<condition attribute='statuscode' operator='eq' value='1'/>" +
                                        "</filter>" +
                                        "</entity>" +
                                        "</fetch>";
                                    if (formContext.getAttribute("niq_salesorgid") !== null && formContext.getAttribute("niq_salesorgid").getValue() !== null) {
                                        var salesOrgId = formContext.getAttribute("niq_salesorgid").getValue()[0].id;

                                        sapExtResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                                            "<entity name='account'>" +
                                            "<attribute name='name' />" +
                                            "<attribute name='accountid' />" +
                                            "<attribute name='address1_line1' />" +
                                            "<attribute name='niq_vatregistrationnumber' />" +
                                            "<attribute name='niq_sap_id__c' />" +
                                            "<attribute name='niq_countryid' />" +
                                            "<attribute name='address1_city' />" +
                                            "<order attribute='name' descending='false' />" +
                                            "<filter type='and'>" +
                                            "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                            "<condition attribute='niq_ultimateparentid' operator='eq' uitype='account' value='" + accountId + "' />" +

                                            "</filter>" +
                                            "<link-entity name='niq_saleorgassignment' from='niq_account' to='accountid' link-type='inner' alias='ac'>" +
                                            "<filter type='and'>" +
                                            "<condition attribute='niq_salesorg' operator='eq' uitype='niq_salesorg' value='" + salesOrgId + "' />" +
                                            "<condition attribute='niq_accountblocked' operator='eq' value='0' />" +
                                            "</filter>" +
                                            "</link-entity>" +
                                            "</entity>" +
                                            "</fetch>";


                                    }
                                }

                                formContext.getControl(fieldName).addCustomView(vwRelSAPId, entName, vwRelSAP, relSAPResult, resLayout, false);
                                formContext.getControl(fieldName).addCustomView(vwSAPExtId, entName, vwSAPExt, sapExtResult, resLayout, false);

                            },
                            function (error) {
                                Xrm.Utility.alertDialog(error.message);
                            }
                        );


                    }
                    else {

                        formContext.getControl(fieldName).addCustomView(vwRelSAPId, entName, vwRelSAP, noResult, resLayout, false);
                        formContext.getControl(fieldName).addCustomView(vwSAPExtId, entName, vwSAPExt, noResult, resLayout, false);

                    }


                }
                formContext.getControl(fieldName).addCustomView(vwNicId, entName, vwNic, sapNicResult, resLayout, false);



            },
            function (error) {
                Xrm.Utility.alertDialog(error.message);
            }
        );

    },
    ValidateNewBillToParty: function (formContext, fieldName, field, salesorgId) {
        if (CommonForm.Events.CheckValueExists(formContext, fieldName)) {
            var fieldId = formContext.getAttribute(fieldName).getValue()[0].id;
            salesOrgId = salesorgId.replace("{", "").replace("}", "");
            fieldId = fieldId.replace("{", "").replace("}", "");


            Xrm.WebApi.online.retrieveMultipleRecords("niq_saleorgassignment", "?$select=niq_accountblocked&$filter=_niq_salesorg_value eq " + salesOrgId + " and  _niq_account_value eq " + fieldId + "&$top=1").then(
                function success(results) {
                    if (results.entities.length) {
                        var accBlocked = results.entities[0]["niq_accountblocked"];
                        if (accBlocked)
                            formContext.ui.setFormNotification("Selected " + field + "Account is blocked for Sales Org. Please submit an unblocking request for the selected SAP account.", "ERROR", field + "error");

                    }
                    else
                        formContext.ui.setFormNotification("Selected " + field + " Account is not connected to Sales Org. Please submit an extension request for the selected SAP account.", "WARNING", field + "warning");

                },
                function (error) {
                    Xrm.Utility.alertDialog(error.message);
                }
            );

        }
        else {

            formContext.ui.clearFormNotification(field + "warning");
            formContext.ui.clearFormNotification(field + "error");


        }
    },
    PreventAutosave: function (executionContext) {
        "use strict";
        var eventArgs = executionContext.getEventArgs();
        if (eventArgs.getSaveMode() == 70 || eventArgs.getSaveMode() == 2) {
            eventArgs.preventDefault();
        }
    },
    PreventAutosaveForQuickCreate: function (executionContext) {
        "use strict";
        var eventArgs = executionContext.getEventArgs();
        if (eventArgs.getSaveMode() == 70) {
            eventArgs.preventDefault();
        }
    },

    HideClosedApprovalStatus: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        if (formContext.getAttribute("niq_approvalstatus") != null && formContext.getAttribute("niq_approvalstatus").getValue() != null) {
            if (formContext.getAttribute("niq_approvalstatus").getValue() != 4) {
                formContext.getControl("niq_approvalstatus").removeOption(4);
            }
        }
    },
    //DYNCRM-2226 start
    showHideChangeSubType: function (executionContext) {
        var formContext = executionContext.getFormContext();

        var typeOfChange = formContext.getAttribute("niq_typeofchange").getValue();
        var changeSubtype = formContext.getControl("niq_changesubtypebasesonly");
        changeSubtype.setVisible(false);
        var opportunityID = formContext.getAttribute("niq_opportunity").getValue()[0].id.replace("{", "").replace("}", "");

        Xrm.WebApi.retrieveRecord("opportunity", opportunityID, "?$select=niq_businessarea,niq_otherchangespocrdocument").then(
            function success(result) {
                var businessArea = result.niq_businessarea;
                var otherChangesPOCRDoc = result.niq_otherchangespocrdocument;
                if (typeOfChange === 100000006) {
                    //prepopulate Documentation field on POCR irrespective of Business area
                    if (otherChangesPOCRDoc) {
                        formContext.getAttribute("niq_documentationconfirmingthechange").setValue(otherChangesPOCRDoc);
                    }
                    if (businessArea === 100000000) {
                        //show Change Sub-Type field for BASES business area else hide it
                        changeSubtype.setVisible(true);
                    }
                    else {
                        changeSubtype.setVisible(false);
                    }
                }
            },
            function (error) {
                Xrm.Utility.alertDialog(error.message);

            }
        );
    }
    //DYNCRM-2226 end
};