if (typeof (OpportunityProductEnhancementForm) === "undefined") {
    OpportunityProductEnhancementForm = {
        __namespace: true
    };
}
OpportunityProductEnhancementForm.Events = {
FormOnload: function (executionContext) {
this.LockActualAmountOnBasisOfOppoApprovalStatus(executionContext);

},
LockActualAmountOnBasisOfOppoApprovalStatus :  function (executionContext) {
    "use strict";
    var formContext = executionContext.getFormContext();

    if (CommonForm.Events.CheckValueExists(formContext, "niq_opportunitynameid"))
    {
       var oppo = formContext.getAttribute("niq_opportunitynameid").getValue();
       var oppoID = oppo[0].id.replace('{', '').replace('}', '');
       
       Xrm.WebApi.online.retrieveRecord("opportunity",oppoID, "?$select=niq_approvalstatus").then(
          function success(result) 
          {
              if (result["niq_approvalstatus"] !== null) 
              {
                      var approvalstatus = result.niq_approvalstatus;
                          if (approvalstatus === 100000001) 
                          {
                              formContext.getControl("niq_actualamountincreaseannualvalue").setDisabled(true);
                          }
              }
          }, 
          function(error) 
          {
            Xrm.Utility.alertDialog(error.message);
          }
       );  
    }
}
}

