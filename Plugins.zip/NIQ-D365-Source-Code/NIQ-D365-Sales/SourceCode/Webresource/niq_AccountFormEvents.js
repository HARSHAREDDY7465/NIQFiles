if (typeof (AccountForm) === "undefined") {
    AccountForm = {
        __namespace: true
    };
}

AccountForm.Events = {
    ParentAccountOnChange: function (executionContext) { // On Change of Parent Account auto Populate Ultimate Parent Account on the record
        'use strict';
        //added comments
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "parentaccountid") && CommonForm.Events.CheckValueExists(formContext, "parentaccountid")) {
            var parentAccountId = formContext.getAttribute("parentaccountid").getValue()[0].id;
            var globalContext = Xrm.Utility.getGlobalContext();
            var serverUrl = globalContext.getClientUrl();
            var fetchUltimateParent = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                "<entity name='account'>" +
                "<attribute name='accountid' />" +
                "<attribute name='niq_ultimateparentid' />" +
                "<order attribute='niq_ultimateparentid' descending='false' />" +
                "<filter type='and'>" +
                "<condition attribute='accountid' operator='eq' uitype='account' value='" + parentAccountId + "'/>" +
                "</filter>" +
                "</entity>" +
                "</fetch>";

            var fetchUltimateParentResults = GetCRMWebAPI.Methods.GetFetchRecords(serverUrl, fetchUltimateParent, "accounts");

            if (fetchUltimateParentResults !== null && fetchUltimateParentResults.value.length > 0 && fetchUltimateParentResults.value[0] !== null) {
                var retrivedvalue = fetchUltimateParentResults.value[0]._niq_ultimateparentid_value; //get the id of the field
                var retrivedformatedvalue = fetchUltimateParentResults.value[0]["_niq_ultimateparentid_value@OData.Community.Display.V1.FormattedValue"]; //get the formatted name of the field
                if (retrivedvalue !== null && retrivedvalue !== "undefined") {
                    var ultimateParentObj = new Array();
                    ultimateParentObj[0] = new Object();
                    ultimateParentObj[0].id = retrivedvalue;
                    ultimateParentObj[0].name = retrivedformatedvalue;
                    ultimateParentObj[0].entityType = "account";
                    formContext.getAttribute("niq_ultimateparentid").setValue(ultimateParentObj);
                }
                else {
                    var parentAccObj = new Array();
                    parentAccObj[0] = formContext.getAttribute("parentaccountid").getValue()[0];
                    formContext.getAttribute("niq_ultimateparentid").setValue(parentAccObj);
                }

            }
            else {
                var parentAccObj = new Array();
                parentAccObj[0] = formContext.getAttribute("parentaccountid").getValue()[0];
                formContext.getAttribute("niq_ultimateparentid").setValue(parentAccObj);
            }
        }
    },

    formOnLoadDisableSapFields: function (executionContext) { // Disable fields of a Sap Account Tab for non-admin users on load of form if acc type is SAP Account
        'use strict';
        this.accTypeOnChange(executionContext);// On Change of Acc type/Form Load SHow or Hide the Account Tabs based on Acc Type
        this.onCreateDisableReadOnly(executionContext);//  Enable the Account Type Field For Admin Role while account create
        this.servicefieldisableforNGH(executionContext); //Enable service field only for NGH
        this.setUltimateParentFilter(executionContext);  //Set Filer to show only customer accounts on Ultimate Parent
        this.CustomerTypefieldisableforRoles(executionContext);
        var formContext = executionContext.getFormContext();
        this.disableWelcomePackageEmailsFieldForRoles(executionContext);
        var tab = formContext.ui.tabs.get("tab_4");
        var accType = formContext.getAttribute("niq_accounttype").getValue()
        if (accType !== null && accType === 2 && tab !== null && tab !== "undefined") {
            formContext.ui.navigation.items.forEach(function (item) {
                if (item._id === "nav_msa_partner_opportunity" || item._id === "navOppsParent")
                    item.setVisible(false);
            });

            if (!CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer")) {
                var tabsections = tab.sections.get();
                for (var i in tabsections) {
                    var sectionName = tabsections[i].getName();
                    CommonForm.Events.EnableOrDisableSection(formContext, "tab_4", sectionName, true);
                }
            }
        }
    },

    CustomerTypefieldisableforRoles: function (executionContext) {
        'use strict';
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer,NIQ Add-on Deal Desk Approver")) {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_customertype")) {

                formContext.getControl("niq_customertype").setDisabled(false);
            }
        }
        else {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_customertype")) {
                formContext.getControl("niq_customertype").setDisabled(true);
            }

        }

    },

    disableWelcomePackageEmailsFieldForRoles: function (executionContext) {
        "use strict";

        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Global Helpline Agent,NIQ Global Helpline Manager,System Administrator")) {
            formContext.getControl("niq_ngh_discoveraccess_isemailon").setDisabled(false);
        }
        else {
            formContext.getControl("niq_ngh_discoveraccess_isemailon").setDisabled(true);
        }
    },

    onCreateDisableReadOnly: function (executionContext) { //  Enable the Account Type Field For Admin Role while account create
        'use strict';
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        if (formType === 1) { //To check the form type is in create mode 

            if (CommonForm.Events.CheckIfLoggedInUserRoles("Business Admin,System Administrator,System Customizer")) // To check non-admin roles
            {
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_accounttype")) {
                    formContext.getControl("niq_accounttype1").setDisabled(false); // To make account type field editable
                    formContext.getControl("niq_accounttype2").setDisabled(false); //To make account type field editable
                }
            }
            else {
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_accounttype")) {
                    formContext.getControl("niq_accounttype1").setDisabled(true);// To make account type field readonly
                    formContext.getControl("niq_accounttype2").setDisabled(true);// To make account type field readonly
                }
            }

        }
        else {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_accounttype")) {
                formContext.getControl("niq_accounttype1").setDisabled(true);// To make account type field readonly
                formContext.getControl("niq_accounttype2").setDisabled(true);// To make account type field readonly
            }
        }
    },
    servicefieldisableforNGH: function (executionContext) {
        'use strict';
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("System Administrator,NIQ Global Helpline Manager")) {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_nghspecialclient")) {

                formContext.getControl("niq_nghspecialclient").setDisabled(false);
            }
        }
        else {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_nghspecialclient")) {
                formContext.getControl("niq_nghspecialclient").setDisabled(true);
            }

        }

    },
    accTypeOnChange: function (executionContext) { // On Change of Acc type/Form Load SHow or Hide the Account Tabs based on Acc Type
        'use strict';
        var formContext = executionContext.getFormContext();

        if (CommonForm.Events.CheckFieldExists(formContext, "niq_accounttype")) {  // To Check Either Account Type Field Exists Or Not
            var accountType = formContext.getAttribute("niq_accounttype").getValue();
            if (accountType !== "undefined" && accountType === 2) {   //To ensure Account type field and SAP Account summary tab are having valid information
                this.setUltimateParentFilter(executionContext);
                CommonForm.Events.ShowHideTabs(formContext, "tab_3", false);
                CommonForm.Events.ShowHideTabs(formContext, "tab_4", true);//To Make SAP account summary tab visible
                CommonForm.Events.ShowHideTabs(formContext, "Finance_Approval_Requests", true);
                CommonForm.Events.SetFocusTabs(formContext, "tab_4");//To focus on SAP account tab

            }
            else if (accountType !== "undefined" && accountType === 1) {
                CommonForm.Events.ShowHideTabs(formContext, "tab_4", false);
                CommonForm.Events.ShowHideTabs(formContext, "Finance_Approval_Requests", false);
                CommonForm.Events.ShowHideTabs(formContext, "tab_3", true);
                CommonForm.Events.SetFocusTabs(formContext, "tab_3"); //To focus on Customer account tab

            }
        }
    },

    setUltimateParentFilter: function (executionContext) {
        // get the form context
        formContext = executionContext.getFormContext();
        if (formContext.getControl("niq_ultimateparentid")) {
            var account = formContext.getControl('niq_ultimateparentid');

            if (account.getEntityTypes().length > 1) {
                account.setEntityTypes(['account']);
            }
            formContext.getControl("niq_ultimateparentid").addPreSearch(this.filterCustomerAccounts);
        }
    },
    filterCustomerAccounts: function () {
        // Only show accounts with the type 'Customer Account'
        var customeraccount = 1;
        //formContext = executionContext.getFormContext();
        var customerAccountFilter = "<filter type='and'>  <condition attribute='statecode' operator='eq' value='0' /> <condition attribute='niq_accounttype' operator='eq' value='" + customeraccount + "' /> </filter>";
        formContext.getControl("niq_ultimateparentid").addCustomFilter(customerAccountFilter, "account");
    },

    Servicetabeditefunction(executionContext) {
        var formContext = executionContext.getFormContext();
        if (!CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer,NIQ Project Manager,NIQ Sales User,NIQ Marketing User,NIQ Marketing Manager - Business,NIQ Marketing Professional - Business,Sales Manager") && formContext.ui.getFormType() != 1) {
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Client Response Manager,NIQ Client Response Agent,NIQ Analytics Agent,NIQ Analytics Manager,NIQ Global Helpline Agent,NIQ Global Helpline Manager")) {
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_accounttype")) {
                    formContext.ui.controls.forEach(function (control, index) {

                        control.setDisabled(true);


                    });

                    formContext.getControl("niq_serviceroutingmarketid").setDisabled(false);
                    formContext.getControl("niq_serviceroutingclientgroupid").setDisabled(false);
                    formContext.getControl("niq_servicedomains").setDisabled(false);
                    formContext.getControl("niq_serviceaccountadvisory").setDisabled(false);
                    formContext.getControl("niq_knowledgepermissionsets").setDisabled(false);
                    formContext.getControl("niq_nghspecialclient").setDisabled(false);
                    formContext.getControl("niq_hypercare2").setDisabled(false);
                    formContext.getControl("niq_platformaccountadvisory").setDisabled(false);

                }
                else {
                    if (CommonForm.Events.CheckFieldExists(formContext, "niq_accounttype")) {
                        formContext.getControl("niq_serviceroutingmarketid").setDisabled(true);
                        formContext.getControl("niq_serviceroutingclientgroupid").setDisabled(true);
                        formContext.getControl("niq_servicedomains").setDisabled(true);
                        formContext.getControl("niq_serviceaccountadvisory").setDisabled(true);
                        formContext.getControl("niq_knowledgepermissionsets").setDisabled(true);
                        formContext.getControl("niq_nghspecialclient").setDisabled(true);
                        formContext.getControl("niq_hypercare2").setDisabled(true);
                        formContext.getControl("niq_platformaccountadvisory").setDisabled(true);
                    }
                }

            }

        }

    }
}

//DYNCRM_70 Start Line
function filterLookup(executionContext) {
    var formContext = executionContext.getFormContext();
    var Industry = formContext.getAttribute("niq_industry").getValue();
    if (Industry != null) {
        formContext.getControl("niq_subindustry").addPreSearch(function () {
            addLookupFilter(formContext);
        });
    }
}
function addLookupFilter(formContext) {
    var Industry = formContext.getAttribute("niq_industry").getValue();
    if (Industry != null && Industry != undefined) {
        var fetchxmL = "<filter type='and'><condition attribute = 'niq_industry' operator = 'eq' value = '" + Industry + "' /></filter >"
        formContext.getControl("niq_subindustry").addCustomFilter(fetchxmL, "niq_subindustry");
    }
}
function clearSubIndustryValue(executionContext) {
    var formContext = executionContext.getFormContext();

    var industry = formContext.getAttribute("niq_industry");
    var subIndustry = formContext.getAttribute("niq_subindustry");

    if (industry && subIndustry) {

        var subIndustryValue = subIndustry.getValue();

        if (subIndustryValue != null) {
            subIndustry.setValue(null);
        }
    }
}
//DYNCRM_70 End Line
