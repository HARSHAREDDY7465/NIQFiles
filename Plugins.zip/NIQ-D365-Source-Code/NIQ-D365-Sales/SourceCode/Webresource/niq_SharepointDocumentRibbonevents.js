function displayAlertDialog(primaryControl) {
    var formContext = primaryControl;
    var entityName = formContext.data.entity.getEntityName();
    if (entityName == "incident") {
        var recordType = formContext.getAttribute("niq_recordtype").getValue();
        if (recordType == 100000000 || recordType == 100000001 || recordType == 100000003) {
            setTimeout(this.displayAlert, 2000)
        }
    }

}


function displayAlert() {
    var alertStrings = {
        confirmButtonLabel: "Ok",
        title: "Confirm the document location",
        text: "Please confirm the document location where you are going to upload the file before uploading.!"
    };
    var alertOptions = { height: 320, width: 590 };
    Xrm.Navigation.openAlertDialog(alertStrings, alertOptions).then(
        function (success) {
            // Do something here
        },
        function (error) {
            console.log(error.message);
        }
    );
}

async function ShowHildeUploadButton(primaryControl) {
    // statement 1
    var isPrivateCreated = false;
    var formContext = primaryControl;
    var entityName = formContext.data.entity.getEntityName();
    if (entityName == "incident") {
        var recordType = formContext.getAttribute("niq_recordtype").getValue();
        var createdon = formContext.getAttribute("createdon").getValue();
        var date1 = new Date("2023-01-06");
        if (recordType == 100000000 || recordType == 100000001 || recordType == 100000003) {
            var requestId = formContext.data.entity.getId();
            if (createdon > date1) {
                isPrivateCreated = await ReadDocumentLocations(requestId);
            }
            else {
                isPrivateCreated = true;
            }
            if (isPrivateCreated != true) {
                formContext.ui.setFormNotification("If you don't see the upload button in documents tab, Please check again in 20-30 seconds to see Upload button.", "WARNING", "DocumentUploadButtonNotification");
            }
            else {
                formContext.ui.clearFormNotification("DocumentUploadButtonNotification");
            }
            return isPrivateCreated;

        }
        else {
            return true;
        }

    }
    else if (entityName === "niq_sapaccountrequest") {
        debugger;
        var stage = formContext.getAttribute("niq_stage").getValue();
        if ((CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User")) && (!CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer"))) {
            if ((stage === "New SAP Account Details Submission") || (stage === "Credit Check Details Submission") || (stage === "Close")) {
                return false;
            }
            else {
                return true;
            }
        }
        else {
            return true;
        }
    }
    else {
        return true;
    }
}

async function ShowHildeNewButton(primaryControl) {
    var formContext = primaryControl;
    var entityName = formContext.data.entity.getEntityName();
    if (entityName === "niq_sapaccountrequest") {
        if ((CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User")) && (!CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer"))) {
            return false;
        }
        else {
            return true;
        }
    }
    else {
        return true;
    }
}

async function ReadDocumentLocations(string) {
    var result = await Xrm.WebApi.retrieveMultipleRecords("sharepointdocumentlocation", "?$select=name&$filter=(name eq 'Private' and regardingobjectid_incident/incidentid eq " + string + ")");
    if (result.entities.length > 0) {
        return true;
    }
}