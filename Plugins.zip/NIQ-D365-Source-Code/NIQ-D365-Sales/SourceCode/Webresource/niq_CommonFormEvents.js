if (typeof (CommonForm) === "undefined")
{
	CommonForm = {
		__namespace: true
	};
}
var gsCurrentUserRoles = []; //global variable to save user roles names - array
var delegateRoles=['Delegate Agent','Delegate Manager', 'System Administrator'];
var nondelegateRoles=['NIQ Global Helpline Agent', 'NIQ Global Helpline Manager', 'Analytics Agent', 'Client Response Agent', 'Client Response Manager', 'Analytics Manager','Ops Solution Provider', 'System Administrator','Ops Submitter'];
var showopsbuttonRoles = ['NIQ Global Helpline Agent', 'NIQ Global Helpline Manager', 'Analytics Agent', 'Client Response Agent', 'Client Response Manager', 'Analytics Manager',
'Ops Solution Provider', 'System Administrator','Ops Submitter'];
var serviceReqCreateRoles=['Delegate Agent','Delegate Manager','NIQ Global Helpline Agent', 'NIQ Global Helpline Manager', 'Analytics Agent', 'Client Response Agent', 'Client Response Manager', 'Analytics Manager',
'Ops Solution Provider', 'System Administrator','Ops Submitter'];
var sysAdmin=['System Administrator'];
CommonForm.Events = {
	ShowHideTabs: function (formContext, tabName, isVisible)
	{ // Hide a tab
		"use strict";
		if (formContext.ui.tabs.get(tabName) !== null)
		{
			formContext.ui.tabs.get(tabName).setVisible(isVisible);
		}
	},
	ShowHideFields: function (formContext, fields, isVisible)
	{ //Show or Hide fields in the form
		"use strict";
		for (var i = 0; i < fields.length; i++)
		{
			if (formContext.getControl(fields[i]) !== null)
			{
				formContext.getControl(fields[i]).setVisible(isVisible);
			}
		}
	},
	SetRequiredFieldLevels: function (formContext, fields, reqlevel)
	{ //Show or Hide fields in the form
		"use strict";
		for (var i = 0; i < fields.length; i++)
		{
			if (formContext.getControl(fields[i]) !== null)
			{
				formContext.getAttribute(fields[i]).setRequiredLevel(reqlevel);
			}
		}
	},
	SetFocusTabs: function (formContext, tabName)
	{ //Set focus to a tab
		"use strict";
		if (formContext.ui.tabs.get(tabName) !== null)
		{
			formContext.ui.tabs.get(tabName).setFocus();
		}
	},
	ShowHideSections: function (formContext, tabName, sectionName, isVisible)
	{ //show or hide a section in a tab
		"use strict";
		if (formContext.ui.tabs.get(tabName) !== null && formContext.ui.tabs.get(tabName).sections.get(sectionName) !== null)
		{
			formContext.ui.tabs.get(tabName).sections.get(sectionName).setVisible(isVisible);
		}
	},
	CheckFieldExists: function (formContext, fieldName)
	{ // function to check if a field exists in a form
		"use strict";
		if (formContext.getAttribute(fieldName) !== null) return true;
		else return false;
	},
	CheckControlExists: function (formContext, fieldName)
	{ // function to check if a field exists in a form	
		"use strict";
		if (formContext.getControl(fieldName) !== null) return true;
		else return false;
	},
	CheckValueExists: function (formContext, fieldName)
	{ // Check if a value exists in a form
		"use strict";
		var isValueExists = false;
		if (formContext.getAttribute(fieldName) !== null && formContext.getAttribute(fieldName).getValue() !== null)
		{
			isValueExists = true;
		}
		return isValueExists;
	},
	GetFieldValue: function (formContext, fieldName)
	{ // Get field value from a field
		"use strict";
		if (formContext.getAttribute(fieldName) !== null)
		{
			return formContext.getAttribute(fieldName).getValue();
		}
		else return null;
	},
	SetFieldValue: function (formContext, fieldName, val)
	{ // set field value from a value
		"use strict";
		if (formContext.getAttribute(fieldName) !== null)
		{
			formContext.getAttribute(fieldName).setValue(val);
		}
	},
	GetUserRoleNames: function ()
	{
		"use strict";
		// check if logged in user has a specific role
		if (gsCurrentUserRoles.length === 0)
		{
			var globalContext = Xrm.Utility.getGlobalContext();
			var laRoles = globalContext.userSettings.securityRoles;
			this.getRole(laRoles); // get all role names in the gsCurrentUserRoles array object 
		}
	},
	CheckIfLoggedInUserRole: function (rolename)
	{ //Check if the current user role exists in the list of roles
		"use strict";
		var isRoleExists = false;
		this.GetUserRoleNames();
		// iterate through each role name
		for (var liCountI = 0; liCountI < gsCurrentUserRoles.length; liCountI++)
		{
			if (gsCurrentUserRoles[liCountI].toString().toLowerCase().indexOf(rolename.toLowerCase()) >= 0)
			{
				isRoleExists = true;
			}
		}
		return isRoleExists; // return true if role exists 
	},
	// check either of one role exists from the rolenames sent ,  rolenames will be string separated by comma
	CheckIfLoggedInUserRoles: function (rolenames)
	{ // Check if multiple roles exists in currnet user roles
		"use strict";
		var isRoleExists = false;
		//check if global variable contains current user role names in array
		this.GetUserRoleNames();
		// check if the roles are available in rolenames string
		var found = gsCurrentUserRoles.some(r => rolenames.indexOf(r) >= 0);
		if (found)
		{
			return true;
		}
		else
		{
			return false;
		}
	},
	// get the rolename for the current user roles
	getRole: function (rolesid)
	{ // parameter- get rolesid array of the current user 
		"use strict";
		var globalContext = Xrm.Utility.getGlobalContext();
		var serverUrl = globalContext.getClientUrl();
		var fetchRole = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
			"<entity name='role'>" +
			"<attribute name='name' />" +
			"<filter type='and'>" +
			"<condition attribute='roleid' operator='in'>";
		for (var i = 0; i < rolesid.length; i++)
		{
			fetchRole += "<value uiname='' uitype='role'>" + rolesid[i] + "</value>";
		}
		fetchRole += "</condition></filter>" + "</entity>" + "</fetch>";
		var fetchroleResults = this.GetFetchRecords(serverUrl, fetchRole, "roles");
		if (fetchroleResults != null && fetchroleResults.value.length > 0)
		{
			for (var j = 0; j < fetchroleResults.value.length; j++)
			gsCurrentUserRoles.push(fetchroleResults.value[j].name); // load the roles names to array
		}
	},
	// disable all the fields of the form 
	disableFormFields: function (lbOnOff, formContext)
	{ // Disable all the fields in a form
		"use strict";
		var index = 0;
		formContext.ui.controls.forEach(function (control, index)
		{
			if (control && control.getDisabled && !control.getDisabled())
			{
				control.setDisabled(lbOnOff);
			}
		});
	},
	// load dependent option set values 
	filteroptions: function (executionContext, optionAName, optionBName, optionSetBValues, dependecies)
	{
		"use strict";
		var formContext = executionContext.getFormContext();
		var selectedAValue = formContext.getAttribute(optionAName).getValue();
		var optionSetBControl = formContext.getControl(optionBName);
		// check the global variable and load the values in the array
		if (optionSetBValues === null) optionSetBValues = optionSetBControl.getOptions();
		if (optionSetBValues.length > 1 && (optionSetBValues[0].text === "" || optionSetBValues[0].text === undefined))
		{
			optionSetBValues.shift();
		}
		//  check if selected value is  not null
		if (selectedAValue !== null)
		{
			optionSetBControl.clearOptions();
			var dependeciesB = dependecies.find(d => d[0] === selectedAValue).slice(1);
			var filtredOptionB = optionSetBValues.filter(v => dependeciesB.includes(v.value));
			filtredOptionB.forEach(d => {
				optionSetBControl.addOption(d);
			})
		}
		else
		{
			optionSetBControl.clearOptions();
		}
	},
	EnableOrDisableSection: function (formContext, tabName, sectionName, status)
	{ //Enable  or Disable fields of a section in a tab
		"use strict";
		if (formContext.ui.tabs.get(tabName).sections.get(sectionName) !== null && formContext.ui.tabs.get(tabName).sections.get(sectionName) !== undefined)
		{
			var controls = formContext.ui.tabs.get(tabName).sections.get(sectionName).controls.get();
			var numberOfControls = controls.length;
			for (var i = 0; i < numberOfControls; i++)
			{
				controls[i].setDisabled(status);
			}
		}
	},
	navigateToForm: function (entityName, entityFormId)
	{
		var entityFormOptions = {};
		entityFormOptions.entityName = entityName;
		entityFormOptions.formId = entityFormId;
		entityFormOptions.openInNewWindow = false;
		Xrm.Navigation.openForm(entityFormOptions);
	},
	navigateToHnSForm: function (entityName, entityFormId)
	{
		var pageInput = {
			pageType: "entityrecord",
			entityName: entityName,
			formId: entityFormId
		};
		var navigationOptions = {
			target: 2,
			height: {
				value: 100,
				unit: "%"
			},
			width: {
				value: 50,
				unit: "%"
			},
			position: 1
		};
		Xrm.Navigation.navigateTo(pageInput, navigationOptions);
		//Xrm.Navigation.navigateTo({pageType:"entityrecord", entityName:entityName, formType:1,formId:entityFormId}, {target: 2, position: 1, width: {value: 50, unit:"%"}});
	},
	GetFieldText: function (formContext, fieldName)
	{ // Get field value from a field
		"use strict";
		if (formContext.getAttribute(fieldName) !== null)
		{
			return formContext.getAttribute(fieldName).getText();
		}
		else return null;
	},
	LoadFormBasedOnRecordType: function (formContext, recordTypeText)
	{
		var currentForm = formContext.ui.formSelector.getCurrentItem();
		// Get all the forms accessible and filter the one which has to be loaded
		if (currentForm.getLabel().toLowerCase() !== recordTypeText.toLowerCase())
		{
			// Get the Record's, record type text
			var availableForms = formContext.ui.formSelector.items.get();
			for (var i in availableForms)
			{
				var form = availableForms[i];
				var formname = form.getLabel();
				if (formname.toLowerCase() === recordTypeText.toLowerCase())
				{
					form.navigate();
					return true;
				}
			}
			if (currentForm.getLabel().toLowerCase() !== availableForms[0].getLabel().toLowerCase())
			{
				availableForms[0].navigate();
				return true;
			}
		}
	},
    ShowHideCreateNewbtn: function (primaryctrl)
	{
		"use strict";
		if (CommonForm.Events.CheckIfLoggedInUserRoles(serviceReqCreateRoles))
			{
		
			
			
				return true;
			
		}
		else return false;
	},
	ShowHideOpsCreateNewbtn: function (primaryctrl)
	{
		"use strict";
		if (CommonForm.Events.CheckIfLoggedInUserRoles(showopsbuttonRoles))
			{
		
		
			
				return true;
			
		}
		else return false;
	},
    ShowHideCreateNewDelegateBtn: function (primaryctrl)
	{
		"use strict";
		if (CommonForm.Events.CheckIfLoggedInUserRoles(delegateRoles))
			{
		
			
			
				return true;
			
		}
		else return false;
	},
    ShowHideCreateNewNonDelegateBtn: function (primaryctrl)
	{
		"use strict";
		if (CommonForm.Events.CheckIfLoggedInUserRoles(nondelegateRoles))
			{
		
			
			
				return true;
			
		}
		else return false;
	},
    ShowHideCreateNewNghAMBtn: function (primaryctrl)
	{
		"use strict";
		if (CommonForm.Events.CheckIfLoggedInUserRoles(sysAdmin))
			{
		
			
			
				return true;
			
		}
		else return false;
	},
   

	//synchronous method to fetch record from the application
	GetFetchRecords: function (clientURL, fetchXmlQuery, ename)
	{
		"use strict";
		var req = new XMLHttpRequest();
		var resultVal = null;
		req.open(
			"GET",
		clientURL +
			"/api/data/v9.0/" + ename + "?fetchXml=" + encodeURIComponent(fetchXmlQuery),
		false);
		req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
		req.onreadystatechange = function ()
		{
			if (this.readyState === 4)
			{
				req.onreadystatechange = null;
				if (this.status === 200)
				{
					var results = JSON.parse(this.response);
					resultVal = results;
				}
				else
				{
					resultVal = null;
				}
			}
		};
		req.send();
		return resultVal;
	},
 OpenQuickCreate : function (primaryctrl)
    {
        var parameters = {};
        var accountid = primaryctrl.data.entity.attributes.getByName("customerid").getValue();
        var title = primaryctrl.data.entity.attributes.getByName("title").getValue();
        var description= primaryctrl.data.entity.attributes.getByName("description").getValue();
        parameters ["title"]=title ;
        parameters ["description"]=description ;
        
        if (accountid != null)
        {
            var lkupaccount = new Array();
            lkupaccount[0] = new Object();
            lkupaccount[0].id = accountid[0].id;
            lkupaccount[0].name = accountid[0].name;
            lkupaccount[0].entityType = "account";
            parameters["customerid"] = lkupaccount;
        }
        if (title != null)
        {
            var lkupparentcaseid = new Array();
            lkupparentcaseid [0] = new Object();
            lkupparentcaseid [0].id = "{" + primaryctrl._entityReference.id.guid.toUpperCase()+ "}";
            lkupparentcaseid [0].name = primaryctrl.data.entity.attributes.getByName("title").getValue();
            lkupparentcaseid [0].entityType = primaryctrl._entityName;
            parameters["parentcase"] = primaryctrl.data.entity.getEntityReference();
        }
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "incident";
        entityFormOptions["useQuickCreateForm"] = true;
        Xrm.Navigation.openForm(entityFormOptions, parameters)
    }
}