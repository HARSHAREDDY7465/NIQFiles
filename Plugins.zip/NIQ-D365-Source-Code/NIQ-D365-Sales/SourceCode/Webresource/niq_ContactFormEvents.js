if (typeof (ContactForm) === "undefined") {
	ContactForm = {
		__namespace: true
	};
}

var canEditRoles = "System Administrator,NIQ Global Helpline Agent,NIQ Global Helpline Manager";
var canEditRolesSysAdmin = "System Administrator";
var servicestandardContactroles = "NIQ Global Helpline Manager,NIQ Global Helpline Agent,NIQ Analytics Agent,NIQ Analytics Manager,"
	+ "NIQ Delegate Agent,NIQ Delegate Manager,NIQ Client Response Agent,NIQ Client Response Manager,NIQ Ops Solution Provider,NIQ Ops Submitter";
var marketingMembersList = "NIQ Marketing User,NIQ Marketing Manager - Business";

ContactForm.Events =
{
	// set 'ContactForm.setparentcustomeridFilter' in the Contact form onload event handler
	setparentcustomeridFilter: function (executionContext) {
		// get the form context
		formContext = executionContext.getFormContext();
		if (formContext.getControl("parentcustomerid")) {
			var account = formContext.getControl('parentcustomerid');

			if (account.getEntityTypes().length > 1) {
				account.setEntityTypes(['account']);
			}
			formContext.getControl("parentcustomerid").addPreSearch(this.filterCustomerAccounts);
		}
	},
	filterCustomerAccounts: function () {
		// Only show accounts with the type 'Customer Account'
		var customeraccount = 1;
		//formContext = executionContext.getFormContext();
		var customerAccountFilter = "<filter type='and'>  <condition attribute='statecode' operator='eq' value='0' /> <condition attribute='niq_accounttype' operator='eq' value='" + customeraccount + "' /> </filter>";
		formContext.getControl("parentcustomerid").addCustomFilter(customerAccountFilter, "account");
	},
	//Method for onload functions
	FormOnload: function (executionContext) {
		var formContext = executionContext.getFormContext();
		var emailFieldControlError = formContext.getControl("emailaddress1");
		formContext.getAttribute("emailaddress1").addOnChange(this.ThrowErrorForPortalContact);
		//formContext.getAttribute("emailaddress1").addOnChange(this.ErrorOnPortalContactEmailChangeOnSave);
		var contactDepartmentField = ["department"];
		if (CommonForm.Events.CheckIfLoggedInUserRoles(canEditRoles)) {
			formContext.getControl("niq_accessapproverdesignation").setDisabled(false);
			CommonForm.Events.ShowHideFields(formContext, contactDepartmentField, true);
		}
		else {
			formContext.getControl("niq_accessapproverdesignation").setDisabled(true);
			CommonForm.Events.ShowHideFields(formContext, contactDepartmentField, false);
		}
		// formContext.getAttribute("parentcustomerid").addOnChange(this.CheckForNielsenConsumerGlobal);
		var passwordhash = CommonForm.Events.GetFieldValue(formContext, "adx_identity_passwordhash");
		var createdby = CommonForm.Events.GetFieldValue(formContext, "createdby");
		if (createdby !== null) {
			var name = createdby[0].name;
			if (passwordhash !== null || (name === "SYSTEM")) {
				if (formContext.ui.getFormType() !== 1) {
					if (CommonForm.Events.CheckIfLoggedInUserRoles(canEditRolesSysAdmin)) {
						//formContext.getControl("emailaddress1").setDisabled(false);
						if (formContext.getControl("niq_communitydepartment") !== null)
							formContext.getControl("niq_communitydepartment").setDisabled(false);
					}
					else {
						if (formContext.getControl("niq_communitydepartment") !== null)
							formContext.getControl("niq_communitydepartment").setDisabled(true);
						//	formContext.getControl("emailaddress1").setDisabled(true);
					}
				}
			}
		}
		if (CommonForm.Events.CheckIfLoggedInUserRoles(canEditRolesSysAdmin)) {
			formContext.getControl("niq_communitydepartment").setDisabled(false);
		}
		else {
			formContext.getControl("niq_communitydepartment").setDisabled(true);
		}
		formContext.data.entity.addOnSave(this.ThrowErrorForServiceRoles);
		formContext.data.entity.addOnSave(this.ThrowErrorForInternalContacts);
        formContext.data.entity.addOnSave(this.ErrorOnPortalContactEmailChangeOnSave);
        ContactForm.Events.makeNonRequiredFieldsForMarketingUsers(executionContext);
	},
	ThrowErrorForPortalContact: function (executionContext) {
		"use strict";
		formContext = executionContext.getFormContext();
		var emailFieldControlError = formContext.getControl("emailaddress1");
		var contactId = formContext.data.entity.getId();
		var passwordhash = CommonForm.Events.GetFieldValue(formContext, "adx_identity_passwordhash");
		var createdby = CommonForm.Events.GetFieldValue(formContext, "createdby");
		var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'> <entity name='contact'> <attribute name='adx_identity_passwordhash' /><attribute name='department' /> <attribute name='adx_identity_securitystamp' />";
		fetchXml += "<filter type='and'>  <condition attribute='contactid' operator='eq' uiname='' uitype='contact' value='" + contactId + "' />";
		fetchXml += "</filter> <link-entity name='account' from='accountid' to='parentcustomerid' visible='false' link-type='outer' alias='acc'> <attribute name='niq_industry' />";
		fetchXml += "<attribute name='niq_accounttype' /><attribute name='name' /> <attribute name='niq_accountmarketid' /> </link-entity>";
		fetchXml += "</entity> </fetch>";
		var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
		var result = GetCRMWebAPI.Methods.GetFetchRecords(clienturl, fetchXml, "contacts");
		//check if data is retrieved & Companyname has data 
		if (result !== null && result.value.length > 0 && result.value[0] !== null) {
			//get the first row /only row retrieved
			var rec = result.value[0];
			if (rec.adx_identity_securitystamp !== null)
				passwordhash = rec.adx_identity_securitystamp;
		}

		if (createdby !== null) {
			var name = createdby[0].name;
			if ((passwordhash !== null && passwordhash !== undefined) || (name === "SYSTEM")) {
				if (formContext.ui.getFormType() !== 1) {

					if (!CommonForm.Events.CheckIfLoggedInUserRoles(canEditRolesSysAdmin)) {
						var oppAttributes = Xrm.Page.data.entity.attributes.get("emailaddress1");
						if (oppAttributes != null) {

							if (oppAttributes.getIsDirty()) {
								emailFieldControlError.setNotification("This contact is linked to a user in our community. Please submit a H&S request to update the email of this contact.", "emailFieldError");

							}
							else {

								emailFieldControlError.clearNotification("emailFieldError");
							}
						}
						else {

							emailFieldControlError.clearNotification("emailFieldError");
						}
					}

				}
			}
		}

	},

	ErrorOnPortalContactEmailChangeOnSave: function (executionContext) {
		"use strict";
		formContext = executionContext.getFormContext();
		var emailFieldControlError = formContext.getControl("emailaddress1");
		var contactId = formContext.data.entity.getId();
		var passwordhash = CommonForm.Events.GetFieldValue(formContext, "adx_identity_passwordhash");

		var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'> <entity name='contact'> <attribute name='adx_identity_passwordhash' /><attribute name='department' /> <attribute name='adx_identity_securitystamp' />";
		fetchXml += "<filter type='and'>  <condition attribute='contactid' operator='eq' uiname='' uitype='contact' value='" + contactId + "' />";
		fetchXml += "</filter> <link-entity name='account' from='accountid' to='parentcustomerid' visible='false' link-type='outer' alias='acc'> <attribute name='niq_industry' />";
		fetchXml += "<attribute name='niq_accounttype' /><attribute name='name' /> <attribute name='niq_accountmarketid' /> </link-entity>";
		fetchXml += "</entity> </fetch>";
		var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
		var result = GetCRMWebAPI.Methods.GetFetchRecords(clienturl, fetchXml, "contacts");
		//check if data is retrieved & Companyname has data 
		if (result !== null && result.value.length > 0 && result.value[0] !== null) {
			//get the first row /only row retrieved
			var rec = result.value[0];
			if (rec.adx_identity_securitystamp !== null)
				passwordhash = rec.adx_identity_securitystamp;
		}

		var createdby = CommonForm.Events.GetFieldValue(formContext, "createdby");
		if (createdby !== null) {
			var name = createdby[0].name;
			if ((passwordhash !== null && passwordhash !== undefined) || (name === "SYSTEM")) {
				if (formContext.ui.getFormType() !== 1) {

					if (!CommonForm.Events.CheckIfLoggedInUserRoles(canEditRolesSysAdmin)) {

						//Check for dirty attributes and set their submit mode to never
						var oppAttributes = Xrm.Page.data.entity.attributes.get("emailaddress1");
						if (oppAttributes != null) {
							if (oppAttributes.getIsDirty()) {
								emailFieldControlError.setNotification("This contact is linked to a user in our community. Please submit a H&S request to update the email of this contact.", "emailFieldError");

							}
							else {
								// formContext.ui.clearFormNotification("emailaddressError");
								emailFieldControlError.clearNotification("emailFieldError");
							}

						}
						else {
							// formContext.ui.clearFormNotification("emailaddressError");
							emailFieldControlError.clearNotification("emailFieldError");
						}
					}
				}
			}
		}

	},
	CheckForNielsenConsumerGlobal: function (executionContext) {
		"use strict";
		formContext = executionContext.getFormContext();
		var account = CommonForm.Events.GetFieldValue(formContext, "parentcustomerid");
		var recordtype = CommonForm.Events.GetFieldValue(formContext, "niq_contactrecordtype");
		if (account !== null && recordtype !== null && recordtype === 1) {
			// get parent account with requestid
			var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'> <entity name='account'> <attribute name='name' /><attribute name='parentaccountid' />";
			fetchXml += "<filter type='and'> <condition attribute='accountid' operator='eq' uiname='' value='" + account[0].id + "' />";
			fetchXml += "</filter></entity> </fetch>";
			var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
			var result = GetCRMWebAPI.Methods.GetFetchRecords(clienturl, fetchXml, "accounts");
			//check if data is retrieved & Companyname has data 
			if (result !== null && result.value.length > 0 && result.value[0] !== null) {
				//get the first row /only row retrieved
				var rec = result.value[0];
				// check if account name is not nielsen consumer global 
				var parentaccountid = rec._parentaccountid_value;
				var result = ContactForm.Events.GetParentAccountInfo(parentaccountid);
				//check if data is retrieved & Companyname has data 
				if (result !== undefined && result !== null && result.value.length > 0 && result.value[0] !== null) {
					//get the first row /only row retrieved
					var rec = result.value[0];
					var Deptname = rec.name;
					if (Deptname !== null && Deptname !== undefined) {
						var accountControlError = formContext.getControl("parentcustomerid");
						if (Deptname !== "Nielsen Consumer (Global)") {
							formContext.ui.setFormNotification("Internal Contact should be associated with Nielsen Consumer (Global) account.", "ERROR", "nielsenglobError");
							duetdateFieldControlError.setNotification("Internal Contact should be associated with Nielsen Consumer (Global) account.", "nielsenglobErrorField");
							executionContext.getEventArgs().preventDefault();
						}
						else {
							formContext.ui.clearFormNotification("nielsenglobError");
							accountControlError.clearNotification("nielsenglobErrorField");
						}
					}
				}
			}
		}
	},
	GetParentAccountInfo: function (accountid) {
		"use strict";
		if (accountid !== null) {
			// get parent account with requestid
			var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'> <entity name='account'> <attribute name='name' />";
			fetchXml += "<filter type='and'> <condition attribute='accountid' operator='eq' uiname='' value='" + accountid + "' />";
			fetchXml += "</filter></entity> </fetch>";
			var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
			var result = GetCRMWebAPI.Methods.GetFetchRecords(clienturl, fetchXml, "accounts");
			return result;
		}
	},
	ThrowErrorForServiceRoles: function (executionContext) {
		"use strict";
		formContext = executionContext.getFormContext();
		var recordtype = CommonForm.Events.GetFieldValue(formContext, "niq_contactrecordtype");
		var email = CommonForm.Events.GetFieldValue(formContext, "emailaddress1");
		if (CommonForm.Events.CheckIfLoggedInUserRoles(servicestandardContactroles) && (formContext.ui.getFormType() === 1)) {
			if ((recordtype === false) && ((email.indexOf("@gmail") > -1) || (email.indexOf("@hotmail") > -1) || (email.indexOf("@yahoo") > -1) || (email.indexOf("@mailnesia") > -1) || (email.indexOf("@msn") > -1) || (email.indexOf("@live") > -1))) {
				formContext.ui.setFormNotification("Email: Please use a corporate email address associated with the Account. If you need an exception for any clients, please raise a Help and Support request.", "ERROR", "servicerolesError");
				executionContext.getEventArgs().preventDefault();
			}
			else {
				formContext.ui.clearFormNotification("servicerolesError");
			}
		}
	},
	ThrowErrorForInternalContacts: function (executionContext) {
		"use strict";
		formContext = executionContext.getFormContext();
		var accountid = CommonForm.Events.GetFieldValue(formContext, "parentcustomerid");
		var accountFieldControl = formContext.getControl("parentcustomerid");
		var recordtype = CommonForm.Events.GetFieldValue(formContext, "niq_contactrecordtype");
		var accname = accountid[0].name;
		if (((accountid !== null && accountid !== undefined)) && ((accname !== null && accname !== undefined && recordtype === true && accname.indexOf("Consumer (Global)") > -1))) {
			formContext.ui.setFormNotification("Account Name: Please be advised, new contact is not allowed under Nielsen Consumer (Global) account", "ERROR", "AccountError");
			executionContext.getEventArgs().preventDefault();
		}
		else {
			formContext.ui.clearFormNotification("AccountError");
		}
    },

    showHideFieldsOnSharedBillingMailBox: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var sharedMailBox = CommonForm.Events.GetFieldValue(formContext, "niq_sharedbillingmailbox");
        if (sharedMailBox == false && !CommonForm.Events.CheckIfLoggedInUserRoles(marketingMembersList)) {
            formContext.getAttribute("jobtitle").setRequiredLevel("required");
            formContext.getAttribute("niq_functionalarea").setRequiredLevel("required");
            formContext.getAttribute("niq_managementlevel").setRequiredLevel("required");
        }
        else {
            formContext.getAttribute("jobtitle").setRequiredLevel("none");
            formContext.getAttribute("niq_functionalarea").setRequiredLevel("none");
            formContext.getAttribute("niq_managementlevel").setRequiredLevel("none");
        }

    },
    makeNonRequiredFieldsForMarketingUsers: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles(marketingMembersList)) {
            formContext.getAttribute("niq_preferredlanguage").setRequiredLevel("none");
            formContext.getAttribute("parentcustomerid").setRequiredLevel("none");
        }
        else {
            formContext.getAttribute("niq_preferredlanguage").setRequiredLevel("required");
            formContext.getAttribute("parentcustomerid").setRequiredLevel("required");
        }

    },

    onButtonClickCreateLeads: function (executionContext) {
        var confirmStrings = { text: " Do you want to create a lead ?", title: "Create a Lead" };
        var confirmOptions = { height: 200, width: 450 };
        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed)
                    ContactForm.Events.CreateLead(executionContext);
                else
                    console.log("closing");
            });
    },

    CreateLead: function (executionContext) {

        var formContext = executionContext;
        
        var functionalarea = CommonForm.Events.GetFieldValue(formContext, "niq_functionalarea");
        var managementlevel = CommonForm.Events.GetFieldValue(formContext, "niq_managementlevel");
        var country = CommonForm.Events.GetFieldValue(formContext, "niq_countryid");
        var internalinitiative = CommonForm.Events.GetFieldValue(formContext, "niq_internalinitiative");
        var acnt = CommonForm.Events.GetFieldValue(formContext, "parentcustomerid");
        var acntname = acnt != null ? acnt[0].name : null;
        var countryid = country != null ? "/niq_countries(" + country[0].id.replace("{", "").replace("}", "") + ")" : null;
        var internalinitiativeid = internalinitiative != null ? "/niq_internalinitiatives(" + internalinitiative[0].id.replace("{", "").replace("}", "") + ")" : null;

        var leadData = null;
        leadData = new Object();

        leadData["firstname"] = CommonForm.Events.GetFieldValue(formContext, "firstname");
        leadData["lastname"] = CommonForm.Events.GetFieldValue(formContext, "lastname");
        leadData["emailaddress1"] = CommonForm.Events.GetFieldValue(formContext, "emailaddress1");
        leadData["jobtitle"] = CommonForm.Events.GetFieldValue(formContext, "jobtitle");
        leadData["mobilephone"] = CommonForm.Events.GetFieldValue(formContext, "mobilephone");
        leadData["niq_Country@odata.bind"] = countryid;
        leadData["niq_InternalInitiative@odata.bind"] = internalinitiativeid;
        leadData["leadsourcecode"] = 0;
        leadData["companyname"] = acntname;
        if (functionalarea != null)
            leadData["niq_functionalarea"] = functionalarea;

        if (managementlevel != null)
            leadData["niq_managementlevel"] = managementlevel;


        Xrm.Utility.showProgressIndicator("Please wait....Creating a Lead");
        Xrm.WebApi.createRecord("lead", leadData).then(
            function success(result) {
                Xrm.Utility.closeProgressIndicator();

                var entityLeadFormOptions = {};
                entityLeadFormOptions["entityName"] = "lead";
                entityLeadFormOptions["entityId"] = result.id;

                // Open the form.
                Xrm.Navigation.openForm(entityLeadFormOptions).then(
                    function (success) {
                        console.log(success);
                    },
                    function (error) {
                        console.log(error);
                    });
            },
            function (error) {
                Xrm.Utility.closeProgressIndicator();
            }
        );


    },

    HideContactEditableMainForm: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var formItems = [];
        formItems = formContext.ui.formSelector.items;

        formItems.forEach(function (item) {
            if (item._label === "Contact Editable main form") {
                item.setVisible(false);
            }
        });

    }


}