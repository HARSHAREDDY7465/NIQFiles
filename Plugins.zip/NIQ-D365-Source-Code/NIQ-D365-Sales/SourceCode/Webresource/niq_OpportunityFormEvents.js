if (typeof (OpportunityForm) === "undefined") {
    OpportunityForm = {
        __namespace: true
    };
}

OpportunityForm.Events = {
    FormOnload: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext(); // getting FormCOntext
        this.InvoiceInfoVerifiedFieldReadOnly(executionContext); //making Invoice info verified field read only
        this.CustomViewCommon(formContext, "niq_soldtoparty"); // Adding Custom Views for Sold To Party Views       
        this.CustomViewInvoiceReceipient(executionContext);
        this.CustomViewAccountGoals(formContext, "niq_accountgoalid");
        this.OnChangeContractAction(executionContext);
        formContext.data.process.addOnStageChange(this.OnBpfStageChange);
        formContext.data.process.addOnPreStageChange(this.TothrowerrorforAgreementtype);
        formContext.data.process.addOnPreStageChange(this.TothrowerrorforHostOpportunity);
        this.OnChangeOfStage(executionContext);
        this.ShowDeliveryNotification(executionContext);
        //this.ExistingContractAnnualValueVisibility(executionContext);
        this.HideandShowOppoProductEnhancementTab(executionContext);
        this.OnChangeOfApprovalStatusShowNotification(executionContext);
        this.SalesOrgSalesGroupRequired(executionContext);
        this.TempOrFinallyExecutedURLValidation(executionContext);
        this.SetURLCheckboxNegotiationStage(executionContext);
        this.OnCreateofOpportunity(executionContext);        
        this.setDefaultAMView(executionContext);
        this.displayMessageBlockedQuoteProduct(executionContext);
        this.checkforActiveOPERecords(executionContext);
        this.ShowhideProjectDetailSection(executionContext);
        this.PopulateEstCloseDateFromDefaultSettings(executionContext);
        this.ShowSectionsBasedOnPartyValues(executionContext);
        this.ShowHideCompetitor1Field(executionContext);

        if (formContext.getControl("quote") !== null)
            formContext.getControl("quote").setDisabled(true);
        var formType = formContext.ui.getFormType();
        if (formType !== 1 && formType !== 4) {

            this.setMainQuoteFilter(executionContext);
            if (CommonForm.Events.CheckValueExists(formContext, "niq_approvalstatus")) {
                var approvalStatus = formContext.getAttribute("niq_approvalstatus").getValue();
                var sapStatus = CommonForm.Events.CheckValueExists(formContext, "niq_sapintegrationstatus") ? formContext.getAttribute("niq_sapintegrationstatus").getValue() : 1;
                var stage = CommonForm.Events.CheckValueExists(formContext, "niq_stage") ? formContext.getAttribute("niq_stage").getValue() : "";
                if (approvalStatus === 100000001 || (approvalStatus === 100000002 && sapStatus != 100000000 && stage === "Closed Won - In Review")) {
                    CommonForm.Events.disableFormFields(true, formContext);
                    this.RefreshRibbon(executionContext);
                }
            }


            formContext.data.entity.addOnSave(this.ValidateIsDirty);
            this.showNotification(executionContext);
            this.ValidateSalesOrgAccounts(executionContext, "niq_soldtoparty", "Sold To Party"); // Validating Sold to Party SAP Account
            this.ValidateSalesOrgAccounts(executionContext, "niq_deliverytoparty", "Delievery To Party"); // Validating Delievery to Party SAP Account
            this.ValidateSalesOrgAccounts(executionContext, "niq_billtoparty", "Bill To Party");// Validating BIll To Party SAP Account
            //this.SetDefaultValueofPE(executionContext);
            //QCP Mandatory Char Value Added Check
            formContext.getControl("header_process_niq_mandatorycharvaluesadded").setDisabled(true);
            formContext.getControl("header_process_niq_signedagreementcreatedandexecutedfromquot").setDisabled(true);
            this.bPFStageErrorNotification(executionContext);
            formContext.data.entity.addOnSave(this.TothrowerrorforAgreementtypeandLanguage);
        }
    },
    setDefaultAMView: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.getControl("header_process_niq_primarycontactid");
        var defaultView = formContext.getControl("niq_primarycontactid").getDefaultView();
        formContext.getControl("header_process_niq_primarycontactid").setDefaultView(defaultView);
        formContext.getControl("header_process_niq_fieldingcountry");
        var defaultView1 = formContext.getControl("niq_fieldingcountry").getDefaultView();
        formContext.getControl("header_process_niq_fieldingcountry").setDefaultView(defaultView1);
    },
    setVisibilityRevenueShareDealField: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_revenuesharedeal") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator")) {
            formContext.getControl("niq_revenuesharedeal").setVisible(true);
        }
        else {
            formContext.getControl("niq_revenuesharedeal").setVisible(false);
        }
    },

    ShowDeliveryNotification: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_businessarea") &&
            formContext.getAttribute("niq_businessarea").getValue() != 100000000 &&
            CommonForm.Events.CheckValueExists(formContext, "statecode") &&
            formContext.getAttribute("statecode").getValue() === 1) {
            var opportunityId = formContext.data.entity.getId().replace("{", "").replace("}", "");
            var req = new XMLHttpRequest();
            req.open("GET", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/niq_deliveries?$select=niq_deliveryid&$filter=(_niq_opportunityid_value eq " + opportunityId + ")", false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Prefer", "odata.include-annotations=*");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        var results = JSON.parse(this.response);
                        console.log(results);
                        if (results.value.length > 0) {
                            formContext.ui.setFormNotification("By uploading an Evidence of Delivery (EOD) file to a Delivery you certify that this Evidence of Delivery is true, accurate & reflects the delivery requirements per the contractual terms and conditions. Falsification of evidence of delivery is subject to disciplinary action per NIQ's Code of Conduct.", "INFO", "deliverystatusnotify");

                        }
                        else {
                            formContext.ui.clearFormNotification("deliverystatusnotify");
                        }
                    } else {
                        console.log(this.responseText);
                    }
                }
            };
            req.send();

        }
        else {
            formContext.ui.clearFormNotification("deliverystatusnotify");
        }
    },
    OnSaveShowNotificationForCompetitorsTab: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        formContext.ui.setFormNotification("In case of a competitive deal indicate competitors on the Competitors tab of this opportunity", "INFO", "notification");
        setTimeout(
            function () {
                formContext.ui.clearFormNotification("notification");
            },
            10000
        );
    },

    ShowHideCompetitor1Field: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (formContext.data.process.getActiveStage().getName().toLowerCase() === "pre-proposal" || formContext.data.process.getActiveStage().getName().toLowerCase() === "proposal") {
            formContext.getControl("header_process_niq_competitor1").setVisible(false);
        }
        else {
            formContext.getControl("header_process_niq_competitor1").setVisible(true);
        }
    },
 showNotification: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_opportunitytype") && formContext.getAttribute("niq_opportunitytype").getValue() === 2 && CommonForm.Events.CheckValueExists(formContext, "niq_existingcontractaction") && (formContext.getAttribute("niq_existingcontractaction").getValue() === 2 || formContext.getAttribute("niq_existingcontractaction").getValue() === 4))
            formContext.ui.setFormNotification("The revenue for the existing contract that you are managing via this opportunity is accounted for in SAP. For accurate forecasting you need to reflect the revenue difference between this opportunity and revenue already present in SAP on the \"SAP Deferred Revenue reconciliation placeholder\"", "INFO", "DYNMSM-2138");
        else
            formContext.ui.clearFormNotification("DYNMSM-2138");
    },

    setMainQuoteFilter: function (executionContext) {
        // get the form context
        formContext = executionContext.getFormContext();
        if (formContext.getControl("niq_mainquoteid") !== null) {
            formContext.getControl("niq_mainquoteid").addPreSearch(this.filterQuotes);
        }
    },
    filterQuotes: function () {
        // Only show Draft or Active Quotes Related to Oportunity  
        var oppoId = formContext.data.entity.getId();
        var quoteFilter = "<filter type='and'> <condition attribute='opportunityid' operator='eq' uitype='opportunity' value='" + oppoId + "' /> <condition attribute='statecode' operator='in'> <value>1</value> <value>0</value></condition> </filter>";
        formContext.getControl("niq_mainquoteid").addCustomFilter(quoteFilter, "quote");
    },
    CustomViewBillToParty: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "parentaccountid") && CommonForm.Events.CheckFieldExists(formContext, "niq_billtoparty")) {

            var viewId2 = formContext.getControl("niq_billtoparty").getDefaultView();
            var entName = "account";
            var vwName = "Related SAP accounts inc. NIC";
            var resFetch = "";
            var viewId3 = "{00000000-0000-0000-0000-000000000003}";
            var vwNamebill = "Opportunity's Sales org SAP accounts";
            var resFetch1 = "";
            var noRecords = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                "<entity name='account'>" +
                "<attribute name='name' />" +
                "<attribute name='primarycontactid' />" +
                "<attribute name='telephone1' />" +
                "<attribute name='accountid' />" +
                "<order attribute='name' descending='false' />" +
                "<filter type='and'>" +
                "<condition attribute='niq_accounttype' operator='eq' value='21' />" +
                "</filter>" +
                "</entity>" +
                "</fetch>";
            var resLayout = "<grid name='resultset' object='10030' jump='mtctb_name' select='1' icon='1' preview='1'>" +
                "<row name='result' id='new_user'>" +
                "<cell name='name' width='200'/>" +
                "<cell name='niq_vatregistrationnumber' width='100'/>" +
                "<cell name='niq_sap_id__c' width='100'/>" +
                "<cell name='niq_countryid' width='125'/>" +
                "</row>" +
                "</grid>";
            if (CommonForm.Events.CheckValueExists(formContext, "parentaccountid")) {

                var parentAccountId = formContext.getAttribute("parentaccountid").getValue()[0].id;

                Xrm.WebApi.online.retrieveRecord("account", parentAccountId, "?$select=_niq_ultimateparentid_value").then(
                    function success(result) {
                        var ultimateParentId = result["_niq_ultimateparentid_value"];


                        if (ultimateParentId !== null) {
                            resFetch = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                "<entity name='account'>" +
                                "<attribute name='name' />" +
                                "<attribute name='accountid' />" +
                                "<attribute name='address1_line1' />" +
                                "<attribute name='niq_vatregistrationnumber' />" +
                                "<attribute name='niq_sap_id__c' />" +
                                "<attribute name='niq_countryid' />" +
                                "<attribute name='address1_city' />" +
                                "<order attribute='name' descending='false' />" +
                                "<filter type='and'>" +
                                "<filter type='or'>" +
                                "<filter type='and'>" +
                                "<condition attribute='niq_ultimateparentid' operator='eq' uitype='account' value='{" + ultimateParentId + "}' />" +
                                "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                "</filter>" +
                                "<filter type='and'>" +
                                "<condition attribute='niq_sap_id__c' operator='like' value='%NIC%' />" +
                                "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                "</filter>" +
                                "</filter>" +
                                "</filter>" +
                                "</entity>" +
                                "</fetch>"
                        }
                        else {
                            resFetch = noRecords
                        }




                        if (formContext.getAttribute("niq_salesorgid") !== null && formContext.getAttribute("niq_salesorgid").getValue() !== null) {
                            var salesOrgId = formContext.getAttribute("niq_salesorgid").getValue()[0].id;

                            resFetch1 = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                                "<entity name='account'>" +
                                "<attribute name='name' />" +
                                "<attribute name='accountid' />" +
                                "<attribute name='address1_line1' />" +
                                "<attribute name='niq_vatregistrationnumber' />" +
                                "<attribute name='niq_sap_id__c' />" +
                                "<attribute name='niq_countryid' />" +
                                "<attribute name='address1_city' />" +
                                "<order attribute='name' descending='false' />" +
                                "<filter type='and'>" +
                                "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                "<condition attribute='niq_ultimateparentid' operator='eq' uitype='account' value='{" + ultimateParentId + "}' />" +
                                "</filter>" +
                                "<link-entity name='niq_saleorgassignment' from='niq_account' to='accountid' link-type='inner' alias='ac'>" +
                                "<filter type='and'>" +
                                "<condition attribute='niq_salesorg' operator='eq' uitype='niq_salesorg' value='" + salesOrgId + "' />" +
                                "<condition attribute='niq_accountblocked' operator='eq' value='0' />" +
                                "</filter>" +
                                "</link-entity>" +
                                "</entity>" +
                                "</fetch>";


                        }
                        else {
                            resFetch1 = noRecords;
                        }

                        formContext.getControl("niq_billtoparty").addCustomView(viewId2, entName, vwName, resFetch, resLayout, true);
                        formContext.getControl("niq_billtoparty").addCustomView(viewId3, entName, vwNamebill, resFetch1, resLayout, false);




                    },
                    function (error) {
                        Xrm.Utility.alertDialog(error.message);
                    }
                );


            }
            if (!CommonForm.Events.CheckValueExists(formContext, "parentaccountid")) {

                formContext.getControl("niq_billtoparty").addCustomView(viewId2, entName, vwName, noRecords, resLayout, true);
                formContext.getControl("niq_billtoparty").addCustomView(viewId3, entName, vwNamebill, noRecords, resLayout, false);

            }
        }
    },
    InvoiceInfoVerifiedFieldReadOnly: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        formContext.getControl("header_process_niq_invoiceinformationverified").setDisabled(true);

    },
    OnChangeofSoldtoParty: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_soldtoparty") && CommonForm.Events.CheckValueExists(formContext, "niq_soldtoparty")) {
            var soldToParty = formContext.getAttribute("niq_soldtoparty").getValue();

            if (CommonForm.Events.CheckFieldExists(formContext, "niq_billtoparty") && !CommonForm.Events.CheckValueExists(formContext, "niq_billtoparty")) {
                formContext.getAttribute("niq_billtoparty").setValue(soldToParty);
            }

            if (CommonForm.Events.CheckFieldExists(formContext, "niq_deliverytoparty") && !CommonForm.Events.CheckValueExists(formContext, "niq_deliverytoparty")) {
                formContext.getAttribute("niq_deliverytoparty").setValue(soldToParty);
            }


        }
    },
    ValidateContractEndDate: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_contractenddate") && CommonForm.Events.CheckFieldExists(formContext, "niq_contractstartdate")) {
            var contractEndDate = formContext.getAttribute("niq_contractenddate").getValue();
            var contractStartDate = formContext.getAttribute("niq_contractstartdate").getValue();

            if ((contractEndDate !== null) && (contractStartDate !== null) && (contractStartDate > contractEndDate)) {
                formContext.getControl("niq_contractenddate").setNotification("The Contract End Date cannot be before Contract Start Date.", "validateContractEndDate");
                formContext.getAttribute("niq_contractenddate").setValue(null);
            }
            else {
                formContext.getControl("niq_contractstartdate").clearNotification("validateContracStarttDate");
                formContext.getControl("niq_contractenddate").clearNotification("validateContractEndDate");
            }
        }
    },
    ValidateContractStartDate: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_contractenddate") && CommonForm.Events.CheckFieldExists(formContext, "niq_contractstartdate")) {
            var contractEndDate = formContext.getAttribute("niq_contractenddate").getValue();
            var contractStartDate = formContext.getAttribute("niq_contractstartdate").getValue();

            if (((contractStartDate !== null) && contractEndDate !== null) && (contractStartDate > contractEndDate)) {
                formContext.getControl("niq_contractstartdate").setNotification("The Contract Start Date cannot be after Contract End Date.", "validateContracStarttDate");
                formContext.getAttribute("niq_contractstartdate").setValue(null);
            }
            else {
                formContext.getControl("niq_contractenddate").clearNotification("validateContractEndDate");
                formContext.getControl("niq_contractstartdate").clearNotification("validateContracStarttDate");
            }
        }
    },
    CustomViewCommon: function (formContext, fieldName) {
        "use strict";
        var entName = "account";
        var vwNic = "NIC SAP Accounts(internal)";
        var vwNicId = "{00000000-0000-0000-0000-000000000023}";
        var resLayout = "<grid name='resultset' object='1' jump='name' select='1' icon='1' preview='1'>" +
            "<row name='result' id='accountid'>" +
            "<cell name='name' width='300'/>" +
            "<cell name='address1_line1' width='100'/>" +
            "<cell name='address1_city' width='100'/>" +
            "<cell name='niq_countryid' width='100'/>" +
            "<cell name='niq_sap_id__c' width='100'/>" +
            "<cell name='niq_vatregistrationnumber' width='100'/>" +
            "</row>" +
            "</grid>";
        var sapNicResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
            "<entity name='account'>" +
            "<attribute name='name' />" +
            "<attribute name='address1_line1' />" +
            "<attribute name='address1_city' />" +
            "<attribute name='niq_countryid' />" +
            "<attribute name='niq_sap_id__c' />" +
            "<attribute name='niq_vatregistrationnumber' />" +
            "<attribute name='accountid' />" +
            "<order attribute='name' descending='false' />" +
            "<filter type='and'>" +
            "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
            "<condition attribute='niq_sap_id__c' operator='like' value='%NIC%' />" +
            "</filter>" +
            "</entity>" +
            "</fetch>";
        if (CommonForm.Events.CheckFieldExists(formContext, "parentaccountid") && CommonForm.Events.CheckFieldExists(formContext, fieldName)) {
            var relSAPResult = "";
            var sapExtResult = "";
            var vwSAPExtId = "{00000000-0000-0000-0000-000000000001}";
            var vwSAPExt = "Related SAP Accounts ext to sales org";
            var vwRelSAPId = formContext.getControl(fieldName).getDefaultView();

            var vwRelSAP = "Related SAP Accounts";

            var noResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                "<entity name='account'>" +
                "<attribute name='name' />" +
                "<attribute name='primarycontactid' />" +
                "<attribute name='telephone1' />" +
                "<attribute name='accountid' />" +
                "<order attribute='name' descending='false' />" +
                "<filter type='and'>" +
                "<condition attribute='niq_accounttype' operator='eq' value='21' />" +
                "</filter>" +
                "</entity>" +
                "</fetch>";

            if (CommonForm.Events.CheckValueExists(formContext, "parentaccountid")) {

                var parentAccountId = formContext.getAttribute("parentaccountid").getValue()[0].id;

                Xrm.WebApi.online.retrieveRecord("account", parentAccountId, "?$select=_niq_ultimateparentid_value").then(
                    function success(result) {
                        var ultimateParentId = result["_niq_ultimateparentid_value"];

                        if (ultimateParentId !== null) {
                            relSAPResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                "<entity name='account'>" +
                                "<attribute name='name' />" +
                                "<attribute name='accountid' />" +
                                "<attribute name='address1_line1' />" +
                                "<attribute name='niq_vatregistrationnumber' />" +
                                "<attribute name='niq_sap_id__c' />" +
                                "<attribute name='niq_countryid' />" +
                                "<attribute name='address1_city' />" +
                                "<order attribute='name' descending='false' />" +
                                "<filter type='and'>" +
                                "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                "<condition attribute='niq_ultimateparentid' operator='eq'  uitype='account' value='{" + ultimateParentId + "}' />" +
                                "<condition attribute='statuscode' operator='eq' value='1'/>" +
                                "</filter>" +
                                "</entity>" +
                                "</fetch>";
                            if (formContext.getAttribute("niq_salesorgid") !== null && formContext.getAttribute("niq_salesorgid").getValue() !== null) {
                                var salesOrgId = formContext.getAttribute("niq_salesorgid").getValue()[0].id;

                                sapExtResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                                    "<entity name='account'>" +
                                    "<attribute name='name' />" +
                                    "<attribute name='accountid' />" +
                                    "<attribute name='address1_line1' />" +
                                    "<attribute name='niq_vatregistrationnumber' />" +
                                    "<attribute name='niq_sap_id__c' />" +
                                    "<attribute name='niq_countryid' />" +
                                    "<attribute name='address1_city' />" +
                                    "<order attribute='name' descending='false' />" +
                                    "<filter type='and'>" +
                                    "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                    "<condition attribute='niq_ultimateparentid' operator='eq' uitype='account' value='{" + ultimateParentId + "}' />" +
                                    "</filter>" +
                                    "<link-entity name='niq_saleorgassignment' from='niq_account' to='accountid' link-type='inner' alias='ac'>" +
                                    "<filter type='and'>" +
                                    "<condition attribute='niq_salesorg' operator='eq' uitype='niq_salesorg' value='" + salesOrgId + "' />" +
                                    "<condition attribute='niq_accountblocked' operator='eq' value='0' />" +
                                    "</filter>" +
                                    "</link-entity>" +
                                    "</entity>" +
                                    "</fetch>";


                            }
                        }
                        else {
                            relSAPResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                "<entity name='account'>" +
                                "<attribute name='name' />" +
                                "<attribute name='accountid' />" +
                                "<attribute name='address1_line1' />" +
                                "<attribute name='niq_vatregistrationnumber' />" +
                                "<attribute name='niq_sap_id__c' />" +
                                "<attribute name='niq_countryid' />" +
                                "<attribute name='address1_city' />" +
                                "<order attribute='name' descending='false' />" +
                                "<filter type='and'>" +
                                "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                "<condition attribute='niq_ultimateparentid' operator='eq'  uitype='account' value='" + parentAccountId + "' />" +
                                "<condition attribute='statuscode' operator='eq' value='1'/>" +
                                "</filter>" +
                                "</entity>" +
                                "</fetch>";
                            if (formContext.getAttribute("niq_salesorgid") !== null && formContext.getAttribute("niq_salesorgid").getValue() !== null) {
                                var salesOrgId = formContext.getAttribute("niq_salesorgid").getValue()[0].id;

                                sapExtResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                                    "<entity name='account'>" +
                                    "<attribute name='name' />" +
                                    "<attribute name='accountid' />" +
                                    "<attribute name='address1_line1' />" +
                                    "<attribute name='niq_vatregistrationnumber' />" +
                                    "<attribute name='niq_sap_id__c' />" +
                                    "<attribute name='niq_countryid' />" +
                                    "<attribute name='address1_city' />" +
                                    "<order attribute='name' descending='false' />" +
                                    "<filter type='and'>" +
                                    "<condition attribute='niq_accounttype' operator='eq' value='2' />" +
                                    "<condition attribute='niq_ultimateparentid' operator='eq' uitype='account' value='" + parentAccountId + "' />" +
                                    "</filter>" +
                                    "<link-entity name='niq_saleorgassignment' from='niq_account' to='accountid' link-type='inner' alias='ac'>" +
                                    "<filter type='and'>" +
                                    "<condition attribute='niq_salesorg' operator='eq' uitype='niq_salesorg' value='" + salesOrgId + "' />" +
                                    "<condition attribute='niq_accountblocked' operator='eq' value='0' />" +
                                    "</filter>" +
                                    "</link-entity>" +
                                    "</entity>" +
                                    "</fetch>";


                            }
                        }


                        formContext.getControl(fieldName).addCustomView(vwRelSAPId, entName, vwRelSAP, relSAPResult, resLayout, false);
                        formContext.getControl(fieldName).addCustomView(vwSAPExtId, entName, vwSAPExt, sapExtResult, resLayout, false);




                    },
                    function (error) {
                        Xrm.Utility.alertDialog(error.message);
                    }
                );


            }
            else {

                formContext.getControl(fieldName).addCustomView(vwRelSAPId, entName, vwRelSAP, noResult, resLayout, false);
                formContext.getControl(fieldName).addCustomView(vwSAPExtId, entName, vwSAPExt, noResult, resLayout, false);

            }


        }
        formContext.getControl(fieldName).addCustomView(vwNicId, entName, vwNic, sapNicResult, resLayout, false);
    },
    CustomViewAccountGoals: function (formContext, fieldName) {
        var entName = "niq_niqaccountgoal";
        var vwRelAcc = "All NIQ Account Goals";
        var vwRelAccId = formContext.getControl(fieldName).getDefaultView();
        if (CommonForm.Events.CheckValueExists(formContext, "parentaccountid") && CommonForm.Events.CheckFieldExists(formContext, fieldName)) {

            var accountId = formContext.getAttribute("parentaccountid").getValue()[0].id;
            var resLayout = "<grid name='resultset' object='10910' jump='niq_niqaccountgoalname' select='1' icon='1' preview='1'>" +
                "<row name='result' id='niq_niqaccountgoalid'>" +
                "<cell name='niq_niqaccountgoalname' width='300'/>" +
                "<cell name='niq_clientobjective' width='100'/>" +
                "<cell name='niq_potentialrevenueassociated' width='100'/>" +
                "<cell name='statecode' width='100'/>" +
                "<cell name='createdon' width='125'/>" +
                "</row>" +
                "</grid>";
            var relAccResult = "";
            Xrm.WebApi.online.retrieveRecord("account", accountId, "?$select=_niq_ultimateparentid_value").then(
                function success(result) {
                    var ultimateParentId = result["_niq_ultimateparentid_value"];

                    if (ultimateParentId !== null) {
                        relAccResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                            "<entity name='niq_niqaccountgoal'>" +
                            "<attribute name='niq_niqaccountgoalid' />" +
                            "<attribute name='niq_niqaccountgoalname' />" +
                            "<attribute name='createdon' />" +
                            "<attribute name='statecode' />" +
                            "<attribute name='niq_potentialrevenueassociated' />" +
                            "<attribute name='niq_clientobjective' />" +
                            "<order attribute='niq_niqaccountgoalname' descending='false' />" +
                            "<link-entity name='account' from='accountid' to='niq_accountameid' link-type='inner' alias='ab'>" +
                            "<filter type='and'>" +
                            "<condition attribute='accountid' operator='eq-or-under' uitype='account' value='" + ultimateParentId + "' />" +
                            "</filter>" +
                            "</link-entity>" +
                            "</entity>" +
                            "</fetch>";


                    }
                    else {

                        relAccResult = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                            "<entity name='niq_niqaccountgoal'>" +
                            "<attribute name='niq_niqaccountgoalid' />" +
                            "<attribute name='niq_niqaccountgoalname' />" +
                            "<attribute name='createdon' />" +
                            "<attribute name='statecode' />" +
                            "<attribute name='niq_potentialrevenueassociated' />" +
                            "<attribute name='niq_clientobjective' />" +
                            "<order attribute='niq_niqaccountgoalname' descending='false' />" +
                            "<link-entity name='account' from='accountid' to='niq_accountameid' link-type='inner' alias='ab'>" +
                            "<filter type='and'>" +
                            "<condition attribute='accountid' operator='eq-or-under' uitype='account' value='" + accountId + "' />" +
                            "</filter>" +
                            "</link-entity>" +
                            "</entity>" +
                            "</fetch>";


                    }


                    formContext.getControl(fieldName).addCustomView(vwRelAccId, entName, vwRelAcc, relAccResult, resLayout, false);


                },
                function (error) {
                    Xrm.Utility.alertDialog(error.message);
                }
            );




        }
    },
    CustomViewInvoiceReceipient: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        if (CommonForm.Events.CheckFieldExists(formContext, "parentaccountid") &&
            CommonForm.Events.CheckValueExists(formContext, "parentaccountid")) {
            var parentaccountId = formContext.getAttribute("parentaccountid").getValue()[0].id;
            var viewId = formContext.getControl("parentcontactid").getDefaultView();
            var viewId2 = formContext.getControl("niq_invoicerecipient2").getDefaultView();
            var viewId3 = formContext.getControl("niq_invoicerecipient3").getDefaultView();
            var viewId4 = formContext.getControl("niq_invoicerecipient4").getDefaultView();
            var viewId5 = formContext.getControl("niq_invoicerecipient5").getDefaultView();
            var viewId6 = formContext.getControl("niq_nameoninvoiceifdifffrominvoicerecipient").getDefaultView();

            var entity = "contact";
            var ViewDisplayName = "All Contacts";
            var layout = "<grid name='resultset' object='2' jump='lastname' select='1' icon='1' preview='1'>" +
                "<row name='result' id='contactid'>" +
                "<cell name='fullname' width='300'/>" +
                "<cell name='emailaddress1' width='100'/>" +
                "</row>" +
                "</grid>";

            var fetchXML = "";
            Xrm.WebApi.online.retrieveRecord("account", parentaccountId, "?$select=_niq_ultimateparentid_value").then(
                function success(result) {
                    var ultimateParentId = result["_niq_ultimateparentid_value"];

                    if (ultimateParentId !== null) {
                        fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                            "<entity name='contact'>" +
                            "<attribute name='fullname' />" +
                            "<attribute name='contactid' />" +
                            "<attribute name='emailaddress1' />" +
                            "<order attribute='fullname' descending='false' />" +
                            "<link-entity name='account' from='accountid' to='parentcustomerid' link-type='inner' alias='ac'>" +
                            "<filter type='and'>" +
                            "<condition attribute='accountid' operator='eq-or-under' uitype='account' value='{" + ultimateParentId + "}' />" +
                            "</filter>" +
                            "</link-entity>" +
                            "</entity>" +
                            "</fetch>";



                    }
                    else {

                        fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                            "<entity name='contact'>" +
                            "<attribute name='fullname' />" +
                            "<attribute name='contactid' />" +
                            "<attribute name='emailaddress1' />" +
                            "<order attribute='fullname' descending='false' />" +
                            "<link-entity name='account' from='accountid' to='parentcustomerid' link-type='inner' alias='ac'>" +
                            "<filter type='and'>" +
                            "<condition attribute='accountid' operator='eq-or-under' uitype='account' value='" + parentaccountId + "' />" +
                            "</filter>" +
                            "</link-entity>" +
                            "</entity>" +
                            "</fetch>";



                    }


                    formContext.getControl("parentcontactid").addCustomView(viewId, entity, ViewDisplayName, fetchXML, layout, false);
                    formContext.getControl("niq_invoicerecipient2").addCustomView(viewId2, entity, ViewDisplayName, fetchXML, layout, false);
                    formContext.getControl("niq_invoicerecipient3").addCustomView(viewId3, entity, ViewDisplayName, fetchXML, layout, false);
                    formContext.getControl("niq_invoicerecipient4").addCustomView(viewId4, entity, ViewDisplayName, fetchXML, layout, false);
                    formContext.getControl("niq_invoicerecipient5").addCustomView(viewId5, entity, ViewDisplayName, fetchXML, layout, false);
                    formContext.getControl("niq_nameoninvoiceifdifffrominvoicerecipient").addCustomView(viewId6, entity, ViewDisplayName, fetchXML, layout, false);

                },
                function (error) {
                    Xrm.Utility.alertDialog(error.message);
                }
            );

        }
    },
    _LockApprovalStatusOnBPF: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.getControl("header_process_niq_approvalstatus").setDisabled(true);
        formContext.getControl("header_process_niq_submissiontime").setDisabled(true);
        formContext.getControl("header_process_statecode").setVisible(false);
    },
    ValidateIsDirty: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_approvalstatus")) {
            var isDirty = formContext.getAttribute("niq_approvalstatus").getIsDirty();
            if (isDirty) {
                formContext.data.entity.addOnPostSave(OpportunityForm.Events.OnApprovalStatusChange);
            }
        }

    },
    OnApprovalStatusChange: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_approvalstatus")) {
            var oppoId = formContext.data.entity.getId().replace("{", "").replace("}", "");
            formContext.data.refresh(true).then(function refreshOppo() {
                var entityFormOptions = {};
                entityFormOptions["entityName"] = "opportunity";
                entityFormOptions["entityId"] = oppoId;

                // Open the form.
                Xrm.Navigation.openForm(entityFormOptions);
            });
        }
    },
    RefreshRibbon: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        formContext.ui.refreshRibbon();
    },
    ValidateSalesOrgAccounts: function (executionContext, fieldName, field) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var fieldVerified = " ";
        switch (fieldName) {
            case "niq_soldtoparty": fieldVerified = "niq_soldtopartyverified";
                break;
            case "niq_billtoparty": fieldVerified = "niq_billtopartyverified";
                break;
            case "niq_deliverytoparty": fieldVerified = "niq_delivertopartyverified";
                break;
            default: fieldVerified = " ";
                break;
        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_salesorgid") && CommonForm.Events.CheckValueExists(formContext, fieldName)) {
            var salesOrgId = formContext.getAttribute("niq_salesorgid").getValue()[0].id;
            var fieldId = formContext.getAttribute(fieldName).getValue()[0].id;
            salesOrgId = salesOrgId.replace("{", "").replace("}", "");
            fieldId = fieldId.replace("{", "").replace("}", "");


            Xrm.WebApi.online.retrieveMultipleRecords("niq_saleorgassignment", "?$select=niq_accountblocked&$filter=_niq_salesorg_value eq " + salesOrgId + " and  _niq_account_value eq " + fieldId + "&$top=1").then(
                function success(results) {
                    if (results.entities.length) {


                        var accBlocked = results.entities[0]["niq_accountblocked"];
                        if (accBlocked) {
                            if (fieldVerified !== " " && CommonForm.Events.CheckFieldExists(formContext, fieldVerified)) {
                                formContext.getAttribute(fieldVerified).setValue(false);
                            }
                            formContext.ui.setFormNotification("Selected " + field + "Account is blocked for Sales Org. Please submit an unblocking request for the selected SAP account.", "ERROR", field + "error");
                        } else {
                            if (fieldVerified !== " " && CommonForm.Events.CheckFieldExists(formContext, fieldVerified)) {
                                formContext.getAttribute(fieldVerified).setValue(true);
                                OpportunityForm.Events.RefreshRibbon(executionContext);
                            }
                        }

                    }
                    else {
                        if (fieldVerified !== " " && CommonForm.Events.CheckFieldExists(formContext, fieldVerified)) {
                            formContext.getAttribute(fieldVerified).setValue(false);
                        }
                        formContext.ui.setFormNotification("Selected " + field + " Account is not connected to Sales Org. Please submit an extension request for the selected SAP account.", "WARNING", field + "warning");
                    }
                },
                function (error) {
                    Xrm.Utility.alertDialog(error.message);
                }
            );

        }
        else {
            if (fieldVerified !== " " && CommonForm.Events.CheckFieldExists(formContext, fieldVerified)) {
                formContext.getAttribute(fieldVerified).setValue(false);
            }
            formContext.ui.clearFormNotification(field + "warning");
            formContext.ui.clearFormNotification(field + "error");


        }
    },
    OnChangeStageToNegotiation: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.data.process.addOnStageChange(this.OnBpfStageChange);
    },

    OnChangeContractAction: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        //if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete")) {
        //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").setDisabled(true);
        //}
        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_tempeoafinallyexecutedagreementprovided")) {
            formContext.getControl("header_process_niq_tempeoafinallyexecutedagreementprovided").setDisabled(true);
        }
        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_soldtopartyverified")) {
            formContext.getControl("header_process_niq_soldtopartyverified").setDisabled(true);
        } if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_billtopartyverified")) {
            formContext.getControl("header_process_niq_billtopartyverified").setDisabled(true);
        } if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_delivertopartyverified")) {
            formContext.getControl("header_process_niq_delivertopartyverified").setDisabled(true);
        }
        if (CommonForm.Events.CheckControlExists(formContext, "header_process_totalamount")) {
            formContext.getControl("header_process_totalamount").setDisabled(true);
        }
        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_contractstartdate")) {
            formContext.getControl("header_process_niq_contractstartdate").setDisabled(true);
        }
        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_contractenddate")) {
            formContext.getControl("header_process_niq_contractenddate").setDisabled(true);
        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_opportunitytype")) {
            var oppoType = formContext.getAttribute("niq_opportunitytype").getValue();
            if (oppoType === 2) {
                if (CommonForm.Events.CheckValueExists(formContext, "niq_existingcontractaction")) {
                    var contractaction = formContext.getAttribute("niq_existingcontractaction").getValue();
                    ////if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete") && (CommonForm.Events.CheckFieldExists(formContext, "niq_valueofapicola")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_valueofpricechange")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_valueofproductenhancements")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_valueofscopechange")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_onetimefees")) && (CommonForm.Events.CheckValueExists(formContext, "niq_existingcontractannualvalue")) && (CommonForm.Events.CheckValueExists(formContext, "niq_newcontractannualvalue"))) {
                    //    var sumOfApiCola = parseFloat((Math.round(formContext.getControl("niq_valueofapicola").getAttribute().getValue() * 100) / 100).toFixed(2));
                    //    var sumOfPriceChange = parseFloat((Math.round(formContext.getControl("niq_valueofpricechange").getAttribute().getValue() * 100) / 100).toFixed(2));
                    //    var sumOfProductEnhancement = parseFloat((Math.round(formContext.getControl("niq_valueofproductenhancements").getAttribute().getValue() * 100) / 100).toFixed(2));
                    //    var sumOfScopeChange = parseFloat((Math.round(formContext.getControl("niq_valueofscopechange").getAttribute().getValue() * 100) / 100).toFixed(2));
                    //    var sumOfOnetimefee = parseFloat((Math.round(formContext.getControl("niq_onetimefees").getAttribute().getValue() * 100) / 100).toFixed(2));
                    //    var sumServices = parseFloat((Math.round((sumOfApiCola + sumOfPriceChange + sumOfProductEnhancement + sumOfScopeChange + sumOfOnetimefee) * 100) / 100).toFixed(2));
                    //    var changeincontractvalue = parseFloat((Math.round(formContext.getControl("niq_changeincontractvalue").getAttribute().getValue() * 100) / 100).toFixed(2));

                    //    //if ((sumServices === changeincontractvalue) && CommonForm.Events.CheckValueExists(formContext, "niq_existingcontractannualvalue") && (formContext.getControl("niq_existingcontractannualvalue").getAttribute().getValue() !== 0) && CommonForm.Events.CheckValueExists(formContext, "niq_newcontractannualvalue")) {
                    //    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setValue(true);
                    //    //}
                    //    //else {
                    //    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setValue(false);

                    //    //}

                    //}
                    //else if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete")) {
                    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").setVisible(false);
                    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setRequiredLevel("none");
                    //    if (formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute() != null && formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().getValue())
                    //        formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setValue(false);
                    //}
                    if (contractaction === 2 || contractaction === 3) {
                        if (CommonForm.Events.CheckControlExists(formContext, "niq_contractdecision")) {

                            if (formContext.getControl("niq_contractdecision").getAttribute().getValue() !== 100000000) {
                                formContext.getControl("niq_contractdecision").addOption({ value: 100000000, text: 'No Changes To Existing Contract' });
                                formContext.getControl("niq_contractdecision").getAttribute().setValue(100000000);
                            }
                            else {
                                formContext.getControl("niq_contractdecision").removeOption(100000000);
                                formContext.getControl("niq_contractdecision").addOption({ value: 100000000, text: 'No Changes To Existing Contract' });
                                formContext.getControl("niq_contractdecision").getAttribute().setValue(100000000);
                            }

                        }


                    }
                    else if (CommonForm.Events.CheckControlExists(formContext, "niq_contractdecision")) {

                        formContext.getControl("niq_contractdecision").removeOption(100000000);
                    }
                    //if ((contractaction === 1 || contractaction === 2 || contractaction === 4) && CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete")) {
                    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").setVisible(true);
                    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setRequiredLevel("required");
                    //}
                    //else if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete")) {
                    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").setVisible(false);
                    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setRequiredLevel("none");
                    //}
                }
                else {
                    if (CommonForm.Events.CheckFieldExists(formContext, "niq_contractdecision")) {

                        formContext.getControl("niq_contractdecision").removeOption(100000000);
                    }
                    //if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete")) {
                    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").setVisible(false);
                    //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setRequiredLevel("none");

                    //}
                }

            }
            else {
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_contractdecision")) {

                    formContext.getControl("niq_contractdecision").removeOption(100000000);
                }
                //if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete")) {
                //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").setVisible(false);
                //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setRequiredLevel("none");

                //}
            }
        }
        else {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_contractdecision")) {

                formContext.getControl("niq_contractdecision").removeOption(100000000);
            }
            //if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_hasrevenuewalkanalysisbeencomplete")) {
            //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").setVisible(false);
            //    formContext.getControl("header_process_niq_hasrevenuewalkanalysisbeencomplete").getAttribute().setRequiredLevel("none");

            //}
        }
    },

    OnChangeOfStage: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        if ((!CommonForm.Events.CheckValueExists(formContext, "niq_originalopportunityid")) && (!CommonForm.Events.CheckValueExists(formContext, "niq_ultimateoriginalopportunityid")) && formContext.getAttribute("statecode") != null && (formContext.getAttribute("statecode").getValue() === 1)) {
            CommonForm.Events.ShowHideSections(formContext, "Summary", "Summary_section_14", true);
        }

        else {
            CommonForm.Events.ShowHideSections(formContext, "Summary", "Summary_section_14", false);
        }
    },
    HideandShowOppoProductEnhancementTab: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        if ((CommonForm.Events.CheckValueExists(formContext, "niq_opportunitytype")) && (CommonForm.Events.CheckValueExists(formContext, "niq_existingcontractaction"))) {
            var oppoType = formContext.getAttribute("niq_opportunitytype").getValue();
            var contractaction = formContext.getAttribute("niq_existingcontractaction").getValue();
            if (oppoType === 2 && contractaction !== 3) {

                CommonForm.Events.ShowHideTabs(formContext, "tab_9", true);
            }

            else {
                CommonForm.Events.ShowHideTabs(formContext, "tab_9", false);
            }
        }
    },
    OnBpfStageChange: function (executionContext) {
        "use strict";


        var formContext = executionContext.getFormContext();
        var activeProcess = (formContext.data.process.getActiveProcess() !== null) ? (formContext.data.process.getActiveProcess().getName()) : null;
        var activeStage = (formContext.data.process.getActiveStage() !== null) ? (formContext.data.process.getActiveStage().getName()) : null;
        if ((activeProcess === "Opportunity Business Process Flow") && ((activeStage === "Negotiation") || (activeStage === "Pre-Proposal") || (activeStage === "Proposal"))) {
            var oppoId = formContext.data.entity.getId().replace("{", "").replace("}", "");
            formContext.data.refresh(true).then(function refreshOppo() {
                var entityFormOptions = {};
                entityFormOptions["entityName"] = "opportunity";
                entityFormOptions["entityId"] = oppoId;
                // Open the form.
                Xrm.Navigation.openForm(entityFormOptions);
            });
        }


    },
    /*
ExistingContractAnnualValueVisibility: function (executionContext) {
        "use strict";
        //show/hide Existing Contract Annual Value on Opportunity form
        var formContext = executionContext.getFormContext();
        if ((CommonForm.Events.CheckFieldExists(formContext, "niq_opportunitytype")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_existingcontractannualvalue"))) {
            //Getting Opportunity Type Value
            var opportunityType = formContext.getAttribute("niq_opportunitytype").getValue();
            //Checking Opportunity Type is equal to Existing Contract Management Value 
            if ((opportunityType !== null) && (opportunityType === 2)) {
                formContext.getControl("niq_existingcontractannualvalue").setVisible(true);
                formContext.getAttribute("niq_existingcontractannualvalue").setRequiredLevel("required");
                if (CommonForm.Events.CheckControlExists(formContext, "niq_existingcontractannualvalue1")) {
                    if (CommonForm.Events.CheckFieldExists(formContext, "niq_existingcontractaction")) {
                        //Getting Existing Contract action Value
                        var contractAction = formContext.getAttribute("niq_existingcontractaction").getValue();
                        //Checking Existing Contract Action is not Instruct SAP revenue booking for existing evergreen contract
                        if ((contractAction === 1) || (contractAction === 2) || (contractAction === 4)) {
                            formContext.getControl("niq_existingcontractannualvalue1").setVisible(true);
                        }
                        else {
                            formContext.getControl("niq_existingcontractannualvalue1").setVisible(false);
                        }
                    }
                }
            }
            else {
                formContext.getControl("niq_existingcontractannualvalue").setVisible(false);
                formContext.getAttribute("niq_existingcontractannualvalue").setRequiredLevel("none");
                formContext.getAttribute("niq_existingcontractannualvalue").setValue(null);
            }
        }
    },
*/
    OnChangeOfApprovalStatusShowNotification: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_approvalstatus")) {
            var approvalstatus = formContext.getAttribute("niq_approvalstatus").getValue();


            if (approvalstatus === 100000001) {
                formContext.ui.setFormNotification("Opportunity was submitted to Gatekeeper for approval. You need to recall it to be able to edit it or any records related to it.", "INFO", "onChangeOfApprovalStatusShowNotification");
                CommonForm.Events.EnableOrDisableSection(formContext, "tab_9", "tab_9_section_1", true);

            }
            else {
                formContext.ui.clearFormNotification("onChangeOfApprovalStatusShowNotification");
                CommonForm.Events.EnableOrDisableSection(formContext, "tab_9", "tab_9_section_1", false);
            }
        }
    },
    SetDefaultValueofPE: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_valueofproductenhancements")) {
            if (!CommonForm.Events.CheckValueExists(formContext, "niq_valueofproductenhancements")) {
                formContext.getAttribute("niq_valueofproductenhancements").setValue(0);
                formContext.data.refresh(true);
            }
        }
    },
    ClearCurrency: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "transactioncurrencyid")) {
            var formType = formContext.ui.getFormType();
            if (formType === 1 && formContext.getAttribute("niq_opportunitytype").getValue() !== 2) {
                formContext.getAttribute("transactioncurrencyid").setValue(null);
            }
        }
    },
    bPFStageErrorNotification: function (executionContext) {
        "use strict";
        var negotiationStageErrorMessage = "Please proceed to the main quote first and select values for all the mandatory Quote product characteristics for the quote products. You will be able to move opportunity to Closed Won in Review stage or resubmit to Gatekeeper after doing that.";
        var closeWonInReviewStageErrorMessage = "FAR got Rejected as main quote related mandatory Quote product characteristics values are not added. Please add mandatory data and resubmit for approval.";
        var formContext = executionContext.getFormContext();
        formContext.ui.clearFormNotification("onNegotiationMQPC");
        formContext.ui.clearFormNotification("onClosedWonInReviewMQPC");
        if (formContext.data.process.getActiveStage().getName().toLowerCase() === "negotiation" && formContext.getAttribute("niq_mandatorycharvaluesadded").getValue() === false) {
            formContext.ui.setFormNotification(negotiationStageErrorMessage, "WARNING", "onNegotiationMQPC");
        }
        //Mandatory Char Values Added is false and BPF is in Close won - in review stage, remove the Approve option value and Promp user for Rejection.
        else if (formContext.data.process.getActiveStage().getName().toLowerCase() === "closed won - in review" && formContext.getAttribute("niq_mandatorycharvaluesadded").getValue() === false &&
            formContext.getAttribute("niq_approvalstatus").getValue() === 100000003) {
            formContext.ui.setFormNotification(closeWonInReviewStageErrorMessage, "ERROR", "onClosedWonInReviewMQPC");
        }
    },
    TempOrFinallyExecutedURLValidation: function (executionContext) {
        formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_mainquoteid")) {
            var quoteId = formContext.getAttribute("niq_mainquoteid").getValue()[0].id;
            Xrm.WebApi.online.retrieveRecord("quote", quoteId, "?$select=niq_clmgate2").then(
                function success(result) {
                    var clmgate2 = result["niq_clmgate2"];
                    if (clmgate2 === true) {
                        if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_signedagreementcreatedandexecutedfromquot")) {
                            formContext.getControl("header_process_niq_signedagreementcreatedandexecutedfromquot").getAttribute().setRequiredLevel("required");
                            formContext.getControl("header_process_niq_signedagreementcreatedandexecutedfromquot").setVisible(true);
                        }
                        formContext.getControl("header_process_niq_tempeoafinallyexecutedagreementprovided").getAttribute().setRequiredLevel("none");
                        formContext.getControl("header_process_niq_tempeoafinallyexecutedagreementprovided").setVisible(false);
                    } else if (clmgate2 === false || clmgate2 === null) {
                        formContext.getControl("header_process_niq_signedagreementcreatedandexecutedfromquot").getAttribute().setRequiredLevel("none");
                        formContext.getControl("header_process_niq_signedagreementcreatedandexecutedfromquot").setVisible(false);
                        formContext.getControl("header_process_niq_tempeoafinallyexecutedagreementprovided").setVisible(true);
                        formContext.getControl("header_process_niq_tempeoafinallyexecutedagreementprovided").getAttribute().setRequiredLevel("required");
                    }
                },
                function (error) { }
            );
        }
    },
    SetURLCheckboxNegotiationStage: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "niq_mainquoteid")) {
            var quoteId = formContext.getAttribute("niq_mainquoteid").getValue()[0].id;
            Xrm.WebApi.online.retrieveRecord("quote", quoteId, "?$select=niq_congaagreementstatus,niq_finallyexecutedagreementurl,niq_clmgate2").then(
                function success(result) {
                    var clmgate2 = result["niq_clmgate2"];
                    var congaagreementstatus = result["niq_congaagreementstatus"];
                    var finallyexecutedagreementurl = result["niq_finallyexecutedagreementurl"];
                    if (clmgate2 === true) {
                        if (CommonForm.Events.CheckValueExists(formContext, "niq_tempeoaurl") || (congaagreementstatus === 100000005 && finallyexecutedagreementurl !== null)) {
                            if (CommonForm.Events.CheckControlExists(formContext, "header_process_niq_signedagreementcreatedandexecutedfromquot")) {
                                formContext.getControl("header_process_niq_signedagreementcreatedandexecutedfromquot").getAttribute().setValue(true);
                            } else {
                                formContext.getControl("header_process_niq_signedagreementcreatedandexecutedfromquot").getAttribute().setValue(false);
                            }
                        } else {
                            formContext.getControl("header_process_niq_signedagreementcreatedandexecutedfromquot").getAttribute().setValue(false);
                        }
                    }
                },
                function (error) { }
            );
        }
    },

    SalesOrgSalesGroupRequired: function (executionContext) {
        "use strict";
        //make Sales Org-Sales Group field required for valid Sales Org
        // get the form context
        var formContext = executionContext.getFormContext();

        if (CommonForm.Events.CheckFieldExists(formContext, "niq_salesorgid") && (CommonForm.Events.CheckFieldExists(formContext, "niq_salesgroupsalesorgid")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_originalopportunityid"))) {
            var salesorgvalue = formContext.getAttribute("niq_salesorgid").getValue();
            var originalOppo = formContext.getAttribute("niq_originalopportunityid").getValue();
            var BU = formContext.getAttribute("niq_creatorsbusinessfunctionalunit").getValue();
            formContext.getAttribute("niq_salesgroupsalesorgid").setRequiredLevel("none");
            if (CommonForm.Events.CheckValueExists(formContext, "niq_salesorgid")) {
                var salesOrg = formContext.getAttribute("niq_salesorgid").getValue();
                var salesOrg_id = salesOrg[0].id.replace('{', '').replace('}', '');
                // retrieve salesorgcode
                Xrm.WebApi.retrieveRecord("niq_salesorg", salesOrg_id, "?$select=niq_salesorgcode").then(
                    function success(result) {
                        if (result["niq_salesorgcode"] !== null) {
                            var salesOrgCode = result.niq_salesorgcode;
                            //retrieve Sales Org List_Oppoortunity_Lead configurationsetting
                            Xrm.WebApi.online.retrieveMultipleRecords("niq_configurationsetting", "?$select=niq_to&$filter=niq_name eq 'Sales%20Org%20List_Oppoortunity_Lead'").then(
                                function success(results) {
                                    if (result["niq_salesorgcode"] !== null) {
                                        var niq_to = results.entities[0]["niq_to"];
                                        if (niq_to !== null) {
                                            if ((niq_to.includes(salesOrgCode)) && (BU === null)) {
                                                formContext.getAttribute("niq_salesgroupsalesorgid").setRequiredLevel("required");
                                                if (originalOppo === null && BU === null) {
                                                    formContext.getAttribute("niq_salesgroupsalesorgid").setRequiredLevel("required");
                                                }
                                                else {
                                                    formContext.getAttribute("niq_salesgroupsalesorgid").setRequiredLevel("none");
                                                }

                                            }
                                            else {
                                                formContext.getAttribute("niq_salesgroupsalesorgid").setRequiredLevel("none");

                                                //formContext.getAttribute("niq_salesgroupsalesorgid").setValue(true);
                                            }

                                        }
                                    }
                                },
                                function (error) {

                                }
                            );
                        }
                    },
                    function (error) {

                    }
                );
            }
        }
    },

    OnCreateofOpportunity: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckValueExists(formContext, "ownerid")) {
            var owner = formContext.getAttribute("ownerid").getValue();
            var ownerId = owner[0].id.replace('{', '').replace('}', '');
            Xrm.WebApi.online.retrieveRecord("systemuser", ownerId, "?$select=niq_businessfunctionalunit").then(
                function success(result) {
                    console.log(result);
                    var niq_businessfunctionalunit = result["niq_businessfunctionalunit"];
                    var niq_businessfunctionalunit_formatted = result["niq_businessfunctionalunit@OData.Community.Display.V1.FormattedValue"];
                    if (niq_businessfunctionalunit === 100000012) {
                        formContext.getAttribute("niq_creatorsbusinessfunctionalunit").setValue(niq_businessfunctionalunit_formatted);

                    }
                    else {
                        formContext.getAttribute("niq_creatorsbusinessfunctionalunit").setValue(null);

                    }
                },
                function (error) {
                    console.log(error.message);
                }
            );

        }

    },





    PopulatingValueOfOppo: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if ((CommonForm.Events.CheckFieldExists(formContext, "niq_originalopportunityid")) && (CommonForm.Events.CheckValueExists(formContext, "niq_originalopportunityid")) && (CommonForm.Events.CheckValueExists(formContext, "niq_opportunitytype")) && (CommonForm.Events.CheckValueExists(formContext, "niq_existingcontractaction")) && (CommonForm.Events.CheckFieldExists(formContext, "niq_finallyexecutedagreementurl"))) {
            var oppotype = formContext.getAttribute("niq_opportunitytype").getValue();
            var originaloppo = formContext.getAttribute("niq_originalopportunityid").getValue();
            var originaloppo_id = originaloppo[0].id.replace('{', '').replace('}', '');
            var action = formContext.getAttribute("niq_existingcontractaction").getValue();
            Xrm.WebApi.online.retrieveRecord("opportunity", originaloppo_id, "?$select=niq_finallyexecutedagreementurl").then(
                function success(result) {
                    if (oppotype === 2) {
                        if ((action === 2) || (action === 3)) {
                            if ((result["niq_finallyexecutedagreementurl"] !== null)) {
                                var finallyexecutedagreementurl = result["niq_finallyexecutedagreementurl"];
                                formContext.getAttribute("niq_finallyexecutedagreementurl").setValue(finallyexecutedagreementurl);
                            }
                        }
                        else {
                            formContext.getAttribute("niq_finallyexecutedagreementurl").setValue(null);
                        }
                    }
                    else {
                        formContext.getAttribute("niq_finallyexecutedagreementurl").setValue(null);
                    }

                },
                function (error) {
                    Xrm.Utility.alertDialog(error.message);
                }
            );
        }
    },
    TothrowerrorforAgreementtypeandLanguage: function (executionContext) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var stage1 = CommonForm.Events.CheckValueExists(formContext, "niq_stage") ? formContext.getAttribute("niq_stage").getValue() : "";
            var preventSave = false;
            var args = executionContext.getEventArgs();
            if ((stage1 !== "Proposal" && stage1 !== "Pre-Proposal" && stage1 !== null)) {
                var quote = formContext.getAttribute("niq_mainquoteid").getValue();
                var quoteId = quote[0].id;
                quoteId = quoteId.replace("{", "");
                quoteId = quoteId.replace("}", "");

                var req = new XMLHttpRequest();
                req.open("GET", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.1/quotes(" + quoteId + ")?$select=niq_agreementtype , niq_agreementlanguage , niq_clmgate1", false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var result = JSON.parse(this.response);
                            var agreementType = result["niq_agreementtype"];
                            var agreementLanguage = result["niq_agreementlanguage"];
                            var clmgate1 = result["niq_clmgate1"];
                            if ((clmgate1 === true) && (agreementLanguage === null)) {
                                var niqerror = "Agreement Type and Agreement Language must be filled out on the main quote.";
                                formContext.ui.setFormNotification(niqerror, "ERROR", "agreementerror");
                                args.preventDefault();
                                QuoteForm.Events.setRequiredAgreementType(executionContext);
                            }
                            else {
                                formContext.ui.clearFormNotification("agreementerror");
                            }

                        }
                        else {
                            Xrm.Utility.alertDialog(this.statusText);
                        }
                    }
                };
                req.send();

            }
        }
        catch (e) {
            throw e.message;
        }


    },
    TothrowerrorforAgreementtype: function (executionContext) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var stage2 = CommonForm.Events.CheckValueExists(formContext, "niq_stage") ? formContext.getAttribute("niq_stage").getValue() : "";
            var preventSave = false;
            var args = executionContext.getEventArgs();
            if (args.getDirection() === "Next") {
                if (stage2 === "Negotiation") {
                    var quote = formContext.getAttribute("niq_mainquoteid").getValue();
                    var quoteId = quote[0].id;
                    quoteId = quoteId.replace("{", "");
                    quoteId = quoteId.replace("}", "");

                    var req = new XMLHttpRequest();
                    req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/quotes(" + quoteId + ")?$select=niq_agreementtype", false);
                    req.setRequestHeader("OData-MaxVersion", "4.0");
                    req.setRequestHeader("OData-Version", "4.0");
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            req.onreadystatechange = null;
                            if (this.status === 200) {
                                var result = JSON.parse(this.response);
                                var agreementType = result["niq_agreementtype"];
                                if (agreementType === null) {
                                    var niqerror = "Agreement Type must be populated on the main quote before you can move past Negotiation stage";
                                    formContext.ui.setFormNotification(niqerror, "ERROR", "agreementerror");
                                    args.preventDefault();
                                }
                                else {
                                    formContext.ui.clearFormNotification("agreementerror");
                                }
                            }
                            else {
                                Xrm.Utility.alertDialog(this.statusText);
                            }
                        }
                    };
                    req.send();
                }
            }

        }
        catch (e) {
            throw e.message;
        }
    },

    TothrowerrorforHostOpportunity: function (executionContext) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var targetOppId = formContext.data.entity.getId().replace("{", "").replace("}", "");
            var isHostOpp = formContext.getAttribute("niq_ishostopportunity").getValue();
            var hostOpp = formContext.getAttribute("niq_hostopportunity").getValue();
            var revShareDeal = formContext.getAttribute("niq_revenuesharedeal").getValue();

            var stage = CommonForm.Events.CheckValueExists(formContext, "niq_stage") ? formContext.getAttribute("niq_stage").getValue() : "";
            var preventSave = false;
            var args = executionContext.getEventArgs();
            if (args.getDirection() === "Next") {
                if (stage === "Negotiation") {
                    if (isHostOpp == 1 && hostOpp == null && revShareDeal == 1) {
                        var fetchXmlChildOpp = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
                            "<entity name='opportunity' >" +
                            "<attribute name='name' />" +
                            "<attribute name='niq_stage' />" +
                            "<attribute name='statecode' />" +
                            "<attribute name='niq_opportunitynumber' />" +
                            "<attribute name='opportunityid' />" +
                            "<attribute name='niq_ishostopportunity' />" +
                            "<attribute name='niq_hostopportunity' />" +
                            "<attribute name='niq_approvalstatus' />" +
                            "<attribute name='niq_revenuesharedeal' />" +
                            "<filter type='and' >" +
                            "<condition attribute='niq_hostopportunity' operator='eq' uitype='opportunity' value='" + targetOppId + "' />" +
                            "<condition attribute='statecode' operator='eq' value='0' />" +
                            "</filter>" +
                            "</entity>" +
                            "</fetch>";
                        var serverUrl = Xrm.Utility.getGlobalContext().getClientUrl();
                        var fetchXmlResults = GetCRMWebAPI.Methods.GetFetchRecords(serverUrl, fetchXmlChildOpp, "opportunities");
                        if (fetchXmlResults !== null && fetchXmlResults.value.length > 0) {
                            var oppNumber = '';
                            for (var i = 0; i < fetchXmlResults.value.length; i++) {
                                if (fetchXmlResults.value[i].niq_stage !== "Closed Won - In Review" && (fetchXmlResults.value[i].niq_approvalstatus === 100000001 || fetchXmlResults.value[i].niq_approvalstatus !== null) && fetchXmlResults.value[i].statecode === 0) {
                                    oppNumber += fetchXmlResults.value[i].niq_opportunitynumber + ", ";
                                }
                            }
                            if (oppNumber != null || oppNumber.length > 0) {
                                oppNumber = oppNumber.substring(0, oppNumber.length - 2);
                                var hostOppErrMsg = "These child opportunities " + oppNumber + " have not been submitted to gatekeeper. Please send all child opportunities to the gatekeeper before sending the host opportunity to gatekeeper";
                                formContext.ui.setFormNotification(hostOppErrMsg, "ERROR", "hostopportunityerror");
                                args.preventDefault();
                            }
                            else {
                                formContext.ui.clearFormNotification("hostopportunityerror");
                            }
                        }
                    }
                }
            }          
        }
        catch (e) {
            throw e.message;
        }
    },

    PopulatingValueOfCloneOppo: function (executionContext) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var formInformationTips = "Sales Org, Sales Group and Opportunity Currency: “This field cannot be changed for a cloned opportunity.If you need them changed you will need to create a New Opportunity.";
            var fieldInformationTips = "Are you creating this opportunity to reflect a completely new sale/to manage an existing contract? : This field cannot be changed for a cloned opportunity.  If this is not a new sale, use the “Manage Existing Contract";

            if ((CommonForm.Events.CheckFieldExists(formContext, "niq_cloneopportunity")) && (CommonForm.Events.CheckValueExists(formContext, "niq_cloneopportunity"))) {

                var originaloppo = formContext.getAttribute("niq_cloneopportunity").getValue();
                var originaloppo_id = originaloppo[0].id.replace('{', '').replace('}', '');
                formContext.ui.setFormNotification(formInformationTips, "INFORMATION");
                formContext.ui.setFormNotification(fieldInformationTips, "INFORMATION");
                formContext.getControl("niq_opportunitytype").setDisabled(true);
                formContext.getControl("niq_salesorgid").setDisabled(true);
                formContext.getControl("niq_salesgroupsalesorgid").setDisabled(true);
                formContext.getControl("transactioncurrencyid").setDisabled(true);
                Xrm.WebApi.online.retrieveMultipleRecords("opportunity", "?$select=_niq_salesgroupsalesorgid_value,_niq_salesorgid_value,_parentaccountid_value,_transactioncurrencyid_value&$filter=opportunityid eq " + originaloppo_id).
                    then(function success(results) {
                        for (var i = 0; i < results.entities.length; i++) {
                            if ((results.entities[i]["_niq_salesorgid_value"] !== null)) {
                                var lookupSalesGroupOrgValue = new Array();
                                lookupSalesGroupOrgValue[0] = new Object();
                                lookupSalesGroupOrgValue[0].id = results.entities[i]["_niq_salesorgid_value"];;
                                lookupSalesGroupOrgValue[0].name = results.entities[i]["_niq_salesorgid_value@OData.Community.Display.V1.FormattedValue"];
                                lookupSalesGroupOrgValue[0].entityType = results.entities[i]["_niq_salesorgid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                formContext.getAttribute("niq_salesorgid").setValue(lookupSalesGroupOrgValue);
                            }
                            else {
                                formContext.getAttribute("niq_salesorgid").setValue(null);
                            }
                            if ((results.entities[i]["_niq_salesgroupsalesorgid_value"] !== null)) {
                                var lookupSalesGroupValue = new Array();
                                lookupSalesGroupValue[0] = new Object();
                                lookupSalesGroupValue[0].id = results.entities[i]["_niq_salesgroupsalesorgid_value"];
                                lookupSalesGroupValue[0].name = results.entities[i]["_niq_salesgroupsalesorgid_value@OData.Community.Display.V1.FormattedValue"];
                                lookupSalesGroupValue[0].entityType = results.entities[i]["_niq_salesgroupsalesorgid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                formContext.getAttribute("niq_salesgroupsalesorgid").setValue(lookupSalesGroupValue);
                            }
                            else {
                                formContext.getAttribute("niq_salesgroupsalesorgid").setValue(null);
                            }
                            if ((results.entities[i]["_parentaccountid_value"] !== null)) {
                                var lookupParentAccountidValue = new Array();
                                lookupParentAccountidValue[0] = new Object();
                                lookupParentAccountidValue[0].id = results.entities[i]["_parentaccountid_value"];
                                lookupParentAccountidValue[0].name = results.entities[i]["_parentaccountid_value@OData.Community.Display.V1.FormattedValue"];
                                lookupParentAccountidValue[0].entityType = results.entities[i]["_parentaccountid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                formContext.getAttribute("parentaccountid").setValue(lookupParentAccountidValue);
                            }
                            else {
                                formContext.getAttribute("parentaccountid").setValue(null);
                            }
                            if ((results.entities[i]["_transactioncurrencyid_value"] !== null)) {
                                var lookupTransactionCurrencyValue = new Array();
                                lookupTransactionCurrencyValue[0] = new Object();
                                lookupTransactionCurrencyValue[0].id = results.entities[i]["_transactioncurrencyid_value"];;
                                lookupTransactionCurrencyValue[0].name = results.entities[i]["_transactioncurrencyid_value@OData.Community.Display.V1.FormattedValue"];
                                lookupTransactionCurrencyValue[0].entityType = results.entities[i]["_transactioncurrencyid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                formContext.getAttribute("transactioncurrencyid").setValue(lookupTransactionCurrencyValue);
                            }
                            else {
                                formContext.getAttribute("transactioncurrencyid").setValue(null);
                            }

                        }
                    },
                    function (error) {
                        Xrm.Utility.alertDialog(error.message);
                    }
                    );
            }
            else {
                /*
                formContext.getAttribute("niq_salesorgid").setValue(null);
                formContext.getAttribute("niq_salesgroupsalesorgid").setValue(null);
                formContext.getAttribute("parentaccountid").setValue(null);
                formContext.getAttribute("transactioncurrencyid").setValue(null);
                */
            }
        }
        catch (e) {
            throw e.message;
        }
    },

    displayMessageBlockedQuoteProduct: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (formContext.ui.getFormType() !== 1) {
            var quote = formContext.getAttribute("niq_mainquoteid").getValue();
            if (quote != null) {
                var quoteId = quote[0].id;
                if (quoteId != null) {
                    quoteId = quoteId.replace("{", "");
                    quoteId = quoteId.replace("}", "");
                    var globalContext = Xrm.Utility.getGlobalContext();
                    var serverUrl = globalContext.getClientUrl();
                    var fetchQuote = "<fetch top='1'><entity name='quote'><attribute name='niq_blockedproductdesc' /><filter><condition attribute='quoteid' operator='eq' value='" + quoteId + "' />   </filter></entity></fetch>";
                    var fetchResults = GetCRMWebAPI.Methods.GetFetchRecords(serverUrl, fetchQuote, "quotes");
                    if (fetchResults !== null && fetchResults.value.length > 0 && fetchResults.value[0]['niq_blockedproductdesc'] !== null) {
                        var blockedProdDesc = fetchResults.value[0]['niq_blockedproductdesc'];
                        if (blockedProdDesc != null) {
                            Xrm.Page.ui.setFormNotification("This cloned opportunity contains the following blocked products which must be removed in Experlogix before this opportunity can be closed to avoid SAP integration failure: " + blockedProdDesc, "WARNING");
                        }
                    }
                }
            }
        }
    },
    ShowhideProjectDetailSection: function (executionContext) {

        var formContext = executionContext.getFormContext();
        if (formContext.getAttribute("niq_businessarea") != null || formContext.getAttribute("niq_businessarea").getValue() != null) {

            var businessAreaValue = formContext.getAttribute("niq_businessarea").getValue();

            if (businessAreaValue == 100000000) {
                formContext.ui.tabs.get("Summary").sections.get("ProjectDetailSection").setVisible(true);
            }
            else {

                formContext.ui.tabs.get("Summary").sections.get("ProjectDetailSection").setVisible(false);
            }
        }
    },

    //
    checkforActiveOPERecords: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var opportunityType = formContext.getAttribute("niq_opportunitytype").getValue();
        var formType = formContext.ui.getFormType();
        if (formType == 1) {
            //new
            if ((formContext.getControl("header_process_niq_product_enhancement_impact_provision") != null) && (formContext.getControl("header_process_niq_product_enhancement_impact_provision") != undefined)) {
                formContext.getControl("header_process_niq_product_enhancement_impact_provision").setVisible(false);
            }
        }
        else if (formType == 4) {//disabled
            if(opportunityType == 1){                                          //type is "completely new sale"
            if ((formContext.getControl("header_process_niq_product_enhancement_impact_provision") != null) && (formContext.getControl("header_process_niq_product_enhancement_impact_provision") != undefined)) {
                formContext.getControl("header_process_niq_product_enhancement_impact_provision").setVisible(false);
            }
        }
            return;
        }
        else {
            if (opportunityType == 2) {
                //only when type is "existing contract mgt"
                var oppid = formContext.data.entity.getId().substring(1, 37);
                var recordcount = null;
                var req = new XMLHttpRequest();
                req.open("GET", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/niq_opportunityproductenhancements?$filter=(_niq_opportunitynameid_value eq " + oppid + " and statecode eq 0)", true);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Prefer", "odata.include-annotations=*");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var results = JSON.parse(this.response);
                            console.log(results);
                            recordcount = results.value.length;
                            //alert('record count ' + recordcount);
                            var fldcontrol = formContext.getControl("header_process_niq_product_enhancement_impact_provision");
                            var fldattribute = fldcontrol.getAttribute();
                            if (recordcount >= 1) {
                                if ((formContext.getControl("header_process_niq_product_enhancement_impact_provision") != null) && (formContext.getControl("header_process_niq_product_enhancement_impact_provision") != undefined)) {
                                    formContext.getControl("header_process_niq_product_enhancement_impact_provision").setVisible(true);
                                    //alert('making visible');
                                    if (fldattribute != undefined) {
                                        formContext.getControl("header_process_niq_product_enhancement_impact_provision").getAttribute().setRequiredLevel("required");
                                    }
                                }
                            }
                            else {
                                if ((formContext.getControl("header_process_niq_product_enhancement_impact_provision") != null) && (formContext.getControl("header_process_niq_product_enhancement_impact_provision") != undefined)) {
                                    if (fldattribute != undefined) {
                                        formContext.getControl("header_process_niq_product_enhancement_impact_provision").getAttribute().setRequiredLevel("none");
                                    }
                                    formContext.getControl("header_process_niq_product_enhancement_impact_provision").setVisible(false);
                                }
                            }
                        } else {
                            console.log(this.responseText);
                        }
                    }
                };
                req.send();
            }
        }
    },
    hostChildOpportunityGridSetDisable: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var approvalStatus;
        var status;
        var opportunityId = formContext.data.entity.getId();

        if (opportunityId != null) {
            var fetchXmlQuery = '<fetch version= "1.0" output-format="xml-platform" mapping= "logical" distinct= "false">' +
                '<entity name= "opportunity">' +
                '<attribute name="opportunityid"/>' +
                '<attribute name="niq_stage"/>' +
                '<attribute name="niq_approvalstatus"/>' +
                '<attribute name="statecode"/>' +
                '<filter type="and">' +
                '<condition attribute="opportunityid" operator="eq" value="' + opportunityId + '"/>' +
                '</filter>' +
                '</entity>' +
                '</fetch>';
            var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
            var results = GetCRMWebAPI.Methods.GetFetchRecords(clienturl, fetchXmlQuery, "opportunities");

            if (results != null && results.value.length > 0) {
                approvalStatus = results.value[0]["niq_approvalstatus"]; // approval status
                status = results.value[0]["statecode"]; // Status  
            }
            OpportunityForm.Events.disablechildOpportunityGrid(executionContext, approvalStatus, status);
        }
    },

    disablechildOpportunityGrid: function (executionContext, approvalStatus, status) {
        var formContext = executionContext.getFormContext();
        var fieldsList = ["estimatedclosedate", "niq_closeprobability", "niq_tempeoaurl", "niq_finallyexecutedagreementurl", "niq_podocumentationurl", "niq_customerponumber",
            "niq_customerpodate", "niq_billingtype", "niq_billinginstructions", "niq_shouldclientbeinvoicedforthisopportunity", "niq_optopportunityoutofbasesorciclient"];


        if (approvalStatus != 100000001 && approvalStatus != 100000000 && status == 0) {
            formContext.getData().getEntity().attributes.forEach(function (attr) {
                var fld = attr.getName();
                if (!fieldsList.includes(fld)) {
                    attr.controls.forEach(function (control) {
                        control.setDisabled(true);
                    });
                }
            });
        }
        else {
            formContext.getData().getEntity().attributes.forEach(function (attr) {
                attr.controls.forEach(function (control) {
                    control.setDisabled(true);
                });
            });
        }

    },
    PopulateDefaultFieldsFromDefaultSettings: function (executionContext) {
        //niq_salesorgid, niq_salesgroupsalesorgid, transactioncurrencyid
        var formContext = executionContext.getFormContext();
        var userSettings = Xrm.Utility.getGlobalContext().userSettings;
        var formType = formContext.ui.getFormType();
        var currentuserid = userSettings.userId.substring(1, 37);
        //alert(currentuserid);
        var username = userSettings.userName;
        if (formContext.getAttribute("niq_salesorgid").getValue() == null || formContext.getAttribute("niq_salesgroupsalesorgid").getValue() == null || formContext.getAttribute("transactioncurrencyid").getValue() == null) {
            Xrm.WebApi.retrieveMultipleRecords("niq_salesuserdefaultsettings", "?$select=_niq_defaultcurrency_value,_niq_defaultsalesgroupsalesorg_value,_niq_defaultsalesorg_value&$filter=_niq_user_value eq '" + currentuserid + "' and statecode eq 0").then(
                function success(results) {
                    console.log(results);
                    for (var i = 0; i < results.entities.length; i++) {
                        var result = results.entities[i];
                        // Columns
                        var niq_salesuserdefaultsettingsid = result["niq_salesuserdefaultsettingsid"]; // Guid
                        var niq_defaultcurrency = result["_niq_defaultcurrency_value"]; // Lookup
                        var niq_defaultcurrency_formatted = result["_niq_defaultcurrency_value@OData.Community.Display.V1.FormattedValue"];
                        var niq_defaultcurrency_lookuplogicalname = result["_niq_defaultcurrency_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        var niq_defaultsalesgroupsalesorg = result["_niq_defaultsalesgroupsalesorg_value"]; // Lookup
                        var niq_defaultsalesgroupsalesorg_formatted = result["_niq_defaultsalesgroupsalesorg_value@OData.Community.Display.V1.FormattedValue"];
                        var niq_defaultsalesgroupsalesorg_lookuplogicalname = result["_niq_defaultsalesgroupsalesorg_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        var niq_defaultsalesorg = result["_niq_defaultsalesorg_value"]; // Lookup
                        var niq_defaultsalesorg_formatted = result["_niq_defaultsalesorg_value@OData.Community.Display.V1.FormattedValue"];
                        var niq_defaultsalesorg_lookuplogicalname = result["_niq_defaultsalesorg_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        //alert('niq_defaultcurrency_lookuplogicalname ' + niq_defaultcurrency_lookuplogicalname + '\n niq_defaultcurrency_formatted ' + niq_defaultcurrency_formatted + '\n niq_defaultcurrency ' + niq_defaultcurrency +'\n niq_defaultsalesgroupsalesorg_lookuplogicalname ' + niq_defaultsalesgroupsalesorg_lookuplogicalname+ '\n niq_defaultsalesgroupsalesorg ' + niq_defaultsalesgroupsalesorg + '\n niq_defaultsalesgroupsalesorg_formatted ' + niq_defaultsalesgroupsalesorg_formatted + '\n niq_defaultsalesorg_lookuplogicalname ' + niq_defaultsalesorg_lookuplogicalname+'\n niq_defaultsalesorg' + niq_defaultsalesorg + '\n niq_defaultsalesorg_formatted ' + niq_defaultsalesorg_formatted);
                        if (formContext.getAttribute("niq_salesorgid").getValue() == null && niq_defaultsalesorg != null) {
                            var salesOrg = {
                                "entityType": niq_defaultsalesorg_lookuplogicalname, // change this to the logical name of parent table.
                                "id": niq_defaultsalesorg, // guid of the parent record
                                "name": niq_defaultsalesorg_formatted // text representing the name of the record to be displayed in the lookup.
                            };

                            // replace salesorg with the lookup field name.
                            formContext.getAttribute("niq_salesorgid").setValue([salesOrg]);
                            formContext.getControl("niq_salesgroupsalesorgid").setDisabled(false);
                        }
                        if (formContext.getAttribute("niq_salesgroupsalesorgid").getValue() == null && niq_defaultsalesgroupsalesorg != null) {
                            var salesGroudSalesOrg = {
                                "entityType": niq_defaultsalesgroupsalesorg_lookuplogicalname,
                                "id": niq_defaultsalesgroupsalesorg,
                                "name": niq_defaultsalesgroupsalesorg_formatted
                            };

                            // replace salesgroupsalesorg with the lookup field name.
                            formContext.getAttribute("niq_salesgroupsalesorgid").setValue([salesGroudSalesOrg]);
                        }
                        //alert('formType ' + formType);
                        if (formType == 1 || (formType == 2 && (formContext.getAttribute("transactioncurrencyid").getValue() == null && niq_defaultcurrency != null))) {
                            //alert('currency');
                            var currency = {
                                "entityType": niq_defaultcurrency_lookuplogicalname,
                                "id": niq_defaultcurrency,
                                "name": niq_defaultcurrency_formatted
                            };

                            formContext.getAttribute("transactioncurrencyid").setValue([currency]);
                        }
                    }
                },
                function (error) {
                    console.log(error.message);
                }
            );
        }
    },

    OnChangeOpportunityTypeAndContractAction: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();

        if (CommonForm.Events.CheckValueExists(formContext, "niq_opportunitytype")) {
            var oppoType = formContext.getAttribute("niq_opportunitytype").getValue();
            if (oppoType === 2) {
                if (CommonForm.Events.CheckValueExists(formContext, "niq_existingcontractaction")) {
                    var contractaction = formContext.getAttribute("niq_existingcontractaction").getValue();

                    if (contractaction === 1) {
                        if (CommonForm.Events.CheckControlExists(formContext, "niq_contractdecision")) {
                            formContext.getControl("niq_contractdecision").getAttribute().setValue(100000001);
                        }
                    }
                    if (contractaction === 2 || contractaction === 3) {
                        if (CommonForm.Events.CheckControlExists(formContext, "niq_contractdecision")) {
                            formContext.getControl("niq_contractdecision").getAttribute().setValue(100000000);
                        }
                    }
                    if (contractaction === 4) {
                        if (CommonForm.Events.CheckControlExists(formContext, "niq_contractdecision")) {
                            formContext.getControl("niq_contractdecision").getAttribute().setValue(100000002);
                        }
                    }
                }
            }
            else {
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_contractdecision")) {
                    formContext.getControl("niq_contractdecision").getAttribute().setValue(100000001);
                }
            }
        }
    },

    PopulateEstCloseDateFromDefaultSettings: function (executionContext) {
        // var formContext = Xrm.Page;
        var formContext = executionContext.getFormContext();
        var est_Close_Date = formContext.getAttribute("estimatedclosedate").getValue();
        var formType = formContext.ui.getFormType();
        if (est_Close_Date == null || formType == 1) {
            var opportunityType = formContext.getAttribute("niq_opportunitytype").getValue();
            var userid = Xrm.Utility.getGlobalContext().userSettings.userId;
            userid = userid.substring(1, userid.length - 1);
            var daysToAdd = 0;


            var options = "?$select=niq_defaultsalescycleindaysnewsale,niq_defausalescycleexistingcontractmanagement,_niq_user_value&$filter=_niq_user_value eq " + userid;

            Xrm.WebApi.retrieveMultipleRecords("niq_salesuserdefaultsettings", options).then(
                function success(results) {
                    if (results == undefined || results == null) return;
                    if (results.entities.length == 0) return;
                    var niq_defaultsalescycleindaysnewsale = results.entities[0]["niq_defaultsalescycleindaysnewsale"];
                    var niq_defausalescycleexistingcontractmanagement = results.entities[0]["niq_defausalescycleexistingcontractmanagement"];
                    if (opportunityType == 1) daysToAdd = niq_defaultsalescycleindaysnewsale;                 // completely new sale
                    else if (opportunityType == 2) daysToAdd = niq_defausalescycleexistingcontractmanagement; // existing contract mgt
                    if (daysToAdd != undefined && daysToAdd != null) {
                        let reqdate = new Date();
                        reqdate.setDate(new Date().getDate() + daysToAdd);
                        formContext.getAttribute("estimatedclosedate").setValue(reqdate);
                    }
                },
                function (error) {
                    console.log(error.message);
                });
        }
    },

    ShowSectionsBasedOnPartyValues: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        debugger;
        var stpControl, btpControl, dtpControl, stpControlId, btpControlId, dtpControlId;

        if (formContext.getAttribute("niq_soldtoparty") != null && formContext.getAttribute("niq_soldtoparty").getValue() != null) {
            stpControl = formContext.getControl("niq_soldtoparty");
            stpControlId = stpControl.getAttribute().getValue()[0].id;
        }
        if (formContext.getAttribute("niq_billtoparty") != null && formContext.getAttribute("niq_billtoparty").getValue() != null) {
            btpControl = formContext.getControl("niq_billtoparty");
            btpControlId = btpControl.getAttribute().getValue()[0].id;
        }
        if (formContext.getAttribute("niq_deliverytoparty") != null && formContext.getAttribute("niq_deliverytoparty").getValue()) {
            dtpControl = formContext.getControl("niq_deliverytoparty");
            dtpControlId = dtpControl.getAttribute().getValue()[0].id;
        }

        if (stpControlId === btpControlId &&
            stpControlId === dtpControlId) {
            //alert('equal');
            formContext.ui.tabs.get("Summary").sections.get("CommonPartyDetails").setVisible(true);
            formContext.ui.tabs.get("Summary").sections.get("SoldToPartyDetails").setVisible(false);
            formContext.ui.tabs.get("Summary").sections.get("BillToPartyDetails").setVisible(false);
            formContext.ui.tabs.get("Summary").sections.get("DeliverToPartyDetails").setVisible(false);

        }
        else {
            //alert('not equal');
            formContext.ui.tabs.get("Summary").sections.get("CommonPartyDetails").setVisible(false);
            formContext.ui.tabs.get("Summary").sections.get("SoldToPartyDetails").setVisible(true);
            formContext.ui.tabs.get("Summary").sections.get("BillToPartyDetails").setVisible(true);
            formContext.ui.tabs.get("Summary").sections.get("DeliverToPartyDetails").setVisible(true);
        }
    },

}

//DYNCRM-1725 Start Line 
//DYNCRM-1725 Filding Country CI field should be visible and Required when Business Area eq Customer Insights(CI)
function fieldingCountryCI_OnChange(executionContext) {
    debugger;
    var formContext = executionContext.getFormContext();
    var businessArea = formContext.getAttribute("niq_businessarea").getValue();
    if (businessArea == 100000001) {
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_fieldingcountryci")) {
            formContext.getControl("niq_fieldingcountryci").setVisible(true);
            formContext.getAttribute("niq_fieldingcountryci").setRequiredLevel("required");
            formContext.getControl('header_process_niq_fieldingcountry').setVisible(false);
        }
    } else {
        formContext.getControl("niq_fieldingcountryci").setVisible(false);
        formContext.getAttribute("niq_fieldingcountryci").setRequiredLevel("none");
    }
}
//DYNCRM-1725 End Line