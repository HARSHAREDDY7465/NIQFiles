if (typeof (AccountPlanForm) === "undefined") {
    AccountPlanForm = {
        __namespace: true
    };
}

AccountPlanForm.Events = {    
    RefreshRibbon: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        formContext.ui.refreshRibbon();
    },
    ValidateEndDate: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_enddate") && CommonForm.Events.CheckFieldExists(formContext, "niq_startdate")) {
            var endDate = formContext.getAttribute("niq_enddate").getValue();
            var startDate = formContext.getAttribute("niq_startdate").getValue();
           
            if ((endDate !== null) && (startDate !== null) && (startDate > endDate)) {
                formContext.getControl("niq_enddate").setNotification("The End Date cannot be before Start Date.", "validateEndDate");
                //formContext.getAttribute("niq_enddate").setValue(null);
            }
            else {
                formContext.getControl("niq_startdate").clearNotification("validateStarttDate");
                formContext.getControl("niq_enddate").clearNotification("validateEndDate");
            }
        }
    },
    ValidateStartDate: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_enddate") && CommonForm.Events.CheckFieldExists(formContext, "niq_startdate")) {
            var endDate = formContext.getAttribute("niq_enddate").getValue();
            var startDate = formContext.getAttribute("niq_startdate").getValue();
            
            if (((startDate !== null) && endDate !== null) && (startDate > endDate)) {
                formContext.getControl("niq_startdate").setNotification("The Start Date cannot be after End Date.", "validateStarttDate");
                //formContext.getAttribute("niq_startdate").setValue(null);
            }
            else {
                formContext.getControl("niq_enddate").clearNotification("validateEndDate");
                formContext.getControl("niq_startdate").clearNotification("validateStarttDate");
            }
        }
    }
}