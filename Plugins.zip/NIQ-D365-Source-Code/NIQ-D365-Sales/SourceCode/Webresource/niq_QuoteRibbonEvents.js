if (typeof (QuoteRibbon) === "undefined") {
    QuoteRibbon = {
        __namespace: true
    };
}
QuoteRibbon.Events = {
    formContextOnClickInitiateDealDeskButton: null,
    OnClickRecallButton: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var quoteId = formContext.data.entity.getId().replace("{", "").replace("}", "");
        var confirmStrings = { text: "Do you wish to Recall the Quote from Approval", cancelButtonLabel: "No", confirmButtonLabel: "Yes" };
        var confirmOptions = { height: 200, width: 450 };
        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    //Xrm.Utility.showProgressIndicator();
                    var data = {};
                    //data.niq_quoteheaderdetailsapproval = formContext.getAttribute("niq_quoteheaderdetailsapproval").getValue();
                    data.niq_isrecalled = 1;
                    Xrm.WebApi.online.updateRecord("quote", quoteId, data).then(
                        function success(result) {
                            Xrm.Utility.closeProgressIndicator();
                            //formContext.data.refresh(true).then(function RefreshQuote() {
                            var entityFormOptions = {};
                            entityFormOptions["entityName"] = "quote";
                            entityFormOptions["entityId"] = quoteId;
                            Xrm.Navigation.openForm(entityFormOptions);
                            //});
                        },
                        function (error) {
                        }
                    );
                }
            }
        );
    },
    InitiateDealDeskButtonVisibility: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var quoteStatus = false;
        var overallDealDesk = false;
        var ELbillingScheduleComplete=false;
        if ((formContext.getAttribute("statecode").getValue() !== null) && (formContext.getAttribute("statecode").getValue() !== 2) && (formContext.getAttribute("statecode").getValue() !== 3)) {
            quoteStatus = true;
        }
        if ((formContext.getAttribute("niq_overalldealdeskapproval") !== null) && (formContext.getAttribute("niq_overalldealdeskapproval").getValue !== null) && (formContext.getAttribute("niq_elbillingschedulecomplete") !== null) && (formContext.getAttribute("niq_elbillingschedulecomplete").getValue !== null) && (((formContext.getAttribute("niq_overalldealdeskapproval").getValue() === 4) || (formContext.getAttribute("niq_overalldealdeskapproval").getValue() === 3)) && (formContext.getAttribute("niq_elbillingschedulecomplete").getValue() !== false)) ){
            overallDealDesk = true;

        }
        if ((formContext.getAttribute("niq_elbillingschedulecomplete").getValue() !== null) && (formContext.getAttribute("niq_elbillingschedulecomplete").getValue() !== false))
         {
            ELbillingScheduleComplete = true;
        }
        
        if (quoteStatus === true && overallDealDesk === true && ELbillingScheduleComplete === true) {
            return true;
        } else {
            return false;
        }
    },
    OnClickInitiateDealDeskButton: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        QuoteRibbon.Events.formContextOnClickInitiateDealDeskButton = executionContext;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_dealdeskapprovalrequest";
        entityFormOptions["useQuickCreateForm"] = true;
        var formParameters = {};
        if (CommonForm.Events.CheckValueExists(formContext, "name")) {
            var quoteData = new Array();
            quoteData[0] = new Object();
            quoteData[0].id = formContext.data.entity.getEntityReference().id.replace("{", "").replace("}", "");
            quoteData[0].name = formContext.data.entity.getEntityReference().name;
            quoteData[0].entityType = formContext.data.entity.getEntityReference().entityType;
            formParameters["niq_quoteid"] = quoteData;
        }
        if (CommonForm.Events.CheckValueExists(formContext, "opportunityid")) {
            var oppoDetails = new Array();
            oppoDetails[0] = new Object();
            oppoDetails[0].id = formContext.getAttribute("opportunityid").getValue()[0].id;
            oppoDetails[0].name = formContext.getAttribute("opportunityid").getValue()[0].name;
            oppoDetails[0].entityType = "opportunity";
            formParameters["niq_opportunityid"] = oppoDetails;
        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_dealdeskapproval")) {
            formParameters["niq_pricingapproval"] = formContext.getAttribute("niq_dealdeskapproval").getValue();
        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_fundusageapproval")) {
            formParameters["niq_fundusageapproval"] = formContext.getAttribute("niq_fundusageapproval").getValue();
        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_quoteheaderdetailsapproval")) {
            formParameters["niq_quoteheaderdetailsapproval"] = formContext.getAttribute("niq_quoteheaderdetailsapproval").getValue();
        }
        if (CommonForm.Events.CheckValueExists(formContext, "niq_overalldealdeskapproval")) {
            formParameters["niq_overalldealdeskapproval"] = formContext.getAttribute("niq_overalldealdeskapproval").getValue();
        }
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
                if (success !== undefined && success !== null && success.savedEntityReference !== undefined &&
                    success.savedEntityReference !== null && success.savedEntityReference.length > 0 &&
                    success.savedEntityReference[0].id !== undefined && success.savedEntityReference[0].id !== null &&
                    QuoteRibbon.Events.formContextOnClickInitiateDealDeskButton.getAttribute("niq_overalldealdeskapproval") !== undefined &&
                    QuoteRibbon.Events.formContextOnClickInitiateDealDeskButton.getAttribute("niq_overalldealdeskapproval") !== null) {
                    QuoteRibbon.Events.formContextOnClickInitiateDealDeskButton.getAttribute("niq_overalldealdeskapproval").setValue(7);
                    QuoteRibbon.Events.formContextOnClickInitiateDealDeskButton.getAttribute("niq_isrecalled").setValue(2);
                    QuoteRibbon.Events.formContextOnClickInitiateDealDeskButton.data.save(1);
                }

 

            },
            function (error) { }
        );
    },

 

    cancelAgreementButtonVisibility: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var QuoteFlag = false;
        var clmgate2 = formContext.getAttribute("niq_clmgate2").getValue();
        if (clmgate2 !== null && clmgate2 === true) {
            if ((CommonForm.Events.CheckValueExists(formContext, "niq_congaagreementstatus")) && (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User"))) {
                if ((formContext.getAttribute("niq_congaagreementstatus").getValue() === 100000002) || (formContext.getAttribute("niq_congaagreementstatus").getValue() === 100000007) || ((formContext.getAttribute("niq_congaagreementstatus").getValue() === 100000003) && (formContext.getAttribute("niq_congasyncstatus").getValue() === 100000002)))  {

 

                    formContext.getControl("niq_canceledreason").setDisabled(false);
                    QuoteFlag = true;
                }
            }

 

        }
        if (QuoteFlag === true) {
            return true;
        }
        else {
            return false;
        }
    },
    onClickCancelAgreementButton: function (executionContext) {
        "use strict";
        var formContext = executionContext;

 

        var confirmStrings = { text: "Do you wish to initiated the agreement cancellation process in Conga?", cancelButtonLabel: "No", confirmButtonLabel: "Yes" };
        var confirmOptions = { height: 200, width: 450 };
        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    if (CommonForm.Events.CheckFieldExists(formContext, "niq_congaagreementstatus") && CommonForm.Events.CheckFieldExists(formContext, "niq_canceledreason") && CommonForm.Events.CheckFieldExists(formContext, "niq_congasyncstatus") && CommonForm.Events.CheckFieldExists(formContext, "niq_synctoclm")) {
                        if (formContext.getAttribute("niq_canceledreason").getValue() === null) {
                            var alertStrings = { text: "Please provide cancellation reason" };
                            //formContext.getControl("niq_canceledreason").setFocus();
                            Xrm.Navigation.openAlertDialog(alertStrings).then(
                                function (success) {
                                    formContext.getControl("niq_canceledreason").setDisabled(false);

 

                                    formContext.getControl("niq_canceledreason").setFocus();
                                },
                                function (error) {

 

                                }
                            );
                        }
                        else {
                            formContext.getAttribute("niq_congaagreementstatus").setValue(100000003);
                            formContext.getAttribute("niq_congasyncstatus").setValue(100000000);
                            formContext.getAttribute("niq_synctoclm").setValue(true);
                            formContext.data.entity.save();
                        }
                    }
                }
            }
        );
    },
    createAgreementButtonVisibility: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var OpportunityFlag = false;
        var quoteProductFlag = false;
        var clmgate1 = formContext.getAttribute("niq_clmgate1").getValue();
        var clmgate2 = formContext.getAttribute("niq_clmgate2").getValue();		
        var fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' no-lock='true' top='1'>" +
            "  <entity name='opportunity'>" +
            "    <attribute name='opportunityid' />" +
            "    <order attribute='estimatedclosedate' descending='false' />" +
            "    <order attribute='customerid' descending='false' />" +
            "    <filter type='and'>" +
            "      <filter type='or'>" +
            "        <condition attribute='niq_stage' operator='eq' value='Negotiation' />" +
            "        <filter type='and'>" +
            "          <condition attribute='niq_stage' operator='eq' value='Closed Won - In Review' />" +
            "          <condition attribute='niq_approvalstatus' operator='in'>" +
            "            <value>100000003</value>" +
            "            <value>100000004</value>" +
            "          </condition>" +
            "        </filter>" +
            "      </filter>" +
            "      <condition attribute='niq_mainquoteid' operator='eq' uitype='quote' value='" + formContext.data.entity.getEntityReference().id + "' />" +
            "    </filter>" +
            "    <link-entity name='quote' from='quoteid' to='niq_mainquoteid' link-type='inner' alias='ab'>" +
            "      <filter type='and'>" +
            "        <condition attribute='niq_overalldealdeskapproval' operator='in'>" +
            "          <value>6</value>" +
            "          <value>5</value>" +
            "        </condition>" +
            "      </filter>" +
            "    </link-entity>" +
            "  </entity>" +
            "</fetch>";
        var fetchResults = GetCRMWebAPI.Methods.GetFetchRecords(Xrm.Utility.getGlobalContext().getClientUrl(), fetchXML, "opportunities");
        if (fetchResults !== null && fetchResults.value.length > 0 && clmgate1 !== null && clmgate1 === true && clmgate2 !== null && clmgate2 === true) {
            OpportunityFlag = true;
            var fetchQP = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' no-lock='true' top='1'>" +
                "  <entity name='quotedetail'>" +
                "    <attribute name='quotedetailname' />" +
                "    <attribute name='quotedetailid' />" +
                "    <attribute name='niq_isqpscompleted' />" +
                "    <order attribute='quotedetailname' descending='false' />" +
                "    <filter type='and'>" +
                "       <condition attribute='niq_isqpscompleted' operator='eq' value='0' />" +
                "      <condition attribute='quoteid' operator='eq' uitype='quote' value='" + formContext.data.entity.getEntityReference().id + "' />" +
                "    </filter>" +
                "  </entity>" +
                "</fetch>";
            var fetchQPResults = GetCRMWebAPI.Methods.GetFetchRecords(Xrm.Utility.getGlobalContext().getClientUrl(), fetchQP, "quotedetails");

 

            /*var fetchQP = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' no-lock='true' top='1'>" +
                "  <entity name='quotedetail'>" +
                "    <attribute name='quotedetailname' />" +
                "    <attribute name='quotedetailid' />" +
                "    <order attribute='quotedetailname' descending='false' />" +
                "    <filter type='and'>" +
                "       <condition attribute='niq_databasename' operator='null' />" +
                "      <condition attribute='quoteid' operator='eq' uitype='quote' value='" + formContext.data.entity.getEntityReference().id + "' />" +
                "    </filter>" +
                "  </entity>" +
                "</fetch>";
            var fetchQPDBNResults = GetCRMWebAPI.Methods.GetFetchRecords(Xrm.Utility.getGlobalContext().getClientUrl(), fetchQP, "quotedetails");*/
            if (fetchQPResults === null || fetchQPResults.value.length === 0)
                quoteProductFlag = true;
        }
        if ((OpportunityFlag === true && quoteProductFlag === true) || ((formContext.getAttribute("niq_congaagreementstatus").getValue() !== null && formContext.getAttribute("niq_congaagreementstatus").getValue() === 100000001 && formContext.getAttribute("niq_congasyncstatus").getValue() !== null && formContext.getAttribute("niq_congasyncstatus").getValue() === 100000002) || (formContext.getAttribute("niq_congaagreementstatus").getValue() !== null && formContext.getAttribute("niq_congaagreementstatus").getValue() === 100000006 && formContext.getAttribute("niq_congasyncstatus").getValue() !== null && formContext.getAttribute("niq_congasyncstatus").getValue() === 100000002)))
            return true;
        else
            return false;
    },

 

    onClickCreateAgreementButton: function (executionContext) {
        "use strict";
        var formContext = executionContext, attrCount = 0;

 

        if (CommonForm.Events.CheckFieldExists(formContext, "niq_clmgate2") && (formContext.getAttribute("niq_clmgate2").getValue() != true)) {
            Xrm.Navigation.openErrorDialog({ message: "This agreement type and agreement language is not supported by Conga yet." });
            return;
        }

 

        if (CommonForm.Events.CheckFieldExists(formContext, "niq_agreementtype") && CommonForm.Events.CheckFieldExists(formContext, "niq_agreementlanguage") && CommonForm.Events.CheckFieldExists(formContext, "niq_agreementautomation") && CommonForm.Events.CheckFieldExists(formContext, "niq_docusigncontactid") && CommonForm.Events.CheckFieldExists(formContext, "niq_billtopartyname")) {
            var fieldsInfo = !CommonForm.Events.CheckValueExists(formContext, "niq_agreementtype") ? "Agreement Type, " : "";
            fieldsInfo += !CommonForm.Events.CheckValueExists(formContext, "niq_agreementlanguage") ? "Agreement Language, " : "";
            fieldsInfo += !CommonForm.Events.CheckValueExists(formContext, "niq_agreementautomation") ? "Agreement Automation, " : "";
            fieldsInfo += !CommonForm.Events.CheckValueExists(formContext, "niq_docusigncontactid") ? "DocuSign Contact, " : "";
            fieldsInfo += !CommonForm.Events.CheckValueExists(formContext, "niq_billtopartyname") ? "Bill To Party " : "";
            if ((CommonForm.Events.CheckValueExists(formContext, "niq_agreementtype")) && (formContext.getAttribute("niq_agreementtype").getValue() === 100000002) && (CommonForm.Events.CheckFieldExists(formContext, "niq_parentmsaquoteid"))) {
                if (!(CommonForm.Events.CheckValueExists(formContext, "niq_parentmsaquoteid"))) {
                    fieldsInfo += "Parent MSA Quote";
                }
                else {
                    fieldsInfo += "";
                }
            }
            if (fieldsInfo.length > 0) {
                Xrm.Navigation.openErrorDialog({ message: "The following fields in Agreement Creation Details section still need to be populated in order to create agreement: " + fieldsInfo + ". Please note automated contracting should not be used at this time for Retailers, Financial Services, Government and Partner Network"});
                return;
            }
        }
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_congaagreementstatus") && (formContext.getAttribute("niq_congaagreementstatus").getValue() === 100000001 || formContext.getAttribute("niq_congaagreementstatus").getValue() === 100000006)) {
            Xrm.Navigation.openErrorDialog({ message: "Agreement creation process has been already launched for this quote. See Agreement Number and Conga Sync Status fields below for more detail." });
            return;
        }
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_congaagreementstatus") && (formContext.getAttribute("niq_congaagreementstatus").getValue() === null
            || formContext.getAttribute("niq_congaagreementstatus").getValue() === 100000000 || formContext.getAttribute("niq_congaagreementstatus").getValue() === 100000004)) {
            var confirmStrings = { text: "Do you wish to initiated the agreement creation process in Conga? \n" + toUnicodeVariant('Please note automated contracting should not be used at this time for Retailers, Financial Services, Government and Partner Network!','bold', 'bold'), cancelButtonLabel: "No", confirmButtonLabel: "Yes" };
            var confirmOptions = { height: 200, width: 450 };
            Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
                function (success) {
                    if (success.confirmed) {
                        if (CommonForm.Events.CheckFieldExists(formContext, "niq_congaagreementstatus") && CommonForm.Events.CheckFieldExists(formContext, "niq_congasyncstatus")) {
                            if (formContext.getAttribute("niq_congaagreementstatus").getValue() === 100000000 || !CommonForm.Events.CheckValueExists(formContext, "niq_congaagreementstatus")) {
                                attrCount++;
                                formContext.getAttribute("niq_congaagreementstatus").setValue(100000001);
                                formContext.getAttribute("niq_congasyncstatus").setValue(100000000);
                            }
                            else if (formContext.getAttribute("niq_congaagreementstatus").getValue() === 100000004) {
                                attrCount++;
                                formContext.getAttribute("niq_congaagreementstatus").setValue(100000006);
                                formContext.getAttribute("niq_congasyncstatus").setValue(100000003);
                            }
                        }
                        if (CommonForm.Events.CheckFieldExists(formContext, "niq_synctoclm") && attrCount > 0) {
                            formContext.getAttribute("niq_synctoclm").setValue(true);
                            formContext.data.entity.save();
                        }
                    }
                }
            );
        }
    }
}
var ReviseVisibility = (function () {

 

    //this variable stores if async operation was already completed
    var isAsyncOperationCompleted = false;
    //this variable stores the result - if button enabled or not
    var isButtonEnabled = false;

 

    function IsButtonEnabled(formContext) {
        //If async operation was already completed I just return the result of it
        if (isAsyncOperationCompleted) {
            return isButtonEnabled;
        }
        if (CommonForm.Events.CheckValueExists(formContext, "opportunityid")) {
            var oppoId = formContext.getAttribute("opportunityid").getValue()[0].id.replace("{", "").replace("}", "");
            Xrm.WebApi.online.retrieveRecord("opportunity", oppoId, "?$select=niq_stage").then(
                function success(result) {
                    isAsyncOperationCompleted = true;
                    var niq_stage = result["niq_stage"];
                    if (niq_stage === "Pre-Proposal" || niq_stage === "Proposal")
                        isButtonEnabled = true;

 

                    if (isButtonEnabled) {
                        formContext.ui.refreshRibbon();
                    }
                },
                function (error) {
                    isAsyncOperationCompleted = true;
                    Xrm.Navigation.openAlertDialog({ text: error.message });
                }
            );
        }
        else
            isAsyncOperationCompleted = true;

 

        return false;
    }

 

    return {
        IsButtonEnabled: IsButtonEnabled
    };
})();
function toUnicodeVariant(str, variant, flags) {
    const offsets = {
        m: [0x1d670, 0x1d7f6],
        b: [0x1d400, 0x1d7ce],
        i: [0x1d434, 0x00030],
        bi: [0x1d468, 0x00030],
        c: [0x1d49c, 0x00030],
        bc: [0x1d4d0, 0x00030],
        g: [0x1d504, 0x00030],
        d: [0x1d538, 0x1d7d8],
        bg: [0x1d56c, 0x00030],
        s: [0x1d5a0, 0x1d7e2],
        bs: [0x1d5d4, 0x1d7ec],
        is: [0x1d608, 0x00030],
        bis: [0x1d63c, 0x00030],
        o: [0x24B6, 0x2460],
        p: [0x249C, 0x2474],
        w: [0xff21, 0xff10],
        u: [0x2090, 0xff10]
    }

    const variantOffsets = {
        'monospace': 'm',
        'bold': 'b',
        'italic': 'i',
        'bold italic': 'bi',
        'script': 'c',
        'bold script': 'bc',
        'gothic': 'g',
        'gothic bold': 'bg',
        'doublestruck': 'd',
        'sans': 's',
        'bold sans': 'bs',
        'italic sans': 'is',
        'bold italic sans': 'bis',
        'parenthesis': 'p',
        'circled': 'o',
        'fullwidth': 'w'
    }

    // special characters (absolute values)
    var special = {
        m: {
            ' ': 0x2000,
            '-': 0x2013
        },
        i: {
            'h': 0x210e
        },
        g: {
            'C': 0x212d,
            'H': 0x210c,
            'I': 0x2111,
            'R': 0x211c,
            'Z': 0x2128
        },
        o: {
            '0': 0x24EA,
            '1': 0x2460,
            '2': 0x2461,
            '3': 0x2462,
            '4': 0x2463,
            '5': 0x2464,
            '6': 0x2465,
            '7': 0x2466,
            '8': 0x2467,
            '9': 0x2468,
        },
        p: {},
        w: {}
    }
    //support for parenthesized latin letters small cases 
    for (var i = 97; i <= 122; i++) {
        special.p[String.fromCharCode(i)] = 0x249C + (i - 97)
    }
    //support for full width latin letters small cases 
    for (var i = 97; i <= 122; i++) {
        special.w[String.fromCharCode(i)] = 0xff41 + (i - 97)
    }

    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';

    var getType = function (variant) {
        if (variantOffsets[variant]) return variantOffsets[variant]
        if (offsets[variant]) return variant;
        return 'm'; //monospace as default
    }
    var getFlag = function (flag, flags) {
        if (!flags) return false
        return flags.split(',').indexOf(flag) > -1
    }

    var type = getType(variant);
    var underline = getFlag('underline', flags);
    var strike = getFlag('strike', flags);
    var result = '';

    for (var k of str) {
        let index
        let c = k
        if (special[type] && special[type][c]) c = String.fromCodePoint(special[type][c])
        if (type && (index = chars.indexOf(c)) > -1) {
            result += String.fromCodePoint(index + offsets[type][0])
        } else if (type && (index = numbers.indexOf(c)) > -1) {
            result += String.fromCodePoint(index + offsets[type][1])
        } else {
            result += c
        }
        if (underline) result += '\u0332' // add combining underline
        if (strike) result += '\u0336' // add combining strike
    }
    return result
}