if (typeof (UserAccessRequestForm) === "undefined") {
    UserAccessRequestForm = {
        _namespace: true
    };
}
UserAccessRequestForm.Events = {

    setVisibleAndRequireBasesPrimary: function (executionContext) {
        // Getting formContext 
        var formContext = executionContext.getFormContext();


        var field = formContext.getAttribute("niq_primaryfunction").getValue();

        if (field == 1) {


            formContext.getControl("niq_basesprimaryworkstream").setVisible(true);

            formContext.getAttribute("niq_basesprimaryworkstream").setRequiredLevel("required");
        }

        else {


            formContext.getControl("niq_basesprimaryworkstream").setVisible(false);

            formContext.getAttribute("niq_basesprimaryworkstream").setRequiredLevel("none");

        }
    }
}
