﻿using System;
using System.Linq;
using System.Text;
using System.Activities;
using Microsoft.Xrm.Sdk;

using Newtonsoft.Json.Linq;
using System.Data;
using System.Globalization;

namespace NIQ.CRM.Tool.Sales
{
    public class GetDeliverySchedulePayLoad
    {
        
        public string QuoteProductsPayLoad { get; set; }
         public string SchedulesPayLoad { get; set; }
         public string QuoteProductCharPayLoad { get; set; }
         public string DeliveryResponsePayLoad { get; set; }

        StringBuilder sbPayload;
        public void Execute(IOrganizationService service)
        {
          
            try
            {
                sbPayload = new StringBuilder();
                var jobjQuoteProductsPayLoad = JObject.Parse(QuoteProductsPayLoad);
                var jobjSchedulesPayLoad = JObject.Parse(SchedulesPayLoad);
                var jobjQuoteProductCharPayLoad = JObject.Parse(QuoteProductCharPayLoad);
               BuildDeliverySchedulePayload(jobjQuoteProductsPayLoad, jobjSchedulesPayLoad, jobjQuoteProductCharPayLoad, null);
                
            }
            catch (Exception ex)
            {
               
                throw ex;
            }
        }

        public void BuildDeliverySchedulePayload(JObject jobjQuoteProductsPayLoad, JObject jobjSchedulesPayLoad, JObject jobjQuoteProductCharPayLoad, ITracingService tracingService)
        {
            try
            {
               
               
             
                JArray QuoteProductsJarry = (JArray)jobjQuoteProductsPayLoad["value"];
                JArray QuoteProductCharJarry = (JArray)jobjQuoteProductCharPayLoad["value"];
                JArray SchedulesJarry = (JArray)jobjSchedulesPayLoad["value"];
                foreach (var prod in QuoteProductsJarry)
                {
                    bool basedOnShortCycle = false;
                    var deliverycreationlogic = (Int32)prod["productpricelevel.niq_deliverycreationlogic"];
                   
                    if (deliverycreationlogic == 100000001 || deliverycreationlogic == 100000004)// All Schedule or Based on Short Cycle
                    {
                        if (deliverycreationlogic == 100000001)
                        {
                            basedOnShortCycle = true;
                        }
                        else
                        {
                            JArray quoteProductCharJson = JArray.FromObject(QuoteProductCharJarry.Where(o => (string)o["quotedetailid"] == (string)prod["quotedetailid"]));
                            if (quoteProductCharJson != null && quoteProductCharJson.Count > 0)
                            {
                                basedOnShortCycle = true;
                            }
                        }

                        if (basedOnShortCycle)
                        {
                            JArray allSchedulesJson = JArray.FromObject(SchedulesJarry.Where(o => (string)o["_niq_lineitemid_value"] == (string)prod["quotedetailid"]));
                            if (allSchedulesJson != null && allSchedulesJson.Count > 0)
                            {
                                foreach (var schedule in allSchedulesJson)
                                {
                                    if (schedule["niq_scheduledate"] != null && schedule["createdon"] != null)
                                    {
                                         CreateDelivery(Convert.ToDateTime(schedule["niq_scheduledate"]), prod["quotedetailname"].ToString(), schedule["niq_amount"].ToString(), prod["quotedetailid"].ToString(), schedule["niq_scheduleid"].ToString());
                                      
                                    }
                                }
                            }
                           
                        }
                    }

                    if (deliverycreationlogic == 100000002)//First schedule
                    {                       
                        JArray firstSchedulesJson = JArray.FromObject(SchedulesJarry.Where(o => (string)o["_niq_lineitemid_value"] == (string)prod["quotedetailid"]));
                        if (firstSchedulesJson != null && firstSchedulesJson.FirstOrDefault().Count() > 0)
                        {
                            if (firstSchedulesJson.FirstOrDefault()?["niq_scheduledate"]?.Value<string>() != null 
                                && firstSchedulesJson.FirstOrDefault()?["createdon"]?.Value<string>() != null)
                            {
                                CreateDelivery(Convert.ToDateTime(firstSchedulesJson.FirstOrDefault()?["niq_scheduledate"]?.Value<string>()), 
                                                             prod["quotedetailname"].ToString(), 
                                                             firstSchedulesJson.FirstOrDefault()?["niq_amount"]?.Value<string>(), 
                                                             prod["quotedetailid"].ToString(), 
                                                             firstSchedulesJson.FirstOrDefault()?["niq_scheduleid"]?.Value<string>());
                              
                            }

                        }
                     
                    }
                    if (deliverycreationlogic == 100000003)//Last Schedule
                    {
                        JArray lastSchedulesJson = JArray.FromObject(SchedulesJarry.Where(o => (string)o["_niq_lineitemid_value"] == (string)prod["quotedetailid"]).OrderByDescending(x => x["niq_scheduledate"]));
                        if (lastSchedulesJson != null && lastSchedulesJson.Count > 0)
                        {
                            if (lastSchedulesJson.FirstOrDefault()?["niq_scheduledate"]?.Value<string>() != null
                                && lastSchedulesJson.FirstOrDefault()?["createdon"]?.Value<string>() != null)
                            {
                                 CreateDelivery(Convert.ToDateTime(lastSchedulesJson.FirstOrDefault()?["niq_scheduledate"]?.Value<string>()),
                                                             prod["quotedetailname"].ToString(),
                                                             lastSchedulesJson.FirstOrDefault()?["niq_amount"]?.Value<string>(), 
                                                             prod["quotedetailid"].ToString(),
                                                             lastSchedulesJson.FirstOrDefault()?["niq_scheduleid"]?.Value<string>());
                             
                            }
                        }
                       
                    }
                    if (deliverycreationlogic == 100000005)//Quoteproductenddate
                    {
                        JArray endSchedulesJson = JArray.FromObject(SchedulesJarry.Where(o => (string)o["_niq_lineitemid_value"] == (string)prod["quotedetailid"]).OrderByDescending(x => x["niq_scheduledate"]));
                        if (endSchedulesJson != null && endSchedulesJson.Count() > 0)
                        {
                            if (endSchedulesJson.FirstOrDefault()?["niq_scheduleid"]?.Value<string>() != null
                                && endSchedulesJson.FirstOrDefault()?["niq_scheduledate"]?.Value<string>() != null
                                && endSchedulesJson.FirstOrDefault()?["createdon"]?.Value<string>() != null)
                            {
                               CreateDelivery(Convert.ToDateTime(prod["niq_lineitemenddate"]), 
                                                                     prod["quotedetailname"].ToString(),
                                                                     endSchedulesJson.FirstOrDefault()?["niq_amount"]?.Value<string>(), 
                                                                     prod["quotedetailid"].ToString(),
                                                                     endSchedulesJson.FirstOrDefault()?["niq_scheduleid"]?.Value<string>());
                             
                            }
                        }
                         
                    }

                }
               
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
      
        public void CreateDelivery(DateTime scheduledate, string quotedetailname, string deliveryamount, string quoteProductid, string quoteProdScheduleid)
        {
            
            sbPayload.AppendLine("{");
            sbPayload.AppendLine(string.Format("\"name\":\"{0}\",", scheduledate.ToString("dd.MM.yyyy", CultureInfo.CurrentCulture) + "_" + quotedetailname));
            sbPayload.AppendLine(string.Format("\"niq_deliveryamount\":\"{0}\",", Convert.ToString(deliveryamount)));
            sbPayload.AppendLine(string.Format("\"niq_scheduledate\":\"{0}\",", Convert.ToString(scheduledate)));
            sbPayload.AppendLine(string.Format("\"niq_relatedquotelineitemid\":\"/quotedetails({0})\",", Convert.ToString(quoteProductid)));
            sbPayload.AppendLine(string.Format("\"niq_scheduleid\":\"/niq_schedules({0})\"", Convert.ToString(quoteProdScheduleid)));
            sbPayload.AppendLine("},");
        
        }

    }
}
