﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;
using System.Configuration;
using System.IO;

namespace NielsenIQ.CRM.Plugins
{
    public class CreateDelivery_Plugin
    {
        IOrganizationService service;
        string filelogpath = "";
        public CreateDelivery_Plugin(IOrganizationService service)
        {
            this.service = service;
            filelogpath = string.Format(@".\log_{0}.txt",DateTime.Now.ToString("yyyyMMddhhmmss"));
            // File.CreateText(filelogpath);
            using (StreamWriter writer = new StreamWriter(filelogpath)) ;
          
        }
        public void Execute(Guid opportunityid)
        {
            try
            {
                Entity oppoObj = new Entity("opportunity", opportunityid);
                oppoObj["statecode"] = new OptionSetValue(1);
               //Extract the tracing service for use in debugging sandboxed plug-ins.

                // The InputParameters collection contains all the data  
                         
                        File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: Getting the target entity from Input Parameters.");
                // Obtain the target entity from the input parameters.
                if (oppoObj != null && oppoObj.Id != Guid.Empty && oppoObj.Attributes.Contains("statecode"))
                {
                    int stateCode = oppoObj.GetAttributeValue<OptionSetValue>("statecode").Value;
                    if (stateCode == 1)
                    {
                        File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: Oppo Status 1.");

                        Entity retOppo = service.Retrieve(oppoObj.LogicalName, oppoObj.Id, new ColumnSet("ownerid", "niq_mainquoteid", "transactioncurrencyid"));
                        if (retOppo != null && retOppo.Id != Guid.Empty && retOppo.Attributes.Contains("niq_mainquoteid") && retOppo.GetAttributeValue<EntityReference>("niq_mainquoteid").Id != Guid.Empty)
                        {
                            File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: ret Oppo" + retOppo.Id);
                            Entity retQuote = service.Retrieve(retOppo.GetAttributeValue<EntityReference>("niq_mainquoteid").LogicalName, retOppo.GetAttributeValue<EntityReference>("niq_mainquoteid").Id, new ColumnSet("niq_salesorgid"));
                            if (retQuote != null && retQuote.Id != Guid.Empty && retQuote.Attributes.Contains("niq_salesorgid") && retQuote.GetAttributeValue<EntityReference>("niq_salesorgid").Id != Guid.Empty)
                            {
                                File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: retquote." + retQuote.Id);
                                string fetchXmlQuoteProducts = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='quotedetail'>
                                                                    <attribute name='quotedetailname' />
                                                                    <attribute name='niq_lineitemenddate' />
                                                                    <attribute name='quotedetailid' />
                                                                    <attribute name='productid' />
                                                                    <order attribute='quotedetailname' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='quoteid' operator='eq'  uitype='quote' value='{0}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";
                                fetchXmlQuoteProducts = string.Format(fetchXmlQuoteProducts, retQuote.Id);

                                var quoteProducts = service.RetrieveMultiple(new FetchExpression(fetchXmlQuoteProducts));
                                if (quoteProducts != null && quoteProducts.Entities != null && quoteProducts.Entities.Count > 0)
                                {
                                    string priceListQuery = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                      <entity name='pricelevel'>
                                                                        <attribute name='name' />
                                                                        <attribute name='pricelevelid' />
                                                                        <order attribute='name' descending='false' />
                                                                        <filter type='and'>
                                                                          <condition attribute='niq_salesorg' operator='eq' uitype='niq_salesorg' value='{0}' />
                                                                        </filter>
                                                                      </entity>
                                                                    </fetch>";
                                    priceListQuery = string.Format(priceListQuery, retQuote.GetAttributeValue<EntityReference>("niq_salesorgid").Id);
                                    var priceListRecords = service.RetrieveMultiple(new FetchExpression(priceListQuery));
                                    if (priceListRecords != null && priceListRecords.Entities != null && priceListRecords.Entities.Count > 0)
                                    {
                                        Entity priceList = priceListRecords.Entities.FirstOrDefault();
                                        File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: quoteProduct count." + quoteProducts.Entities.Count);
                                        foreach (Entity quoteProduct in quoteProducts.Entities)
                                        {
                                            if (quoteProduct != null && quoteProduct.Id != Guid.Empty && quoteProduct.Attributes.Contains("productid") && quoteProduct.GetAttributeValue<EntityReference>("productid").Id != Guid.Empty && quoteProduct.Attributes.Contains("quotedetailname"))
                                            {
                                                File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: quoteproduct id ." + quoteProduct.Id);
                                                string fetchXmlPricelistItems = @"<fetch top='1'>
                                                                                <entity name='productpricelevel'>
                                                                                <attribute name='niq_deliverycreationlogic' />
                                                                                <filter>
                                                                                    <condition attribute='pricelevelid' operator='eq' value='{0}' uitype='pricelevel' />
                                                                                    <condition attribute='productid' operator='eq' value='{1}'  uitype='product' />
                                                                                </filter>
                                                                                </entity>
                                                                            </fetch>";
                                                fetchXmlPricelistItems = string.Format(fetchXmlPricelistItems, priceList.Id, quoteProduct.GetAttributeValue<EntityReference>("productid").Id);

                                                Entity priceListItem = service.RetrieveMultiple(new FetchExpression(fetchXmlPricelistItems)).Entities.FirstOrDefault();

                                                if (priceListItem != null && priceListItem.Id != Guid.Empty && priceListItem.Attributes.Contains("niq_deliverycreationlogic"))
                                                {
                                                    File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: ret pricelist item" + priceListItem.Id);
                                                    int delieveryLogic = priceListItem.GetAttributeValue<OptionSetValue>("niq_deliverycreationlogic").Value;
                                                    File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: delivery logic" + delieveryLogic);
                                                    bool basedOnShortCycle = true;
                                                    if (delieveryLogic == 100000001 || delieveryLogic == 100000004)// All Schedule or Based on Short Cycle
                                                    {
                                                        if (delieveryLogic == 100000001)
                                                        {
                                                            File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: basedonShortCycle False");
                                                            basedOnShortCycle = false;
                                                        }
                                                        else
                                                        {
                                                            string fetchXmlShortCycle = @"<fetch top='1' no-lock='true' version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                                                                                      <entity name='niq_quoteproductcharacteristic'>
                                                                                                        <attribute name='niq_name' />
                                                                                                        <attribute name='niq_quoteproductid' />
                                                                                                        <attribute name='niq_materialcharacteristicvalueid' />
                                                                                                        <attribute name='niq_materialcharacteristicid' />
                                                                                                        <attribute name='niq_quoteproductcharacteristicid' />
                                                                                                        <order attribute='niq_name' descending='false' />
                                                                                                        <filter type='and'>
                                                                                                          <condition attribute='niq_quoteproductid' operator='eq' uitype='quotedetail' value='{0}' />
                                                                                                          <condition attribute='niq_quoteid' operator='eq' uitype='quote' value='{1}' />
                                                                                                        </filter>
                                                                                                        <link-entity name='niq_characteristicvalue' from='niq_characteristicvalueid' to='niq_materialcharacteristicvalueid' link-type='inner' alias='az'>
                                                                                                          <filter type='and'>
                                                                                                            <condition attribute='niq_characteristicvaluecode' operator='eq' value='SC000003' />
                                                                                                          </filter>
                                                                                                        </link-entity>
                                                                                                        <link-entity name='quotedetail' from='quotedetailid' to='niq_quoteproductid' visible='false' link-type='outer' alias='a_4c4cfd74acc0ec1198400022487f7a7f'>
                                                                                                          <attribute name='quotedetailname' />
                                                                                                        </link-entity>
                                                                                                      </entity>
                                                                                                    </fetch>";

                                                            fetchXmlShortCycle = string.Format(fetchXmlShortCycle, quoteProduct.Id, retQuote.Id);
                                                            var result = service.RetrieveMultiple(new FetchExpression(fetchXmlShortCycle));
                                                            if (!(result != null && result.Entities != null && result.Entities.Count > 0))
                                                            {
                                                                File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: basedonShortCycle False");
                                                                basedOnShortCycle = false;
                                                            }
                                                        }
                                                        if (!basedOnShortCycle)
                                                        {
                                                            File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: basedonShortCycle False");
                                                            string fetchXmlAllScheduler = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                                      <entity name='niq_schedule'>
                                                                                        <attribute name='niq_scheduleid' />
                                                                                        <attribute name='niq_name' />
                                                                                        <attribute name='createdon' />
                                                                                        <attribute name='niq_scheduledate' />
                                                                                        <attribute name='niq_amount' />
                                                                                        <order attribute='niq_name' descending='false' />
                                                                                        <filter type='and'>
                                                                                          <condition attribute='niq_scheduletype' operator='in'>                                                                                                 
                                                                                                    <value>100000002</value>
                                                                                                    <value>100000001</value>
                                                                                           </condition>
                                                                                          <condition attribute='niq_lineitemid' operator='eq' uitype='quotedetail' value='{0}' />
                                                                                        </filter>
                                                                                      </entity>
                                                                                    </fetch>";
                                                            fetchXmlAllScheduler = string.Format(fetchXmlAllScheduler, quoteProduct.Id);
                                                            var quoteProductsSchedlures = service.RetrieveMultiple(new FetchExpression(fetchXmlAllScheduler));
                                                            if (quoteProductsSchedlures != null && quoteProductsSchedlures.Entities != null && quoteProductsSchedlures.Entities.Count > 0)
                                                            {
                                                                foreach (Entity quoteProdSchedule in quoteProductsSchedlures.Entities)
                                                                {
                                                                    File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler:quoteProdSchedule" + quoteProdSchedule.Id);

                                                                    if (quoteProdSchedule.Attributes.Contains("niq_scheduledate") && quoteProdSchedule.Attributes.Contains("createdon"))
                                                                    {
                                                                        File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: contains schedule date & created on" + quoteProdSchedule.GetAttributeValue<DateTime>("niq_scheduledate") + " created on " + quoteProdSchedule.GetAttributeValue<DateTime>("createdon"));

                                                                        CreateDelivery(quoteProdSchedule, retOppo, quoteProduct, priceList, service);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                    if (delieveryLogic == 100000002)//First schedule
                                                    {
                                                        string fetchXmlFirstScheduler = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                                      <entity name='niq_schedule'>
                                                                                        <attribute name='niq_scheduleid' />
                                                                                        <attribute name='niq_name' />
                                                                                        <attribute name='createdon' />
                                                                                        <attribute name='niq_scheduledate' />
                                                                                        <attribute name='niq_amount' />
                                                                                        <order attribute='niq_scheduledate' descending='false' />
                                                                                        <filter type='and'>
                                                                                          <condition attribute='niq_scheduletype' operator='in'>                                                                                              
                                                                                                 <value>100000002</value>
                                                                                                 <value>100000001</value>
                                                                                           </condition>
                                                                                          <condition attribute='niq_lineitemid' operator='eq' uitype='quotedetail' value='{0}' />
                                                                                        </filter>
                                                                                      </entity>
                                                                                    </fetch>";
                                                        fetchXmlFirstScheduler = string.Format(fetchXmlFirstScheduler, quoteProduct.Id);


                                                        Entity quoteProdSchedule = service.RetrieveMultiple(new FetchExpression(fetchXmlFirstScheduler)).Entities.FirstOrDefault();
                                                        if (quoteProdSchedule != null && quoteProdSchedule.Id != Guid.Empty && quoteProdSchedule.Attributes.Contains("niq_scheduledate") && quoteProdSchedule.Attributes.Contains("createdon"))
                                                        {
                                                            File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler:quoteProdSchedule" + quoteProdSchedule.Id);
                                                            File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: contains schedule date & created on" + quoteProdSchedule.GetAttributeValue<DateTime>("niq_scheduledate") + " created on " + quoteProdSchedule.GetAttributeValue<DateTime>("createdon"));
                                                            CreateDelivery(quoteProdSchedule, retOppo, quoteProduct, priceList, service);
                                                        }
                                                    }
                                                    if (delieveryLogic == 100000003)//Last Schedule
                                                    {
                                                        string fetchXmlLastScheduler = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                                      <entity name='niq_schedule'>
                                                                                        <attribute name='niq_scheduleid' />
                                                                                        <attribute name='niq_name' />
                                                                                        <attribute name='createdon' />
                                                                                        <attribute name='niq_scheduledate' />
                                                                                        <attribute name='niq_amount' />
                                                                                        <order attribute='niq_scheduledate' descending='true' />
                                                                                        <filter type='and'>
                                                                                          <condition attribute='niq_scheduletype' operator='in'>                                                                                                
                                                                                                 <value>100000002</value>
                                                                                                 <value>100000001</value>
                                                                                          </condition>
                                                                                          <condition attribute='niq_lineitemid' operator='eq' uitype='quotedetail' value='{0}' />
                                                                                        </filter>
                                                                                      </entity>
                                                                                    </fetch>";
                                                        fetchXmlLastScheduler = string.Format(fetchXmlLastScheduler, quoteProduct.Id);


                                                        Entity quoteProdSchedule = service.RetrieveMultiple(new FetchExpression(fetchXmlLastScheduler)).Entities.FirstOrDefault();
                                                        if (quoteProdSchedule != null && quoteProdSchedule.Id != Guid.Empty && quoteProdSchedule.Attributes.Contains("niq_scheduledate") && quoteProdSchedule.Attributes.Contains("createdon"))
                                                        {
                                                            File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler:quoteProdSchedule" + quoteProdSchedule.Id);
                                                            File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: contains schedule date & created on" + quoteProdSchedule.GetAttributeValue<DateTime>("niq_scheduledate") + " created on " + quoteProdSchedule.GetAttributeValue<DateTime>("createdon"));
                                                            CreateDelivery(quoteProdSchedule, retOppo, quoteProduct, priceList, service);
                                                        }
                                                    }
                                                    if (delieveryLogic == 100000005)//Quoteproductenddate
                                                    {
                                                        string fetchXmlLastScheduler = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                                      <entity name='niq_schedule'>
                                                                                        <attribute name='niq_scheduleid' />
                                                                                        <attribute name='niq_name' />
                                                                                        <attribute name='createdon' />
                                                                                        <attribute name='niq_scheduledate' />
                                                                                        <attribute name='niq_amount' />
                                                                                        <order attribute='niq_scheduledate' descending='true' />
                                                                                        <filter type='and'>
                                                                                          <condition attribute='niq_scheduletype' operator='in'>                                                                                                
                                                                                                 <value>100000002</value>
                                                                                                 <value>100000001</value>
                                                                                          </condition>
                                                                                          <condition attribute='niq_lineitemid' operator='eq' uitype='quotedetail' value='{0}' />
                                                                                        </filter>
                                                                                      </entity>
                                                                                    </fetch>";
                                                        fetchXmlLastScheduler = string.Format(fetchXmlLastScheduler, quoteProduct.Id);


                                                        Entity quoteProdSchedule = service.RetrieveMultiple(new FetchExpression(fetchXmlLastScheduler)).Entities.FirstOrDefault();
                                                        if (quoteProdSchedule != null && quoteProdSchedule.Id != Guid.Empty && quoteProdSchedule.Attributes.Contains("niq_scheduledate") && quoteProdSchedule.Attributes.Contains("createdon"))
                                                        {
                                                            File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler:quoteProdSchedule" + quoteProdSchedule.Id);
                                                            File.AppendAllText(filelogpath,Environment.NewLine +"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: contains schedule date & created on" + quoteProdSchedule.GetAttributeValue<DateTime>("niq_scheduledate") + " created on " + quoteProdSchedule.GetAttributeValue<DateTime>("createdon"));
                                                            CreateDeliveryforBases(quoteProdSchedule, retOppo, quoteProduct, priceList, service);
                                                        }
                                                    }

                                                }
                                            }
                                        }

                                    }
                                }
                            }
                        }
                    }


                }
                 
             

            }
            catch (Exception ex)
            {
                File.AppendAllText(filelogpath,Environment.NewLine +ex.Message);
            }

        }



        private void CreateDelivery(Entity quoteProdSchedule, Entity retOppo, Entity quoteProduct, Entity priceList, IOrganizationService service)
        {
            Entity createDeliverRecord = new Entity("niq_delivery");
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: delivery logic" + quoteProduct.GetAttributeValue<string>("quotedetailname"));

            string name = quoteProdSchedule.GetAttributeValue<DateTime>("niq_scheduledate").ToString("dd.MM.yyyy") + "_" + quoteProduct.GetAttributeValue<string>("quotedetailname");
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: name" + name);

            createDeliverRecord["niq_delivery"] = name;
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: ownerid" + retOppo.GetAttributeValue<EntityReference>("ownerid"));
            createDeliverRecord["ownerid"] = new EntityReference(retOppo.GetAttributeValue<EntityReference>("ownerid").LogicalName, retOppo.GetAttributeValue<EntityReference>("ownerid").Id);
            if (quoteProdSchedule.Attributes.Contains("niq_amount"))
            {
                File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: Amount" + quoteProdSchedule.GetAttributeValue<Money>("niq_amount"));
                createDeliverRecord["niq_deliveryamount"] = quoteProdSchedule.GetAttributeValue<Money>("niq_amount");
            }
            createDeliverRecord["niq_deliverystatus"] = new OptionSetValue(100000000);
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: Schedule Date" + quoteProdSchedule.GetAttributeValue<DateTime>("niq_scheduledate"));
            createDeliverRecord["niq_dateofdelivery"] = quoteProdSchedule.GetAttributeValue<DateTime>("niq_scheduledate");
            createDeliverRecord["niq_proposeddeliverydate"] = quoteProdSchedule.GetAttributeValue<DateTime>("niq_scheduledate");
            createDeliverRecord["niq_previouslyconfirmeddateofdelivery"] = quoteProdSchedule.GetAttributeValue<DateTime>("niq_scheduledate");
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: related quoteproduct" + quoteProduct.Id);
            createDeliverRecord["niq_relatedquotelineitemid"] = new EntityReference(quoteProduct.LogicalName, quoteProduct.Id);
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: related Pricelist" + priceList.Id);

            createDeliverRecord["niq_pricelistid"] = new EntityReference(priceList.LogicalName, priceList.Id);
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: related Oppo" + retOppo.Id);
            createDeliverRecord["niq_opportunityid"] = new EntityReference(retOppo.LogicalName, retOppo.Id);
            if (retOppo.Attributes.Contains("transactioncurrencyid") && retOppo.GetAttributeValue<EntityReference>("transactioncurrencyid").Id != Guid.Empty)
            {
                File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: related Oppo" + retOppo.Id);
                createDeliverRecord["transactioncurrencyid"] = (EntityReference)retOppo.GetAttributeValue<EntityReference>("transactioncurrencyid");
            }
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: related QuoteProdSchedule" + quoteProdSchedule.Id);
            createDeliverRecord["niq_scheduleid"] = new EntityReference(quoteProdSchedule.LogicalName, quoteProdSchedule.Id);

            Guid deliverId = service.Create(createDeliverRecord);
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: delivery record" + deliverId.ToString());
        }
        private void CreateDeliveryforBases(Entity quoteProdSchedule, Entity retOppo, Entity quoteProduct, Entity priceList, IOrganizationService service)
        {
            Entity createDeliverRecord = new Entity("niq_delivery");
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: delivery logic" + quoteProduct.GetAttributeValue<string>("quotedetailname"));

            string name = quoteProduct.GetAttributeValue<DateTime>("niq_lineitemenddate").ToString("dd.MM.yyyy") + "_" + quoteProduct.GetAttributeValue<string>("quotedetailname");
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: name" + name);

            createDeliverRecord["niq_delivery"] = name;
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: ownerid" + retOppo.GetAttributeValue<EntityReference>("ownerid"));
            createDeliverRecord["ownerid"] = new EntityReference(retOppo.GetAttributeValue<EntityReference>("ownerid").LogicalName, retOppo.GetAttributeValue<EntityReference>("ownerid").Id);
            if (quoteProdSchedule.Attributes.Contains("niq_amount"))
            {
                File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: Amount" + quoteProdSchedule.GetAttributeValue<Money>("niq_amount"));
                createDeliverRecord["niq_deliveryamount"] = quoteProdSchedule.GetAttributeValue<Money>("niq_amount");
            }
            createDeliverRecord["niq_deliverystatus"] = new OptionSetValue(100000000);
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: Schedule Date" + quoteProduct.GetAttributeValue<DateTime>("niq_lineitemenddate"));
            createDeliverRecord["niq_dateofdelivery"] = quoteProduct.GetAttributeValue<DateTime>("niq_lineitemenddate");
            createDeliverRecord["niq_proposeddeliverydate"] = quoteProduct.GetAttributeValue<DateTime>("niq_lineitemenddate");
            createDeliverRecord["niq_previouslyconfirmeddateofdelivery"] = quoteProduct.GetAttributeValue<DateTime>("niq_lineitemenddate");
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: related quoteproduct" + quoteProduct.Id);
            createDeliverRecord["niq_relatedquotelineitemid"] = new EntityReference(quoteProduct.LogicalName, quoteProduct.Id);
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: related Pricelist" + priceList.Id);

            createDeliverRecord["niq_pricelistid"] = new EntityReference(priceList.LogicalName, priceList.Id);
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: related Oppo" + retOppo.Id);
            createDeliverRecord["niq_opportunityid"] = new EntityReference(retOppo.LogicalName, retOppo.Id);
            if (retOppo.Attributes.Contains("transactioncurrencyid") && retOppo.GetAttributeValue<EntityReference>("transactioncurrencyid").Id != Guid.Empty)
            {
                File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: related Oppo" + retOppo.Id);
                createDeliverRecord["transactioncurrencyid"] = (EntityReference)retOppo.GetAttributeValue<EntityReference>("transactioncurrencyid");
            }
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: related QuoteProdSchedule" + quoteProdSchedule.Id);
            createDeliverRecord["niq_scheduleid"] = new EntityReference(quoteProdSchedule.LogicalName, quoteProdSchedule.Id);

            Guid deliverId = service.Create(createDeliverRecord);
            File.AppendAllText(filelogpath,"OnClosedWon_Opportunity_CreateDelievery_QuoteProducts_Scheduler: delivery record" + deliverId.ToString());
        }
    }
}
