﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NIQ.CRM.Tool.Sales
{
    public partial class DebugForm : Form
    {
        public DebugForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Utility util = new Utility();
            GetDeliverySchedulePayLoad paload = new GetDeliverySchedulePayLoad();
            paload.QuoteProductsPayLoad= File.ReadAllText(@"..\..\Jsonfiles\QuoteProducts.json");
            paload.QuoteProductCharPayLoad = File.ReadAllText(@"..\..\Jsonfiles\QuoteProductsChar.json");
            paload.SchedulesPayLoad = File.ReadAllText(@"..\..\Jsonfiles\Schedules.json");
            paload.Execute(util.service);
        }
    }
}
