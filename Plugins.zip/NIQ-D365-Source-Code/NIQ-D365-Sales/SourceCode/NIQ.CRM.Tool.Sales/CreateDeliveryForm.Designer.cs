﻿namespace NIQ.CRM.Tool.Sales
{
    partial class CreateDeliveryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txt_OptyGUID = new System.Windows.Forms.TextBox();
            this.btn_createdelivery = new System.Windows.Forms.Button();
            this.lbl_processing = new System.Windows.Forms.Label();
            this.btn_wonOpty = new System.Windows.Forms.Button();
            this.btn_deleteDel = new System.Windows.Forms.Button();
            this.btn_SetBPF = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Opportunity GUID";
            // 
            // txt_OptyGUID
            // 
            this.txt_OptyGUID.Location = new System.Drawing.Point(120, 13);
            this.txt_OptyGUID.Name = "txt_OptyGUID";
            this.txt_OptyGUID.Size = new System.Drawing.Size(264, 20);
            this.txt_OptyGUID.TabIndex = 1;
            // 
            // btn_createdelivery
            // 
            this.btn_createdelivery.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_createdelivery.Location = new System.Drawing.Point(43, 117);
            this.btn_createdelivery.Name = "btn_createdelivery";
            this.btn_createdelivery.Size = new System.Drawing.Size(113, 46);
            this.btn_createdelivery.TabIndex = 2;
            this.btn_createdelivery.Text = "Create Delivery";
            this.btn_createdelivery.UseVisualStyleBackColor = false;
            this.btn_createdelivery.Click += new System.EventHandler(this.btn_createdelivery_Click);
            // 
            // lbl_processing
            // 
            this.lbl_processing.AutoSize = true;
            this.lbl_processing.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_processing.ForeColor = System.Drawing.Color.Green;
            this.lbl_processing.Location = new System.Drawing.Point(94, 180);
            this.lbl_processing.Name = "lbl_processing";
            this.lbl_processing.Size = new System.Drawing.Size(245, 29);
            this.lbl_processing.TabIndex = 3;
            this.lbl_processing.Text = "PROCESSING.......";
            this.lbl_processing.Visible = false;
            // 
            // btn_wonOpty
            // 
            this.btn_wonOpty.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_wonOpty.Location = new System.Drawing.Point(43, 51);
            this.btn_wonOpty.Name = "btn_wonOpty";
            this.btn_wonOpty.Size = new System.Drawing.Size(114, 46);
            this.btn_wonOpty.TabIndex = 4;
            this.btn_wonOpty.Text = "Won Opportunity";
            this.btn_wonOpty.UseVisualStyleBackColor = false;
            this.btn_wonOpty.Click += new System.EventHandler(this.btn_wonOpty_Click);
            // 
            // btn_deleteDel
            // 
            this.btn_deleteDel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_deleteDel.Location = new System.Drawing.Point(205, 117);
            this.btn_deleteDel.Name = "btn_deleteDel";
            this.btn_deleteDel.Size = new System.Drawing.Size(103, 46);
            this.btn_deleteDel.TabIndex = 5;
            this.btn_deleteDel.Text = "Delete Delivery";
            this.btn_deleteDel.UseVisualStyleBackColor = false;
            this.btn_deleteDel.Click += new System.EventHandler(this.btn_deleteDel_Click);
            // 
            // btn_SetBPF
            // 
            this.btn_SetBPF.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_SetBPF.Location = new System.Drawing.Point(205, 51);
            this.btn_SetBPF.Name = "btn_SetBPF";
            this.btn_SetBPF.Size = new System.Drawing.Size(179, 46);
            this.btn_SetBPF.TabIndex = 6;
            this.btn_SetBPF.Text = "Set BPF= Closed Won-Approved";
            this.btn_SetBPF.UseVisualStyleBackColor = false;
            this.btn_SetBPF.Click += new System.EventHandler(this.btn_SetBPF_Click);
            // 
            // CreateDeliveryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(402, 227);
            this.Controls.Add(this.btn_SetBPF);
            this.Controls.Add(this.btn_deleteDel);
            this.Controls.Add(this.btn_wonOpty);
            this.Controls.Add(this.lbl_processing);
            this.Controls.Add(this.btn_createdelivery);
            this.Controls.Add(this.txt_OptyGUID);
            this.Controls.Add(this.label1);
            this.Name = "CreateDeliveryForm";
            this.Text = "Create Delivery";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_OptyGUID;
        private System.Windows.Forms.Button btn_createdelivery;
        private System.Windows.Forms.Label lbl_processing;
        private System.Windows.Forms.Button btn_wonOpty;
        private System.Windows.Forms.Button btn_deleteDel;
        private System.Windows.Forms.Button btn_SetBPF;
    }
}

