﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.Plugins;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NIQ.CRM.Tool.Sales
{
    public partial class CreateDeliveryForm : Form
    {
        Utility objUtility  = new Utility();
        string filelogpath;
        public CreateDeliveryForm()
        {
            InitializeComponent();
        }

        private void btn_createdelivery_Click(object sender, EventArgs e)
        {
            try
            {
                this.btn_createdelivery.Enabled = false;
                this.lbl_processing.Visible = true;
                CreateDelivery_Plugin obj = new CreateDelivery_Plugin(objUtility.service);
                obj.Execute(Guid.Parse(this.txt_OptyGUID.Text.Trim()));
                this.lbl_processing.Visible = false;
                MessageBox.Show("Completed. Please see log file");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message + ex.StackTrace);
            }
            finally {
                this.btn_createdelivery.Enabled = true;
                this.lbl_processing.Visible = false;
            }
           
        }
        
        private void btn_wonOpty_Click(object sender, EventArgs e)
        {
            try
            {
                this.btn_wonOpty.Enabled = false;
                this.lbl_processing.Visible = true;
                filelogpath = string.Format(@".\WonOptylog_{0}.txt", DateTime.Now.ToString("yyyyMMddhhmmss"));
                using (StreamWriter writer = new StreamWriter(filelogpath)) ;
                Entity oppty = new Entity("opportunity", Guid.Parse(this.txt_OptyGUID.Text.Trim()));

                Entity OpporClose = new Entity("opportunityclose");

                OpporClose["actualend"] = DateTime.Now;
                OpporClose["opportunityid"] = new EntityReference(oppty.LogicalName, oppty.Id);
                OpporClose["opportunitystatecode"] = new OptionSetValue(1);
                OpporClose["opportunitystatuscode"] = new OptionSetValue(3);
                objUtility.service.Create(OpporClose);
                File.AppendAllText(filelogpath, Environment.NewLine + "Won Opportunity-" + txt_OptyGUID.Text.Trim());
                //Update Opportunity
                oppty["niq_closeprobability"] = new OptionSetValue(100000006);
                oppty["niq_stage"] = "Closed Won - Approved";
                objUtility.service.Update(oppty);
                File.AppendAllText(filelogpath, Environment.NewLine + "Update  Opportunity stage - 'Closed Won - Approved'");

                MessageBox.Show("Won Opportunity : Completed.");

            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: Won Opportunity - " + ex.Message);
            }
            finally
            {
                this.btn_wonOpty.Enabled = true;
                this.lbl_processing.Visible = false;
            }
        }
        public Entity GetActiveBPFDetails(Entity entity, IOrganizationService service)
        {
            Entity activeProcessInstance = null;
            RetrieveProcessInstancesRequest entityBPFsRequest = new RetrieveProcessInstancesRequest
            {
                EntityId = entity.Id,
                EntityLogicalName = entity.LogicalName
            };
            RetrieveProcessInstancesResponse entityBPFsResponse = (RetrieveProcessInstancesResponse)service.Execute(entityBPFsRequest);
            if (entityBPFsResponse.Processes != null && entityBPFsResponse.Processes.Entities != null)
            {
                activeProcessInstance = entityBPFsResponse.Processes.Entities[0];
            }
            return activeProcessInstance;
        }
        public RetrieveActivePathResponse GetAllStagesOfSelectedBPF(Guid activeBPFId, Guid activeStageId, ref int currentStagePosition, IOrganizationService service)
        {
            // Retrieve the process stages in the active path of the current process instance
            RetrieveActivePathRequest pathReq = new RetrieveActivePathRequest
            {
                ProcessInstanceId = activeBPFId
            };
            RetrieveActivePathResponse pathResp = (RetrieveActivePathResponse)service.Execute(pathReq);
            for (int i = 0; i < pathResp.ProcessStages.Entities.Count; i++)
            {
                // Retrieve the active stage name and active stage position based on the activeStageId for the process instance
                if (pathResp.ProcessStages.Entities[i].Attributes["processstageid"].ToString() == activeStageId.ToString())
                {
                    currentStagePosition = i;
                }
            }
            return pathResp;
        }

        private void btn_deleteDel_Click(object sender, EventArgs e)
        {
            try
            {
                this.btn_deleteDel.Enabled = false;
                this.lbl_processing.Visible = true;
                filelogpath = string.Format(@".\DeleteDeliverlog_{0}.txt", DateTime.Now.ToString("yyyyMMddhhmmss"));
                using (StreamWriter writer = new StreamWriter(filelogpath)) ;
                string strFetchXml = string.Format(@"<fetch>
                          <entity name='niq_delivery'>
                            <attribute name='niq_deliveryid' />
                            <filter>
                              <condition attribute='niq_opportunityid' operator='eq' value='{0}' />
                            </filter>
                          </entity>
                        </fetch>", this.txt_OptyGUID.Text.Trim());

                File.AppendAllText(filelogpath, Environment.NewLine + "Fetchxml -> " + strFetchXml);
                List<Entity> lstEnt = objUtility.GetRecordsbyFetchxml(strFetchXml);

                if (lstEnt != null && lstEnt.Count > 0)
                {
                    File.AppendAllText(filelogpath, Environment.NewLine + "Record Fetched, Count -> "+ lstEnt.Count );
                    foreach (var item in lstEnt)
                    {
                        objUtility.service.Delete(item.LogicalName, item.Id);
                        File.AppendAllText(filelogpath, Environment.NewLine + "Deleted Delivery id -> " + item.Id);
                    }
                    MessageBox.Show("Deleted Delivery : Please see log.");
                }
                else
                    File.AppendAllText(filelogpath, Environment.NewLine + "No Record Found");

            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: Delete Deliveries." + ex.Message);
            }
            finally
            {
                this.btn_deleteDel.Enabled = true;
                this.lbl_processing.Visible = false;
            }

        }

        private void btn_SetBPF_Click(object sender, EventArgs e)
        {
            try
            {
                this.btn_SetBPF.Enabled = false;
                this.lbl_processing.Visible = true;
                filelogpath = string.Format(@".\SetBPFlog_{0}.txt", DateTime.Now.ToString("yyyyMMddhhmmss"));
                using (StreamWriter writer = new StreamWriter(filelogpath)) ;

                Entity oppty = new Entity("opportunity", Guid.Parse(this.txt_OptyGUID.Text.Trim()));
                string logicalNameOfBPF = "niq_bpf_opportunity";

                ConditionExpression condition2 = new ConditionExpression();
                condition2.AttributeName = "bpf_opportunityid";
                condition2.Operator = ConditionOperator.Equal;
                condition2.Values.Add(oppty.Id);

                FilterExpression filter2 = new FilterExpression();
                filter2.Conditions.Add(condition2);

                QueryExpression query2 = new QueryExpression("niq_bpf_opportunity");
                query2.ColumnSet.AddColumns("activestageid", "statecode", "statuscode");
                query2.Criteria.AddFilter(filter2);

                EntityCollection oppoBpf = objUtility.service.RetrieveMultiple(query2);


                File.AppendAllText(filelogpath, Environment.NewLine + "bpf retrieved successfully");
                foreach (var bpf in oppoBpf.Entities)
                {
                    var retBpf = objUtility.service.Retrieve(bpf.LogicalName, bpf.Id, new ColumnSet("statecode", "statuscode"));
                    if (retBpf.GetAttributeValue<OptionSetValue>("statecode").Value == 1)
                    {
                        objUtility.service.Execute(new SetStateRequest
                        {
                            EntityMoniker = new EntityReference(retBpf.LogicalName, retBpf.Id),
                            State = new OptionSetValue(0), //"Active"
                            Status = new OptionSetValue(1) //"Active"
                        });
                        File.AppendAllText(filelogpath, Environment.NewLine + "bpf 1 updated");
                    }

                }

                Entity activeProcessInstance = GetActiveBPFDetails(oppty, objUtility.service);
                if (activeProcessInstance != null)
                {
                    Guid activeBPFId = activeProcessInstance.Id;
                    Guid activeStageId = new Guid(activeProcessInstance.Attributes["processstageid"].ToString());
                    int currentStagePosition = -1;
                    RetrieveActivePathResponse pathResp = GetAllStagesOfSelectedBPF(activeBPFId, activeStageId, ref currentStagePosition, objUtility.service);
                    if (currentStagePosition > -1 && pathResp.ProcessStages != null && pathResp.ProcessStages.Entities != null && currentStagePosition + 1 < pathResp.ProcessStages.Entities.Count)
                    {
                        Guid nextStageId = (Guid)pathResp.ProcessStages.Entities[currentStagePosition + 1].Attributes["processstageid"];
                        Entity entBPF = new Entity(logicalNameOfBPF)
                        {
                            Id = activeBPFId
                        };
                        entBPF["activestageid"] = new EntityReference("processstage", nextStageId);
                        objUtility.service.Update(entBPF);

                        objUtility.service.Execute(new SetStateRequest
                        {
                            EntityMoniker = new EntityReference(logicalNameOfBPF, activeBPFId),
                            State = new OptionSetValue(1), //Status
                            Status = new OptionSetValue(2) //Status reason
                        });
                        File.AppendAllText(filelogpath, Environment.NewLine + "bpf 2 updated");
                    }
                }

                MessageBox.Show("BPF Stage is set with Closed Won - Approved");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
            finally
            {
                this.btn_SetBPF.Enabled = true;
                this.lbl_processing.Visible = false;
            }
        }
    }
}

