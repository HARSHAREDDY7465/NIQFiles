﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.IdentityModel.Metadata;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Principal;
using System.Workflow.Runtime.Tracking;

namespace NielsenIQ.ABO.Plugins
{
    public class Apply_Automatic_Renewal : IPlugin
    {
        private const string OpportunityEntityName = "opportunity";
        private const string OpportunityIdField = "opportunityid";
        private const string NameField = "name";
        private const string NIQCloseProbabilityField = "niq_closeprobability";
        private const string NIQIsCloneFormField = "niq_iscloneform";
        private const string NIQCloneOpportunityField = "niq_cloneopportunity";
        private const string NIQAmendedFromOpportunityField = "niq_amendedfromopportunity";
        private const string NIQCOLAField = "niq_cola";
        private const string NIQProductEnhancementField = "niq_productenhancement";
        private const string NIQContractDecisionField = "niq_contractdecision";
        private const string NIQAutomatedOpportunityField = "niq_automatedopportunity";
        private const string NIQAssetConfigIdField = "niq_assetconfigidinput";
        private const string NIQContractDateField = "niq_contractenddate";
        private const string NIQOpportunityTypeField = "niq_opportunitytype";
        private const string NIQExistingContractActionField = "niq_existingcontractaction";
        private const string NIQExistingContractExpirationField = "niq_existingcontractexpirationdate";
        private const string NIQEffectiveDateField = "niq_effectivedate";
        private const string NIQCreatedOnField = "createdon";
        private const string NIQCreatedByField = "createdby";
        private const string NIQModifiedByField = "modifiedby";
        private const string NIQStageField = "niq_stage";
        private const string NIQMainQuoteField = "niq_mainquoteid";
        private const string NIQModifiedOnField = "modifiedon";
        private const string NIQStateCodeField = "statecode";
        private const string NIQStatusCodeField = "statuscode";
        private const string NIQOpportunityNumberField = "niq_opportunitynumber";
        private const string NIQSapError = "niq_saperror";
        private const string NIQSapErrorText = "niq_saperrortext";
        private const string NIQSapContractFlowurl = "niq_sapcontractpaflowurl";
        private const string NIQSapIntegrationStatus = "niq_sapintegrationstatus";
        private const string NIQSapSalesDocumentId = "niq_sapsalesdocumentid";
        private const string NIQApprovalStatus = "niq_approvalstatus";
        private const string NIQHostOpportunity = "niq_hostopportunity";
        private const string NIQPODocumentationUrl = "niq_podocumentationurl";
        private const string NIQTempUrl = "niq_tempeoaurl";
        private const string NIQFinallyExecutedUrl = "niq_finallyexecutedagreementurl";
        private const string NIQExternalID = "niq_externalid";
        public static string NIQLeadId = "niq_leadid";
        public static string NIQOriginatingLead = "originatingleadid";
        public static string NIQCustomerponumber = "niq_customerponumber";
        public static string NIQCustomerpodate = "niq_customerpodate";
        public void Execute(IServiceProvider serviceProvider)
        {
            // Fetching services from the serviceProvider
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = factory.CreateOrganizationService(context.UserId);
            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            tracing.Trace("Plugin execution started.");

            // Try to get the input parameters
            if (TryGetInputParameters(context, out var opportunityIds))
            {
                var originalOpportunity = service.Retrieve("opportunity", new Guid(opportunityIds), new ColumnSet(true));
                if (originalOpportunity != null)
                {
                    tracing.Trace("Original Opportunity retrieved successfully.");
                    //DYNCRM-28063 mapping assetconfiginputid field on renewal opportunity
                    string commaSeperatedGuids = getcommaSeperatedAssetConfigIds(service, originalOpportunity.Id.ToString());
                    // Create a cloned opportunity
                    var clonedOpportunityId = CreateClonedOpportunity(originalOpportunity, tracing, service, context);
                    tracing.Trace($"Cloned Opportunity ID: {clonedOpportunityId}");

                    // Update the cloned opportunity with additional values
                    UpdateClonedOpportunity(service, originalOpportunity, clonedOpportunityId, tracing, commaSeperatedGuids);
                }
                else
                {
                    tracing.Trace("Original opportunity not found.");
                }
            }
            else
            {
                tracing.Trace("Required input parameters missing.");
            }
        }

        //DYNCRM-28063 mapping assetconfiginputid field on renewal opportunity
        /// <summary>
        /// Get Comma seperated all guids of originating opportunity
        /// </summary>
        /// <param name="service"></param>
        /// <param name="originatingOpportunityId"></param>
        /// <returns></returns>
        private string getcommaSeperatedAssetConfigIds(IOrganizationService service, string originatingOpportunityId)
        {
            string fetchXml = $@"<fetch>
	                            <entity name='niq_assetconfig'>
		                            <attribute name='niq_assetconfigid' />
		                            <filter type='and'>
			                            <condition attribute='niq_originatingopportunity' operator='eq' value='{originatingOpportunityId}' />
		                            </filter>
	                            </entity>
                            </fetch>";
            List<Entity> entities = service.RetrieveMultiple(new FetchExpression(fetchXml)).Entities.ToList();
            return string.Join(",", entities.Select(e => e.Id.ToString()));
        }

        private bool TryGetInputParameters(IPluginExecutionContext context, out string opportunityIds)
        {
            opportunityIds = null;

            if (context.InputParameters.TryGetValue("OpportunityIds", out var opportunityIdsObj))
            {
                opportunityIds = (string)opportunityIdsObj;
                return true;
            }

            // Log if the parameters are not found
            return false;
        }

        /// <summary>
        /// Create Clone Opportunity
        /// </summary>
        /// <param name="originalOpportunity"></param>
        /// <param name="assetConfigIds"></param>
        /// <param name="termStartdate"></param>
        /// <param name="termEnddate"></param>
        /// <param name="evergreenIncrease"></param>
        /// <param name="cola"></param>
        /// <param name="pe"></param>
        /// <param name="tracing"></param>
        /// <param name="service"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        private Guid CreateClonedOpportunity(Entity originalOpportunity, ITracingService tracing, IOrganizationService service, IPluginExecutionContext context)
        {
            var account = originalOpportunity.GetAttributeValue<EntityReference>("parentaccountid");
            tracing.Trace($"Cloning opportunity for account: {account.Name}.");

            // Initialize a new cloned opportunity entity
            Entity clonedOpportunity = new Entity("opportunity");

            // Dynamically copy attributes, skipping irrelevant ones
            CopyOpportunityAttributes(originalOpportunity, clonedOpportunity, account, tracing, context, service);

            // Create the cloned opportunity in CRM
            var clonedOpportunityId = service.Create(clonedOpportunity);
            context.OutputParameters["ClonedOpportunity"] = clonedOpportunityId;
            tracing.Trace($"Cloned opportunity created with ID: {clonedOpportunityId}");

            return clonedOpportunityId;
        }

        /// <summary>
        /// Create Clone Opportunity
        /// </summary>
        /// <param name="originalOpportunity"></param>
        /// <param name="clonedOpportunity"></param>
        /// <param name="account"></param>
        /// <param name="pe"></param>
        /// <param name="cola"></param>
        /// <param name="assetConfigIds"></param>
        /// <param name="assetConfigIds"></param>
        /// <param name="assetConfigIds"></param>
        /// <param name="tracing"></param>
        private void CopyOpportunityAttributes(Entity originalOpportunity, Entity clonedOpportunity, EntityReference account, ITracingService tracing, IPluginExecutionContext context, IOrganizationService service)
        {
            tracing.Trace("Copying attributes from the original opportunity to the cloned opportunity.");
            Entity ultimateoriginalOpp = CommonFunctions.RetrieveUltimateOriginalOpportunityDetails(originalOpportunity, tracing, service);

            foreach (var attribute in originalOpportunity.Attributes)
            {
                if (attribute.Key != NIQApprovalStatus && attribute.Key != OpportunityIdField && attribute.Key != NIQCreatedOnField && attribute.Key != NIQEffectiveDateField && attribute.Key != NIQCreatedByField && attribute.Key != NIQModifiedByField && attribute.Key != NIQStageField && attribute.Key != NIQMainQuoteField && attribute.Key != NIQAmendedFromOpportunityField && attribute.Key != NIQIsCloneFormField && attribute.Key != NIQCloneOpportunityField && attribute.Key != NIQEffectiveDateField &&
                    attribute.Key != NIQProductEnhancementField && attribute.Key != NIQCOLAField && attribute.Key != NIQAutomatedOpportunityField && attribute.Key != NIQCloseProbabilityField && attribute.Key != NIQContractDecisionField && attribute.Key != NIQAssetConfigIdField && attribute.Key != NIQModifiedOnField && attribute.Key != NIQStateCodeField && attribute.Key != NIQStatusCodeField && attribute.Key != NIQOpportunityNumberField &&
                    attribute.Key != NIQSapError && attribute.Key != NIQSapErrorText && attribute.Key != NIQSapContractFlowurl && attribute.Key != NIQSapIntegrationStatus && attribute.Key != NIQSapSalesDocumentId && attribute.Key != NIQOpportunityTypeField && attribute.Key != NIQHostOpportunity &&
                    attribute.Key != NIQFinallyExecutedUrl && attribute.Key != NIQTempUrl && attribute.Key != NIQPODocumentationUrl && attribute.Key != NIQExternalID && attribute.Key != NIQLeadId && attribute.Key != NIQOriginatingLead && attribute.Key != NIQCustomerpodate && attribute.Key!= NIQCustomerponumber)
                {
                    // Handle specific fields with custom logic
                    tracing.Trace($"Setting attribute {attribute.Key}");
                    switch (attribute.Key)
                    {
                        case "name":
                            //Code changes as per DYNCRM-28675
                            string opportunityname;
                            if (ultimateoriginalOpp != null && ultimateoriginalOpp.Contains("name") && ultimateoriginalOpp.TryGetAttributeValue<string>("name", out opportunityname))
                            {
                                clonedOpportunity["name"] = $"{opportunityname}_Renewal_{DateTime.Now:MMM dd yyyy}";
                            }
                            else
                                clonedOpportunity["name"] = $"{account.Name}_Renewal_{DateTime.Now:MMM dd yyyy}";

                            tracing.Trace($"Setting Name field for cloned opportunity: {clonedOpportunity["name"]}");
                            break;

                        default:
                            // Default case for other attributes
                            if (attribute.Value is EntityReference lookupValue)
                            {
                                clonedOpportunity[attribute.Key] = new EntityReference(lookupValue.LogicalName, lookupValue.Id);
                                tracing.Trace($"Setting lookup field {attribute.Key} with reference {lookupValue.Id}");
                            }
                            else
                            {
                                clonedOpportunity[attribute.Key] = attribute.Value;
                                tracing.Trace($"Copying field {attribute.Key} with value {attribute.Value}");
                            }
                            break;
                    }
                }
            }
            DateTime startDate = originalOpportunity.GetAttributeValue<DateTime>("niq_contractstartdate");
            DateTime endDate = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate");
            TimeSpan difference = endDate - startDate;
            //double totalDays = difference.TotalDays;
            int totalMonths = GetFullMonthsBetweenDates(startDate, endDate);
            clonedOpportunity["estimatedclosedate"] = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate").ToUniversalTime().AddDays(-30); ;
            clonedOpportunity["niq_contractstartdate"] = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate").ToUniversalTime().AddDays(+1);
            clonedOpportunity["niq_automaticrenewalstartdate"] = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate").ToUniversalTime().AddDays(+1);
            clonedOpportunity["niq_contractenddate"] = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate").ToUniversalTime().AddDays(+1).AddMonths(totalMonths);
            clonedOpportunity["niq_automaticrenewalenddate"] = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate").ToUniversalTime().AddMonths(totalMonths);
            clonedOpportunity["niq_automaticrenewal"] = true;
            clonedOpportunity["ownerid"] = originalOpportunity.GetAttributeValue<EntityReference>("ownerid");
            clonedOpportunity["niq_opportunitytype"] = new OptionSetValue(1);
            clonedOpportunity["niq_existingcontractaction"] = new OptionSetValue(3);
            clonedOpportunity["niq_contractdecision"] = new OptionSetValue(100000002);
            clonedOpportunity["niq_existingsapsalesdocumentid"] = originalOpportunity.GetAttributeValue<string>("niq_sapsalesdocumentid");
            clonedOpportunity["niq_existingcontractexpirationdate"] = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate");
            clonedOpportunity["niq_amendedfromopportunity"] = new EntityReference("opportunity", originalOpportunity.Id);

            clonedOpportunity["niq_cloneopportunity"] = originalOpportunity.ToEntityReference();

            clonedOpportunity["niq_iscloneform"] = true;
            tracing.Trace($"Setting NIQIsCloneFormField to true.");

            clonedOpportunity["niq_amendedfromopportunity"] = originalOpportunity.ToEntityReference();
           
            //Code changes for DYNCRM-28652
            if (ultimateoriginalOpp != null)
                clonedOpportunity["niq_ultimateoriginalopportunityid"] = ultimateoriginalOpp.ToEntityReference();
           
        }

        /// <summary>
        /// Get latest EstimatedDate from selected assets configs
        /// </summary>
        /// <param name="assetIds"></param>
        /// <param name="service"></param>
        public DateTime GetEstimatedDate(string assetIds, IOrganizationService service, ITracingService tracing)
        {
            tracing.Trace("est date");
            List<Guid> assetconfigIds = assetIds.Split(',').Select(id => new Guid(id.Trim())).ToList();
            List<DateTime> expirationDates = new List<DateTime>();
            foreach (Guid assetId in assetconfigIds)
            {
                QueryExpression query = new QueryExpression("niq_assetconfig")
                {
                    ColumnSet = new ColumnSet("niq_assetenddate"),
                    Criteria = { Conditions = { new ConditionExpression("niq_assetconfigid", ConditionOperator.Equal, assetId) } }
                };

                EntityCollection results = service.RetrieveMultiple(query);
                if (results.Entities.Count > 0 && results.Entities[0].Contains("niq_assetenddate"))
                {
                    expirationDates.Add((DateTime)results.Entities[0]["niq_assetenddate"]);
                }
            }
            tracing.Trace(expirationDates.Max().AddDays(-1).ToString());
            return expirationDates.Max();
        }

        /// <summary>
        /// Update the Opportunity record
        /// </summary>
        /// <param name="service"></param>
        /// <param name="originalOpportunity"></param>
        /// <param name="clonedOpportunityId"></param>
        /// <param name="tracing"></param>
        public void UpdateClonedOpportunity(IOrganizationService service, Entity originalOpportunity, Guid clonedOpportunityId, ITracingService tracing, string commaseperatedGuids)
        {
            tracing.Trace($"Updating cloned opportunity (ID: {clonedOpportunityId}).");

            var updateClonedOpportunity = new Entity("opportunity", clonedOpportunityId)
            {
                ["niq_existingcontractexpirationdate"] = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate"),
                ["niq_opportunitytype"] = new OptionSetValue(2),
                ["niq_existingcontractaction"] = new OptionSetValue(1),
                ["niq_contractdecision"] = new OptionSetValue(100000002),
                ["niq_sapintegrationstatus"] = null,
                ["niq_amendedfromopportunity"] = new EntityReference("opportunity", originalOpportunity.Id),
                ["niq_assetconfigidinput"] = commaseperatedGuids,
                //Code changes for DYNCRM-28676
                ["niq_originalopportunityid"] = new EntityReference("opportunity", originalOpportunity.Id)
        };

            service.Update(updateClonedOpportunity);
            tracing.Trace("Cloned Opportunity values updated successfully.");
        }
        /// <summary>
        /// Calculate Months between 2 dates
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public static int GetFullMonthsBetweenDates(DateTime startDate, DateTime endDate)
        {

            int totalMonths = (endDate.Year - startDate.Year) * 12 + endDate.Month - startDate.Month;

            // Adjust if the end day is earlier than the start day
            if (endDate.Day < startDate.Day)
            {
                totalMonths--;
            }

            return totalMonths;
        }
    }
}