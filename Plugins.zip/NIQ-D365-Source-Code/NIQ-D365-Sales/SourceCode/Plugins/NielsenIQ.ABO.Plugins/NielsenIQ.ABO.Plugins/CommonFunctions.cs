﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Threading.Tasks;

namespace NielsenIQ.ABO.Plugins
{
    public static class CommonFunctions
    {
        public static Entity RetrieveUltimateOriginalOpportunityDetails(Entity originalOpportunity, ITracingService tracing, IOrganizationService service)
        {
            Entity ultimateOriginalOpportunity = new Entity();
            if (originalOpportunity != null && tracing != null && service != null)
            {
                if (originalOpportunity.Attributes.ContainsKey("niq_ultimateoriginalopportunityid") && originalOpportunity["niq_ultimateoriginalopportunityid"] is EntityReference ultOrgOppRef && ultOrgOppRef.Id != Guid.Empty)
                {

                    ultimateOriginalOpportunity = service.Retrieve("opportunity", ultOrgOppRef.Id, new ColumnSet(true));
                    tracing.Trace("Parent opportunity contains reference to ultimate original opportunity");
                }
                else if (originalOpportunity.Contains("niq_opportunitytype") && originalOpportunity["niq_opportunitytype"] is OptionSetValue option && option.Value == 1)// Contains opportunity type and opportunitytype = Completely New Sales (1)
                {
                    ultimateOriginalOpportunity = originalOpportunity;
                    tracing.Trace("Parent opportunity is completely new Sale, original opportunity itself will be ultimate original opportunity");
                }
                else
                {
                    tracing.Trace("Neither Ultimate Original Opportunity Lookup value available in Parent opportunity, not the opportunity is Completely New Sales.");
                    ultimateOriginalOpportunity = null;
                }
            }
            else
            {
                tracing.Trace("Original Opportunity/ tracing service/ IOrgService null reference passed in CommonFunction.RetrieveUltimateOriginalOpportunityDetails");
            }
            return ultimateOriginalOpportunity;
        }
    }
}
