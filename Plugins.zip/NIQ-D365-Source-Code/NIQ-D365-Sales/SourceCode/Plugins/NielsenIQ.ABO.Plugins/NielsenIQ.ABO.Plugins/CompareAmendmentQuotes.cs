using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;

namespace NielsenIQ.ABO.Plugins
{
    public class CompareAmendmentQuotes : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Retrieve the execution context and organization service
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            Entity quoteEnt = null;
            EntityReference salesOrgRef = null;
            try
            {
                // Check if input parameters contain AmendmentOpportunityID
                if (context.InputParameters.Contains("AmendmentOpportunityID") && context.InputParameters["AmendmentOpportunityID"] is EntityReference amendmentOpportunityRef)
                {
                    DeleteExistingAmendmentQuoteComparisons(service, amendmentOpportunityRef);

                    Entity amendmentOpportunity = GetMainQuote(service, amendmentOpportunityRef) ?? throw new InvalidPluginExecutionException("No Main Quote is associated with Amendment Opportunity.");
                    string configID = amendmentOpportunity.Contains("niq_assetconfigidinput") && amendmentOpportunity.Attributes["niq_assetconfigidinput"] != null ? amendmentOpportunity.GetAttributeValue<string>("niq_assetconfigidinput") : null;
                    tracing.Trace("tracing: configID:" + configID);

                    EntityReference amendmentOpportunityMainQuoteRef = amendmentOpportunity.Contains("niq_mainquoteid") && amendmentOpportunity.Attributes["niq_mainquoteid"] != null ? amendmentOpportunity.GetAttributeValue<EntityReference>("niq_mainquoteid") : null;

                    if (amendmentOpportunityMainQuoteRef != null)
                    {
                        quoteEnt = service.Retrieve(amendmentOpportunityMainQuoteRef.LogicalName, amendmentOpportunityMainQuoteRef.Id, new ColumnSet("niq_salesorgid"));

                        if (quoteEnt != null && quoteEnt.Contains("niq_salesorgid") && quoteEnt.Attributes["niq_salesorgid"] != null)
                        {
                            salesOrgRef = quoteEnt.GetAttributeValue<EntityReference>("niq_salesorgid");
                        }
                    }

                    EntityReference amendedFromOpportunityRef = GetAmendedFromOpportunity(service, amendmentOpportunityRef) ?? throw new InvalidPluginExecutionException("No Amended From Opportunity is assiciated with Amendment Opportunity.");


                    Entity amendedFromOpportunity = GetMainQuote(service, amendedFromOpportunityRef) ?? throw new InvalidPluginExecutionException("No Main Quote is associated with Amended From Opportunity.");
                    EntityReference amendedFromOpportunityMainQuoteRef = amendedFromOpportunity.Contains("niq_mainquoteid") && amendedFromOpportunity.Attributes["niq_mainquoteid"] != null ? amendedFromOpportunity.GetAttributeValue<EntityReference>("niq_mainquoteid") : null;

                    //string configID = amendedFromOpportunity.Contains("niq_assetconfigidinput") && amendedFromOpportunity.Attributes["niq_assetconfigidinput"] != null ? amendedFromOpportunity.GetAttributeValue<string>("niq_assetconfigidinput") : null;
                    //tracing.Trace("tracing: configID:" + configID);
                    EntityCollection amendmentOpportunityMainQuoteProducts = GetOpportunityMainQuoteProducts(service, amendmentOpportunityMainQuoteRef, salesOrgRef);
                    EntityCollection amendedFromOpportunityMainQuoteProducts = GetOpportunityMainQuoteProducts(service, amendedFromOpportunityMainQuoteRef, salesOrgRef);
                    tracing.Trace("amendmentOpportunityMainQuoteProducts : " + amendmentOpportunityMainQuoteProducts.Entities.Count);
                    tracing.Trace("amendedFromOpportunityMainQuoteProducts : " + amendedFromOpportunityMainQuoteProducts.Entities.Count);

                    EntityReference accountNameForAmendmentOpportunityRef = GetAccountName(service, amendmentOpportunityRef);
                    EntityReference accountNameForAmendedFromOpportunityRef = GetAccountName(service, amendedFromOpportunityRef);

                    tracing.Trace("Tracing function CompareBothOpportunityMainQuoteProducts Start");
                    CompareBothOpportunityMainQuoteProducts(service, amendmentOpportunityRef, amendmentOpportunityMainQuoteProducts, amendedFromOpportunityMainQuoteProducts, accountNameForAmendedFromOpportunityRef, accountNameForAmendmentOpportunityRef, configID, tracing);
                    tracing.Trace("Tracing function CompareBothOpportunityMainQuoteProducts End");

                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("An error occurred in CompareAmendmentQuotesPlugin: " + ex.Message, ex);
            }
        }

        // Deletes existing Amendment Quote Asset Compare records linked to the Amendment Opportunity
        private void DeleteExistingAmendmentQuoteComparisons(IOrganizationService service, EntityReference amendmentOpportunityRef)
        {
            QueryExpression query = new QueryExpression("niq_amendmentquotecompare")
            {
                ColumnSet = new ColumnSet("niq_amendmentquotecompareid"),
                Criteria = new FilterExpression
                {
                    Conditions = { new ConditionExpression("niq_opportunityid", ConditionOperator.Equal, amendmentOpportunityRef.Id) }
                }
            };

            EntityCollection existingComparisons = service.RetrieveMultiple(query);
            foreach (Entity existingComparison in existingComparisons.Entities)
            {
                service.Delete(existingComparison.LogicalName, existingComparison.Id);
            }
        }

        // Retrieves the Main Quote reference
        private Entity GetMainQuote(IOrganizationService service, EntityReference opportunityRef)
        {
            Entity opportunity = service.Retrieve("opportunity", opportunityRef.Id, new ColumnSet("niq_mainquoteid", "niq_assetconfigidinput"));
            return opportunity;
        }

        // Retrieves the Amended From Opportunity reference
        private EntityReference GetAmendedFromOpportunity(IOrganizationService service, EntityReference amendmentOpportunityRef)
        {
            Entity opportunity = service.Retrieve("opportunity", amendmentOpportunityRef.Id, new ColumnSet("niq_amendedfromopportunity"));
            return opportunity?.GetAttributeValue<EntityReference>("niq_amendedfromopportunity");
        }

        // Gets products from the opportunity main quote
        private EntityCollection GetOpportunityMainQuoteProducts(IOrganizationService service, EntityReference opportunityMainQuoteRef, EntityReference salesOrg)
        {
            //QueryExpression query = new QueryExpression("quotedetail")
            //{
            //    ColumnSet = new ColumnSet("quotedetailid", "quoteid", "productid", "niq_databasename", "niq_termlength", "extendedamount", "niq_contractproductname", "niq_elassetid"),
            //    Criteria = new FilterExpression
            //    {
            //        Conditions = { new ConditionExpression("quoteid", ConditionOperator.Equal, opportunityMainQuoteRef.Id),
            //                       new ConditionExpression("niq_lineitemenddate", ConditionOperator.GreaterThan, DateTime.UtcNow)
            //        }
            //    }
            //};

            Guid PriceListId = getPriceListId(salesOrg, service);
            QueryExpression query = new QueryExpression("quotedetail")
            {
                ColumnSet = new ColumnSet("niq_salesorgcodeid", "quotedetailid", "quoteid", "productid", "niq_databasename", "niq_termlength", "extendedamount", "niq_contractproductname", "niq_elassetid", "niq_lineitemstartdate", "niq_lineitemenddate")
            };
            query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, opportunityMainQuoteRef.Id);
            query.Criteria.AddCondition("quantity", ConditionOperator.GreaterThan, 0);
            //query.Criteria.AddCondition("extendedamount", ConditionOperator.NotEqual, 0);
            query.Criteria.AddCondition("niq_isrevshareline", ConditionOperator.Equal, false);
            query.Criteria.AddCondition("niq_lineitemenddate", ConditionOperator.GreaterThan, DateTime.Now);
            LinkEntity productPriceLink = new LinkEntity("quotedetail", "productpricelevel", "productid", "productid", JoinOperator.Inner);
            productPriceLink.LinkCriteria.AddCondition("pricelevelid", ConditionOperator.Equal, PriceListId);
            productPriceLink.LinkCriteria.AddCondition("niq_itemcategorygroup", ConditionOperator.NotEqual, 100000002);

            // Attach Link Entity to Query
            query.LinkEntities.Add(productPriceLink);
            return service.RetrieveMultiple(query);

            //EntityCollection opportunityMainQuoteProducts = service.RetrieveMultiple(query);
            //return opportunityMainQuoteProducts;
        }
        //Get PriceList record based on Sales Org
        public static Guid getPriceListId(EntityReference salesOrg, IOrganizationService service)
        {
            string fetchXMl = $@"<fetch top='1'>
                                <entity name='pricelevel'>
                                    <attribute name='pricelevelid' />
                                    <filter type='and'>
                                        <condition attribute='niq_salesorg' operator='eq' value='{salesOrg.Id}' />
                                    </filter>
                                </entity>
                            </fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchXMl)).Entities.First().Id;
        }

        // Retrieves the Account Name reference
        private EntityReference GetAccountName(IOrganizationService service, EntityReference opportunityRef)
        {
            Entity opportunity = service.Retrieve("opportunity", opportunityRef.Id, new ColumnSet("parentaccountid"));
            return opportunity?.GetAttributeValue<EntityReference>("parentaccountid");
        }

        //Compares all the products from main quote of both the opportunities
        private void CompareBothOpportunityMainQuoteProducts(IOrganizationService service, EntityReference amendmentOpportunityRef, EntityCollection amendmentOpportunityMainQuoteProducts, EntityCollection amendedFromOpportunityMainQuoteProducts, EntityReference accountNameForAmendedFromOpportunityRef, EntityReference accountNameForAmendmentOpportunityRef, string commaSeperatedConfigIds, ITracingService tracing)
        {
            try
            {
                Money changeAmount = new Money(0);
                double termLengthOriginalQuoteProduct = 0.0;
                DateTime startDateOriginalQuoteProduct;
                DateTime endDateOriginalQuoteProduct;
                double termLengthAmendmentQuoteProduct = 0.0;
                DateTime startDateAmendmentQuoteProduct;
                DateTime endDateAmendmentQuoteProduct;

                string[] configArray = commaSeperatedConfigIds != null ? commaSeperatedConfigIds.Split(',') : null;
                foreach (Entity amendmentOpportunityMainQuoteProduct in amendmentOpportunityMainQuoteProducts.Entities)
                {
                    bool isAmendmentProductFoundInAmendedProduct = false;
                    Entity currentamendedFromOpportunityMainQuoteProduct = null;

                    //Get Term Lenght
                    termLengthAmendmentQuoteProduct = amendmentOpportunityMainQuoteProduct.Contains("niq_termlength") && amendmentOpportunityMainQuoteProduct.Attributes["niq_termlength"] != null ? amendmentOpportunityMainQuoteProduct.GetAttributeValue<double>("niq_termlength") : 0;
                    if (termLengthAmendmentQuoteProduct < 1)
                    {
                        startDateAmendmentQuoteProduct = amendmentOpportunityMainQuoteProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                        endDateAmendmentQuoteProduct = amendmentOpportunityMainQuoteProduct.GetAttributeValue<DateTime>("niq_lineitemenddate");

                        if (endDateAmendmentQuoteProduct.Subtract(startDateAmendmentQuoteProduct).Days > 30)
                            termLengthAmendmentQuoteProduct = endDateAmendmentQuoteProduct.Subtract(startDateAmendmentQuoteProduct).Days / 30;
                        else
                            termLengthAmendmentQuoteProduct = 1;
                    }
                    tracing.Trace("termLengthAmendmentQuoteProduct : " + termLengthAmendmentQuoteProduct);

                    Entity amendmentOpportunityQuoteProductdetails = CheckForAttributeInEntity(amendmentOpportunityMainQuoteProduct, "productid")
                        ? GetQuoteProductDetails(service, amendmentOpportunityMainQuoteProduct.GetAttributeValue<EntityReference>("productid").Id)
                        : throw new InvalidPluginExecutionException("Existing Product is empty in the Quote Product of Amendment Opportunity.");

                    foreach (Entity amendedFromOpportunityMainQuoteProduct in amendedFromOpportunityMainQuoteProducts.Entities)
                    {
                        //Get Term Lenght
                        termLengthOriginalQuoteProduct = amendedFromOpportunityMainQuoteProduct.Contains("niq_termlength") && amendedFromOpportunityMainQuoteProduct.Attributes["niq_termlength"] != null ? amendedFromOpportunityMainQuoteProduct.GetAttributeValue<double>("niq_termlength") : 0;
                        if (termLengthOriginalQuoteProduct < 1)
                        {
                            startDateOriginalQuoteProduct = amendedFromOpportunityMainQuoteProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                            endDateOriginalQuoteProduct = amendedFromOpportunityMainQuoteProduct.GetAttributeValue<DateTime>("niq_lineitemenddate");

                            if (endDateOriginalQuoteProduct.Subtract(startDateOriginalQuoteProduct).Days > 30)
                                termLengthOriginalQuoteProduct = endDateOriginalQuoteProduct.Subtract(startDateOriginalQuoteProduct).Days / 30;
                            else
                                termLengthOriginalQuoteProduct = 1;
                        }
                        tracing.Trace("termLengthOriginalQuoteProduct : " + termLengthOriginalQuoteProduct);

                        Entity amendedFromOpportunityQuoteProductdetails = CheckForAttributeInEntity(amendedFromOpportunityMainQuoteProduct, "productid")
                            ? GetQuoteProductDetails(service, amendedFromOpportunityMainQuoteProduct.GetAttributeValue<EntityReference>("productid").Id)
                            : throw new InvalidPluginExecutionException("Product ID is empty in the Product associated with Amended From Opportunity.");

                        if (amendmentOpportunityQuoteProductdetails.GetAttributeValue<string>("productnumber") == amendedFromOpportunityQuoteProductdetails.GetAttributeValue<string>("productnumber") && amendmentOpportunityQuoteProductdetails.GetAttributeValue<string>("name") == amendedFromOpportunityQuoteProductdetails.GetAttributeValue<string>("name") && amendmentOpportunityMainQuoteProduct.GetAttributeValue<string>("niq_contractproductname") == amendedFromOpportunityMainQuoteProduct.GetAttributeValue<string>("niq_contractproductname") && new Guid(amendmentOpportunityMainQuoteProduct.GetAttributeValue<string>("niq_elassetid")) == new Guid(amendedFromOpportunityMainQuoteProduct.GetAttributeValue<string>("niq_elassetid")))
                        {
                            isAmendmentProductFoundInAmendedProduct = true;
                            currentamendedFromOpportunityMainQuoteProduct = amendedFromOpportunityMainQuoteProduct;
                            break;
                        }
                    }
                    if (isAmendmentProductFoundInAmendedProduct)
                    {
                        //Status: Modified (610570002)
                        tracing.Trace("Inside isAmendmentProductFoundInAmendedProduct");

                        if (!CheckForAttributeInEntity(amendmentOpportunityMainQuoteProduct, "extendedamount"))
                            throw new InvalidPluginExecutionException("Extended Amount is empty in the Quote Product of Amendment Opportunity.");

                        if (!CheckForAttributeInEntity(currentamendedFromOpportunityMainQuoteProduct, "extendedamount"))
                            throw new InvalidPluginExecutionException("Extended Amount is empty in the Quote Product of Amended From Opportunity.");
                        if (termLengthAmendmentQuoteProduct > 0 && termLengthOriginalQuoteProduct > 0)
                        {
                            changeAmount = new Money((amendmentOpportunityMainQuoteProduct.GetAttributeValue<Money>("extendedamount").Value / Convert.ToDecimal(termLengthAmendmentQuoteProduct)) - (currentamendedFromOpportunityMainQuoteProduct.GetAttributeValue<Money>("extendedamount").Value / Convert.ToDecimal(termLengthOriginalQuoteProduct)));
                        }
                        // decimal epsilon = 0.000001M;
                        decimal roundedValue = Math.Round(changeAmount.Value, 2);
                        tracing.Trace("changeAmount.Value::" + roundedValue);
                        if (roundedValue != 0.00M)
                        {
                            tracing.Trace("Creating the Records");
                            CreateAmendmentQuoteComparison(service, amendmentOpportunityRef, 610570002, changeAmount, amendmentOpportunityMainQuoteProduct, accountNameForAmendmentOpportunityRef);
                        }
                    }
                    else
                    {
                        //Status: Added (610570000)
                        // Probable Fix (changeAmount 
                        //Changes for Bug-27739
                        Money amendedQuoteAmount = new Money(0);
                        if (termLengthAmendmentQuoteProduct > 0)
                        {
                            amendedQuoteAmount = new Money((amendmentOpportunityMainQuoteProduct.GetAttributeValue<Money>("extendedamount").Value / Convert.ToDecimal(termLengthAmendmentQuoteProduct)));
                        }
                        //? new Money((amendmentOpportunityMainQuoteProduct.GetAttributeValue<Money>("extendedamount").Value / Convert.ToDecimal(termLengthAmendmentQuoteProduct)))

                        changeAmount = CheckForAttributeInEntity(amendmentOpportunityMainQuoteProduct, "extendedamount") ? amendedQuoteAmount
                         : throw new InvalidPluginExecutionException("Extended Amount is empty in the Quote Product of Amendment Opportunity.");

                        CreateAmendmentQuoteComparison(service, amendmentOpportunityRef, 610570000, changeAmount, amendmentOpportunityMainQuoteProduct, accountNameForAmendmentOpportunityRef);
                    }
                }
                foreach (Entity amendedFromOpportunityMainQuoteProduct in amendedFromOpportunityMainQuoteProducts.Entities)
                {
                    tracing.Trace("AmendedFromQPGUID: " + amendedFromOpportunityMainQuoteProduct.Id.ToString());
                    Entity amendedFromOpportunityQuoteProductdetails = GetQuoteProductDetails(service, amendedFromOpportunityMainQuoteProduct.GetAttributeValue<EntityReference>("productid").Id);
                    bool isAmendedProductFoundInAmendmentProduct = false;
                    Entity currentamendedFromOpportunityMainQuoteProduct = null;
                    //Get Term Lenght
                    termLengthOriginalQuoteProduct = amendedFromOpportunityMainQuoteProduct.Contains("niq_termlength") && amendedFromOpportunityMainQuoteProduct.Attributes["niq_termlength"] != null ? amendedFromOpportunityMainQuoteProduct.GetAttributeValue<double>("niq_termlength") : 0;
                    if (termLengthOriginalQuoteProduct < 1)
                    {
                        startDateOriginalQuoteProduct = amendedFromOpportunityMainQuoteProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                        endDateOriginalQuoteProduct = amendedFromOpportunityMainQuoteProduct.GetAttributeValue<DateTime>("niq_lineitemenddate");

                        if (endDateOriginalQuoteProduct.Subtract(startDateOriginalQuoteProduct).Days > 30)
                            termLengthOriginalQuoteProduct = endDateOriginalQuoteProduct.Subtract(startDateOriginalQuoteProduct).Days / 30;
                        else
                            termLengthOriginalQuoteProduct = 1;
                    }
                    tracing.Trace("termLengthOriginalQuoteProduct : " + termLengthOriginalQuoteProduct);
                    foreach (Entity amendmentOpportunityMainQuoteProduct in amendmentOpportunityMainQuoteProducts.Entities)
                    {
                        Entity amendmentOpportunityQuoteProductdetails = GetQuoteProductDetails(service, amendmentOpportunityMainQuoteProduct.GetAttributeValue<EntityReference>("productid").Id);
                        if (amendmentOpportunityQuoteProductdetails.GetAttributeValue<string>("productnumber") == amendedFromOpportunityQuoteProductdetails.GetAttributeValue<string>("productnumber") && amendmentOpportunityQuoteProductdetails.GetAttributeValue<string>("name") == amendedFromOpportunityQuoteProductdetails.GetAttributeValue<string>("name") && amendmentOpportunityMainQuoteProduct.GetAttributeValue<string>("niq_contractproductname") == amendedFromOpportunityMainQuoteProduct.GetAttributeValue<string>("niq_contractproductname") && new Guid(amendmentOpportunityMainQuoteProduct.GetAttributeValue<string>("niq_elassetid")) == new Guid(amendedFromOpportunityMainQuoteProduct.GetAttributeValue<string>("niq_elassetid")))
                        {
                            isAmendedProductFoundInAmendmentProduct = true;
                            break;
                        }
                        else
                        {
                            isAmendedProductFoundInAmendmentProduct = false;
                            currentamendedFromOpportunityMainQuoteProduct = amendedFromOpportunityMainQuoteProduct;
                        }
                    }

                    if (amendmentOpportunityMainQuoteProducts.Entities.Count == 0)
                    {
                        currentamendedFromOpportunityMainQuoteProduct = amendedFromOpportunityMainQuoteProduct;
                    }

                    if (!isAmendedProductFoundInAmendmentProduct || amendmentOpportunityMainQuoteProducts.Entities.Count == 0)
                    {
                        //Status: Removed (610570001)

                        List<Entity> filteredRemovedProducts = new List<Entity>();
                        string fetchXMl = $@"<fetch>
                    <entity name='niq_assetmaterial'>
                        <attribute name='niq_assetmaterialid' />
                        <attribute name='niq_assetconfig' />
                        <attribute name='niq_assetconfigname' />
                        <attribute name='niq_correspondingquoteproduct' />
                        <filter type = 'or'>
                     <condition attribute='niq_correspondingquoteproduct' operator='eq' value='{amendedFromOpportunityMainQuoteProduct.Id}' />
                        </filter>
                    </entity>
                </fetch>";
                        var records = service.RetrieveMultiple(new FetchExpression(fetchXMl));
                        foreach (Entity record in records.Entities)
                        {
                            string assetConfigId = record.GetAttributeValue<EntityReference>("niq_assetconfig").Id.ToString();
                            Guid CorrespondingQP = record.GetAttributeValue<EntityReference>("niq_correspondingquoteproduct").Id;
                            tracing.Trace("Asset ID in Config : " + assetConfigId);
                            tracing.Trace("configArray:" + configArray);
                            tracing.Trace("assetConfigId:" + assetConfigId);
                            tracing.Trace("commaSeperatedConfigIds.Contains(assetConfigId):" + commaSeperatedConfigIds.Contains(assetConfigId));
                            if (configArray != null && configArray.Contains(assetConfigId) && termLengthOriginalQuoteProduct > 0)
                            {
                                tracing.Trace("REMOVED  EXTENDED AMOUNT: " + currentamendedFromOpportunityMainQuoteProduct.GetAttributeValue<Money>("extendedamount").Value);
                                tracing.Trace("REMOVED  TERM LENGTH :" + Convert.ToDecimal(termLengthOriginalQuoteProduct));
                                tracing.Trace("NEW TERM LENGTH: " + Convert.ToDecimal(termLengthOriginalQuoteProduct));
                                changeAmount = new Money(-(currentamendedFromOpportunityMainQuoteProduct.GetAttributeValue<Money>("extendedamount").Value / Convert.ToDecimal(termLengthOriginalQuoteProduct)));

                                CreateAmendmentQuoteComparison(service, amendmentOpportunityRef, 610570001, changeAmount, amendedFromOpportunityMainQuoteProduct, accountNameForAmendedFromOpportunityRef);
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                tracing.Trace(ex.Message);
                tracing.Trace(ex.StackTrace);
            }
        }

        //Gets Quote Product Details from Product
        private Entity GetQuoteProductDetails(IOrganizationService service, Guid productID)
        {
            Entity productDetails = service.Retrieve("product", productID, new ColumnSet("productnumber", "name"));
            return productDetails;
        }

        //Check if the Attribute is available and value is not null
        private bool CheckForAttributeInEntity(Entity entity, String fieldLogicalName)
        {
            return entity.Contains(fieldLogicalName) && entity[fieldLogicalName] != null ? true : false;
        }

        // Creates a new Amendment Quote Asset Compare record
        private void CreateAmendmentQuoteComparison(IOrganizationService service, EntityReference amendmentOpportunityRef, int Status, Money changeAmount, Entity opportunityMainQuoteProduct, EntityReference accountNameRef)
        {
            Entity accountName = service.Retrieve("account", accountNameRef.Id, new ColumnSet("name"));
            string accountNameString = accountName?.GetAttributeValue<String>("name");
            string assetNameString = accountNameString + "_" + (opportunityMainQuoteProduct.GetAttributeValue<string>("niq_databasename") ?? (opportunityMainQuoteProduct.GetAttributeValue<string>("niq_contractproductname")));

            Entity comparisonRecord = new Entity("niq_amendmentquotecompare")
            {
                ["niq_quoteid"] = new EntityReference("quote", opportunityMainQuoteProduct.GetAttributeValue<EntityReference>("quoteid").Id),
                ["niq_opportunityid"] = amendmentOpportunityRef,
                ["niq_type"] = new OptionSetValue(Status),
                ["niq_productid"] = new EntityReference("product", opportunityMainQuoteProduct.GetAttributeValue<EntityReference>("productid").Id),
                ["niq_productname"] = opportunityMainQuoteProduct.GetAttributeValue<string>("niq_contractproductname"),

                ["niq_assetname"] = assetNameString,
                ["niq_changeamount"] = changeAmount
            };

            if (CheckForAttributeInEntity(opportunityMainQuoteProduct, "niq_termlength"))
            {
                comparisonRecord["niq_termlength"] = opportunityMainQuoteProduct["niq_termlength"];
            }

            service.Create(comparisonRecord);
        }
    }
}