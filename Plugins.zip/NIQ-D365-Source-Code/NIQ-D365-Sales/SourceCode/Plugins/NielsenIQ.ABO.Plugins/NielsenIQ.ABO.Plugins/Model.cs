﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NielsenIQ.ABO.Plugins.Model
{
    public enum OpportunityType
    {
        New_Sale = 1,
        Existing_Contract = 2
    }

    public enum ExistingContractAction
    {
        Renewal = 1,
        COLA_PE = 2,
        Evergreen = 3,
        Amendment = 4
    }

    public enum AssetAction
    {
        New_Sale = 610570000,
        Amendment = 610570001,
        Renewal = 610570002,
        COLA_PE = 610570003,
        Evergreen = 610570005
    }

    public enum TermType
    {
        EverGreen = 100000000,
        Fixed = 100000001,
    }
    public enum DocumentVersion
    {
        Initial = 1,
        Amendment = 2,
        Renewal = 3
    }

    public enum DocumentType
    {
        PO = 610570000,
        Finally_Executed_Agreement = 610570001
    }

    public enum AssetType
    {
        Individual = 1,
        Host = 2,
        Child = 3,
        RevShare = 4
    }

    public class AssetData
    {
        public string AssetName { get; set; }
        public string ElAssetID { get; set; }
        public bool IsDatabase { get; set; }
        public bool IsRevShare { get; set; }
        public string DatabaseName { get; set; }
        public string ProductName { get; set; }
        public string ExperlogixConfig { get; set; }
        public string RateCardID { get; set; }
    }

    public enum AssetStatus
    {
        Active = 1001,
        Inactive = 1002,
        Future = 1003
    }
}
