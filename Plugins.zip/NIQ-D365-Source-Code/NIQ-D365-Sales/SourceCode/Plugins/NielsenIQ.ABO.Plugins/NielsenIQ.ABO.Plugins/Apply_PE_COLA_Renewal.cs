﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.ABO.Plugins.Model;
using System;
using System.IdentityModel.Metadata;
using System.Security.Principal;
using System.Web.Services.Description;
using System.Workflow.Runtime.Tracking;

namespace NielsenIQ.ABO.Plugins
{
    public class Apply_PE_COLA_Renewal : IPlugin
    {
        // Constants for attribute names, making it easier to manage and maintain
        private const string OpportunityEntityName = "opportunity";
        private const string OpportunityIdField = "opportunityid";
        private const string NameField = "name";
        private const string NIQCloseProbabilityField = "niq_closeprobability";
        private const string NIQIsCloneFormField = "niq_iscloneform";
        private const string NIQCloneOpportunityField = "niq_cloneopportunity";
        private const string NIQAmendedFromOpportunityField = "niq_amendedfromopportunity";
        private const string NIQCOLAField = "niq_cola";
        private const string NIQProductEnhancementField = "niq_productenhancement";
        private const string NIQContractDecisionField = "niq_contractdecision";
        private const string NIQAutomatedOpportunityField = "niq_automatedopportunity";
        private const string NIQAssetConfigIdField = "niq_assetconfigidinput";
        private const string NIQContractDateField = "niq_contractenddate";
        private const string NIQOpportunityTypeField = "niq_opportunitytype";
        private const string NIQExistingContractActionField = "niq_existingcontractaction";
        private const string NIQExistingContractExpirationField = "niq_existingcontractexpirationdate";
        private const string NIQEffectiveDateField = "niq_effectivedate";
        private const string NIQCreatedOnField = "createdon";
        private const string NIQCreatedByField = "createdby";
        private const string NIQModifiedByField = "modifiedby";
        private const string NIQStageField = "niq_stage";
        private const string NIQMainQuoteField = "niq_mainquoteid";
        private const string NIQModifiedOnField = "modifiedon";
        private const string NIQStateCodeField = "statecode";
        private const string NIQStatusCodeField = "statuscode";
        private const string NIQOpportunityNumberField = "niq_opportunitynumber";
        private const string NIQSapError = "niq_saperror";
        private const string NIQSapErrorText = "niq_saperrortext";
        private const string NIQSapContractFlowurl = "niq_sapcontractpaflowurl";
        private const string NIQSapIntegrationStatus = "niq_sapintegrationstatus";
        private const string NIQSapSalesDocumentId = "niq_sapsalesdocumentid";
        private const string NIQApprovalStatus = "niq_approvalstatus";
        private const string NIQEvergreenincrease = "niq_evergreenincrease";
        private const string NIQHostOpportunity = "niq_hostopportunity";
        private const string NIQExternalID = "niq_externalid";
        public static string NIQLeadId = "niq_leadid";
        public static string NIQOriginatingLead = "originatingleadid";
        public const string NIQEstimatedCloseDate = "estimatedclosedate";
        public const string NIQActualCloseDate = "actualclosedate";

        /// <summary>
        /// This plugin will create a new Automated opportunity 
        /// </summary>
        /// <param name="serviceProvider"></param>
        public void Execute(IServiceProvider serviceProvider)
        {
            // Fetching services from the serviceProvider
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = factory.CreateOrganizationService(context.UserId);
            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            tracing.Trace("Plugin execution started.");
            try
            {
                // Try to get the input parameters
                if (TryGetInputParameters(context, out var assetIds, out var opportunityId, out var effectiveDate, out var pePercentage, out var colaPercentage, out var loggedInUserId))
                {
                    tracing.Trace($"Start Date: {effectiveDate}");

                    // Retrieve the original opportunity
                    var originalOpportunity = service.Retrieve(OpportunityEntityName, new Guid(opportunityId), new ColumnSet(true));
                    if (originalOpportunity != null)
                    {
                        tracing.Trace("Original Opportunity retrieved successfully.");

                        // Create a cloned opportunity
                        var clonedOpportunityId = CreateClonedOpportunity(originalOpportunity, effectiveDate, pePercentage, colaPercentage, assetIds, loggedInUserId, tracing, service);
                        tracing.Trace($"Cloned Opportunity ID: {clonedOpportunityId}");

                        // Update the cloned opportunity with additional values
                        UpdateClonedOpportunity(service, originalOpportunity, clonedOpportunityId, tracing);

                        // Set success output parameters
                        context.OutputParameters["IsSuccess"] = true;
                        context.OutputParameters["ClonedOpportunityId"] = clonedOpportunityId.ToString();
                        tracing.Trace("Plugin executed successfully. Cloned opportunity created and updated.");
                    }
                    else
                    {
                        tracing.Trace("Original opportunity not found.");
                    }
                }
                else
                {
                    tracing.Trace("Required input parameters missing.");
                }
            }
            catch (Exception ex)
            {
                context.OutputParameters["IsSuccess"] = false;
                throw new InvalidPluginExecutionException("An error occurred in CompareRenewalQuotesPlugin: " + ex.Message, ex);
            }
        }

        /// <summary>
        /// Try to get the input parameters
        /// </summary>
        /// <param name="context"></param>
        /// <param name="assetIds"></param>
        /// <param name="opportunityId"></param>
        /// <param name="effectiveDate"></param>
        /// <param name="pePercentage"></param>
        /// <param name="colaPercentage"></param>
        /// <returns></returns>
        private bool TryGetInputParameters(IPluginExecutionContext context, out string assetIds, out string opportunityId, out string effectiveDate, out decimal pePercentage, out decimal colaPercentage, out string loggedInUserId)
        {
            opportunityId = null;
            effectiveDate = null;
            pePercentage = 0;
            colaPercentage = 0;
            assetIds = null;
            loggedInUserId = null;
            if (context.InputParameters.TryGetValue("OpportunityGUID", out var opportunityIdObj) &&
                context.InputParameters.TryGetValue("EffectiveDate", out var effectiveDateObj) &&
                context.InputParameters.TryGetValue("PEpercentage", out var pePercentageObj) &&
                context.InputParameters.TryGetValue("COLApercentage", out var colaPercentageObj) &&
                context.InputParameters.TryGetValue("AssetIds", out var assetIdsObj) &&
                context.InputParameters.TryGetValue("LoggedInUserId", out var loggedInUserIdObj))
            {
                opportunityId = (string)opportunityIdObj;
                effectiveDate = (string)effectiveDateObj;
                pePercentage = (decimal)pePercentageObj;
                colaPercentage = (decimal)colaPercentageObj;
                assetIds = (string)assetIdsObj;
                loggedInUserId = (string)loggedInUserIdObj;
                return true;
            }

            // Log if the parameters are not found
            return false;
        }

        /// <summary>
        /// Create Clone Opportunity
        /// </summary>
        /// <param name="originalOpportunity"></param>
        /// <param name="effectiveDate"></param>
        /// <param name="pePercentage"></param>
        /// <param name="colaPercentage"></param>
        /// <param name="assetIds"></param>
        /// <param name="tracing"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        private Guid CreateClonedOpportunity(Entity originalOpportunity, string effectiveDate, decimal pePercentage, decimal colaPercentage, string assetIds, string loggedInUserId, ITracingService tracing, IOrganizationService service)
        {
            try
            {
                var account = originalOpportunity.GetAttributeValue<EntityReference>("parentaccountid");
                tracing.Trace($"Cloning opportunity for account: {account.Name}.");

                // Initialize a new cloned opportunity entity
                Entity clonedOpportunity = new Entity(OpportunityEntityName);

                // Dynamically copy attributes, skipping irrelevant ones
                CopyOpportunityAttributes(originalOpportunity, clonedOpportunity, account, pePercentage, colaPercentage, assetIds, effectiveDate, tracing, service);
                clonedOpportunity["ownerid"] = new EntityReference("systemuser", new Guid(loggedInUserId));
                // Create the cloned opportunity in CRM
                var clonedOpportunityId = service.Create(clonedOpportunity);
                tracing.Trace($"Cloned opportunity created with ID: {clonedOpportunityId}");

                return clonedOpportunityId;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("An error occurred in CompareRenewalQuotesPlugin: " + ex.Message, ex);
            }

        }

        /// <summary>
        /// Create Clone Opportunity
        /// </summary>
        /// <param name="originalOpportunity"></param>
        /// <param name="clonedOpportunity"></param>
        /// <param name="account"></param>
        /// <param name="pePercentage"></param>
        /// <param name="colaPercentage"></param>
        /// <param name="assetIds"></param>
        /// <param name="tracing"></param>
        private void CopyOpportunityAttributes(Entity originalOpportunity, Entity clonedOpportunity, EntityReference account, decimal pePercentage, decimal colaPercentage, string assetIds, string effectiveDate, ITracingService tracing, IOrganizationService service)
        {
            tracing.Trace("Copying attributes from the original opportunity to the cloned opportunity.");
            try
            {
                Entity ultimateoriginalOpp = CommonFunctions.RetrieveUltimateOriginalOpportunityDetails(originalOpportunity, tracing, service);
                foreach (var attribute in originalOpportunity.Attributes)
                {
                    if (attribute.Key != NIQEvergreenincrease && attribute.Key != NIQApprovalStatus && attribute.Key != OpportunityIdField && attribute.Key != NIQCreatedOnField && attribute.Key != NIQEffectiveDateField && attribute.Key != NIQCreatedByField && attribute.Key != NIQModifiedByField && attribute.Key != NIQStageField && attribute.Key != NIQMainQuoteField && attribute.Key != NIQAmendedFromOpportunityField && attribute.Key != NIQIsCloneFormField && attribute.Key != NIQCloneOpportunityField && attribute.Key != NIQEffectiveDateField &&
                        attribute.Key != NIQProductEnhancementField && attribute.Key != NIQCOLAField && attribute.Key != NIQAutomatedOpportunityField && attribute.Key != NIQCloseProbabilityField && attribute.Key != NIQContractDecisionField && attribute.Key != NIQAssetConfigIdField && attribute.Key != NIQModifiedOnField && attribute.Key != NIQStateCodeField && attribute.Key != NIQStatusCodeField && attribute.Key != NIQOpportunityNumberField &&
                        attribute.Key != NIQSapError && attribute.Key != NIQSapErrorText && attribute.Key != NIQSapContractFlowurl && attribute.Key != NIQSapIntegrationStatus && attribute.Key != NIQSapSalesDocumentId && attribute.Key != NIQOpportunityTypeField && attribute.Key != NIQHostOpportunity && attribute.Key != NIQExternalID && attribute.Key != NIQLeadId && attribute.Key != NIQOriginatingLead)
                    {
                        // Handle specific fields with custom logic
                        tracing.Trace($"Setting attribute {attribute.Key}");
                        switch (attribute.Key)
                        {
                            case NameField:
                                clonedOpportunity[NameField] = $"{account.Name}_PE_COLA_Apply_{DateTime.Now:dd/MM/yyyy}";
                                tracing.Trace($"Setting Name field for cloned opportunity: {clonedOpportunity[NameField]}");
                                break;

                            case NIQEstimatedCloseDate:
                                // Use UTC in plugins; Dataverse handles presentation in user's timezone
                                var nowUtc = DateTime.UtcNow;
                                // If the field is Date-Only, store just the date portion:
                                clonedOpportunity[NIQEstimatedCloseDate] = nowUtc.Date;
                                tracing.Trace($"Setting EstimatedCloseDate (UTC date) for cloned opportunity: {clonedOpportunity[NIQEstimatedCloseDate]}");
                                break;

                            case NIQActualCloseDate:
                                clonedOpportunity[NIQActualCloseDate] = null; // Set blank
                                tracing.Trace("Setting NIQActualCloseDate to blank for cloned opportunity.");
                                break;



                            default:
                                // Default case for other attributes
                                if (attribute.Value is EntityReference lookupValue)
                                {
                                    clonedOpportunity[attribute.Key] = new EntityReference(lookupValue.LogicalName, lookupValue.Id);
                                    tracing.Trace($"Setting lookup field {attribute.Key} with reference {lookupValue.Id}");
                                }
                                else
                                {
                                    clonedOpportunity[attribute.Key] = attribute.Value;
                                    tracing.Trace($"Copying field {attribute.Key} with value {attribute.Value}");
                                }
                                break;
                        }
                    }
                }
                clonedOpportunity[NIQAssetConfigIdField] = assetIds;
                tracing.Trace($"Setting NIQAssetConfigId field to: {assetIds}");

                clonedOpportunity[NIQContractDecisionField] = new OptionSetValue(100000000); // Set contract decision value
                tracing.Trace($"Setting NIQContractDecision field.");

                clonedOpportunity[NIQCloseProbabilityField] = new OptionSetValue(100000006); // Close probability value
                tracing.Trace($"Setting NIQCloseProbability field: {clonedOpportunity[NIQCloseProbabilityField]}");

                clonedOpportunity[NIQAutomatedOpportunityField] = true;
                tracing.Trace($"Setting NIQAutomatedOpportunity field to true.");

                clonedOpportunity[NIQCOLAField] = colaPercentage;
                tracing.Trace($"Setting NIQCOLA field to: {colaPercentage}");

                clonedOpportunity[NIQProductEnhancementField] = pePercentage;
                tracing.Trace($"Setting NIQProductEnhancement field to: {pePercentage}");

                DateTime parsedDate = DateTime.Parse(effectiveDate);
                tracing.Trace($"Setting parsedDate field to: {parsedDate}");

                DateTime utcDate = parsedDate.ToUniversalTime();
                tracing.Trace($"Setting utcDate field to: {utcDate}");

                DateTime dateOnly = utcDate.Date;
                tracing.Trace($"Setting dateOnly field to: {dateOnly}");

                clonedOpportunity[NIQEffectiveDateField] = dateOnly;

                clonedOpportunity[NIQCloneOpportunityField] = originalOpportunity.ToEntityReference();
                tracing.Trace($"Setting lookup field {NIQCloneOpportunityField} to reference the original opportunity.");

                clonedOpportunity[NIQIsCloneFormField] = true;
                clonedOpportunity[NIQOpportunityTypeField] = new OptionSetValue((int)OpportunityType.New_Sale);
                tracing.Trace($"Setting NIQIsCloneFormField to true.");

                tracing.Trace("niq_sapsalesdocumentid" + originalOpportunity.GetAttributeValue<string>("niq_sapsalesdocumentid"));
                clonedOpportunity["niq_existingsapsalesdocumentid"] = originalOpportunity.GetAttributeValue<string>("niq_sapsalesdocumentid");

                //clonedOpportunity[NIQAmendedFromOpportunityField] = originalOpportunity.ToEntityReference();
                //tracing.Trace($"Setting lookup field {NIQAmendedFromOpportunityField} to reference the original opportunity.");

                //clonedOpportunity["niq_ultimateoriginalopportunityid"] = new EntityReference("opportunity", originalOpportunity.Id);
                if (ultimateoriginalOpp != null)
                    clonedOpportunity["niq_ultimateoriginalopportunityid"] = ultimateoriginalOpp.ToEntityReference();
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("An error occurred in CompareRenewalQuotesPlugin: " + ex.Message, ex);
            }

        }
        /// <summary>
        /// Update the Opportunity record
        /// </summary>
        /// <param name="service"></param>
        /// <param name="originalOpportunity"></param>
        /// <param name="clonedOpportunityId"></param>
        /// <param name="tracing"></param>
        /// <param name="effectiveDate"></param>
        /// <param name="pePercentage"></param>
        /// <param name="colaPercentage"></param>
        public void UpdateClonedOpportunity(IOrganizationService service, Entity originalOpportunity, Guid clonedOpportunityId, ITracingService tracing)
        {
            try
            {
                tracing.Trace($"Updating cloned opportunity (ID: {clonedOpportunityId}).");

                var updateClonedOpportunity = new Entity(OpportunityEntityName, clonedOpportunityId)
                {
                    ["niq_existingsapsalesdocumentid"] = originalOpportunity.GetAttributeValue<string>("niq_sapsalesdocumentid"),
                    [NIQOpportunityTypeField] = new OptionSetValue((int)OpportunityType.Existing_Contract),
                    [NIQExistingContractActionField] = new OptionSetValue((int)ExistingContractAction.COLA_PE),
                    [NIQExistingContractExpirationField] = originalOpportunity.GetAttributeValue<DateTime>(NIQContractDateField),
                    [NIQAmendedFromOpportunityField] = new EntityReference(originalOpportunity.LogicalName, originalOpportunity.Id),
                    ["niq_originalopportunityid"] = new EntityReference(originalOpportunity.LogicalName, originalOpportunity.Id)
                };

                service.Update(updateClonedOpportunity);
                tracing.Trace("Cloned Opportunity values updated successfully.");
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("An error occurred in CompareRenewalQuotesPlugin: " + ex.Message, ex);
            }

        }
    }
}