﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json.Linq;
using NielsenIQ.ABO.Plugins.Model;

namespace NielsenIQ.ABO.Plugins
{
    public class GenerateAssetDataModel : IPlugin
    {
        IOrganizationService service;
        ITracingService tracing;
        EntityReference RevShareAsset;
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            service = factory.CreateOrganizationService(context.UserId);
            tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            tracing.Trace("START");
            try
            {
                string opportunityId = (string)context.InputParameters["OpportunityId"];
                tracing.Trace($@"opportunityId: {opportunityId}");
                string salesOrderId = (string)context.InputParameters["SalesOrderId"];
                tracing.Trace($@"salesOrderId: {salesOrderId}");
                #region Setup Asset Entity Data
                HashSet<string> assetIds = new HashSet<string>(); // To store unique asset IDs
                List<AssetData> uniqueAssets = new List<AssetData>();
                Entity OppEntity = service.Retrieve("opportunity", new Guid(opportunityId), new ColumnSet(true));

                EntityReference MainQuoteRef = OppEntity.GetAttributeValue<EntityReference>("niq_mainquoteid");

                #region "Section to capture Revenue Share Deal flag from current or host opportunity of current opportunity being processed (DYNCRM-27927)"
                bool isRevShareOpportunity = false;
                bool? opportunityIsRevsShareflag;
                if (OppEntity.Attributes.Contains("niq_revenuesharedeal"))
                {
                    opportunityIsRevsShareflag = OppEntity.GetAttributeValue<bool?>("niq_revenuesharedeal");
                    if (opportunityIsRevsShareflag.HasValue && opportunityIsRevsShareflag == true)
                    {
                        isRevShareOpportunity = true;//If current opportunity is a host opportunity fetch set the IsRevshare
                    }
                    else
                    {
                        isRevShareOpportunity = false;
                    }
                }

                if (OppEntity.Attributes.Contains("niq_hostopportunity") && OppEntity.Attributes["niq_hostopportunity"] != null)// This is a child opportunity and have a host link
                {
                    //Get the entity reference for the Host Opportunity and get the IsRevShare value populated from Host Opportunity
                    EntityReference hostOpp = OppEntity.GetAttributeValue<EntityReference>("niq_hostopportunity");
                    if (hostOpp != null)
                    {
                        Entity hostOppEntity = service.Retrieve("opportunity", hostOpp.Id, new ColumnSet("niq_revenuesharedeal"));
                        if (hostOppEntity != null)
                        {
                            //get the IsRevShare flag from current opportunities host opportunity
                            opportunityIsRevsShareflag = hostOppEntity.GetAttributeValue<bool?>("niq_revenuesharedeal");
                            if (opportunityIsRevsShareflag.HasValue && opportunityIsRevsShareflag == true)
                            {
                                isRevShareOpportunity = true;//If current opportunity is a host opportunity fetch set the IsRevshare
                            }
                            else
                            {
                                isRevShareOpportunity = false;
                            }
                        }
                        tracing.Trace("Current Opportunities host opportunity Id: " + hostOpp.Id);
                    }
                }
                tracing.Trace("Current Opportunity Revshare Deal flag value: " + isRevShareOpportunity);
                #endregion
                tracing.Trace("MANII QUOTE ID: " + MainQuoteRef.Id);
                EntityReference AccountRef = OppEntity.GetAttributeValue<EntityReference>("parentaccountid");
                bool AssetCheck = CheckAccountHasAssetsForCurrentOpportunity(service, AccountRef.Id, OppEntity.Id);
                bool SalesOrderCheck = checkSalesOrderLinkedWithOpportunity(service, new Guid(opportunityId), new Guid(salesOrderId));
                if (AssetCheck && SalesOrderCheck)
                {
                    Entity QuoteEntity = service.Retrieve(MainQuoteRef.LogicalName, MainQuoteRef.Id, new ColumnSet("niq_contractstartdate", "niq_contractenddate", "niq_salesorgid", "niq_termtype"));
                    List<Entity> quoteProducts = GetQuoteProduct(service, MainQuoteRef.Id);

                    tracing.Trace($@"ListQP: {quoteProducts.Count}");
                    foreach (Entity quoteProduct in quoteProducts)
                    {
                        tracing.Trace("PRODUCT: " + quoteProduct.GetAttributeValue<string>("productname"));
                        var revShareFlag = false;
                        var ELassetId = quoteProduct.GetAttributeValue<string>("niq_elassetid");
                        var revshareline = quoteProduct.GetAttributeValue<bool>("niq_isrevshareline");
                        tracing.Trace("Is Revenue ShareLine: " + revshareline.ToString());
                        tracing.Trace("EL ID: " + ELassetId);
                        if ((!string.IsNullOrEmpty(ELassetId) && assetIds.Add(ELassetId)) || revshareline) // Ensures uniqueness
                        {
                            if (quoteProduct.Attributes.Contains("niq_databasename"))
                            {
                                tracing.Trace("database product");
                                string databaseName = quoteProduct.GetAttributeValue<string>("niq_databasename");
                                string expConfig = quoteProduct.GetAttributeValue<string>("niq_productdescription");
                                string ratecardId = quoteProduct.GetAttributeValue<string>("niq_ratecardid");
                                tracing.Trace("RATE CARD ID IN DATABASE ASSET: " + ratecardId);
                                if (!uniqueAssets.Any(e => e.ElAssetID == ELassetId))
                                {
                                    uniqueAssets.Add(new AssetData { ElAssetID = ELassetId, IsRevShare = false, RateCardID = ratecardId, AssetName = AccountRef.Name + "_" + databaseName, IsDatabase = true, DatabaseName = databaseName, ExperlogixConfig = expConfig });
                                }
                            }
                            else if (quoteProduct.Attributes.Contains("niq_isrevshareline") && quoteProduct.GetAttributeValue<bool>("niq_isrevshareline") == true && !revShareFlag)
                            {
                                tracing.Trace("revshare product");
                                string databaseName = quoteProduct.GetAttributeValue<string>("niq_databasename");
                                string expConfig = quoteProduct.GetAttributeValue<string>("niq_productdescription");
                                if (!uniqueAssets.Any(e => e.IsRevShare == true))
                                {
                                    uniqueAssets.Add(new AssetData { IsRevShare = true, AssetName = "RevShare_" + AccountRef.Name, IsDatabase = false, DatabaseName = databaseName, ExperlogixConfig = expConfig });
                                }
                                revShareFlag = true;
                            }
                            else
                            {
                                tracing.Trace("manual added product");
                                EntityReference ProductRef = quoteProduct.GetAttributeValue<EntityReference>("productid");
                                string productName = ProductRef.Name;
                                string expConfig = quoteProduct.GetAttributeValue<string>("niq_productdescription");
                                tracing.Trace($@"Asset-Name: {productName}");
                                if (!uniqueAssets.Any(e => e.ElAssetID == ELassetId))
                                {
                                    uniqueAssets.Add(new AssetData { ElAssetID = ELassetId, IsRevShare = false, AssetName = AccountRef.Name + "_" + productName, IsDatabase = false, ProductName = productName, ExperlogixConfig = expConfig });
                                }
                            }
                        }
                    }
                    tracing.Trace($@"uniqueAssetList: {uniqueAssets.Count}");

                    foreach (AssetData assetData in uniqueAssets)
                    {
                        // find if asset already exists for account by databasename / productname ->> we have to create new field 
                        tracing.Trace($@"AssetName: {assetData.AssetName}");
                        Guid AssetId = getAsset(service, OppEntity, assetData);
                        tracing.Trace("ASSET LINEKD!");
                        Guid AssetConfigId = CreateAssetConfig(service, quoteProducts, OppEntity, QuoteEntity, AssetId, assetData, AccountRef, new Guid(salesOrderId), isRevShareOpportunity);
                        tracing.Trace("ASSET CONFIG CREATED!");
                        CreateAssetMaterial(service, quoteProducts, OppEntity, AssetId, AssetConfigId, assetData, tracing);
                        tracing.Trace("ASSET MATERIAL CREATED!");
                        createAssetDocumentrecords(service, AssetId, OppEntity, AssetConfigId, QuoteEntity);
                        tracing.Trace("ASSET DOCUMENT CREATED!");
                        context.OutputParameters["IsSuccess"] = true;
                        context.OutputParameters["ErrorMessage"] = "";
                    }
                }
                else
                {
                    if (!SalesOrderCheck)
                    {
                        tracing.Trace($@"Sales Order not associated with Opportunity.");
                        context.OutputParameters["IsSuccess"] = false;
                        context.OutputParameters["ErrorMessage"] = "Sales Order not associated with Opportunity.";
                    }
                    if (!AssetCheck)
                    {
                        tracing.Trace($@"Opportunity already associated with asset(s).");
                        context.OutputParameters["IsSuccess"] = false;
                        context.OutputParameters["ErrorMessage"] = "Opportunity already associated with asset(s).";
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                context.OutputParameters["IsSuccess"] = false;
                context.OutputParameters["ErrorMessage"] = ex.Message;
                tracing.Trace("ERROR: " + ex.Message);
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        /// <summary>
        ///     Check Account has Assets for Opportunity
        /// </summary>
        /// <param name="service">Organization Service</param>
        /// <param name="accountId">Account Id</param>
        /// <param name="opportunityId">Opportunity Id</param>
        /// <returns></returns>
        public bool CheckAccountHasAssetsForCurrentOpportunity(IOrganizationService service, Guid accountId, Guid opportunityId)
        {
            string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='niq_asset'>
                                    <attribute name='niq_assetid' />
                                    <attribute name='niq_assetnumber' />
                                    <attribute name='createdon' />
                                    <order attribute='niq_assetnumber' descending='false' />
                                    <filter type='and'>
                                    <condition attribute='niq_account' operator='eq' value='{accountId}' />
                                    <condition attribute='niq_originatingopportunity' operator='eq' value='{opportunityId}' />
                                    </filter>
                                </entity>
                                </fetch>";


            return !service.RetrieveMultiple(new FetchExpression(fetchXml)).Entities.Any();
        }

        /// <summary>
        /// Get Quote Products by MainQuoteId
        /// </summary>
        /// <param name="service">Organization Service</param>
        /// <param name="MainQuoteId">Maind Quote Guid</param>
        /// <returns></returns>
        private List<Entity> GetQuoteProduct(IOrganizationService service, Guid MainQuoteId)
        {
            string fetchXmlQP = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='quotedetail'>
                                            <attribute name='quotedetailid' />
                                            <attribute name='quotedetailname' />
                                            <attribute name='productid' />
                                            <attribute name='quotedetailname' />
                                            <attribute name='niq_elassetid' />
                                            <attribute name='niq_lineitemstartdate' />
                                            <attribute name='niq_lineitemenddate' />
                                            <attribute name='niq_databasename' />
                                            <attribute name='baseamount' />
                                            <attribute name='extendedamount' />
                                            <attribute name='niq_countinput' />
                                            <attribute name='niq_contractproductname' />
                                            <attribute name='manualdiscountamount' />	
                                            <attribute name='niq_productdescription' />	
                                            <attribute name='niq_updatefrequency' />	
                                            <attribute name='productname' />	
                                            <attribute name='niq_isrevshareline' />	
                                            <attribute name='niq_ratecardid' />	
                                            <attribute name='niq_remark' />	
                                            <order attribute='quotedetailname' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='quoteid' operator='eq' value='{MainQuoteId}'/>
                                              <condition attribute='productname' operator='ne' value='SAP Deferred Revenue reconciliation placeholder' />
                                            </filter>
                                          </entity>
                                        </fetch>";
            List<Entity> QuoteProductList = service.RetrieveMultiple(new FetchExpression(fetchXmlQP)).Entities.ToList();
            return QuoteProductList;
        }

        /// <summary>
        /// Create Asset Config Records
        /// </summary>
        /// <param name="service">Organization Service</param>
        /// <param name="quoteProducts">Quote Product List</param>
        /// <param name="OppEntity">Opportunity Entity</param>
        /// <param name="QuoteEntity">Quote Entity</param>
        /// <param name="AssetId">Asset Id</param>
        /// <param name="uniqueAsset">Unique Asset List</param>
        /// <param name="AccountRef">Account Reference</param>
        /// <param name="SalesOrderId">Sales Order Id</param>
        /// <returns></returns>
        public Guid CreateAssetConfig(IOrganizationService service, List<Entity> quoteProducts, Entity OppEntity, Entity QuoteEntity, Guid AssetId, AssetData uniqueAsset, EntityReference AccountRef, Guid SalesOrderId, bool isRevShareOpportunity)
        {
            Entity assetConfig = new Entity("niq_assetconfig");
            assetConfig["niq_asset"] = new EntityReference("niq_asset", AssetId);
            mapAssetTypeAndHost(OppEntity, uniqueAsset, assetConfig, isRevShareOpportunity);
            assetConfig["niq_ratecardid"] = uniqueAsset.RateCardID;
            assetConfig["niq_account"] = new EntityReference("account", AccountRef.Id);
            assetConfig["niq_originatingopportunity"] = OppEntity.ToEntityReference();
            assetConfig["transactioncurrencyid"] = OppEntity.GetAttributeValue<EntityReference>("transactioncurrencyid");
            assetConfig["niq_sapsalesdocumentid"] = OppEntity.GetAttributeValue<string>("niq_sapsalesdocumentid");
            assetConfig["niq_originatingquote"] = new EntityReference("quote", QuoteEntity.Id);
            assetConfig["niq_originatingsalesorder"] = new EntityReference("salesorder", SalesOrderId);
            assetConfig["niq_experlogixconfig"] = uniqueAsset.ExperlogixConfig;
            assetConfig["niq_originatingaction"] = getAction(OppEntity);
            tracing.Trace("ACTION MAPPEDD");
            assetConfig["niq_assettermnote"] = getnotes(OppEntity);
            if (OppEntity.Attributes.Contains("originatingleadid"))
                assetConfig["niq_originatinglead"] = OppEntity.GetAttributeValue<EntityReference>("originatingleadid");
            if (QuoteEntity.Attributes.Contains("niq_salesorgid"))
                assetConfig["niq_assetsalesorg"] = QuoteEntity.GetAttributeValue<EntityReference>("niq_salesorgid");
            DateTime todaysDate = DateTime.Today;
            tracing.Trace("MAPPED TILL TODAYS DATE");
            List<Entity> filteredProducts = new List<Entity>();
            if (!string.IsNullOrEmpty(uniqueAsset.ElAssetID))
                filteredProducts = quoteProducts.Where(e => e.Attributes.Contains("niq_elassetid") && e.GetAttributeValue<string>("niq_elassetid") == uniqueAsset.ElAssetID).ToList();
            else if (uniqueAsset.IsRevShare)
                filteredProducts = quoteProducts.Where(e => e.Attributes.Contains("niq_isrevshareline") && e.GetAttributeValue<bool>("niq_isrevshareline") == true).ToList();
            else
            {
                filteredProducts = quoteProducts.Where(e => e.Attributes.Contains("productid") &&
                e.GetAttributeValue<EntityReference>("productid").Name == uniqueAsset.ProductName &&
                e.Attributes.Contains("niq_elassetid") &&
                new Guid(e.GetAttributeValue<string>("niq_elassetid")) == new Guid(uniqueAsset.ElAssetID)
                ).ToList();
            }
            DateTime assetStartDate = filteredProducts.Where(e => e.Contains("niq_lineitemstartdate")).Select(e => e.GetAttributeValue<DateTime>("niq_lineitemstartdate")).Min();
            DateTime assetEndDate = filteredProducts.Where(e => e.Contains("niq_lineitemstartdate")).Select(e => e.GetAttributeValue<DateTime>("niq_lineitemenddate")).Max();
            assetConfig["niq_assetstartdate"] = assetStartDate;
            assetConfig["niq_assetenddate"] = assetEndDate;
            if (assetStartDate <= todaysDate && assetEndDate >= todaysDate)
                assetConfig["niq_assetstatus"] = new OptionSetValue((int)AssetStatus.Active);
            else if (assetStartDate < todaysDate && assetEndDate <= todaysDate)
                assetConfig["niq_assetstatus"] = new OptionSetValue((int)AssetStatus.Inactive);
            else if (assetStartDate > todaysDate && assetEndDate > todaysDate)
                assetConfig["niq_assetstatus"] = new OptionSetValue((int)AssetStatus.Future);
            assetConfig["niq_assetcreationdate"] = DateTime.UtcNow;
            tracing.Trace("MAPPED TILL ASSET CREATION DATE");
            if (uniqueAsset.IsDatabase)
            {
                tracing.Trace("INSIDE DATABSE ASSET CONDITION");
                List<Entity> filteredQuoteProducts = filterQuoteProductsByElAssetIDName(quoteProducts, uniqueAsset.ElAssetID);
                decimal filteredPrice = filteredQuoteProducts.Where(e => e.Contains("baseamount") && e["baseamount"] != null).Sum(e => ((Money)e["baseamount"]).Value);
                assetConfig["niq_assetprice"] = new Money(filteredPrice);
                decimal filteredPriceDiscount = filteredQuoteProducts.Where(e => e.Contains("extendedamount") && e["extendedamount"] != null).Sum(e => ((Money)e["extendedamount"]).Value);
                assetConfig["niq_assetextendedamount"] = new Money(filteredPriceDiscount);
                assetConfig["niq_updatefrequency"] = filteredQuoteProducts.FirstOrDefault().GetAttributeValue<OptionSetValue>("niq_updatefrequency");
            }
            else if (uniqueAsset.IsRevShare)
            {
                tracing.Trace("INSIDE REVSHARE ASSET CONDITION");
                List<Entity> filteredQP = quoteProducts.Where(qp => qp.Contains("niq_isrevshareline") && qp.GetAttributeValue<bool>("niq_isrevshareline")).ToList();
                tracing.Trace("PRODUCTS FILTERED");
                decimal filteredPrice = filteredQP.Where(e => e.Contains("baseamount") && e["baseamount"] != null).Sum(e => ((Money)e["baseamount"]).Value);
                assetConfig["niq_assetprice"] = new Money(filteredPrice);
                tracing.Trace("ASSET PRICE FILTERED");
                decimal filteredPriceDiscount = filteredQP.Where(e => e.Contains("extendedamount") && e["extendedamount"] != null).Sum(e => ((Money)e["extendedamount"]).Value);
                assetConfig["niq_assetextendedamount"] = new Money(filteredPriceDiscount);
                tracing.Trace("EXTENDED AMOUNT FILTERED");
                assetConfig["niq_updatefrequency"] = filteredQP.FirstOrDefault().GetAttributeValue<OptionSetValue>("niq_updatefrequency");
                tracing.Trace("UPDATE FREQUENCY FILTERED");
            }
            else
            {
                tracing.Trace("INSIDE PRODUCT ASSET CONDITION");
                List<Entity> filteredQP = quoteProducts.Where(e => e.Contains("quotedetailname") && e["quotedetailname"] != null && e["quotedetailname"].Equals(uniqueAsset.ProductName) && e["niq_elassetid"].Equals(uniqueAsset.ElAssetID)).ToList();
                decimal filteredPrice = filteredQP.Where(e => e.Contains("baseamount") && e["baseamount"] != null).Sum(e => ((Money)e["baseamount"]).Value);
                assetConfig["niq_assetprice"] = new Money(filteredPrice);
                decimal filteredPriceDiscount = filteredQP.Where(e => e.Contains("extendedamount") && e["extendedamount"] != null).Sum(e => ((Money)e["extendedamount"]).Value);
                assetConfig["niq_assetextendedamount"] = new Money(filteredPriceDiscount);
                assetConfig["niq_updatefrequency"] = filteredQP.FirstOrDefault().GetAttributeValue<OptionSetValue>("niq_updatefrequency");
            }
            tracing.Trace("OUTSIDE TYPE OF ASSET CONDITIONS");
            OptionSetValue termtype = QuoteEntity.GetAttributeValue<OptionSetValue>("niq_termtype");
            if (termtype.Value == (Int32)TermType.EverGreen)
            {
                assetConfig["niq_termtype"] = new OptionSetValue((Int32)TermType.EverGreen);
            }
            else
            {
                assetConfig["niq_termtype"] = new OptionSetValue((Int32)TermType.Fixed);
            }
            OptionSetValue opportuntiyType = OppEntity.GetAttributeValue<OptionSetValue>("niq_opportunitytype");
            tracing.Trace("Opportunity Type :" + opportuntiyType.Value.ToString());
            assetConfig["niq_iscurrentassetconfig"] = true;
            if (opportuntiyType.Value == (Int32)OpportunityType.Existing_Contract && OppEntity.Attributes.Contains("niq_amendedfromopportunity") && OppEntity.GetAttributeValue<EntityReference>("niq_amendedfromopportunity") != null)
            {
                Guid originalOpportunityId = OppEntity.GetAttributeValue<EntityReference>("niq_amendedfromopportunity").Id;
                makeExistingAssetConfigNonCurrent(service, originalOpportunityId, AccountRef.Id, AssetId, OppEntity);
            }
            return service.Create(assetConfig);
        }

        public string getnotes(Entity Opportunity)
        {
            var OppType = Opportunity.GetAttributeValue<OptionSetValue>("niq_opportunitytype");
            var contractAction = Opportunity.GetAttributeValue<OptionSetValue>("niq_existingcontractaction");
            if (OppType.Value == (Int32)OpportunityType.Existing_Contract)
            {
                if (contractAction.Value == (Int32)ExistingContractAction.COLA_PE)
                {
                    var COLA = Opportunity.GetAttributeValue<decimal>("niq_cola");
                    var PE = Opportunity.GetAttributeValue<decimal>("niq_productenhancement");
                    return "COLA & PE Application " + (PE + COLA).ToString("F2") + "%";
                }
                else if (contractAction.Value == (Int32)ExistingContractAction.Evergreen)
                {
                    var COLA = Opportunity.GetAttributeValue<decimal>("niq_cola");
                    var PE = Opportunity.GetAttributeValue<decimal>("niq_productenhancement");
                    var EVERGREEN = Opportunity.GetAttributeValue<decimal>("niq_evergreenincrease");
                    return "Evergreen Renewal " + "PE - " + PE.ToString("F2") + "%" + " COLA - " + COLA.ToString("F2") + "%" + " Evergreen Increase - " + EVERGREEN.ToString("F2") + "%";
                }
                else
                    return Opportunity.GetAttributeValue<string>("name");
            }
            else
            {
                return Opportunity.GetAttributeValue<string>("name");
            }
        }

        /// <summary>
        /// make Existing Asset Config Non Current to restrict from appearing in Asset Config Grid
        /// </summary>
        /// <param name="service">Organization Service</param>
        /// <param name="OppId">Opportunity GUID</param>
        /// <param name="AccountId">Account GUID</param>
        public void makeExistingAssetConfigNonCurrent(IOrganizationService service, Guid OppId, Guid AccountId, Guid assetId, Entity OppEntity)
        {
            string fetchXml = $@"<fetch>
                                <entity name='niq_assetconfig'>
                                    <attribute name='niq_assetconfigid' />
                                    <filter type='and'>
                                        <condition attribute='niq_account' operator='eq' value='{AccountId}' />
                                        <condition attribute='niq_asset' operator='eq' value='{assetId}' />
                                    </filter>
                                </entity>
                            </fetch>";
            List<Entity> configRecords = service.RetrieveMultiple(new FetchExpression(fetchXml)).Entities.ToList();
            tracing.Trace("TOTAL EXISITNG ASSETS! " + configRecords.Count());
            if (configRecords.Count > 0)
            {
                tracing.Trace("INSIDE IF OF makeExistingAssetConfigNonCurrent FN");
                foreach (var configRecord in configRecords)
                {
                    configRecord["niq_iscurrentassetconfig"] = false;
                    service.Update(configRecord);
                }
                tracing.Trace("LEAVING IF OF makeExistingAssetConfigNonCurrent FN");
            }
        }

        /// <summary>
        /// Create Asset Material
        /// </summary>
        /// <param name="service">Organization Service</param>
        /// <param name="quoteProducts">Quote Product List</param>
        /// <param name="OppEntity">Opportunity Entity</param>
        /// <param name="AssetId">Asset Id</param>
        /// <param name="AssetConfigId">Asset Config Id</param>
        /// <param name="uniqueAsset">Unique Asset Data</param>
        /// <param name="tracing">Tracing Service</param>
        public void CreateAssetMaterial(IOrganizationService service, List<Entity> quoteProducts, Entity OppEntity, Guid AssetId, Guid AssetConfigId, AssetData uniqueAsset, ITracingService tracing)
        {
            List<Entity> MaterialListQP = new List<Entity>();
            if (!string.IsNullOrEmpty(uniqueAsset.ElAssetID))
            {
                MaterialListQP = quoteProducts.Where(e => e.Attributes.Contains("niq_elassetid") && e.GetAttributeValue<string>("niq_elassetid") == uniqueAsset.ElAssetID).ToList();
            }
            else if (uniqueAsset.IsRevShare)
            {
                MaterialListQP = quoteProducts.Where(e => e.Attributes.Contains("niq_isrevshareline") && e.GetAttributeValue<bool>("niq_isrevshareline") == true).ToList();
            }
            else
            {
                MaterialListQP = quoteProducts.Where(e => e.Attributes.Contains("productid") && e.GetAttributeValue<EntityReference>("productid").Name == uniqueAsset.ProductName && e.GetAttributeValue<string>("niq_elassetid") == uniqueAsset.ElAssetID).ToList();
            }

            foreach (var quoteProduct in MaterialListQP)
            {
                Entity assetMaterial = new Entity("niq_assetmaterial");
                assetMaterial["niq_asset"] = new EntityReference("niq_asset", AssetId);
                assetMaterial["niq_correspondingquoteproduct"] = new EntityReference(quoteProduct.LogicalName, quoteProduct.Id);
                assetMaterial["niq_ratecardid"] = uniqueAsset.RateCardID;
                assetMaterial["transactioncurrencyid"] = quoteProduct.GetAttributeValue<EntityReference>("transactioncurrencyid");
                assetMaterial["niq_productid"] = new EntityReference("product", quoteProduct.GetAttributeValue<EntityReference>("productid").Id);
                assetMaterial["niq_assetconfig"] = new EntityReference("niq_assetconfig", AssetConfigId);
                assetMaterial["niq_amount"] = quoteProduct.GetAttributeValue<Money>("baseamount");
                assetMaterial["niq_extendedamount"] = quoteProduct.GetAttributeValue<Money>("extendedamount");
                assetMaterial["niq_productname"] = quoteProduct.GetAttributeValue<string>("niq_contractproductname");
                assetMaterial["niq_remarks"] = quoteProduct.GetAttributeValue<string>("niq_remark");
                assetMaterial["niq_countofitem"] = quoteProduct.GetAttributeValue<string>("niq_countinput");
                if (quoteProduct.Attributes.Contains("niq_lineitemstartdate"))
                    assetMaterial["niq_startdate"] = quoteProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                if (quoteProduct.Attributes.Contains("niq_lineitemenddate"))
                    assetMaterial["niq_enddate"] = quoteProduct.GetAttributeValue<DateTime>("niq_lineitemenddate");

                if (quoteProduct.Attributes.Contains("niq_lineitemstartdate") && quoteProduct.Attributes.Contains("niq_lineitemenddate"))
                {
                    DateTime startDate = quoteProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                    DateTime endDate = quoteProduct.GetAttributeValue<DateTime>("niq_lineitemenddate");
                    DateTime todaysDate = DateTime.Today;

                    if (startDate <= todaysDate && endDate >= todaysDate)
                        assetMaterial["niq_productstatus"] = new OptionSetValue((int)AssetStatus.Active);
                    else if (startDate < todaysDate && endDate <= todaysDate)
                        assetMaterial["niq_productstatus"] = new OptionSetValue((int)AssetStatus.Inactive);
                    else if (startDate > todaysDate && endDate > todaysDate)
                        assetMaterial["niq_productstatus"] = new OptionSetValue((int)AssetStatus.Future);
                }
                //try
                //{
                //    var expString = uniqueAsset.ExperlogixConfig;
                //    List<KeyValuePair<string, string>> list = getJsonFields();
                //    foreach (var pair in list)
                //    {
                //        string jsonKey = pair.Key;
                //        object value = GetValueFromFirstObject(expString, jsonKey, tracing);
                //        if (value != null)
                //        {
                //            assetMaterial[pair.Value] = value.ToString();
                //        }
                //    }
                //}
                //catch
                //{
                //    continue;
                //}
                service.Create(assetMaterial);
            }
        }

        /// <summary>
        /// Filter Quote Product by Database Name
        /// </summary>
        /// <param name="quoteProducts">Quote Product List</param>
        /// <param name="databaseName">Name of Database</param>
        /// <returns></returns>
        public List<Entity> filterQuoteProductsByElAssetIDName(List<Entity> quoteProducts, string elAssetId)
        {
            List<Entity> filteredList = quoteProducts.Where(e => e.Contains("niq_elassetid") && e["niq_elassetid"] != null && e["niq_elassetid"].Equals(elAssetId)).ToList();
            return filteredList;
        }

        /// <summary>
        /// Function to Check Sales Order for Corresponding opportunitities.
        /// </summary>
        /// <param name="jsonString"> JSON string where key value will be searched</param>
        /// <param name="key">key ton search in json string</param>
        ///  <param name="tracing"> tracing object for trace logs</param>
        /// <returns> get Value for corresponding key present in JSON. </returns>
        public bool checkSalesOrderLinkedWithOpportunity(IOrganizationService service, Guid opportunityId, Guid salesOrderId)
        {
            Entity SalesOrder = service.Retrieve("salesorder", salesOrderId, new ColumnSet("opportunityid"));
            Guid oppId = SalesOrder.GetAttributeValue<EntityReference>("opportunityid").Id;
            if (oppId == opportunityId)
                return true;
            else
                return false;
        }

        /// <summary>
        /// Function to crete Asset Document records.
        /// </summary>
        /// <param name="service"> Iorganization service to perform CRUD operations.</param>
        /// <param name="assetId">Asset record GUID to map it with asset document record</param>
        /// <param name="Opportunity"> Opportunity record to map fields with Asset Document record.</param>
        /// <param name="AssetConfigId"> Assett Config GUID to associate it with asset document record.</param>
        /// <param name="Quote"> Quote record data to populate in asset material record</param>
        public void createAssetDocumentrecords(IOrganizationService service, Guid assetId, Entity Opportunity, Guid AssetConfigId, Entity Quote)
        {

            var OppType = Opportunity.GetAttributeValue<OptionSetValue>("niq_opportunitytype");
            var contractAction = Opportunity.GetAttributeValue<OptionSetValue>("niq_existingcontractaction");
            if (Opportunity.Attributes.Contains("niq_podocumentationurl") && Opportunity.GetAttributeValue<string>("niq_podocumentationurl") != null)
            {
                Entity assetDocumentpo = new Entity("niq_assetdocument");
                assetDocumentpo["niq_account"] = new EntityReference("account", Opportunity.GetAttributeValue<EntityReference>("parentaccountid").Id);
                assetDocumentpo["niq_assetconfig"] = new EntityReference("niq_assetconfig", AssetConfigId);
                assetDocumentpo["niq_asset"] = new EntityReference("niq_asset", assetId);
                assetDocumentpo["niq_contractstartdate"] = Opportunity.GetAttributeValue<DateTime>("niq_contractstartdate");
                assetDocumentpo["niq_contractenddate"] = Opportunity.GetAttributeValue<DateTime>("niq_contractenddate");
                assetDocumentpo["niq_documenturl"] = Opportunity.GetAttributeValue<string>("niq_podocumentationurl");
                assetDocumentpo["niq_documenttype"] = new OptionSetValue((Int32)DocumentType.PO);
                if (OppType.Value == (Int32)OpportunityType.Existing_Contract && contractAction.Value == (Int32)ExistingContractAction.Amendment)
                    assetDocumentpo["niq_version"] = new OptionSetValue((Int32)DocumentVersion.Amendment);
                else if (OppType.Value == (Int32)OpportunityType.Existing_Contract && contractAction.Value == (Int32)ExistingContractAction.Renewal)
                    assetDocumentpo["niq_version"] = new OptionSetValue((Int32)DocumentVersion.Renewal);
                else
                    assetDocumentpo["niq_version"] = new OptionSetValue((Int32)DocumentVersion.Initial);
                service.Create(assetDocumentpo);
            }
            if (Opportunity.Attributes.Contains("niq_finallyexecutedagreementurl") && Opportunity.GetAttributeValue<string>("niq_finallyexecutedagreementurl") != null)
            {
                Entity assetDocumenteoa = new Entity("niq_assetdocument");
                assetDocumenteoa["niq_account"] = new EntityReference("account", Opportunity.GetAttributeValue<EntityReference>("parentaccountid").Id);
                assetDocumenteoa["niq_assetconfig"] = new EntityReference("niq_assetconfig", AssetConfigId);
                assetDocumenteoa["niq_asset"] = new EntityReference("niq_asset", assetId);
                assetDocumenteoa["niq_contractstartdate"] = Quote.GetAttributeValue<DateTime>("niq_contractstartdate");
                assetDocumenteoa["niq_contractenddate"] = Quote.GetAttributeValue<DateTime>("niq_contractenddate");
                assetDocumenteoa["niq_documenturl"] = Opportunity.GetAttributeValue<string>("niq_finallyexecutedagreementurl");
                assetDocumenteoa["niq_documenttype"] = new OptionSetValue((Int32)DocumentType.Finally_Executed_Agreement);
                if (OppType.Value == (Int32)OpportunityType.Existing_Contract && contractAction.Value == (Int32)ExistingContractAction.Amendment)
                    assetDocumenteoa["niq_version"] = new OptionSetValue((Int32)DocumentVersion.Amendment);
                else if (OppType.Value == (Int32)OpportunityType.Existing_Contract && contractAction.Value == (Int32)ExistingContractAction.Renewal)
                    assetDocumenteoa["niq_version"] = new OptionSetValue((Int32)DocumentVersion.Renewal);
                else
                    assetDocumenteoa["niq_version"] = new OptionSetValue((Int32)DocumentVersion.Initial);
                service.Create(assetDocumenteoa);
            }
        }

        /// <summary>
        ///     Function to get value of key present in Experlogix JSON mapped with field's logical name.
        /// </summary>
        /// <param name="jsonString"> JSON string where key value will be searched</param>
        /// <param name="key">key ton search in json string</param>
        /// <param name="tracing"> tracing object for trace logs</param>
        /// <returns> get Value for corresponding key present in JSON. </returns>
        static string GetValueFromFirstObject(string jsonString, string key, ITracingService tracing)
        {
            try
            {
                var jsonObject = JObject.Parse(jsonString);
                var firstProperty = jsonObject.Properties().FirstOrDefault(); // Get the first key dynamically
                if (firstProperty != null && firstProperty.Value is JObject nestedObject)
                {
                    tracing.Trace("KeF Found: " + key);
                    return nestedObject.TryGetValue(key, out JToken value) ? value.ToString() : null;
                }
            }
            catch (Exception ex)
            {
                tracing.Trace("Error: " + ex.Message);
                return null;
            }
            return null;
        }

        /// <summary>
        ///     Function to get List of Keys Value Pair present in Experlogix JSON mapped with field's logical name.
        /// </summary>
        /// <returns> key value pair of fields present in experlogix json. </returns>
        //public List<KeyValuePair<string, string>> getJsonFields()
        //{
        //    List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>();
        //    list.Add(new KeyValuePair<string, string>("Facts", "niq_facts"));
        //list.Add(new KeyValuePair<string, string>("Category Scope", "niq_categoryscope"));
        //list.Add(new KeyValuePair<string, string>("Periodicity", "niq_periodicity"));
        //list.Add(new KeyValuePair<string, string>("Granularity", "niq_granularity"));
        //list.Add(new KeyValuePair<string, string>("Local Market Multiplier", "niq_localmarketmultiplier"));
        //list.Add(new KeyValuePair<string, string>("Channels/Retailers", "niq_channelretailer"));
        //list.Add(new KeyValuePair<string, string>("Delivery Tier", "niq_deliverytier"));
        //list.Add(new KeyValuePair<string, string>("Ongoing ALS", "niq_ongoingals"));
        //list.Add(new KeyValuePair<string, string>("Health & Wellness", "niq_healthandwellness"));
        //list.Add(new KeyValuePair<string, string>("Tenants count", "niq_tenantscount"));
        //list.Add(new KeyValuePair<string, string>("View by Categories count", "niq_viewbycategoriescount"));
        //list.Add(new KeyValuePair<string, string>("Report Model(s)", "niq_reportmodels"));
        //list.Add(new KeyValuePair<string, string>("Services in Contract", "niq_contractservice"));
        //list.Add(new KeyValuePair<string, string>("Add-Ons", "niq_addons"));
        //list.Add(new KeyValuePair<string, string>("Assortment", "niq_assortment"));
        //list.Add(new KeyValuePair<string, string>("Assortment Department", "niq_assortmentdepartment"));
        //list.Add(new KeyValuePair<string, string>("Dataset CPS Product", "niq_datasetcpsprod"));
        //list.Add(new KeyValuePair<string, string>("Dataset CPS Package Select", "niq_datasetcpspackage"));
        //list.Add(new KeyValuePair<string, string>("Eq. Vol", "niq_eqvol"));
        //list.Add(new KeyValuePair<string, string>("Demographics", "niq_demographics"));
        //list.Add(new KeyValuePair<string, string>("Geographies", "niq_geographies"));
        //list.Add(new KeyValuePair<string, string>("Extended Back Data Included", "niq_extbackdataincluded"));
        //list.Add(new KeyValuePair<string, string>("Back Data", "niq_backdata"));
        //list.Add(new KeyValuePair<string, string>("Specific Panel", "niq_specificpanel"));
        //list.Add(new KeyValuePair<string, string>("Packaging", "niq_packaging"));
        //list.Add(new KeyValuePair<string, string>("Servicing", "niq_servicing"));
        //list.Add(new KeyValuePair<string, string>("Extract Name", "niq_extractname"));
        //list.Add(new KeyValuePair<string, string>("Market Count by Extract", "niq_marketcountextract"));
        //list.Add(new KeyValuePair<string, string>("Product Count by Extract", "niq_productcountextract"));
        //list.Add(new KeyValuePair<string, string>("Periods Count by Extract", "niq_periodcountextract"));
        //list.Add(new KeyValuePair<string, string>("Facts count by Extract", "niq_factcountbyextract"));
        //list.Add(new KeyValuePair<string, string>("Max count of Data Point", "niq_maxcountdatapoint"));
        //list.Add(new KeyValuePair<string, string>("Total Complementary NIQ Units", "niq_complementaryniqunit"));
        //list.Add(new KeyValuePair<string, string>("Total Chargeable Units", "niq_totalchargeableunit"));
        //return list;
        //}

        /// <summary>
        ///     Check opportunity type if it is new sales or existing contract.
        /// </summary>
        /// <param name="OppEntity">Opportunity Entity to check it's type</param>
        /// <returns> returns optionset value for type of opportunity. </returns>
        public OptionSetValue getAction(Entity OppEntity)
        {
            var OppType = OppEntity.GetAttributeValue<OptionSetValue>("niq_opportunitytype");
            if (OppType.Value == (Int32)OpportunityType.New_Sale)
            {
                return new OptionSetValue((Int32)AssetAction.New_Sale);
            }
            else
            {
                var contractAction = OppEntity.GetAttributeValue<OptionSetValue>("niq_existingcontractaction");
                if (contractAction.Value == (Int32)ExistingContractAction.Renewal)
                {
                    return new OptionSetValue((Int32)AssetAction.Renewal);
                }
                else if (contractAction.Value == (Int32)ExistingContractAction.COLA_PE)
                {
                    return new OptionSetValue((Int32)AssetAction.COLA_PE);
                }
                else if (contractAction.Value == (Int32)ExistingContractAction.Evergreen)
                {
                    return new OptionSetValue((Int32)AssetAction.Evergreen);
                }
                else
                {
                    return new OptionSetValue((Int32)AssetAction.Amendment);
                }
            }
        }

        /// <summary>
        ///     check if asset already exists for amendmend Opportunity. If not create asset and return GUID
        /// </summary>
        /// <param name="service"> Organizrion service to perform CRUD operatinos in Dataverse</param>
        /// <param name="Opportunity"> Opportunity ID to check it's type</param>
        /// <param name="Asset"> Asset class object where unique dataset values are stored</param>
        /// <returns> returns GUID of created asset record. </returns>
        public Guid getAsset(IOrganizationService service, Entity Opportunity, AssetData Asset)
        {
            tracing.Trace("Inside getAsset FN!!");
            var OppType = Opportunity.GetAttributeValue<OptionSetValue>("niq_opportunitytype");
            var contractAction = Opportunity.GetAttributeValue<OptionSetValue>("niq_existingcontractaction");
            if (OppType.Value == (Int32)OpportunityType.Existing_Contract)
            {
                if (Asset.ElAssetID != null) // for ratecard and manual entry products
                {
                    string FetchXML = $@"<fetch>
	                                        <entity name='niq_asset'>
		                                        <filter type='and'>
			                                        <condition attribute='niq_assetid' operator='eq' value='{Guid.Parse(Asset.ElAssetID)}' />
		                                        </filter>
	                                        </entity>
                                        </fetch>";
                    EntityCollection results = service.RetrieveMultiple(new FetchExpression(FetchXML));
                    if (results.Entities.Count() > 0)
                    {
                        return results.Entities[0].Id;
                    }
                    else
                    {
                        Guid assetId = CreateAsset(service, Opportunity, Asset);
                        return assetId;
                    }
                }
                else if (Asset.IsRevShare)
                {
                    if (RevShareAsset != null || checkRevShareAsset(Opportunity))
                        return RevShareAsset.Id;
                    else
                    {
                        Guid assetId = CreateAsset(service, Opportunity, Asset);
                        return assetId;
                    }
                }
                else
                {
                    Guid assetId = CreateAsset(service, Opportunity, Asset);
                    return assetId;
                }
            }
            else
            {
                Guid assetId = CreateAsset(service, Opportunity, Asset);
                return assetId;

            }
        }

        /// <summary>
        ///     Create asset record for Opportunity
        /// </summary>
        /// <param name="service"> Organization service to perform CRUD operations</param>
        /// <param name="Opportunity">Opportunity record to fetch it's values</param>
        /// <param name="Asset"></param>
        /// <returns> Guid of Asset record created</returns>
        public Guid CreateAsset(IOrganizationService service, Entity Opportunity, AssetData Asset)
        {
            tracing.Trace("inside create asset FN");
            Entity assetEntity = new Entity("niq_asset");
            if (Asset.ElAssetID != null)
                assetEntity["niq_assetid"] = Guid.Parse(Asset.ElAssetID);
            if (Asset.IsDatabase == true)
                assetEntity["niq_databaseproductname"] = Asset.DatabaseName;
            else
                assetEntity["niq_databaseproductname"] = Asset.ProductName;
            assetEntity["niq_assetname"] = Asset.AssetName;
            assetEntity["niq_account"] = Opportunity.GetAttributeValue<EntityReference>("parentaccountid");
            assetEntity["niq_originatingopportunity"] = Opportunity.ToEntityReference();
            try
            {
                tracing.Trace("TRY block of Create Asset FN");
                Guid AssetId = service.Create(assetEntity);
                if (Asset.IsRevShare)
                    updateElassetId(AssetId, Opportunity, Asset.ElAssetID);
                return AssetId;
            }
            catch (Exception ex)
            {
                tracing.Trace("CATCH block of Create Asset FN");
                //assetEntity["niq_assetid"] = Guid.NewGuid();
                //Guid AssetId = service.Create(assetEntity);
                //updateElassetId(AssetId, Opportunity, Asset.ElAssetID);
                //return AssetId;
                throw new InvalidPluginExecutionException("Exception: "+ex.Message);
            }
        }

        public void updateElassetId(Guid AssetId, Entity Opportunity, string ElassetId)
        {
            Guid quoteId = Opportunity.GetAttributeValue<EntityReference>("niq_mainquoteid").Id;
            string fetchXml = $@"<fetch>
	                            <entity name='quotedetail'>
		                            <filter type='and'>
			                            <condition attribute='niq_elassetid' operator='eq' value='{ElassetId}' />
                                        <condition attribute='quoteid' operator='eq' value='{quoteId}' />
		                            </filter>
	                            </entity>
                            </fetch>";
            List<Entity> QuoteProducts = service.RetrieveMultiple(new FetchExpression(fetchXml)).Entities.ToList();
            foreach (Entity quoteProduct in QuoteProducts)
            {
                quoteProduct["niq_elassetid"] = AssetId.ToString().Replace("-", "");
                service.Update(quoteProduct);
            }
            tracing.Trace("Leaving updateElassetId FN");
        }

        public void mapAssetTypeAndHost(Entity Opportuntiy, AssetData uniqueAsset, Entity assetConfig, bool isRevShareOpportunity)
        {
            if (!isRevShareOpportunity)
            {
                assetConfig["niq_assettype"] = new OptionSetValue((int)AssetType.Individual);
                tracing.Trace("Mapped INDIVIDUAL type");
            }
            else
            {
                if (uniqueAsset.IsRevShare)
                {
                    tracing.Trace("Mapped revshare type");
                    assetConfig["niq_assettype"] = new OptionSetValue((int)AssetType.RevShare);
                    assetConfig["niq_hostopportunity"] = new EntityReference(Opportuntiy.LogicalName, Opportuntiy.Id);
                }
                else if (Opportuntiy.Attributes.Contains("niq_hostopportunity") && Opportuntiy.GetAttributeValue<EntityReference>("niq_hostopportunity") != null)
                {
                    tracing.Trace("Mapped CHILD type");
                    assetConfig["niq_assettype"] = new OptionSetValue((int)AssetType.Child);
                    assetConfig["niq_hostopportunity"] = Opportuntiy.GetAttributeValue<EntityReference>("niq_hostopportunity");
                }
                else if (Opportuntiy.Attributes.Contains("niq_ishostopportunity") && Opportuntiy.GetAttributeValue<bool>("niq_ishostopportunity") == true)
                {
                    tracing.Trace("Mapped HOST type");
                    assetConfig["niq_hostopportunity"] = new EntityReference(Opportuntiy.LogicalName, Opportuntiy.Id);
                    assetConfig["niq_assettype"] = new OptionSetValue((int)AssetType.Host);
                }
            }
        }

        public bool checkRevShareAsset(Entity Opportuntiy)
        {
            Guid AccountId = Opportuntiy.GetAttributeValue<EntityReference>("parentaccountid").Id;
            Guid AmendedFromOpp = Opportuntiy.GetAttributeValue<EntityReference>("niq_amendedfromopportunity").Id;
            string FetchXML = $@"<fetch top='1'>
                                <entity name='niq_assetconfig'>
                                    <attribute name='niq_assetconfigid' />
                                    <attribute name='niq_asset' />
                                    <attribute name='niq_assetname' />
                                    <filter type='and'>
                                        <condition attribute='niq_assettype' operator='eq' value='4' />
                                        <condition attribute='niq_account' operator='eq' value='{AccountId}' />
                                        <condition attribute='niq_originatingopportunity' operator='eq' value='{AmendedFromOpp}' />
                                    </filter>
                                </entity>
                            </fetch>";
            EntityCollection RevShareAssets = service.RetrieveMultiple(new FetchExpression(FetchXML));
            if (RevShareAssets.Entities.Count() > 0)
            {
                RevShareAsset = RevShareAssets.Entities.First().GetAttributeValue<EntityReference>("niq_asset");
                return true;
            }
            else
                return false;
        }
    }
}