using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace NielsenIQ.ABO.Plugins
{
    public class CompareRenewalQuotes : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Retrieve the execution context and organization service
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            try
            {
                // Check if input parameters contain RenewalOpportunityID
                if (context.InputParameters.Contains("RenewalOpportunityID") && context.InputParameters["RenewalOpportunityID"] is EntityReference renewalOpportunityRef)
                {
                    DeleteExistingRenewalQuoteComparisons(service, renewalOpportunityRef);

                    EntityReference amendedFromOpportunityRef = GetAmendedFromOpportunity(service, renewalOpportunityRef);
                    if (amendedFromOpportunityRef == null) return;

                    EntityReference accountNameForAmendedFromOpportunityRef = GetAccountName(service, amendedFromOpportunityRef);
                    if (accountNameForAmendedFromOpportunityRef == null) return;

                    EntityReference accountNameForRenewalOpportunityRef = GetAccountName(service, renewalOpportunityRef);
                    if (accountNameForAmendedFromOpportunityRef == null) return;

                    EntityReference mainQuoteRef = GetMainQuote(service, amendedFromOpportunityRef);
                    if (mainQuoteRef == null) return;

                    CompareMainQuoteProducts(service, renewalOpportunityRef, mainQuoteRef, accountNameForAmendedFromOpportunityRef);
                    CompareRenewalOpportunityQuotes(service, renewalOpportunityRef, accountNameForRenewalOpportunityRef);
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("An error occurred in CompareRenewalQuotesPlugin: " + ex.Message, ex);
            }
        }

        // Deletes existing Renewal Quote Asset Compare records linked to the Renewal Opportunity
        private void DeleteExistingRenewalQuoteComparisons(IOrganizationService service, EntityReference renewalOpportunityRef)
        {
            QueryExpression query = new QueryExpression("niq_renewalquoteassetcompare")
            {
                ColumnSet = new ColumnSet("niq_renewalquoteassetcompareid"),
                Criteria = new FilterExpression
                {
                    Conditions = { new ConditionExpression("niq_opportunityid", ConditionOperator.Equal, renewalOpportunityRef.Id) }
                }
            };

            EntityCollection existingComparisons = service.RetrieveMultiple(query);
            foreach (Entity record in existingComparisons.Entities)
            {
                service.Delete(record.LogicalName, record.Id);
            }
        }

        // Retrieves the Amended From Opportunity reference
        private EntityReference GetAmendedFromOpportunity(IOrganizationService service, EntityReference renewalOpportunityRef)
        {
            Entity opportunity = service.Retrieve("opportunity", renewalOpportunityRef.Id, new ColumnSet("niq_amendedfromopportunity"));
            return opportunity?.GetAttributeValue<EntityReference>("niq_amendedfromopportunity");
        }

        // Retrieves the Main Quote reference
        private EntityReference GetMainQuote(IOrganizationService service, EntityReference amendedFromOpportunityRef)
        {
            Entity amendedOpportunity = service.Retrieve("opportunity", amendedFromOpportunityRef.Id, new ColumnSet("niq_mainquoteid"));
            return amendedOpportunity?.GetAttributeValue<EntityReference>("niq_mainquoteid");
        }

        // Retrieves the Account Name reference
        private EntityReference GetAccountName(IOrganizationService service, EntityReference opportunityRef)
        {
            Entity opportunity = service.Retrieve("opportunity", opportunityRef.Id, new ColumnSet("parentaccountid"));
            return opportunity?.GetAttributeValue<EntityReference>("parentaccountid");
        }

        // Compares products from the main quote
        private void CompareMainQuoteProducts(IOrganizationService service, EntityReference renewalOpportunityRef, EntityReference mainQuoteRef, EntityReference accountNameForAmendedFromOpportunityRef)
        {
            Entity quote = service.Retrieve("quote", mainQuoteRef.Id, new ColumnSet("quoteid"));
            EntityCollection mainQuoteProducts = GetQuoteProducts(service, quote);
            foreach (Entity product in mainQuoteProducts.Entities)
            {
                CreateRenewalQuoteComparison(service, renewalOpportunityRef, "Base Quote", product, accountNameForAmendedFromOpportunityRef);
            }
        }

        // Compares products from renewal opportunity quotes
        private void CompareRenewalOpportunityQuotes(IOrganizationService service, EntityReference renewalOpportunityRef, EntityReference accountNameForRenewalOpportunityRef)
        {
            QueryExpression query = new QueryExpression("quote")
            {
                ColumnSet = new ColumnSet("quoteid", "name"),
                Criteria = new FilterExpression
                {
                    Conditions = { new ConditionExpression("opportunityid", ConditionOperator.Equal, renewalOpportunityRef.Id) }
                }
            };

            EntityCollection renewalQuotes = service.RetrieveMultiple(query);
            foreach (Entity quote in renewalQuotes.Entities)
            {
                EntityCollection renewalQuoteProducts = GetQuoteProducts(service, quote);
                foreach (Entity renewalProduct in renewalQuoteProducts.Entities)
                {
                    CreateRenewalQuoteComparison(service, renewalOpportunityRef, quote.GetAttributeValue<String>("name"), renewalProduct, accountNameForRenewalOpportunityRef);
                }
            }
        }

        //Retrieves the Quote Products from Quote
        private EntityCollection GetQuoteProducts(IOrganizationService service, Entity quote)
        {
            QueryExpression productQuery = new QueryExpression("quotedetail")
            {
                ColumnSet = new ColumnSet("quotedetailid", "productid", "baseamount", "quoteid", "niq_updatefrequency", "niq_lineitemstartdate", "niq_lineitemenddate", "extendedamount", "niq_contractproductname", "niq_countinput", "niq_remark", "niq_databasename"),
                Criteria = new FilterExpression
                {
                    Conditions = {
                        new ConditionExpression("quoteid", ConditionOperator.Equal, quote.Id),
                        new ConditionExpression("productname", ConditionOperator.NotEqual, "Dummy Product For Total Amount Set")
                    }
                }
            };

            EntityCollection products = service.RetrieveMultiple(productQuery);
            return products;
        }

        // Creates a new Renewal Quote Asset Compare record
        private void CreateRenewalQuoteComparison(IOrganizationService service, EntityReference renewalOpportunityRef, string quoteType, Entity product, EntityReference accountNameRef)
        {
            Entity accountName = service.Retrieve("account", accountNameRef.Id, new ColumnSet("name"));
            string accountNameString = accountName?.GetAttributeValue<String>("name");
            string assetNameString = accountNameString + "_" + (product.GetAttributeValue<string>("niq_databasename") ?? (product.GetAttributeValue<string>("niq_contractproductname")));

            Entity comparisonRecord = new Entity("niq_renewalquoteassetcompare")
            {
                ["niq_opportunityid"] = renewalOpportunityRef,
                ["niq_assetname"] = assetNameString,
                ["niq_quotename"] = quoteType,
                ["niq_updatefrequency"] = product.Contains("niq_updatefrequency") ? product["niq_updatefrequency"] : null,
                ["niq_startdate"] = product.GetAttributeValue<DateTime?>("niq_lineitemstartdate"),
                ["niq_enddate"] = product.GetAttributeValue<DateTime?>("niq_lineitemenddate"),
                ["niq_amount"] = product.GetAttributeValue<Money>("baseamount"),
                ["niq_extendedamount"] = product.GetAttributeValue<Money>("extendedamount"),
                ["niq_productname"] = product.GetAttributeValue<string>("niq_contractproductname"),
                ["niq_remarks"] = product.GetAttributeValue<string>("niq_remark")
            };

            if (int.TryParse(product.GetAttributeValue<string>("niq_countinput"), out int itemCount))
            {
                comparisonRecord["niq_itemcount"] = itemCount;
            }

            service.Create(comparisonRecord);
        }
    }
}