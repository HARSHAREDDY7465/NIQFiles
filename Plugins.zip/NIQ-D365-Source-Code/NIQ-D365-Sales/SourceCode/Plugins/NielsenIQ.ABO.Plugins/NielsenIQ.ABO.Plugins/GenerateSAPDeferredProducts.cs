﻿using System;
using System.Activities.Expressions;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace NielsenIQ.ABO.Plugins
{
    public class GenerateSAPDeferredProducts : IPlugin
    {
        IOrganizationService service;
        ITracingService tracing;
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            service = factory.CreateOrganizationService(context.UserId);
            tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            tracing.Trace("START");
            try
            {
                string opportunityId = (string)context.InputParameters["opportunityId"];
                tracing.Trace($@"opportunityId: {opportunityId}");
                Entity Opportunity = getOpportunity(opportunityId);
                string commaSeperatedConfigIds = Opportunity.GetAttributeValue<string>("niq_assetconfigidinput");
                Guid currentquoteId = Opportunity.GetAttributeValue<EntityReference>("niq_mainquoteid").Id;
                Guid parentquoteId = getOpportunity(Opportunity.GetAttributeValue<EntityReference>("niq_amendedfromopportunity").Id.ToString()).GetAttributeValue<EntityReference>("niq_mainquoteid").Id;
                deleteExistingSAPDeferredProducts(currentquoteId);
                Entity currentQuoteEnt = service.Retrieve("quote", currentquoteId, new ColumnSet(true));
                Entity parentquoteEnt = service.Retrieve("quote", parentquoteId, new ColumnSet(true));
                List<Entity> currentQuoteProducts = getProducts(currentQuoteEnt, true);
                tracing.Trace("Current QP Count: " + currentQuoteProducts.Count);
                List<Entity> parentqQuoteProducts = getProducts(parentquoteEnt, false);
                tracing.Trace("Parent QP Count: " + parentqQuoteProducts.Count);
                List<Entity> AddedQuoteProducts = currentQuoteProducts.Where(currentQuoteProduct => !parentqQuoteProducts.Any(parentqQuoteProduct => parentqQuoteProduct.GetAttributeValue<EntityReference>("productid")?.Id == currentQuoteProduct.GetAttributeValue<EntityReference>("productid")?.Id &&
                                                                        parentqQuoteProduct.GetAttributeValue<string>("niq_contractproductname") == currentQuoteProduct.GetAttributeValue<string>("niq_contractproductname") &&
                                                                        Guid.Parse(parentqQuoteProduct.GetAttributeValue<string>("niq_elassetid")) == Guid.Parse(currentQuoteProduct.GetAttributeValue<string>("niq_elassetid")) &&
                                                                        currentQuoteProduct.GetAttributeValue<bool>("niq_isrevshareline") == false && parentqQuoteProduct.GetAttributeValue<bool>("niq_isrevshareline") == false)).ToList();
                List<Entity> DeletedQuoteProducts = getRemovedProducts(parentqQuoteProducts, currentQuoteProducts, commaSeperatedConfigIds);
                List<Entity> ModifiedQuoteProducts = getPriceChangedProducts(parentqQuoteProducts, currentQuoteProducts);


                // 1) Pull manual deferred lines (make sure your getter returns both fields)
                var manualDeferredLines = getManualSapDeferredProducts(currentQuoteEnt);

                // Normalization helper: trim + lower; returns null for null/empty input
                string Norm(string s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim().ToLowerInvariant();

                // 2) Build lookup sets

                // Names: case-insensitive via OrdinalIgnoreCase or normalize to lower
                var manualRelatedNames = new HashSet<string>(
                    manualDeferredLines
                        .Select(e => e.GetAttributeValue<string>("niq_sapdeferredrelatedproduct"))
                        .Where(s => !string.IsNullOrWhiteSpace(s))
                        .Select(s => s.Trim()),
                    StringComparer.OrdinalIgnoreCase);

                // Asset IDs: since niq_elassetid is a string, normalize to lower+trim for consistent matching
                var manualRelatedAssetIds = new HashSet<string>(
                    manualDeferredLines
                        .Select(e => e.GetAttributeValue<string>("niq_elassetid"))
                        .Select(Norm)
                        .Where(s => !string.IsNullOrEmpty(s))
                );

                // Helpers to read values from Modified/Added quotedetail
                string GetAddedProductName(Entity qd)
                {
                    return qd.GetAttributeValue<string>("productname");
                }

                string GetAddedProductAssetId(Entity qd)
                {
                    return qd.GetAttributeValue<string>("niq_elassetid");
                }

                // 3) Filter ModifiedQuoteProducts: exclude if name OR assetId matches any manual deferred line
                AddedQuoteProducts = AddedQuoteProducts
                    .Where(ap =>
                    {
                        // Name comparison (case-insensitive due to set)
                        var name = GetAddedProductName(ap);
                        var nameBlocks = !string.IsNullOrWhiteSpace(name) && manualRelatedNames.Contains(name.Trim());

                        // AssetId comparison (string-based, normalized)
                        var assetId = Norm(GetAddedProductAssetId(ap));
                        var assetBlocks = !string.IsNullOrEmpty(assetId) && manualRelatedAssetIds.Contains(assetId);

                        // Keep only those that do NOT match both criterion
                        return !(nameBlocks && assetBlocks);
                    })
                    .ToList();

                DeletedQuoteProducts = DeletedQuoteProducts
                    .Where(ap =>
                    {
                        // Name comparison (case-insensitive due to set)
                        var name = GetAddedProductName(ap);
                        var nameBlocks = !string.IsNullOrWhiteSpace(name) && manualRelatedNames.Contains(name.Trim());

                        // AssetId comparison (string-based, normalized)
                        var assetId = Norm(GetAddedProductAssetId(ap));
                        var assetBlocks = !string.IsNullOrEmpty(assetId) && manualRelatedAssetIds.Contains(assetId);

                        // Keep only those that do NOT match by both criterion
                        return !(nameBlocks && assetBlocks);
                    })
                    .ToList();

                ModifiedQuoteProducts = ModifiedQuoteProducts
                    .Where(ap =>
                    {
                        // Name comparison (case-insensitive due to set)
                        var name = GetAddedProductName(ap);
                        var nameBlocks = !string.IsNullOrWhiteSpace(name) && manualRelatedNames.Contains(name.Trim());

                        // AssetId comparison (string-based, normalized)
                        var assetId = Norm(GetAddedProductAssetId(ap));
                        var assetBlocks = !string.IsNullOrEmpty(assetId) && manualRelatedAssetIds.Contains(assetId);

                        // Keep only those that do NOT match by both criterion
                        return !(nameBlocks && assetBlocks);
                    })
                    .ToList();


                if (AddedQuoteProducts.Count() > 0)  // Create SPA Deferred Revenue product line for each addded product
                {
                    tracing.Trace("Inside Added Products logic.");
                    foreach (Entity addedproduct in AddedQuoteProducts)
                    {
                        tracing.Trace("Mapping Started");
                        Entity product = new Entity(addedproduct.LogicalName);
                        product["productname"] = "SAP Deferred Revenue reconciliation placeholder";
                        //product["niq_type"] = new OptionSetValue(2);
                        //product["niq_istimebased"] = false;
                        product["niq_termlength"] = (double)(addedproduct["niq_termlength"]);
                        product["niq_onplatformdelivery"] = addedproduct.GetAttributeValue<string>("niq_onplatformdelivery");
                        product["producttypecode"] = addedproduct.GetAttributeValue<OptionSetValue>("producttypecode");
                        product["niq_elassetid"] = addedproduct.GetAttributeValue<string>("niq_elassetid");
                        product["niq_brandid"] = addedproduct.GetAttributeValue<EntityReference>("niq_brandid");
                        product["niq_subbrandid"] = addedproduct.GetAttributeValue<EntityReference>("niq_subbrandid");
                        product["niq_lineitemstartdate"] = addedproduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                        product["niq_lineitemenddate"] = addedproduct.GetAttributeValue<DateTime>("niq_lineitemenddate");
                        product["priceperunit"] = new Money(0);
                        tracing.Trace($"Added Product - niq_billingstartdate: {addedproduct.GetAttributeValue<DateTime?>("niq_billingstartdate")?.ToString() ?? "NULL"}");
                        tracing.Trace($"Added Product - niq_billingenddate: {addedproduct.GetAttributeValue<DateTime?>("niq_billingenddate")?.ToString() ?? "NULL"}");
                        product["niq_billingstartdate"] = addedproduct.GetAttributeValue<DateTime?>("niq_billingstartdate");
                        product["niq_billingenddate"] = addedproduct.GetAttributeValue<DateTime?>("niq_billingenddate");
                        product["niq_calculatedtermlength"] = addedproduct.GetAttributeValue<double>("niq_calculatedtermlength");
                        OptionSetValue updateFrequency = addedproduct.GetAttributeValue<OptionSetValue>("niq_updatefrequency");
                        tracing.Trace("updateFrequency:" + updateFrequency);
                        //DYNCRM_30879
                        MapFrequencyFields(product, addedproduct, tracing);

                        //Udate Frequency
                        //if (updateFrequency.Value == 100000009 || updateFrequency.Value == 100000008)
                        //    product["niq_updatefrequency"] = new OptionSetValue(100000000);
                        //else
                        //    product["niq_updatefrequency"] = addedproduct.GetAttributeValue<OptionSetValue>("niq_updatefrequency");

                        //OptionSetValue deliverFrequency = addedproduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency");
                        //tracing.Trace("deliverFrequency:" + deliverFrequency);
                        //tracing.Trace("niq_onplatformdelivery:" + addedproduct.GetAttributeValue<string>("niq_onplatformdelivery").ToLower());
                        //// Revenue Frequency
                        //if (addedproduct.GetAttributeValue<string>("niq_onplatformdelivery") != null && addedproduct.GetAttributeValue<string>("niq_onplatformdelivery").ToLower() == "no")
                        //{
                        //    if (deliverFrequency.Value == 100000009 || deliverFrequency.Value == 100000008)
                        //        product["niq_deliveryfrequency"] = new OptionSetValue(100000000);
                        //    else
                        //        product["niq_deliveryfrequency"] = addedproduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency");
                        //}
                        //else
                        //{
                        //    product["niq_deliveryfrequency"] = new OptionSetValue(100000000); // monthly
                        //}
                        //// Lag Revenue Recognition
                        //if (addedproduct.GetAttributeValue<string>("niq_onplatformdelivery") != null && addedproduct.GetAttributeValue<string>("niq_onplatformdelivery").ToLower() == "no")
                        //{
                        //    product["niq_lagrevenuerecognition"] = addedproduct.GetAttributeValue<OptionSetValue>("niq_lagrevenuerecognition");
                        //}
                        //else
                        //{
                        //    product["niq_lagrevenuerecognition"] = new OptionSetValue(100000000); // No Lag
                        //}
                        //// Billing Frequency
                        //OptionSetValue billingFrequency = addedproduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency");
                        //if (billingFrequency.Value == 100000009 || billingFrequency.Value == 100000010 || billingFrequency.Value == 100000011 || billingFrequency.Value == 100000012 || billingFrequency.Value == 100000013 || billingFrequency.Value == 100000014)
                        //    product["niq_billingfrequency"] = new OptionSetValue(100000000);
                        //else
                        //    product["niq_billingfrequency"] = addedproduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency");

                        product["niq_reconciliationamount"] = addedproduct.GetAttributeValue<Money>("extendedamount");
                        product["productdescription"] = "SAP Deferred Revenue reconciliation placeholder";
                        product["quoteid"] = currentQuoteEnt.ToEntityReference();
                        product["msdyn_linedescription"] = "SAP Deferred Revenue reconciliation placeholder";
                        product["transactioncurrencyid"] = addedproduct.GetAttributeValue<EntityReference>("transactioncurrencyid");
                        product["niq_isocurrencycodeqp"] = addedproduct.GetAttributeValue<string>("niq_isocurrencycodeqp");
                        product["exchangerate"] = addedproduct.GetAttributeValue<decimal>("exchangerate");
                        product["quantity"] = addedproduct.GetAttributeValue<decimal>("quantity");
                        product["quotedetailname"] = "SAP Deferred Revenue reconciliation placeholder";
                        product["isproductoverridden"] = true;
                        product["niq_billingschedulestatus"] = new OptionSetValue(610570003);
                        tracing.Trace("Mapping Write In Product");
                        if (addedproduct.Attributes.Contains("niq_uslocalsubbrand") && addedproduct.GetAttributeValue<EntityReference>("niq_uslocalsubbrand") != null)
                            product["niq_uslocalsubbrand"] = addedproduct.GetAttributeValue<EntityReference>("niq_uslocalsubbrand");
                        product["niq_sapdeferredrelatedproduct"] = addedproduct.GetAttributeValue<string>("productname");
                        Guid SAPDeferredProduct = service.Create(product);
                        Entity updateProduct = new Entity(addedproduct.LogicalName);
                        updateProduct.Id = SAPDeferredProduct;
                        updateProduct["niq_isrevenuemodified"] = DateTime.UtcNow.ToString();
                        //updateProduct["niq_isbillingmodified"] = DateTime.UtcNow.ToString();
                        service.Update(updateProduct);
                        tracing.Trace("SAP DEFERRED LINE CREATED for Added Product:" + addedproduct.GetAttributeValue<string>("niq_contractproductname") + "Amount: " + addedproduct.GetAttributeValue<Money>("extendedamount").Value);
                    }
                }

                if (DeletedQuoteProducts.Count() > 0)  // Create SPA Deferred Revenue product line for each deleted product
                {
                    try
                    {
                        tracing.Trace("Inside Deleted Products logic.");
                        Entity currentquote = service.Retrieve("quote", currentquoteId, new ColumnSet("niq_contractstartdate"));
                        if (currentquote != null && currentquote.GetAttributeValue<DateTime>("niq_contractstartdate") != null)
                        {
                            DateTime contractStartDate = Convert.ToDateTime(currentquote["niq_contractstartdate"]);
                            if (contractStartDate != null)
                            {
                                tracing.Trace("CONTRACT START DATE: " + contractStartDate.ToString());
                                tracing.Trace("Error in Contract Date");
                                foreach (Entity deletedProduct in DeletedQuoteProducts)
                                {
                                    decimal Amount = -Math.Abs(getSchedulesAmount(service, deletedProduct.Id, contractStartDate.ToString()).Value);
                                    Money deletedamount = new Money(Amount);
                                    Entity product = new Entity(deletedProduct.LogicalName);
                                    DateTime productStartDate = contractStartDate;
                                    DateTime productEndDate = deletedProduct.GetAttributeValue<DateTime>("niq_lineitemenddate");
                                    product["productname"] = "SAP Deferred Revenue reconciliation placeholder";
                                    //product["niq_type"] = new OptionSetValue(2);
                                    //product["niq_istimebased"] = false;
                                    product["niq_onplatformdelivery"] = deletedProduct.GetAttributeValue<string>("niq_onplatformdelivery");
                                    product["producttypecode"] = deletedProduct.GetAttributeValue<OptionSetValue>("producttypecode");
                                    product["niq_brandid"] = deletedProduct.GetAttributeValue<EntityReference>("niq_brandid");
                                    product["niq_elassetid"] = deletedProduct.GetAttributeValue<string>("niq_elassetid");
                                    product["niq_subbrandid"] = deletedProduct.GetAttributeValue<EntityReference>("niq_subbrandid");
                                    product["niq_lineitemstartdate"] = productStartDate;
                                    product["niq_lineitemenddate"] = productEndDate;
                                    product["niq_termlength"] = (double)(Math.Round(((productEndDate - productStartDate).TotalDays) / 30));
                                    product["priceperunit"] = new Money(0);
                                    OptionSetValue updateFrequency = deletedProduct.GetAttributeValue<OptionSetValue>("niq_updatefrequency");
                                    //DYNCRM_30879
                                    MapFrequencyFields(product, deletedProduct, tracing);
                                    //if (updateFrequency.Value == 100000009 || updateFrequency.Value == 100000008)
                                    //    product["niq_updatefrequency"] = new OptionSetValue(100000000);
                                    //else
                                    //    product["niq_updatefrequency"] = deletedProduct.GetAttributeValue<OptionSetValue>("niq_updatefrequency");

                                    //OptionSetValue deliverFrequency = deletedProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency");
                                    //if (deletedProduct.GetAttributeValue<string>("niq_onplatformdelivery") != null && deletedProduct.GetAttributeValue<string>("niq_onplatformdelivery").ToLower() == "no")
                                    //{
                                    //    if (deliverFrequency.Value == 100000009 || deliverFrequency.Value == 100000008)
                                    //        product["niq_deliveryfrequency"] = new OptionSetValue(100000000);
                                    //    else
                                    //        product["niq_deliveryfrequency"] = deletedProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency");
                                    //}
                                    //else
                                    //{
                                    //    product["niq_deliveryfrequency"] = new OptionSetValue(100000000);
                                    //}


                                    //if (deletedProduct.GetAttributeValue<string>("niq_onplatformdelivery") != null && deletedProduct.GetAttributeValue<string>("niq_onplatformdelivery").ToLower() == "no")
                                    //{
                                    //    product["niq_lagrevenuerecognition"] = deletedProduct.GetAttributeValue<OptionSetValue>("niq_lagrevenuerecognition");
                                    //}
                                    //else
                                    //{
                                    //    product["niq_lagrevenuerecognition"] = new OptionSetValue(100000000); // No Lag
                                    //}
                                    //OptionSetValue billingFrequency = deletedProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency");
                                    //if (billingFrequency.Value == 100000009 || billingFrequency.Value == 100000010 || billingFrequency.Value == 100000011 || billingFrequency.Value == 100000012 || billingFrequency.Value == 100000013 || billingFrequency.Value == 100000014)
                                    //    product["niq_billingfrequency"] = new OptionSetValue(100000000);
                                    //else
                                    //    product["niq_billingfrequency"] = deletedProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency");
                                    product["niq_reconciliationamount"] = deletedamount;
                                    product["productdescription"] = "SAP Deferred Revenue reconciliation placeholder";
                                    product["quoteid"] = currentQuoteEnt.ToEntityReference();
                                    product["msdyn_linedescription"] = "SAP Deferred Revenue reconciliation placeholder";
                                    product["transactioncurrencyid"] = deletedProduct.GetAttributeValue<EntityReference>("transactioncurrencyid");
                                    product["niq_isocurrencycodeqp"] = deletedProduct.GetAttributeValue<string>("niq_isocurrencycodeqp");
                                    product["exchangerate"] = deletedProduct.GetAttributeValue<decimal>("exchangerate");
                                    product["quantity"] = deletedProduct.GetAttributeValue<decimal>("quantity");
                                    product["quotedetailname"] = "SAP Deferred Revenue reconciliation placeholder";
                                    product["isproductoverridden"] = true;
                                    product["niq_billingschedulestatus"] = new OptionSetValue(610570003);
                                    tracing.Trace($"Deleted Product - niq_billingstartdate: {deletedProduct.GetAttributeValue<DateTime?>("niq_billingstartdate")?.ToString() ?? "NULL"}");
                                    tracing.Trace($"Deleted Product - niq_billingenddate: {deletedProduct.GetAttributeValue<DateTime?>("niq_billingenddate")?.ToString() ?? "NULL"}");
                                    product["niq_billingstartdate"] = deletedProduct.GetAttributeValue<DateTime?>("niq_billingstartdate");
                                    product["niq_billingenddate"] = deletedProduct.GetAttributeValue<DateTime?>("niq_billingenddate");
                                    product["niq_calculatedtermlength"] = deletedProduct.GetAttributeValue<double>("niq_calculatedtermlength");
                                    if (deletedProduct.Attributes.Contains("niq_uslocalsubbrand") && deletedProduct.GetAttributeValue<EntityReference>("niq_uslocalsubbrand") != null)
                                        product["niq_uslocalsubbrand"] = deletedProduct.GetAttributeValue<EntityReference>("niq_uslocalsubbrand");
                                    product["niq_sapdeferredrelatedproduct"] = deletedProduct.GetAttributeValue<string>("productname");
                                    Guid SAPDeferredProduct = service.Create(product);
                                    Entity updateProduct = new Entity(deletedProduct.LogicalName);
                                    updateProduct.Id = SAPDeferredProduct;
                                    updateProduct["niq_isrevenuemodified"] = DateTime.UtcNow.ToString();
                                   // updateProduct["niq_isbillingmodified"] = DateTime.UtcNow.ToString();
                                    service.Update(updateProduct);
                                    tracing.Trace("SAP DEFERRED LINE CREATED for Deleted Product:" + deletedProduct.GetAttributeValue<string>("niq_contractproductname") + "Amount: " + deletedamount.Value);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        tracing.Trace(ex.Message);
                    }
                }

                if (ModifiedQuoteProducts.Count() > 0) // Create SPA Deferred Revenue product line for each modified product
                {
                    if (currentQuoteEnt != null && currentQuoteEnt.Contains("niq_contractstartdate") && currentQuoteEnt["niq_contractstartdate"] != null)
                    {
                        tracing.Trace("Inside Modified Quote Products logic");
                        foreach (Entity modifiedProduct in ModifiedQuoteProducts)
                        {
                            Entity ProductInParentQuote = parentqQuoteProducts.Where(parentQuoteProduct =>
                                parentQuoteProduct.GetAttributeValue<EntityReference>("productid").Id == modifiedProduct.GetAttributeValue<EntityReference>("productid").Id &&
                                new Guid(parentQuoteProduct.GetAttributeValue<string>("niq_elassetid")) == new Guid(modifiedProduct.GetAttributeValue<string>("niq_elassetid")) &&
                                parentQuoteProduct.GetAttributeValue<string>("niq_contractproductname") == modifiedProduct.GetAttributeValue<string>("niq_contractproductname")).First();
                            tracing.Trace("Parent Product ID: " + ProductInParentQuote.Id);
                            tracing.Trace("Modified Product ID: " + modifiedProduct.Id);
                            Money ModifiedAmount = getModifiedAmount(modifiedProduct, ProductInParentQuote, service);
                            Entity product = new Entity(modifiedProduct.LogicalName);
                            DateTime contractStartDate = Convert.ToDateTime(currentQuoteEnt["niq_contractstartdate"]);
                            DateTime productStartDate = contractStartDate;
                            DateTime productEndDate = ProductInParentQuote.GetAttributeValue<DateTime>("niq_lineitemenddate");
                            OptionSetValue productType = modifiedProduct.GetAttributeValue<OptionSetValue>("niq_type");
                            product["productname"] = "SAP Deferred Revenue reconciliation placeholder";
                            //product["niq_type"] = new OptionSetValue(2);
                            //product["niq_istimebased"] = false;
                            product["niq_onplatformdelivery"] = modifiedProduct.GetAttributeValue<string>("niq_onplatformdelivery");
                            product["producttypecode"] = modifiedProduct.GetAttributeValue<OptionSetValue>("producttypecode");
                            product["niq_brandid"] = modifiedProduct.GetAttributeValue<EntityReference>("niq_brandid");
                            product["niq_subbrandid"] = modifiedProduct.GetAttributeValue<EntityReference>("niq_subbrandid");

                            //aditional scenario for identifying Modification v/s Asset Deletion case if the Original quote product end date is less than amended quote product
                            // In this case the SAP deferred line item should have the starting date should be next date from Amended Quote product 
                            if (modifiedProduct.GetAttributeValue<DateTime>("niq_lineitemenddate") < productEndDate)//Asset Deletion
                            {
                                product["niq_lineitemstartdate"] = (modifiedProduct.GetAttributeValue<DateTime>("niq_lineitemenddate").AddDays(1));
                                product["niq_lineitemenddate"] = productEndDate;
                                tracing.Trace("productEndDate: " + productEndDate);
                                tracing.Trace("modifiedProduct[niq_lineitemstartdate]: " + modifiedProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate"));
                                product["niq_termlength"] = (double)GetDateDiffInMonth(productEndDate, modifiedProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate"));
                            }
                            else//Product Modification
                            {
                                product["niq_lineitemstartdate"] = modifiedProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                                product["niq_lineitemenddate"] = modifiedProduct.GetAttributeValue<DateTime>("niq_lineitemenddate");
                                product["niq_termlength"] = (double)(modifiedProduct["niq_termlength"]);
                            }

                            product["priceperunit"] = new Money(0);
                            //DYNCRM_30879
                            MapFrequencyFields(product, modifiedProduct, tracing);

                            //OptionSetValue updateFrequency = modifiedProduct.GetAttributeValue<OptionSetValue>("niq_updatefrequency");
                            //if (updateFrequency.Value == 100000009 || updateFrequency.Value == 100000008)
                            //    product["niq_updatefrequency"] = new OptionSetValue(100000000);
                            //else
                            //    product["niq_updatefrequency"] = modifiedProduct.GetAttributeValue<OptionSetValue>("niq_updatefrequency");

                            //OptionSetValue deliverFrequency = modifiedProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency");
                            //if (modifiedProduct.GetAttributeValue<string>("niq_onplatformdelivery") != null && modifiedProduct.GetAttributeValue<string>("niq_onplatformdelivery").ToLower() == "no")
                            //{
                            //    if (deliverFrequency.Value == 100000009 || deliverFrequency.Value == 100000008)
                            //        product["niq_deliveryfrequency"] = new OptionSetValue(100000000);
                            //    else
                            //        product["niq_deliveryfrequency"] = modifiedProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency");
                            //}
                            //else
                            //{
                            //    product["niq_deliveryfrequency"] = new OptionSetValue(100000000); // monthly
                            //}


                            //if (modifiedProduct.GetAttributeValue<string>("niq_onplatformdelivery") != null && modifiedProduct.GetAttributeValue<string>("niq_onplatformdelivery").ToLower() == "no")
                            //{
                            //    product["niq_lagrevenuerecognition"] = modifiedProduct.GetAttributeValue<OptionSetValue>("niq_lagrevenuerecognition");
                            //}
                            //{
                            //    product["niq_lagrevenuerecognition"] = new OptionSetValue(100000000); // No Lag
                            //}

                            //OptionSetValue billingFrequency = modifiedProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency");
                            //if (billingFrequency.Value == 100000009 || billingFrequency.Value == 100000010 || billingFrequency.Value == 100000011 || billingFrequency.Value == 100000012 || billingFrequency.Value == 100000013 || billingFrequency.Value == 100000014)
                            //    product["niq_billingfrequency"] = new OptionSetValue(100000000);
                            //else
                            //    product["niq_billingfrequency"] = modifiedProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency");
                            product["niq_reconciliationamount"] = ModifiedAmount;
                            product["productdescription"] = "SAP Deferred Revenue reconciliation placeholder";
                            product["quoteid"] = currentQuoteEnt.ToEntityReference();
                            product["msdyn_linedescription"] = "SAP Deferred Revenue reconciliation placeholder";
                            product["transactioncurrencyid"] = modifiedProduct.GetAttributeValue<EntityReference>("transactioncurrencyid");
                            product["niq_isocurrencycodeqp"] = modifiedProduct.GetAttributeValue<string>("niq_isocurrencycodeqp");
                            product["exchangerate"] = modifiedProduct.GetAttributeValue<decimal>("exchangerate");
                            product["quantity"] = modifiedProduct.GetAttributeValue<decimal>("quantity");
                            product["niq_elassetid"] = modifiedProduct.GetAttributeValue<string>("niq_elassetid");
                            product["quotedetailname"] = "SAP Deferred Revenue reconciliation placeholder";
                            product["isproductoverridden"] = true;
                            product["niq_billingschedulestatus"] = new OptionSetValue(610570003);
                            tracing.Trace($"Modified Product - niq_billingstartdate: {modifiedProduct.GetAttributeValue<DateTime?>("niq_billingstartdate")?.ToString() ?? "NULL"}");
                            tracing.Trace($"Modified Product - niq_billingenddate: {modifiedProduct.GetAttributeValue<DateTime?>("niq_billingenddate")?.ToString() ?? "NULL"}");
                            product["niq_billingstartdate"] = modifiedProduct.GetAttributeValue<DateTime?>("niq_billingstartdate");
                            product["niq_billingenddate"] = modifiedProduct.GetAttributeValue<DateTime?>("niq_billingenddate");
                            product["niq_calculatedtermlength"] = modifiedProduct.GetAttributeValue<double>("niq_calculatedtermlength");
                            if (modifiedProduct.Attributes.Contains("niq_uslocalsubbrand") && modifiedProduct.GetAttributeValue<EntityReference>("niq_uslocalsubbrand") != null)
                                product["niq_uslocalsubbrand"] = modifiedProduct.GetAttributeValue<EntityReference>("niq_uslocalsubbrand");
                            product["niq_sapdeferredrelatedproduct"] = modifiedProduct.GetAttributeValue<string>("productname");
                            Guid SAPDeferredProduct = service.Create(product);
                            Entity updateProduct = new Entity(modifiedProduct.LogicalName);
                            updateProduct.Id = SAPDeferredProduct;
                            updateProduct["niq_isrevenuemodified"] = DateTime.UtcNow.ToString();
                            //updateProduct["niq_isbillingmodified"] = DateTime.UtcNow.ToString();
                            service.Update(updateProduct);
                            tracing.Trace("SAP DEFERRED LINE CREATED for Modified Product:" + modifiedProduct.GetAttributeValue<string>("niq_contractproductname") + "Amount: " + ModifiedAmount.Value);
                        }
                    }
                }

                if (currentQuoteProducts.Count() == 0)
                {
                    context.OutputParameters["isSuccess"] = false;
                    return;
                }
                Entity Opp = new Entity("opportunity");
                Opp.Id = new Guid(opportunityId);
                Opp["niq_isdeferredrevenueclicked"] = true;
                service.Update(Opp);
                context.OutputParameters["isSuccess"] = true;
            }
            catch (Exception ex)
            {
                tracing.Trace("EXCEPTION : " + ex.Message);
                context.OutputParameters["isSuccess"] = false;
            }
        }
        /// <summary>
        /// Map Frequency Fields from Originating Opp
        /// </summary>
        /// <param name="targetProduct"></param>
        /// <param name="sourceProduct"></param>
        /// <param name="tracing"></param>
        private void MapFrequencyFields(Entity targetProduct, Entity sourceProduct, ITracingService tracing)
        {
            try
            {
                //Update Freq
                if (sourceProduct.Contains("niq_updatefrequency"))
                {
                    targetProduct["niq_updatefrequency"] = sourceProduct.GetAttributeValue<OptionSetValue>("niq_updatefrequency");
                    tracing.Trace($"Mapped niq_updatefrequency: {sourceProduct.GetAttributeValue<OptionSetValue>("niq_updatefrequency")?.Value}");
                }
                //revenue
                if (sourceProduct.Contains("niq_deliveryfrequency"))
                {
                    targetProduct["niq_deliveryfrequency"] = sourceProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency");
                    tracing.Trace($"Mapped niq_deliveryfrequency: {sourceProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency")?.Value}");
                }

                //lagrevenue
                if (sourceProduct.Contains("niq_lagrevenuerecognition"))
                {
                    targetProduct["niq_lagrevenuerecognition"] = sourceProduct.GetAttributeValue<OptionSetValue>("niq_lagrevenuerecognition");
                    tracing.Trace($"Mapped niq_lagrevenuerecognition: {sourceProduct.GetAttributeValue<OptionSetValue>("niq_lagrevenuerecognition")?.Value}");
                }

                //billing
                if (sourceProduct.Contains("niq_billingfrequency"))
                {
                    targetProduct["niq_billingfrequency"] = sourceProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency");
                    tracing.Trace($"Mapped niq_billingfrequency: {sourceProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency")?.Value}");
                }
                if (sourceProduct.Contains("niq_type"))
                {
                    targetProduct["niq_type"] = sourceProduct.GetAttributeValue<OptionSetValue>("niq_type");
                    tracing.Trace($"Mapped niq_type: {sourceProduct.GetAttributeValue<OptionSetValue>("niq_type")?.Value}");
                }
                if (sourceProduct.Contains("niq_istimebased"))
                {
                    targetProduct["niq_istimebased"] = sourceProduct.GetAttributeValue<bool>("niq_istimebased");
                    tracing.Trace($"Mapped niq_istimebased: {sourceProduct.GetAttributeValue<bool>("niq_istimebased")}");
                }

            }
            catch (Exception ex)
            {
                tracing.Trace($"Error mapping frequency fields: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Calculate the number of Months (non fractional) between 2 given dates
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>

        public static int GetDateDiffInMonth(DateTime endDate, DateTime startDate)
        {

            int months = ((endDate.Year - startDate.Year) * 12) + endDate.Month - startDate.Month;
            //considering our End dates are always last day of month, so increasing month count by 1 to adjust for the date
            months++;
            return months;
        }

        public Entity getOpportunity(string OpportunityId)
        {
            return service.Retrieve("opportunity", new Guid(OpportunityId), new ColumnSet("niq_mainquoteid", "niq_amendedfromopportunity", "niq_assetconfigidinput"));
        }

        public List<Entity> getProducts(Entity MainQuote, bool isCurrent)
        {
            Guid PriceListId = getPriceListId(MainQuote, service);
            QueryExpression query = new QueryExpression("quotedetail")
            {
                ColumnSet = new ColumnSet(true)
            };
            query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, MainQuote.Id);
            query.Criteria.AddCondition("quantity", ConditionOperator.GreaterThan, 0);
            query.Criteria.AddCondition("extendedamount", ConditionOperator.NotEqual, 0);
            query.Criteria.AddCondition("niq_isrevshareline", ConditionOperator.Equal, false);
            //if (!isCurrent)
            //    query.Criteria.AddCondition("niq_lineitemenddate", ConditionOperator.GreaterThan, DateTime.Now);
            LinkEntity productPriceLink = new LinkEntity("quotedetail", "productpricelevel", "productid", "productid", JoinOperator.Inner);
            productPriceLink.LinkCriteria.AddCondition("pricelevelid", ConditionOperator.Equal, PriceListId);
            productPriceLink.LinkCriteria.AddCondition("niq_glaccountnumber", ConditionOperator.BeginsWith, "0006");
            // Attach Link Entity to Query
            query.LinkEntities.Add(productPriceLink);
            return service.RetrieveMultiple(query).Entities.ToList();

        }

        public List<Entity> getManualSapDeferredProducts(Entity mainQuote)
        {
            var query = new QueryExpression("quotedetail")
            {
                ColumnSet = new ColumnSet("quotedetailid", "niq_sapdeferredrelatedproduct", "niq_elassetid"), // only what we need
                Criteria =
        {
            Conditions =
            {
                new ConditionExpression("quoteid", ConditionOperator.Equal, mainQuote.Id),
                new ConditionExpression("quantity", ConditionOperator.GreaterThan, 0),
                new ConditionExpression("niq_isrevshareline", ConditionOperator.Equal, false),
                new ConditionExpression("niq_ismanualreconflag", ConditionOperator.Equal, true)
            }
        }
            };

            return service.RetrieveMultiple(query).Entities.ToList();
        }


        public static Guid getPriceListId(Entity MainQuote, IOrganizationService service)
        {
            string fetchXMl = $@"<fetch top='1'>
	                            <entity name='pricelevel'>
		                            <attribute name='pricelevelid' />
		                            <filter type='and'>
			                            <condition attribute='niq_salesorg' operator='eq' value='{MainQuote.GetAttributeValue<EntityReference>("niq_salesorgid").Id}' />
		                            </filter>
	                            </entity>
                            </fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchXMl)).Entities.First().Id;
        }

        public List<Entity> getPriceChangedProducts(List<Entity> parentqQuoteProducts, List<Entity> currentQuoteProducts)
        {
            List<Entity> modifiedProducts = new List<Entity>();
            foreach (Entity newProduct in currentQuoteProducts)
            {
                var newProductId = newProduct.GetAttributeValue<EntityReference>("productid")?.Id;
                var newAmount = newProduct.GetAttributeValue<Money>("extendedamount")?.Value ?? 0m;
                DateTime newProductEndDate = newProduct.GetAttributeValue<DateTime>("niq_lineitemenddate");
                var newTermLength = newProduct.GetAttributeValue<double>("niq_termlength");
                var newELAssetID = newProduct.GetAttributeValue<string>("niq_elassetid");
                if (newTermLength < 1)
                {
                    DateTime startDate = newProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                    if (newProductEndDate.Subtract(startDate).Days > 30)
                        newTermLength = newProductEndDate.Subtract(startDate).Days / 30;
                    else
                        newTermLength = 1;
                }
                decimal newRate = Math.Round(newAmount / Convert.ToDecimal(newTermLength), 2);
                var newContractProductName = newProduct.GetAttributeValue<string>("niq_contractproductname");
                var oldProducts = parentqQuoteProducts.Where(op => op.GetAttributeValue<EntityReference>("productid")?.Id == newProductId && op.GetAttributeValue<string>("niq_contractproductname") == newContractProductName && new Guid(op.GetAttributeValue<string>("niq_elassetid")) == new Guid(newELAssetID));
                foreach (var oldProduct in oldProducts)
                {
                    if (oldProduct != null)
                    {
                        var oldAmount = oldProduct.GetAttributeValue<Money>("extendedamount")?.Value ?? 0m;
                        var oldTermLength = oldProduct.GetAttributeValue<double>("niq_termlength");
                        var oldELAssetID = oldProduct.GetAttributeValue<string>("niq_elassetid");
                        var oldContractProductName = oldProduct.GetAttributeValue<string>("niq_contractproductname");
                        DateTime oldProductEndDate = oldProduct.GetAttributeValue<DateTime>("niq_lineitemenddate");
                        if (oldTermLength < 1)
                        {
                            DateTime startDate = oldProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                            if (oldProductEndDate.Subtract(startDate).Days > 30)
                                oldTermLength = oldProductEndDate.Subtract(startDate).Days / 30;
                            else
                                oldTermLength = 1;
                        }
                        decimal oldRate = Math.Round(oldAmount / Convert.ToDecimal(oldTermLength), 2);
                        tracing.Trace("NEW RATE: " + newRate);
                        tracing.Trace("NEW Term : " + newTermLength);
                        tracing.Trace("OLD RATE: " + oldRate);
                        tracing.Trace("Old Term : " + oldTermLength);
                        if (newRate != oldRate || newProductEndDate != oldProductEndDate)
                        {
                            modifiedProducts.Add(newProduct);
                        }
                    }
                }
            }
            return modifiedProducts;
        }

        public List<Entity> getRemovedProducts(List<Entity> OldOppQuoteProducts, List<Entity> NewOppQuoteProducts, string commaSeperatedConfigIds)
        {
            List<Entity> removedProducts = OldOppQuoteProducts.Where(OldQuoteProduct => !NewOppQuoteProducts.Any(NewQuoteProduct => NewQuoteProduct.GetAttributeValue<EntityReference>("productid")?.Id == OldQuoteProduct.GetAttributeValue<EntityReference>("productid")?.Id &&
                                                                        NewQuoteProduct.GetAttributeValue<string>("niq_contractproductname") == OldQuoteProduct.GetAttributeValue<string>("niq_contractproductname") &&
                                                                        NewQuoteProduct.GetAttributeValue<bool>("niq_isrevshareline") == false && OldQuoteProduct.GetAttributeValue<bool>("niq_isrevshareline") == false &&
                                                                        Guid.Parse(NewQuoteProduct.GetAttributeValue<string>("niq_elassetid")) == Guid.Parse(OldQuoteProduct.GetAttributeValue<string>("niq_elassetid")))).ToList();
            tracing.Trace("REMOVED PRODUCT COUNT: " + removedProducts.Count);
            foreach (Entity removedProduct in removedProducts)
            {
                tracing.Trace("SAP DEFERRED LINE Found for Removed Product:" + removedProduct.GetAttributeValue<string>("niq_contractproductname") + "Amount: " + removedProduct.GetAttributeValue<Money>("extendedamount").Value);
            }
            List<Entity> filteredRemovedProducts = new List<Entity>();
            string filter = string.Empty;
            if (removedProducts.Count > 0)
            {
                foreach (Entity product in removedProducts)
                {
                    filter += $@"<condition attribute='niq_correspondingquoteproduct' operator='eq' value='{product.Id}' />";
                }

                string fetchXMl = $@"<fetch>
	                        <entity name='niq_assetmaterial'>
		                        <attribute name='niq_assetmaterialid' />
		                        <attribute name='niq_assetconfig' />
		                        <attribute name='niq_assetconfigname' />
		                        <attribute name='niq_correspondingquoteproduct' />
                                <filter type = 'or'>
		                        {filter}
                                </filter>
	                        </entity>
                        </fetch>";
                tracing.Trace("FETCHXML: " + fetchXMl);
                var records = service.RetrieveMultiple(new FetchExpression(fetchXMl));
                tracing.Trace("FILTERED Materials COUNT: " + records.Entities.Count());
                tracing.Trace("Comma Seperated GUID: " + commaSeperatedConfigIds);
                foreach (Entity record in records.Entities)
                {
                    string assetConfigId = record.GetAttributeValue<EntityReference>("niq_assetconfig").Id.ToString();
                    Guid CorrespondingQP = record.GetAttributeValue<EntityReference>("niq_correspondingquoteproduct").Id;
                    tracing.Trace("Asset ID in Config : " + assetConfigId);
                    if (!string.IsNullOrEmpty(commaSeperatedConfigIds) && commaSeperatedConfigIds.Contains(assetConfigId))
                    {
                        filteredRemovedProducts.Add(OldOppQuoteProducts.Where(oldQuoteProduct => oldQuoteProduct.Id == CorrespondingQP).FirstOrDefault());
                    }
                }
            }

            tracing.Trace("FILTERED REMOVED PRODUCTS: " + filteredRemovedProducts.Count);
            return filteredRemovedProducts;
        }
        public Money getSchedulesAmount(IOrganizationService service, Guid quoteProductId, string contractStartDate)
        {
            string FetchXml = $@"<fetch>
	                            <entity name='niq_schedule'>
		                            <attribute name='niq_scheduleid' />
		                            <attribute name='niq_amount' />
		                            <filter type='and'>
			                            <condition attribute='niq_lineitemid' operator='eq' value='{quoteProductId}' />
			                            <condition attribute='niq_scheduletype' operator='eq' value='100000001' />
			                            <condition attribute='niq_scheduledate' operator='ge' value='{contractStartDate}' />
		                            </filter>
	                            </entity>
                            </fetch>";
            List<Entity> schedules = service.RetrieveMultiple(new FetchExpression(FetchXml)).Entities.ToList();
            decimal totalAmount = 0;
            if (schedules.Count > 0)
            {
                foreach (Entity schedule in schedules)
                {
                    if (schedule.Attributes.Contains("niq_amount") && schedule.GetAttributeValue<Money>("niq_amount") != null)
                    {
                        totalAmount += schedule.GetAttributeValue<Money>("niq_amount").Value;
                    }
                }
            }
            return new Money(totalAmount);
        }

        public void deleteExistingSAPDeferredProducts(Guid QuoteId)
        {
            QueryExpression query = new QueryExpression("quotedetail")
            {
                ColumnSet = new ColumnSet(true)
            };
            query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, QuoteId);
            query.Criteria.AddCondition("productname", ConditionOperator.Equal, "SAP Deferred Revenue reconciliation placeholder");
            List<Entity> sapDeferredProducts = service.RetrieveMultiple(query).Entities.ToList();
            if (sapDeferredProducts.Count() > 0)
            {
                foreach (Entity sapDeferredProduct in sapDeferredProducts)
                {
                    if ((sapDeferredProduct.GetAttributeValue<bool?>("niq_ismanualreconflag") ?? false) == false)
                    {
                        service.Delete(sapDeferredProduct.LogicalName, sapDeferredProduct.Id);
                    }
                }
            }
        }

        public static string GetdateinMMddyyyy(string date)
        {
            if (date != null && Convert.ToString(date).Trim().Length > 0)
                return Convert.ToDateTime(date).ToString("MM-dd-yyyy");
            return "";
        }

        public static DateTime getRejectiondate(IOrganizationService service, DateTime contractStartDate, Guid ProductId)
        {
            string fetchxml = $@"<fetch top='1'>
	                            <entity name='niq_schedule'>
		                            <attribute name='niq_scheduleid' />
		                            <attribute name='niq_scheduledate' />
		                            <filter type='and'>
			                            <condition attribute='niq_lineitemid' operator='eq' value='{ProductId}' />
			                            <condition attribute='niq_scheduledate' operator='ge' value='{GetdateinMMddyyyy(contractStartDate.ToString())}' />
			                            <condition attribute='niq_scheduletype' operator='eq' value='100000000' />
		                            </filter>
		                            <order attribute='niq_scheduledate' />
	                            </entity>
                            </fetch>";
            Entity schedule = service.RetrieveMultiple(new FetchExpression(fetchxml)).Entities.ToList().FirstOrDefault();
            DateTime scheduleDate = schedule.GetAttributeValue<DateTime>("niq_scheduledate");
            return scheduleDate.AddDays(-1);
        }

        public Money getModifiedAmount(Entity currentProduct, Entity OriginalProduct, IOrganizationService service)
        {
            var newAmount = currentProduct.GetAttributeValue<Money>("extendedamount")?.Value ?? 0m;
            var newTermLength = currentProduct.GetAttributeValue<double>("niq_termlength");
            DateTime newStartDate = currentProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
            DateTime newEndDate = currentProduct.GetAttributeValue<DateTime>("niq_lineitemenddate");
            var newELAssetID = currentProduct.GetAttributeValue<string>("niq_elassetid");
            var newContractProductName = currentProduct.GetAttributeValue<string>("niq_contractproductname");
            var oldELAssetID = OriginalProduct.GetAttributeValue<string>("niq_elassetid");
            var oldContractProductName = OriginalProduct.GetAttributeValue<string>("niq_contractproductname");

            if (newTermLength < 1)
            {

                if (newEndDate.Subtract(newStartDate).Days > 30)
                    newTermLength = newEndDate.Subtract(newStartDate).Days / 30;
                else
                    newTermLength = 1;
            }
            decimal newRate = Math.Round(newAmount / Convert.ToDecimal(newTermLength), 2);
            var oldAmount = OriginalProduct.GetAttributeValue<Money>("extendedamount")?.Value ?? 0m;
            var oldTermLength = OriginalProduct.GetAttributeValue<double>("niq_termlength");
            DateTime oldStartDate = OriginalProduct.GetAttributeValue<DateTime>("niq_lineitemstartdate");
            DateTime oldEndDate = OriginalProduct.GetAttributeValue<DateTime>("niq_lineitemenddate");
            if (oldTermLength < 1)
            {

                if (oldEndDate.Subtract(oldStartDate).Days > 30)
                    oldTermLength = oldEndDate.Subtract(oldStartDate).Days / 30;
                else
                    oldTermLength = 1;
            }
            decimal oldRate = Math.Round(oldAmount / Convert.ToDecimal(oldTermLength), 2);
            decimal sapDeferredAmount = 0;
            tracing.Trace("New EL Asset ID: " + new Guid(newELAssetID));
            tracing.Trace("Old EL Asset ID: " + new Guid(oldELAssetID));
            tracing.Trace("New Product ID: " + currentProduct.Id);
            tracing.Trace("Old Product ID: " + OriginalProduct.Id);
            tracing.Trace("New ContractProcutName: " + newContractProductName);
            tracing.Trace("Old ContractProcutName: " + oldContractProductName);
            tracing.Trace("CONTRACT START DATE: " + newStartDate.ToString());
            tracing.Trace("Original QP ID: " + OriginalProduct.Id);
            tracing.Trace("Current QP ID: " + currentProduct.Id);
            Money totalAmountBeforeAmendedOpp = getSchedulesAmountforProduct(service, OriginalProduct.Id, newStartDate.ToString(), "lt");
            tracing.Trace("Amount before amendment : " + totalAmountBeforeAmendedOpp.Value.ToString());
            Money totalAmountAfterAmendedOpp = getSchedulesAmountforProduct(service, currentProduct.Id, newStartDate.ToString(), "ge");
            tracing.Trace("AMOUNT AFTER AMENDMENT : " + totalAmountAfterAmendedOpp.Value.ToString());
            Money OriginalExtendedAmount = OriginalProduct.GetAttributeValue<Money>("extendedamount");
            tracing.Trace("ORIGNIAL EXTENDDED AMOUTN: " + OriginalExtendedAmount.Value.ToString());
            sapDeferredAmount = Math.Round(totalAmountBeforeAmendedOpp.Value, 2) + Math.Round(totalAmountAfterAmendedOpp.Value, 2) - Math.Round(OriginalExtendedAmount.Value, 2);
            tracing.Trace("SAP DEFERRED REVENEUE: " + sapDeferredAmount.ToString());
            return new Money(sapDeferredAmount);
        }
        public Money getSchedulesAmountforProduct(IOrganizationService service, Guid quoteProductId, string contractStartDate, string condition)
        {
            string FetchXml = $@"<fetch>
	                            <entity name='niq_schedule'>
		                            <attribute name='niq_scheduleid' />
		                            <attribute name='niq_amount' />
		                            <filter type='and'>
			                            <condition attribute='niq_lineitemid' operator='eq' value='{quoteProductId}' />
			                            <condition attribute='niq_scheduletype' operator='in'>
                                            <value>100000001</value>
                                            <value>100000002</value>
                                          </condition>
			                            <condition attribute='niq_scheduledate' operator='{condition}' value='{contractStartDate}' />
		                            </filter>
	                            </entity>
                            </fetch>";
            tracing.Trace("FETCH: " + FetchXml);
            List<Entity> schedules = service.RetrieveMultiple(new FetchExpression(FetchXml)).Entities.ToList();
            tracing.Trace("SCHEDULE COUNT FOR " + quoteProductId + " " + schedules.Count);
            decimal totalAmount = 0;
            if (schedules.Count > 0)
            {
                foreach (Entity schedule in schedules)
                {
                    if (schedule.Attributes.Contains("niq_amount") && schedule.GetAttributeValue<Money>("niq_amount") != null)
                    {
                        totalAmount += schedule.GetAttributeValue<Money>("niq_amount").Value;
                    }
                }
            }
            return new Money(totalAmount);
        }
    }
}