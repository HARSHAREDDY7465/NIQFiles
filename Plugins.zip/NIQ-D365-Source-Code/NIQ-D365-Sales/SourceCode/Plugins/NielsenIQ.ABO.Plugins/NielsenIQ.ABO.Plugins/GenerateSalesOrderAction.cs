﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;

namespace NielsenIQ.ABO.Plugins
{
    public class GenerateSalesOrderAction : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = factory.CreateOrganizationService(context.UserId);
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            tracing.Trace("START");
            try
            {
                string opportunityId = (string)context.InputParameters["OpportunityId"];
                tracing.Trace($@"opportunityId: {opportunityId}");
                Entity OppEntity = service.Retrieve("opportunity", new Guid(opportunityId), new ColumnSet("niq_mainquoteid", "statecode"));
                OptionSetValue Oppstatus = OppEntity.GetAttributeValue<OptionSetValue>("statecode");
                Entity quoteEntity = service.Retrieve("quote", OppEntity.GetAttributeValue<EntityReference>("niq_mainquoteid").Id, new ColumnSet("statecode"));
                OptionSetValue quoteStatus = quoteEntity.GetAttributeValue<OptionSetValue>("statecode");
                if (quoteStatus.Value == 2 && Oppstatus.Value == 1)
                {

                    string fetchXML = $@"<fetch>
	                                    <entity name='salesorder'>
		                                    <filter type='and'>
			                                    <condition attribute='opportunityid' operator='eq' value='{opportunityId}' />
		                                    </filter>
                                            <order attribute='createdon' descending='true' />
	                                    </entity>
                                    </fetch>";
                    List<Entity> salesOrders = service.RetrieveMultiple(new FetchExpression(fetchXML)).Entities.ToList();
                    if(salesOrders.Count > 0)
                    {
                        Guid salesOrderId = salesOrders.First().Id;
                        tracing.Trace($@"Sales Order already exists with ID: {salesOrderId}"); 
                        context.OutputParameters["IsSuccess"] = true;
                        context.OutputParameters["ErrorMessage"] = "";
                        context.OutputParameters["SalesOrderId"] = salesOrderId;
                    }
                    else
                    {
                        Guid salesOrderId = CreateSalesOrder(service, quoteEntity.Id, tracing);
                        tracing.Trace($@"Sales Order created with ID: {salesOrderId}");
                        context.OutputParameters["IsSuccess"] = true;
                        context.OutputParameters["ErrorMessage"] = "";
                        context.OutputParameters["SalesOrderId"] = salesOrderId;
                    }                        
                }
                else
                {
                    tracing.Trace($@"Opportunity and Quote must be closed won state. Opportunity state: {OppEntity.FormattedValues["statecode"]} and Quote state: {quoteEntity.FormattedValues["statecode"]}");
                    context.OutputParameters["IsSuccess"] = false;
                    context.OutputParameters["ErrorMessage"] = "Opportunity and Main quote must be in Closed Won state for creating a Sales Order.";
                }
            }
            catch (Exception ex)
            {
                context.OutputParameters["IsSuccess"] = false;
                context.OutputParameters["ErrorMessage"] = ex.Message;
                context.OutputParameters["SalesOrderId"] = "";
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        /// <summary>
        ///     Create Sales Order for quote
        /// </summary>
        /// <param name="service">Organization Service</param>
        /// <param name="MainQuoteId"> Main Quote ID</param>
        /// <param name="tracing">Tracing Service</param>
        /// <returns></returns>
        private Guid CreateSalesOrder(IOrganizationService service, Guid MainQuoteId, ITracingService tracing)
        {
            ConvertQuoteToSalesOrderRequest request = new ConvertQuoteToSalesOrderRequest
            {
                QuoteId = MainQuoteId,
                ColumnSet = new ColumnSet(true)
            };
            var response = (ConvertQuoteToSalesOrderResponse)service.Execute(request);
            tracing.Trace($"Order created successfully with ID: {response.Entity.Id}");
            return response.Entity.Id;
        }
    }
}
