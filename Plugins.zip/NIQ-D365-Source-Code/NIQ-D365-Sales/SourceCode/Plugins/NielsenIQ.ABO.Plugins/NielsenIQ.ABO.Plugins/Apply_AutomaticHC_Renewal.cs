﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NielsenIQ.ABO.Plugins
{
    public class Apply_AutomaticHC_Renewal : IPlugin
    {
        private const string OpportunityIdField = "opportunityid";
        private const string NIQCloseProbabilityField = "niq_closeprobability";
        private const string NIQIsCloneFormField = "niq_iscloneform";
        private const string NIQCloneOpportunityField = "niq_cloneopportunity";
        private const string NIQAmendedFromOpportunityField = "niq_amendedfromopportunity";
        private const string NIQCOLAField = "niq_cola";
        private const string NIQProductEnhancementField = "niq_productenhancement";
        private const string NIQContractDecisionField = "niq_contractdecision";
        private const string NIQAutomatedOpportunityField = "niq_automatedopportunity";
        private const string NIQAssetConfigIdField = "niq_assetconfigidinput";
        private const string NIQOpportunityTypeField = "niq_opportunitytype";
        private const string NIQEffectiveDateField = "niq_effectivedate";
        private const string NIQCreatedOnField = "createdon";
        private const string NIQCreatedByField = "createdby";
        private const string NIQModifiedByField = "modifiedby";
        private const string NIQStageField = "niq_stage";
        private const string NIQMainQuoteField = "niq_mainquoteid";
        private const string NIQModifiedOnField = "modifiedon";
        private const string NIQStateCodeField = "statecode";
        private const string NIQStatusCodeField = "statuscode";
        private const string NIQOpportunityNumberField = "niq_opportunitynumber";
        private const string NIQSapError = "niq_saperror";
        private const string NIQSapErrorText = "niq_saperrortext";
        private const string NIQSapContractFlowurl = "niq_sapcontractpaflowurl";
        private const string NIQSapIntegrationStatus = "niq_sapintegrationstatus";
        private const string NIQSapSalesDocumentId = "niq_sapsalesdocumentid";
        private const string NIQApprovalStatus = "niq_approvalstatus";
        public static string NIQLeadId = "niq_leadid";
        public static string NIQOriginatingLead = "originatingleadid";
        public static string NIQCustomerponumber = "niq_customerponumber";
        public static string NIQCustomerpodate = "niq_customerpodate";
        private const string NIQPODocumentationUrl = "niq_podocumentationurl";
        private const string NIQTempUrl = "niq_tempeoaurl";
        private const string NIQFinallyExecutedUrl = "niq_finallyexecutedagreementurl";
        public void Execute(IServiceProvider serviceProvider)
        {
            // Fetching services from the serviceProvider
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = factory.CreateOrganizationService(context.UserId);
            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            tracing.Trace("Plugin execution started.");

            // Try to get the input parameters
            if (TryGetInputParameters(context, out var opportunityIds))
            {
                var originalOpportunity = service.Retrieve("opportunity", new Guid(opportunityIds), new ColumnSet(true));
                if (originalOpportunity != null)
                {
                    tracing.Trace("Original Opportunity retrieved successfully.");
                    //DYNCRM-28063 mapping assetconfiginputid field on renewal opportunity
                    string commaSeperatedGuids = getcommaSeperatedAssetConfigIds(service, originalOpportunity.Id.ToString());
                    // Create a cloned opportunity
                    var clonedOpportunityId = CreateClonedOpportunity(originalOpportunity, Guid.Empty, true, tracing, service, context);
                    tracing.Trace($"Cloned Opportunity ID: {clonedOpportunityId}");

                    // Update the cloned opportunity with additional values
                    UpdateClonedOpportunity(service, originalOpportunity, clonedOpportunityId, tracing, commaSeperatedGuids);

                    string fetchquery = string.Format(@"<fetch>
	                <!-- Table -->
	<entity name='opportunity'>
		<!-- Columns -->
		<attribute name='opportunityid' />
		<attribute name='accountid' />
        <attribute name='ownerid' />
		<attribute name='accountidname' />
		<attribute name='msdyn_accountmanagerid' />
		<attribute name='msdyn_accountmanageridname' />
		<attribute name='parentaccountid' />
		<attribute name='parentaccountidname' />
		<attribute name='niq_amendedfromopportunity' />
		<attribute name='niq_amendedfromopportunityname' />
		<attribute name='niq_automaticrenewalenddate' />
		<attribute name='niq_automaticrenewalstartdate' />
		<attribute name='niq_billtoparty' />
		<attribute name='niq_billtopartyname' />
		<attribute name='niq_billtopartypreviousvalue' />
		<attribute name='niq_billtopartypreviousvaluename' />
		<attribute name='niq_cloneopportunity' />
		<attribute name='niq_cloneopportunityname' />
		<attribute name='niq_competitor1' />
		<attribute name='niq_competitor1name' />
		<attribute name='niq_competitor2' />
		<attribute name='niq_competitor2name' />
		<attribute name='niq_competitor3' />
		<attribute name='niq_competitor3name' />
		<attribute name='niq_competitor4' />
		<attribute name='niq_competitor4name' />
		<attribute name='niq_competitor5' />
		<attribute name='niq_competitor5name' />
		<attribute name='niq_competitor6' />
		<attribute name='niq_competitor6name' />
		<attribute name='niq_contractenddate' />
		<attribute name='niq_contractstartdate' />
		<attribute name='msdyn_contractorganizationalunitid' />
		<attribute name='msdyn_contractorganizationalunitidname' />
		<attribute name='createdby' />
		<attribute name='createdbyname' />
		<attribute name='createdonbehalfby' />
		<attribute name='createdonbehalfbyname' />
		<attribute name='niq_createdinsalesforceby' />
		<attribute name='niq_createdinsalesforcebyname' />
		<attribute name='transactioncurrencyid' />
		<attribute name='transactioncurrencyidname' />
		<attribute name='niq_customeraccountpreviousvalue' />
		<attribute name='niq_customeraccountpreviousvaluename' />
		<attribute name='niq_deliverytoparty' />
		<attribute name='niq_deliverytopartyname' />
		<attribute name='niq_delivertopartypreviousvalue' />
		<attribute name='niq_delivertopartypreviousvaluename' />
		<attribute name='niq_fieldingcountry' />
		<attribute name='niq_fieldingcountryname' />
		<attribute name='niq_hostopportunity' />
		<attribute name='niq_hostopportunityname' />
		<attribute name='niq_hostingopportunity' />
		<attribute name='niq_hostingopportunityname' />
		<attribute name='niq_internalinitiative' />
		<attribute name='niq_internalinitiativename' />
		<attribute name='parentcontactid' />
		<attribute name='parentcontactidname' />
		<attribute name='niq_invoicerecipient2' />
		<attribute name='niq_invoicerecipient2name' />
		<attribute name='niq_invoicerecipient3' />
		<attribute name='niq_invoicerecipient3name' />
		<attribute name='niq_invoicerecipient4' />
		<attribute name='niq_invoicerecipient4name' />
		<attribute name='niq_invoicerecipient5' />
		<attribute name='niq_invoicerecipient5name' />
		<attribute name='msdynmkt_journeyid' />
		<attribute name='msdynmkt_journeyidname' />
		<attribute name='msdyn_opportunitykpiid' />
		<attribute name='msdyn_opportunitykpiidname' />
		<attribute name='niq_localcontributor' />
		<attribute name='niq_localcontributorname' />
		<attribute name='niq_mainquoteid' />
		<attribute name='niq_mainquoteidname' />
		<attribute name='modifiedby' />
		<attribute name='modifiedbyname' />
		<attribute name='modifiedonbehalfby' />
		<attribute name='modifiedonbehalfbyname' />
		<attribute name='niq_msacontract' />
		<attribute name='niq_msacontractname' />
		<attribute name='niq_accountgoalid' />
		<attribute name='niq_accountgoalidname' />
		<attribute name='niq_niqsigner' />
		<attribute name='niq_niqsignername' />
		<attribute name='name' />
		<attribute name='niq_opportunityownerpostclosure' />
		<attribute name='niq_opportunityownerpostclosurename' />
		<attribute name='niq_originalopportunityid' />
		<attribute name='niq_originalopportunityidname' />
		<attribute name='originatingleadid' />
		<attribute name='originatingleadidname' />
		<attribute name='msa_partnerid' />
		<attribute name='msa_partneridname' />
		<attribute name='msa_partneroppid' />
		<attribute name='msa_partneroppidname' />
		<attribute name='niq_postopportunity' />
		<attribute name='niq_postopportunityname' />
		<attribute name='msdyn_predictivescoreid' />
		<attribute name='msdyn_predictivescoreidname' />
		<attribute name='pricelevelid' />
		<attribute name='pricelevelidname' />
		<attribute name='niq_primarycontactid' />
		<attribute name='niq_primarycontactidname' />
		<attribute name='niq_salesgroupid' />
		<attribute name='niq_salesgroupidname' />
		<attribute name='niq_salesgroupsalesorgid' />
		<attribute name='niq_salesgroupsalesorgidname' />
		<attribute name='niq_salesorgid' />
		<attribute name='niq_salesorgidname' />
		<attribute name='niq_salesorgpreviousvalue' />
		<attribute name='niq_salesorgpreviousvaluename' />
		<attribute name='niq_sapsalesdocumentid' />
		<attribute name='msdyn_segmentid' />
		<attribute name='msdyn_segmentidname' />
		<attribute name='niq_soldtoparty' />
		<attribute name='niq_soldtopartyname' />
		<attribute name='niq_soldtopartypreviousvalue' />
		<attribute name='niq_soldtopartypreviousvaluename' />
		<attribute name='niq_ultimateoriginalopportunityid' />
		<attribute name='niq_ultimateoriginalopportunityidname' />
		<!-- Filter By -->
		<filter type='and'>
			<condition attribute='niq_hostopportunity' operator='eq' value='{0}' />
		</filter>
	</entity>
</fetch>", originalOpportunity.Id.ToString());
                    string childOpportunity = string.Empty;
                    EntityCollection opportunityRecord = service.RetrieveMultiple(new FetchExpression(fetchquery));
                    foreach (var opportunity in opportunityRecord.Entities)
                    {
                        Console.WriteLine("Name: {0}", opportunity.Attributes["opportunityid"]);
                        string commaSeperatedguids = getcommaSeperatedAssetConfigIds(service, opportunity.Id.ToString());
                        var clonedchildOpportunityId = CreateClonedOpportunity(opportunity, clonedOpportunityId, false, tracing, service, context);
                        tracing.Trace($"Cloned Opportunity ID: {clonedchildOpportunityId}");

                        // Update the cloned opportunity with additional values
                        UpdateClonedOpportunity(service, opportunity, clonedchildOpportunityId, tracing, commaSeperatedguids);
                        childOpportunity = childOpportunity.ToString() + "," + clonedchildOpportunityId.ToString();
                    }
                    string clonedOpp = clonedOpportunityId.ToString() + childOpportunity;
                    context.OutputParameters["ClonedOpportunity"] = clonedOpp;
                    tracing.Trace("Plugin executed successfully. Cloned opportunity created and updated.");
                }
                else
                {
                    tracing.Trace("Original opportunity not found.");
                }
            }
            else
            {
                tracing.Trace("Required input parameters missing.");
            }
        }

        private string getcommaSeperatedAssetConfigIds(IOrganizationService service, string originatingOpportunityId)
        {
            string fetchXml = $@"<fetch>
	                            <entity name='niq_assetconfig'>
		                            <attribute name='niq_assetconfigid' />
		                            <filter type='and'>
			                            <condition attribute='niq_originatingopportunity' operator='eq' value='{originatingOpportunityId}' />
		                            </filter>
	                            </entity>
                            </fetch>";
            List<Entity> entities = service.RetrieveMultiple(new FetchExpression(fetchXml)).Entities.ToList();
            return string.Join(",", entities.Select(e => e.Id.ToString()));
        }

        private bool TryGetInputParameters(IPluginExecutionContext context, out string opportunityIds)
        {
            opportunityIds = null;

            if (context.InputParameters.TryGetValue("OpportunityIds", out var opportunityIdsObj))
            {
                opportunityIds = (string)opportunityIdsObj;
                return true;
            }

            // Log if the parameters are not found
            return false;
        }

        /// <summary>
        /// Create Clone Opportunity
        /// </summary>
        /// <param name="originalOpportunity"></param>
        /// <param name="parentClonedOpportunityId"></param>
        /// <param name="isHost"></param>
        /// <param name="tracing"></param>
        /// <param name="service"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        private Guid CreateClonedOpportunity(Entity originalOpportunity, Guid parentClonedOpportunityId, bool isHost, ITracingService tracing, IOrganizationService service, IPluginExecutionContext context)
        {
            var account = originalOpportunity.GetAttributeValue<EntityReference>("parentaccountid");
            tracing.Trace($"Cloning opportunity for account: {account.Name}.");

            // Initialize a new cloned opportunity entity
            Entity clonedOpportunity = new Entity("opportunity");

            // Dynamically copy attributes, skipping irrelevant ones
            CopyOpportunityAttributes(originalOpportunity, clonedOpportunity, parentClonedOpportunityId, account, isHost, tracing, context, service);

            // Create the cloned opportunity in CRM
            var clonedOpportunityId = service.Create(clonedOpportunity);
            tracing.Trace($"Cloned opportunity created with ID: {clonedOpportunityId}");

            return clonedOpportunityId;
        }

        /// <summary>
        /// Create Clone Opportunity
        /// </summary>
        /// <param name="originalOpportunity"></param>
        /// <param name="clonedOpportunity"></param>
        /// <param name="account"></param>
        /// <param name="parentclonedOpportunityId"></param>
        /// <param name="isHost"></param>
        /// <param name="tracing"></param>
        private void CopyOpportunityAttributes(Entity originalOpportunity, Entity clonedOpportunity, Guid parentclonedOpportunityId, EntityReference account, bool isHost, ITracingService tracing, IPluginExecutionContext context, IOrganizationService service)
        {
            tracing.Trace("Copying attributes from the original opportunity to the cloned opportunity.");
            string salesOrgName = string.Empty;
            string hostOppName = string.Empty;
            if (!isHost && parentclonedOpportunityId != null)
            {
                EntityReference salesOrgref = (EntityReference)originalOpportunity.Attributes["niq_salesorgid"];
                salesOrgName = salesOrgref.Name;

                Entity parententity = service.Retrieve("opportunity", parentclonedOpportunityId, new ColumnSet(true));
                hostOppName = parententity.Attributes["name"].ToString();
            }
            Entity ultimateoriginalOpp = CommonFunctions.RetrieveUltimateOriginalOpportunityDetails(originalOpportunity, tracing, service);
            foreach (var attribute in originalOpportunity.Attributes)
            {
                if (attribute.Key != NIQApprovalStatus && attribute.Key != OpportunityIdField && attribute.Key != NIQCreatedOnField && attribute.Key != NIQEffectiveDateField && attribute.Key != NIQCreatedByField && attribute.Key != NIQModifiedByField && attribute.Key != NIQStageField && attribute.Key != NIQMainQuoteField && attribute.Key != NIQAmendedFromOpportunityField && attribute.Key != NIQIsCloneFormField && attribute.Key != NIQCloneOpportunityField && attribute.Key != NIQEffectiveDateField &&
                    attribute.Key != NIQProductEnhancementField && attribute.Key != NIQCOLAField && attribute.Key != NIQAutomatedOpportunityField && attribute.Key != NIQCloseProbabilityField && attribute.Key != NIQContractDecisionField && attribute.Key != NIQAssetConfigIdField && attribute.Key != NIQModifiedOnField && attribute.Key != NIQStateCodeField && attribute.Key != NIQStatusCodeField && attribute.Key != NIQOpportunityNumberField &&
                    attribute.Key != NIQSapError && attribute.Key != NIQSapErrorText && attribute.Key != NIQSapContractFlowurl && attribute.Key != NIQSapIntegrationStatus && attribute.Key != NIQSapSalesDocumentId && attribute.Key != NIQOpportunityTypeField && attribute.Key != NIQLeadId && attribute.Key != NIQOriginatingLead && attribute.Key != NIQCustomerpodate && attribute.Key != NIQCustomerponumber && attribute.Key != NIQFinallyExecutedUrl && attribute.Key != NIQTempUrl && attribute.Key != NIQPODocumentationUrl)
                {
                    // Handle specific fields with custom logic
                    tracing.Trace($"Setting attribute {attribute.Key}");
                    switch (attribute.Key)
                    {
                        case "name":
                            string opportunityname;
                            if (ultimateoriginalOpp != null && ultimateoriginalOpp.Contains("name") && ultimateoriginalOpp.TryGetAttributeValue<string>("name", out opportunityname))
                            {
                                clonedOpportunity["name"] = $"{opportunityname}_Renewal_{DateTime.Now:MMM dd yyyy}";
                            }
                            else
                                clonedOpportunity["name"] = isHost == true ? $"{account.Name}_Renewal_Host_{DateTime.Now:MMM dd yyyy}" : $"Child_" + salesOrgName + "#" + hostOppName;
                            tracing.Trace($"Setting Name field for cloned opportunity: {clonedOpportunity["name"]}");
                            break;

                        default:
                            // Default case for other attributes
                            if (attribute.Value is EntityReference lookupValue)
                            {
                                clonedOpportunity[attribute.Key] = new EntityReference(lookupValue.LogicalName, lookupValue.Id);
                                tracing.Trace($"Setting lookup field {attribute.Key} with reference {lookupValue.Id}");
                            }
                            else
                            {
                                clonedOpportunity[attribute.Key] = attribute.Value;
                                tracing.Trace($"Copying field {attribute.Key} with value {attribute.Value}");
                            }
                            break;
                    }
                }
            }
            DateTime startDate = originalOpportunity.GetAttributeValue<DateTime>("niq_contractstartdate");
            DateTime endDate = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate");
            TimeSpan difference = endDate - startDate;
            double totalDays = difference.TotalDays;
            clonedOpportunity["estimatedclosedate"] = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate").ToUniversalTime().AddDays(-30);
            clonedOpportunity["niq_contractstartdate"] = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate").ToUniversalTime().AddDays(1);
            clonedOpportunity["niq_automaticrenewalstartdate"] = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate").ToUniversalTime().AddDays(+1);
            clonedOpportunity["niq_contractenddate"] = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate").ToUniversalTime().AddDays(+1).AddDays(totalDays);
            clonedOpportunity["niq_automaticrenewalenddate"] = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate").ToUniversalTime().AddDays(+1).AddDays(totalDays);
            clonedOpportunity["niq_automaticrenewal"] = true;
            clonedOpportunity["ownerid"] = originalOpportunity.GetAttributeValue<EntityReference>("ownerid");
            clonedOpportunity["niq_opportunitytype"] = new OptionSetValue(1);
            clonedOpportunity["niq_existingcontractaction"] = new OptionSetValue(3);
            clonedOpportunity["niq_contractdecision"] = new OptionSetValue(100000002);
            clonedOpportunity["niq_existingsapsalesdocumentid"] = originalOpportunity.GetAttributeValue<string>("niq_sapsalesdocumentid");
            clonedOpportunity["niq_existingcontractexpirationdate"] = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate");
            clonedOpportunity["niq_amendedfromopportunity"] = new EntityReference("opportunity", originalOpportunity.Id);
            if (isHost == false)
            {
                clonedOpportunity["niq_hostopportunity"] = new EntityReference("opportunity", parentclonedOpportunityId);
            }
            clonedOpportunity["niq_cloneopportunity"] = originalOpportunity.ToEntityReference();

            clonedOpportunity["niq_iscloneform"] = true;
            tracing.Trace($"Setting NIQIsCloneFormField to true.");

            clonedOpportunity["niq_amendedfromopportunity"] = originalOpportunity.ToEntityReference();
            clonedOpportunity["niq_ultimateoriginalopportunityid"] = new EntityReference("opportunity", originalOpportunity.Id);
            //Code changes for DYNCRM-28652
            if (ultimateoriginalOpp != null)
                clonedOpportunity["niq_ultimateoriginalopportunityid"] = ultimateoriginalOpp.ToEntityReference();
           
        }

        /// <summary>
        /// Get latest EstimatedDate from selected assets configs
        /// </summary>
        /// <param name="assetIds"></param>
        /// <param name="service"></param>
        /// <param name="tracing"></param>
        public DateTime GetEstimatedDate(string assetIds, IOrganizationService service, ITracingService tracing)
        {
            tracing.Trace("est date");
            List<Guid> assetconfigIds = assetIds.Split(',').Select(id => new Guid(id.Trim())).ToList();
            List<DateTime> expirationDates = new List<DateTime>();
            foreach (Guid assetId in assetconfigIds)
            {
                QueryExpression query = new QueryExpression("niq_assetconfig")
                {
                    ColumnSet = new ColumnSet("niq_assetenddate"),
                    Criteria = { Conditions = { new ConditionExpression("niq_assetconfigid", ConditionOperator.Equal, assetId) } }
                };

                EntityCollection results = service.RetrieveMultiple(query);
                if (results.Entities.Count > 0 && results.Entities[0].Contains("niq_assetenddate"))
                {
                    expirationDates.Add((DateTime)results.Entities[0]["niq_assetenddate"]);
                }
            }
            tracing.Trace(expirationDates.Max().AddDays(-1).ToString());
            return expirationDates.Max();
        }

        /// <summary>
        /// Update the Opportunity record
        /// </summary>
        /// <param name="service"></param>
        /// <param name="originalOpportunity"></param>
        /// <param name="clonedOpportunityId"></param>
        /// <param name="tracing"></param>
        public void UpdateClonedOpportunity(IOrganizationService service, Entity originalOpportunity, Guid clonedOpportunityId, ITracingService tracing, string commaSeperatedGuids)
        {
            tracing.Trace($"Updating cloned opportunity (ID: {clonedOpportunityId}).");

            var updateClonedOpportunity = new Entity("opportunity", clonedOpportunityId)
            {
                ["niq_existingcontractexpirationdate"] = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate"),
                ["niq_opportunitytype"] = new OptionSetValue(2),
                ["niq_existingcontractaction"] = new OptionSetValue(1),
                ["niq_contractdecision"] = new OptionSetValue(100000002),
                ["niq_sapintegrationstatus"] = null,
                ["niq_amendedfromopportunity"] = new EntityReference("opportunity", originalOpportunity.Id),
                ["niq_assetconfigidinput"] = commaSeperatedGuids,
                 //Code changes for DYNCRM-28652
                ["niq_originalopportunityid"] = new EntityReference("opportunity", originalOpportunity.Id)
            };

            service.Update(updateClonedOpportunity);
            tracing.Trace("Cloned Opportunity values updated successfully.");
        }
    }
}