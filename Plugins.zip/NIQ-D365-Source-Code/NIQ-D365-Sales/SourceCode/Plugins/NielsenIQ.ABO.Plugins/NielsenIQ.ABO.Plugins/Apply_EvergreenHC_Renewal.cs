﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.ABO.Plugins.Model;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;

namespace NielsenIQ.ABO.Plugins
{
    public class Apply_EvergreenHC_Renewal : IPlugin
    {
        private const string OpportunityIdField = "opportunityid";
        private const string NIQCloseProbabilityField = "niq_closeprobability";
        private const string NIQIsCloneFormField = "niq_iscloneform";
        private const string NIQCloneOpportunityField = "niq_cloneopportunity";
        private const string NIQAmendedFromOpportunityField = "niq_amendedfromopportunity";
        private const string NIQCOLAField = "niq_cola";
        private const string NIQProductEnhancementField = "niq_productenhancement";
        private const string NIQContractDecisionField = "niq_contractdecision";
        private const string NIQAutomatedOpportunityField = "niq_automatedopportunity";
        private const string NIQAssetConfigIdField = "niq_assetconfigidinput";
        private const string NIQOpportunityTypeField = "niq_opportunitytype";
        private const string NIQEffectiveDateField = "niq_effectivedate";
        private const string NIQCreatedOnField = "createdon";
        private const string NIQCreatedByField = "createdby";
        private const string NIQModifiedByField = "modifiedby";
        private const string NIQStageField = "niq_stage";
        private const string NIQMainQuoteField = "niq_mainquoteid";
        private const string NIQModifiedOnField = "modifiedon";
        private const string NIQStateCodeField = "statecode";
        private const string NIQStatusCodeField = "statuscode";
        private const string NIQOpportunityNumberField = "niq_opportunitynumber";
        private const string NIQSapError = "niq_saperror";
        private const string NIQSapErrorText = "niq_saperrortext";
        private const string NIQSapContractFlowurl = "niq_sapcontractpaflowurl";
        private const string NIQSapIntegrationStatus = "niq_sapintegrationstatus";
        private const string NIQSapSalesDocumentId = "niq_sapsalesdocumentid";
        private const string NIQApprovalStatus = "niq_approvalstatus";
        public static string NIQLeadId = "niq_leadid";
        public static string NIQOriginatingLead = "originatingleadid";
        public void Execute(IServiceProvider serviceProvider)
        {
            // Fetching services from the serviceProvider
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = factory.CreateOrganizationService(context.UserId);
            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            try
            {
                tracing.Trace("Plugin execution started.");

                // Try to get the input parameters
                if (TryGetInputParameters(context, out var hostAssetConfigIds, out var childAssetConfigIds, out var opportunityId, out var termStartDate, out var termEndDate, out var evergreenIncrease, out var cola, out var pe))
                {
                    tracing.Trace($"Start Date: {termStartDate}");
                    tracing.Trace("childAssetConfigIds: " + childAssetConfigIds);
                    tracing.Trace("opportunityId: " + opportunityId);
                    tracing.Trace("hostAssetConfigIds: " + hostAssetConfigIds);

                    // Retrieve the original opportunity
                    var originalOpportunity = service.Retrieve("opportunity", new Guid(opportunityId), new ColumnSet(true));
                    Guid hostClonedOpp = Guid.NewGuid();
                    string allAssetIds = string.IsNullOrEmpty(hostAssetConfigIds) == false ? hostAssetConfigIds.ToString() + "," + childAssetConfigIds.ToString() : childAssetConfigIds.ToString();
                    if (hostAssetConfigIds == null)
                    {
                        hostAssetConfigIds = childAssetConfigIds;
                    }
                    if (originalOpportunity != null)
                    {
                        tracing.Trace("Original Opportunity retrieved successfully.");

                        // Create a cloned opportunity
                        var clonedOpportunityId = CreateClonedOpportunity(originalOpportunity, hostAssetConfigIds, termStartDate, termEndDate, evergreenIncrease, cola, pe, tracing, service, context, true, hostClonedOpp, allAssetIds);
                        hostClonedOpp = clonedOpportunityId;
                        tracing.Trace($"Cloned Opportunity ID: {clonedOpportunityId}");

                        // Update the cloned opportunity with additional values
                        UpdateClonedOpportunity(service, originalOpportunity, clonedOpportunityId, tracing);

                        // Set success output parameters
                        context.OutputParameters["IsSuccess"] = true;
                        context.OutputParameters["ClonedOpportunityId"] = clonedOpportunityId.ToString();
                        tracing.Trace("Plugin executed successfully. Cloned opportunity created and updated.");
                    }
                    else
                    {
                        tracing.Trace("Original opportunity not found.");
                    }

                    //creating child opportunities
                    string[] ids = childAssetConfigIds.Split(',');
                    HashSet<string> distinctChildOpportunityIds = new HashSet<string>();
                    for (int i = 0; i < ids.Length; i++)
                    {
                        Entity entity = service.Retrieve("niq_assetconfig", Guid.Parse(ids[i]), new ColumnSet(true));
                        EntityReference opportunityrLookup = (EntityReference)entity.Attributes["niq_originatingopportunity"];
                        string childOpportunityId = opportunityrLookup.Id.ToString();
                        if (!string.IsNullOrEmpty(childOpportunityId))
                        {
                            distinctChildOpportunityIds.Add(childOpportunityId);
                        }

                    }

                    List<string> distinctChildOpportunityIdList = distinctChildOpportunityIds.ToList();

                    foreach (string childOpportunityId in distinctChildOpportunityIdList)
                    {
                        var childOriginalOpportunity = service.Retrieve("opportunity", new Guid(childOpportunityId), new ColumnSet(true));
                        var clonedOpportunityId = CreateClonedOpportunity(childOriginalOpportunity, childAssetConfigIds, termStartDate, termEndDate, evergreenIncrease, cola, pe, tracing, service, context, false, hostClonedOpp, allAssetIds);
                        tracing.Trace($"Cloned Opportunity ID: {clonedOpportunityId}");

                        // Update the cloned opportunity with additional values
                        UpdateClonedOpportunity(service, childOriginalOpportunity, clonedOpportunityId, tracing);

                        // Set success output parameters
                        context.OutputParameters["IsSuccess"] = true;
                        context.OutputParameters["ClonedOpportunityId"] = clonedOpportunityId.ToString();
                    }

                }
                else
                {
                    tracing.Trace("Required input parameters missing.");
                }
            }
            catch (Exception ex)
            {
                tracing.Trace(ex.ToString());
            }
        }

        private bool TryGetInputParameters(IPluginExecutionContext context, out string hostAssetConfigIds, out string childAssetConfigIds, out string opportunityId, out string termStartDate, out string termEndDate, out decimal evergreenIncrease, out decimal cola, out decimal pe)
        {
            opportunityId = null;
            hostAssetConfigIds = null;
            childAssetConfigIds = null;
            termStartDate = null;
            termEndDate = null;
            cola = 0;
            pe = 0;
            evergreenIncrease = 0;

            if (context.InputParameters.TryGetValue("hostAssetConfigIds", out var hostAssetConfigIdsObj) &&
                context.InputParameters.TryGetValue("childAssetConfigIds", out var childAssetConfigIdsObj) &&
                context.InputParameters.TryGetValue("opportunityId", out var opportunityIdObj) &&
                context.InputParameters.TryGetValue("termStartDate", out var termStartDateObj) &&
                context.InputParameters.TryGetValue("termEndDate", out var termEndDateObj) &&
                context.InputParameters.TryGetValue("cola", out var colaObj) &&
                context.InputParameters.TryGetValue("pe", out var peObj) &&
                context.InputParameters.TryGetValue("evergreenIncrease", out var evergreenIncreaseObj))
            {
                hostAssetConfigIds = (string)hostAssetConfigIdsObj;
                childAssetConfigIds = (string)childAssetConfigIdsObj;
                opportunityId = (string)opportunityIdObj;
                termStartDate = (string)termStartDateObj;
                termEndDate = (string)termEndDateObj;
                cola = Decimal.Parse(string.IsNullOrEmpty(colaObj.ToString()) ? "0" : colaObj.ToString());
                pe = Decimal.Parse(string.IsNullOrEmpty(peObj.ToString()) ? "0" : peObj.ToString());
                evergreenIncrease = Decimal.Parse(string.IsNullOrEmpty(evergreenIncreaseObj.ToString()) ? "0" : evergreenIncreaseObj.ToString());
                return true;
            }

            // Log if the parameters are not found
            return false;
        }

        /// <summary>
        /// Create Clone Opportunity
        /// </summary>
        /// <param name="originalOpportunity"></param>
        /// <param name="assetConfigIds"></param>
        /// <param name="termStartdate"></param>
        /// <param name="termEnddate"></param>
        /// <param name="evergreenIncrease"></param>
        /// <param name="cola"></param>
        /// <param name="pe"></param>
        /// <param name="tracing"></param>
        /// <param name="service"></param>
        /// <param name="context"></param>
        /// <param name="isHost"></param>
        /// <param name="hostOppId"></param>
        /// <param name="allAssetIds"></param>
        /// <returns></returns>
        private Guid CreateClonedOpportunity(Entity originalOpportunity, string assetConfigIds, string termStartdate, string termEnddate, decimal evergreenIncrease, decimal cola, decimal pe, ITracingService tracing, IOrganizationService service, IPluginExecutionContext context, bool isHost, Guid hostOppId, string allAssetIds)
        {
            var account = originalOpportunity.GetAttributeValue<EntityReference>("parentaccountid");
            tracing.Trace($"Cloning opportunity for account: {account.Name}.");

            // Initialize a new cloned opportunity entity
            Entity clonedOpportunity = new Entity("opportunity");

            // Dynamically copy attributes, skipping irrelevant ones
            CopyOpportunityAttributes(originalOpportunity, clonedOpportunity, account, pe, cola, assetConfigIds, termStartdate, termEnddate, evergreenIncrease, tracing, context, service, isHost, hostOppId, allAssetIds);

            // Create the cloned opportunity in CRM
            var clonedOpportunityId = service.Create(clonedOpportunity);
            tracing.Trace($"Cloned opportunity created with ID: {clonedOpportunityId}");

            return clonedOpportunityId;
        }

        /// <summary>
        /// Create Clone Opportunity
        /// </summary>
        /// <param name="originalOpportunity"></param>
        /// <param name="clonedOpportunity"></param>
        /// <param name="account"></param>
        /// <param name="pe"></param>
        /// <param name="cola"></param>
        /// <param name="assetConfigIds"></param>
        /// <param name="assetConfigIds"></param>
        /// <param name="assetConfigIds"></param>
        /// <param name="tracing"></param>
        /// <param name="context"></param>
        /// <param name="service"></param>
        /// <param name="isHost"></param>
        /// <param name="hostOppId"></param>
        /// <param name="allAssetIds"></param>
        private void CopyOpportunityAttributes(Entity originalOpportunity, Entity clonedOpportunity, EntityReference account, decimal pe, decimal cola, string assetConfigIds, string termStartDate, string termEndDate, decimal evergreenIncrease, ITracingService tracing, IPluginExecutionContext context, IOrganizationService service, bool isHost, Guid hostOppId, string allAssetIds)
        {
            tracing.Trace("Copying attributes from the original opportunity to the cloned opportunity.");

            string salesOrgName = string.Empty;
            string hostOppName = string.Empty;
            if (!isHost)
            {
                EntityReference salesOrgref = (EntityReference)originalOpportunity.Attributes["niq_salesorgid"];
                salesOrgName = salesOrgref.Name;

                Entity parententity = service.Retrieve("opportunity", hostOppId, new ColumnSet(true));
                //EntityReference hostref = (EntityReference)parententity.Attributes["name"];
                hostOppName = parententity.Attributes["name"].ToString();
            }
            Entity ultimateoriginalOpp = CommonFunctions.RetrieveUltimateOriginalOpportunityDetails(originalOpportunity, tracing, service);
            foreach (var attribute in originalOpportunity.Attributes)
            {
                if (attribute.Key != NIQApprovalStatus && attribute.Key != OpportunityIdField && attribute.Key != NIQCreatedOnField && attribute.Key != NIQEffectiveDateField && attribute.Key != NIQCreatedByField && attribute.Key != NIQModifiedByField && attribute.Key != NIQStageField && attribute.Key != NIQMainQuoteField && attribute.Key != NIQAmendedFromOpportunityField && attribute.Key != NIQIsCloneFormField && attribute.Key != NIQCloneOpportunityField && attribute.Key != NIQEffectiveDateField &&
                    attribute.Key != NIQProductEnhancementField && attribute.Key != NIQCOLAField && attribute.Key != NIQAutomatedOpportunityField && attribute.Key != NIQCloseProbabilityField && attribute.Key != NIQContractDecisionField && attribute.Key != NIQAssetConfigIdField && attribute.Key != NIQModifiedOnField && attribute.Key != NIQStateCodeField && attribute.Key != NIQStatusCodeField && attribute.Key != NIQOpportunityNumberField &&
                    attribute.Key != NIQSapError && attribute.Key != NIQSapErrorText && attribute.Key != NIQSapContractFlowurl && attribute.Key != NIQSapIntegrationStatus && attribute.Key != NIQSapSalesDocumentId && attribute.Key != NIQOpportunityTypeField && attribute.Key != NIQLeadId && attribute.Key != NIQOriginatingLead)
                {
                    // Handle specific fields with custom logic
                    //tracing.Trace($"Setting attribute {attribute.Key}");

                    switch (attribute.Key)
                    {
                        case "name":
                            clonedOpportunity["name"] = isHost == true ? $"{account.Name}_ Renewal_Host_{DateTime.Now:dd/MM/yyyy}" : $"Child_" + salesOrgName + "# " + hostOppName;
                            tracing.Trace($"Setting Name field for cloned opportunity: {clonedOpportunity["name"]}");
                            break;

                        default:
                            // Default case for other attributes
                            if (attribute.Value is EntityReference lookupValue)
                            {
                                clonedOpportunity[attribute.Key] = new EntityReference(lookupValue.LogicalName, lookupValue.Id);
                                //tracing.Trace($"Setting lookup field {attribute.Key} with reference {lookupValue.Id}");
                            }
                            else
                            {
                                clonedOpportunity[attribute.Key] = attribute.Value;
                                //tracing.Trace($"Copying field {attribute.Key} with value {attribute.Value}");
                            }
                            break;
                    }
                }
            }

            DateTime estDate = GetEstimatedDate(allAssetIds, service);
            clonedOpportunity["niq_assetconfigidinput"] = assetConfigIds;
            clonedOpportunity["estimatedclosedate"] = estDate;
            clonedOpportunity["ownerid"] = new EntityReference("systemuser", context.UserId);
            clonedOpportunity["niq_opportunitytype"] = new OptionSetValue(1);
            clonedOpportunity["niq_existingcontractaction"] = new OptionSetValue(3);
            clonedOpportunity["niq_contractdecision"] = new OptionSetValue(100000002);
            clonedOpportunity["niq_existingsapsalesdocumentid"] = originalOpportunity.GetAttributeValue<string>("niq_sapsalesdocumentid");
            clonedOpportunity["niq_existingcontractexpirationdate"] = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate");
            //clonedOpportunity["niq_amendedfromopportunity"] = new EntityReference("opportunity", originalOpportunity.Id);
            clonedOpportunity["niq_cola"] = cola;
            clonedOpportunity["niq_evergreenincrease"] = evergreenIncrease;
            clonedOpportunity["niq_productenhancement"] = pe;
            clonedOpportunity["niq_automatedopportunity"] = true;
            if (isHost == false)
            {
                clonedOpportunity["niq_hostopportunity"] = new EntityReference("opportunity", hostOppId);
            }
            DateTime parsedStartDate = DateTime.Parse(termStartDate);
            DateTime utcStartDate = parsedStartDate.ToUniversalTime();
            DateTime startDateOnly = utcStartDate.Date;
            clonedOpportunity["niq_termstartdate"] = startDateOnly;
            clonedOpportunity["niq_contractstartdate"] = startDateOnly;

            DateTime parsedEndDate = DateTime.Parse(termEndDate);
            DateTime utcEndDate = parsedEndDate.ToUniversalTime();
            DateTime endDateOnly = utcEndDate.Date;
            clonedOpportunity["niq_termenddate"] = endDateOnly;
            clonedOpportunity["niq_contractenddate"] = endDateOnly;

            clonedOpportunity["niq_cloneopportunity"] = originalOpportunity.ToEntityReference();

            clonedOpportunity["niq_iscloneform"] = true;
            tracing.Trace($"Setting NIQIsCloneFormField to true.");

            clonedOpportunity["niq_amendedfromopportunity"] = originalOpportunity.ToEntityReference();
            //clonedOpportunity["niq_ultimateoriginalopportunityid"] = new EntityReference("opportunity", originalOpportunity.Id);
            if (ultimateoriginalOpp != null)
                clonedOpportunity["niq_ultimateoriginalopportunityid"] = ultimateoriginalOpp.ToEntityReference();
        }

        /// <summary>
        /// Get latest EstimatedDate from selected assets configs
        /// </summary>
        /// <param name="assetIds"></param>
        /// <param name="service"></param>
        public DateTime GetEstimatedDate(string assetIds, IOrganizationService service)
        {
            List<Guid> assetconfigIds = assetIds.Split(',').Select(id => new Guid(id.Trim())).ToList();
            List<DateTime> expirationDates = new List<DateTime>();
            foreach (Guid assetId in assetconfigIds)
            {
                QueryExpression query = new QueryExpression("niq_assetconfig")
                {
                    ColumnSet = new ColumnSet("niq_assetenddate"),
                    Criteria = { Conditions = { new ConditionExpression("niq_assetconfigid", ConditionOperator.Equal, assetId) } }
                };

                EntityCollection results = service.RetrieveMultiple(query);
                if (results.Entities.Count > 0 && results.Entities[0].Contains("niq_assetenddate"))
                {
                    expirationDates.Add((DateTime)results.Entities[0]["niq_assetenddate"]);
                }
            }
            return expirationDates.Max().AddDays(-30);
        }

        /// <summary>
        /// Update the Opportunity record
        /// </summary>
        /// <param name="service"></param>
        /// <param name="originalOpportunity"></param>
        /// <param name="clonedOpportunityId"></param>
        /// <param name="tracing"></param>
        public void UpdateClonedOpportunity(IOrganizationService service, Entity originalOpportunity, Guid clonedOpportunityId, ITracingService tracing)
        {
            tracing.Trace($"Updating cloned opportunity (ID: {clonedOpportunityId}).");

            var updateClonedOpportunity = new Entity("opportunity", clonedOpportunityId)
            {
                ["niq_existingcontractexpirationdate"] = originalOpportunity.GetAttributeValue<DateTime>("niq_contractenddate"),
                ["niq_opportunitytype"] = new OptionSetValue(2),
                ["niq_existingcontractaction"] = new OptionSetValue(3),
                ["niq_contractdecision"] = new OptionSetValue(100000002),
                ["niq_sapintegrationstatus"] = null,
                ["niq_sapsalesdocumentid"] = null,
                ["niq_amendedfromopportunity"] = originalOpportunity.ToEntityReference(),
                ["niq_originalopportunityid"] = originalOpportunity.ToEntityReference()
            };

            service.Update(updateClonedOpportunity);
            tracing.Trace("Cloned Opportunity values updated successfully.");
        }
    }
}