﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk.Messages;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_PriceListItems_Update_QuoteProducts : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                var multipleRequest = new ExecuteMultipleRequest()
                {
                    Settings = new ExecuteMultipleSettings()
                    {
                        ContinueOnError = false,
                        ReturnResponses = true
                    },
                    Requests = new OrganizationRequestCollection()
                };
                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity priceListItem = (Entity)context.InputParameters["Target"];
                    if (priceListItem != null && priceListItem.Id != Guid.Empty)
                    {
                        tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts: pricelistitem" + priceListItem.Id);
                        Entity retPriceListItems = service.Retrieve(priceListItem.LogicalName, priceListItem.Id, new ColumnSet("pricelevelid", "productid"));
                        if (retPriceListItems != null && retPriceListItems.Id != Guid.Empty && retPriceListItems.Attributes.Contains("productid") && retPriceListItems.Attributes.Contains("pricelevelid"))
                        {
                            tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts: retPricelistitem" + retPriceListItems.Id);
                            if (priceListItem.Attributes.Contains("niq_glaccountnumber"))
                            {
                                tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts: gl Account Number got updated");
                                string fetchGLAccXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='niq_glaccount'>
                                                            <attribute name='niq_glaccountid' />
                                                            <attribute name='niq_name' />
                                                            <order attribute='niq_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='niq_glaccountnumber' operator='eq' value='{0}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                                fetchGLAccXml = string.Format(fetchGLAccXml, priceListItem.GetAttributeValue<string>("niq_glaccountnumber"));
                                tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts: fetching gl Account with update gl account number ");
                                Entity glAccount = service.RetrieveMultiple(new FetchExpression(fetchGLAccXml)).Entities.FirstOrDefault();
                                if (glAccount != null && glAccount.Id != Guid.Empty)
                                {
                                    tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts:fetched gl account  " + glAccount.Id);
                                    UpdateQuoteProd(service, tracing, glAccount, retPriceListItems.GetAttributeValue<EntityReference>("productid").Id, retPriceListItems.GetAttributeValue<EntityReference>("pricelevelid").Id, multipleRequest);
                                }
                            }
                            if (priceListItem.Attributes.Contains("niq_profitcentrecode"))
                            {
                                tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts: profit centre got updated");
                                string fetchProfitCentreXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='niq_profitcentre'>
                                                                    <attribute name='niq_profitcentreid' />
                                                                    <attribute name='niq_name' />
                                                                    <order attribute='niq_name' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='niq_profitcentrecode' operator='eq' value='{0}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";
                                fetchProfitCentreXml = string.Format(fetchProfitCentreXml, priceListItem.GetAttributeValue<string>("niq_profitcentrecode"));
                                tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts: fetching Profit centre with updated profit centre code");
                                Entity profitCentre = service.RetrieveMultiple(new FetchExpression(fetchProfitCentreXml)).Entities.FirstOrDefault();
                                if (profitCentre != null && profitCentre.Id != Guid.Empty)
                                {
                                    tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts:fetched profit centre  " + profitCentre.Id);
                                    UpdateQuoteProd(service, tracing, profitCentre, retPriceListItems.GetAttributeValue<EntityReference>("productid").Id, retPriceListItems.GetAttributeValue<EntityReference>("pricelevelid").Id, multipleRequest);

                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private void UpdateQuoteProd(IOrganizationService service, ITracingService tracing, Entity recordObj, Guid productId, Guid priceLevelId, ExecuteMultipleRequest multipleRequest)
        {
            try
            {

                string fetchQuoteProdXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                              <entity name='quotedetail'>
                                                <attribute name='quotedetailname' />
                                                <attribute name='quotedetailid' />
                                                <order attribute='quotedetailname' descending='false' />
                                                <link-entity name='product' from='productid' to='productid' link-type='inner' alias='aa'>
                                                  <filter type='and'>
                                                    <condition attribute='productid' operator='eq' uitype='product' value='{0}' />
                                                  </filter>
                                                </link-entity>
                                                <link-entity name='quote' from='quoteid' to='quoteid' link-type='inner' alias='ab'>
                                                  <link-entity name='niq_salesorg' from='niq_salesorgid' to='niq_salesorgid' link-type='inner' alias='ac'>
                                                    <link-entity name='pricelevel' from='niq_salesorg' to='niq_salesorgid' link-type='inner' alias='ad'>
                                                      <filter type='and'>
                                                        <condition attribute='pricelevelid' operator='eq' uitype='pricelevel' value='{1}' />
                                                      </filter>
                                                    </link-entity>
                                                  </link-entity>
                                                </link-entity>
                                              </entity>
                                            </fetch>";
                fetchQuoteProdXml = string.Format(fetchQuoteProdXml, productId, priceLevelId);
                tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts:fetching Quote Products ");
                var quoteProducts = service.RetrieveMultiple(new FetchExpression(fetchQuoteProdXml));
                if (quoteProducts != null && quoteProducts.Entities != null && quoteProducts.Entities.Count > 0)
                {
                    tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts:fetched quote products count " + quoteProducts.Entities.Count);
                    bool update = false;
                    foreach (Entity quoteProd in quoteProducts.Entities)
                    {
                        if (quoteProd != null && quoteProd.Id != Guid.Empty)
                        {
                            tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts:fetched quote product " + quoteProd.Id);

                            UpdateRequest updateRequest = new UpdateRequest { Target = quoteProd };
                            tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts:record logical name  " + recordObj.LogicalName);
                            if (recordObj.LogicalName == "niq_profitcentre")
                            {
                                quoteProd["niq_profitcentreid"] = new EntityReference(recordObj.LogicalName, recordObj.Id);
                                update = true;
                            }
                            if (recordObj.LogicalName == "niq_glaccount")
                            {
                                quoteProd["niq_glaccountid"] = new EntityReference(recordObj.LogicalName, recordObj.Id);
                                update = true;
                            }
                            if (update)
                            {
                                tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts:adding quote Prod in multiple request");
                                multipleRequest.Requests.Add(updateRequest);
                                tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts:added success ");
                            }
                        }
                    }

                    if (update)
                    {
                        tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts:execution multipe req");
                        ExecuteMultipleResponse multipleResponse = (ExecuteMultipleResponse)service.Execute(multipleRequest);
                        tracing.Trace("OnUpdate_PriceListItems_Update_QuoteProducts:multiple request success");

                    }

                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
