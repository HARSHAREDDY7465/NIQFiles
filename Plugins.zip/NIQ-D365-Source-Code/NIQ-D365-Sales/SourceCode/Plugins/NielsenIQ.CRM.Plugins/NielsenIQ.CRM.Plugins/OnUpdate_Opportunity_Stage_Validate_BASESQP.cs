﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Opportunity_Stage_Validate_BASESQP : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            int totalQP = 0; int BASESQP = 0; int nonBASESQP = 0; int exceptionQP = 0;
            //Extract the tracing service for use in debugging sandboxed plug-ins.
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            try
            {
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_Opportunity_Stage_Validate_BASESQP: Getting the target entity from Input Parameters.");
                    Entity oppSales = (Entity)context.InputParameters["Target"];
                    tracing.Trace(oppSales.LogicalName);
                    Entity bpfObj = service.Retrieve(oppSales.LogicalName, oppSales.Id, new ColumnSet("activestageid", "bpf_opportunityid"));
                    Entity opportunity = service.Retrieve(bpfObj.GetAttributeValue<EntityReference>("bpf_opportunityid").LogicalName, bpfObj.GetAttributeValue<EntityReference>("bpf_opportunityid").Id, new ColumnSet("niq_mainquoteid", "niq_stage"));
                    if (opportunity != null && opportunity.GetAttributeValue<EntityReference>("niq_mainquoteid").Id != Guid.Empty && bpfObj.GetAttributeValue<EntityReference>("activestageid").Name.ToLower() == "proposal")
                    {
                        tracing.Trace(opportunity.GetAttributeValue<string>("niq_stage").ToLower());
                        QueryExpression query = new QueryExpression("quotedetail");
                        query.ColumnSet = new ColumnSet("quotedetailname", "niq_brandid");
                        query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, opportunity.GetAttributeValue<EntityReference>("niq_mainquoteid").Id);
                        LinkEntity linkentity = new LinkEntity();
                        linkentity.LinkToEntityName = "product";
                        linkentity.LinkFromEntityName = "quotedetail";
                        linkentity.LinkFromAttributeName = "niq_brandid";
                        linkentity.LinkToAttributeName = "productid";
                        linkentity.Columns = new ColumnSet("name");
                        linkentity.EntityAlias = "brand";
                        query.LinkEntities.Add(linkentity);
                        EntityCollection quoteProducts = service.RetrieveMultiple(query);
                        foreach (Entity QuoteProduct in quoteProducts.Entities)
                        {
                            totalQP++;
                            tracing.Trace(totalQP.ToString());
                            if (QuoteProduct.GetAttributeValue<EntityReference>("niq_brandid").Id != Guid.Empty && QuoteProduct.Attributes.Contains("niq_brandid"))
                            {
                                //Entity brand = service.Retrieve(QuoteProduct.GetAttributeValue<EntityReference>("niq_brandid").LogicalName, QuoteProduct.GetAttributeValue<EntityReference>("niq_brandid").Id, new ColumnSet("name"));
                                if (QuoteProduct.GetAttributeValue<string>("quotedetailname") == "BASES CLIENT FUNDS" || QuoteProduct.GetAttributeValue<string>("quotedetailname") == "Fund Usage" || QuoteProduct.GetAttributeValue<string>("quotedetailname") == "SAP Deferred Revenue reconciliation placeholder")
                                {
                                    exceptionQP++;
                                }
                                else if (QuoteProduct.GetAttributeValue<AliasedValue>("brand.name").Value.ToString().ToLower() == "bases" && QuoteProduct.GetAttributeValue<string>("quotedetailname") != "SAP Deferred Revenue reconciliation placeholder")
                                {
                                    BASESQP++;
                                }
                                else //
                                {
                                    nonBASESQP++;
                                }
                            }
                            tracing.Trace("Non-BASES " + nonBASESQP + " BASES " + BASESQP + " Exception QuoteProducts " + exceptionQP);
                            if (BASESQP > 0 && nonBASESQP > 0)
                            {
                                tracing.Trace("Inside IF");
                                throw new InvalidPluginExecutionException("BASES products cannot be included in opportunities with other non-BASES products. To move forward, remove the BASES products if this is not specifically a BASES opportunity.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}