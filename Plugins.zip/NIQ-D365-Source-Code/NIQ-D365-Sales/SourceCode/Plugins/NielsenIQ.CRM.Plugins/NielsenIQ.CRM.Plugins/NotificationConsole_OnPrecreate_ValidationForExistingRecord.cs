﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace NielsenIQ.CRM.Plugins
{
    public class NotificationConsole_OnPrecreate_ValidationForExistingRecord : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            tracingService.Trace("NotificationConsole_OnPrecreate_ValidationForExistingRecord plugin execution started.");

            try
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity entity = (Entity)context.InputParameters["Target"];

                    if (entity.LogicalName != "niq_notificationconsole")
                    {
                        tracingService.Trace("Plugin execution skipped - not targeting niq_notificationconsole entity.");
                        return;
                    }

                    if (entity.Attributes.Contains("niq_notificationdate") && entity["niq_notificationdate"] != null)
                    {
                        DateTime notificationDate = entity.GetAttributeValue<DateTime>("niq_notificationdate");

                        tracingService.Trace($"Notification date: {notificationDate}");

                        QueryExpression query = new QueryExpression("niq_notificationconsole")
                        {
                            ColumnSet = new ColumnSet("niq_notificationdate"),
                            Criteria = new FilterExpression
                            {
                                Conditions =
                                {
                                    new ConditionExpression("niq_notificationdate", ConditionOperator.Equal, notificationDate)
                                }
                            }
                        };

                        tracingService.Trace("Executing query to check for existing records.");

                        EntityCollection existingRecords = service.RetrieveMultiple(query);

                        if (existingRecords != null && existingRecords.Entities.Count > 0)
                        {
                            tracingService.Trace("Existing record found. Throwing exception.");
                            throw new InvalidPluginExecutionException("There is already a notification set to be sent on this notification date.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the exception details (if logging is configured) and throw a generic error message.

                throw new InvalidPluginExecutionException(ex.Message);

            }
        }
    }
}
