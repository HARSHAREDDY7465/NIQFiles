﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_OpportunityProduct_PricePerUnit : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_OpportunityProduct_PricePerUnit: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    if (context.MessageName == "Update")
                    {
                        Entity oppoObj = (Entity)context.InputParameters["Target"];
                        if (context.Depth > 2 || !oppoObj.Contains("priceperunit"))
                        {
                            return;
                        }
                        if (oppoObj != null && oppoObj.Id != Guid.Empty)
                        {

                            Decimal pricePerUnit = oppoObj.GetAttributeValue<Money>("priceperunit").Value;
                            if (pricePerUnit != 0)
                            {
                                return;
                            }
                            tracing.Trace("OnUpdate_OpportunityProduct_PricePerUnit: Checking the Contest message is update.");
                            Guid _opportunityId = (service.Retrieve(oppoObj.LogicalName, oppoObj.Id, new ColumnSet("opportunityid"))).GetAttributeValue<EntityReference>("opportunityid").Id; tracing.Trace("OnUpdate_OpportunityProduct_PricePerUnit: Checking Opportunity Main Quote Total Price.");
                            string fetchXmlQuote = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='quote'>
                                                        <attribute name='quoteid' />
                                                        <attribute name='totalamount' />
                                                        <order attribute='totalamount' descending='false' />
                                                        <filter type='and'>
                                                          <condition attribute='niq_mainquote' operator='eq' value='1' />
                                                          <condition attribute='opportunityid' operator='eq' value='{_opportunityId.ToString()}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";


                            Entity quoteObj = service.RetrieveMultiple(new FetchExpression(fetchXmlQuote)).Entities.FirstOrDefault();

                            if (quoteObj != null && quoteObj.Id != Guid.Empty)
                            {
                                tracing.Trace("OnUpdate_OpportunityProduct_PricePerUnit: Retrieved Quote Records -> ." + quoteObj.Id);
                                if (quoteObj.Contains("totalamount"))
                                {
                                    if (quoteObj.GetAttributeValue<Money>("totalamount").Value > 0)
                                    {
                                        throw new InvalidPluginExecutionException("Invalid Price Per Unit: this cannot be updated to Zero");
                                    }
                                }
                            }

                        }

                    }

                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}