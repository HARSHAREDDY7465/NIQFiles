﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using System.Text.RegularExpressions;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.Plugins.Helper;
using System.Xml;

namespace NielsenIQ.CRM.Plugins
{
    public class GiveBackupAccessToUser : IPlugin
    {

        private readonly string _secureString;
        private readonly string _unsecureString;

        public GiveBackupAccessToUser(string unsecureString)
        {
            if (String.IsNullOrWhiteSpace(unsecureString))
            {
                throw new InvalidPluginExecutionException("Unsecure and secure strings are required for this plugin to execute.");
            }

            //string ContactFullName = GetUnsecureConfigValue("UserId");
            _unsecureString = unsecureString;
            //_secureString = secureString;
        }
        public string GetUnsecureConfigValue(string doc, string key, ITracingService tracing)
        {
            const string XPATH = "Settings/setting[@name='{0}']";
            tracing.Trace("xpath: " + XPATH);
            string configVal = string.Empty;
            try
            {
                var xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(doc);
                var node = xmlDoc.SelectSingleNode(string.Format(XPATH, key));
                tracing.Trace("node: " + node);
                return node == null ? configVal : node.Attributes["value"].Value;
            }
            catch
            {
                return configVal;
            }
        }
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                tracing.Trace("context : " + context.MessageName);
                tracing.Trace("unsecured config: " + _unsecureString);
                string UserName = GetUnsecureConfigValue(_unsecureString, "UserName", tracing);
                IOrganizationService service1 = factory.CreateOrganizationService(context.UserId);
                tracing.Trace("impersonated user name: " + UserName);
                QueryExpression qe = new QueryExpression("systemuser");
                qe.Criteria.AddCondition("domainname", ConditionOperator.Equal, UserName);
                qe.Criteria.AddCondition("isdisabled", ConditionOperator.Equal, false);
                EntityCollection ec = service1.RetrieveMultiple(qe);
                if (ec == null || ec.Entities.Count == 0)
                    throw new InvalidPluginExecutionException("User not found for the username mentioned in configuration " + UserName);

                Guid UserGuid = ec.Entities[0].Id;
                tracing.Trace("UserGuid: " + UserGuid);
                IOrganizationService service = factory.CreateOrganizationService(UserGuid); //Impersonating user

                var OppOwner = "";
                var OppId = "";
                var OppUser = "";
                var LocalContri_User = "";
                var QuoteId = "";

                Entity oppTarget = new Entity();
                if (context.MessageName != "niq_GiveBackupAccessToUsersAction")
                {
                    Entity oppEntity = new Entity();
                    oppTarget = (Entity)context.InputParameters["Target"];
                    if (context.PostEntityImages.Contains("Image") && context.PostEntityImages["Image"] != null)
                    {
                        oppEntity = (Entity)context.PostEntityImages["Image"];
                    }
                    else
                    {
                        oppEntity = (Entity)context.InputParameters["Target"];
                    }
                    OppOwner = oppEntity.GetAttributeValue<EntityReference>("ownerid").Id.ToString();
                    OppId = oppEntity.Id.ToString();
                    OppUser = context.InitiatingUserId.ToString(); //trigger the plugin
                    LocalContri_User = oppEntity.Contains("niq_localcontributor") && oppEntity["niq_localcontributor"] != null ? oppEntity.GetAttributeValue<EntityReference>("niq_localcontributor").Id.ToString() : "";
                    // QuoteId = oppEntity.GetAttributeValue<EntityReference>("niq_mainquoteid").Id.ToString();
                    QuoteId = oppEntity.GetAttributeValue<EntityReference>("niq_mainquoteid")?.Id.ToString() ?? "";
                }
                //triggered by script
                else
                {
                    OppOwner = (string)context.InputParameters["OpportunityOwner"];
                    OppId = (string)context.InputParameters["OpportunityId"];
                    OppUser = (string)context.InputParameters["OpportunityUser"];
                    //LocalContri_User = (string)context.InputParameters["LocalContributorUser"];
                    QuoteId = (string)context.InputParameters["MainQuote"];
                }

                tracing.Trace("Quoteid is :" + QuoteId);
                tracing.Trace("Local id" + LocalContri_User);
                Entity enQuote = new Entity("quote");
                if (!string.IsNullOrEmpty(QuoteId))
                {
                    enQuote.Id = new Guid(QuoteId.ToString());
                    tracing.Trace($"Quote with ID: {enQuote.Id}");
                }

                Entity enopp = new Entity("opportunity");
                enopp.Id = new Guid(OppId.ToString());
                tracing.Trace($"Opportunity with ID: {enopp.Id}");
                Guid backup1userid = Guid.Empty;
                Guid backup2userid = Guid.Empty;
                Guid backup3userid = Guid.Empty;

                //Guid templateId = CommonHelper.GetTemplateId("Opportunity Sales Team Template", service);
                Guid templateId = Guid.Empty;
                Guid templateId1 = Guid.Empty;
                var responseConfigSettings = CommonHelper.GetConfigSettingsAccessTeamTemplate(service, tracing);
                if (responseConfigSettings.oppAccessTeam != null)
                {
                    templateId = CommonHelper.GetTemplateId(responseConfigSettings.oppAccessTeam, service);
                    tracing.Trace("template id opportunity " + templateId);
                }

                if (responseConfigSettings.quoteAccessTeam != null)
                {
                    tracing.Trace("retrieve quote team template id");
                    templateId1 = CommonHelper.GetTemplateId(responseConfigSettings.quoteAccessTeam, service);
                    tracing.Trace("template id quote  " + templateId1);
                }

                if (context.PreEntityImages.Contains("Image") && context.PreEntityImages["Image"] != null)
                {
                    Entity preImage = (Entity)context.PreEntityImages["Image"];
                    //if the opportunity teams, subgrid is empty don't try to remove the previous user from access
                    if (preImage.Contains("niq_localcontributor") && preImage["niq_localcontributor"] != null && preImage.GetAttributeValue<EntityReference>("niq_localcontributor").Id != preImage.GetAttributeValue<EntityReference>("ownerid").Id && !string.IsNullOrEmpty(QuoteId))
                    {
                        tracing.Trace("Removing previous local contributor: " + preImage.GetAttributeValue<EntityReference>("niq_localcontributor").Id);
                        tracing.Trace("niq_localcontributor: " + oppTarget.Contains("niq_localcontributor"));
                        tracing.Trace("main quote: " + oppTarget.Contains("niq_mainquoteid"));
                        if (oppTarget.Contains("niq_localcontributor"))
                        {
                            CommonHelper.RemoveUserToAccessTeam(enopp, preImage.GetAttributeValue<EntityReference>("niq_localcontributor").Id, templateId, tracing, service);
                            CommonHelper.RemoveUserToAccessTeam(enQuote, preImage.GetAttributeValue<EntityReference>("niq_localcontributor").Id, templateId1, tracing, service);

                        }
                        tracing.Trace("Previous local contributor removed successfully");
                    }
                }


                tracing.Trace("OpportunityOwner: " + OppOwner + "<\br> OpportunityId " + OppId + "\n OpportunityUser " + OppUser);
                QueryExpression DefaultSettingQE = new QueryExpression("niq_salesuserdefaultsettings");
                DefaultSettingQE.ColumnSet = new ColumnSet("niq_backupuser1", "niq_backupuser2", "niq_backupuser3");
                DefaultSettingQE.Criteria.AddCondition("niq_user", ConditionOperator.Equal, new Guid(OppOwner.ToString()));// new EntityReference("systemuser", new Guid(OppOwner.ToString())));
                                                                                                                           //priceListQuery.NoLock = true or false;
                EntityCollection ECOpportunities = service.RetrieveMultiple(DefaultSettingQE);
                if (ECOpportunities.Entities.Count > 0 && context.MessageName == "niq_GiveBackupAccessToUsersAction")
                {
                    tracing.Trace("ECOpportunities.Entities.Count " + ECOpportunities.Entities.Count);
                    Entity en = new Entity();
                    en = ECOpportunities.Entities[0];
                    backup1userid = (en.GetAttributeValue<EntityReference>("niq_backupuser1") != null) ? en.GetAttributeValue<EntityReference>("niq_backupuser1").Id : Guid.Empty;
                    tracing.Trace("en");
                    backup2userid = (en.GetAttributeValue<EntityReference>("niq_backupuser2") != null) ? en.GetAttributeValue<EntityReference>("niq_backupuser2").Id : Guid.Empty;
                    backup3userid = (en.GetAttributeValue<EntityReference>("niq_backupuser3") != null) ? en.GetAttributeValue<EntityReference>("niq_backupuser3").Id : Guid.Empty;

                    // using the Commonehelperclass method getting the template and assigning the user
                    tracing.Trace("backup1userid " + backup1userid + "\nbackup2userid" + backup2userid + "\nbackup3userid " + backup3userid);

                    tracing.Trace("temaplate id " + templateId);



                    if (backup1userid != Guid.Empty)
                    {
                        CommonHelper.AddUserToAccessTeam(enopp, backup1userid, templateId, tracing, service);
                        CommonHelper.AddUserToAccessTeam(enQuote, backup1userid, templateId1, tracing, service);
                    }
                    if (backup2userid != Guid.Empty)
                    {
                        CommonHelper.AddUserToAccessTeam(enopp, backup2userid, templateId, tracing, service);
                        CommonHelper.AddUserToAccessTeam(enQuote, backup2userid, templateId1, tracing, service);
                    }
                    if (backup3userid != Guid.Empty)
                    {
                        CommonHelper.AddUserToAccessTeam(enopp, backup3userid, templateId, tracing, service);
                        CommonHelper.AddUserToAccessTeam(enQuote, backup3userid, templateId1, tracing, service);
                    }
                }

                if (!string.IsNullOrEmpty(LocalContri_User) && context.MessageName != "niq_GiveBackupAccessToUsersAction")
                {
                    tracing.Trace("Processing local contributor user");
                    Guid localContributorId = new Guid(LocalContri_User);
                    if (LocalContri_User != OppOwner)
                    {
                        // Add the local contributor to the opportunity access team
                        CommonHelper.AddUserToAccessTeam(enopp, localContributorId, templateId, tracing, service);
                        tracing.Trace("Added local contributor with ID: " + localContributorId + " to Opp access teams");
                    }
                    if (LocalContri_User != OppOwner && !string.IsNullOrEmpty(QuoteId))
                    {
                        CommonHelper.AddUserToAccessTeam(enQuote, localContributorId, templateId1, tracing, service);
                        tracing.Trace("Added local contributor with ID: " + localContributorId + " to Quote access teams");
                    }

                }

                bool isbasesaccountrole = false;

                //get Opp details and check if bases opportunity
                Entity enOpportunity = service.Retrieve("opportunity", new Guid(OppId), new ColumnSet("niq_businessarea", "parentaccountid"));
                if (context.MessageName != "Update" && enOpportunity.Contains("niq_businessarea") && enOpportunity.GetAttributeValue<OptionSetValue>("niq_businessarea").Value == 100000000)
                {
                    tracing.Trace("isbases opportunity");
                    QueryExpression qeAR = new QueryExpression("niq_accountrole");
                    qeAR.ColumnSet = new ColumnSet("niq_user", "niq_role");

                    //using fetchxml
                    Guid acntid = enOpportunity.GetAttributeValue<EntityReference>("parentaccountid").Id;
                    tracing.Trace("acnt id: " + acntid);
                    string fetchQuery = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                        <entity name='niq_accountrole'>
                        <attribute name='niq_accountroleid' />
                        <attribute name='niq_name' />
                        <attribute name='createdon' />
                        <attribute name='niq_user' />
                        <attribute name='statecode' />
                        <attribute name='niq_role' />
                        <attribute name='niq_accountid' />
                        <filter type='and'>
                          <condition attribute='statecode' operator='eq' value='0' />
                          <condition attribute='niq_accountid' operator='eq' uitype='account' value='" + acntid + @"' />
                          <condition attribute='niq_role' operator='in'>
                            <value>100000003</value>
                            <value>100000004</value>
                            <value>100000005</value>
                            <value>100000006</value>
                            <value>100000007</value>
                            <value>100000008</value>
                            <value>100000009</value>
                            <value>100000010</value>
                          </condition>
                        </filter>
                        <link-entity name='systemuser' from='systemuserid' to='niq_user' link-type='inner' alias='ac'>
                          <filter type='and'>
                            <condition attribute='isdisabled' operator='eq' value='0' />
                          </filter>
                        </link-entity>
                      </entity>
                    </fetch>";
                    tracing.Trace("fetchxml: " + fetchQuery);

                    FetchExpression fetchEx = new FetchExpression(fetchQuery);
                    EntityCollection ecAccountRoles = service.RetrieveMultiple(fetchEx);
                    if (ecAccountRoles.Entities.Count > 0)
                    {
                        tracing.Trace("Account Roles found: " + ecAccountRoles.Entities.Count);
                        foreach (Entity enlocalAR in ecAccountRoles.Entities)
                        {
                            Guid acntroleuserid = (enlocalAR.GetAttributeValue<EntityReference>("niq_user") != null) ? enlocalAR.GetAttributeValue<EntityReference>("niq_user").Id : Guid.Empty;
                            if (acntroleuserid != Guid.Empty)
                            {
                                tracing.Trace("acntroleuserid: " + acntroleuserid);
                                CommonHelper.AddUserToAccessTeam(enopp, acntroleuserid, templateId, tracing, service);
                                CommonHelper.AddUserToAccessTeam(enQuote, acntroleuserid, templateId1, tracing, service);
                                tracing.Trace("added acntroleuserid: " + acntroleuserid);
                            }

                            if (acntroleuserid == new Guid(OppUser.ToString()))
                                isbasesaccountrole = true;
                        }
                    }
                }
                tracing.Trace("isbasesaccountrole: " + isbasesaccountrole.ToString());
                if (context.MessageName == "niq_GiveBackupAccessToUsersAction")
                {
                    //tracing.Trace("It's not a form save");
                    if ((new Guid(OppUser.ToString()) == backup1userid || new Guid(OppUser.ToString()) == backup2userid || new Guid(OppUser.ToString()) == backup3userid) || isbasesaccountrole == true)
                    {
                        tracing.Trace("OK Message");
                        //context.SetValue(Message, "OK new");
                        context.OutputParameters["Message"] = "Ok";
                    }
                    else
                    {
                        tracing.Trace("Not OK Message");
                        context.OutputParameters["Message"] = "Edit access was granted to backup users listed by the opportunity owner and to users with the account role (BASES opportunities only). Your name is not included in any list. Therefore, no additional access is provided";
                    }
                }
                else
                {
                    tracing.Trace("Successfully tiggered by updating local contributor or main quote");
                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("Msg" + ex.Message);
            }
        }
    }
}