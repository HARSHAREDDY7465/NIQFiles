﻿using System;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Collections.Generic;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_DocuSign_Quote_UpdateCLMPrimaryContact : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(null);

                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_DocuSign_Quote_UpdateCLMPrimaryContact: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity quote = (Entity)context.InputParameters["Target"];
                    if (quote != null && quote.Id != Guid.Empty)
                    {
                        Entity postImage = (Entity)context.PostEntityImages["Image"];
                        Entity updQuote = new Entity(quote.LogicalName, quote.Id);
                        bool update = false;
                        tracing.Trace("quote id->" + quote.Id);
                        tracing.Trace("quote.Attributes.Contains(niq_docusigncontactid)->" + quote.Attributes.Contains("niq_docusigncontactid"));
                        tracing.Trace("postImage.Attributes.Contains(niq_docusigncontactid)->" + postImage.Attributes.Contains("niq_docusigncontactid"));
                        tracing.Trace("postImage.Attributes.Contains(sales)->" + postImage.Attributes.Contains("niq_salesorgid"));
                        tracing.Trace("quote.Attributes.Contains(sales)->" + quote.Attributes.Contains("niq_salesorgid"));

                        if (quote.Attributes.Contains("niq_docusigncontactid") && postImage.Attributes.Contains("niq_docusigncontactid") && postImage.GetAttributeValue<EntityReference>("niq_docusigncontactid") != null && postImage.GetAttributeValue<EntityReference>("niq_docusigncontactid").Id != Guid.Empty)
                        {
                            Entity retContact = service.Retrieve(quote.GetAttributeValue<EntityReference>("niq_docusigncontactid").LogicalName, quote.GetAttributeValue<EntityReference>("niq_docusigncontactid").Id, new ColumnSet("fullname", "emailaddress1", "jobtitle"));
                            tracing.Trace("retcontact id->" + retContact.Id);
                            updQuote["niq_primarycontactname"] = retContact.Attributes.Contains("fullname") ? retContact.GetAttributeValue<string>("fullname") : null;
                            updQuote["niq_primarycontactemail"] = retContact.Attributes.Contains("emailaddress1") ? retContact.GetAttributeValue<string>("emailaddress1") : null;
                            updQuote["niq_primarycontacttitle"] = retContact.Attributes.Contains("jobtitle") ? retContact.GetAttributeValue<string>("jobtitle") : null;
                            update = true;
                        }
                        else if (!postImage.Attributes.Contains("niq_docusigncontactid") && quote.Attributes.Contains("niq_docusigncontactid"))
                        {
                            tracing.Trace("docusign contact null ");
                            updQuote["niq_primarycontactname"] = null;
                            updQuote["niq_primarycontactemail"] = null;
                            updQuote["niq_primarycontacttitle"] = null;
                            update = true;

                        }
                        if (quote.Attributes.Contains("niq_salesorgid") && postImage.Attributes.Contains("niq_salesorgid") && postImage.GetAttributeValue<EntityReference>("niq_salesorgid").Id != Guid.Empty)
                        {
                            tracing.Trace("sales org id id->" + postImage.GetAttributeValue<EntityReference>("niq_salesorgid").Id);
                            Guid salesOrgId = postImage.GetAttributeValue<EntityReference>("niq_salesorgid").Id;
                            QueryExpression salesOrgQuery = new QueryExpression("niq_salesorg");
                            salesOrgQuery.TopCount = 1;
                            salesOrgQuery.ColumnSet.AddColumns("niq_operatingcountryid");
                            salesOrgQuery.Criteria.AddCondition("niq_salesorgid", ConditionOperator.Equal, salesOrgId);
                            var salesOrgRecords = service.RetrieveMultiple(salesOrgQuery);
                            if (salesOrgRecords != null && salesOrgRecords.Entities != null && salesOrgRecords.Entities.Count > 0)
                            {
                                tracing.Trace("sales Org Count " + salesOrgRecords.Entities.Count);
                                foreach (Entity record in salesOrgRecords.Entities)
                                {
                                    if (record.Attributes.Contains("niq_operatingcountryid"))
                                    {
                                        Entity country = service.Retrieve(record.GetAttributeValue<EntityReference>("niq_operatingcountryid").LogicalName, record.GetAttributeValue<EntityReference>("niq_operatingcountryid").Id, new ColumnSet("niq_countrycode"));
                                        if (country != null && country.Id != Guid.Empty && country.Attributes.Contains("niq_countrycode"))
                                        {
                                            tracing.Trace("Country id ->" + country.Id);
                                            updQuote["niq_market"] = country.GetAttributeValue<string>("niq_countrycode");
                                            update = true;
                                            break;
                                        }
                                        else
                                        {
                                            tracing.Trace("No Country");
                                            updQuote["niq_market"] = null;
                                            update = true;
                                            break;
                                        }

                                    }
                                }
                            }
                            else
                            {
                                tracing.Trace("sales Org Count 0");
                                updQuote["niq_market"] = null;
                                update = true;

                            }
                        }
                        if (quote.Attributes.Contains("ownerid") && postImage.Attributes.Contains("ownerid") && postImage.GetAttributeValue<EntityReference>("ownerid") != null && postImage.GetAttributeValue<EntityReference>("ownerid").Id != Guid.Empty)
                        {
                            Entity retUser = service.Retrieve(quote.GetAttributeValue<EntityReference>("ownerid").LogicalName, quote.GetAttributeValue<EntityReference>("ownerid").Id, new ColumnSet("fullname", "internalemailaddress"));
                            tracing.Trace("retUser id->" + retUser.Id);
                            updQuote["niq_salesrepname"] = retUser.Attributes.Contains("fullname") ? retUser.GetAttributeValue<string>("fullname") : null;
                            updQuote["niq_salesrepemail"] = retUser.Attributes.Contains("internalemailaddress") ? retUser.GetAttributeValue<string>("internalemailaddress") : null;

                            update = true;
                        }
                        if (update)
                            service.Update(updQuote);


                    }
                }


            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
