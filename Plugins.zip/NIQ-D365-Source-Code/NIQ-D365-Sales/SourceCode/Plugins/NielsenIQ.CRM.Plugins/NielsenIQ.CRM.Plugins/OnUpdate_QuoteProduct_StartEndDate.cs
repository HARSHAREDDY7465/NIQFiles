﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using NielsenIQ.CRM.Plugins.Helper;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System.Text.RegularExpressions;
using System.Linq;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_QuoteProduct_StartEndDate : IPlugin
    {
        Entity targetEntity = new Entity();
        Entity postImage = new Entity();
        Entity updateQuoteProduct = new Entity();
        Entity updateOpportunity = new Entity();
        Entity resultOpportunity = new Entity();
        Entity resultQuote = new Entity();
        Entity updateQuote = new Entity();
        DateTime niq_lineitemstartdate = DateTime.MinValue;
        DateTime niq_lineitemenddate = DateTime.MinValue;
        DateTime update_lineitemstartdate = DateTime.MinValue;
        DateTime update_lineitemenddate = DateTime.MinValue;
        Guid quoteId;
        DateTime? earliestStartDate = null;
        DateTime? latestEndDate = null;

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                tracingService.Trace("Execution Begins");
                tracingService.Trace("Depth:" + context.Depth);
                targetEntity = (Entity)context.InputParameters["Target"];

                if (context.Depth >= 1 && context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    targetEntity = (Entity)context.InputParameters["Target"];
                    updateQuoteProduct = new Entity("quotedetail", targetEntity.Id);
                    tracingService.Trace("retQuoteProduct Id:" + targetEntity.Id);
                    bool update = false;

                    //bool isRevShareline = targetEntity.GetAttributeValue<bool>("niq_isrevshareline");
                    //tracingService.Trace($"RevShareline,{isRevShareline}");

                    Entity fullQP = service.Retrieve(targetEntity.LogicalName, targetEntity.Id, new ColumnSet("niq_isrevshareline"));
                    bool isRevShareline = fullQP.GetAttributeValue<bool>("niq_isrevshareline");
                    tracingService.Trace($"RevShareline,{isRevShareline}");

                    tracingService.Trace("niq_lineitemenddate" + targetEntity.Contains("niq_lineitemenddate"));
                    tracingService.Trace("niq_lineitemstartdate" + targetEntity.Contains("niq_lineitemstartdate"));

                    if (!isRevShareline && targetEntity != null && targetEntity.LogicalName == "quotedetail"
                        && (targetEntity.Contains("niq_lineitemenddate") || targetEntity.Contains("niq_lineitemstartdate")))
                    {
                        //bool isRevShareline = targetEntity.GetAttributeValue<bool>("niq_isrevshareline");
                        //tracingService.Trace($"RevShareline,{isRevShareline}");

                        tracingService.Trace($"RevShareline,{isRevShareline}");
                        tracingService.Trace("RevShare is False/True.");
                        if (context.MessageName.ToLower() == "update")
                        {
                            if (targetEntity.Attributes.Contains("niq_lineitemenddate"))
                            {
                                if (Convert.ToString(targetEntity.GetAttributeValue<DateTime?>("niq_lineitemenddate")) != ""
                                    && (targetEntity.GetAttributeValue<DateTime?>("niq_lineitemenddate")) != null)
                                {
                                    niq_lineitemenddate = targetEntity.GetAttributeValue<DateTime>("niq_lineitemenddate");
                                }
                            }
                            if (targetEntity.Attributes.Contains("niq_lineitemstartdate"))
                            {
                                if (Convert.ToString(targetEntity.GetAttributeValue<DateTime?>("niq_lineitemstartdate")) != ""
                                    && (targetEntity.GetAttributeValue<DateTime?>("niq_lineitemstartdate")) != null)
                                {
                                    niq_lineitemstartdate = targetEntity.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                                }
                            }
                            tracingService.Trace("niq_lineitemstartdate" + Convert.ToString(niq_lineitemstartdate));
                            tracingService.Trace("niq_lineitemenddate" + Convert.ToString(niq_lineitemenddate));

                            Entity retQuoteProduct = service.Retrieve(targetEntity.LogicalName, targetEntity.Id, new ColumnSet("quoteid"));
                            if (retQuoteProduct != null && retQuoteProduct.Id != Guid.Empty && retQuoteProduct.Attributes.Contains("quoteid"))
                            {
                                tracingService.Trace("retQuote Id" + retQuoteProduct.GetAttributeValue<EntityReference>("quoteid").Id);
                                Entity retQuote = service.Retrieve(retQuoteProduct.GetAttributeValue<EntityReference>("quoteid").LogicalName, retQuoteProduct.GetAttributeValue<EntityReference>("quoteid").Id, new ColumnSet("niq_contractstartdate", "niq_contractenddate", "niq_mainquote", "opportunityid"));
                                Entity retOppor = service.Retrieve(retQuote.GetAttributeValue<EntityReference>("opportunityid").LogicalName, retQuote.GetAttributeValue<EntityReference>("opportunityid").Id, new ColumnSet("niq_contractenddate", "niq_contractstartdate"));
                                quoteId = retQuoteProduct.GetAttributeValue<EntityReference>("quoteid").Id;
                                tracingService.Trace("quoteId" + Convert.ToString(quoteId));
                                updateQuote = new Entity(retQuoteProduct.GetAttributeValue<EntityReference>("quoteid").LogicalName, quoteId);
                                updateOpportunity = new Entity(retQuote.GetAttributeValue<EntityReference>("opportunityid").LogicalName, retQuote.GetAttributeValue<EntityReference>("opportunityid").Id);

                                //string fetchDateQP = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' aggregate='true' >
                                //                        <entity name='quotedetail' >
                                //                            <attribute name='niq_lineitemstartdate' alias='minDate' aggregate='min' />
                                //                            <attribute name='niq_lineitemenddate' alias='maxDate' aggregate='max' />
                                //                            <filter type='and' >
                                //                                <condition attribute='quoteid' operator='eq' uiname='testchanges' uitype='quote' value='{0}' />
                                //                                <condition attribute='quotedetailname' operator='ne' value='SAP Deferred Revenue reconciliation placeholder' />
                                //                            </filter>
                                //                        </entity>
                                //                    </fetch>";
                                //fetchDateQP = string.Format(fetchDateQP, retQuote.Id);
                                var resDateQP = CommonHelper.ReturnMinMaxContractStartEnddate(service, retQuote.Id, tracingService);
                                if (resDateQP != null && resDateQP.Entities != null && resDateQP.Entities.Count > 0)
                                {
                                    Entity dateQP = resDateQP.Entities.FirstOrDefault();
                                    DateTime? existingContractStartDate = retQuote.GetAttributeValue<DateTime>("niq_contractstartdate") == null ? DateTime.MinValue : retQuote.GetAttributeValue<DateTime>("niq_contractstartdate");
                                    DateTime? existingContractEndDate = retQuote.GetAttributeValue<DateTime>("niq_contractenddate") == null ? DateTime.MinValue : retQuote.GetAttributeValue<DateTime>("niq_contractenddate");
                                    tracingService.Trace("Existing contratc start date:{0}", existingContractStartDate.HasValue ? existingContractStartDate.Value.ToString("yyyy-MM-dd") : "null");
                                    tracingService.Trace("Existing contratc End date:{0}", existingContractEndDate.HasValue ? existingContractEndDate.Value.ToString("yyyy-MM-dd") : "null");

                                    if (dateQP.Contains("minDate"))
                                    {
                                        DateTime newMinDate = (DateTime)dateQP.GetAttributeValue<AliasedValue>("minDate").Value;
                                        tracingService.Trace("New Min Date :{0}", newMinDate.ToString("yyyy-MM-dd"));

                                        if (!existingContractStartDate.HasValue || newMinDate != existingContractStartDate.Value)
                                        {
                                            tracingService.Trace("Updating Contract startdate from {0} to {1}", existingContractStartDate.HasValue ? existingContractStartDate.Value.ToString("yyyy-MM-dd") : "null", newMinDate.ToString("yyyy-MM-dd"));
                                            updateQuote["niq_contractstartdate"] = newMinDate;
                                            updateOpportunity["niq_contractstartdate"] = newMinDate;
                                            update = true;
                                        }
                                        //updateQuote["niq_contractstartdate"] = dateQP.GetAttributeValue<AliasedValue>("minDate").Value;
                                        //updateOpportunity["niq_contractstartdate"] = dateQP.GetAttributeValue<AliasedValue>("minDate").Value;
                                        //update = true;
                                    }
                                    if (dateQP.Contains("maxDate"))
                                    {
                                        DateTime newMaxDate = (DateTime)dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                        tracingService.Trace("New Max Date :{0}", newMaxDate.ToString("yyyy-MM-dd"));

                                        if (!existingContractEndDate.HasValue || newMaxDate != existingContractEndDate.Value)
                                        {
                                            tracingService.Trace("Updating Contract End Date from {0} to {1}", existingContractEndDate.HasValue ? existingContractEndDate.Value.ToString("yyyy-MM-dd") : "null", newMaxDate.ToString("yyyy-MM-dd"));
                                            updateQuote["niq_contractenddate"] = newMaxDate;
                                            updateOpportunity["niq_contractenddate"] = newMaxDate;
                                            update = true;
                                        }
                                        //updateQuote["niq_contractenddate"] = dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                        //updateOpportunity["niq_contractenddate"] = dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                        //update = true;
                                    }
                                }


                                if (update)
                                {

                                    service.Update(updateQuote);

                                    tracingService.Trace("OnUpdate_QuoteProduct_StartEndDate: sucesfull update quote");
                                    if (retQuote.Attributes.Contains("niq_mainquote") && retQuote.GetAttributeValue<bool>("niq_mainquote"))
                                    {
                                        service.Update(updateOpportunity);
                                        tracingService.Trace("OnUpdate_QuoteProduct_StartEndDate: sucesfull updated Oppo");
                                    }
                                }
                            }
                        }
                    }
                    tracingService.Trace("Execution of updation if rev share line started");
                    // Update Contract start/End of Opp in Respective Rev share line
                    Entity childOpp = RetrieveChildOpp(updateQuote, service, tracingService);
                    //Get Host opportunity
                    if (childOpp != null)
                    {
                        EntityReference hostOppRef = childOpp.Contains("niq_hostopportunity") && childOpp.Attributes["niq_hostopportunity"] != null ? childOpp.GetAttributeValue<EntityReference>("niq_hostopportunity") : null;
                        if (hostOppRef != null)
                        {
                            string fetchChildOpp = CreateRevShareLine.IsOpportunityEditable(service, hostOppRef.Id, tracingService);
                            // Check host opportunity is editable
                            Entity hostOpportunity = CreateRevShareLine.IsValidHostOppWithData(service, fetchChildOpp, tracingService);
                            if (childOpp != null && hostOpportunity != null)
                            {
                                UpdateRevShareLineDate(childOpp, hostOpportunity, service, tracingService);
                            }
                        }
                    }
                }
                DateTime currentTime1 = DateTime.Now;
                tracingService.Trace("Current Time (with seconds): " + currentTime1.ToString("yyyy-MM-dd HH:mm:ss"));
            }
            catch (InvalidPluginExecutionException ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        /// <summary>
        /// Retrieve child Opp
        /// </summary>
        /// <param name="quote"></param>
        /// <param name="service"></param>
        /// <param name="tracing"></param>
        /// <returns></returns>
        public Entity RetrieveChildOpp(Entity quote, IOrganizationService service, ITracingService tracing)
        {
            Entity opportunity = null;
            try
            {
                string fetchOpp = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='opportunity'>
                                <attribute name='opportunityid' />
                                  <attribute name='niq_hostopportunity' />
                                   <attribute name='niq_contractenddate' />
                                   <attribute name='niq_contractstartdate' />
                                   <attribute name='totalamount' />
                                <filter type='and'>
                                  <condition attribute='niq_mainquoteid' operator='eq' value='{" + quote.Id + @"}' />
                                  <condition attribute='niq_hostopportunity' operator='not-null' />
                                </filter>
                              </entity>
                            </fetch>";
                EntityCollection opportunityColl = service.RetrieveMultiple(new FetchExpression(fetchOpp));
                if (opportunityColl.Entities.Count > 0)
                {
                    opportunity = opportunityColl.Entities.Cast<Entity>().FirstOrDefault();
                }
            }
            catch (InvalidPluginExecutionException ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
            return opportunity;
        }
        public void UpdateRevShareLineDate(Entity childOpp, Entity hostOppEnt, IOrganizationService service, ITracingService tracing)
        {
            Entity hostOpportunity = new Entity("opportunity");
            Entity hostQuote = new Entity("quote");
            string functionName = "UpdateRevShareLineDate";
            try
            {
                tracing.Trace("function Executing:" + functionName);
                //below method is return existing rev share line product of child opportunity
                Entity existingRevShare = RetriveExistingChildRevShare(service, childOpp.Id, tracing);
                if (existingRevShare != null)
                {
                    //Also pass preimage in update commmon function bcz check if values are same then don't update the that fields
                    Entity updateRevShareLine = UpdateRevShareLineProduct(service, existingRevShare, tracing, childOpp);//put here update common
                    service.Update(updateRevShareLine);
                    tracing.Trace("Rev Share line Updated");
                    Entity revSharLine = service.Retrieve(existingRevShare.LogicalName, existingRevShare.Id, new ColumnSet("niq_lineitemstartdate", "niq_lineitemenddate"));
                    //Get Rev Share line start/end date
                    DateTime? revShareStartdate = revSharLine.Contains("niq_lineitemstartdate") && revSharLine.Attributes["niq_lineitemstartdate"] != null ? revSharLine.GetAttributeValue<DateTime?>("niq_lineitemstartdate") : null;
                    tracing.Trace("Rev share product start date :" + revShareStartdate);
                    DateTime? revShareEnddate = revSharLine.Contains("niq_lineitemenddate") && revSharLine.Attributes["niq_lineitemenddate"] != null ? revSharLine.GetAttributeValue<DateTime?>("niq_lineitemenddate") : null;
                    tracing.Trace("Rev share product End date  :" + revShareEnddate);
                    //Get contract start/end date of opp
                    DateTime? oppContractStartDate = hostOppEnt.Contains("niq_contractstartdate") && hostOppEnt.Attributes["niq_contractstartdate"] != null ? hostOppEnt.GetAttributeValue<DateTime?>("niq_contractstartdate") : null;
                    tracing.Trace("Opportunity Contract Start Date :" + oppContractStartDate);
                    DateTime? oppContractEndDate = hostOppEnt.Contains("niq_contractenddate") && hostOppEnt.Attributes["niq_contractenddate"] != null ? hostOppEnt.GetAttributeValue<DateTime?>("niq_contractenddate") : null;
                    tracing.Trace("Opportunity Contract End Date :" + oppContractEndDate);
                    //Get Main quote of Host Opportunity
                    EntityReference hostmainQuote = hostOppEnt.Contains("niq_mainquoteid") && hostOppEnt.Attributes["niq_mainquoteid"] != null ? hostOppEnt.GetAttributeValue<EntityReference>("niq_mainquoteid") : null;

                    //if (oppContractStartDate != null && revShareStartdate != null && oppContractStartDate > revShareStartdate)
                    //{
                    //    hostOpportunity["niq_contractstartdate"] = revShareStartdate;
                    //    hostQuote["niq_contractstartdate"] = revShareStartdate;
                    //}
                    //if (oppContractEndDate != null && revShareEnddate != null && oppContractEndDate < revShareEnddate)
                    //{
                    //    hostOpportunity["niq_contractenddate"] = revShareEnddate;
                    //    hostQuote["niq_contractenddate"] = revShareEnddate;
                    //}

                    //IC-POC #27538_B
                    if ((oppContractStartDate != null && revShareStartdate != null) || (oppContractEndDate != null && revShareEnddate != null))
                    {
                        EntityCollection oppStartEndDate = CommonHelper.ReturnMinMaxContractStartEnddate(service, hostmainQuote.Id, tracing);
                        Entity dateQP = oppStartEndDate.Entities.FirstOrDefault();
                        if (dateQP.Contains("minDate"))
                        {
                            if (dateQP.GetAttributeValue<AliasedValue>("minDate") != null)
                            {
                                earliestStartDate = (DateTime)dateQP.GetAttributeValue<AliasedValue>("minDate").Value;
                                hostOpportunity["niq_contractstartdate"] = earliestStartDate;
                                hostQuote["niq_contractstartdate"] = earliestStartDate;
                            }
                        }
                        if (dateQP.Contains("maxDate"))
                        {
                            if (dateQP.GetAttributeValue<AliasedValue>("maxDate") != null)
                            {
                                latestEndDate = (DateTime)dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                hostOpportunity["niq_contractenddate"] = latestEndDate;
                                hostQuote["niq_contractenddate"] = latestEndDate;
                            }
                        }
                    }
                    //IC-POC #27538_E
                    if (hostmainQuote != null)
                    {
                        hostQuote.Id = hostmainQuote.Id;
                        tracing.Trace("hostmainQuote:" + hostmainQuote.Id);
                        service.Update(hostQuote);
                    }
                    hostOpportunity.Id = hostOppEnt.Id;
                    //UpdateRequest requestOpportunity = new UpdateRequest()
                    //{
                    //    Target = hostOpportunity
                    //};
                    //requestOpportunity.Parameters.Add("BypassCustomPluginExecution", true);
                    //service.Execute(requestOpportunity);
                    service.Update(hostOpportunity);
                }

            }
            catch (InvalidPluginExecutionException ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        public static Entity UpdateRevShareLineProduct(IOrganizationService service, Entity existingRevShare, ITracingService tracingService, Entity opportunityDetails)
        {
            Entity revShareLineQuoteProduct = new Entity("quotedetail");
            bool contractStartEndDateChange = false;
            double monthDifference = 0;
            int productType = 0;
            bool isChanged = false;
            tracingService.Trace("Inside : updateRevShareLineProduct");
            //Below contract start and end date retrieve from the trigger opportunity
            DateTime? oppContractStartDate = opportunityDetails.Contains("niq_contractstartdate") && opportunityDetails.Attributes["niq_contractstartdate"] != null ? opportunityDetails.GetAttributeValue<DateTime?>("niq_contractstartdate") : null;
            tracingService.Trace("Opportunity Contract Start Date :" + oppContractStartDate);
            DateTime? oppContractEndDate = opportunityDetails.Contains("niq_contractenddate") && opportunityDetails.Attributes["niq_contractenddate"] != null ? opportunityDetails.GetAttributeValue<DateTime?>("niq_contractenddate") : null;
            tracingService.Trace("Opportunity Contract End Date :" + oppContractEndDate);
            Decimal? TotalAmount = opportunityDetails.Contains("totalamount") && opportunityDetails.Attributes["totalamount"] != null ? (decimal?)opportunityDetails.GetAttributeValue<Money>("totalamount").Value : null;
            tracingService.Trace("Opportunity Total Amount :" + TotalAmount);

            //Below fields are retrieve from the existing rev share line
            DateTime? revShareStartdate = existingRevShare.Contains("niq_lineitemstartdate") && existingRevShare.Attributes["niq_lineitemstartdate"] != null ? existingRevShare.GetAttributeValue<DateTime?>("niq_lineitemstartdate") : null;
            tracingService.Trace("Rev share product start date :" + revShareStartdate);
            DateTime? revShareEnddate = existingRevShare.Contains("niq_lineitemenddate") && existingRevShare.Attributes["niq_lineitemenddate"] != null ? existingRevShare.GetAttributeValue<DateTime?>("niq_lineitemenddate") : null;
            tracingService.Trace("Rev share product end date  :" + revShareEnddate);
            Decimal? revShareAmount = existingRevShare.Contains("extendedamount") && existingRevShare.Attributes["extendedamount"] != null ? (decimal?)existingRevShare.GetAttributeValue<Money>("extendedamount").Value : null;
            tracingService.Trace("Rev share product extend Amount :" + revShareAmount);

            revShareLineQuoteProduct.Id = existingRevShare.Id;
            if (revShareStartdate.HasValue && oppContractStartDate != revShareStartdate)
            {
                revShareLineQuoteProduct["niq_lineitemstartdate"] = oppContractStartDate;
                contractStartEndDateChange = true;
            }
            if (revShareEnddate.HasValue && oppContractEndDate != revShareEnddate)
            {
                revShareLineQuoteProduct["niq_lineitemenddate"] = oppContractEndDate;
                contractStartEndDateChange = true;
            }
            if (contractStartEndDateChange == true)
            {
                if (CreateRevShareLine.CheckFirstDayMonth(oppContractStartDate, tracingService) && CreateRevShareLine.CheckLastDayMonth(oppContractEndDate, tracingService))
                {
                    if (oppContractStartDate.HasValue && oppContractEndDate.HasValue)
                    {
                        monthDifference = CreateRevShareLine.GetMonthDifference(oppContractStartDate.Value, oppContractEndDate.Value, tracingService);
                        tracingService.Trace("monthDifference:" + monthDifference);
                        //revShareLineQuoteProduct["niq_termlength"] = monthDifference;
                        //DYNCRM-21595
                        revShareLineQuoteProduct["niq_calculatedtermlength"] = monthDifference;
                        isChanged = true;
                    }
                }
                else
                {
                    //isCompatiable = true;
                    monthDifference = 0;
                    //revShareLineQuoteProduct["niq_termlength"] = monthDifference;
                    //DYNCRM-21595
                    revShareLineQuoteProduct["niq_calculatedtermlength"] = monthDifference;
                    tracingService.Trace("Month Difference: " + monthDifference);
                    isChanged = true;
                }
            }
            if (existingRevShare.Contains("niq_billingfrequency") && existingRevShare.Attributes["niq_billingfrequency"] != null)
            {
                OptionSetValue billingFrequencyOptionSet = existingRevShare.GetAttributeValue<OptionSetValue>("niq_billingfrequency");
                int billingfrequency = billingFrequencyOptionSet.Value;
                if (billingfrequency != 0 && (billingfrequency == 100000010 || billingfrequency == 100000011 || billingfrequency == 100000012 || billingfrequency == 100000013))
                {
                    revShareLineQuoteProduct["niq_billingstartdate"] = oppContractStartDate;
                    revShareLineQuoteProduct["niq_billingenddate"] = oppContractEndDate;
                    isChanged = true;
                }
            }

            if (existingRevShare.Contains("niq_type") && existingRevShare.GetAttributeValue<OptionSetValue>("niq_type") != null)
            {

                OptionSetValue type = existingRevShare.GetAttributeValue<OptionSetValue>("niq_type");
                productType = type.Value;
            }
            if (existingRevShare.Contains("niq_istimebased"))
            {

                bool isTimeBased = existingRevShare.GetAttributeValue<bool>("niq_istimebased");
                if (productType == 100000001 && !isTimeBased)
                {
                    revShareLineQuoteProduct["niq_calculatedtermlength"] = monthDifference;
                    isChanged = true;
                }
            }
            tracingService.Trace("Total Amount:" + TotalAmount);
            tracingService.Trace("Rev Amount:" + revShareAmount);
            //if (revShareAmount.HasValue && TotalAmount != revShareAmount)
            //{
            //revShareLineQuoteProduct["extendedamount"] = TotalAmount;
            //}
            tracingService.Trace("ischanged:" + isChanged);
            if (isChanged == true)
            {
                revShareLineQuoteProduct["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                revShareLineQuoteProduct["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
            }
            return revShareLineQuoteProduct;
        }

        /// <summary>
        /// Retrieve existing rev share line product
        /// </summary>
        /// <param name="service"></param>
        /// <param name="childOpportunityId"></param>
        /// <param name="tracingService"></param>
        /// <returns></returns>
        private Entity RetriveExistingChildRevShare(IOrganizationService service, Guid childOpportunityId, ITracingService tracingService)
        {
            try
            {
                string functionName = "retriVeExistingChildRevShare";
                tracingService.Trace("Inside :" + functionName);
                string fetchRevshareDetails = string.Empty;
                Entity revShareLineProduct = null;

                try
                {
                    fetchRevshareDetails = @"<fetch>
                    <entity name='quotedetail'>
                    <attribute name='quotedetailid' />
                    <attribute name='niq_billingenddate' />
                    <attribute name='niq_billingstartdate' />
                    <attribute name='niq_correspondingchildopportunity' />
                    <attribute name='niq_lineitemenddate' />
                    <attribute name='extendedamount' />
                    <attribute name='productname' />
                    <attribute name='niq_lineitemstartdate' />
                    <attribute name='niq_termlength' />
                    <attribute name='niq_calculatedtermlength' />
                     <attribute name='niq_type' />
                    <attribute name='niq_istimebased' />
                      <attribute name='niq_billingfrequency' />
                    <filter type='and'>
                    <condition attribute='niq_correspondingchildopportunity' operator='not-null' />
                    <condition attribute='niq_correspondingchildopportunity' operator='eq' value='" + childOpportunityId + @"' />
                    </filter>
                    </entity>
                    </fetch>";

                    EntityCollection revShareLineColl = service.RetrieveMultiple(new FetchExpression(fetchRevshareDetails));
                    tracingService.Trace("quotedetailColl Count:" + revShareLineColl.Entities.Count);
                    if (revShareLineColl.Entities.Count > 0)
                    {
                        revShareLineProduct = revShareLineColl.Entities.Cast<Entity>().FirstOrDefault();
                        tracingService.Trace("quotedetailColl Count:" + revShareLineProduct.Id);
                    }
                }
                catch (Exception ex)
                {
                    throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
                }
                return revShareLineProduct;
            }
            catch (InvalidPluginExecutionException ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
