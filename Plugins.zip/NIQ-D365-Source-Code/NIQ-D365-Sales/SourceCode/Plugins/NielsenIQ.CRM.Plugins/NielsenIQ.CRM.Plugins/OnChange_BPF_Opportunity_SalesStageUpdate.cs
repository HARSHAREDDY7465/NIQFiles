using System;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace NielsenIQ.CRM.Plugins
{
    public class OnChange_BPF_Opportunity_SalesStageUpdate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context =(IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory =(IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            //Updated for - DYNCRM-30896 Moved all the Js logic to Plugin!
            try
            {
                tracing.Trace("Plugin started - Post Operation");

                if (context.Depth > 5)
                {
                    tracing.Trace("Depth exceeded, exiting");
                    return;
                }
                tracing.Trace("Plugin triggered by MessageName: {0}", context.MessageName);

                if (!context.InputParameters.Contains("Target") ||
                    !(context.InputParameters["Target"] is Entity target) ||
                    target.LogicalName != "opportunity")
                {
                    tracing.Trace("Invalid target");
                    return;
                }

                Entity preImage = context.PreEntityImages.Contains("Image")
                    ? context.PreEntityImages["Image"]
                    : null;

                Entity postImage = context.PostEntityImages.Contains("Image")
                    ? context.PostEntityImages["Image"]
                    : null;

                tracing.Trace("Post Image Count: " + context.PostEntityImages.Count);
                foreach (var i in context.PostEntityImages)
                {
                    tracing.Trace($"Image key: {i.Key}");
                }

                Entity opptarget = (Entity)context.InputParameters["Target"];
                Guid oppIdcurrent = target.Id;

                tracing.Trace("{0} message detected for Opportunity Id: {1}", context.MessageName, oppIdcurrent);

                ColumnSet cols = new ColumnSet(
                    "niq_forecastingdatapresence",
                    "niq_existingcontractaction",
                    "niq_tempeoaurl",
                    "niq_finallyexecutedagreementurl",
                    "niq_stage");

                Entity opportunity = service.Retrieve("opportunity", oppIdcurrent, cols);

                string previousStage = preImage?.GetAttributeValue<string>("niq_stage") ?? opportunity.GetAttributeValue<string>("niq_stage");

                string currentStage = postImage?.GetAttributeValue<string>("niq_stage") ?? opportunity.GetAttributeValue<string>("niq_stage");


                tracing.Trace($"Previous Stage: {previousStage ?? "null"}");
                tracing.Trace($"Current Stage: {currentStage ?? "null"}");


                OptionSetValue existingContractAction = postImage?.GetAttributeValue<OptionSetValue>("niq_existingcontractaction") ?? opportunity.GetAttributeValue<OptionSetValue>("niq_existingcontractaction");


                if (existingContractAction != null)
                {
                    // Trace the numeric value
                    tracing.Trace("Existing Contract Action Value: {0}", existingContractAction.Value);

                    // Trace the value
                    if (opportunity.FormattedValues.Contains("niq_existingcontractaction"))
                    {
                        tracing.Trace("Existing Contract Action Label: {0}",
                            opportunity.FormattedValues["niq_existingcontractaction"]);
                    }
                    else
                    {
                        tracing.Trace("Existing Contract Action Label not found in FormattedValues");
                    }
                }
                else
                {
                    tracing.Trace("Existing Contract Action is null");
                }


                int calculatedStage = 0;


                // CREATE
                if (context.MessageName == "Create")
                {
                    if (existingContractAction != null &&
                        (existingContractAction.Value == 1 || existingContractAction.Value == 4))
                    {
                        tracing.Trace("Create → Existing contract action is 1 or 4");
                        switch (currentStage?.Trim())
                        {
                            case "Pre-Proposal":
                                calculatedStage = 1003;
                                break;

                            default:
                                calculatedStage = 1001; // fallback if stage doesn't match
                                break;
                        }
                    }
                    else
                    {
                        tracing.Trace("Create → Default Sales Stage = Discover/ExistingContract is null");
                        calculatedStage = 1001;
                    }
                }

                // UPDATE
                if (context.MessageName == "Update" && !string.IsNullOrEmpty(currentStage))
                {
                    tracing.Trace("Update → Processing stage logic");
                    // Get IDs
                    Guid oppId = oppIdcurrent;
                    ColumnSet postcols = new ColumnSet("niq_forecastingdatapresence", "niq_existingcontractaction", "niq_tempeoaurl", "niq_finallyexecutedagreementurl", "niq_stage");
                    Entity postopportunity = service.Retrieve("opportunity", oppId, cols);
                    tracing.Trace("Retrieved Opportunity with Id: {0}", oppId);               

                    string currentTempUrl = postImage?.GetAttributeValue<string>("niq_tempeoaurl");
                    string currentFinalUrl = postImage?.GetAttributeValue<string>("niq_finallyexecutedagreementurl");


                    // Existing Contract Action override
                    if (existingContractAction != null &&
                        (existingContractAction.Value == 1 || existingContractAction.Value == 4))
                    {
                        tracing.Trace("Existing Contract Action logic");

                        switch (currentStage?.Trim())
                        {
                            case "Pre-Proposal":
                            case "Proposal":
                                calculatedStage = 1003;
                                break;

                            case "Negotiation":
                                bool hasAgreement =
                                    !string.IsNullOrEmpty(currentTempUrl) ||
                                    !string.IsNullOrEmpty(currentFinalUrl);

                                tracing.Trace($"hasAgreement={hasAgreement}");
                                calculatedStage = hasAgreement ? 1005 : 1004;
                                break;

                            case "Closed Won - In Review":
                            case "Closed Won - Approved":
                                calculatedStage = 1006;
                                break;

                            case "Closed Lost":
                                calculatedStage = 1007;
                                break;
                        }
                    }
                    else
                    {
                        calculatedStage = ProcessActiveStage( tracing,currentStage,previousStage, opportunity,postImage );

                    }
                }

                if (calculatedStage == 0)
                {
                    tracing.Trace("No Sales Stage calculated, exiting");
                    return;
                }

                Entity update = new Entity("opportunity", oppIdcurrent);
                SetSalesStageAndDescription(tracing, update, new OptionSetValue(calculatedStage));

                tracing.Trace($"Updating Opportunity with SalesStage {calculatedStage}");
                service.Update(update);

                tracing.Trace("Plugin completed successfully");
            }
            catch (Exception ex)
            {
                tracing.Trace("Exception: " + ex);
                throw new InvalidPluginExecutionException("Error in Opportunity Sales Stage plugin", ex);
            }
        }

        private int ProcessActiveStage( ITracingService tracing,string currentStage, string previousStage, Entity opportunity, Entity postImage)

        {
            tracing.Trace("ProcessActiveStage started");


            int salesStage = 0;
            string currentTempUrl = postImage?.GetAttributeValue<string>("niq_tempeoaurl");
            string currentFinalUrl = postImage?.GetAttributeValue<string>("niq_finallyexecutedagreementurl");

            string current = currentStage?.Trim();
            string previous = previousStage?.Trim();

            tracing.Trace($"current={current}, previous={previous}");

            // Backward movement
            if (!string.IsNullOrEmpty(previous) && previous != current)
            {
                if (previous == "Closed Won - In Review" && current == "Negotiation")
                    return 1005;

                if (previous == "Negotiation" && current == "Proposal")
                    return 1003;

                if (previous == "Proposal" && current == "Pre-proposal")
                    return 1002;
            }

            // Forward movement
            switch (currentStage?.Trim())
            {
                case "Pre-Proposal":
                    bool hasProducts =opportunity.GetAttributeValue<bool?>("niq_forecastingdatapresence") ?? false;
                    salesStage = hasProducts ? 1002 : 1001;
                    break;

                case "Proposal":
                    salesStage = 1003;
                    break;

                case "Negotiation":
                    bool hasAgreement =
                        !string.IsNullOrEmpty(currentTempUrl) ||
                        !string.IsNullOrEmpty(currentFinalUrl);

                    tracing.Trace($"hasAgreement={hasAgreement}");
                    salesStage = hasAgreement ? 1005 : 1004;
                    break;

                case "Closed Won - In Review":
                case "Closed Won - Approved":
                    salesStage = 1006;
                    break;

                case "Closed Lost":
                    salesStage = 1007;
                    break;
            }

            tracing.Trace($"ProcessActiveStage calculated={salesStage}");
            return salesStage;
        }
        private void SetSalesStageAndDescription(ITracingService tracing,Entity target, OptionSetValue salesStage)
        {
            if (salesStage == null)
                return;

            target["niq_salesstage"] = salesStage;

            var descriptions = new Dictionary<int, string>
            {
                {1001, "Discover: Diagnose customer priorities and uncover growth drivers; explore changes in business needs. Exit: BANT confirmed, L1 product selected, estimated close date set."},
                {1002, "Solution: Position renewal as strategic growth; connect solutions to future goals and pain points. Exit: Solution set formalized, pain points resolved, opp team created, customer accepts solution."},
                {1003, "Proposal/Pricing: Present a value-driven proposal aligned to BANT; emphasize ROI and avoid discounting. Exit: Product configured, deal desk approval, proposal delivered and acknowledged."},
                {1004, "Negotiation: Reinforce value and address risk; share proof points and maintain expansion options. Exit: Customer agrees, billing/shipping provided, SAP account created."},
                {1005, "Contracting: Ensure clarity on scope and terms. Exit: Redlines resolved, contract sent, PO received from customer if needed."},
                {1006, "Closed Won: Validate documentation and confirm next steps internally. Exit: Signed contract received."},
                {1007, ""}
            };

            if (descriptions.TryGetValue(salesStage.Value, out string description))
            {
                target["niq_salesstagedescription"] = description;
                tracing.Trace($"SalesStageDescription set to: {description}");
            }
        }
    }
}