﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;
using NielsenIQ.CRM.Plugins.Helper;

namespace NielsenIQ.CRM.Plugins
{
    public class OnCreateUpdate_QuoteProductCharacteristic_Update_Opportunity : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                if (context.MessageName.ToLower() == "delete")
                {
                    Entity preImage = context.PreEntityImages.Contains("Image") ? (Entity)context.PreEntityImages["Image"] : new Entity();
                    if (preImage.Contains("niq_ismainquote") && (bool)preImage["niq_ismainquote"] && preImage.Contains("niq_quoteid"))
                    {
                        tracing.Trace("Post Operation On" + context.MessageName + " of Quote Product Characteristics: Getting the target entity from Input Parameters.");
                        CommonHelper.updateOpportunityMandatoryCharValueAddedValidation(((EntityReference)preImage["niq_quoteid"]).Id, tracing, service);
                    }
                }


                // The InputParameters collection contains all the data  
                else if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("Post Operation On" + context.MessageName + " of Quote Product Characteristics: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity qpceRecord = (Entity)context.InputParameters["Target"];
                    Entity postImage = context.PostEntityImages.Contains("Image") ? (Entity)context.PostEntityImages["Image"] : new Entity();
                    if ((context.MessageName.ToLower() == "create" || (context.MessageName.ToLower() == "update") && (bool)postImage["niq_ismainquote"]))
                    {
                        tracing.Trace("in if block");
                        Guid quoteId = qpceRecord.Contains("niq_quoteid") ? ((EntityReference)qpceRecord["niq_quoteid"]).Id :
                            (postImage.Contains("niq_quoteid") ? ((EntityReference)postImage["niq_quoteid"]).Id : new Guid());
                        if (quoteId != null && quoteId != new Guid())
                        {
                            tracing.Trace("in second if block");
                            CommonHelper.updateOpportunityMandatoryCharValueAddedValidation(quoteId, tracing, service);
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
