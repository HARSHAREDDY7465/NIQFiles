﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.Plugins.Helper;

namespace NielsenIQ.CRM.Plugins
{
    public class OnQuoteRevision_Update_MainQuote : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnQuoteRevision: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity currentQuote = (Entity)context.InputParameters["Target"];
                    if (currentQuote != null && currentQuote.Id != Guid.Empty)
                    {
                        bool update = false;
                        if (currentQuote.LogicalName != "quote")
                        {
                            tracing.Trace("OnQuoteRevision: inputparameter is not quote ");
                            return;
                        }
                        Entity relOppo = service.Retrieve("opportunity", currentQuote.GetAttributeValue<EntityReference>("opportunityid").Id, new ColumnSet("parentaccountid", "niq_billtoparty", "niq_deliverytoparty", "name", "niq_opportunitynumber", "niq_salesgroupsalesorgid", "niq_mainquoteid", "estimatedclosedate", "transactioncurrencyid", "niq_salesorgid"));
                        Entity updQuote = new Entity(currentQuote.LogicalName, currentQuote.Id);
                        if (relOppo != null && relOppo.Id != Guid.Empty)
                        {
                            tracing.Trace("OnQuoteRevision:relOppo " + relOppo.Id);


                            if (relOppo.Attributes.Contains("parentaccountid") && relOppo.GetAttributeValue<EntityReference>("parentaccountid") != null && relOppo.GetAttributeValue<EntityReference>("parentaccountid").Id != Guid.Empty)
                            {
                                tracing.Trace("OnQuoteRevision: accountid " + relOppo.GetAttributeValue<EntityReference>("parentaccountid").Id);
                                Entity retAccount = service.Retrieve(relOppo.GetAttributeValue<EntityReference>("parentaccountid").LogicalName, relOppo.GetAttributeValue<EntityReference>("parentaccountid").Id, new ColumnSet("address1_line1", "address1_city", "niq_stateprovince", "address1_postalcode", "niq_countryid", "niq_industry"));
                                if (retAccount != null && retAccount.Id != Guid.Empty)
                                {
                                    if (retAccount.Attributes.Contains("address1_line1"))
                                    {

                                        updQuote["niq_accountaddressstreet"] = retAccount.GetAttributeValue<string>("address1_line1");
                                    }
                                    if (retAccount.Attributes.Contains("address1_city"))
                                    {

                                        updQuote["niq_accountaddresscity"] = retAccount.GetAttributeValue<string>("address1_city");
                                    }
                                    if (retAccount.Attributes.Contains("niq_stateprovince"))
                                    {
                                        updQuote["niq_accountaddressstateprovince"] = retAccount.FormattedValues["niq_stateprovince"];
                                    }

                                    if (retAccount.Attributes.Contains("address1_postalcode"))
                                    {

                                        updQuote["niq_accountaddresspostalcode"] = retAccount.GetAttributeValue<string>("address1_postalcode");
                                    }
                                    if (retAccount.Attributes.Contains("niq_countryid"))
                                    {

                                        updQuote["niq_accountaddresscountry"] = retAccount.GetAttributeValue<EntityReference>("niq_countryid").Name;
                                    }
                                    if (retAccount.Attributes.Contains("niq_industry"))
                                    {

                                        updQuote["niq_accountindustry"] = retAccount.FormattedValues["niq_industry"];
                                    }
                                    updQuote["niq_account"] = relOppo.GetAttributeValue<EntityReference>("parentaccountid").Name;
                                    update = true;
                                }
                            }
                            if (relOppo.Attributes.Contains("niq_billtoparty") && relOppo.GetAttributeValue<EntityReference>("niq_billtoparty") != null && relOppo.GetAttributeValue<EntityReference>("niq_billtoparty").Id != Guid.Empty)
                            {
                                tracing.Trace("OnQuoteRevision: niq_billtoparty " + relOppo.GetAttributeValue<EntityReference>("niq_billtoparty").Id);
                                Entity retBillAccount = service.Retrieve(relOppo.GetAttributeValue<EntityReference>("niq_billtoparty").LogicalName, relOppo.GetAttributeValue<EntityReference>("niq_billtoparty").Id, new ColumnSet("address1_line1", "address1_city", "niq_stateprovince", "address1_postalcode", "niq_countryid", "niq_billingstatecode", "niq_vatregistrationnumber", "name"));
                                if (retBillAccount != null && retBillAccount.Id != Guid.Empty)
                                {
                                    if (retBillAccount.Attributes.Contains("address1_line1"))
                                    {

                                        updQuote["niq_billtoaccountaddressstreet"] = retBillAccount.GetAttributeValue<string>("address1_line1");
                                    }
                                    if (retBillAccount.Attributes.Contains("address1_city"))
                                    {

                                        updQuote["niq_billtoaccountaddresscity"] = retBillAccount.GetAttributeValue<string>("address1_city");
                                    }
                                    if (retBillAccount.Attributes.Contains("niq_billingstatecode"))
                                    {

                                        updQuote["niq_billtoaccountaddressstateprovince"] = retBillAccount.GetAttributeValue<string>("niq_billingstatecode");
                                    }
                                    if (retBillAccount.Attributes.Contains("niq_vatregistrationnumber"))
                                    {

                                        updQuote["niq_vatnumber"] = retBillAccount.GetAttributeValue<string>("niq_vatregistrationnumber");
                                    }
                                    if (retBillAccount.Attributes.Contains("name"))
                                    {

                                        updQuote["niq_billtopartyname"] = retBillAccount.GetAttributeValue<string>("name");
                                    }
                                    if (retBillAccount.Attributes.Contains("address1_postalcode"))
                                    {

                                        updQuote["niq_billtoaccountaddresspostalcode"] = retBillAccount.GetAttributeValue<string>("address1_postalcode");
                                    }
                                    if (retBillAccount.Attributes.Contains("niq_countryid"))
                                    {

                                        updQuote["niq_billtoaccountaddresscountry"] = retBillAccount.GetAttributeValue<EntityReference>("niq_countryid").Name;
                                    }
                                    updQuote["niq_billtoaccount"] = relOppo.GetAttributeValue<EntityReference>("niq_billtoparty").Name;
                                    update = true;

                                }
                            }
                            if (relOppo.Attributes.Contains("niq_deliverytoparty") && relOppo.GetAttributeValue<EntityReference>("niq_deliverytoparty") != null && relOppo.GetAttributeValue<EntityReference>("niq_deliverytoparty").Id != Guid.Empty)
                            {
                                tracing.Trace("OnQuoteRevision: niq_deliverytoparty " + relOppo.GetAttributeValue<EntityReference>("niq_deliverytoparty").Id);
                                Entity retShipAccount = service.Retrieve(relOppo.GetAttributeValue<EntityReference>("niq_deliverytoparty").LogicalName, relOppo.GetAttributeValue<EntityReference>("niq_deliverytoparty").Id, new ColumnSet("address1_line1", "address1_city", "niq_stateprovince", "address1_postalcode", "niq_countryid"));
                                if (retShipAccount != null && retShipAccount.Id != Guid.Empty)
                                {
                                    if (retShipAccount.Attributes.Contains("address1_line1"))
                                    {

                                        updQuote["niq_shiptoaccountaddressstreet"] = retShipAccount.GetAttributeValue<string>("address1_line1");
                                    }
                                    if (retShipAccount.Attributes.Contains("address1_city"))
                                    {

                                        updQuote["niq_shiptoaccountaddresscity"] = retShipAccount.GetAttributeValue<string>("address1_city");
                                    }
                                    if (retShipAccount.Attributes.Contains("niq_stateprovince"))
                                    {

                                        updQuote["niq_shiptoaccountaddressstateprovince"] = retShipAccount.FormattedValues["niq_stateprovince"];
                                    }

                                    if (retShipAccount.Attributes.Contains("address1_postalcode"))
                                    {

                                        updQuote["niq_shiptoaccountaddresspostalcode"] = retShipAccount.GetAttributeValue<string>("address1_postalcode");
                                    }
                                    if (retShipAccount.Attributes.Contains("niq_countryid"))
                                    {

                                        updQuote["niq_shiptoaccountaddresscountry"] = retShipAccount.GetAttributeValue<EntityReference>("niq_countryid").Name;
                                    }
                                    updQuote["niq_shiptoaccount"] = relOppo.GetAttributeValue<EntityReference>("niq_deliverytoparty").Name;
                                    update = true;

                                }
                            }
                            if (relOppo.Attributes.Contains("name") && relOppo.GetAttributeValue<string>("name") != null)
                            {
                                updQuote["niq_opportunityname"] = relOppo.GetAttributeValue<string>("name");
                                update = true;
                            }
                            if (relOppo.Attributes.Contains("niq_opportunitynumber") && relOppo.GetAttributeValue<string>("niq_opportunitynumber") != null)
                            {
                                updQuote["niq_opportunitynumber"] = relOppo.GetAttributeValue<string>("niq_opportunitynumber");
                                update = true;
                            }
                            if (relOppo.Attributes.Contains("niq_salesgroupsalesorgid") && relOppo.GetAttributeValue<EntityReference>("niq_salesgroupsalesorgid") != null && relOppo.GetAttributeValue<EntityReference>("niq_salesgroupsalesorgid").Id != Guid.Empty)
                            {
                                updQuote["niq_salesgroup"] = relOppo.GetAttributeValue<EntityReference>("niq_salesgroupsalesorgid").Name;
                                update = true;
                            }
                            if (relOppo.Attributes.Contains("transactioncurrencyid") && relOppo.GetAttributeValue<EntityReference>("transactioncurrencyid") != null && relOppo.GetAttributeValue<EntityReference>("transactioncurrencyid").Id != Guid.Empty)
                            {
                                Entity currency = service.Retrieve(relOppo.GetAttributeValue<EntityReference>("transactioncurrencyid").LogicalName, relOppo.GetAttributeValue<EntityReference>("transactioncurrencyid").Id, new ColumnSet("isocurrencycode"));
                                if (currency != null && currency.Attributes.Contains("isocurrencycode") && currency.GetAttributeValue<string>("isocurrencycode") != null)
                                {
                                    updQuote["niq_isocurrencycode"] = currency.GetAttributeValue<string>("isocurrencycode");
                                    update = true;
                                }
                            }

                        }

                        //tracing.Trace("OnQuoteRevision: Getting the revisionnumber");
                        //if (currentQuote.Attributes.Contains("revisionnumber"))
                        //{
                        //    int revisionNumber = currentQuote.GetAttributeValue<int>("revisionnumber");
                        //    if (revisionNumber > 0)
                        //    {
                        //        tracing.Trace("OnQuoteRevision: revision is greater than 0.");
                        //        tracing.Trace("OnQuoteRevision: retrieving related opportunity");
                        //        tracing.Trace("OnQuoteRevision: Getting the main quote from opportunity");
                        //        if (relOppo != null && relOppo.Id != Guid.Empty && relOppo.Attributes.Contains("niq_mainquoteid") && relOppo["niq_mainquoteid"] != null)
                        //        {
                        //            tracing.Trace("OnQuoteRevision: Getting the quote number.");
                        //            string currentQuoteNum = currentQuote.GetAttributeValue<string>("quotenumber");
                        //            tracing.Trace("OnQuoteRevision: Getting the main quote .");
                        //            Entity mainQuote = service.Retrieve("quote", relOppo.GetAttributeValue<EntityReference>("niq_mainquoteid").Id, new ColumnSet("quotenumber"));
                        //            if (mainQuote != null && mainQuote.Id != Guid.Empty && mainQuote.Attributes.Contains("quotenumber") && mainQuote["quotenumber"] != null)
                        //            {
                        //                tracing.Trace("OnQuoteRevision: Getting the main quote number");
                        //                string mainQuoteNum = mainQuote.GetAttributeValue<string>("quotenumber");
                        //                tracing.Trace("OnQuoteRevision: Checking Main quote number & current quote number");
                        //                if (mainQuoteNum == currentQuoteNum)
                        //                {
                        //                    tracing.Trace("OnQuoteRevision: Updating related Opportunity Main Quote.");
                        //                    Entity updOppo = new Entity("opportunity", currentQuote.GetAttributeValue<EntityReference>("opportunityid").Id);
                        //                    updOppo["niq_mainquoteid"] = new EntityReference(currentQuote.LogicalName, currentQuote.Id);
                        //                    service.Update(updOppo);
                        //                    tracing.Trace("OnQuoteRevision: Success");
                        //                }
                        //            }

                        //            updQuote["niq_dealdeskapproval"] = new OptionSetValue(100000000);
                        //            update = true;

                        //        }
                        //    }
                        //}

                        Guid templateId = CommonHelper.GetTemplateId("Opportunity Teams", service);
                        tracing.Trace("PostassignorPostCreate: Result = " + templateId);
                        if (templateId != Guid.Empty)
                        {
                            var fetchUsersFromOpportunityTeam = @"<fetch>
                                                <entity name='opportunity' > <attribute name='name' />
                                                <filter type='and'>
	                                                <condition attribute='opportunityid' operator='eq' value='" + currentQuote.GetAttributeValue<EntityReference>("opportunityid").Id + @"' />       
                                                </filter>
                                                <link-entity name='principalobjectaccess' from='objectid' to='opportunityid' link-type='inner' alias='poa' >
	                                                <attribute name='objectid' alias='objectid' />
                                                <link-entity name='team' from='teamid' to='principalid' link-type='inner' >
	                                                <link-entity name='teamtemplate' from='teamtemplateid' to='teamtemplateid' >
	                                                <filter type='and'>
	                                                <condition attribute='teamtemplateid' operator='eq' value='" + templateId + @"'/> 
	                                                </filter>
	                                                </link-entity>
                                                <link-entity name='teammembership' from='teamid' to='teamid' link-type='inner' intersect='true' >
                                                <link-entity name='systemuser' from='systemuserid' to='systemuserid' link-type='inner' >
	                                                <attribute name='fullname' /> 
	                                                <attribute name='systemuserid' />
                                                </link-entity>
                                                </link-entity>
                                                </link-entity>
                                                </link-entity>
                                                </entity>
                                                </fetch>";

                            var teamMembers = service.RetrieveMultiple(new FetchExpression(fetchUsersFromOpportunityTeam));
                            if (teamMembers != null && teamMembers.Entities != null && teamMembers.Entities.Count > 0)
                            {
                                Guid quouteTemplateId = CommonHelper.GetTemplateId("Quote Teams", service);
                                if (quouteTemplateId != Guid.Empty)
                                {
                                    foreach (Entity teamMember in teamMembers.Entities)
                                    {
                                        if (teamMember.Attributes.Contains("systemuser5.systemuserid") && teamMember.Attributes["systemuser5.systemuserid"] != null)
                                        {
                                            Guid userId = new Guid(((AliasedValue)teamMember.Attributes["systemuser5.systemuserid"]).Value.ToString());
                                            if (userId != Guid.Empty)
                                            {
                                                CommonHelper.AddUserToAccessTeam(currentQuote, userId, quouteTemplateId, tracing, service);
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (!currentQuote.Attributes.Contains("niq_salesorgid"))
                        {
                            if (relOppo.Attributes.Contains("transactioncurrencyid") && relOppo.Attributes.Contains("niq_salesorgid"))
                            {

                                EntityReference salesOrg = relOppo.GetAttributeValue<EntityReference>("niq_salesorgid");
                                updQuote["niq_salesorgid"] = new EntityReference(salesOrg.LogicalName, salesOrg.Id);
                                update = true;
                                if (relOppo.Attributes.Contains("niq_salesorgid") && relOppo.GetAttributeValue<EntityReference>("niq_salesorgid").Id != Guid.Empty)
                                {
                                    Guid salesOrgId = ((EntityReference)relOppo["niq_salesorgid"]).Id;
                                    QueryExpression salesOrgQuery = new QueryExpression("niq_salesorg");
                                    salesOrgQuery.TopCount = 1;
                                    salesOrgQuery.ColumnSet.AddColumns("niq_operatingcountryid");
                                    salesOrgQuery.Criteria.AddCondition("niq_salesorgid", ConditionOperator.Equal, salesOrgId);
                                    var salesOrgRecords = service.RetrieveMultiple(salesOrgQuery);
                                    if (salesOrgRecords != null && salesOrgRecords.Entities != null && salesOrgRecords.Entities.Count > 0)
                                    {
                                        foreach (Entity record in salesOrgRecords.Entities)
                                        {
                                            if (record.Attributes.Contains("niq_operatingcountryid"))
                                            {
                                                Entity country = service.Retrieve(record.GetAttributeValue<EntityReference>("niq_operatingcountryid").LogicalName, record.GetAttributeValue<EntityReference>("niq_operatingcountryid").Id, new ColumnSet("niq_countrycode"));
                                                if (country != null && country.Id != Guid.Empty && country.Attributes.Contains("niq_countrycode"))
                                                {
                                                    updQuote["niq_market"] = country.GetAttributeValue<string>("niq_countrycode");
                                                    update = true;
                                                    break;
                                                }
                                                else
                                                {
                                                    updQuote["niq_market"] = null;
                                                    update = true;
                                                    break;
                                                }

                                            }
                                        }
                                    }
                                    else
                                    {
                                        updQuote["niq_market"] = null;
                                        update = true;

                                    }
                                }



                            }
                        }

                        if (update)
                        {
                            service.Update(updQuote);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}