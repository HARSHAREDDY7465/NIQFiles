﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;


namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Opportunity_Update_FAR : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdateOpportunity: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity oppoObj = (Entity)context.InputParameters["Target"];
                    if (context.Depth > 2 || !oppoObj.Contains("totalamount"))
                    {
                        return;
                    }
                    if (oppoObj != null && oppoObj.Id != Guid.Empty)
                    {
                        tracing.Trace("OnUpdateOpportunity: Checking the Contest message is update.");
                        if (context.MessageName == "Update")
                        {
                            tracing.Trace("OnUpdateOpportunity: Getting the FAR records which are rejected for opportunity ");
                            string fetchXmlFAR = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='niq_financeapprovalrequests'>
                                                <attribute name='niq_financeapprovalrequestsid' />
                                                <attribute name='niq_financeapprovalrequests' />
                                                <attribute name='createdon' />
                                                <order attribute='niq_financeapprovalrequests' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='niq_approvalstatus' operator='eq' value='100000003' />
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='niq_relatedopportunity' operator='eq'  uitype='opportunity' value='{0}' />
                                                </filter>
                                              </entity>
                                            </fetch>";
                            fetchXmlFAR = String.Format(fetchXmlFAR, oppoObj.Id);

                            Entity farObj = service.RetrieveMultiple(new FetchExpression(fetchXmlFAR)).Entities.FirstOrDefault();

                            if (farObj != null && farObj.Id != Guid.Empty)
                            {
                                tracing.Trace("OnUpdateOpportunity: Retrieved FAR Records -> ." + farObj.Id);
                                int count = 0;
                                tracing.Trace("OnUpdateOpportunity: Getting the PostImage.");
                                Entity postImage = context.PostEntityImages.Contains("OpportunityImage") ? (Entity)context.PostEntityImages["OpportunityImage"] : null;
                                if (postImage != null)
                                {

                                    Money budgetAmountpost = postImage.Attributes.Contains("budgetamount") ? postImage.GetAttributeValue<Money>("budgetamount") : null;
                                    DateTime estCloseDatepost = postImage.Attributes.Contains("estimatedclosedate") ? postImage.GetAttributeValue<DateTime>("estimatedclosedate") : DateTime.MinValue;
                                    EntityReference custAccountpost = postImage.Attributes.Contains("parentaccountid") ? postImage.GetAttributeValue<EntityReference>("parentaccountid") : null;
                                    EntityReference salesOrgpost = postImage.Attributes.Contains("niq_salesorgid") ? postImage.GetAttributeValue<EntityReference>("niq_salesorgid") : null;
                                    EntityReference billTopost = postImage.Attributes.Contains("niq_billtoparty") ? postImage.GetAttributeValue<EntityReference>("niq_billtoparty") : null;
                                    EntityReference soldTopost = postImage.Attributes.Contains("niq_soldtoparty") ? postImage.GetAttributeValue<EntityReference>("niq_soldtoparty") : null;
                                    EntityReference deliverTopost = postImage.Attributes.Contains("niq_deliverytoparty") ? postImage.GetAttributeValue<EntityReference>("niq_deliverytoparty") : null;
                                    string custPopost = postImage.Attributes.Contains("niq_customerponumber") ? postImage.GetAttributeValue<string>("niq_customerponumber") : null;
                                    string billingInstpost = postImage.Attributes.Contains("niq_billinginstructions") ? postImage.GetAttributeValue<string>("niq_billinginstructions") : null;
                                    OptionSetValue billTypepost = postImage.Attributes.Contains("niq_billingtype") ? postImage.GetAttributeValue<OptionSetValue>("niq_billingtype") : null;
                                    //Gatekeeper related EP 1958, US 3149
                                    OptionSetValue opportunityTypepost = postImage.Attributes.Contains("niq_opportunitytype") ? postImage.GetAttributeValue<OptionSetValue>("niq_opportunitytype") : null;
                                    OptionSetValue existingContrActpost = postImage.Attributes.Contains("niq_existingcontractaction") ? postImage.GetAttributeValue<OptionSetValue>("niq_existingcontractaction") : null;
                                    OptionSetValue contractDecpost = postImage.Attributes.Contains("niq_contractdecision") ? postImage.GetAttributeValue<OptionSetValue>("niq_contractdecision") : null;
                                    DateTime customerPODatepost = postImage.Attributes.Contains("niq_customerpodate") ? postImage.GetAttributeValue<DateTime>("niq_customerpodate") : DateTime.MinValue;
                                    Money totalAmountpost = postImage.Attributes.Contains("totalamount") ? postImage.GetAttributeValue<Money>("totalamount") : null;
                                    //End
                                    tracing.Trace("OnUpdateOpportunity: Getting PreImage");
                                    Entity preImage = context.PreEntityImages.Contains("OpportunityImage") ? (Entity)context.PreEntityImages["OpportunityImage"] : null;

                                    if (preImage != null)
                                    {

                                        Money budgetAmountpre = preImage.Attributes.Contains("budgetamount") ? preImage.GetAttributeValue<Money>("budgetamount") : null;
                                        DateTime estCloseDatepre = preImage.Attributes.Contains("estimatedclosedate") ? preImage.GetAttributeValue<DateTime>("estimatedclosedate") : DateTime.MinValue;
                                        EntityReference custAccountpre = preImage.Attributes.Contains("parentaccountid") ? preImage.GetAttributeValue<EntityReference>("parentaccountid") : null;
                                        EntityReference salesOrgpre = preImage.Attributes.Contains("niq_salesorgid") ? preImage.GetAttributeValue<EntityReference>("niq_salesorgid") : null;
                                        EntityReference billTopre = preImage.Attributes.Contains("niq_billtoparty") ? preImage.GetAttributeValue<EntityReference>("niq_billtoparty") : null;
                                        EntityReference soldTopre = preImage.Attributes.Contains("niq_soldtoparty") ? preImage.GetAttributeValue<EntityReference>("niq_soldtoparty") : null;
                                        EntityReference deliverTopre = preImage.Attributes.Contains("niq_deliverytoparty") ? preImage.GetAttributeValue<EntityReference>("niq_deliverytoparty") : null;
                                        string custPopre = preImage.Attributes.Contains("niq_customerponumber") ? preImage.GetAttributeValue<string>("niq_customerponumber") : null;
                                        string billingInstpre = preImage.Attributes.Contains("niq_billinginstructions") ? preImage.GetAttributeValue<string>("niq_billinginstructions") : null;
                                        OptionSetValue billTypepre = preImage.Attributes.Contains("niq_billingtype") ? preImage.GetAttributeValue<OptionSetValue>("niq_billingtype") : null;
                                        //Gatekeeper related EP 1958, US 3149
                                        OptionSetValue opportunityTypepre = preImage.Attributes.Contains("niq_opportunitytype") ? preImage.GetAttributeValue<OptionSetValue>("niq_opportunitytype") : null;
                                        OptionSetValue existingContrActpre = preImage.Attributes.Contains("niq_existingcontractaction") ? preImage.GetAttributeValue<OptionSetValue>("niq_existingcontractaction") : null;
                                        OptionSetValue contractDecpre = preImage.Attributes.Contains("niq_contractdecision") ? preImage.GetAttributeValue<OptionSetValue>("niq_contractdecision") : null;
                                        DateTime customerPODatepre = preImage.Attributes.Contains("niq_customerpodate") ? preImage.GetAttributeValue<DateTime>("niq_customerpodate") : DateTime.MinValue;
                                        Money totalAmountpre = preImage.Attributes.Contains("totalamount") ? preImage.GetAttributeValue<Money>("totalamount") : null;
                                        //End
                                        Entity updOppo = new Entity("opportunity", oppoObj.Id);

                                        if ((budgetAmountpre == null || budgetAmountpost == null) && (budgetAmountpost != budgetAmountpre))
                                        {
                                            count++;
                                            updOppo["niq_budgetamountpreviousvalue"] = budgetAmountpre;
                                        }
                                        else if (budgetAmountpre != null && budgetAmountpost != null && budgetAmountpre.Value != budgetAmountpost.Value)
                                        {
                                            count++;
                                            updOppo["niq_budgetamountpreviousvalue"] = budgetAmountpre;
                                        }
                                        if ((estCloseDatepre != DateTime.MinValue) && (estCloseDatepre != estCloseDatepost))
                                        {
                                            count++;
                                            updOppo["niq_estclosedatepreviousvalue"] = estCloseDatepre;
                                        }
                                        if ((custAccountpre == null || custAccountpost == null) && (custAccountpre != custAccountpost))
                                        {
                                            count++;
                                            updOppo["niq_customeraccountpreviousvalue"] = custAccountpre;
                                        }
                                        else if (custAccountpre != null && custAccountpost != null && custAccountpre.Id != custAccountpost.Id)
                                        {
                                            count++;
                                            updOppo["niq_customeraccountpreviousvalue"] = custAccountpre;
                                        }
                                        if ((salesOrgpre == null || salesOrgpost == null) && (salesOrgpost != salesOrgpre))
                                        {
                                            count++;
                                            updOppo["niq_salesorgpreviousvalue"] = salesOrgpre;
                                        }
                                        else if (salesOrgpre != null && salesOrgpost != null && salesOrgpre.Id != salesOrgpost.Id)
                                        {
                                            count++;
                                            updOppo["niq_salesorgpreviousvalue"] = salesOrgpre;
                                        }
                                        if ((soldTopre == null || soldTopost == null) && (soldTopost != soldTopre))
                                        {
                                            count++;
                                            updOppo["niq_soldtopartypreviousvalue"] = soldTopre;
                                        }
                                        else if (soldTopre != null && soldTopost != null && soldTopost.Id != soldTopre.Id)
                                        {
                                            count++;
                                            updOppo["niq_soldtopartypreviousvalue"] = soldTopre;
                                        }
                                        if ((billTopre == null || billTopost == null) && (billTopost != billTopre))
                                        {
                                            count++;
                                            updOppo["niq_billtopartypreviousvalue"] = billTopre;
                                        }
                                        else if (billTopost != null && billTopre != null && billTopre.Id != billTopost.Id)
                                        {
                                            count++;
                                            updOppo["niq_billtopartypreviousvalue"] = billTopre;
                                        }
                                        if ((deliverTopre == null || deliverTopost == null) && (deliverTopost != deliverTopre))
                                        {
                                            count++;
                                            updOppo["niq_delivertopartypreviousvalue"] = deliverTopre;
                                        }
                                        else if (deliverTopost != null && deliverTopre != null && deliverTopre.Id != deliverTopost.Id)
                                        {
                                            count++;
                                            updOppo["niq_delivertopartypreviousvalue"] = deliverTopre;
                                        }
                                        if ((custPopre == null || custPopost == null) && (custPopost != custPopre))
                                        {
                                            count++;
                                            updOppo["niq_customerponumberpreviousvalue"] = custPopre;
                                        }
                                        else if (custPopost != null && custPopre != null && custPopre != custPopost)
                                        {
                                            count++;
                                            updOppo["niq_customerponumberpreviousvalue"] = custPopre;
                                        }
                                        if ((billingInstpre == null || billingInstpost == null) && (billingInstpre != billingInstpost))
                                        {
                                            count++;
                                            updOppo["niq_billinginstructionspreviousvalue"] = billingInstpre;
                                        }
                                        else if (billingInstpost != null && billingInstpre != null && billingInstpre != billingInstpost)
                                        {
                                            count++;
                                            updOppo["niq_billinginstructionspreviousvalue"] = billingInstpre;
                                        }
                                        if ((billTypepre == null || billTypepost == null) && (billTypepost != billTypepre))
                                        {
                                            count++;
                                            updOppo["niq_billingtypepreviousvalue"] = billTypepre;
                                        }
                                        else if (billTypepost != null && billTypepre != null && billTypepre.Value != billTypepost.Value)
                                        {
                                            count++;
                                            updOppo["niq_billingtypepreviousvalue"] = billTypepre;
                                        }

                                        //Gatekeeper
                                        if (((opportunityTypepre == null || opportunityTypepost == null) && (opportunityTypepre != opportunityTypepost)) ||
                                            (opportunityTypepost != null && opportunityTypepre != null && opportunityTypepre.Value != opportunityTypepost.Value))
                                        {
                                            count++;
                                            updOppo["niq_opportunitytypepreviousvalue"] = opportunityTypepre;
                                        }
                                        if (((existingContrActpre == null || existingContrActpost == null) && (existingContrActpre != existingContrActpost)) ||
                                            (existingContrActpost != null && existingContrActpre != null && existingContrActpre.Value != existingContrActpost.Value))
                                        {
                                            count++;
                                            updOppo["niq_existingcontractactionpreviousvalue"] = existingContrActpre;
                                        }
                                        if (((contractDecpre == null || contractDecpost == null) && (contractDecpre != contractDecpost)) ||
                                            (contractDecpost != null && contractDecpre != null && contractDecpre.Value != contractDecpost.Value))
                                        {
                                            count++;
                                            updOppo["niq_contractdecisionpreviousvalue"] = contractDecpre;
                                        }
                                        if (((customerPODatepre == null || customerPODatepost == null) && (customerPODatepre != customerPODatepost)) ||
                                            (customerPODatepost != null && customerPODatepre != null && customerPODatepre != customerPODatepost))
                                        {
                                            count++;
                                            if (customerPODatepre != DateTime.MinValue)
                                                updOppo["niq_customerpodatepreviousvalue"] = customerPODatepre;
                                            else
                                                updOppo["niq_customerpodatepreviousvalue"] = null;
                                        }
                                        if (((totalAmountpre == null || totalAmountpost == null) && (totalAmountpre != totalAmountpost)) ||
                                            (totalAmountpost != null && totalAmountpre != null && totalAmountpre.Value != totalAmountpost.Value))
                                        {
                                            count++;
                                            updOppo["niq_totalamountpreviousvalue"] = totalAmountpre;
                                        }
                                        //End
                                        tracing.Trace("OnUpdateOpportunity:Checking Count.");
                                        if (count > 0)
                                        {
                                            tracing.Trace("OnUpdateOpportunity: Updating the values in Opportunity");
                                            service.Update(updOppo);
                                            tracing.Trace("OnUpdateOpportunity: Opportunity Updated successful");
                                        }


                                    }

                                }
                            }


                        }
                    }

                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
