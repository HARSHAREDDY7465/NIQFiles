﻿using System;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Collections.Generic;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_SyncLinkedInFieldMapping : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity entityObj = (Entity)context.InputParameters["Target"];
                    if (entityObj != null && entityObj.Id != Guid.Empty)
                    {
                        tracing.Trace("OnUpdate_SyncLinkedInFieldMapping: Entity: " + entityObj.LogicalName);
                        tracing.Trace("OnUpdate_SyncLinkedInFieldMapping: ID: " + entityObj.Id.ToString());

                        // KeyValuePair<String, Object> attribute = entityObj.Attributes.FirstOrDefault();
                        Entity updEntity = null;
                        foreach (var attribute in entityObj.Attributes)
                        {
                            tracing.Trace("OnUpdate_SyncLinkedInFieldMapping: Attribute Field: " + attribute.Key);
                            tracing.Trace("OnUpdate_SyncLinkedInFieldMapping: Attribute Value: " + attribute.Value);

                            Entity resultLinkedInData = GetLinkedInMappingData(service, tracing, entityObj.LogicalName, attribute.Key.ToString(), (attribute.Value != null ? attribute.Value.ToString(): string.Empty));
                            if (resultLinkedInData.Contains("niq_dynamicsfieldtype"))
                            {
                                if (resultLinkedInData["niq_dynamicsfieldtype"] != null && resultLinkedInData["niq_dynamicsfieldtype"].ToString() == "OptionSet")
                                {
                                    tracing.Trace("OnUpdate_SyncLinkedInFieldMapping: Entering Optionset");
                                    if (resultLinkedInData["niq_dynamicsfieldname"] != null && resultLinkedInData["niq_dynamicsschemavalue"] != null)
                                    {
                                        string val = resultLinkedInData["niq_dynamicsschemavalue"].ToString();
                                        if (val.Contains(","))
                                        {
                                            val = val.Replace(",", "");
                                        }

                                        if (updEntity==null) updEntity = new Entity(entityObj.LogicalName, entityObj.Id);
                                        
                                        updEntity[resultLinkedInData["niq_dynamicsfieldname"].ToString()] = new OptionSetValue(Convert.ToInt32(val));
                                       
                                        tracing.Trace("OnUpdate_SyncLinkedInFieldMapping: " + resultLinkedInData["niq_dynamicsfieldname"].ToString() + "field added");
                                    }
                                }
                                else if (resultLinkedInData["niq_dynamicsfieldtype"] != null && resultLinkedInData["niq_dynamicsfieldtype"].ToString().Contains("LookUp"))
                                {
                                    string lookupEntity = string.Empty;
                                    string lookupAltKey = string.Empty;
                                    string fieldtype = resultLinkedInData["niq_dynamicsfieldtype"].ToString().Replace("LookUp", "");
                                    tracing.Trace("OnUpdate_SyncLinkedInFieldMapping: fieldtype: " + fieldtype);
                                    if (fieldtype.Contains(","))
                                    {
                                        string[] values = fieldtype.Split(',');
                                        for (int i = 0; i < values.Length; i++)
                                        {
                                            values[i] = values[i].Trim();
                                        }
                                        lookupEntity = values[0].TrimStart('(');
                                        lookupAltKey = values[1].TrimEnd(')');
                                    }

                                    tracing.Trace("OnUpdate_SyncLinkedInFieldMapping: lookupEntity: " + lookupEntity);
                                    tracing.Trace("OnUpdate_SyncLinkedInFieldMapping: lookupAltKey: " + lookupAltKey);

                                    if (!string.IsNullOrEmpty(lookupAltKey))
                                    {
                                        if (resultLinkedInData["niq_dynamicsfieldname"] != null && resultLinkedInData["niq_dynamicsschemavalue"] != null)
                                        {
                                            if (updEntity == null) updEntity = new Entity(entityObj.LogicalName, entityObj.Id);
                                           
                                            updEntity[resultLinkedInData["niq_dynamicsfieldname"].ToString()] = new EntityReference(lookupEntity, lookupAltKey, resultLinkedInData["niq_dynamicsschemavalue"]);
                                           
                                            tracing.Trace("OnUpdate_SyncLinkedInFieldMapping: " + lookupEntity + " field added");
                                        }
                                    }
                                    else
                                    {
                                        if (resultLinkedInData["niq_dynamicsdisplayvalue"] != null && resultLinkedInData["niq_dynamicsschemavalue"] != null && resultLinkedInData["niq_dynamicsfieldname"] != null)
                                        {
                                            Guid lookupGuid = GetCountryGuid(service, tracing, resultLinkedInData["niq_dynamicsdisplayvalue"].ToString(), resultLinkedInData["niq_dynamicsschemavalue"].ToString());
                                            if (lookupGuid != null)
                                            {
                                                if (updEntity == null) updEntity = new Entity(entityObj.LogicalName, entityObj.Id);
                                                
                                                updEntity[resultLinkedInData["niq_dynamicsfieldname"].ToString()] = new EntityReference(lookupEntity, lookupGuid);
                                                
                                                tracing.Trace("OnUpdate_SyncLinkedInFieldMapping: " + lookupEntity + " field added");
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (updEntity != null)
                            service.Update(updEntity);
                        tracing.Trace("OnUpdate_SyncLinkedInFieldMapping: All fields updated successfully");
                    }
                }
            }
            catch (Exception ex)
            {
                tracing.Trace("Exception in OnUpdate_SyncLinkedInFieldMapping: " + ex.Message);
            }
        }

        public Entity GetLinkedInMappingData(IOrganizationService service, ITracingService tracing, string entityname, string fieldFromLinkedin, string linkedinFieldvalue)
        {
            Entity LinkedinFM = new Entity();
            try
            {
                if (entityname != null && fieldFromLinkedin != null && linkedinFieldvalue != null && linkedinFieldvalue != string.Empty)
                {
                    var query1 = new QueryExpression("niq_linkedindynamicsmapping")
                    {
                        ColumnSet = new ColumnSet(true),
                        Criteria =
                            {
                                Conditions =
                                {
                                    new ConditionExpression("niq_entityname", ConditionOperator.Equal, entityname),
                                    new ConditionExpression("niq_linkedinfieldname", ConditionOperator.Equal, fieldFromLinkedin),
                                    new ConditionExpression("niq_linkedinvalue", ConditionOperator.Equal, linkedinFieldvalue),
                                }
                            }
                    };
                    EntityCollection entitylist = service.RetrieveMultiple(query1);
                    if (entitylist.Entities.Count>0 && entitylist.Entities[0] != null)
                    {
                        LinkedinFM = entitylist.Entities.FirstOrDefault();
                        tracing.Trace("GetLinkedInMappingData: dynamicsDisplayValue: " + LinkedinFM.Attributes["niq_dynamicsdisplayvalue"]);
                        tracing.Trace("GetLinkedInMappingData: dynamicsSchemaValue: " + LinkedinFM.Attributes["niq_dynamicsschemavalue"]);
                        tracing.Trace("GetLinkedInMappingData: dynamicsFieldType: " + LinkedinFM.Attributes["niq_dynamicsfieldtype"]);
                        tracing.Trace("GetLinkedInMappingData: dynamicsField: " + LinkedinFM.Attributes["niq_dynamicsfieldname"]);
                    }
                }
            }
            catch (Exception ex)
            {
                tracing.Trace("Exception in GetLinkedInMappingData: " + ex.Message);
                return null;
            }
            return LinkedinFM;
        }

        public Guid GetCountryGuid(IOrganizationService service, ITracingService tracing, string countryName, string countryCode)
        {
            Guid countryGuid = new Guid();
            try
            {
                if (countryName != null && countryCode != null)
                {
                    var query1 = new QueryExpression("niq_country")
                    {
                        ColumnSet = new ColumnSet(true),
                        Criteria =
                            {
                                Conditions =
                                {
                                    new ConditionExpression("niq_name", ConditionOperator.Equal, countryName),
                                    new ConditionExpression("niq_countrycode", ConditionOperator.Equal, countryCode),
                                }
                            }
                    };
                    var entitylist = service.RetrieveMultiple(query1);
                    if (entitylist.Entities[0] != null)
                    {
                        countryGuid = entitylist.Entities[0].Id;
                        tracing.Trace("GetCountryGuid: countryGuid: " + countryGuid);
                    }
                }

            }
            catch (Exception ex)
            {
                tracing.Trace("Exception in GetCountryGuid: " + ex.Message);
            }
            return countryGuid;
        }

    }
}
