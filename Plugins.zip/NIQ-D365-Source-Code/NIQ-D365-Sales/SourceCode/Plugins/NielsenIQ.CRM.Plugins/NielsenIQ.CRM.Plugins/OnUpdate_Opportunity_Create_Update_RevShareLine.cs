﻿using System;
using Microsoft.Xrm.Sdk;
using NielsenIQ.CRM.Plugins.Helper;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;
using Microsoft.SqlServer.Server;
using Newtonsoft.Json.Linq;
using System.IdentityModel.Metadata;
using System.Windows;
using System.Xml.Linq;


// Create/Update Rev Share Line
namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Opportunity_Create_Update_RevShareLine : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {

            //Extract the tracing service for use in debugging sandboxed plug-ins.
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            // Obtain the execution context from the service provider.
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            // Obtain the organization service reference.
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            string fetchChildOpp = string.Empty;
            EntityCollection childOppColl = null;
            Entity preImage = null;
            Entity postImage = null;
            Entity existingRevShareLine = null;
            try
            {
                // When Contract start/End Date,Total Amount and Main quote is Updated is updated
                if (context.MessageName.Equals("Update", StringComparison.OrdinalIgnoreCase)
                    && context.PrimaryEntityName.Equals("opportunity", StringComparison.OrdinalIgnoreCase))
                {
                    if (context.PreEntityImages.Contains("PreImage"))
                    {
                        //Get PreImage
                        preImage = context.PreEntityImages["PreImage"];
                    }
                    if (context.PostEntityImages.Contains("PostImage"))
                    {
                        //Get PostImage
                        postImage = context.PostEntityImages["PostImage"];
                    }
                    //Get Pre and Post image of Host opportunity
                    EntityReference hostOpportunityPost = postImage.Contains("niq_hostopportunity") && postImage.Attributes["niq_hostopportunity"] != null ? postImage.GetAttributeValue<EntityReference>("niq_hostopportunity") : null;
                    EntityReference hostOpportunityPre = preImage.Contains("niq_hostopportunity") && preImage.Attributes["niq_hostopportunity"] != null ? preImage.GetAttributeValue<EntityReference>("niq_hostopportunity") : null;

                    if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                    {
                        // Get Target Entity
                        Entity oppoObj = (Entity)context.InputParameters["Target"];

                        // Get Host Opportunity
                        EntityReference hostOppLookUp = postImage.Contains("niq_hostopportunity") && postImage.Attributes["niq_hostopportunity"] != null ? postImage.GetAttributeValue<EntityReference>("niq_hostopportunity") : null;
                        tracing.Trace(hostOppLookUp == null ? "Host opportunity" : "Child Opportunity");
                        if (hostOppLookUp != null)
                        {

                            fetchChildOpp = CreateRevShareLine.IsOpportunityEditable(service, hostOppLookUp.Id, tracing);
                            // Check host opportunity is editable
                            Entity hostOpportunity = CreateRevShareLine.IsValidHostOppWithData(service, fetchChildOpp, tracing);

                            //if (hostOpportunity == null) { return; }
                            //tracing.Trace("Host Opportunity :" + hostOpportunity.Id);
                            tracing.Trace("context.Depth:" + context.Depth);
                            //On Update of Child opportunity Contract start/end date, Main Quote
                            if (context.Depth == 1)
                            {
                                // If Main Quote is changed on Host Opportunity
                                if (oppoObj.Contains("niq_mainquoteid") && oppoObj.Attributes["niq_mainquoteid"] != null)
                                {
                                    tracing.Trace("Main Quote has changed on Child Opportunity");
                                    if (preImage != null)
                                    {
                                        tracing.Trace("Main Quote Has Changed on Child Opportunity");
                                        //Access fields from Pre-Image
                                        EntityReference mainQuotePre = preImage.Contains("niq_mainquoteid") && preImage.Attributes["niq_mainquoteid"] != null ? preImage.GetAttributeValue<EntityReference>("niq_mainquoteid") : null;

                                        if (mainQuotePre != null)
                                        {
                                            string fetchXml = $@"
                                                <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                <entity name='quotedetail'>
                                                    <filter type='and'>
                                                    <condition attribute='niq_correspondingchildopportunity' operator='eq'  value='{oppoObj.Id}' />
                                                    <condition attribute='niq_isrevshareline' operator='eq' value='1' />
                                                    </filter>
                                                </entity>
                                                </fetch>";

                                            EntityCollection quoteDetails = service.RetrieveMultiple(new FetchExpression(fetchXml));
                                            if (quoteDetails.Entities.Count > 0)
                                            {

                                                foreach (var entity in quoteDetails.Entities)
                                                {
                                                    // Delete the quotedetail record
                                                    service.Delete(entity.LogicalName, entity.Id);
                                                }
                                            }
                                        }
                                    }
                                    if (postImage != null && hostOpportunity != null)
                                    {
                                        tracing.Trace("Create Rev Share line for New main quote");
                                        postImage = context.PostEntityImages["PostImage"];
                                        // Access fields from Post-Image
                                        EntityReference mainQuotePost = postImage.Contains("niq_mainquoteid") && postImage.Attributes["niq_mainquoteid"] != null ? postImage.GetAttributeValue<EntityReference>("niq_mainquoteid") : null; ;
                                        if (mainQuotePost != null)
                                        {
                                            Entity childQuote = new Entity(mainQuotePost.LogicalName, mainQuotePost.Id);
                                            Entity opp = CreateRevShareLine.GetOppOfQuote(service, childQuote, tracing);
                                            if (opp != null)
                                            {
                                                EntityReference oppRef = opp.GetAttributeValue<EntityReference>("niq_hostopportunity");
                                                //hostOpportunity = new Entity(oppRef.LogicalName, oppRef.Id);
                                                childOppColl = CreateRevShareLine.GetChildOpportunity(service, hostOpportunity, tracing, oppoObj);
                                                //if we want to trigger from child opportunity pass "true" at last parameter
                                                CreateRevShareLine.ProcessToCreateRevShareLineFromHostOpportunity(service, hostOpportunity, childOppColl, tracing, true);
                                                tracing.Trace("New Main quote Rev share line created");
                                            }
                                        }
                                    }
                                }
                                if (oppoObj.Contains("niq_hostopportunity") && hostOpportunity != null)
                                {

                                    if (hostOpportunityPost != null)
                                    {
                                        tracing.Trace("Host Opportunity has been changed");
                                        childOppColl = CreateRevShareLine.GetChildOpportunity(service, hostOpportunity, tracing, oppoObj);
                                        CreateRevShareLine.ProcessToCreateRevShareLineFromHostOpportunity(service, hostOpportunity, childOppColl, tracing, true);
                                    }
                                }

                            }
                            if (context.Depth == 3)
                            {
                                //Delete Rev Share line of host opportunity if child opp is lost
                                if (oppoObj.Contains("statecode") && oppoObj.Attributes["statecode"] != null)
                                {
                                    tracing.Trace("Status of Child Opp has changed");
                                    OptionSetValue stateCode = oppoObj.GetAttributeValue<OptionSetValue>("statecode");
                                    Entity hostOpp = new Entity(hostOppLookUp.LogicalName, hostOppLookUp.Id);
                                    tracing.Trace("Status code of Child Opp:" + stateCode.Value);
                                    if (stateCode.Value == 2) //2 is lost
                                    {
                                        Entity revShareLine = CreateRevShareLine.GetRevShareLineOfHostOpp(service, oppoObj, hostOpp, tracing);

                                        if (revShareLine != null)
                                        {
                                            tracing.Trace("Rev share line record found");
                                            service.Delete(revShareLine.LogicalName, revShareLine.Id);
                                            tracing.Trace("Rev share line record deleted successfully");
                                        }
                                    }
                                }
                                //tracing.Trace("Contains:" + oppoObj.Contains("niq_contractenddate"));
                                //tracing.Trace("Contains:" + oppoObj.Attributes["niq_contractstartdate"]);
                                //tracing.Trace("Contains niq_contractenddate:" + oppoObj.Attributes["niq_contractenddate"]);
                                // tracing.Trace("Contains niq_contractstartdate:" + oppoObj.Attributes["niq_contractstartdate"]);
                                // if Contrcta start/end date is null then delete all the Rev share line from host opportunity
                                else if ((oppoObj.Contains("niq_contractenddate") && oppoObj.Attributes["niq_contractenddate"] == null) || ((oppoObj.Contains("niq_contractstartdate") && oppoObj.Attributes["niq_contractstartdate"] == null)))
                                {
                                    tracing.Trace("Contract start/end date is null");
                                    string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'> 
                                                        <entity name='quotedetail'>                                                      
                                                        <filter type='and'>                                                       
                                                        <condition attribute='niq_correspondingchildopportunity' operator='eq' value='{oppoObj.Id}' />                                                     
                                                        <condition attribute='niq_isrevshareline' operator='eq' value='1' />                                                  
                                                        </filter>                       
                                                        </entity>                                                  
                                                        </fetch>";

                                    EntityCollection quoteDetails = service.RetrieveMultiple(new FetchExpression(fetchXml));
                                    tracing.Trace("quoteDetails to delete:" + quoteDetails.Entities.Count);
                                    if (quoteDetails.Entities.Count > 0)
                                    {
                                        foreach (var entity in quoteDetails.Entities)
                                        {    // Delete the quotedetail record                   
                                            service.Delete(entity.LogicalName, entity.Id);
                                            tracing.Trace("quoteDetails(rev share) deleted successfully");
                                        }
                                    }
                                }
                            }
                            if (context.Depth == 2)
                            {
                                if (oppoObj.Contains("niq_contractenddate") && oppoObj.Attributes["niq_contractenddate"] != null && hostOpportunity != null)
                                {
                                    tracing.Trace("Contract end Date has changed");
                                    childOppColl = CreateRevShareLine.GetChildOpportunity(service, hostOpportunity, tracing, oppoObj);
                                    //if we want to trigger from child opportunity pass "true" at last parameter
                                    CreateRevShareLine.ProcessToCreateRevShareLineFromHostOpportunity(service, hostOpportunity, childOppColl, tracing, true);
                                }
                                else if (oppoObj.Contains("niq_contractstartdate") && oppoObj.Attributes["niq_contractstartdate"] != null && hostOpportunity != null)
                                {
                                    tracing.Trace("Contract start Date has changed");
                                    childOppColl = CreateRevShareLine.GetChildOpportunity(service, hostOpportunity, tracing, oppoObj);
                                    //if we want to trigger from child opportunity pass "true" at last parameter
                                    CreateRevShareLine.ProcessToCreateRevShareLineFromHostOpportunity(service, hostOpportunity, childOppColl, tracing, true);
                                }
                                else if (oppoObj.Contains("totalamount") && hostOpportunity != null)
                                {
                                    tracing.Trace("Total Amount Contains Value.");
                                    childOppColl = CreateRevShareLine.GetChildOpportunity(service, hostOpportunity, tracing, oppoObj);
                                    //if we want to trigger from child opportunity pass "true" at last parameter
                                    CreateRevShareLine.ProcessToCreateRevShareLineFromHostOpportunity(service, hostOpportunity, childOppColl, tracing, true);
                                }
                                // if Contrcta start/end date is null then delete all the Rev share line from host opportunity
                                //else if ((oppoObj.Contains("niq_contractenddate") && oppoObj.Attributes["niq_contractenddate"] == null) || ((oppoObj.Contains("niq_contractstartdate") && oppoObj.Attributes["niq_contractstartdate"] == null)))
                                //{
                                //    tracing.Trace("Contract start/end date is null");
                                //    string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'> 
                                //                        <entity name='quotedetail'>                                                      
                                //                        <filter type='and'>                                                       
                                //                        <condition attribute='niq_correspondingchildopportunity' operator='eq' value='{oppoObj.Id}' />                                                     
                                //                        <condition attribute='niq_isrevshareline' operator='eq' value='1' />                                                  
                                //                        </filter>                       
                                //                        </entity>                                                  
                                //                        </fetch>";

                                //    EntityCollection quoteDetails = service.RetrieveMultiple(new FetchExpression(fetchXml));
                                //    tracing.Trace("quoteDetails to delete:" + quoteDetails.Entities.Count);
                                //    if (quoteDetails.Entities.Count > 0)
                                //    {
                                //        foreach (var entity in quoteDetails.Entities)
                                //        {    // Delete the quotedetail record                   
                                //            service.Delete(entity.LogicalName, entity.Id);
                                //            tracing.Trace("quoteDetails(rev share) deleted successfully");
                                //        }
                                //    }
                                //}
                            }
                            else if (context.Depth == 5 || context.Depth == 1)
                            {
                                if (oppoObj.Contains("niq_contractenddate") && oppoObj.Attributes["niq_contractenddate"] != null && hostOpportunity != null)
                                {
                                    tracing.Trace("Contract end Date has changed");
                                    childOppColl = CreateRevShareLine.GetChildOpportunity(service, hostOpportunity, tracing, oppoObj);
                                    //if we want to trigger from child opportunity pass "true" at last parameter
                                    CreateRevShareLine.ProcessToCreateRevShareLineFromHostOpportunity(service, hostOpportunity, childOppColl, tracing, true);
                                }
                                else if (oppoObj.Contains("niq_contractstartdate") && oppoObj.Attributes["niq_contractstartdate"] != null && hostOpportunity != null)
                                {
                                    tracing.Trace("Contract start Date has changed");
                                    childOppColl = CreateRevShareLine.GetChildOpportunity(service, hostOpportunity, tracing, oppoObj);
                                    //if we want to trigger from child opportunity pass "true" at last parameter
                                    CreateRevShareLine.ProcessToCreateRevShareLineFromHostOpportunity(service, hostOpportunity, childOppColl, tracing, true);
                                }
                                else if (oppoObj.Contains("totalamount") && hostOpportunity != null)
                                {
                                    tracing.Trace("Total Amount Contains Value.");
                                    childOppColl = CreateRevShareLine.GetChildOpportunity(service, hostOpportunity, tracing, oppoObj);
                                    //if we want to trigger from child opportunity pass "true" at last parameter
                                    CreateRevShareLine.ProcessToCreateRevShareLineFromHostOpportunity(service, hostOpportunity, childOppColl, tracing, true);
                                }
                            }
                            //else if (context.Depth == 4)
                            //{

                            //    if (oppoObj.Contains("totalamount") && hostOpportunity != null && hostOpportunity.Contains("niq_automatedopportunity") && hostOpportunity.GetAttributeValue<bool>("niq_automatedopportunity"))
                            //    {
                            //        tracing.Trace("Total Amount Contains Value.");
                            //        childOppColl = CreateRevShareLine.GetChildOpportunity(service, hostOpportunity, tracing, oppoObj);
                            //        //if we want to trigger from child opportunity pass "true" at last parameter
                            //        CreateRevShareLine.ProcessToCreateRevShareLineFromHostOpportunity(service, hostOpportunity, childOppColl, tracing, true);
                            //    }
                            //}

                        }
                        else if (hostOpportunityPre != null && hostOpportunityPost == null)
                        {
                            tracing.Trace("Host Opportunity is Null.");
                            existingRevShareLine = CreateRevShareLine.RetrieveExistingRevShare(service, oppoObj, tracing);
                            if (existingRevShareLine != null)
                            {
                                tracing.Trace("Found Existing Rev Share Line and deleting it.");
                                service.Delete(existingRevShareLine.LogicalName, existingRevShareLine.Id);
                                tracing.Trace("Existing Rev Share Line deleted.");
                            }
                        }
                        else
                        {
                            tracing.Trace("Main Quote Has Changed on Host Opportunity");// change
                            if (context.Depth == 1 && oppoObj.Contains("niq_mainquoteid") && preImage != null)
                            {
                                // Access fields from Pre-Image
                                EntityReference mainQuotePre = preImage.Contains("niq_mainquoteid") && preImage.Contains("niq_mainquoteid") ? preImage.GetAttributeValue<EntityReference>("niq_mainquoteid") : null;
                                if (mainQuotePre != null)
                                {
                                    EntityReference newQuoteRef = oppoObj.Contains("niq_mainquoteid") && oppoObj.Attributes["niq_mainquoteid"] != null ? oppoObj.GetAttributeValue<EntityReference>("niq_mainquoteid") : null;

                                    // Build the FetchXML query dynamically using the old quoteid                                            
                                    string fetchXml = $@"                                                            
                                                 <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>                                                            
                                                 <entity name='quotedetail'>                                                               
                                                 <attribute name='quoteid' />                                                            
                                                 <filter type='and'>                                                                 
                                                 <condition attribute='niq_correspondingchildopportunity' operator='not-null' />                                          
                                                 <condition attribute='quoteid' operator='eq' uiname='Quote 1_Host_Opportunity' uitype='quote' value='{mainQuotePre.Id}' />     
                                                 <condition attribute='niq_isrevshareline' operator='eq' value='1' />                                                          
                                                 </filter>                                        
                                                 </entity>                                                
                                                 </fetch>";
                                    tracing.Trace($"FetchXML query generated: {fetchXml}");
                                    // Execute the FetchXML query to get the quotedetail records                                        
                                    EntityCollection quoteDetails = service.RetrieveMultiple(new FetchExpression(fetchXml));
                                    tracing.Trace($"Retrieved {quoteDetails.Entities.Count} quotedetail records.");
                                    // Check if any quote details were returned                                    
                                    if (quoteDetails.Entities.Count > 0)
                                    {
                                        foreach (Entity quoteDetail in quoteDetails.Entities)
                                        {
                                            tracing.Trace($"Processing quotedetail with ID: {quoteDetail.Id}");
                                            if (newQuoteRef != null)
                                            {
                                                // Update the quoteid to the new value                                                  
                                                quoteDetail["quoteid"] = new EntityReference(newQuoteRef.LogicalName, newQuoteRef.Id);
                                                // Update the quotedetail record                                                    
                                                service.Update(quoteDetail);
                                                tracing.Trace($"Updated quoteid in quotedetail with ID: {quoteDetail.Id}");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        tracing.Trace("No quotedetail records found for the provided quoteid.");
                                    }

                                }
                                if (postImage != null && context.Stage == 40)
                                {
                                    tracing.Trace("Main Quote Has Changed on Host Opportunity");
                                    // Get Oppertunity entity
                                    Entity hostOpp = new Entity(postImage.LogicalName, postImage.Id);
                                    if (hostOpp != null)
                                    {
                                        oppoObj = null;
                                        fetchChildOpp = CreateRevShareLine.IsOpportunityEditable(service, hostOpp.Id, tracing);
                                        Entity hostOpportunity = CreateRevShareLine.IsValidHostOppWithData(service, fetchChildOpp, tracing);
                                        if (hostOpportunity != null)
                                        {
                                            childOppColl = CreateRevShareLine.GetChildOpportunity(service, hostOpp, tracing, oppoObj);
                                            //if we want to trigger from child opportunity pass "true" at last parameter
                                            CreateRevShareLine.ProcessToCreateRevShareLineFromHostOpportunity(service, hostOpp, childOppColl, tracing, true);
                                            tracing.Trace("New Main quote Rev share line created on Host Opportunity");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }


                tracing.Trace("Message Before Associate : " + context.MessageName.ToLower());
                if (context.MessageName.ToLower() == "associate" && context.Depth == 1)
                {
                    tracing.Trace("Child Associate block: ");
                    Relationship relationShipName = (Relationship)context.InputParameters["Relationship"];

                    tracing.Trace("Relationship Name: " + relationShipName);
                    if (relationShipName.SchemaName == "niq_opportunity_HostOpportunity_opportunity")
                    {
                        EntityReference target = (EntityReference)context.InputParameters["Target"];
                        EntityReferenceCollection relatedEntities = context.InputParameters["RelatedEntities"] as EntityReferenceCollection;
                        //tracing.Trace("Relationship Name: 1");
                        foreach (var relatedEntity in relatedEntities)
                        {
                            if (relatedEntity.LogicalName != "opportunity") { return; }
                            ;
                            // Get the ID of the associated record
                            Guid associatedChildRecordId = relatedEntity.Id;
                            tracing.Trace("Associate Child Record ID: " + associatedChildRecordId);
                            // Get the logical name of the associated entity
                            string associatedEntityLogicalName = relatedEntity.LogicalName;
                            Entity associatedChildOppEnt = service.Retrieve("opportunity", associatedChildRecordId, new Microsoft.Xrm.Sdk.Query.ColumnSet("niq_hostopportunity"));
                            EntityReference associateHostOppLookUp = associatedChildOppEnt.GetAttributeValue<EntityReference>("niq_hostopportunity");
                            tracing.Trace("Associate Host opportunity Lookup: " + associateHostOppLookUp);
                            if (associateHostOppLookUp == null) { return; }
                            tracing.Trace("Associate Host Record ID: " + associateHostOppLookUp.Id);
                            fetchChildOpp = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                              <entity name='opportunity'>
                                <attribute name='name' />
                                <attribute name='niq_stage' />
                                <attribute name='totalamount' />
                                <attribute name='opportunityid' />
                                <order attribute='estimatedclosedate' descending='false' />
                                <order attribute='customerid' descending='false' />
                                <filter type='and'>
                                   <condition attribute='niq_revenuesharedeal' operator='eq' value='1' />
                                  <condition attribute='opportunityid' operator='eq' value='{" + associateHostOppLookUp.Id + @"}' />
                                </filter>
                              </entity>
                            </fetch>";
                            Entity associateHostOpportunity = CreateRevShareLine.IsValidHostOppWithData(service, fetchChildOpp, tracing);

                            tracing.Trace("Associate Host Opportunity :" + associateHostOpportunity);
                            if (associateHostOpportunity == null) { return; }
                            tracing.Trace("Host Opportunity :" + associateHostOpportunity.Id);
                            childOppColl = CreateRevShareLine.GetChildOpportunity(service, associateHostOpportunity, tracing, associatedChildOppEnt);
                            //if we want to trigger from child opportunity pass "true" at last parameter
                            CreateRevShareLine.ProcessToCreateRevShareLineFromHostOpportunity(service, associateHostOpportunity, childOppColl, tracing, true);
                        }
                    }
                }

                //DYNCRM-30737 -Trigger on Discount is missing so added to trigger it form Quote level!
                tracing.Trace("Message Before Quote : " + context.MessageName.ToLower());
                tracing.Trace($"Plugin triggered on {context.PrimaryEntityName} at depth: {context.Depth}");
                if (context.Depth != 4)
                {
                    tracing.Trace("Skipping recursive execution.");
                    return;
                }
                if (context.MessageName.Equals("Update", StringComparison.OrdinalIgnoreCase) &&
                    context.PrimaryEntityName.Equals("quote", StringComparison.OrdinalIgnoreCase))
                {
                    tracing.Trace("Going inside the Discount check as totalamount is same");
                    Entity target = (Entity)context.InputParameters["Target"];
                    Entity pretarget = context.PreEntityImages.Contains("PreImage") ? context.PreEntityImages["PreImage"] : null;
                    Entity quote = service.Retrieve("quote", target.Id, new ColumnSet("opportunityid", "niq_discount"));
                    EntityReference oppRef = quote.GetAttributeValue<EntityReference>("opportunityid");

                    tracing.Trace("Opportunity reference found: " + oppRef.Id.ToString());

                    Entity opportunity = service.Retrieve("opportunity", oppRef.Id, new ColumnSet("niq_hostopportunity"));


                    tracing.Trace("Retrieved opportunity: " + opportunity.Id.ToString());

                    EntityReference associateHostOppLookUp = opportunity.GetAttributeValue<EntityReference>("niq_hostopportunity");

                    tracing.Trace("Host opportunity lookup: " + associateHostOppLookUp.Id.ToString());


                    Entity hostOpportunity = null;
                    if (target.Contains("niq_discount"))
                    {
                        tracing.Trace("Depth: " + context.Depth);

                        decimal? newDiscount = target.GetAttributeValue<decimal?>("niq_discount");
                        decimal? oldDiscount = pretarget?.GetAttributeValue<decimal?>("niq_discount");
                        tracing.Trace("New discount (Target): " + (newDiscount.HasValue ? newDiscount.Value.ToString() : "null"));
                        tracing.Trace("Old discount (PreImage): " + (oldDiscount.HasValue ? oldDiscount.Value.ToString() : "null"));

                        if (newDiscount != oldDiscount)
                        {
                            tracing.Trace("Quote discount changed, proceeding with host opportunity logic.");

                            if (associateHostOppLookUp != null)
                            {
                                Guid hostOppId = associateHostOppLookUp.Id;
                                fetchChildOpp = CreateRevShareLine.IsOpportunityEditable(service, hostOppId, tracing);

                                Entity hostOpp = CreateRevShareLine.IsValidHostOppWithData(service, fetchChildOpp, tracing);

                                tracing.Trace("Host opportunity retrieved: " + hostOpp.Id.ToString());
                                if (hostOpp != null)
                                {
                                    EntityReference oppRef1 = quote.GetAttributeValue<EntityReference>("opportunityid");

                                    // Retrieve the full child opportunity entity
                                    Entity childOpp = service.Retrieve("opportunity", oppRef1.Id, new ColumnSet(true));

                                    EntityCollection childOppColls = CreateRevShareLine.GetChildOpportunity(service, hostOpportunity, tracing, childOpp);
                                    var childIds = string.Join(", ", childOppColls.Entities.Select(e => e.Id.ToString()));
                                    tracing.Trace("Child Opportunity Ids: " + childIds);

                                    foreach (var childOpps in childOppColls.Entities)
                                    {
                                        tracing.Trace("Processing child opportunity with Id: " + childOpps.Id);

                                        CreateRevShareLine.UpdateExtingRevShareLine(service, childOpps, tracing);

                                        tracing.Trace("Finished UpdateExtingRevShareLine for child opportunity Id: " + childOpps.Id);
                                    }
                                    //CreateRevShareLine.UpdatePricingApprovalOnMainQuote(hostOpportunity, service, tracing);
                                }
                            }
                        }
                    }

                } 
            }

            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}