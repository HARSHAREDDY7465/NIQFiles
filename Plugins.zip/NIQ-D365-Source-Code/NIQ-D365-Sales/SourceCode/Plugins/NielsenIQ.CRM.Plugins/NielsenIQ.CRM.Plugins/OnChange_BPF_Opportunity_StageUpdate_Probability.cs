﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using NielsenIQ.CRM.Plugins.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;

namespace NielsenIQ.CRM.Plugins
{
    public class OnChange_BPF_Opportunity_StageUpdate_Probability : IPlugin
    {
        private static readonly HttpClient client = new HttpClient();
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                IOrganizationService serviceUser = serviceFactory.CreateOrganizationService(null);
                bool onlyLimitedChildOpp = false;
                // The InputParameters collection contains all the data  
                if (context.Depth > 1)
                {
                    return;
                }
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {

                    tracing.Trace("OnChangeBPF: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity entity = (Entity)context.InputParameters["Target"];
                    if (entity != null && entity.Id != Guid.Empty)
                    {
                        tracing.Trace("OnChangeBPF: Getting the Post Image from Context.");
                        Entity postImage = (Entity)context.PostEntityImages["Image"];

                        if (postImage != null && postImage.Attributes.Contains("bpf_opportunityid") && postImage.Attributes.Contains("activestageid"))
                        {
                            tracing.Trace("OnChangeBPF: postImage -> ." + postImage);
                            if (context.MessageName == "Create")
                            {
                                int oppoProb = (int)CommonConstant.Probability.PreProposal;
                                Entity oppoObj = service.Retrieve("opportunity", ((EntityReference)postImage["bpf_opportunityid"]).Id, new ColumnSet("niq_closeprobability"));
                                Entity updOppocreate = new Entity("opportunity", ((EntityReference)postImage["bpf_opportunityid"]).Id);
                                if (oppoObj != null && oppoObj.Id != Guid.Empty && oppoObj.Contains("niq_closeprobability"))
                                {
                                    if (oppoObj.Contains("niq_closeprobability"))
                                    {
                                        oppoProb = oppoObj.GetAttributeValue<OptionSetValue>("niq_closeprobability").Value;
                                    }
                                    UpdateOppoFields(tracing, service, updOppocreate, oppoProb, "Pre-Proposal", 1);
                                }

                            }
                            if (context.MessageName == "Update")
                            {
                                Entity preImage = (Entity)context.PreEntityImages["Image"];
                                if (preImage != null && preImage.Attributes.Contains("bpf_opportunityid") && preImage.Attributes.Contains("activestageid"))
                                {
                                    string postActiveStage = ((EntityReference)postImage["activestageid"]).Name.ToLower();
                                    string preActiveStage = ((EntityReference)preImage["activestageid"]).Name.ToLower();
                                    Guid oppoId = ((EntityReference)preImage["bpf_opportunityid"]).Id;

                                    Entity retOppo = service.Retrieve(preImage.GetAttributeValue<EntityReference>("bpf_opportunityid").LogicalName, preImage.GetAttributeValue<EntityReference>("bpf_opportunityid").Id, new ColumnSet("niq_mainquoteid", "niq_salesorgid", "niq_sapintegrationstatus", "niq_approvalstatus", "totalamount", "niq_mainquoteid", "niq_revenuesharedeal", "niq_hostopportunity"));
                                    EntityReference hostOppo = retOppo.GetAttributeValue<EntityReference>("niq_hostopportunity");
                                    tracing.Trace("hostoppo 70");

                                    //Cretea a Reveneu Shareline in Host Opportunity
                                    if (preActiveStage == "pre-proposal" && postActiveStage == "proposal")
                                    {
                                        Entity hostOpp = new Entity("opportunity", oppoId);
                                        string fetchOpp = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='opportunity'>
                                                            <attribute name='niq_revenuesharedeal' />
                                                            <attribute name='niq_mainquoteid' />
                                                             <attribute name='niq_contractstartdate' />
                                                             <attribute name='niq_contractenddate' />
                                                              <filter type='and'>
                                                              <filter type='or'>
                                                                <condition attribute='niq_stage' operator='eq' value='Pre-Proposal' />
                                                                <filter type='and'>
                                                                  <condition attribute='niq_stage' operator='eq' value='Closed Won - In Review' />
                                                                  <condition attribute='niq_approvalstatus' operator='in'>
                                                                    <value>100000000</value>
                                                                    <value>100000005</value>
                                                                    <value>100000003</value>
                                                                    <value>100000006</value>
                                                                  </condition>
                                                                </filter>
                                                              </filter>
                                                              <condition attribute='niq_revenuesharedeal' operator='eq' value='1' />
                                                                <condition attribute='niq_hostopportunity' operator='null' />
                                                              <condition attribute='opportunityid' operator='eq' value='{" + hostOpp.Id + @"}' />
                                                            </filter>
                                                          </entity>
                                                    </fetch>";
                                        Entity hostOpportunity = CreateRevShareLine.IsValidHostOppWithData(service, fetchOpp, tracing);
                                        EntityCollection childOppColl = null;
                                        // Check if the niq_revsharelines field exists and if its value is true
                                        if (hostOpportunity != null)
                                        {
                                            tracing.Trace("Cretea a Revenue Shareline in Host Opportunity");
                                            tracing.Trace("InitiatingUserId" + context.InitiatingUserId);
                                            Entity childEntity = null;
                                            //Get Child Opportunities of Host Opportunities
                                            childOppColl = CreateRevShareLine.GetChildOpportunity(service, hostOpp, tracing, childEntity);
                                            //if we want to trigger from Host opportunity pass "fasle" at last parameter
                                            CreateRevShareLine.ProcessToCreateRevShareLineFromHostOpportunity(service, hostOpportunity, childOppColl, tracing, false);
                                        }

                                    } // Delete all Rev share line if stage is moved from proposal to preproposal
                                    else if (preActiveStage == "proposal" && postActiveStage == "pre-proposal")
                                    {
                                        tracing.Trace("Stage change from proposal to pre-proposal.");
                                        //Sprint26_DYNCRM30318_B
                                        var payload = new
                                        {
                                            opportunityId = oppoId,
                                            mode = "Delete"
                                        };
                                        string json = JsonConvert.SerializeObject(payload, Formatting.Indented);
                                        string configName = "HTTPRequest_OpportunityCreateRevShareLines";

                                        //Call HTTP flow “PA_Opportunity_CreateRevShareLines_HTTP” in async mode and pass this json string 
                                        // Retrieve configuration settings to HTTPRequest_OpportunityCreateRevShareLines
                                        var query = new QueryExpression("niq_configurationsetting")
                                        {
                                            ColumnSet = new ColumnSet("niq_to"),
                                            Criteria = new FilterExpression
                                            {
                                                Conditions =
                                                {
                                                    new ConditionExpression("niq_name", ConditionOperator.Equal, configName)
                                                }
                                            }
                                        };
                                        var results = service.RetrieveMultiple(query);
                                        if (results.Entities.Count > 0)
                                        {
                                            var url = results.Entities[0]["niq_to"].ToString();
                                            tracing.Trace("URL:- " + url.ToString());
                                            var content = new StringContent(json, Encoding.UTF8, "application/json");
                                            var response = client.PostAsync(url, content).Result;
                                        }

                                    }
                                    //Sprint26_DYNCRM30318_E
                                    if (preActiveStage == "proposal" && postActiveStage == "negotiation")
                                    {

                                        if (retOppo != null && retOppo.Id != Guid.Empty && retOppo.Attributes.Contains("niq_mainquoteid") && retOppo.GetAttributeValue<EntityReference>("niq_mainquoteid").Id != Guid.Empty)
                                        {
                                            CommonHelper.updateOpportunityMandatoryCharValueAddedValidation(retOppo.GetAttributeValue<EntityReference>("niq_mainquoteid").Id, tracing, service);
                                        }
                                    }
                                    if (postActiveStage == "negotiation" && postActiveStage == "closed won - in review")
                                    {
                                        tracing.Trace("When stage change Negotiation to Close Won.");
                                        EntityReference mainQuoteId = retOppo.Attributes.Contains("niq_mainquoteid") && retOppo.GetAttributeValue<EntityReference>("niq_mainquoteid") != null ? retOppo.GetAttributeValue<EntityReference>("niq_mainquoteid") : null;
                                        tracing.Trace("Main Quote Id = " + mainQuoteId);
                                        if (mainQuoteId != null)
                                        {
                                            string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                <entity name='quotedetail'>
                                                    <attribute name='productdescription' />
                                                    <attribute name='priceperunit' />
                                                    <order attribute='niq_brandid' descending='false' />
                                                    <condition attribute='quoteid' operator='eq' value='" + mainQuoteId.Id + @"' />
                                                    <filter type='and'>
                                                    <filter type='or'>
                                                        <filter type='and'>
                                                        <condition attribute='niq_billingfrequency' operator='eq' value='100000009' />
                                                        <condition attribute='niq_remainingbillingamount' operator='gt' value='0' />
                                                        </filter>
                                                        <filter type='and'>
                                                        <condition attribute='niq_deliveryfrequency' operator='eq' value='100000009' />
                                                        <condition attribute='niq_remainingrevenueamount' operator='gt' value='0' />
                                                        </filter>
                                                    </filter>
                                                    </filter>
                                                </entity>
                                                </fetch>";
                                            EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetchXml));
                                            tracing.Trace("Record Count  = " + result.Entities.Count);
                                            if (result.Entities.Count > 0)
                                            {
                                                throw new InvalidPluginExecutionException("This Opportunity cannot be moved to 'Closed Won-In Review' because there are pending schedules. Please complete the Schedules to move forward.");
                                            }
                                        }
                                    }
                                    if (preActiveStage == "negotiation" && (postActiveStage == "pre-proposal" || postActiveStage == "proposal"))
                                    {
                                        if (retOppo != null && retOppo.Id != Guid.Empty && retOppo.Attributes.Contains("niq_mainquoteid") && retOppo.GetAttributeValue<EntityReference>("niq_mainquoteid").Id != Guid.Empty && retOppo.Attributes.Contains("niq_salesorgid") && retOppo.GetAttributeValue<EntityReference>("niq_salesorgid").Id != Guid.Empty)
                                        {
                                            bool isPilotMarket = false;

                                            Entity salesOrg = service.Retrieve(retOppo.GetAttributeValue<EntityReference>("niq_salesorgid").LogicalName, retOppo.GetAttributeValue<EntityReference>("niq_salesorgid").Id, new ColumnSet("niq_pilotmarket"));
                                            isPilotMarket = salesOrg.Attributes.Contains("niq_pilotmarket") ? salesOrg.GetAttributeValue<bool>("niq_pilotmarket") : false;
                                            if (isPilotMarket)
                                            {
                                                string fetchQuote = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                      <entity name='quote'>
                                                                        <attribute name='name' />
                                                                        <attribute name='totalamount' />
                                                                        <attribute name='opportunityid' />
                                                                        <attribute name='niq_mainquote' />
                                                                        <attribute name='niq_dealdeskapproval' />
                                                                        <attribute name='niq_contractstartdate' />
                                                                        <attribute name='niq_contractenddate' />
                                                                        <attribute name='quoteid' />
                                                                        <order attribute='name' descending='false' />
                                                                        <filter type='and'>                                                                          
                                                                          <condition attribute='niq_congaagreementstatus' operator='ne' value='100000000' />
                                                                          <condition attribute='niq_congaagreementstatus' operator='ne' value='100000004' />
                                                                          <condition attribute='niq_congaagreementstatus' operator='not-null' />
                                                                          <condition attribute='quoteid' operator='eq' uitype='quote' value='{0}' />
                                                                        </filter>   
                                                                      </entity>
                                                                    </fetch>";
                                                fetchQuote = string.Format(fetchQuote, retOppo.GetAttributeValue<EntityReference>("niq_mainquoteid").Id);
                                                var result = service.RetrieveMultiple(new FetchExpression(fetchQuote));
                                                if (result != null && result.Entities != null && result.Entities.Count > 0)
                                                {
                                                    throw new InvalidPluginExecutionException("In order to move this opportunity’s stage backward, you would need to cancel the agreement from the main quote.");
                                                }
                                                else
                                                {
                                                    ProcessActiveStage(tracing, service, ((EntityReference)postImage["bpf_opportunityid"]).Id, ((EntityReference)postImage["activestageid"]).Name);

                                                }
                                            }
                                            else
                                            {
                                                ProcessActiveStage(tracing, service, ((EntityReference)postImage["bpf_opportunityid"]).Id, ((EntityReference)postImage["activestageid"]).Name);

                                            }
                                        }
                                    }
                                    else if (preActiveStage == "closed won - in review" && (postActiveStage == "pre-proposal" || postActiveStage == "proposal" || postActiveStage == "negotiation"))
                                    {
                                        //string fetchXmlFAR = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                        //                            <entity name='niq_financeapprovalrequests'>
                                        //                            <attribute name='niq_financeapprovalrequestsid' />
                                        //                            <attribute name='niq_financeapprovalrequests' />
                                        //                            <attribute name='createdon' />
                                        //                            <order attribute='niq_financeapprovalrequests' descending='false' />
                                        //                            <filter type='and'>
                                        //                                <condition attribute='niq_approvalstatus' operator='eq' value='100000001' />
                                        //                                <condition attribute='niq_approvaltype' operator='eq' value='100000000' />
                                        //                                <condition attribute='statecode' operator='eq' value='0' />
                                        //                                <condition attribute='niq_relatedopportunity' operator='eq'  uitype='opportunity' value='{0}' />
                                        //                            </filter>
                                        //                            </entity>
                                        //                        </fetch>";
                                        //fetchXmlFAR = string.Format(fetchXmlFAR, oppoId);
                                        //var resultFAR = service.RetrieveMultiple(new FetchExpression(fetchXmlFAR));
                                        //if (resultFAR != null && resultFAR.Entities != null && resultFAR.Entities.Count > 0)
                                        //{
                                        //    throw new InvalidPluginExecutionException("This opportunity is pending Gatekeeper approval. You should recall it first from the Gatekeeper queue to be able to move it to an earlier sales process stage.");
                                        //}
                                        //Fix for the DYNCRM-5278
                                        int oppApprovalStatus = -1;
                                        if (retOppo != null && retOppo.Id != Guid.Empty && retOppo.Contains("niq_approvalstatus"))
                                        {
                                            oppApprovalStatus = retOppo.GetAttributeValue<OptionSetValue>("niq_approvalstatus").Value;
                                        }
                                        tracing.Trace("OnChangeBPF: Opp Approval Status " + oppApprovalStatus);
                                        if (oppApprovalStatus == 100000001)
                                        {
                                            throw new InvalidPluginExecutionException("This opportunity is pending Gatekeeper approval. You should recall it first from the Gatekeeper queue to be able to move it to an earlier sales process stage.");
                                        }
                                        else
                                        {
                                            Guid userId = context.UserId;
                                            tracing.Trace("context.UserId userid for changing the stage -> " + userId);
                                            tracing.Trace("context.Initiating userid for changing the stage -> " + context.InitiatingUserId);
                                            string[] Roles = { "NIQ Business Admin", "System Administrator", "System Customizer" };
                                            if (UserHasRole(serviceUser, userId, Roles, tracing))
                                            {
                                                ProcessActiveStage(tracing, service, ((EntityReference)postImage["bpf_opportunityid"]).Id, ((EntityReference)postImage["activestageid"]).Name);

                                            }
                                            else
                                            {

                                                int sapStatus = retOppo.Attributes.Contains("niq_sapintegrationstatus") && retOppo.GetAttributeValue<OptionSetValue>("niq_sapintegrationstatus") != null ? retOppo.GetAttributeValue<OptionSetValue>("niq_sapintegrationstatus").Value : -1;
                                                int approvalStatus = retOppo.Attributes.Contains("niq_approvalstatus") && retOppo.GetAttributeValue<OptionSetValue>("niq_approvalstatus") != null ? retOppo.GetAttributeValue<OptionSetValue>("niq_approvalstatus").Value : -1;
                                                tracing.Trace("Not a admin user");
                                                if (sapStatus != 100000000 && approvalStatus == 100000002)
                                                {
                                                    throw new InvalidPluginExecutionException("It is not allowed to move Opportunity Stage as Opportunity has not been synced to SAP. Please contact Administrator in order to take Opportunity back to Negotiation Stage");
                                                }
                                                else
                                                {
                                                    ProcessActiveStage(tracing, service, ((EntityReference)postImage["bpf_opportunityid"]).Id, ((EntityReference)postImage["activestageid"]).Name);
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        ProcessActiveStage(tracing, service, ((EntityReference)postImage["bpf_opportunityid"]).Id, ((EntityReference)postImage["activestageid"]).Name);
                                    }


                                    tracing.Trace("Execution for 20430");
                                    List<string> userRoles = GetUserRoles(service, context.UserId, tracing);
                                    bool hasRole = false;
                                    if (userRoles.Contains("NIQ Sales User") || userRoles.Contains("System Administrator"))
                                    {
                                        hasRole = true;
                                    }

                                    tracing.Trace("hasRole:" + hasRole);
                                    tracing.Trace("niq_revenuesharedeal:" + retOppo.Contains("niq_revenuesharedeal"));
                                    if (hasRole && retOppo.Contains("niq_revenuesharedeal") && retOppo.GetAttributeValue<bool>("niq_revenuesharedeal"))
                                    {
                                        // 20352
                                        /// Validate Child Opportunities for BPF required Fields to move to Negotiation Stage
                                        IsValidOpportunityForNegotiation(preActiveStage, postActiveStage, oppoId, retOppo, service, tracing);

                                        bool isValidTotal = ValidateTotalParentOpportunityValue(preActiveStage, postActiveStage, oppoId, retOppo, service, tracing);
                                        if (!isValidTotal)
                                        {
                                            throw new InvalidPluginExecutionException("There is an amount mismatch for this record.");
                                        }
                                    }

                                    if (retOppo.Contains("niq_hostopportunity") && retOppo["niq_hostopportunity"] != null)
                                    {
                                        tracing.Trace("hostoppo 329");
                                        Entity hostOppoFields = service.Retrieve(hostOppo.LogicalName, hostOppo.Id, new ColumnSet("niq_revenuesharedeal", "niq_stage"));
                                        if (hostOppoFields.Contains("niq_revenuesharedeal") && hostOppoFields.GetAttributeValue<bool>("niq_revenuesharedeal")
                                            && (preActiveStage == "negotiation" && postActiveStage == "closed won - in review")
                                            && hostOppoFields.Contains("niq_stage") &&
                                            (string.Equals(hostOppoFields.GetAttributeValue<string>("niq_stage").ToLower(), "pre-proposal") ||
                                            string.Equals(hostOppoFields.GetAttributeValue<string>("niq_stage").ToLower(), "proposal") ||
                                            string.Equals(hostOppoFields.GetAttributeValue<string>("niq_stage").ToLower(), "negotiation")))
                                        {
                                            tracing.Trace("hostoppo 333");
                                            throw new InvalidPluginExecutionException("For revenue share deal, the child opportunity cannot be moved to closed won in review. It will move to closed won in review together with host the opportunity");
                                        }
                                    }

                                }
                            }
                        }
                    }
                }

            }

            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        // 20352 - Parent Child validation for stage advancement on Parent Opportunity BPF while manually progressing on Opportunity entity (APPLICABLE ONLY FOR REV SHARE OPPTY)
        /// <summary>
        /// Validate Child Opportunities for BPF required Fields to move to Negotiation Stage(For Host opportunity in Rev Share)
        /// </summary>
        /// <param name="preActiveStage"></param>
        /// <param name="postActiveStage"></param>
        /// <param name="oppoId"></param>
        /// <param name="retOppo"></param>
        /// <param name="service"></param>
        /// <param name="tracing"></param>
        private void IsValidOpportunityForNegotiation(string preActiveStage, string postActiveStage, Guid oppoId, Entity retOppo, IOrganizationService service, ITracingService tracing)
        {
            try
            {
                tracing.Trace("preActiveStage:" + preActiveStage);
                tracing.Trace("postActiveStage:" + postActiveStage);
                if (preActiveStage == "negotiation" && postActiveStage == "closed won - in review")
                {
                    // 20352
                    tracing.Trace("Execution of US 20352");
                    tracing.Trace("niq_revenuesharedeal" + retOppo.GetAttributeValue<bool>("niq_revenuesharedeal"));
                    if (retOppo.Contains("niq_revenuesharedeal") && retOppo.GetAttributeValue<bool>("niq_revenuesharedeal"))
                    {
                        tracing.Trace("Opportunity id  = " + oppoId);
                        string fetchXmlChildOpp = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' no-lock='false' >
                                                <entity name='opportunity' >
                                                <attribute name='niq_opportunitynumber' />
                                                    <filter type='and' >
                                                        <condition attribute='niq_hostopportunity' operator='eq' value='{" + oppoId + @"}' uiname='1' uitype='opportunity' />
                                                        <condition attribute='statecode' operator='eq' value='0' />
                                                    </filter>
                                                </entity>
                                            </fetch>";

                        EntityCollection ResultChildOppEntcoll = service.RetrieveMultiple(new FetchExpression(fetchXmlChildOpp));

                        string fetchXmlValidChildOpp = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' no-lock='false' >
                                                <entity name='opportunity' >
                                                <attribute name='niq_opportunitynumber' />
                                                    <filter type='and' >
                                                        <condition attribute='niq_hostopportunity' operator='eq' value='{" + oppoId + @"}' uiname='1' uitype='opportunity' />
                                                        <condition attribute='niq_mainquotesdealdeskapprovalobtained' operator='eq' value='1' />
                                                        <condition attribute='niq_contractdecision' operator='not-null' />
                                                        <condition attribute='niq_soldtopartyverified' operator='eq' value='1' />
                                                        <condition attribute='niq_billtopartyverified' operator='eq' value='1' />
                                                        <condition attribute='niq_delivertopartyverified' operator='eq' value='1' />
                                                        <condition attribute='niq_tempeoafinallyexecutedagreementprovided'  operator='eq' value='1' />
                                                        <condition attribute='niq_billinginstructions' operator='not-null' />
                                                        <condition attribute='niq_mandatorycharvaluesadded' operator='eq' value='1' />
                                                        <condition attribute='niq_shouldclientbeinvoicedforthisopportunity' operator='not-null' />
                                                        <condition attribute='niq_invoiceinformationverified' operator='eq' value='1' />
                                                        <condition attribute='niq_competitor1' operator='not-null' />
                                                        <condition attribute ='niq_product_enhancement_impact_provisions' operator= 'not-null' />
                                                        <condition attribute='niq_readyfornextstage' operator='eq' value='1' />
                                                      <filter type='or' >
                                                                <condition attribute='niq_stage' operator='eq' value='Negotiation' />
                                                                <condition attribute='niq_stage' operator='like' value='Closed Won - In Review' />
                                                        </filter >
                                                        <filter type='or'>
                                                          <filter type='and'>
                                                            <condition attribute='niq_businessarea' operator='eq' value='100000000' />
                                                            <condition attribute='niq_terminationclause' operator='not-null' />
                                                          </filter>
                                                          <condition attribute='niq_businessarea' operator='ne' value='100000000' />
                                                        </filter>
                                                       </filter>
                                               </entity>
                                            </fetch>";

                        /*
                        //   <condition attribute='niq_terminationclause' operator='not-null' />

                                                    <filter type='or' >
                                                                <condition attribute='niq_stage' operator='eq' value='Negotiation' />
                                                                <condition attribute='niq_stage' operator='like' value='Closed%' />
                                                        </filter >


                        */

                        EntityCollection ResultValidChildOppEntcoll = service.RetrieveMultiple(new FetchExpression(fetchXmlValidChildOpp));
                        tracing.Trace("ResultValidChildOppEntcoll  = " + ResultValidChildOppEntcoll.Entities.Count);
                        tracing.Trace("ResultChildOppEntcoll  = " + ResultChildOppEntcoll.Entities.Count);

                        if (ResultValidChildOppEntcoll.Entities.Count != ResultChildOppEntcoll.Entities.Count)
                        {
                            throw new InvalidPluginExecutionException("One or more child opportunities are not ready to move to next stage. Please send all child opportunities to negotiation stage and make them ready to move to next stage before sending the host opportunity to gatekeeper");
                            //throw new InvalidPluginExecutionException("These child opportunities (opportunity number) are not in negotiation stage. Please send all child opportunities to negotiation stage before sending the host opportunity to gatekeeper.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private List<string> GetUserRoles(IOrganizationService service, Guid userId, ITracingService tracing)
        {
            // Query to retrieve the roles for the user
            var query = new QueryExpression("systemuserroles");
            query.ColumnSet = new ColumnSet("roleid");
            tracing.Trace("userId:" + userId);
            query.Criteria.AddCondition("systemuserid", ConditionOperator.Equal, userId);

            var userRoles = service.RetrieveMultiple(query).Entities;
            tracing.Trace("userRoles:" + userRoles.Count);

            // Get role names
            var roleNames = new List<string>();
            foreach (var userRole in userRoles)
            {
                var roleId = userRole.GetAttributeValue<Guid>("roleid");
                var role = service.Retrieve("role", roleId, new ColumnSet("name"));
                tracing.Trace("role:" + role);
                roleNames.Add(role.GetAttributeValue<string>("name"));
            }


            return roleNames;
        }

        /*
                private bool ValidateTotalParentOpportunityValue(string preActiveStage, string postActiveStage, Guid oppoId, Entity retOppo, IOrganizationService service, ITracingService tracing)
                {
                    bool isValid = true;
                    EntityCollection ResultChildOpp = null;
                    EntityCollection ResultParentOppProducts = null;
                    decimal hostTotalAmountExcludedRevShare = 0;
                    decimal childTotalAmount = 0;
                    try
                    {
                        tracing.Trace("preActiveStage:" + preActiveStage);
                        tracing.Trace("postActiveStage:" + postActiveStage);
                        if (preActiveStage == "negotiation" && postActiveStage == "closed won - in review")
                        {
                            if (retOppo.Attributes.Contains("totalamount") && retOppo.Attributes.Contains("niq_mainquoteid"))
                            {

                                decimal hostTotalAmount = retOppo.GetAttributeValue<Money>("totalamount").Value;
                                EntityReference mainQuoteRef = retOppo.GetAttributeValue<EntityReference>("niq_mainquoteid");

                                Guid mainQuoteId = mainQuoteRef.Id;

                                string fetchXmlChildOpp = $@"<fetch distinct='false' aggregate='true'>
                                                        <entity name='opportunity'>
                                                           <attribute name='opportunityid' aggregate='count' alias='childCount'/>    
                                                            <attribute name='totalamount' aggregate='sum' alias='totalBaseAmount'/>                                             
                                                            <filter type='and'>
                                                            <condition attribute='niq_hostopportunity' operator='eq' value='{oppoId}' />
                                                            </filter>
                                                        </entity>
                                                        </fetch>";

                                ResultChildOpp = service.RetrieveMultiple(new FetchExpression(fetchXmlChildOpp));
                                tracing.Trace("ResultChildOpp:" + ResultChildOpp.Entities.Count);
                                if (ResultChildOpp != null && ResultChildOpp.Entities != null && ResultChildOpp.Entities.Count > 0)
                                {

                                    var childCount = ResultChildOpp.Entities.First().GetAttributeValue<AliasedValue>("childCount");
                                    int totalChildRecordCount = childCount != null ? (int)childCount.Value : 0;
                                    tracing.Trace("totalChildRecordCount:" + totalChildRecordCount);

                                    if (totalChildRecordCount == 0) { return true; }

                                    //var totalChildAmount = ResultChildOpp.Entities.First().GetAttributeValue<Money>("totalBaseAmount");
                                    //tracing.Trace("totalChildAmount:" + totalChildAmount);

                                    var childAmount = ResultChildOpp.Entities.First().GetAttributeValue<AliasedValue>("totalBaseAmount");
                                    decimal? totalChildAmount = childAmount != null ? ((Money)childAmount.Value).Value : (decimal?)null;
                                    tracing.Trace("totalChildAmount:" + totalChildAmount);


                                    string fetchXmlHostOppProducts = @"<fetch distinct='false' aggregate='true'>
                                            <entity name='quotedetail'>
                                                <attribute name='baseamount' aggregate='sum' alias='totalBaseAmount' />
                                                <filter type='and'>
                                                    <condition attribute='quoteid' operator='eq' value='{" + mainQuoteId + @"}' />
                                                </filter>
                                                <link-entity name='product' from='productid' to='productid' link-type='inner' alias='ProductEntity'>
                                                    <filter type='and'>
                                                        <condition attribute='productnumber' operator='not-like' value='%Rev Share%' />
                                                        <condition attribute='productnumber' operator='not-like' value='%RevShare%' />
                                                        <condition attribute='productnumber' operator='not-like' value='%Rev-Share%' />
                                                        <condition attribute='productnumber' operator='not-like' value='%REVSHR%' />
                                                    </filter>
                                                </link-entity>
                                            </entity>
                                        </fetch>";

                                    ResultParentOppProducts = service.RetrieveMultiple(new FetchExpression(fetchXmlHostOppProducts));
                                    if (ResultParentOppProducts != null && ResultParentOppProducts.Entities != null && ResultParentOppProducts.Entities.Count > 0)
                                    {
                                        var totalBaseAmount = ResultParentOppProducts.Entities.First().GetAttributeValue<AliasedValue>("totalBaseAmount");
                                        decimal? totalParentAmount = totalBaseAmount != null ? ((Money)totalBaseAmount.Value).Value : (decimal?)null;
                                        tracing.Trace("totalParentAmount:" + totalParentAmount);


                                        if (totalParentAmount != null)
                                        {
                                            hostTotalAmountExcludedRevShare = totalParentAmount.Value;
                                        }
                                        tracing.Trace("hostTotalAmountExcludedRevShare:" + hostTotalAmountExcludedRevShare);
                                    }
                                    if (totalChildAmount != null)
                                    {
                                        childTotalAmount = totalChildAmount.Value;
                                        tracing.Trace("childTotalAmount:" + childTotalAmount);
                                    }
                                    tracing.Trace("hostTotalAmount:" + hostTotalAmount);
                                    tracing.Trace("hostTotalAmountExcludedRevShare:" + hostTotalAmountExcludedRevShare);
                                    tracing.Trace("childTotalAmount:" + childTotalAmount);

                                    if (!(hostTotalAmount == (hostTotalAmountExcludedRevShare + childTotalAmount)))
                                    {
                                        isValid = false;
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new InvalidPluginExecutionException(ex.Message);
                    }

                    return isValid;
                }

        */
        private bool ValidateTotalParentOpportunityValue(string preActiveStage, string postActiveStage, Guid oppoId, Entity retOppo, IOrganizationService service, ITracingService tracing)
        {
            bool isValid = true;
            EntityCollection ResultChildOpp = null;
            EntityCollection ResultParentOppProducts = null;
            decimal hostTotalAmountExcludedRevShare = 0;
            decimal childTotalAmount = 0;

            try
            {
                tracing.Trace("preActiveStage:" + preActiveStage);
                tracing.Trace("postActiveStage:" + postActiveStage);

                if (preActiveStage == "negotiation" && postActiveStage == "closed won - in review")
                {
                    if (retOppo.Attributes.Contains("totalamount") && retOppo.Attributes.Contains("niq_mainquoteid"))
                    {
                        decimal hostTotalAmount = retOppo.GetAttributeValue<Money>("totalamount").Value;
                        EntityReference mainQuoteRef = retOppo.GetAttributeValue<EntityReference>("niq_mainquoteid");
                        Guid mainQuoteId = mainQuoteRef.Id;

                        // Fetch child opportunities without aggregate
                        string fetchXmlChildOpp = $@"
                        <fetch>
                            <entity name='opportunity'>
                                <attribute name='opportunityid' />
                                <attribute name='totalamount' />
                                <filter type='and'>
                                    <condition attribute='niq_hostopportunity' operator='eq' value='{oppoId}' />
                                    <condition attribute='statecode' operator='neq' value='2' />
                                </filter>
                            </entity>
                        </fetch>";

                        ResultChildOpp = service.RetrieveMultiple(new FetchExpression(fetchXmlChildOpp));
                        tracing.Trace("ResultChildOpp count: " + ResultChildOpp.Entities.Count);

                        if (ResultChildOpp != null && ResultChildOpp.Entities.Count > 0)
                        {
                            // Sum up the total amounts of child opportunities
                            childTotalAmount = ResultChildOpp.Entities.Sum(child => child.Attributes.Contains("totalamount") && child.GetAttributeValue<Money>("totalamount") != null ? child.GetAttributeValue<Money>("totalamount").Value : 0);

                            tracing.Trace("childTotalAmount: " + childTotalAmount);

                            // Fetch parent opportunity products without aggregate
                            string fetchXmlHostOppProducts = $@"
                            <fetch>
                                <entity name='quotedetail'>
                                    <attribute name='extendedamount' />
                                    <filter type='and'>
                                        <condition attribute='quoteid' operator='eq' value='{mainQuoteId}' />
                                    </filter>
                                    <link-entity name='product' from='productid' to='productid' link-type='inner'>
                                        <filter type='and'>
                                            <condition attribute='productnumber' operator='not-like' value='%Rev Share%' />
                                            <condition attribute='productnumber' operator='not-like' value='%RevShare%' />
                                            <condition attribute='productnumber' operator='not-like' value='%Rev-Share%' />
                                            <condition attribute='productnumber' operator='not-like' value='%REVSHR%' />
                                        </filter>
                                    </link-entity>
                                </entity>
                            </fetch>";

                            ResultParentOppProducts = service.RetrieveMultiple(new FetchExpression(fetchXmlHostOppProducts));
                            if (ResultParentOppProducts != null && ResultParentOppProducts.Entities.Count > 0)
                            {
                                // Sum up the base amounts of parent opportunity products
                                hostTotalAmountExcludedRevShare = ResultParentOppProducts.Entities.Sum(product => product.Attributes.Contains("extendedamount") && product.GetAttributeValue<Money>("extendedamount") != null ? product.GetAttributeValue<Money>("extendedamount").Value : 0);
                                tracing.Trace("hostTotalAmountExcludedRevShare: " + hostTotalAmountExcludedRevShare);
                            }

                            tracing.Trace("hostTotalAmount: " + hostTotalAmount);
                            tracing.Trace("hostTotalAmountExcludedRevShare: " + hostTotalAmountExcludedRevShare);
                            tracing.Trace("childTotalAmount: " + childTotalAmount);

                            if (!(hostTotalAmount == (hostTotalAmountExcludedRevShare + childTotalAmount)))
                            {
                                isValid = false;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }

            return isValid;
        }

        private void ProcessActiveStage(ITracingService tracing, IOrganizationService service, Guid oppoid, string activestagename)
        {
            try
            {
                tracing.Trace("OnChangeBPF: creating opportunity obj.");
                int approvalStatus = -1;
                Entity oppoObj = service.Retrieve("opportunity", oppoid, new ColumnSet("niq_approvalstatus"));
                if (oppoObj != null && oppoObj.Id != Guid.Empty && oppoObj.Contains("niq_approvalstatus"))
                {
                    approvalStatus = oppoObj.GetAttributeValue<OptionSetValue>("niq_approvalstatus").Value;
                }
                Entity updOppo = new Entity("opportunity", oppoid);
                tracing.Trace("OnChangeBPF: BPF stage " + activestagename);
                tracing.Trace("OnChangeBPF: Approval Status " + approvalStatus);
                //Get the active stage name 
                switch (activestagename.ToLower())
                {
                    case "pre-proposal":
                        tracing.Trace("OnChangeBPF: BPF stage pre-proposal." + activestagename);
                        UpdateOppoFields(tracing, service, updOppo, (int)CommonConstant.Probability.PreProposal, activestagename, approvalStatus);
                        break;
                    case "proposal":
                        tracing.Trace("OnChangeBPF: BPF stage proposal." + activestagename);
                        UpdateOppoFields(tracing, service, updOppo, (int)CommonConstant.Probability.Proposal, activestagename, approvalStatus);
                        break;
                    case "negotiation":
                        tracing.Trace("OnChangeBPF: BPF stage Negotiation." + activestagename);
                        UpdateOppoFields(tracing, service, updOppo, (int)CommonConstant.Probability.Negotiation, activestagename, approvalStatus);
                        break;
                    case "closure":
                        tracing.Trace("OnChangeBPF: BPF stage Closure." + activestagename);
                        UpdateOppoFields(tracing, service, updOppo, (int)CommonConstant.Probability.Negotiation, activestagename, approvalStatus);
                        break;
                    case "closed won - in review":
                        tracing.Trace("OnChangeBPF: BPF stage closed won - in review ." + activestagename);
                        UpdateOppoFields(tracing, service, updOppo, (int)CommonConstant.Probability.ClosedWon, activestagename, approvalStatus);
                        break;
                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private void UpdateOppoFields(ITracingService tracing, IOrganizationService service, Entity updoppo, int probability, string stageName, int approvalStatus)
        {
            try
            {
                tracing.Trace("OnChangeBPF: updating opportunity...." + probability + ".." + stageName + "..." + approvalStatus);
                if (stageName.ToLower() != "closure")
                {
                    updoppo["niq_closeprobability"] = new OptionSetValue(probability);
                }
                if ((stageName.ToLower() == "closed won - in review") && (approvalStatus != (int)CommonConstant.ApprovalStatus.Pending))
                {
                    tracing.Trace("clearing the values of SAP and setting again the approval to pending to create a far");
                    updoppo["niq_approvalstatus"] = new OptionSetValue((int)CommonConstant.ApprovalStatus.Pending);
                    updoppo["niq_saperrortext"] = null;
                    updoppo["niq_sapintegrationstatus"] = null;
                }
                updoppo["niq_stage"] = stageName;

                service.Update(updoppo);
                tracing.Trace("OnChangeBPF: opportunity updated sucesfully");
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private static bool UserHasRole(IOrganizationService service, Guid userId, string[] roleNames, ITracingService tracing)
        {
            bool hasRole = false;
            tracing.Trace("inside userhasrole");

            foreach (var roleName in roleNames)
            {
                tracing.Trace("role ->" + roleName);
                QueryExpression qe = new QueryExpression("systemuserroles");
                qe.Criteria.AddCondition("systemuserid", ConditionOperator.Equal, userId);
                LinkEntity link = qe.AddLink("role", "roleid", "roleid", JoinOperator.Inner);
                link.LinkCriteria.AddCondition("name", ConditionOperator.Equal, roleName);
                var result = service.RetrieveMultiple(qe);
                if (result != null && result.Entities != null && result.Entities.Count > 0)
                {
                    hasRole = true;
                    return hasRole;
                }
            }
            tracing.Trace("hasrole->" + hasRole);
            return hasRole;
        }
    }
}