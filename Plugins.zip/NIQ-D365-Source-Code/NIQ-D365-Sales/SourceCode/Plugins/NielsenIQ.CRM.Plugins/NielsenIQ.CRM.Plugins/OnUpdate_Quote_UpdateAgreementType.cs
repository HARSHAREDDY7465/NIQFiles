﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Quote_UpdateAgreementType : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                // Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                // Check if the InputParameters contains "Target" and it is of type Entity
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("UpdateAgreementType - Plugin Started , getting Current Quote and PreImage");
                    // Obtain the target entity from the input parameters.
                    Entity currentQuote = (Entity)context.InputParameters["Target"];
                    Entity preImage = context.PreEntityImages.Contains("PreImage") ? (Entity)context.PreEntityImages["PreImage"] : null;

                    if (currentQuote != null && currentQuote.Id != Guid.Empty)
                    {
                        // Check if the quote has contract start and end dates
                        if (currentQuote.Contains("niq_contractstartdate") && currentQuote.Contains("niq_contractenddate"))
                        {
                            DateTime startDate = currentQuote.GetAttributeValue<DateTime>("niq_contractstartdate");
                            DateTime endDate = currentQuote.GetAttributeValue<DateTime>("niq_contractenddate");

                            tracing.Trace("Start date: " + startDate.ToString());
                            tracing.Trace("End date: " + endDate.ToString());

                            int months = ((endDate.Year - startDate.Year) * 12) + endDate.Month - startDate.Month + 1;
                            tracing.Trace("Difference in months: " + months.ToString());

                            // Initialize the update entity
                            Entity updQuote = new Entity(currentQuote.LogicalName, currentQuote.Id);
                            bool updateQuote = false;

                            // Check conditions and set the niq_agreementtype based on the previous values
                            if (months < 12 && months != 0 && !preImage.Contains("niq_agreementtype"))
                            {
                                updQuote["niq_agreementtype"] = new OptionSetValue(100000000); // adhoc
                                updateQuote = true;
                            }
                            else if (months >= 12 && months != 0 && !preImage.Contains("niq_msapaymentterm"))
                            {
                                updQuote["niq_agreementtype"] = new OptionSetValue(100000001); // license
                                updateQuote = true;
                            }
                            else if (months >= 12 && months != 0 && preImage.Contains("niq_msapaymentterm"))
                            {
                                updQuote["niq_agreementtype"] = new OptionSetValue(100000002); // local
                                updateQuote = true;
                            }

                            if (updateQuote)
                            {
                                tracing.Trace("Updating Quote with new Agreement Type");
                                service.Update(updQuote);
                            }
                            else
                            {
                                tracing.Trace("No updates required for the Quote");
                            }
                            CalculateAnnualContractValue(service, currentQuote, tracing);
                        }
                        else
                        {
                            tracing.Trace("Contract start date or end date is not populated. Exiting plugin.");
                            return;
                        }
                    }
                }
                

                tracing.Trace("UpdateAgreementType: Plugin Executed Successfully");
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        //DYNCRM-30336 Updating the Annual Contract value and POC value using this two method
        private static void CalculateAnnualContractValue(IOrganizationService service, Entity currentQuote, ITracingService tracing)
        {
            try
            {
                tracing.Trace("CalculateAnnualContractValue: Started.");
                ColumnSet acvColumns = new ColumnSet("niq_ratecardprice", "niq_contractstartdate", "niq_contractenddate", "exchangerate", "niq_salesorgid", "niq_overalldealscore", "niq_annualcontractvalue", "niq_poc");
                Entity quote = service.Retrieve("quote", currentQuote.Id, acvColumns);
                Money rateCardPrice = quote.Contains("niq_ratecardprice") ? quote.GetAttributeValue<Money>("niq_ratecardprice") : null;
                tracing.Trace($"Rate Card Price: {rateCardPrice?.Value.ToString() ?? "null"}");
                if (rateCardPrice == null || rateCardPrice.Value <= 0)
                {
                    tracing.Trace("Rate Card Price is null or zero. Skipping ACV calculation.");
                    return;
                }
                DateTime? contractStartDate = quote.Contains("niq_contractstartdate") ? quote.GetAttributeValue<DateTime?>("niq_contractstartdate") : null;
                DateTime? contractEndDate = quote.Contains("niq_contractenddate") ? quote.GetAttributeValue<DateTime?>("niq_contractenddate") : null;
                decimal? exchangeRate = quote.Contains("exchangerate") ? quote.GetAttributeValue<decimal?>("exchangerate") : null;
                tracing.Trace($"Contract Start Date: {contractStartDate?.ToString() ?? "null"}");
                tracing.Trace($"Contract End Date: {contractEndDate?.ToString() ?? "null"}");
                tracing.Trace($"Exchange Rate: {exchangeRate?.ToString() ?? "null"}");
                if (!contractStartDate.HasValue || !contractEndDate.HasValue)
                {
                    tracing.Trace("Contract dates missing. Cannot calculate ACV.");
                    return;
                }
                if (!exchangeRate.HasValue || exchangeRate.Value <= 0)
                {
                    tracing.Trace("Exchange Rate is null or zero. Cannot calculate ACV.");
                    return;
                }
                double totalDays = (contractEndDate.Value - contractStartDate.Value).TotalDays;
                double numberOfYears = totalDays / 365.25;
                tracing.Trace($"Total Days: {totalDays}, Number of Years: {numberOfYears}");
                if (numberOfYears <= 0)
                {
                    tracing.Trace("Invalid contract period.");
                    return;
                }
                QueryExpression eurQuery = new QueryExpression("transactioncurrency") { ColumnSet = new ColumnSet("exchangerate", "isocurrencycode") };
                eurQuery.Criteria.AddCondition("isocurrencycode", ConditionOperator.Equal, "EUR");
                EntityCollection eurCurrencies = service.RetrieveMultiple(eurQuery);
                if (eurCurrencies.Entities.Count == 0)
                {
                    tracing.Trace("EUR currency not found in system.");
                    return;
                }
                Entity eurCurrency = eurCurrencies.Entities[0];
                decimal eurExchangeRate = eurCurrency.GetAttributeValue<decimal>("exchangerate");
                tracing.Trace($"EUR Exchange Rate: {eurExchangeRate}");
                decimal conversionRate = eurExchangeRate / exchangeRate.Value;
                tracing.Trace($"Conversion Rate: {conversionRate}");
                decimal priceInEUR = rateCardPrice.Value * conversionRate;
                tracing.Trace($"Price in EUR: {priceInEUR}");
                decimal annualContractValue = priceInEUR / (decimal)numberOfYears;
                annualContractValue = Math.Round(annualContractValue, 2);
                tracing.Trace($"Calculated ACV: {annualContractValue}");
                Money existingACV = quote.Contains("niq_annualcontractvalue") ? quote.GetAttributeValue<Money>("niq_annualcontractvalue") : null;
                tracing.Trace($"Existing ACV: {existingACV?.Value.ToString() ?? "null"}");
                bool pocValue = CalculatePOC(service, quote, annualContractValue, tracing);
                bool existingPOC = quote.Contains("niq_poc") && quote.GetAttributeValue<bool>("niq_poc");
                tracing.Trace($"Calculated POC: {pocValue}");
                tracing.Trace($"Existing POC: {existingPOC}");
                bool needsUpdate = false;
                if (existingACV == null || existingACV.Value != annualContractValue)
                {
                    needsUpdate = true;
                    tracing.Trace("ACV has changed. Update needed.");
                }
                if (existingPOC != pocValue)
                {
                    needsUpdate = true;
                    tracing.Trace("POC has changed. Update needed.");
                }
                if (needsUpdate)
                {
                    Entity quoteToUpdate = new Entity("quote", currentQuote.Id);
                    quoteToUpdate["niq_annualcontractvalue"] = new Money(annualContractValue);
                    quoteToUpdate["niq_poc"] = pocValue;
                    service.Update(quoteToUpdate);
                    tracing.Trace("ACV and POC updated successfully.");
                }
                else
                {
                    tracing.Trace("No changes in ACV or POC. Skipping update.");
                }
            }
            catch (Exception ex)
            {
                tracing.Trace($"Error in CalculateAnnualContractValue: {ex.Message}");
                throw new InvalidPluginExecutionException($"Error calculating Annual Contract Value: {ex.Message}", ex);
            }
        }

        private static bool CalculatePOC(IOrganizationService service, Entity quote, decimal annualContractValue, ITracingService tracing)
        {
            try
            {
                tracing.Trace("CalculatePOC: Started.");
                //QueryExpression ddarQuery = new QueryExpression("niq_dealdeskapprovalrequest");
                //ddarQuery.NoLock = true;
                //ddarQuery.TopCount = 1;
                //ddarQuery.ColumnSet = new ColumnSet("niq_dealdeskapprovalrequestid", "niq_poc_flag");
                //ddarQuery.Criteria.AddCondition("niq_quoteid", ConditionOperator.Equal, quote.Id);
                //ddarQuery.Criteria.AddCondition("statecode", ConditionOperator.Equal, 1); // Inactive/Approved
                //ddarQuery.Criteria.AddCondition("niq_poc_flag", ConditionOperator.Equal, true);
                //ddarQuery.AddOrder("createdon", OrderType.Descending);
                //var resultDDAR = service.RetrieveMultiple(ddarQuery);
                //if (resultDDAR.Entities.Count > 0)
                //{
                //    tracing.Trace("Found approved DDAR with POC flag = true. POC will remain FALSE.");
                //    return false;
                //}
                EntityReference salesOrgRef = quote.Contains("niq_salesorgid") ? quote.GetAttributeValue<EntityReference>("niq_salesorgid") : null;
                if (salesOrgRef == null)
                {
                    tracing.Trace("Sales Org ID is null. POC = FALSE.");
                    return false;
                }
                Guid salesOrgId = salesOrgRef.Id;
                tracing.Trace($"Sales Org ID: {salesOrgId}");
                Entity salesOrg = service.Retrieve("niq_salesorg", salesOrgId, new ColumnSet("niq_poc"));
                bool salesOrgPOC = salesOrg.Contains("niq_poc") && salesOrg.GetAttributeValue<bool>("niq_poc");
                tracing.Trace($"Sales Org POC: {salesOrgPOC}");
                if (!salesOrgPOC || annualContractValue < 375000)
                {
                    tracing.Trace($"Sales Org POC is FALSE or ACV ({annualContractValue}) < 375,000. POC = FALSE.");
                    return false;
                }
                string overallDealScore = quote.Contains("niq_overalldealscore") ? quote.GetAttributeValue<string>("niq_overalldealscore") : null;
                tracing.Trace($"Overall Deal Score: {overallDealScore ?? "null"}");
                if (!string.IsNullOrEmpty(overallDealScore))
                {
                    bool isRedOrYellow = overallDealScore.Equals("Red", StringComparison.OrdinalIgnoreCase) || overallDealScore.Equals("Yellow", StringComparison.OrdinalIgnoreCase);
                    tracing.Trace($"Overall Deal Score is Red or Yellow: {isRedOrYellow}");
                    return isRedOrYellow;
                }
                tracing.Trace("No Overall Deal Score. POC = TRUE.");
                return true;
            }
            catch (Exception ex)
            {
                tracing.Trace($"Error in CalculatePOC: {ex.Message}");
                throw new InvalidPluginExecutionException($"Error calculating POC: {ex.Message}", ex);
            }
        }
    }
}

