﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Project_FieldStartDateAndDeliveryDate_CreatePOCR : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                if (context.MessageName.ToLower() == "update")
                {
                    if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                    {
                        Entity projectContext = (Entity)context.InputParameters["Target"];
                        Entity project = service.Retrieve(projectContext.LogicalName, projectContext.Id, new ColumnSet("niq_fieldstartdate", "niq_studylive", "niq_deliverydate"));
                        DateTime fieldStartDate = new DateTime();
                        DateTime preImageFieldStartDate = new DateTime();
                        DateTime deliveryDate = new DateTime();
                        DateTime preImageDeliveryDate = new DateTime();
                        int preImageStudyLive = 0;
                        int studyLive = 0;
                        if (project.Contains("niq_fieldstartdate") && project.Contains("niq_deliverydate"))
                        {
                            tracing.Trace("niq_fieldstartdate" + project.GetAttributeValue<DateTime>("niq_fieldstartdate"));
                            fieldStartDate = project.GetAttributeValue<DateTime>("niq_fieldstartdate");
                            deliveryDate = project.GetAttributeValue<DateTime>("niq_deliverydate");
                            tracing.Trace("niq_deliverydate" + project.GetAttributeValue<DateTime>("niq_deliverydate"));
                        }
                        studyLive = (!project.Contains("niq_studylive")) ? 0 : project.GetAttributeValue<OptionSetValue>("niq_studylive").Value;
                        tracing.Trace("niq_studylive" + studyLive.ToString());
                        Entity preImageProject = context.PreEntityImages.Contains("projectpreimage") ? (Entity)context.PreEntityImages["projectpreimage"] : new Entity();
                        if (preImageProject.Contains("niq_fieldstartdate") && preImageProject.Contains("niq_deliverydate"))
                        {
                            tracing.Trace("niq_fieldstartdate" + preImageProject.GetAttributeValue<DateTime>("niq_fieldstartdate"));
                            preImageFieldStartDate = preImageProject.GetAttributeValue<DateTime>("niq_fieldstartdate");
                            preImageDeliveryDate = preImageProject.GetAttributeValue<DateTime>("niq_deliverydate");
                            tracing.Trace("niq_deliverydate" + preImageProject.GetAttributeValue<DateTime>("niq_deliverydate"));
                        }
                        preImageStudyLive = (!preImageProject.Contains("niq_studylive")) ? 0 : preImageProject.GetAttributeValue<OptionSetValue>("niq_studylive").Value;
                        tracing.Trace("niq_studylive" + preImageStudyLive.ToString());
                        var relatedOpp = service.Retrieve(preImageProject.GetAttributeValue<EntityReference>("niq_opportunityid").LogicalName, preImageProject.GetAttributeValue<EntityReference>("niq_opportunityid").Id, new ColumnSet("niq_stage", "niq_billingtype", "niq_opportunitytype", "totalamount"));
                        //if ((relatedOpp.Contains("niq_stage")) && (relatedOpp.GetAttributeValue<string>("niq_stage") == "Closed Won - Approved") && (((relatedOpp.Contains("niq_opportunitytype")) && (relatedOpp.GetAttributeValue<OptionSetValue>("niq_opportunitytype").Value == 1) && (relatedOpp.Contains("totalamount")) && (relatedOpp.GetAttributeValue<Money>("totalamount").Value > 0)) || (relatedOpp.GetAttributeValue<OptionSetValue>("niq_opportunitytype").Value == 2)))
                        if (((relatedOpp.Contains("niq_stage")) && (relatedOpp.GetAttributeValue<string>("niq_stage") == "Closed Won - Approved")) && ((relatedOpp.GetAttributeValue<OptionSetValue>("niq_opportunitytype").Value == 1 && relatedOpp.GetAttributeValue<Money>("totalamount").Value > 0) || (relatedOpp.GetAttributeValue<OptionSetValue>("niq_opportunitytype").Value == 2)))
                        {
                            tracing.Trace("niq_stage" + relatedOpp.GetAttributeValue<string>("niq_stage"));
                            var billingtype = (!relatedOpp.Contains("niq_billingtype")) ? 0 : relatedOpp.GetAttributeValue<OptionSetValue>("niq_billingtype").Value;
                            tracing.Trace("niq_billingtype" + billingtype.ToString());
                            if ((fieldStartDate != preImageFieldStartDate))
                            {
                                if (billingtype == 0 || billingtype != 100000002)
                                {
                                    Entity PostOpportunityChangeRequest = new Entity("niq_postopportunity");
                                    PostOpportunityChangeRequest["niq_currentprojectstartdate"] = fieldStartDate;
                                    PostOpportunityChangeRequest["niq_previousprojectstartdate"] = preImageFieldStartDate;
                                    PostOpportunityChangeRequest["niq_typeofchange"] = new OptionSetValue(100000007);
                                    PostOpportunityChangeRequest["niq_descriptionofchange"] = "Project Field Start Date Change";
                                    if (preImageProject.Attributes.Contains("niq_opportunityid"))
                                    {
                                        PostOpportunityChangeRequest["niq_opportunity"] = (EntityReference)preImageProject.GetAttributeValue<EntityReference>("niq_opportunityid");
                                        tracing.Trace("OnUpdate_Project_FieldStartDateAndDeliveryDate_CreatePOCR: contains oppo ");
                                    }
                                    EntityCollection pocrCollection = isPendinPOCRExists(service, 100000007, preImageProject.GetAttributeValue<EntityReference>("niq_opportunityid").Id.ToString(), tracing);
                                    tracing.Trace(pocrCollection.Entities.ToString());
                                    if (pocrCollection.Entities.Count > 0)
                                    {
                                        Entity existingPOCR = new Entity("niq_postopportunity");
                                        existingPOCR.Id = pocrCollection.Entities[0].Id;
                                        existingPOCR["niq_currentprojectstartdate"] = fieldStartDate;
                                        tracing.Trace("niq_currentprojectstartdate " + existingPOCR["niq_currentprojectstartdate"]);
                                        existingPOCR["niq_previousprojectstartdate"] = preImageFieldStartDate;
                                        tracing.Trace("niq_previousprojectstartdate " + existingPOCR["niq_previousprojectstartdate"]);
                                        service.Update(existingPOCR);
                                        tracing.Trace("OnUpdate_Project_FieldStartDateAndDeliveryDate_CreatePOCR:Project Field Start Date Change- record Updated ");
                                    }
                                    else
                                    {
                                        service.Create(PostOpportunityChangeRequest);
                                        tracing.Trace("OnUpdate_Project_FieldStartDateAndDeliveryDate_CreatePOCR: record created ");
                                    }
                                }
                                else if (billingtype == 100000002 && studyLive == 100000001)
                                {
                                    Entity PostOpportunityChangeRequest = new Entity("niq_postopportunity");
                                    PostOpportunityChangeRequest["niq_currentprojectstartdate"] = fieldStartDate;
                                    PostOpportunityChangeRequest["niq_previousprojectstartdate"] = preImageFieldStartDate;
                                    PostOpportunityChangeRequest["niq_typeofchange"] = new OptionSetValue(100000007);
                                    PostOpportunityChangeRequest["niq_descriptionofchange"] = "Project Field Start Date Change";
                                    if (preImageProject.Attributes.Contains("niq_opportunityid"))
                                    {
                                        PostOpportunityChangeRequest["niq_opportunity"] = (EntityReference)preImageProject.GetAttributeValue<EntityReference>("niq_opportunityid");
                                        tracing.Trace("OnUpdate_Project_FieldStartDateAndDeliveryDate_CreatePOCR: contains oppo ");
                                    }
                                    EntityCollection pocrCollection = isPendinPOCRExists(service, 100000007, preImageProject.GetAttributeValue<EntityReference>("niq_opportunityid").Id.ToString(), tracing);
                                    tracing.Trace(pocrCollection.Entities.ToString());
                                    if (pocrCollection.Entities.Count > 0)
                                    {
                                        Entity existingPOCR = new Entity("niq_postopportunity");
                                        existingPOCR.Id = pocrCollection.Entities[0].Id;
                                        existingPOCR["niq_currentprojectstartdate"] = fieldStartDate;
                                        tracing.Trace("niq_currentprojectstartdate " + existingPOCR["niq_currentprojectstartdate"]);
                                        existingPOCR["niq_previousprojectstartdate"] = preImageFieldStartDate;
                                        tracing.Trace("niq_previousprojectstartdate " + existingPOCR["niq_previousprojectstartdate"]);
                                        service.Update(existingPOCR);
                                        tracing.Trace("OnUpdate_Project_FieldStartDateAndDeliveryDate_CreatePOCR:Project Field Start Date Change- record Updated ");
                                    }
                                    else
                                    {
                                        service.Create(PostOpportunityChangeRequest);
                                        tracing.Trace("OnUpdate_Project_FieldStartDateAndDeliveryDate_CreatePOCR: record created ");
                                    }
                                }
                            }
                            if ((deliveryDate != preImageDeliveryDate))
                            {
                                if (billingtype == 0 || billingtype != 100000002)
                                {
                                    Entity PostOpportunityChangeRequest = new Entity("niq_postopportunity");
                                    PostOpportunityChangeRequest["niq_newprojectdeliverydate"] = deliveryDate;
                                    tracing.Trace("niq_newprojectdeliverydate " + PostOpportunityChangeRequest["niq_newprojectdeliverydate"]);
                                    PostOpportunityChangeRequest["niq_previousprojectdeliverydate"] = preImageDeliveryDate;
                                    tracing.Trace("niq_previousprojectdeliverydate " + PostOpportunityChangeRequest["niq_previousprojectdeliverydate"]);
                                    PostOpportunityChangeRequest["niq_typeofchange"] = new OptionSetValue(100000009);
                                    PostOpportunityChangeRequest["niq_descriptionofchange"] = "Project Delivery Date Change";
                                    if (preImageProject.Attributes.Contains("niq_opportunityid"))
                                    {
                                        PostOpportunityChangeRequest["niq_opportunity"] = (EntityReference)preImageProject.GetAttributeValue<EntityReference>("niq_opportunityid");
                                        tracing.Trace("OnUpdate_Project_FieldStartDateAndDeliveryDate_CreatePOCR: contains oppo ");
                                    }
                                    EntityCollection pocrCollection = isPendinPOCRExists(service, 100000009, preImageProject.GetAttributeValue<EntityReference>("niq_opportunityid").Id.ToString(), tracing);
                                    tracing.Trace(pocrCollection.Entities.ToString());
                                    if (pocrCollection.Entities.Count > 0)
                                    {
                                        Entity existingPOCR = new Entity("niq_postopportunity");
                                        existingPOCR.Id = pocrCollection.Entities[0].Id;
                                        existingPOCR["niq_newprojectdeliverydate"] = deliveryDate;
                                        existingPOCR["niq_previousprojectdeliverydate"] = preImageDeliveryDate;
                                        service.Update(existingPOCR);
                                        tracing.Trace("OnUpdate_Project_FieldStartDateAndDeliveryDate_CreatePOCR:Project Delivery Date Change- record Updated ");
                                    }
                                    else
                                    {
                                        service.Create(PostOpportunityChangeRequest);
                                        tracing.Trace("OnUpdate_Project_FieldStartDateAndDeliveryDate_CreatePOCR: record created ");
                                    }
                                }
                                else if (billingtype == 100000002 && studyLive == 100000001)
                                {
                                    Entity PostOpportunityChangeRequest = new Entity("niq_postopportunity");
                                    PostOpportunityChangeRequest["niq_newprojectdeliverydate"] = deliveryDate;
                                    PostOpportunityChangeRequest["niq_previousprojectdeliverydate"] = preImageDeliveryDate;
                                    PostOpportunityChangeRequest["niq_typeofchange"] = new OptionSetValue(100000009);
                                    PostOpportunityChangeRequest["niq_descriptionofchange"] = "Project Delivery Date Change";
                                    if (preImageProject.Attributes.Contains("niq_opportunityid"))
                                    {
                                        PostOpportunityChangeRequest["niq_opportunity"] = (EntityReference)preImageProject.GetAttributeValue<EntityReference>("niq_opportunityid");
                                        tracing.Trace("OnUpdate_Project_FieldStartDateAndDeliveryDate_CreatePOCR: contains oppo ");
                                    }
                                    EntityCollection pocrCollection = isPendinPOCRExists(service, 100000009, preImageProject.GetAttributeValue<EntityReference>("niq_opportunityid").Id.ToString(), tracing);
                                    tracing.Trace(pocrCollection.Entities.ToString());
                                    if (pocrCollection.Entities.Count > 0)
                                    {
                                        Entity existingPOCR = new Entity("niq_postopportunity");
                                        existingPOCR.Id = pocrCollection.Entities[0].Id;
                                        existingPOCR["niq_newprojectdeliverydate"] = deliveryDate;
                                        existingPOCR["niq_previousprojectdeliverydate"] = preImageDeliveryDate;
                                        service.Update(existingPOCR);
                                        tracing.Trace("OnUpdate_Project_FieldStartDateAndDeliveryDate_CreatePOCR:Project Delivery Date Change- record Updated ");
                                    }
                                    else
                                    {
                                        service.Create(PostOpportunityChangeRequest);
                                        tracing.Trace("OnUpdate_Project_FieldStartDateAndDeliveryDate_CreatePOCR: record created ");
                                    }
                                }
                            }
                            if ((studyLive != preImageStudyLive))
                            {
                                if (billingtype == 100000002 && studyLive == 100000001)
                                {
                                    Entity PostOpportunityChangeRequest = new Entity("niq_postopportunity");
                                    PostOpportunityChangeRequest["niq_currentprojectstartdate"] = fieldStartDate;
                                    tracing.Trace("niq_currentprojectstartdate " + PostOpportunityChangeRequest["niq_currentprojectstartdate"]);
                                    PostOpportunityChangeRequest["niq_newprojectdeliverydate"] = deliveryDate;
                                    tracing.Trace("niq_newprojectdeliverydate " + PostOpportunityChangeRequest["niq_newprojectdeliverydate"]);
                                    PostOpportunityChangeRequest["niq_typeofchange"] = new OptionSetValue(100000008);
                                    PostOpportunityChangeRequest["niq_descriptionofchange"] = "Project Study Live Change";
                                    if (preImageProject.Attributes.Contains("niq_opportunityid"))
                                    {
                                        PostOpportunityChangeRequest["niq_opportunity"] = (EntityReference)preImageProject.GetAttributeValue<EntityReference>("niq_opportunityid");
                                        tracing.Trace("OnUpdate_Project_FieldStartDateAndDeliveryDate_CreatePOCR: contains oppo ");
                                    }
                                    EntityCollection pocrCollection = isPendinPOCRExists(service, 100000008, preImageProject.GetAttributeValue<EntityReference>("niq_opportunityid").Id.ToString(), tracing);
                                    tracing.Trace(pocrCollection.Entities.ToString());
                                    if (pocrCollection.Entities.Count > 0)
                                    {
                                        Entity existingPOCR = new Entity("niq_postopportunity");
                                        existingPOCR.Id = pocrCollection.Entities[0].Id;
                                        existingPOCR["niq_currentprojectstartdate"] = fieldStartDate;
                                        existingPOCR["niq_newprojectdeliverydate"] = deliveryDate;
                                        service.Update(existingPOCR);
                                        tracing.Trace("OnUpdate_Project_FieldStartDateAndDeliveryDate_CreatePOCR:Project Delivery Date Change- record Updated ");
                                    }
                                    else
                                    {
                                        service.Create(PostOpportunityChangeRequest);
                                        tracing.Trace("OnUpdate_Project_FieldStartDateAndDeliveryDate_CreatePOCR: record created ");
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        public EntityCollection isPendinPOCRExists(IOrganizationService service, int type, string opportunityId, ITracingService tracing)
        {
            try
            {
                QueryExpression getPOCRRecords = new QueryExpression("niq_postopportunity");
                getPOCRRecords.Criteria.AddCondition("niq_opportunity", ConditionOperator.Equal, new Guid(opportunityId));
                getPOCRRecords.Criteria.AddCondition("niq_approvalstatus", ConditionOperator.Equal, 1);
                getPOCRRecords.Criteria.AddCondition("niq_typeofchange", ConditionOperator.Equal, type);
                EntityCollection pocrCollection = service.RetrieveMultiple(getPOCRRecords);
                return pocrCollection;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }

        }
    }
}