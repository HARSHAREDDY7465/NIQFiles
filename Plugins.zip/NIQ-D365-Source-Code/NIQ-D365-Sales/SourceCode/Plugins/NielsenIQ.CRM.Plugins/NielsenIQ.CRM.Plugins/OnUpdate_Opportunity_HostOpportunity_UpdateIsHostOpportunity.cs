﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;


namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Opportunity_HostOpportunity_UpdateIsHostOpportunity : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdateOpportunity_HostOpportunity_UpdateIsHostOpportunity: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity opportunityObj = (Entity)context.InputParameters["Target"];
                    if (opportunityObj.Contains("niq_hostopportunity") && opportunityObj["niq_hostopportunity"] != null)
                    {
                        tracing.Trace("niq_hostopportunity: " + opportunityObj["niq_hostopportunity"].ToString());
                        Entity opportunity = service.Retrieve(opportunityObj.LogicalName, opportunityObj.Id, new ColumnSet("niq_ishostopportunity"));
                        if(opportunity.Contains("niq_ishostopportunity") && opportunity.GetAttributeValue<bool>("niq_ishostopportunity") == true)
                        {
                            throw new InvalidPluginExecutionException("Opportunity you are trying to connect with host is already a host opportunity. This action is not supported");
                            return;
                        }

                        Guid hostOppLookup = opportunityObj.GetAttributeValue<EntityReference>("niq_hostopportunity").Id;
                        //EntityReference hostOppLookup = new EntityReference();
                        //hostOppLookup = opportunityObj.GetAttributeValues<EntityReference>("niq_hostopportunity").Id;

                        tracing.Trace("hostOppLookup id : " + hostOppLookup);

                        if (hostOppLookup != null)
                        {
                            Entity hostRecord = service.Retrieve(opportunityObj.LogicalName, hostOppLookup, new ColumnSet("niq_ishostopportunity"));
                            hostRecord["niq_ishostopportunity"] = true;

                            service.Update(hostRecord);
                            CheckPrevOppHost(tracing, context, service, opportunityObj);
                        }
                    }
                    else
                    {
                        tracing.Trace("Entering else part : hostLookup is null");
                        //Guid hostOppLookup = opportunityObj.GetAttributeValue<EntityReference>("niq_hostopportunity").Id;
                        tracing.Trace("hasPreImage :" + context.PreEntityImages.Contains("OppPreImage"));
                        CheckPrevOppHost(tracing, context, service, opportunityObj);

                    }
                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private static void CheckPrevOppHost(ITracingService tracing, IPluginExecutionContext context, IOrganizationService service, Entity opportunityObj)
        {
            if (context.PreEntityImages.Contains("OppPreImage"))
            {
                Entity preImage = (Entity)context.PreEntityImages["OppPreImage"];
                tracing.Trace("preImage :" + preImage.Id);
                tracing.Trace("hasPreImage : " + preImage.Contains("niq_hostOpportunity"));

                if (preImage != null)
                {
                    Guid prevOppLookupValue = preImage.Attributes.Contains("niq_hostopportunity") ? preImage.GetAttributeValue<EntityReference>("niq_hostopportunity").Id : Guid.Empty;
                    tracing.Trace("prevLookupValue : " + prevOppLookupValue);

                    if (prevOppLookupValue != Guid.Empty)
                    {

                        QueryExpression query = new QueryExpression("opportunity");
                        query.Criteria.AddCondition("niq_hostopportunity", ConditionOperator.Equal, prevOppLookupValue);

                        EntityCollection results = service.RetrieveMultiple(query);
                        tracing.Trace("query results : " + results);
                        tracing.Trace(results.Entities.Count.ToString());
                        if (results.Entities.Count == 0)
                        {
                            Entity hostRecord = service.Retrieve(opportunityObj.LogicalName, prevOppLookupValue, new ColumnSet("niq_ishostopportunity"));
                            hostRecord["niq_ishostopportunity"] = false;

                            service.Update(hostRecord);
                        }
                    }


                }
            }
        }
    }
}
