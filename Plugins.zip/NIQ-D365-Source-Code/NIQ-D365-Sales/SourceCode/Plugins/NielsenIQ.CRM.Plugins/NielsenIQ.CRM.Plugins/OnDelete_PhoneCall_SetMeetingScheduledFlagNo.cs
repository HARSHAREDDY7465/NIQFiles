﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;
using System.Collections.Generic;
using NielsenIQ.CRM.Plugins.Helper;

namespace NielsenIQ.CRM.Plugins
{
    public class OnDelete_PhoneCall_SetMeetingScheduledFlagNo : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                
                if (context.MessageName == "Delete")
                {
                    tracing.Trace("OnDelete_PhoneCall_SetMeetingScheduledFlagNo - Entering context Delete");
                    string phoneCallId = string.Empty;
                    string regObjIdLead = string.Empty;

                    Entity preImage = context.PreEntityImages.Contains("Image") ? (Entity)context.PreEntityImages["Image"] : new Entity();
                    if (preImage.Contains("activityid") && preImage.GetAttributeValue<Guid>("activityid") != null)
                    {
                        tracing.Trace("OnDelete_PhoneCall_SetMeetingScheduledFlagNo - Entering PreImage");
                        phoneCallId = Convert.ToString(preImage.GetAttributeValue<Guid>("activityid"));
                        tracing.Trace("OnDelete_PhoneCall_SetMeetingScheduledFlagNo: PhoneCall ID: " + phoneCallId.ToString());
                    }
                    if (preImage.Contains("regardingobjectid") && preImage.GetAttributeValue<EntityReference>("regardingobjectid") != null)
                    {
                        regObjIdLead = Convert.ToString(preImage.GetAttributeValue<EntityReference>("regardingobjectid").Id);
                        tracing.Trace("OnDelete_PhoneCall_SetMeetingScheduledFlagNo: regObjIdLead ID: " + regObjIdLead.ToString());
                    }

                    EntityReference regardingRef = preImage.GetAttributeValue<EntityReference>("regardingobjectid");
                    bool islead = regardingRef.LogicalName == "lead";
                    tracing.Trace("OnDelete_PhoneCall_SetMeetingScheduledFlagNo: Is regarding Lead Entity: " + islead.ToString());

                    if (islead && !string.IsNullOrEmpty(regObjIdLead))
                    {
                        string activityStage = string.Empty;
                        string activityStageStartedOn = string.Empty;

                        Entity entityLead = GetLeadToOppData(service, tracing, regObjIdLead);
                        if (entityLead != null && entityLead.FormattedValues["activestageid"].ToString() == "Sales Ready")
                        {
                            tracing.Trace("OnDelete_PhoneCall_SetMeetingScheduledFlagNo: activityStage: " + entityLead.FormattedValues["activestageid"].ToString());
                            activityStageStartedOn = entityLead["activestagestartedon"].ToString();
                            tracing.Trace("OnDelete_PhoneCall_SetMeetingScheduledFlagNo: activityStageStartedOn: " + activityStageStartedOn);

                            int phoneCallCount = GetPhoneCallList(service, tracing, activityStageStartedOn, new Guid(regObjIdLead));
                            int appointmentCount = GeAppointmentList(service, tracing, activityStageStartedOn, new Guid(regObjIdLead));
                            tracing.Trace("OnDelete_PhoneCall_SetMeetingScheduledFlagNo: phoneCallCount: " + phoneCallCount.ToString());
                            tracing.Trace("OnDelete_PhoneCall_SetMeetingScheduledFlagNo: appointmentCount: " + appointmentCount.ToString());
                            if (phoneCallCount == 0 && appointmentCount == 0)
                            {
                                Entity updLead = new Entity("lead", new Guid(regObjIdLead));
                                updLead["niq_mqlappointment"] = false;
                                service.Update(updLead);
                                tracing.Trace("OnDelete_Appointment_SetMeetingScheduledFlagNo: Meeting flag updated to No");
                            }
                        }
                    } 
                }
            }
            catch (Exception ex)
            {
                tracing.Trace("Exception in OnDelete_PhoneCall_SetMeetingScheduledFlagNo: " + ex.Message);
               // throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        /// <summary>
        /// Method to get Lead record from Lead To Opportunity Process entity for Sales Ready Stage
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracing"></param>
        /// <param name="leadGuid"></param>
        /// <returns></returns>
        public Entity GetLeadToOppData(IOrganizationService service, ITracingService tracing, string leadGuid)
        {
            Entity leadToOpp = new Entity();
            try
            {
                if (leadGuid != string.Empty)
                {
                    tracing.Trace("Entering GetLeadToOppData");
                    var query1 = new QueryExpression("niq_leadtoopportunityprocess")
                    {
                        ColumnSet = new ColumnSet(true),                        
                        LinkEntities=
                        {
                            new LinkEntity("niq_leadtoopportunityprocess", "lead", "bpf_leadid", "leadid", JoinOperator.Inner)
                            {
                                LinkCriteria = new FilterExpression()
                                {
                                    Conditions =
                                    {
                                        new ConditionExpression("leadid", ConditionOperator.Equal, leadGuid)
                                    }
                                }
                            }                            
                        },
                    };
                    EntityCollection entitylist = service.RetrieveMultiple(query1);
                    if (entitylist.Entities.Count > 0 && entitylist.Entities[0] != null)
                    {
                        leadToOpp = entitylist.Entities.FirstOrDefault();
                        //tracing.Trace("GetLeadToOppData: activestageid: " + leadToOpp.FormattedValues["activestageid"].ToString());
                        //tracing.Trace("GetLeadToOppData: activestagestartedon: " + leadToOpp.Attributes["activestagestartedon"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                tracing.Trace("Exception in GetLeadToOppData: " + ex.Message);
                return null;
            }
            tracing.Trace("Exiting GetLeadToOppData");
            return leadToOpp;
        }

        /// <summary>
        /// Method to get the list of Phone Call activity under Open status for the regardingObjid
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracing"></param>
        /// <param name="activityStartedOnDate"></param>
        /// <param name="regObjId"></param>
        /// <returns></returns>
        public int GetPhoneCallList(IOrganizationService service, ITracingService tracing, string activityStartedOnDate, Guid regObjId)
        {
            int phoneCallListCount = 0;
            try
            {
                if (activityStartedOnDate != string.Empty)
                {
                    tracing.Trace("Entering GetPhoneCallList");
                    DateTime date = Convert.ToDateTime(activityStartedOnDate);                    
                    var query1 = new QueryExpression("phonecall")
                    {
                        ColumnSet = new ColumnSet(true),
                        Criteria =
                            {
                                Conditions =
                                {
                                    new ConditionExpression("createdon", ConditionOperator.GreaterEqual, date),
                                    new ConditionExpression("statecode", ConditionOperator.In, new object[] { 0, 1}),
                                    new ConditionExpression("regardingobjectid", ConditionOperator.Equal, regObjId),
                                }
                            }
                    };
                    EntityCollection entitylist = service.RetrieveMultiple(query1);                    
                    if (entitylist.Entities.Count > 0 && entitylist.Entities[0] != null)
                    {
                        phoneCallListCount = entitylist.Entities.Count;
                        tracing.Trace("GetPhoneCallList: phoneCallListCount: " + phoneCallListCount.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                tracing.Trace("Exception in GetPhoneCallList: " + ex.Message);
                return 0;
            }
            tracing.Trace("Exiting GetPhoneCallList");
            return phoneCallListCount;
        }

        /// <summary>
        /// Method to get the list of Appointment activity under Open and Scheduled status for the regardingObjid
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracing"></param>
        /// <param name="activityStartedOnDate"></param>
        /// <param name="regObjId"></param>
        /// <returns></returns>
        public int GeAppointmentList(IOrganizationService service, ITracingService tracing, string activityStartedOnDate, Guid regObjId)
        {
            int appointmentListCount = 0;
            try
            {
                if (activityStartedOnDate != string.Empty)
                {
                    tracing.Trace("Entering GeAppointmentList");
                    DateTime date = Convert.ToDateTime(activityStartedOnDate);
                    var query1 = new QueryExpression("appointment")
                    {
                        ColumnSet = new ColumnSet(true),
                        Criteria =
                            {
                                Conditions =
                                {
                                    new ConditionExpression("createdon", ConditionOperator.GreaterEqual, date),
                                    new ConditionExpression("statecode", ConditionOperator.In, new object[] { 0, 3, 1 }),
                                    new ConditionExpression("regardingobjectid", ConditionOperator.Equal, regObjId),
                                }
                            }
                    };
                    EntityCollection entitylist = service.RetrieveMultiple(query1);
                    if (entitylist.Entities.Count > 0 && entitylist.Entities[0] != null)
                    {
                        appointmentListCount = entitylist.Entities.Count;
                        tracing.Trace("GeAppointmentList: appointmentListCount: " + appointmentListCount.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                tracing.Trace("Exception in GeAppointmentList: " + ex.Message);
                return 0;
            }
            tracing.Trace("Exiting GeAppointmentList");
            return appointmentListCount;
        }

    }
}
