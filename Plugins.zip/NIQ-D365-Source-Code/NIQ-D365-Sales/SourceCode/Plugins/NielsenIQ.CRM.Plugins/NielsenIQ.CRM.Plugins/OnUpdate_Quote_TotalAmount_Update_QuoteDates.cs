﻿using System;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Collections.Generic;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Quote_TotalAmount_Update_QuoteDates : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity quote = (Entity)context.InputParameters["Target"];
                    if (quote != null && quote.Id != Guid.Empty)
                    {
                        if (quote.Attributes.Contains("totalamount"))
                        {
                            tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates:  Input Parameters Keys." + quote.Attributes.Values);


                            string fetchXmlQuoteProducts = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='quotedetail'>
                                                        <attribute name='productid' />
                                                        <attribute name='productdescription' />
                                                        <attribute name='quotedetailid' />
                                                        <attribute name='niq_lineitemstartdate' />
                                                        <attribute name='niq_lineitemenddate' />
                                                        <attribute name='niq_salesorgcodeid' />
                                                        <attribute name='niq_profitcentreid' />
                                                        <attribute name='niq_glaccountid' />
                                                        <order attribute='productid' descending='false' />
                                                        <filter type='and'>
                                                          <condition attribute='quoteid' operator='eq' uitype='quote' value='{0}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";
                            fetchXmlQuoteProducts = string.Format(fetchXmlQuoteProducts, quote.Id);
                            tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates: Getting the quote products.");
                            var quoteProducts = service.RetrieveMultiple(new FetchExpression(fetchXmlQuoteProducts));

                            Entity retQuote = service.Retrieve(quote.LogicalName, quote.Id, new ColumnSet("opportunityid", "pricelevelid", "niq_mainquote"));
                            tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates: ret Oppo= " + retQuote.GetAttributeValue<EntityReference>("opportunityid").LogicalName + " id" + retQuote.GetAttributeValue<EntityReference>("opportunityid").Id);
                            Entity relOppo = service.Retrieve(retQuote.GetAttributeValue<EntityReference>("opportunityid").LogicalName, retQuote.GetAttributeValue<EntityReference>("opportunityid").Id, new ColumnSet("niq_salesorgid", "niq_closeprobability"));
                            Entity updQuote = new Entity(quote.LogicalName, quote.Id);
                            Entity updOppo = new Entity(retQuote.GetAttributeValue<EntityReference>("opportunityid").LogicalName, retQuote.GetAttributeValue<EntityReference>("opportunityid").Id);
                            string fetchXmlOpportunityProduct = @"<fetch distinct='true' no-lock='true' mapping='logical' top='1'>
                                                                    <entity name='opportunityproduct'><attribute name='opportunityproductid' /><attribute name='priceperunit' />
                                                                    <filter type='and'><condition attribute='productdescription' operator='not-null' />
                                                                    <condition attribute='opportunityid' operator='eq' value='" + retQuote.GetAttributeValue<EntityReference>("opportunityid").Id + "' />" +
                                                                    "</filter></entity></fetch>";
                            Entity updOppLineWP = ((EntityCollection)service.RetrieveMultiple(new FetchExpression(fetchXmlOpportunityProduct))).Entities.FirstOrDefault();
                            tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates: Getting the Related Opportunity ." + relOppo.Id);
                            if (quoteProducts != null && quoteProducts.Entities != null && quoteProducts.Entities.Count > 0)
                            {
                                tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates: quoteproducts count = " + quoteProducts.Entities.Count);
                                decimal weightedAmount = decimal.MinValue;
                                decimal totalAmount = quote.GetAttributeValue<Money>("totalamount").Value;
                                tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates: totalamount" + totalAmount);


                                int oppoProbability = (int)relOppo.GetAttributeValue<OptionSetValue>("niq_closeprobability").Value;
                                tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates: oppoprob" + oppoProbability);
                                switch (oppoProbability)
                                {
                                    case 100000000:
                                        weightedAmount = 0;
                                        break;
                                    case 100000001:
                                        weightedAmount = (totalAmount * (decimal)0.10);
                                        break;
                                    case 100000002:
                                        weightedAmount = (totalAmount * (decimal)0.25);
                                        break;
                                    case 100000003:
                                        weightedAmount = (totalAmount * (decimal)0.50);
                                        break;
                                    case 100000004:
                                        weightedAmount = (totalAmount * (decimal)0.75);
                                        break;
                                    case 100000005:
                                        weightedAmount = (totalAmount * (decimal)0.90);
                                        break;
                                    case 100000006:
                                        weightedAmount = (decimal)(totalAmount);
                                        break;
                                    default:
                                        break;
                                }
                                tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates: weightedamount" + weightedAmount);
                                if (weightedAmount != decimal.MinValue)
                                {
                                    updQuote["niq_weightedamountnew"] = new Money(weightedAmount);
                                    updOppo["niq_weightedamount"] = new Money(weightedAmount);
                                }

                                tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates: updating quote date.....");
                                service.Update(updQuote);
                                tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates: Sucess");
                                if (retQuote.Attributes.Contains("niq_mainquote") && retQuote.GetAttributeValue<bool>("niq_mainquote"))
                                {
                                    service.Update(updOppo);
                                    if (updOppLineWP != null && updOppLineWP.Id != Guid.Empty)
                                    {
                                        tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates: updatng Oppo Line WP....." + updOppLineWP.Id);
                                        updOppLineWP["priceperunit"] = totalAmount;
                                        service.Update(updOppLineWP);
                                        tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates: sucess");
                                    }
                                }


                            }
                            else
                            {
                                updQuote["niq_discountamount"] = null;
                                updQuote["niq_ratecardprice"] = null;
                                updQuote["niq_discount"] = null;
                                updQuote["niq_contractstartdate"] = null;
                                updQuote["niq_contractenddate"] = null;
                                updOppo["niq_contractstartdate"] = null;
                                updOppo["niq_contractenddate"] = null;
                                updOppo["totalamount"] = null;
                                updQuote["niq_weightedamountnew"] = null;
                                updOppo["niq_weightedamount"] = null;
                                tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates: updating quote date.....");
                                service.Update(updQuote);
                                tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates: Sucess");
                                if (retQuote.Attributes.Contains("niq_mainquote") && retQuote.GetAttributeValue<bool>("niq_mainquote"))
                                {
                                    if (updOppLineWP != null && updOppLineWP.Id != Guid.Empty)
                                    {
                                        tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates: updatng Oppo Line WP to 0....." + updOppLineWP.Id);
                                        updOppLineWP["priceperunit"] = new Money((decimal)0);
                                        service.Update(updOppLineWP);
                                        tracing.Trace("OnUpdate_Quote_TotalAmount_Update_QuoteDates: sucess to 0");
                                    }
                                    service.Update(updOppo);

                                }

                            }
                        }
                        if (quote.Attributes.Contains("totalamount"))
                        {
                            decimal rateCardPrice = 0;
                            decimal discountPer = 0;
                            decimal discountAmount = 0;
                            Entity UpdQuote = new Entity(quote.LogicalName, quote.Id);
                            string fetchQP = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='quotedetail'>
                                                <attribute name='manualdiscountamount' />
                                                <attribute name='quotedetailname' />
                                                <attribute name='quotedetailid' />
                                                <attribute name='niq_discountqp' />
                                                <attribute name='baseamount' />
                                                <order attribute='quotedetailname' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='quoteid' operator='eq' uitype='quote' value='{0}' />
                                                  <condition attribute='baseamount' operator='not-null' />
                                                </filter>
                                              </entity>
                                            </fetch>";
                            fetchQP = string.Format(fetchQP, quote.Id);
                            var resultQP = service.RetrieveMultiple(new FetchExpression(fetchQP));
                            if (resultQP != null && resultQP.Entities != null && resultQP.Entities.Count > 0)
                            {

                                bool isUpdate = false;
                                foreach (Entity quoteP in resultQP.Entities)
                                {
                                    if (quoteP.Attributes.Contains("baseamount"))
                                    {
                                        rateCardPrice += quoteP.GetAttributeValue<Money>("baseamount").Value;
                                        isUpdate = true;

                                    }
                                    if (quoteP.Attributes.Contains("manualdiscountamount"))
                                    {
                                        discountAmount += quoteP.GetAttributeValue<Money>("manualdiscountamount").Value;
                                        isUpdate = true;

                                    }
                                    if (quoteP.Attributes.Contains("niq_discountqp") && (quoteP.GetAttributeValue<decimal>("niq_discountqp") != (decimal)0))
                                    {
                                        discountPer += quoteP.GetAttributeValue<decimal>("niq_discountqp");
                                        isUpdate = true;

                                    }

                                }
                                if (isUpdate)
                                {
                                    UpdQuote["niq_discountamount"] = new Money((decimal)discountAmount);
                                    UpdQuote["niq_ratecardprice"] = new Money((decimal)rateCardPrice);
                                    if (rateCardPrice != 0)
                                    {
                                        UpdQuote["niq_discount"] = (decimal)((discountAmount / rateCardPrice) * 100);
                                    }
                                    else
                                    {
                                        UpdQuote["niq_discount"] = null;
                                    }

                                    service.Update(UpdQuote);
                                }
                            }
                            else
                            {
                                UpdQuote["niq_discountamount"] = null;
                                UpdQuote["niq_ratecardprice"] = null;
                                UpdQuote["niq_discount"] = null;
                                service.Update(UpdQuote);
                            }
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
