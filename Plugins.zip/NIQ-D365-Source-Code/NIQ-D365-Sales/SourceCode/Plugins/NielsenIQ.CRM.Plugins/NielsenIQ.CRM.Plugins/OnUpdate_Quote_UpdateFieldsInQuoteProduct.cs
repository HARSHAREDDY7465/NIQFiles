﻿// This plugin will update start date, end date and frequency fields.
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.Plugins.Helper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Quote_UpdateFieldsInQuoteProduct : IPlugin
    {
        EntityReference salesOrg = new EntityReference();
        OrganizationRequestCollection updateRequests = new OrganizationRequestCollection();
        ExecuteMultipleResponse executeMultipleResponse = new ExecuteMultipleResponse();
        Entity targetEntity = new Entity();
        Entity quoteEntity = new Entity();
        ITracingService tracingService;
        IOrganizationService service;
        ArrayList startDateArrayList = new ArrayList();
        ArrayList endDateArrayList = new ArrayList();
        string url = string.Empty;
        Entity quote = new Entity("quote");
        string fetchXml = string.Empty;
        DateTime[] startdate = null;
        DateTime[] enddate = null;
        bool expValidation = false;
        // Step 3: Map PriceListItem records by their primary id
        Dictionary<Guid, Entity> priceListItemMapping = new Dictionary<Guid, Entity>();
        Entity opportunity = new Entity("opportunity");
        EntityCollection priceListItemResults = null;
        OptionSetValue InCompleteManualInput = new OptionSetValue(610570001);
        OptionSetValue InCompleteSchedulesAuto = new OptionSetValue(610570002);

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                service = serviceFactory.CreateOrganizationService(context.UserId);
                int billingFrequencyOSV = -1;
                tracingService.Trace("context.Depth:" + context.Depth);
                tracingService.Trace("context.MessageName:" + context.MessageName.ToLower());
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity && context.MessageName.ToLower() == "update")
                {

                    tracingService.Trace("Execution Begins");
                    //Get Target quoteProduct
                    targetEntity = (Entity)context.InputParameters["Target"];

                    //get expvalidation field
                    if (targetEntity.Contains("niq_expvalidation") && targetEntity.Attributes["niq_expvalidation"] != null)
                    {
                        expValidation = targetEntity.GetAttributeValue<bool>("niq_expvalidation");
                    }
                    if (context.Depth == 1)
                    {
                        quote.Id = targetEntity.Id;
                        if (expValidation)
                        {
                            quote["niq_asyncprocessinprogress"] = true;
                        }
                        else
                        {
                            quote["niq_asyncprocessinprogress"] = false;
                        }

                        service.Update(quote);
                        tracingService.Trace("Quote Updated");
                    }
                    //Validate Target Entity
                    if (context.Depth == 2 && context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity && context.MessageName.ToLower() == "update")
                    {
                        tracingService.Trace("expValidation:" + expValidation);
                        //Check Entity Name and Message Nam]
                        tracingService.Trace("LogicalName" + targetEntity.LogicalName);
                        tracingService.Trace("MessageName" + context.MessageName.ToLower());

                        string currentStage = "";
                        int oppType = -1;
                        int contractAction = -1;
                        bool autoRenewal = false;
                        if (context.PostEntityImages.Contains("PostImage"))
                        {
                            Entity postImage = context.PostEntityImages["PostImage"];
                            EntityReference opportunityEntRef = postImage.Contains("opportunityid") && postImage.GetAttributeValue<EntityReference>("opportunityid") != null ? postImage.GetAttributeValue<EntityReference>("opportunityid") : null;
                            Entity opportunityDetails = service.Retrieve(opportunityEntRef.LogicalName, opportunityEntRef.Id, new ColumnSet("niq_stage", "niq_opportunitytype", "niq_existingcontractaction", "niq_automaticrenewal", "niq_opportunitynumber"));
                            tracingService.Trace("opportunityID: " + opportunityEntRef.Id);
                            string oppNumber = opportunityDetails.Contains("niq_opportunitynumber") && opportunityDetails["niq_opportunitynumber"] != null ? opportunityDetails.GetAttributeValue<string>("niq_opportunitynumber") : null;
                            tracingService.Trace("opportunityNumber: " + oppNumber);
                            oppType = opportunityDetails.Contains("niq_opportunitytype") && opportunityDetails["niq_opportunitytype"] != null ? opportunityDetails.GetAttributeValue<OptionSetValue>("niq_opportunitytype").Value : -1;
                            tracingService.Trace("OpportunityType: " + oppType);
                            contractAction = opportunityDetails.Contains("niq_existingcontractaction") && opportunityDetails["niq_existingcontractaction"] != null ? opportunityDetails.GetAttributeValue<OptionSetValue>("niq_existingcontractaction").Value : -1;
                            tracingService.Trace("ExistingContractAction: " + contractAction);
                            autoRenewal = opportunityDetails.Contains("niq_automaticrenewal") ? opportunityDetails.GetAttributeValue<bool>("niq_automaticrenewal") : false;
                            tracingService.Trace("AutoRenewal: " + autoRenewal);

                            bool isNewSale = oppType == 1;
                            bool isEvergreen = oppType == 2 && contractAction == 3;
                            bool isPE_COLA = oppType == 2 && contractAction == 2;
                            bool isAutoRenewal = oppType == 2 && contractAction == 1 && autoRenewal;

                            if (isNewSale || isEvergreen || isPE_COLA || isAutoRenewal)
                            {
                                tracingService.Trace("Not an Amendment or manual renewal opportunity. Continuing execution.  New Sale - " + isNewSale + ", Evergreen - " + isEvergreen + ", PE COLA - " + isPE_COLA + ", Auto Renewal - " + isAutoRenewal);
                            }
                            else
                            {
                                tracingService.Trace("This is either a Amendment or manual renewal opportunity. Terminating execution.  New Sale - " + isNewSale + ", Evergreen - " + isEvergreen + ", PE COLA - " + isPE_COLA + ", Auto Renewal - " + isAutoRenewal);
                                return;
                            }
                            if (opportunityDetails.Contains("niq_stage") && opportunityDetails["niq_stage"] != null)
                            {
                                currentStage = opportunityDetails.GetAttributeValue<string>("niq_stage");
                                tracingService.Trace("current stage: " + currentStage);
                            }
                        }

                        if (targetEntity.Id != Guid.Empty && !expValidation)
                        {
                            //Create query to get all quote products associated with quote
                            var quoteProdycuctQuery = BuildQuoteProductQuery(targetEntity.Id);
                            quoteProdycuctQuery.NoLock = true;
                            ///Get all quote products associated with quote
                            EntityCollection quoteProductResults = service.RetrieveMultiple(quoteProdycuctQuery);
                            tracingService.Trace("Count" + quoteProductResults.Entities.Count);

                            if (quoteProductResults.Entities.Count == 0)
                            {
                                quote.Id = targetEntity.Id;
                                quote["niq_asyncprocessinprogress"] = false;
                                service.Update(quote);
                                tracingService.Trace("Quote Updated");
                                return;
                            }

                            List<Guid> productPriceLevelIds = new List<Guid>();
                            foreach (Entity quoteProduct in quoteProductResults.Entities)
                            {
                                string priceListItemId = quoteProduct.Contains("niq_pricelistitem") && quoteProduct.Attributes["niq_pricelistitem"] != null ? quoteProduct.GetAttributeValue<string>("niq_pricelistitem") : string.Empty;
                                tracingService.Trace("priceListItemId:" + priceListItemId);

                                if (priceListItemId != string.Empty)
                                {
                                    productPriceLevelIds.Add(new Guid(priceListItemId));
                                }
                            }
                            tracingService.Trace("productPriceLevelIds:" + productPriceLevelIds.Count);

                            if (productPriceLevelIds.Count > 0)
                            {
                                // Step 2: Retrieve PriceListItem records
                                QueryExpression query = new QueryExpression("productpricelevel");
                                query.ColumnSet = new ColumnSet("productpricelevelid", "niq_billingfrequency", "niq_lagrevenuerecognition", "niq_revenuefrequency", "niq_updatefrequency", "productid", "niq_istimebased");
                                query.Criteria = new FilterExpression(); // Initialize the Criteria property
                                ConditionExpression condition = new ConditionExpression("productpricelevelid", ConditionOperator.In, productPriceLevelIds.ToArray()); // Convert the list to an array
                                query.Criteria.AddCondition(condition);
                                query.NoLock = true;

                                priceListItemResults = service.RetrieveMultiple(query);
                                tracingService.Trace("priceListItemResults:" + priceListItemResults.Entities.Count);

                                foreach (Entity priceListItem in priceListItemResults.Entities)
                                {
                                    if (priceListItem.Contains("productpricelevelid"))
                                    {
                                        priceListItemMapping[priceListItem.Id] = priceListItem;
                                    }
                                }
                            }

                            foreach (Entity quoteProduct in quoteProductResults.Entities)
                            {
                                Entity updateQuoteProduct = new Entity("quotedetail");
                                string priceListItemGuid = quoteProduct.Contains("niq_pricelistitem") && quoteProduct.GetAttributeValue<string>("niq_pricelistitem") != null ? quoteProduct.GetAttributeValue<string>("niq_pricelistitem") : string.Empty;
                                string databaseName = quoteProduct.Contains("niq_databasename") && quoteProduct.GetAttributeValue<string>("niq_databasename") != null ? quoteProduct.GetAttributeValue<string>("niq_databasename") : string.Empty;
                                OptionSetValue productType = quoteProduct.Contains("niq_type") ? quoteProduct.GetAttributeValue<OptionSetValue>("niq_type") : null;

                                DateTime quoteProductCreatedOrStartDate = quoteProduct.GetAttributeValue<DateTime>("createdon");
                                double termLength = quoteProduct.Contains("niq_termlength") && quoteProduct.Attributes["niq_termlength"] != null ? quoteProduct.GetAttributeValue<double>("niq_termlength") : 0;
                                tracingService.Trace("termLength" + termLength);
                                string rateCardUpdateFrequency = quoteProduct.Contains("niq_ratecardupdatefrequency") && quoteProduct.GetAttributeValue<string>("niq_ratecardupdatefrequency") != null ? quoteProduct.GetAttributeValue<string>("niq_ratecardupdatefrequency") : string.Empty;
                                tracingService.Trace("rateCardUpdateFrequency:" + rateCardUpdateFrequency);
                                bool isTimeBased = false;
                                if (!string.IsNullOrEmpty(priceListItemGuid) && priceListItemMapping.ContainsKey(new Guid(priceListItemGuid)))
                                {
                                    Entity priceListItemEnt = priceListItemMapping[new Guid(priceListItemGuid)];
                                    isTimeBased = priceListItemEnt.GetAttributeValue<bool>("niq_istimebased");
                                    tracingService.Trace("isTimeBased:" + isTimeBased);
                                    if (productType != null && productType.Value == 1 && !isTimeBased & termLength == 0 && rateCardUpdateFrequency == string.Empty)
                                    {
                                        updateQuoteProduct["niq_istimebased"] = isTimeBased;
                                        tracingService.Trace("isTimeBased:" + isTimeBased);

                                        billingFrequencyOSV = CommonHelper.SetBillingFrequency(priceListItemEnt, updateQuoteProduct, tracingService);
                                        if (billingFrequencyOSV != -1) updateQuoteProduct["niq_billingfrequency"] = new OptionSetValue(billingFrequencyOSV);
                                        tracingService.Trace("niq_billingfrequency" + billingFrequencyOSV);

                                        updateQuoteProduct["niq_lagrevenuerecognition"] = new OptionSetValue(100000000);

                                        if (!quoteProduct.Contains("niq_updatefrequency") && !quoteProduct.Contains("niq_ratecardupdatefrequency"))
                                        {
                                            int updateFrequnencyOSV = CommonHelper.GetUpdateFrequency(priceListItemEnt, tracingService);
                                            if (updateFrequnencyOSV != -1) updateQuoteProduct["niq_updatefrequency"] = new OptionSetValue(updateFrequnencyOSV);

                                            int deliveryfrequencyOSV = CommonHelper.GetDeliveryFrequency(priceListItemEnt, tracingService);
                                            if (deliveryfrequencyOSV != -1)
                                            {
                                                updateQuoteProduct["niq_deliveryfrequency"] = new OptionSetValue(deliveryfrequencyOSV);
                                                tracingService.Trace("niq_deliveryfrequency" + deliveryfrequencyOSV);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        updateQuoteProduct["niq_istimebased"] = isTimeBased;
                                        tracingService.Trace("isTimeBased:" + isTimeBased);
                                        billingFrequencyOSV = CommonHelper.SetBillingFrequency(priceListItemEnt, updateQuoteProduct, tracingService);
                                        if (billingFrequencyOSV != -1) updateQuoteProduct["niq_billingfrequency"] = new OptionSetValue(billingFrequencyOSV);
                                        tracingService.Trace("niq_billingfrequency" + billingFrequencyOSV);
                                        tracingService.Trace("databaseName:" + databaseName);

                                        int lagRevenueRecognitionOSV = CommonHelper.SetLagRevenueRecognition(priceListItemEnt, tracingService);
                                        if (lagRevenueRecognitionOSV != -1)
                                        {
                                            //always no lag
                                            updateQuoteProduct["niq_lagrevenuerecognition"] = new OptionSetValue(lagRevenueRecognitionOSV);
                                            tracingService.Trace("niq_lagrevenuerecognition" + lagRevenueRecognitionOSV);
                                        }

                                        //int deliveryfrequencyOSV = GetDeliveryFrequency(priceListItemEnt, tracingService);
                                        //if (deliveryfrequencyOSV != -1)
                                        //{
                                        //    updateQuoteProduct["niq_deliveryfrequency"] = new OptionSetValue(deliveryfrequencyOSV);
                                        //    tracingService.Trace("niq_deliveryfrequency" + deliveryfrequencyOSV);
                                        //}
                                        //    }

                                        if (!quoteProduct.Contains("niq_updatefrequency") && quoteProduct.Contains("niq_ratecardupdatefrequency"))
                                        {
                                            CommonHelper.SetFrequencyforRateCateProduct(tracingService, service, quoteProduct, productType, isTimeBased, ref updateQuoteProduct);
                                        }
                                        else if (!quoteProduct.Contains("niq_updatefrequency") && !quoteProduct.Contains("niq_ratecardupdatefrequency"))
                                        {
                                            int updateFrequnencyOSV = CommonHelper.GetUpdateFrequency(priceListItemEnt, tracingService);
                                            if (updateFrequnencyOSV != -1) updateQuoteProduct["niq_updatefrequency"] = new OptionSetValue(updateFrequnencyOSV);

                                            int deliveryfrequencyOSV = CommonHelper.GetDeliveryFrequency(priceListItemEnt, tracingService);
                                            if (deliveryfrequencyOSV != -1)
                                            {
                                                updateQuoteProduct["niq_deliveryfrequency"] = new OptionSetValue(deliveryfrequencyOSV);
                                                tracingService.Trace("niq_deliveryfrequency" + deliveryfrequencyOSV);
                                            }
                                        }
                                    }
                                }
                                else if (quoteProduct.Contains("quotedetailname"))
                                {
                                    string productName = quoteProduct.GetAttributeValue<string>("quotedetailname");
                                    tracingService.Trace("productName:" + productName);
                                    if (productName == "Place Holder Product" || productName == "SAP Deferred Revenue reconciliation placeholder")
                                    {
                                        int defaultValue = 100000000;
                                        updateQuoteProduct["niq_lagrevenuerecognition"] = new OptionSetValue(defaultValue);
                                        updateQuoteProduct["niq_deliveryfrequency"] = new OptionSetValue(defaultValue);
                                        updateQuoteProduct["niq_billingfrequency"] = new OptionSetValue(defaultValue);
                                        updateQuoteProduct["niq_updatefrequency"] = new OptionSetValue(defaultValue);
                                        tracingService.Trace("Updating Defaulting values");
                                    }
                                }
                                tracingService.Trace("isTimeBased:" + isTimeBased);
                                tracingService.Trace("termLength:" + termLength);
                                tracingService.Trace("rateCardUpdateFrequency:" + rateCardUpdateFrequency);
                                DateTime nextMonthStartDate = quoteProductCreatedOrStartDate.Day > 1
                                        ? new DateTime(quoteProductCreatedOrStartDate.Year, quoteProductCreatedOrStartDate.Month, 1).AddMonths(1)
                                        : quoteProductCreatedOrStartDate.Date;
                                DateTime endDateTermLength = nextMonthStartDate;
                                tracingService.Trace("nextMonthStartDate:" + nextMonthStartDate);
                                if (productType != null && productType.Value == 1 && !isTimeBased && termLength == 0 && rateCardUpdateFrequency == string.Empty)
                                {
                                    endDateTermLength = nextMonthStartDate.AddMonths(1).AddDays(-1);
                                    tracingService.Trace("endDateTermLength:" + endDateTermLength);
                                    updateQuoteProduct["niq_lineitemstartdate"] = nextMonthStartDate;
                                    updateQuoteProduct["niq_lineitemenddate"] = endDateTermLength;
                                    updateQuoteProduct["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");

                                    if (!string.IsNullOrEmpty(currentStage) && !string.Equals(currentStage.ToLower(), "pre-proposal"))
                                        updateQuoteProduct["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                                }
                                else
                                {
                                    tracingService.Trace("Set Start date and End date");


                                    endDateTermLength = termLength == 0.0f
                                        ? nextMonthStartDate
                                        : nextMonthStartDate.AddMonths((int)termLength).AddDays(-1);

                                    tracingService.Trace("endDateTermLength:" + endDateTermLength);

                                    updateQuoteProduct["niq_lineitemstartdate"] = nextMonthStartDate;
                                    updateQuoteProduct["niq_lineitemenddate"] = endDateTermLength;

                                    if (!string.IsNullOrEmpty(currentStage) && !string.Equals(currentStage.ToLower(), "pre-proposal"))
                                        updateQuoteProduct["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");

                                    updateQuoteProduct["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");

                                    tracingService.Trace("niq_lineitemstartdate:" + nextMonthStartDate);
                                    tracingService.Trace("niq_lineitemenddate:" + endDateTermLength);

                                    startDateArrayList.Add(nextMonthStartDate.Date);
                                    endDateArrayList.Add(endDateTermLength.Date);
                                }

                                // Update billing start/end date for Adhoc Product Type and if Billing frequency is 50/50,80/20,0/100,One Time
                                if (productType != null && productType.Value == 1 && (billingFrequencyOSV == 100000010 || billingFrequencyOSV == 100000011 || billingFrequencyOSV == 100000012 || billingFrequencyOSV == 100000013))
                                {
                                    updateQuoteProduct["niq_billingstartdate"] = nextMonthStartDate;
                                    updateQuoteProduct["niq_billingenddate"] = endDateTermLength;
                                }

                                tracingService.Trace("After data population, revenue and billing schedule status as to be: ");
                                //if the revenue frequency is auto populated.
                                if (updateQuoteProduct.Attributes.Contains("niq_deliveryfrequency") && updateQuoteProduct["niq_deliveryfrequency"] != null)
                                {
                                    if (updateQuoteProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency").Value == 100000009)
                                    {
                                        tracingService.Trace("delivery frequency is custom, so status is IncompleteManualInput");
                                        updateQuoteProduct["niq_revenueschedulestatus"] = new OptionSetValue(InCompleteManualInput.Value);
                                    }
                                    else
                                    {
                                        tracingService.Trace("delivery frequency not custom, so status is IncompleteSchedulesAuto");
                                        updateQuoteProduct["niq_revenueschedulestatus"] = new OptionSetValue(InCompleteSchedulesAuto.Value);
                                    }
                                }
                                //if the billing frequency is auto populated. 
                                if (updateQuoteProduct.Attributes.Contains("niq_billingfrequency") && updateQuoteProduct["niq_billingfrequency"] != null)
                                {
                                    if (updateQuoteProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value == 100000009)
                                    {
                                        tracingService.Trace("billing frequency as custom, so status is IncompleteManualInput");
                                        updateQuoteProduct["niq_billingschedulestatus"] = new OptionSetValue(InCompleteManualInput.Value);
                                    }
                                    else
                                    {
                                        tracingService.Trace("billing frequency not custom, so status is IncompleteSchedulesAuto");
                                        updateQuoteProduct["niq_billingschedulestatus"] = new OptionSetValue(InCompleteSchedulesAuto.Value);
                                    }
                                }


                                tracingService.Trace("quoteproductid" + quoteProduct.Id);
                                updateQuoteProduct.Id = quoteProduct.Id;

                                Entity opportunity = CreateRevShareLine.GetOppOfQuoteDetail(service, quoteProduct, tracingService);

                                if (opportunity != null && opportunity.Contains("niq_hostopportunity") && opportunity.Attributes["niq_hostopportunity"] != null)
                                {
                                    tracingService.Trace("Child Opp:" + opportunity.Id);
                                    EntityReference hostOppRef = opportunity.GetAttributeValue<EntityReference>("niq_hostopportunity");
                                    Entity hostOpp = service.Retrieve(hostOppRef.LogicalName, hostOppRef.Id, new ColumnSet("name"));
                                    //  tracingService.Trace("hostOpp:" + hostOpp.Id);
                                    Entity revSharLine = CreateRevShareLine.GetRevShareLineOfHostOpp(service, opportunity, hostOpp, tracingService);
                                    if (revSharLine != null)
                                    {
                                        updateQuoteProduct["niq_revshareline"] = new EntityReference(revSharLine.LogicalName, revSharLine.Id);
                                    }

                                }

                                var updateRequest = new UpdateRequest { Target = updateQuoteProduct };
                                updateRequests.Add(updateRequest);
                            }

                            tracingService.Trace("updateRequests Count" + updateRequests.Count);
                            if (updateRequests.Count > 0)
                            {
                                tracingService.Trace("updateRequests Count1:" + updateRequests.Count);
                                // Create the ExecuteMultipleRequest object
                                var executeMultipleRequest = new ExecuteMultipleRequest()
                                {
                                    Requests = updateRequests,
                                    Settings = new ExecuteMultipleSettings()
                                    {
                                        ContinueOnError = false,
                                        ReturnResponses = true
                                    }
                                };
                                // Execute the batch request
                                executeMultipleResponse = (ExecuteMultipleResponse)service.Execute(executeMultipleRequest);
                                tracingService.Trace("Records Updated");
                            }

                            tracingService.Trace("startDateArrayList.Count:" + startDateArrayList.Count);
                            //if (startDateArrayList.Count > 0)
                            //{
                            //    startdate = (DateTime[])startDateArrayList.ToArray(typeof(DateTime));
                            //    Array.Sort(startdate);
                            //    quote["niq_contractstartdate"] = startdate[0];
                            //    opportunity["niq_contractstartdate"] = startdate[0];
                            //    tracingService.Trace("startdate:" + startdate[0]);
                            //}
                            //tracingService.Trace("endDateArrayList.Count:" + endDateArrayList.Count);

                            //if (endDateArrayList.Count > 0)
                            //{
                            //    enddate = (DateTime[])endDateArrayList.ToArray(typeof(DateTime));
                            //    Array.Reverse(enddate);
                            //    quote["niq_contractenddate"] = enddate[0];
                            //    opportunity["niq_contractenddate"] = enddate[0];
                            //    tracingService.Trace("Enddate:" + enddate[0]);
                            //}

                            quote.Id = targetEntity.Id;
                            quote["niq_asyncprocessinprogress"] = false;
                            service.Update(quote);
                            if (context.PostEntityImages.Contains("PostImage"))
                            {
                                Entity postImage = context.PostEntityImages["PostImage"];
                                EntityReference opportunityEntRef = postImage.Contains("opportunityid") && postImage.GetAttributeValue<EntityReference>("opportunityid") != null ? postImage.GetAttributeValue<EntityReference>("opportunityid") : null;
                                if (opportunity != null)
                                {
                                    tracingService.Trace("opportunityEntRef" + opportunityEntRef.Id);
                                    opportunity.Id = opportunityEntRef.Id;
                                    service.Update(opportunity);
                                    tracingService.Trace("Contract start Date and end date are Updated on Opportunity");
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }

        }
        public static QueryExpression CreateQuotedetailQuery(Guid quoteId, string databaseName)
        {
            // Create QueryExpression for entity "quotedetail"
            QueryExpression query = new QueryExpression("quotedetail");

            // Define attributes to retrieve (optional based on your requirement)
            query.ColumnSet = new ColumnSet(true); // Retrieve all columns or specify specific ones as needed

            // Define filter criteria
            FilterExpression filter = new FilterExpression(LogicalOperator.And);
            filter.AddCondition("quoteid", ConditionOperator.Equal, quoteId);
            filter.AddCondition("niq_type", ConditionOperator.Equal, 1);
            filter.AddCondition("niq_databasename", ConditionOperator.Equal, databaseName);

            query.Criteria = filter;

            // Execute query to retrieve results from Dynamics 365
            return query;
        }
        public int GetDeliveryFrequency(Entity priceListItemEnt, ITracingService tracingService)
        {
            tracingService.Trace("Inside GetDeliveryFrequency");
            int deliveryFrequencyOSV = priceListItemEnt.Contains("niq_revenuefrequency") && priceListItemEnt["niq_revenuefrequency"] is OptionSetValue
                ? ((OptionSetValue)priceListItemEnt["niq_revenuefrequency"]).Value
                : -1;
            tracingService.Trace("deliveryFrequencyOSV" + deliveryFrequencyOSV);

            return deliveryFrequencyOSV;
        }
        public int SetLagRevenueRecognition(Entity priceListItemEnt, ITracingService tracingService)
        {
            int lagRevenueRecognitionOSV = (priceListItemEnt.Contains("niq_lagrevenuerecognition") && priceListItemEnt["niq_lagrevenuerecognition"] is OptionSetValue)
                ? ((OptionSetValue)priceListItemEnt["niq_lagrevenuerecognition"]).Value
                : -1;

            return lagRevenueRecognitionOSV;
        }
        public int GetUpdateFrequency(Entity priceListItemEnt, ITracingService tracingService)
        {
            int updateFrequencyOSV = priceListItemEnt.Contains("niq_updatefrequency") && priceListItemEnt["niq_updatefrequency"] is OptionSetValue
                ? ((OptionSetValue)priceListItemEnt["niq_updatefrequency"]).Value
                : -1;

            return updateFrequencyOSV;
        }

        public int SetBillingFrequency(Entity priceListItemEnt, Entity updateQuoteProduct, ITracingService tracingService)
        {
            int billingFrequencyOSV = priceListItemEnt.Contains("niq_billingfrequency") && priceListItemEnt.Attributes["niq_billingfrequency"] != null
                ? priceListItemEnt.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value
                : -1;

            tracingService.Trace("niq_billingfrequency set to: " + billingFrequencyOSV);
            return billingFrequencyOSV;
        }

        private Entity isAdhocProductBehavesAsPeriodic(EntityCollection quoteProductResults, string databaseName, IOrganizationService service, IPluginExecutionContext context, ITracingService tracingService)
        {
            Entity entity = null;
            try
            {
                tracingService.Trace("Count:" + quoteProductResults.Entities.Count);
                // Retrieve the first entity matching the criteria
                entity = quoteProductResults.Entities
                    .FirstOrDefault(p => p.Contains("niq_type") && p.GetAttributeValue<OptionSetValue>("niq_type").Value == 2 &&
                                    p.Contains("niq_onplatformdelivery") &&
                                    p.GetAttributeValue<string>("niq_onplatformdelivery") == "Yes" && p.Contains("niq_databasename") &&
                                    p.GetAttributeValue<string>("niq_databasename") == databaseName);

                if (entity != null)
                {
                    return entity;
                }
                else
                {
                    return null;
                }


            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }

        }
        private QueryExpression BuildQuoteProductQuery(Guid _quoteId)
        {
            QueryExpression query = new QueryExpression("quotedetail");

            query.ColumnSet = new ColumnSet("niq_databasename", "quotedetailid", "niq_pricelistitem", "niq_billingfrequency", "niq_deliveryfrequency", "niq_lagrevenuerecognition", "niq_updatefrequency", "createdon", "niq_termlength", "niq_type", "isproductoverridden", "niq_ratecardupdatefrequency", "quotedetailname", "niq_onplatformdelivery");

            FilterExpression filter = new FilterExpression(LogicalOperator.And);
            filter.AddCondition("niq_lineitemstartdate", ConditionOperator.Null);
            filter.AddCondition("niq_lineitemenddate", ConditionOperator.Null);
            filter.AddCondition("niq_updatefrequency", ConditionOperator.Null);
            filter.AddCondition("niq_lagrevenuerecognition", ConditionOperator.Null);
            filter.AddCondition("niq_billingfrequency", ConditionOperator.Null);
            filter.AddCondition("niq_deliveryfrequency", ConditionOperator.Null);
            filter.AddCondition("quoteid", ConditionOperator.Equal, _quoteId);
            query.Criteria = filter;

            return query;

        }

        //This is function is retrieve the all values of Update frequency option set field.
        //And also return the value where rateCardUpdateFrequency eq option set's text.
    }
}
