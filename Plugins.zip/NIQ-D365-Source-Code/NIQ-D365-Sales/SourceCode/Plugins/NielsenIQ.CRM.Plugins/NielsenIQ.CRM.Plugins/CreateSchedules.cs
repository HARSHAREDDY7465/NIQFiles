﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using System.Text.RegularExpressions;

namespace NielsenIQ.CRM.Plugins
{
    public class CreateSchedules : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                bool isRevenueCalc = (bool)context.InputParameters["isRevenueCalc"];
                bool isBillingCalc = (bool)context.InputParameters["isBillingCalc"];
                DateTime startDate = (DateTime)context.InputParameters["startDate"]; //text_1
                DateTime endDate = (DateTime)context.InputParameters["endDate"]; //text_2
                DateTime estimatedCloseDate = (DateTime)context.InputParameters["estimatedClosedDate"]; //text_5
                bool isContinuous = (bool)context.InputParameters["isContinuous"]; //text_6
                bool revenueDateFlag = (bool)context.InputParameters["revenueDateFlag"]; //text_7
                OptionSetValue revenueFrequency = (OptionSetValue)context.InputParameters["RevenueFrequency"];
                int calculatedTermLength = (int)context.InputParameters["CalculatedTermLength"];

                int addMonths = (int)context.InputParameters["addMonths"]; //number
                int lag = (int)context.InputParameters["lag"]; //number_3

                DateTime currentMonth = startDate.AddMonths(lag);
                // List<DateTime> records = new List<DateTime>();
                List<String> records = new List<String>();
                DateTime IncMonths = startDate.AddMonths(lag);
                DateTime scheduleDate;
                DateTime calculatedScheduleDate;

                if (isRevenueCalc)
                {
                    tracing.Trace("inside isRevenueCalc");
                    while (IncMonths < (endDate.AddMonths(lag)))
                    {
                        //if (isContinuous)
                        // DYNCRM-31105 -- Revenue schedules changes based on Short Cycle Characteristic value
                        tracing.Trace("Rev Freq: "+revenueFrequency.Value);
                        tracing.Trace("Calculated TermLength: "+calculatedTermLength);
                        if (!(revenueFrequency.Value  == 100000008 && calculatedTermLength < 12))
                        {
                            if (estimatedCloseDate >= currentMonth)
                            {
                                //records.Add(estimatedCloseDate);
                                // Schedule date is estimatedCloseDate
                                scheduleDate = estimatedCloseDate;
                                // Calculated Schedule Date is the current month (first day)

                                // If the estimated close date falls after the current month and revenueDateFlag is true,
                                // set the calculated schedule date to the end of that month.

                                if (revenueDateFlag)
                                {
                                    DateTime startOfMonth = new DateTime(currentMonth.AddMonths(1).Year, currentMonth.AddMonths(1).Month, 1);
                                    //records.Add(startOfMonth.AddDays(-1));
                                    calculatedScheduleDate = startOfMonth.AddDays(-1);
                                    tracing.Trace($"scheduleDate: {scheduleDate:MM-dd-yyyy}, calculatedScheduleDate: {calculatedScheduleDate:MM-dd-yyyy}");
                                    //calculatedScheduleDate = scheduleDate;
                                }
                                else
                                {
                                    calculatedScheduleDate = new DateTime(currentMonth.Year, currentMonth.Month, 1);
                                    tracing.Trace($"scheduleDate: {scheduleDate:MM-dd-yyyy}, calculatedScheduleDate: {calculatedScheduleDate:MM-dd-yyyy}");
                                }
                            }
                            else if (revenueDateFlag)
                            {
                                DateTime startOfMonth = new DateTime(currentMonth.AddMonths(1).Year, currentMonth.AddMonths(1).Month, 1);
                                //records.Add(startOfMonth.AddDays(-1));
                                scheduleDate = startOfMonth.AddDays(-1);
                                calculatedScheduleDate = scheduleDate;
                            }
                            else
                            {
                                //records.Add(currentMonth);
                                scheduleDate = currentMonth;
                                calculatedScheduleDate = currentMonth;
                            }
                        }
                        else if (revenueDateFlag)
                        {
                            DateTime startOfMonth = new DateTime(currentMonth.AddMonths(1).Year, currentMonth.AddMonths(1).Month, 1);
                            //records.Add(startOfMonth.AddDays(-1));
                            scheduleDate = startOfMonth.AddDays(-1);
                            calculatedScheduleDate = scheduleDate;
                        }
                        else
                        {
                            //records.Add(new DateTime(currentMonth.Year, currentMonth.Month, 1));
                            scheduleDate = new DateTime(currentMonth.Year, currentMonth.Month, 1);
                            calculatedScheduleDate = scheduleDate;
                        }
                        records.Add($"{scheduleDate:MM-dd-yyyy}:{calculatedScheduleDate:MM-dd-yyyy}");
                        IncMonths = currentMonth.AddMonths(addMonths);
                        currentMonth = IncMonths;
                    }
                }
                else if (isBillingCalc)
                {
                    while (currentMonth < endDate.AddMonths(lag))
                    {
                        DateTime toAdd = new DateTime(currentMonth.Year, currentMonth.Month, 1);
                        //records.Add(toAdd);

                        scheduleDate = toAdd;
                        calculatedScheduleDate = toAdd; // Same for both in billing
                        tracing.Trace($"scheduleDate: {scheduleDate:MM-dd-yyyy}, calculatedScheduleDate: {calculatedScheduleDate:MM-dd-yyyy}");
                        records.Add($"{scheduleDate:MM-dd-yyyy}:{calculatedScheduleDate:MM-dd-yyyy}");
                        currentMonth = toAdd.AddMonths(addMonths);
                    }
                }
                context.OutputParameters["result"] = string.Join(",", records);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}