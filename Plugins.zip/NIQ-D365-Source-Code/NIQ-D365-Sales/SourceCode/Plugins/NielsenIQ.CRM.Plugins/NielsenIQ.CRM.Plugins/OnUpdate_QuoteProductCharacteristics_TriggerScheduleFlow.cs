﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;

namespace NielsenIQ.CRM.Plugins
{
   public class OnUpdate_QuoteProductCharacteristics_TriggerScheduleFlow : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_QuoteProductCharacteristics_TriggerScheduleFlow: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity quoteProductcharobj = (Entity)context.InputParameters["Target"];
                    Entity quoteProductchar = service.Retrieve(quoteProductcharobj.LogicalName, quoteProductcharobj.Id, new ColumnSet("niq_quoteid","niq_ismainquote", "niq_quoteproductid"));
                    if (quoteProductchar != null && quoteProductchar.Attributes.Contains("niq_ismainquote") && quoteProductchar.GetAttributeValue<bool>("niq_ismainquote") &&
                       quoteProductchar.Attributes.Contains("niq_quoteproductid") && quoteProductchar.GetAttributeValue<EntityReference>("niq_quoteproductid").Id != Guid.Empty)
                    {
                        Entity quoteProduct = service.Retrieve(quoteProductchar.GetAttributeValue<EntityReference>("niq_quoteproductid").LogicalName, quoteProductchar.GetAttributeValue<EntityReference>("niq_quoteproductid").Id, new ColumnSet("niq_ismodified"));
                       // if (quote != null && quote.Attributes.Contains("niq_mainquote") && quote.GetAttributeValue<bool>("niq_mainquote"))
                        {
                            Entity updQuoteProd = new Entity(quoteProduct.LogicalName, quoteProduct.Id);
                            string isModified = null;

                            tracing.Trace("OnUpdate_QuoteProductCharacteristics_TriggerScheduleFlow: QP is from Main Quote");
                            if (quoteProduct.Attributes.Contains("niq_ismodified") && context.Depth == 1)
                            {
                                isModified = quoteProduct.GetAttributeValue<string>("niq_ismodified") != null ? quoteProduct.GetAttributeValue<string>("niq_ismodified") : null;
                                tracing.Trace("OnUpdate_QuoteProductCharacteristics_TriggerScheduleFlow: is Modified->" + isModified);
                                switch (isModified)
                                {
                                    case null:
                                        updQuoteProd["niq_ismodified"] = "InProgress";
                                        updQuoteProd["niq_isqpscompleted"] = false;
                                        tracing.Trace("ismodified -> Inprogress");
                                        break;
                                    case "InProgress":
                                        updQuoteProd["niq_ismodified"] = "InProgresss";
                                        updQuoteProd["niq_isqpscompleted"] = false;
                                        tracing.Trace("ismodified -> InProgresss");
                                        break;
                                    case "InProgresss":
                                        updQuoteProd["niq_ismodified"] = "InProgressss";
                                        updQuoteProd["niq_isqpscompleted"] = false;
                                        tracing.Trace("ismodified -> InProgressss");
                                        break;
                                    case "InProgressss":
                                        updQuoteProd["niq_ismodified"] = "InProgresss";
                                        updQuoteProd["niq_isqpscompleted"] = false;
                                        tracing.Trace("ismodified -> InProgresss");
                                        break;
                                    case "Completed":
                                        updQuoteProd["niq_ismodified"] = "InProgress";
                                        updQuoteProd["niq_isqpscompleted"] = false;
                                        tracing.Trace("ismodified -> InProgress");
                                        break;
                                    default:
                                        updQuoteProd["niq_isqpscompleted"] = false;
                                        break;
                                }
                                service.Update(updQuoteProd);
                            }
                            else if (!(quoteProduct.Attributes.Contains("niq_ismodified")) && context.Depth == 1)
                            {
                                tracing.Trace("ismodified -> Inprogress");
                                updQuoteProd["niq_ismodified"] = "InProgress";
                                service.Update(updQuoteProd);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
    

