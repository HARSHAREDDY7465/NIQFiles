﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using NielsenIQ.CRM.Plugins.Helper;
using Microsoft.Xrm.Sdk.Client;
using System.Collections;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_ExperlogicFlag_UpdateIsModified : IPlugin
    {

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(null);

                if (context.Depth > 1)
                {
                    tracing.Trace("Depth checking >1");
                    return;
                }

                if (context.InputParameters.Contains(CommonConstant.TARGET) && context.InputParameters[CommonConstant.TARGET] is Entity)
                {
                    Entity entityObj = (Entity)context.InputParameters[CommonConstant.TARGET];
                    Entity PostImageObj = context.PostEntityImages[CommonConstant.POSTIMAGE] as Entity;

                    tracing.Trace("Quote ID: " + entityObj.Id);
                    tracing.Trace("Quote_niq_expvalidation: " + Convert.ToString((bool)entityObj["niq_expvalidation"]));

                    if (entityObj.Contains("niq_expvalidation") && (bool)entityObj["niq_expvalidation"] && PostImageObj.Contains("niq_mainquote") && (bool)PostImageObj["niq_mainquote"])
                    {                        
                        QueryExpression query = new QueryExpression("quotedetail");
                        query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, entityObj.Id);
                        EntityCollection results = service.RetrieveMultiple(query);
                        tracing.Trace("Quote Product Count: " + results.Entities.Count);
                        foreach (Entity rec in results.Entities)
                        {
                            tracing.Trace("rec.LogicalName: " + rec.LogicalName);
                            Entity updateQP1 = new Entity(rec.LogicalName, rec.Id);
                            if (!rec.Contains("niq_ismodified"))
                            {
                                tracing.Trace("Entering if QP doesnt contain niq_ismodified");
                                updateQP1["niq_ismodified"] = "InProgress";
                            }
                            else
                            {
                                tracing.Trace("Entring else QP contains niq_ismodified");
                                string isModified = null;
                                isModified = rec.GetAttributeValue<string>("niq_ismodified") != null ? rec.GetAttributeValue<string>("niq_ismodified") : null;
                                tracing.Trace("Value of isModified before Switch Case: " + isModified);
                                switch (isModified)
                                {
                                    case null:
                                        updateQP1["niq_ismodified"] = "InProgress";
                                        updateQP1["niq_isqpscompleted"] = false;
                                        tracing.Trace("ismodified -> Inprogress");
                                        break;
                                    case "InProgress":
                                        updateQP1["niq_ismodified"] = "InProgresss";
                                        updateQP1["niq_isqpscompleted"] = false;
                                        tracing.Trace("ismodified -> InProgresss");
                                        break;
                                    case "InProgresss":
                                        updateQP1["niq_ismodified"] = "InProgressss";
                                        updateQP1["niq_isqpscompleted"] = false;
                                        tracing.Trace("ismodified -> InProgressss");
                                        break;
                                    case "InProgressss":
                                        updateQP1["niq_ismodified"] = "InProgresss";
                                        updateQP1["niq_isqpscompleted"] = false;
                                        tracing.Trace("ismodified -> InProgresss");
                                        break;
                                    case "Completed":
                                        updateQP1["niq_ismodified"] = "InProgress";
                                        updateQP1["niq_isqpscompleted"] = false;
                                        tracing.Trace("ismodified -> InProgress");
                                        break;
                                    default:
                                        updateQP1["niq_isqpscompleted"] = false;
                                        break;
                                }
                            }
                            tracing.Trace("updateQP1[niq_ismodified]: " + updateQP1["niq_ismodified"]);
                            service.Update(updateQP1);
                        }                        
                    }
                }
            }
            catch (Exception e)
            {
                throw new InvalidPluginExecutionException(e.Message);
            }
        }
    }
}
