﻿using System;
using Microsoft.Xrm.Sdk;
using NielsenIQ.CRM.Plugins.Helper;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Opportunity_MainQuote_Update_Quote : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(null);

                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_Opportunity_MainQuote_Update_Quote: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity entity = (Entity)context.InputParameters["Target"];

                    tracing.Trace("OnUpdate_Opportunity_MainQuote_Update_Quote: Getting PostImage");
                    Entity postImage = (Entity)context.PostEntityImages["PostImage"];
                    tracing.Trace("OnUpdate_Opportunity_MainQuote_Update_Quote: Getting PreImage");
                    Entity preImage = (Entity)context.PreEntityImages["PreImage"];

                    if (postImage != null && postImage.Attributes.Contains("niq_mainquoteid"))
                    {
                        Entity quoteUpdMainQuote = new Entity("quote", postImage.GetAttributeValue<EntityReference>("niq_mainquoteid").Id);
                        quoteUpdMainQuote["niq_mainquote"] = true;
                        tracing.Trace("OnUpdate_Opportunity_MainQuote_Update_Quote: Updating Main Quote check on Updated Quote");
                        service.Update(quoteUpdMainQuote);
                        tracing.Trace("OnUpdate_Opportunity_MainQuote_Update_Quote: Success");
                        //Clear previous Mandatory Charatteristic Values Added validation and update with new main quote.
                        CommonHelper.updateOpportunityMandatoryCharValueAddedValidation(((EntityReference)postImage["niq_mainquoteid"]).Id, tracing, service);
                        if (preImage != null && preImage.Attributes.Contains("niq_mainquoteid") && preImage.GetAttributeValue<EntityReference>("niq_mainquoteid").Id != postImage.GetAttributeValue<EntityReference>("niq_mainquoteid").Id)
                        {
                            Entity quoteRemMainQuote = new Entity("quote", preImage.GetAttributeValue<EntityReference>("niq_mainquoteid").Id);
                            quoteRemMainQuote["niq_mainquote"] = false;
                            tracing.Trace("OnUpdate_Opportunity_MainQuote_Update_Quote: Updating Main Quote Check on Previous Quote.");
                            service.Update(quoteRemMainQuote);
                            tracing.Trace("OnUpdate_Opportunity_MainQuote_Update_Quote: Success");
                        }
                    }
                    if (!postImage.Attributes.Contains("niq_mainquoteid"))
                    {
                        if (preImage != null && preImage.Attributes.Contains("niq_mainquoteid"))
                        {
                            Entity quoteRemMainQuotes = new Entity("quote", preImage.GetAttributeValue<EntityReference>("niq_mainquoteid").Id);
                            quoteRemMainQuotes["niq_mainquote"] = false;
                            //Clear previous Mandatory Charatteristic Values Added
                            if (!postImage.Contains("niq_mandatorycharvaluesadded") || (bool)postImage["niq_mandatorycharvaluesadded"])
                                quoteRemMainQuotes["niq_mandatorycharvaluesadded"] = false;
                            tracing.Trace("OnUpdate_Opportunity_MainQuote_Update_Quote: Updating Main Quotes Check on Previous Quote.");
                            service.Update(quoteRemMainQuotes);
                            tracing.Trace("OnUpdate_Opportunity_MainQuote_Update_Quote: Success");

                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
