﻿using System;
using System.Linq;
using System.Runtime.Remoting.Services;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow.Activities;
using NielsenIQ.CRM.Plugins.Helper;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Quote_Pricing_ValidatePricingApprovals : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {

            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            tracingService.Trace("OnUpdate_Quote_Pricing_ValidatePricingApprovals Plugin execution started.");

            try
            {
                tracingService.Trace("Depth :" + context.Depth);
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity targetEntity)
                {
                    tracingService.Trace("Target entity identified.");
                    // Retrieve the full Quote entity including niq_salesorgid
                    Entity fullQuote = service.Retrieve(targetEntity.LogicalName, targetEntity.Id, new ColumnSet("niq_overalldealscore", "niq_salesorgid", "niq_discount", "totalamount", "niq_expvalidation", "niq_proposedratecardattainment"));


                    if (fullQuote.Contains("niq_expvalidation"))
                    {
                        bool expvalidation = fullQuote.GetAttributeValue<bool>("niq_expvalidation");
                        if (!expvalidation)
                        {
                            tracingService.Trace("expvalidation :" + fullQuote.GetAttributeValue<bool>("niq_expvalidation"));
                            // Fetch the last record from "niq_dealdeskapprovalrequest"
                            QueryExpression ddarQuery = new QueryExpression("niq_dealdeskapprovalrequest")
                            {
                                TopCount = 1,
                                ColumnSet = new ColumnSet("niq_approvalstatus", "niq_reapprovalforanydiscountchange", "niq_lastapprovedoveralldealscore", "niq_totalamount", "niq_discount"),
                                Criteria =
    {
                                //Retreving the last Approved DDAR even if it is rejected/recalled
                                Conditions =
                                {
                                    new ConditionExpression("niq_approvalstatus", ConditionOperator.Equal,4),
                                    new ConditionExpression("niq_quoteid", ConditionOperator.Equal,fullQuote.Id)
                            }
                            },
                                Orders =
                            {
                                new OrderExpression("createdon", OrderType.Descending) // Sorting by creation date in descending order
                            }
                            };

                            ddarQuery.Criteria.AddCondition("statecode", ConditionOperator.Equal, 1); // Approved record will be InActive.
                            //ddarQuery.Criteria.AddCondition("niq_quoteid", ConditionOperator.Equal, targetEntity.Id);

                            var resultDDAR = service.RetrieveMultiple(ddarQuery);
                            tracingService.Trace("Fetched niq_dealdeskapprovalrequest records: {0}", resultDDAR.Entities.Count);

                            if (resultDDAR != null && resultDDAR.Entities.Count > 0)
                            {
                                Entity ddarEntity = resultDDAR.Entities.FirstOrDefault();

                                // Check if "niq_approvalstatus" is "4" and "niq_ReapprovalwillbeneededforanyDiscountchan" is "Yes"
                                if (ddarEntity != null
                                    && ddarEntity.GetAttributeValue<OptionSetValue>("niq_approvalstatus")?.Value == 4)
                                {


                                    // Retrieve Sales Org entity to get its name
                                    if (fullQuote.Contains("niq_salesorgid") && fullQuote["niq_salesorgid"] != null && fullQuote.Contains("niq_discount") && fullQuote.Contains("totalamount") && fullQuote["totalamount"] != null)
                                    {
                                        tracingService.Trace($"It contains Discount : {fullQuote.GetAttributeValue<decimal>("niq_discount")} and Total Amount : {fullQuote.GetAttributeValue<Money>("totalamount").Value}, OverallDealScore contains : {fullQuote.Contains("niq_overalldealscore")}");
                                        decimal discountOnQuote = fullQuote.GetAttributeValue<decimal>("niq_discount");

                                        var salesOrgReference = fullQuote.GetAttributeValue<EntityReference>("niq_salesorgid");

                                        // Retrieve Sales Org entity to get its name
                                        Entity salesOrg = service.Retrieve(salesOrgReference.LogicalName, salesOrgReference.Id, new ColumnSet("niq_name"));
                                        string salesOrgName = salesOrg.GetAttributeValue<string>("niq_name");
                                        tracingService.Trace("Retrieved values - Sales Org Name: {0}", salesOrgName);

                                        Entity updateQuote = new Entity(targetEntity.LogicalName, targetEntity.Id);



                                        if (ddarEntity.GetAttributeValue<bool>("niq_reapprovalforanydiscountchange"))
                                        {
                                            tracingService.Trace("niq_ReapprovalwillbeneededforanyDiscountchan values is 'Yes' ");

                                            if (
                                                (fullQuote.Attributes.Contains("niq_discount") && ddarEntity.Attributes.Contains("niq_discount") && fullQuote.GetAttributeValue<decimal>("niq_discount") != ddarEntity.GetAttributeValue<decimal>("niq_discount")) ||
                                                (fullQuote.Attributes.Contains("totalamount") && ddarEntity.Attributes.Contains("niq_totalamount") && fullQuote.GetAttributeValue<Money>("totalamount").Value != ddarEntity.GetAttributeValue<Money>("niq_totalamount").Value) ||
                                                (fullQuote.Attributes.Contains("niq_discount") && !ddarEntity.Attributes.Contains("niq_discount")) ||
                                                (!fullQuote.Attributes.Contains("niq_discount") && ddarEntity.Attributes.Contains("niq_discount")) ||
                                                (fullQuote.Attributes.Contains("niq_overalldealscore") && ddarEntity.Attributes.Contains("niq_lastapprovedoveralldealscore") && fullQuote.GetAttributeValue<string>("niq_overalldealscore") != ddarEntity.GetAttributeValue<string>("niq_lastapprovedoveralldealscore")) ||
                                                (fullQuote.Attributes.Contains("niq_overalldealscore") && !ddarEntity.Attributes.Contains("niq_lastapprovedoveralldealscore")) ||
                                                (!fullQuote.Attributes.Contains("niq_overalldealscore") && ddarEntity.Attributes.Contains("niq_lastapprovedoveralldealscore"))
                                                )
                                            {
                                                // Check overall deal score and apply conditions
                                                tracingService.Trace("there is some changes in 3 fields");
                                                tracingService.Trace("Overall Deal score contains data or not : " + fullQuote.Contains("niq_overalldealscore"));
                                                string overallDealScore = string.Empty;
                                                if (fullQuote.Contains("niq_overalldealscore"))
                                                {
                                                    overallDealScore = fullQuote.GetAttributeValue<string>("niq_overalldealscore");
                                                    tracingService.Trace("Quote's Overall Deal Score: {0}", overallDealScore);
                                                }

                                                if (string.IsNullOrEmpty(overallDealScore))
                                                {

                                                    updateQuote["niq_dealdeskapproval"] = DiscountThresholdTable(tracingService, service, salesOrgName, discountOnQuote, fullQuote.Id, null);
                                                    //updateQuote["niq_quoteheaderdetailsapproval"] = new OptionSetValue(2);                                                
                                                }
                                                else if (overallDealScore == "Dark Green" || overallDealScore == "Light Green")
                                                {
                                                    tracingService.Trace("Overall Deal Score : Dark Green or Light Green");
                                                    // Handle Dark Green or Light Green
                                                    // updateQuote["niq_dealdeskapproval"] = DiscountThresholdTable(tracingService, service, salesOrgName, discountOnQuote, fullQuote.Id);
                                                    //updateQuote["niq_quoteheaderdetailsapproval"] = new OptionSetValue(2);
                                                    updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000001); // Segment approval required
                                                }
                                                else if (overallDealScore == "Yellow" || overallDealScore == "Red")
                                                {
                                                    tracingService.Trace("Overall Deal Score : Yellow or Red -> Deal desk approval : approval required ");

                                                    updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000002);
                                                    //updateQuote["niq_quoteheaderdetailsapproval"] = new OptionSetValue(2);
                                                }
                                                //updateQuote["niq_quoteheaderdetailsapproval"] = new OptionSetValue(2);
                                            }
                                            else
                                            {
                                                tracingService.Trace("there is no changes in 3 fields based on last approved ddar, so no approval required.");
                                                updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000003);//no approved required
                                            }
                                        }
                                        else
                                        {
                                            tracingService.Trace("niq_ReapprovalwillbeneededforanyDiscountchan values is 'No' ");

                                            // Step 2: Compare "niq_overalldealscore" in Quote with "niq_lastapprovedoveralldealscore" in Deal Desk Approval Request
                                            string currentDealScore = fullQuote.Contains("niq_overalldealscore") ? fullQuote.GetAttributeValue<string>("niq_overalldealscore") : string.Empty;
                                            string lastApprovedDealScore = ddarEntity.Contains("niq_lastapprovedoveralldealscore") ? ddarEntity.GetAttributeValue<string>("niq_lastapprovedoveralldealscore") : string.Empty;
                                            decimal proposedRateCardAttainment = fullQuote.Contains("niq_proposedratecardattainment") ? fullQuote.GetAttributeValue<decimal>("niq_proposedratecardattainment") : 0m;

                                            tracingService.Trace("Current Deal Score: {0}, Last Approved Deal Score: {1}, Proposed Rate Card Attainment: {2}", currentDealScore, lastApprovedDealScore, proposedRateCardAttainment);

                                            if (!string.IsNullOrEmpty(lastApprovedDealScore) && !string.IsNullOrEmpty(currentDealScore))
                                            {
                                                // part1: Perform comparisons based on the provided conditions
                                                if (lastApprovedDealScore == "Dark Green" && currentDealScore == "Dark Green" ||
                                                    lastApprovedDealScore == "Light Green" && currentDealScore == "Dark Green" ||
                                                    lastApprovedDealScore == "Yellow" && currentDealScore == "Dark Green" ||
                                                    // lastApprovedDealScore == "Yellow" && currentDealScore == "Light Green" ||
                                                    lastApprovedDealScore == "Red" && currentDealScore == "Dark Green" ||
                                                    // lastApprovedDealScore == "Red" && currentDealScore == "Light Green" ||
                                                    lastApprovedDealScore == "Red" && currentDealScore == "Yellow")
                                                {
                                                    // Update Deal Desk Approval field to "100000006"
                                                    tracingService.Trace("Conditions met for : Deal Score sufficient, No Approval Required");
                                                    updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000006);
                                                }
                                                // new logic for light green 
                                                else if (currentDealScore == "Light Green")
                                                {
                                                    tracingService.Trace("Current Deal Score is Light Green - applying new logic.");

                                                    bool isDDARApproved = fullQuote.GetAttributeValue<bool?>("niq_ddarapproved") ?? false;
                                                    bool reApprovalNeeded = fullQuote.GetAttributeValue<bool?>("niq_reapprovalneeded") ?? false;

                                                    if (!isDDARApproved)
                                                    {
                                                        // No DDAR → No approval required
                                                        updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000006); // Deal Score Sufficient
                                                        tracingService.Trace("Light Green, no DDAR → No approval required.");
                                                    }
                                                    else
                                                    {
                                                        if (!reApprovalNeeded)
                                                        {
                                                            // DDAR exists but re-approval not needed → No approval required
                                                            updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000006);
                                                            tracingService.Trace("Light Green, DDAR exists, re-approval NO → No approval required.");
                                                        }
                                                        else
                                                        {
                                                            // DDAR exists and re-approval needed → Approval required
                                                            updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000001); // Segment Lead Approval Required
                                                            tracingService.Trace("Light Green, DDAR exists, re-approval YES → Approval required.");
                                                        }
                                                    }
                                                }
                                                // PART 2: New Logic for Light Green Current Score
                                                //else if (currentDealScore == "Light Green")
                                                //{
                                                // tracingService.Trace("Current Deal Score is Light Green");

                                                // if (proposedRateCardAttainment >= 100)
                                                //{
                                                // tracingService.Trace("Attainment >= 100 - No new approval needed");
                                                // updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000006); // No approval needed
                                                // }
                                                // else if (lastApprovedDealScore == "Dark Green")
                                                //{
                                                // tracingService.Trace("Attainment < 100, last was Dark Green - Segment Lead Approval Required");
                                                // updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000001); // Segment Lead Approval Required
                                                // }
                                                //else if (lastApprovedDealScore == "Red" || lastApprovedDealScore == "Yellow")
                                                //{
                                                // tracingService.Trace("Attainment < 100, last was Red or Yellow - No approval needed");
                                                // updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000006); // No approval needed
                                                // }
                                                //else if (lastApprovedDealScore == "Light Green" && proposedRateCardAttainment < 100)
                                                //{
                                                //tracingService.Trace("Proposed Rate Card Attainment % is < 100, and the last approved one was also Light Green");
                                                //OptionSetValue optionSetValue = CompareOldAndNewDiscount(tracingService, service, currentDealScore, salesOrgName, fullQuote.Id, ddarEntity, discountOnQuote, fullQuote.GetAttributeValue<Money>("totalamount").Value);
                                                //if (optionSetValue != null)
                                                // {
                                                //if (optionSetValue.Value == 100000006)
                                                //{

                                                // tracingService.Trace("Optionset Value for LG & LG :" + optionSetValue.Value);
                                                //updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000003);
                                                // }
                                                // else
                                                //{

                                                // tracingService.Trace("Optionset Value returend LG & LG :" + optionSetValue.Value);
                                                // updateQuote["niq_dealdeskapproval"] = optionSetValue;
                                                //}

                                                //}
                                                //}
                                                // }

                                                // part1: Apply logic based on the score comparisons AC: 5
                                                //else if (lastApprovedDealScore == "Dark Green" && currentDealScore == "Light Green")
                                                //{
                                                //    tracingService.Trace("22130- last approved deal score : dark green, current is light green");
                                                //    updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000001); // Segment approval required
                                                //}
                                                //lastApprovedDealScore == "Yellow" && currentDealScore == "Light Green" ||
                                                //lastApprovedDealScore == "Red" && currentDealScore == "Light Green" ||
                                                // else if (lastApprovedDealScore == "Light Green" && currentDealScore == "Light Green")
                                                //{
                                                //    tracingService.Trace("Conditions met for Deal Score sufficient, [last approved : Dark Green, currentDeal score : light Green] Approval Required -> reach discount threadhold table");
                                                //  updateQuote["niq_dealdeskapproval"] = DiscountThresholdTable(tracingService, service, salesOrgName, discountOnQuote, fullQuote.Id);
                                                //   // updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000001); // Segment approval required

                                                //}
                                                //part1 : Apply logic based on the score comparisons AC: 7,8
                                                else if ((lastApprovedDealScore == "Dark Green" && currentDealScore == "Yellow") ||
                                                    (lastApprovedDealScore == "Dark Green" && currentDealScore == "Red") ||
                                                    (lastApprovedDealScore == "Light Green" && currentDealScore == "Yellow") ||
                                                    (lastApprovedDealScore == "Light Green" && currentDealScore == "Red") ||
                                                    (lastApprovedDealScore == "Yellow" && currentDealScore == "Red"))
                                                {
                                                    tracingService.Trace("Conditions met for Deal Score sufficient, direct - Approval Required");
                                                    updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000002); // Approval required

                                                }
                                                //part2: 
                                                else if (lastApprovedDealScore == "Light Green" && currentDealScore == "Light Green" ||
                                                         lastApprovedDealScore == "Yellow" && currentDealScore == "Yellow" ||
                                                         lastApprovedDealScore == "Red" && currentDealScore == "Red")
                                                {
                                                    // Log the custom message for specific cases
                                                    tracingService.Trace("Both LastApproved Deal Score and Current deal score is same, This case will be taken care by Step3 .");
                                                    OptionSetValue optionSetValue = CompareOldAndNewDiscount(tracingService, service, currentDealScore, salesOrgName, fullQuote.Id, ddarEntity, discountOnQuote, fullQuote.GetAttributeValue<Money>("totalamount").Value);
                                                    if (optionSetValue != null)
                                                    {
                                                        if (optionSetValue.Value == 100000006)
                                                        {

                                                            tracingService.Trace("Optionset Value returend :" + optionSetValue.Value);
                                                            updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000003);
                                                        }
                                                        else
                                                        {

                                                            tracingService.Trace("Optionset Value returend :" + optionSetValue.Value);
                                                            updateQuote["niq_dealdeskapproval"] = optionSetValue;
                                                        }

                                                    }

                                                }
                                                tracingService.Trace("completed");
                                            }
                                            else
                                            {
                                                tracingService.Trace("current quote deal score or last approved deal score may not contains data");
                                                //part3 : Check if "niq_lastapprovedoveralldealscore" has no value and "niq_overalldealscore" has a value
                                                if (string.IsNullOrEmpty(lastApprovedDealScore) && !string.IsNullOrEmpty(currentDealScore))
                                                {
                                                    tracingService.Trace("No last approved deal score, but current deal score exists.");


                                                    // Logic for "Dark Green" score
                                                    if (currentDealScore == "Dark Green")
                                                    {

                                                        tracingService.Trace("Conditions met for Dark Green.-> Deal Score sufficient, No Approval Required");
                                                        updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000006);
                                                    }
                                                    // Logic for "Light Green", 
                                                    else if (currentDealScore == "Light Green")
                                                    {
                                                        tracingService.Trace("Conditions met for Light Green.-> Discount Threashold table");
                                                        OptionSetValue optionSetValue = DiscountThresholdTable(tracingService, service, salesOrgName, discountOnQuote, fullQuote.Id, currentDealScore);
                                                        if (optionSetValue != null)
                                                        {
                                                            if (optionSetValue.Value == 100000006)
                                                            {

                                                                tracingService.Trace("Optionset Value returend :" + optionSetValue.Value);
                                                                updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000003);
                                                            }
                                                            else
                                                            {

                                                                tracingService.Trace("Optionset Value returend :" + optionSetValue.Value);
                                                                updateQuote["niq_dealdeskapproval"] = optionSetValue;
                                                            }

                                                        }
                                                    }
                                                    else if (currentDealScore == "Yellow" || currentDealScore == "Red")
                                                    {
                                                        tracingService.Trace("Overall Deal Score is Yellow or Red. -> Deal Desk Approval Required");
                                                        updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000002); // Approval required
                                                    }
                                                }

                                                //part4 : Check if "niq_lastapprovedoveralldealscore" has value and "niq_overalldealscore" has a no value
                                                else if (string.IsNullOrEmpty(currentDealScore))
                                                {
                                                    // Log the custom message for specific cases
                                                    tracingService.Trace("LastApproved Deal Score either empty or not, and Current deal score is empty, This case will be taken care by Step3 .");
                                                    OptionSetValue optionSetValue = CompareOldAndNewDiscount(tracingService, service, currentDealScore, salesOrgName, fullQuote.Id, ddarEntity, discountOnQuote, fullQuote.GetAttributeValue<Money>("totalamount").Value);
                                                    if (optionSetValue != null)
                                                    {
                                                        tracingService.Trace("Optionset Value returend :" + optionSetValue.Value);
                                                        if (optionSetValue.Value == 100000006)
                                                        {
                                                            tracingService.Trace("when current deal score is empty. instead of 'Deal Score Sufficient; No Approval Required' it will NO approval required.");
                                                            updateQuote["niq_dealdeskapproval"] = new OptionSetValue(100000003);//no approval required
                                                        }
                                                        else
                                                        {
                                                            updateQuote["niq_dealdeskapproval"] = optionSetValue;
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        // Update the Quote entity
                                        if (updateQuote.Attributes.Count > 0)
                                        {
                                            service.Update(updateQuote);
                                            tracingService.Trace("Updated Quote entity with ID: {0}", targetEntity.Id);
                                        }

                                    }

                                }
                            }

                        }

                    }

                }

            }
            catch (Exception ex)
            {
                tracingService.Trace("An error occurred: {0}", ex.ToString());
                throw;
            }
            finally
            {
                tracingService.Trace("OnUpdate_Quote_Pricing_ValidatePricingApprovals Plugin execution ended.");
            }
        }


        public OptionSetValue CompareOldAndNewDiscount(ITracingService tracingService, IOrganizationService service, string quoteOverallDealScore, string salesOrgName, Guid quoteId, Entity LastApprovedDDar, decimal quoteDiscount, decimal quoteAmount)
        {
            tracingService.Trace("CompareOldAndNewDiscount function:");
            if (LastApprovedDDar.Contains("niq_discount") && LastApprovedDDar["niq_discount"] != null && LastApprovedDDar.Contains("niq_totalamount") && LastApprovedDDar["niq_totalamount"] != null)
            {
                decimal ddarDiscount = LastApprovedDDar.GetAttributeValue<decimal>("niq_discount");
                decimal ddarAmount = LastApprovedDDar.GetAttributeValue<Money>("niq_totalamount").Value;
                tracingService.Trace("Ddar Discount = " + ddarDiscount);
                tracingService.Trace("Ddar Amount = " + ddarAmount);
                tracingService.Trace("Quote discount = " + quoteDiscount);
                tracingService.Trace("Quote Amount = " + quoteAmount);


                decimal percentageDecrease = Math.Round((((ddarAmount - quoteAmount) / ddarAmount) * 100), 2);
                tracingService.Trace("Precentage Decrease :" + percentageDecrease);

                if ((quoteDiscount > ddarDiscount && quoteAmount < ddarAmount) ||
                    (quoteDiscount > ddarDiscount && quoteAmount == ddarAmount) ||
                    (quoteDiscount > ddarDiscount && quoteAmount > ddarAmount) ||
                    (quoteDiscount == ddarDiscount && quoteAmount < ddarAmount) ||
                    (quoteDiscount < ddarDiscount && quoteAmount < ddarAmount && percentageDecrease > 15))
                {
                    tracingService.Trace("if part : Based on quote's discount, total amount and  ddar's discount, total amount:  approval required ");
                    //approval required
                    if (!string.IsNullOrEmpty(quoteOverallDealScore))
                    {
                        tracingService.Trace("Current Overall deal score on quote is not Empty");
                        // Implement the logic based on the formatted value
                        if (quoteOverallDealScore == "Dark Green")
                        {
                            tracingService.Trace("Overall Deal Score is Dark Green. -> Deal Score Sufficient, No Approval Required");
                            return new OptionSetValue(100000006); // No approval required
                        }
                        else if (quoteOverallDealScore == "Light Green")
                        {
                            tracingService.Trace("Overall Deal Score is Light Green.");

                            return DiscountThresholdTable(tracingService, service, salesOrgName, quoteDiscount, quoteId, quoteOverallDealScore);
                        }
                        else if (quoteOverallDealScore == "Yellow" || quoteOverallDealScore == "Red")
                        {
                            tracingService.Trace("Overall Deal Score is Yellow or Red. -> Approval Required");
                            return new OptionSetValue(100000002); // Approval required
                        }
                    }
                    tracingService.Trace("Current Overall deal score on quote is Empty -> so got the Discount table");
                    return DiscountThresholdTable(tracingService, service, salesOrgName, quoteDiscount, quoteId, null);
                }
                else if ((quoteDiscount < ddarDiscount && quoteAmount < ddarAmount && percentageDecrease <= 15) ||
                    (quoteDiscount == ddarDiscount && quoteAmount > ddarAmount) ||
                    (quoteDiscount == ddarDiscount && quoteAmount == ddarAmount) ||
                    (quoteDiscount < ddarDiscount && quoteAmount > ddarAmount) ||
                    (quoteDiscount < ddarDiscount && quoteAmount == ddarAmount))

                {
                    tracingService.Trace("else if part: Based on quote's discount, total amount and  ddar's discount: Deal Score Sufficient, No Approval Required ");
                    //no approval required
                    return new OptionSetValue(100000006); // No approval required
                }
            }

            tracingService.Trace("Based on quote's discount, total amount and  ddar's discount, total amount:  none of the conditon satified so return null ");

            return null;
        }

        public OptionSetValue DiscountThresholdTable(ITracingService tracingService, IOrganizationService service, string salesOrgFormattedValue, decimal discount, Guid quoteID, string currentDealScore)
        {

            tracingService.Trace("Discount Threshold Table");
            if (salesOrgFormattedValue == "0500 - Nielsen Consumer LLC" || salesOrgFormattedValue == "0560 - ACNielsen - Canada") // North America
            {
                if (discount > 20)
                {
                    tracingService.Trace("Discount greater than 20. Setting Deal Desk Approval Required.");

                    if (!string.IsNullOrEmpty(currentDealScore) && string.Equals(currentDealScore, "Light Green"))
                    {
                        tracingService.Trace("current deal light green");
                        return new OptionSetValue(100000001); // Segment approval required
                    }
                    tracingService.Trace("current deal score is null or empty");
                    return new OptionSetValue(100000002); // Deal Desk Approval Required
                }
                else
                {
                    tracingService.Trace("Discount not greater than 20. Segment approval required.");
                    return new OptionSetValue(100000001); // Segment approval required
                }
            }
            else // International
            {
                tracingService.Trace("International Sales Org. Fetching related Quote Detail records.");

                // Fetch related "quotedetail" records to check for brands
                QueryExpression quoteDetailQuery = new QueryExpression("quotedetail")
                {
                    ColumnSet = new ColumnSet("niq_brandid"),
                    Criteria = {
                            Conditions =
                            {
                                new ConditionExpression("quoteid", ConditionOperator.Equal, quoteID)
                            }
                    }
                };

                var quoteDetailResults = service.RetrieveMultiple(quoteDetailQuery);
                tracingService.Trace("Number of Quote Detail records found: {0}", quoteDetailResults.Entities.Count);

                /****DYNCRM31242_Start****/
                var brands = CommonHelper.GetEnvVarDefaultValue(service, "niq_RMSBrands", tracingService);
                var eligibleBrands = brands.Split(',').Select(b => b.Trim()).ToArray();
                tracingService.Trace("Eligible Brands: {0}", string.Join(", ", eligibleBrands));
                bool hasRMSorCPS = quoteDetailResults.Entities.Any(qd =>
                {
                    var name = qd.GetAttributeValue<EntityReference>("niq_brandid")?.Name;
                    return eligibleBrands.Contains(name, StringComparer.OrdinalIgnoreCase)
                           || name.Equals("CPS", StringComparison.OrdinalIgnoreCase);
                });
                /****DYNCRM31242_End****/
                bool hasAAC = quoteDetailResults.Entities.Any(qd =>
                    qd.GetAttributeValue<EntityReference>("niq_brandid")?.Name == "AAC");
                bool hasBASES = quoteDetailResults.Entities.Any(qd =>
                    qd.GetAttributeValue<EntityReference>("niq_brandid")?.Name == "BASES");

                tracingService.Trace("Brands present - RMS/CPS: {0}, AAC: {1}, BASES: {2}", hasRMSorCPS, hasAAC, hasBASES);

                if ((hasRMSorCPS && discount > 10) ||
                    (hasAAC && discount > 0) ||
                    (hasBASES && discount > 20))
                {
                    if (!string.IsNullOrEmpty(currentDealScore) && string.Equals(currentDealScore, "Light Green"))
                    {
                        tracingService.Trace("current deal light green & Salesorg is not in NA");
                        return new OptionSetValue(100000001); // Segment approval required
                    }
                    tracingService.Trace("Conditions met for Deal Desk Approval Required.");
                    return new OptionSetValue(100000002); // Deal Desk Approval Required
                }
                else
                {
                    tracingService.Trace("Conditions not met. Segment approval required.");
                    return new OptionSetValue(100000001); // Segment approval required
                }
            }
        }

    }
}