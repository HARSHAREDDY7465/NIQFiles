﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.Plugins.Helper;
namespace NielsenIQ.CRM.Plugins
{
    public class PostAssignorCreate_AddUsertoAccessTeam : IPlugin
    {


        public void Execute(IServiceProvider serviceProvider)
        {
            //Extract the tracing service for use in debugging sandboxed plug-ins.
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            // Obtain the execution context from the service provider.
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));


            // The InputParameters collection contains all the data  
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                tracing.Trace("PostassignorPostCreate: Getting the target entity from Input Parameters.");
                // Obtain the target entity from the input parameters.
                Entity entity = (Entity)context.InputParameters["Target"];
                try
                {

                    // Obtain the organization service reference.
                    IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                    IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);


                    tracing.Trace("PostassignorPostCreate: Getting the Opportunity Access Team");

                    Guid templateId = CommonHelper.GetTemplateId("Opportunity Teams", service);
                    tracing.Trace("PostassignorPostCreate: Result = " + templateId);
                    if (templateId != Guid.Empty)
                    {
                        tracing.Trace("PostassignorPostCreate: Opportunity Access team is available");
                        tracing.Trace("PostassignorPostCreate: checking context message : " + context.MessageName);
                        if (context.MessageName == "Create")

                        {
                            tracing.Trace("PostassignorPostCreate: Inside Create.");
                            tracing.Trace("PostassignorPostCreate: Getting postImage.");
                            Entity postImage = context.PostEntityImages.Contains("PostImage") ? (Entity)context.PostEntityImages["PostImage"] : null;
                            tracing.Trace("PostassignorPostCreate: postImage -" + postImage["createdby"].ToString());
                            tracing.Trace("PostassignorPostCreate: postImage -" + postImage.Attributes.Values);

                            EntityReference createdBy = postImage.GetAttributeValue<EntityReference>("createdby");
                            EntityReference owner = postImage.GetAttributeValue<EntityReference>("ownerid");
                            if (createdBy.Id != Guid.Empty && owner.Id != Guid.Empty && createdBy.Id != owner.Id)
                            {
                                Entity retCreatedBy = service.Retrieve(createdBy.LogicalName, createdBy.Id, new ColumnSet("isdisabled"));
                                if (retCreatedBy != null && retCreatedBy.Id != Guid.Empty && retCreatedBy.Attributes.Contains("isdisabled") && !(retCreatedBy.GetAttributeValue<bool>("isdisabled")))
                                {
                                    tracing.Trace("PostassignorPostCreate: adding user to access team");
                                    CommonHelper.AddUserToAccessTeam(entity, createdBy.Id, templateId, tracing, service);
                                }
                            }
                        }

                        if (context.MessageName == "Update")

                        {
                            tracing.Trace("PostassignorPostCreate: context is update");
                            tracing.Trace("PostassignorPostCreate: Getting the preImage");
                            Entity preImage = context.PreEntityImages.Contains("PreImage") ? (Entity)context.PreEntityImages["PreImage"] : null;
                            EntityReference owner = preImage.GetAttributeValue<EntityReference>("ownerid");
                            if (owner.Id != Guid.Empty)
                            {
                                Entity retOwner = service.Retrieve(owner.LogicalName, owner.Id, new ColumnSet("isdisabled"));
                                if (retOwner != null && retOwner.Id != Guid.Empty && retOwner.Attributes.Contains("isdisabled") && !(retOwner.GetAttributeValue<bool>("isdisabled")))
                                {

                                    tracing.Trace("PostassignorPostCreate: adding uset to access team");
                                    CommonHelper.AddUserToAccessTeam(entity, owner.Id, templateId, tracing, service);

                                    Guid quouteTemplateId = CommonHelper.GetTemplateId("Quote Teams", service);
                                    if (quouteTemplateId != Guid.Empty)
                                    {
                                        string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='quote'>
                                                        <attribute name='name' />
                                                        <attribute name='quoteid' />
                                                        <order attribute='name' descending='false' />
                                                        <filter type='and'>
                                                          <condition attribute='opportunityid' operator='eq' uitype='opportunity' value='{0}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";
                                        fetchXml = string.Format(fetchXml, entity.Id);
                                        var fetchQuotes = service.RetrieveMultiple(new FetchExpression(fetchXml));
                                        if (fetchQuotes != null && fetchQuotes.Entities.Count > 0)
                                        {
                                            foreach (Entity quote in fetchQuotes.Entities)
                                            {
                                                if (owner.Id != Guid.Empty)
                                                {
                                                    tracing.Trace("PostassignorPostCreate: adding uset to access team");
                                                    CommonHelper.AddUserToAccessTeam(quote, owner.Id, quouteTemplateId, tracing, service);
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                        }
                    }

                }



                catch (Exception ex)
                {
                    throw new InvalidPluginExecutionException(ex.Message);
                }
            }
        }


    }
}