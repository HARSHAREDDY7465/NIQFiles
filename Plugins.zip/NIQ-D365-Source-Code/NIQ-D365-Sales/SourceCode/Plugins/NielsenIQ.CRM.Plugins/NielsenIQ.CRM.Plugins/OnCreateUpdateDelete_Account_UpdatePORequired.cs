using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace NielsenIQ.CRM.Plugins
{
    public class OnCreateUpdateDelete_Account_UpdatePORequired : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                //Retrieve previous Ultimate Parent Account, if any.
                Entity oldUltimateParentAccountValue = context.PreEntityImages.Contains("PreEntityImage") ? context.PreEntityImages["PreEntityImage"] : null;
                EntityReference oldUltimateParentAccount = oldUltimateParentAccountValue?.GetAttributeValue<EntityReference>("niq_ultimateparentid");

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity entity && entity.LogicalName == "account")
                {
                    //SAP Account is Created or Updated with "Ultimate Parent Account" or "PO Required?" fields.
                    if (entity.Contains("niq_ultimateparentid") || entity.Contains("niq_porequired"))
                    {
                        EntityReference newUltimateParentAccount = entity.GetAttributeValue<EntityReference>("niq_ultimateparentid");

                        if (oldUltimateParentAccount != null)
                        {
                            //Validate and Update "PO Required?" field on previous Ultimate Parent Account.
                            ValidateAndUpdatePORequired(service, oldUltimateParentAccount.Id);
                        }
                        if (newUltimateParentAccount != null && (oldUltimateParentAccount == null || oldUltimateParentAccount.Id != newUltimateParentAccount.Id))
                        {
                            //Validate and Update "PO Required?" field on new Ultimate Parent Account.
                            ValidateAndUpdatePORequired(service, newUltimateParentAccount.Id);
                        }
                    }
                }
                else if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference entityReference && entityReference.LogicalName == "account")
                {
                    //SAP Account is Deleted.
                    if (oldUltimateParentAccount != null)
                    {
                        //Validate and Update "PO Required?" field on the Ultimate Parent Account.
                        ValidateAndUpdatePORequired(service, oldUltimateParentAccount.Id);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("Error Occured: " + ex);
            }
        }

        private void ValidateAndUpdatePORequired(IOrganizationService service, Guid ultimateParentId)
        {
            //Retrieve all the related SAP Accounts, Validate "PO Requierd?" field and Update "PO Required?" field on Ultimate Parent Account.
            QueryExpression sapAccountQueryExpression = new QueryExpression("account")
            {
                ColumnSet = new ColumnSet("accountid"),
                Criteria = new FilterExpression
                {
                    Conditions =
                    {
                        new ConditionExpression("niq_ultimateparentid", ConditionOperator.Equal, ultimateParentId),
                        new ConditionExpression("niq_accounttype", ConditionOperator.Equal, 2),//Account Type equals to SAP Account
                        new ConditionExpression("niq_porequired", ConditionOperator.Equal, true)// PO Required? equals to Yes
                    }
                }
            };

            EntityCollection relatedSAPAccounts = service.RetrieveMultiple(sapAccountQueryExpression);
            bool hasPoRequiredYes = relatedSAPAccounts.Entities.Count > 0 ? true : false;

            Entity ultimateParentAccount = new Entity("account", ultimateParentId);
            ultimateParentAccount["niq_porequired"] = hasPoRequiredYes;
            service.Update(ultimateParentAccount);
        }
    }
}