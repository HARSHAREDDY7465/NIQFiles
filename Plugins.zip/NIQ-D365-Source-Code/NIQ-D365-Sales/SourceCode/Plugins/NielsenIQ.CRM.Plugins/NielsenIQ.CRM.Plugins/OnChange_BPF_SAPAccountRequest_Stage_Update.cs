﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;

namespace NielsenIQ.CRM.Plugins
{
    public class OnChange_BPF_SAPAccountRequest_Stage_Update : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {

                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(null);
                if (context.Depth > 1)
                {
                    return;
                }
                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnChangeBPFSAPAccount: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity entity = (Entity)context.InputParameters["Target"];
                    if (entity != null && entity.Id != Guid.Empty)
                    {


                        tracing.Trace("OnChangeBPFSAPAccount: Getting the Post Image from Context.");
                        Entity postimage = (Entity)context.PostEntityImages["PostImage"];
                        if (postimage != null && postimage.Attributes.Contains("bpf_niq_sapaccountrequestid") && postimage.Attributes.Contains("activestageid"))
                        {
                            tracing.Trace("OnChangeBPFSAPAccount: postImage -> ." + postimage);
                            if (context.MessageName == "Create")
                            {
                                EntityReference ownerId = new EntityReference("systemuser", context.UserId);
                                Entity sapAccReqObj = service.Retrieve("niq_sapaccountrequest", ((EntityReference)postimage["bpf_niq_sapaccountrequestid"]).Id, new ColumnSet("ownerid"));
                                Entity sapAccReqUpd = new Entity("niq_sapaccountrequest", ((EntityReference)postimage["bpf_niq_sapaccountrequestid"]).Id);
                                if (sapAccReqObj != null && sapAccReqObj.Id != Guid.Empty && sapAccReqObj.Attributes.Contains("ownerid"))
                                {
                                    ownerId = sapAccReqObj.GetAttributeValue<EntityReference>("ownerid");
                                    tracing.Trace("OnChangeBPFSAPAccount: Owner ID ." + ownerId);
                                }

                                UpdateSAPAccount(tracing, service, sapAccReqObj, sapAccReqUpd, ownerId, "New SAP Account Details Submission", context.MessageName);


                            }
                            if (context.MessageName == "Update")
                            {

                                ProcessActiveStage(tracing, service, ((EntityReference)postimage["bpf_niq_sapaccountrequestid"]).Id, ((EntityReference)postimage["activestageid"]).Name);
                                if (((EntityReference)postimage["activestageid"]).Name.ToLower() == "close")
                                {
                                    Entity sapBPFUpd = new Entity(entity.LogicalName, entity.Id);
                                    sapBPFUpd["statecode"] = new OptionSetValue(1);
                                    sapBPFUpd["statuscode"] = new OptionSetValue(2);
                                    tracing.Trace("OnChangeBPFSAPAccount: updating SAP account");
                                    service.Update(sapBPFUpd);
                                    tracing.Trace("OnChangeBPFSAPAccount: sucess");
                                }
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        private void ProcessActiveStage(ITracingService tracing, IOrganizationService service, Guid sapAccId, string activestagename)
        {
            try
            {
                tracing.Trace("OnChangeBPFSAPAccount: creating SAP Account Req obj.");
                Entity sapAccReqUpd = new Entity("niq_sapaccountrequest", sapAccId);
                Entity sapAccReqObj = service.Retrieve("niq_sapaccountrequest", sapAccId, new ColumnSet("ownerid", "createdby", "niq_salesorgid", "niq_creditcheckresult", "niq_reviewresult", "niq_creditcheckriskdecision"));
                if (sapAccReqObj != null && sapAccReqObj.Id != Guid.Empty)
                {
                    tracing.Trace("OnChangeBPFSAPAccount: BPF stage " + activestagename);
                    //Get the active stage name 
                    switch (activestagename.ToLower())
                    {
                        case "credit check assessment":
                            tracing.Trace("OnChangeBPFSAPAccount: BPF stage pre-proposal." + activestagename);
                            //credit check team
                            string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='team'>
                                                <attribute name='name' />
                                                <attribute name='teamid' />
                                                <attribute name='teamtype' />
                                                <order attribute='name' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='name' operator='eq' value='Credit Check Team' />
                                                </filter>
                                              </entity>
                                            </fetch>";
                            var fetchCreditTeam = new FetchExpression(fetchXml);
                            Entity checkCredit = service.RetrieveMultiple(fetchCreditTeam).Entities.FirstOrDefault();
                            if (checkCredit != null && checkCredit.Id != Guid.Empty)
                            {
                                UpdateSAPAccount(tracing, service, sapAccReqObj, sapAccReqUpd, new EntityReference(checkCredit.LogicalName, checkCredit.Id), activestagename, "");
                            }

                            break;
                        case "credit check details submission":
                            tracing.Trace("OnChangeBPFSAPAccount: BPF stage proposal." + activestagename);
                            if (sapAccReqObj.Attributes.Contains("createdby"))
                            {
                                UpdateSAPAccount(tracing, service, sapAccReqUpd, sapAccReqObj, sapAccReqObj.GetAttributeValue<EntityReference>("createdby"), activestagename, "");

                            }
                            break;
                        case "gatekeeper approval":
                            tracing.Trace("OnChangeBPFSAPAccount: BPF stage Negotiation." + activestagename);
                            if (sapAccReqObj.Attributes.Contains("niq_salesorgid"))
                            {
                                Entity saleOrg = service.Retrieve("niq_salesorg", sapAccReqObj.GetAttributeValue<EntityReference>("niq_salesorgid").Id, new ColumnSet("niq_financeteam"));
                                if (saleOrg != null && saleOrg.Id != Guid.Empty && saleOrg.Attributes.Contains("niq_financeteam"))
                                {
                                    UpdateSAPAccount(tracing, service, sapAccReqObj, sapAccReqUpd, saleOrg.GetAttributeValue<EntityReference>("niq_financeteam"), activestagename, "");

                                }

                            }
                            break;
                        case "close":
                            tracing.Trace("OnChangeBPFSAPAccount: BPF stage Closure." + activestagename);
                            if (sapAccReqObj.Attributes.Contains("createdby"))
                            {
                                UpdateSAPAccount(tracing, service, sapAccReqObj, sapAccReqUpd, sapAccReqObj.GetAttributeValue<EntityReference>("createdby"), activestagename, "");

                            }
                            break;
                        case "low credit rating risk acceptance":
                            tracing.Trace("OnChangeBPFSAPAccount: BPF stage Closure." + activestagename);
                            if (sapAccReqObj.Attributes.Contains("createdby"))
                            {
                                UpdateSAPAccount(tracing, service, sapAccReqObj, sapAccReqUpd, sapAccReqObj.GetAttributeValue<EntityReference>("createdby"), activestagename, "");

                            }
                            break;
                        case "bp portal processing":
                            tracing.Trace("OnChangeBPFSAPAccount: BPF stage Closure." + activestagename);
                            string fetchXmlIntUser = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='systemuser'>
                                                    <attribute name='fullname' />
                                                    <attribute name='systemuserid' />
                                                    <order attribute='fullname' descending='false' />
                                                    <filter type='and'>
                                                     <condition attribute='fullname' operator='like' value='%NIQ-CRM-INTEGRATION-D365%' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";
                            var fetchIntUser = new FetchExpression(fetchXmlIntUser);
                            Entity intUser = service.RetrieveMultiple(fetchIntUser).Entities.FirstOrDefault();
                            if (intUser != null && intUser.Id != Guid.Empty)
                            {
                                UpdateSAPAccount(tracing, service, sapAccReqObj, sapAccReqUpd, new EntityReference(intUser.LogicalName, intUser.Id), activestagename, "");
                            }

                            break;
                        case "new sap account details submission":
                            tracing.Trace("OnChangeBPFSAPAccount: BPF stage Closure." + activestagename);
                            if (sapAccReqObj.Attributes.Contains("createdby"))
                            {
                                UpdateSAPAccount(tracing, service, sapAccReqObj, sapAccReqUpd, sapAccReqObj.GetAttributeValue<EntityReference>("createdby"), activestagename, "");

                            }
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private void UpdateSAPAccount(ITracingService tracing, IOrganizationService service, Entity sapAccReqObj, Entity updSAPAccount, EntityReference owner, string stageName, string message)
        {
            try
            {
                tracing.Trace("OnChangeBPFSAPAccount: updating SAP Account Request...");
                if (message == "Create")
                {
                    updSAPAccount["niq_stage"] = stageName;
                }
                else
                {
                    updSAPAccount["niq_stage"] = stageName;
                    updSAPAccount["ownerid"] = owner;
                }
                if (stageName.ToLower() == "credit check assessment")
                {
                    if (!sapAccReqObj.Attributes.Contains("niq_creditcheckresult"))
                    {
                        updSAPAccount["niq_creditcheckresult"] = new OptionSetValue(100000000);
                    }
                }
                if (stageName.ToLower() == "gatekeeper approval")
                {
                    if (!sapAccReqObj.Attributes.Contains("niq_reviewresult"))
                    {
                        updSAPAccount["niq_reviewresult"] = new OptionSetValue(100000001);
                    }
                }
                if (stageName.ToLower() == "close")
                {
                    if (sapAccReqObj.Attributes.Contains("niq_creditcheckriskdecision") && sapAccReqObj.GetAttributeValue<OptionSetValue>("niq_creditcheckriskdecision").Value == 100000001)
                    {
                        updSAPAccount["niq_reviewresult"] = new OptionSetValue(100000004);
                    }
                    updSAPAccount["statecode"] = new OptionSetValue(1);
                    updSAPAccount["statuscode"] = new OptionSetValue(2);
                }
                service.Update(updSAPAccount);
                tracing.Trace("OnChangeBPFSAPAccount: SAP Account Request updated sucesfully");
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

    }
}
