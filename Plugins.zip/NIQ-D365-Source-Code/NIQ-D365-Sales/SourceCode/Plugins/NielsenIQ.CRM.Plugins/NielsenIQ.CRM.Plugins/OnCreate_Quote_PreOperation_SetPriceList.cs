﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace NielsenIQ.CRM.Plugins
{
    public class OnCreate_Quote_PreOperation_SetPriceList : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("PreOperation OnCreate of Quote SetPriceList: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity quoteRecord = (Entity)context.InputParameters["Target"];

                    if (quoteRecord != null && quoteRecord.Id != Guid.Empty)
                    {
                        if (!quoteRecord.Attributes.Contains("niq_numberofftes"))
                        {

                            quoteRecord["niq_numberofftes"] = (decimal)0;
                        }
                        if (!quoteRecord.Attributes.Contains("niq_interestrateonlatepayment"))
                        {
                            //quoteRecord["niq_interestrateonlatepayment"] = (decimal)1.5;//DYNCRM-29224
                        }
                        if (!quoteRecord.Attributes.Contains("niq_paymenttermsid"))
                        {
                            QueryExpression paymenttermQuery = new QueryExpression("niq_paymentterm");
                            paymenttermQuery.ColumnSet = new ColumnSet("niq_paymenttermcode");
                            paymenttermQuery.Criteria.AddCondition("niq_paymenttermcode", ConditionOperator.Equal, "NM01");
                            paymenttermQuery.NoLock = true;
                            EntityCollection paymenttermRecords = service.RetrieveMultiple(paymenttermQuery);
                            foreach (Entity record in paymenttermRecords.Entities)
                            {
                                quoteRecord["niq_paymenttermsid"] = new EntityReference(record.LogicalName, record.Id);
                                break;
                            }

                        }
                        if (quoteRecord.Attributes.Contains("customerid"))
                        {
                            Guid accountId = ((EntityReference)quoteRecord["customerid"]).Id;
                            QueryExpression accountQuery = new QueryExpression("account");
                            accountQuery.TopCount = 1;
                            accountQuery.ColumnSet.AddColumns("niq_customertype");
                            accountQuery.Criteria.AddCondition("accountid", ConditionOperator.Equal, accountId);
                            EntityCollection accountRecords = service.RetrieveMultiple(accountQuery);
                            foreach (Entity record in accountRecords.Entities)
                            {
                                if (record.Attributes.Contains("niq_customertype"))
                                {
                                    quoteRecord["niq_customertype"] = new OptionSetValue(record.GetAttributeValue<OptionSetValue>("niq_customertype").Value);
                                    break;
                                }
                            }

                        }


                    }

                    if (quoteRecord != null && quoteRecord.Id != Guid.Empty && !quoteRecord.Contains("pricelevelid") && quoteRecord.Contains("transactioncurrencyid"))
                    {
                        QueryExpression priceListQuery = new QueryExpression("pricelevel");
                        priceListQuery.ColumnSet = new ColumnSet("pricelevelid");
                        priceListQuery.Criteria.AddCondition("transactioncurrencyid", ConditionOperator.Equal, ((EntityReference)quoteRecord["transactioncurrencyid"]).Id);
                        priceListQuery.Criteria.AddCondition("niq_nonsapmasterdata", ConditionOperator.Equal, true);
                        priceListQuery.NoLock = true;
                        EntityCollection priceListRecords = service.RetrieveMultiple(priceListQuery);
                        foreach (Entity record in priceListRecords.Entities)
                        {
                            quoteRecord["pricelevelid"] = new EntityReference(record.LogicalName, record.Id);
                            break;
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

    }
}
