﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;
using NielsenIQ.CRM.Plugins.Helper;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Quote_ExpValidation_UpdateContractStartAndEndDates : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                DateTime? postContractStarteDate = null;
                DateTime? postContractEndDate = null;
                Entity postImage = null;

                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_Quote_ExpValidation_UpdateContractStartAndEndDates - Plugin Started , getting Current Quote and PreImage");
                    // Obtain the target entity from the input parameters.
                    Entity currentQuote = (Entity)context.InputParameters["Target"];
                    Entity PreImageObj = context.PreEntityImages[CommonConstant.PREIMAGE] as Entity;

                    if (context.Depth < 2)
                    {
                        var (previousTotalAmount, previousDiscount) = GetTotalAmountAndDiscount(PreImageObj, tracing);
                        Guid currentQuoteId = currentQuote.Id;
                        tracing.Trace("Current Quote ID: " + currentQuoteId.ToString());

                        ColumnSet columns = new ColumnSet("totalamount", "niq_discount");
                        Entity quoteToUpdate = service.Retrieve("quote", currentQuote.Id, columns);
                        bool updateQuote = false;

                        // Get current values from Target

                        Money currentTotalAmount = quoteToUpdate.Contains("totalamount")
                            ? quoteToUpdate.GetAttributeValue<Money>("totalamount")
                            : null;

                        decimal? currentDiscount = quoteToUpdate.Contains("niq_discount")
                            ? quoteToUpdate.GetAttributeValue<decimal?>("niq_discount")
                            : null;

                        tracing.Trace("Current Total Amount: " + (currentTotalAmount != null ? currentTotalAmount.Value.ToString() : "null"));
                        tracing.Trace("Current Discount: " + (currentDiscount != null ? currentDiscount.Value.ToString() : "null"));

                        // Check before updating Total Amount
                        if (previousTotalAmount != null)
                        {
                            if (currentTotalAmount == null || currentTotalAmount.Value != previousTotalAmount.Value)
                            {
                                quoteToUpdate["niq_totalamountddg"] = previousTotalAmount;
                                updateQuote = true;
                                tracing.Trace("Total Amount will be updated.");
                            }
                            else
                            {
                                tracing.Trace("Current Total Amount equals previous. Skipping update.");
                            }
                        }

                        // Check before updating Discount
                        if (previousDiscount != null)
                        {
                            if (currentDiscount == null || currentDiscount.Value != previousDiscount.Value)
                            {
                                quoteToUpdate["niq_discountddg"] = previousDiscount;
                                updateQuote = true;
                                tracing.Trace("Discount will be updated.");
                            }
                            else
                            {
                                tracing.Trace("Current Discount equals previous. Skipping update.");
                            }
                        }

                        // Perform update if needed
                        if (updateQuote)
                        {
                            tracing.Trace("Updating Quote with previous values.");
                            service.Update(quoteToUpdate);
                            tracing.Trace("Quote update successful.");
                        }
                        else
                        {
                            tracing.Trace("No fields need updating. Skipping update.");
                        }
                    }


                    if (context.PostEntityImages.Contains("PostImage"))
                    {
                        //Get PostImage
                        postImage = context.PostEntityImages["PostImage"];
                        postContractStarteDate = postImage.Contains("niq_contractstartdate") && postImage.Attributes["niq_contractstartdate"] != null ? (DateTime?)postImage.Attributes["niq_contractstartdate"] : DateTime.MinValue;
                        postContractEndDate = postImage.Contains("niq_contractenddate") && postImage.Attributes["niq_contractenddate"] != null ? (DateTime?)postImage.Attributes["niq_contractenddate"] : DateTime.MinValue;
                        tracing.Trace("Post Image Of contract start date:" + postContractStarteDate);

                        postContractEndDate = postImage.Contains("niq_contractenddate") && postImage.Attributes["niq_contractenddate"] != null ? (DateTime?)postImage.Attributes["niq_contractenddate"] : null;
                        tracing.Trace("Post Image Of contract end date:" + postContractEndDate);
                    }
                    // Check the Quote reocrd contains ExpValidation and the value is "NO"
                    if (currentQuote != null && currentQuote.Id != Guid.Empty && currentQuote.Attributes.Contains("niq_expvalidation") && currentQuote.GetAttributeValue<bool>("niq_expvalidation") == false)
                    {
                        tracing.Trace("ExpValidation : " + currentQuote.GetAttributeValue<bool>("niq_expvalidation"));

                        // Get all the quote products related to the Quote
                        string fetchDateQP = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' aggregate='true' >
                                                        <entity name='quotedetail' >
                                                            <attribute name='niq_lineitemstartdate' alias='minDate' aggregate='min' />
                                                            <attribute name='niq_lineitemenddate' alias='maxDate' aggregate='max' />
                                                            <filter type='and' >
                                                                <condition attribute ='quoteid' operator='eq' uitype='quote' value='{0}' />
                                                                <condition attribute='quotedetailname' operator='ne' value='SAP Deferred Revenue reconciliation placeholder' />
                                                            </filter>
                                                        </entity>
                                                    </fetch>";
                        fetchDateQP = string.Format(fetchDateQP, currentQuote.Id);

                        tracing.Trace("Retrieving Quote Products related to Quote");
                        var resDateQP = service.RetrieveMultiple(new FetchExpression(fetchDateQP));

                        // Initiate the Quote Update Object
                        Entity updQuote = new Entity(currentQuote.LogicalName, currentQuote.Id);
                        // Initiate the Opportunity Update Object
                        Entity updOppo = null;
                        bool updateQuote = false;

                        tracing.Trace("Getting Opportunity & Main Quote Values");
                        // Get the Opportunity from Quote Record if exists else take from PreImage
                        EntityReference opportunityValue = currentQuote.GetAttributeValue<EntityReference>("opportunityid") != null ? currentQuote.GetAttributeValue<EntityReference>("opportunityid") :
                                                            (PreImageObj.GetAttributeValue<EntityReference>("opportunityid") != null ? PreImageObj.GetAttributeValue<EntityReference>("opportunityid") : null);
                        bool isMainQUote = currentQuote.Contains("niq_mainquote") ? currentQuote.GetAttributeValue<bool>("niq_mainquote") : (PreImageObj.Contains("niq_mainquote") ? PreImageObj.GetAttributeValue<bool>("niq_mainquote") : false);

                        if (opportunityValue != null)
                        {
                            updOppo = new Entity(opportunityValue.LogicalName, opportunityValue.Id);
                        }

                        // Check if the Quote having Quote Products
                        if (resDateQP != null && resDateQP.Entities != null && resDateQP.Entities.Count > 0)
                        {
                            tracing.Trace("Getting Start Date & End Date from Quote Product");

                            Entity dateQP = resDateQP.Entities.FirstOrDefault();
                            if (dateQP.Contains("minDate") && dateQP.GetAttributeValue<AliasedValue>("minDate").Value != null)
                            {
                                tracing.Trace("1stif");
                                DateTime mindate = (DateTime)dateQP.GetAttributeValue<AliasedValue>("minDate").Value;
                                if (postContractStarteDate != null && postContractStarteDate > mindate)
                                {
                                    updQuote["niq_contractstartdate"] = mindate;
                                    updOppo["niq_contractstartdate"] = mindate;
                                    updateQuote = true;
                                }

                            }
                            if (dateQP.Contains("maxDate") && dateQP.GetAttributeValue<AliasedValue>("maxDate").Value != null)
                            {
                                tracing.Trace("2ndif");
                                DateTime maxDate = (DateTime)dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                if (postContractEndDate != null && postContractEndDate < maxDate)
                                {
                                    updQuote["niq_contractenddate"] = dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                    updOppo["niq_contractenddate"] = dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                    updateQuote = true;
                                }

                            }
                            //Starts here
                            // we created a new plugin for this OnUpdate_Quote_UpdateAgreementType piece of code since the contractstart and end date is populating after this condition triggers
                            /* if (dateQP.Contains("minDate") && dateQP.Contains("maxDate"))
                              {
                                  DateTime startdate = (DateTime)dateQP.GetAttributeValue<AliasedValue>("minDate").Value;
                                  DateTime enddate = (DateTime)dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                  tracing.Trace("startdate1 :" + startdate.ToString());
                                  tracing.Trace("enddate1 :" + enddate.ToString());
                                  int months = ((enddate.Year - startdate.Year) * 12) + enddate.Month - startdate.Month + 1;
                                  tracing.Trace("difference:" + months.ToString());
                                  if (months < 12 && months != 0 && !PreImageObj.Contains("niq_agreementtype"))
                                  {
                                      updQuote["niq_agreementtype"] = new OptionSetValue(100000000);     //adhoc
                                  }
                                  if (months >= 12 && months != 0 && !PreImageObj.Contains("niq_msapaymentterm"))
                                  {
                                      updQuote["niq_agreementtype"] = new OptionSetValue(100000001);     //license
                                  }
                                  if (months >= 12 && months != 0 && PreImageObj.Contains("niq_msapaymentterm"))
                                  {
                                      updQuote["niq_agreementtype"] = new OptionSetValue(100000002);     //local
                                  }
                              }*/
                        }
                        else
                        {
                            tracing.Trace("Setting Start Date & End Date as NULL values");
                            updateQuote = true;
                            updQuote["niq_contractstartdate"] = null;
                            updOppo["niq_contractstartdate"] = null;

                            updQuote["niq_contractenddate"] = null;
                            updOppo["niq_contractenddate"] = null;
                        }

                        if (updateQuote)
                        {
                            tracing.Trace("Updating Quote");
                            service.Update(updQuote);

                            if (isMainQUote && opportunityValue != null)
                            {
                                tracing.Trace("Updating Opportunity");
                                service.Update(updOppo);

                            }
                        }
                    }
                    CalculateAnnualContractValue(service, currentQuote, tracing);
                }

                tracing.Trace("OnUpdate_Quote_ExpValidation_UpdateContractStartAndEndDates: Plugin Executed Successfully");
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException("OnUpdate_Quote_ExpValidation_UpdateContractStartAndEndDates: " + ex.Message);
            }
        }
        private static (Money previousTotalAmount, decimal? previousDiscount) GetTotalAmountAndDiscount(Entity preImage, ITracingService tracing)
        {
            tracing.Trace("GetTotalAmountAndDiscount: Started.");

            Money previousTotalAmount = null;
            decimal? previousDiscount = null;

            if (preImage != null)
            {
                if (preImage.Contains("totalamount") && preImage["totalamount"] != null)
                {
                    previousTotalAmount = preImage.GetAttributeValue<Money>("totalamount");
                    tracing.Trace("Previous Total Amount: " + previousTotalAmount.Value);
                }
                else
                {
                    tracing.Trace("PreImage does not contain 'totalamount' or it is null.");
                }

                if (preImage.Contains("niq_discount") && preImage["niq_discount"] != null)
                {
                    previousDiscount = preImage.GetAttributeValue<decimal?>("niq_discount");
                    tracing.Trace("Previous Discount: " + previousDiscount);
                }
                else
                {
                    tracing.Trace("PreImage does not contain 'niq_discount' or it is null.");
                }
            }
            else
            {
                tracing.Trace("PreImage object is null.");
            }

            tracing.Trace("GetTotalAmountAndDiscount: Completed.");
            return (previousTotalAmount, previousDiscount);
        }
        //DYNCRM-30336 Updating the Annual Contract value and POC value using this two method
        private static void CalculateAnnualContractValue(IOrganizationService service, Entity currentQuote, ITracingService tracing)
        {
            try
            {
                tracing.Trace("CalculateAnnualContractValue: Started.");
                ColumnSet acvColumns = new ColumnSet("niq_ratecardprice", "niq_contractstartdate", "niq_contractenddate", "exchangerate", "niq_salesorgid", "niq_overalldealscore", "niq_annualcontractvalue", "niq_poc");
                Entity quote = service.Retrieve("quote", currentQuote.Id, acvColumns);
                Money rateCardPrice = quote.Contains("niq_ratecardprice") ? quote.GetAttributeValue<Money>("niq_ratecardprice") : null;
                tracing.Trace($"Rate Card Price: {rateCardPrice?.Value.ToString() ?? "null"}");
                if (rateCardPrice == null || rateCardPrice.Value <= 0)
                {
                    tracing.Trace("Rate Card Price is null or zero. Skipping ACV calculation.");
                    return;
                }
                DateTime? contractStartDate = quote.Contains("niq_contractstartdate") ? quote.GetAttributeValue<DateTime?>("niq_contractstartdate") : null;
                DateTime? contractEndDate = quote.Contains("niq_contractenddate") ? quote.GetAttributeValue<DateTime?>("niq_contractenddate") : null;
                decimal? exchangeRate = quote.Contains("exchangerate") ? quote.GetAttributeValue<decimal?>("exchangerate") : null;
                tracing.Trace($"Contract Start Date: {contractStartDate?.ToString() ?? "null"}");
                tracing.Trace($"Contract End Date: {contractEndDate?.ToString() ?? "null"}");
                tracing.Trace($"Exchange Rate: {exchangeRate?.ToString() ?? "null"}");
                if (!contractStartDate.HasValue || !contractEndDate.HasValue)
                {
                    tracing.Trace("Contract dates missing. Cannot calculate ACV.");
                    return;
                }
                if (!exchangeRate.HasValue || exchangeRate.Value <= 0)
                {
                    tracing.Trace("Exchange Rate is null or zero. Cannot calculate ACV.");
                    return;
                }
                double totalDays = (contractEndDate.Value - contractStartDate.Value).TotalDays;
                double numberOfYears = totalDays / 365.25;
                tracing.Trace($"Total Days: {totalDays}, Number of Years: {numberOfYears}");
                if (numberOfYears <= 0)
                {
                    tracing.Trace("Invalid contract period.");
                    return;
                }
                QueryExpression eurQuery = new QueryExpression("transactioncurrency") { ColumnSet = new ColumnSet("exchangerate", "isocurrencycode") };
                eurQuery.Criteria.AddCondition("isocurrencycode", ConditionOperator.Equal, "EUR");
                EntityCollection eurCurrencies = service.RetrieveMultiple(eurQuery);
                if (eurCurrencies.Entities.Count == 0)
                {
                    tracing.Trace("EUR currency not found in system.");
                    return;
                }
                Entity eurCurrency = eurCurrencies.Entities[0];
                decimal eurExchangeRate = eurCurrency.GetAttributeValue<decimal>("exchangerate");
                tracing.Trace($"EUR Exchange Rate: {eurExchangeRate}");
                decimal conversionRate = eurExchangeRate / exchangeRate.Value;
                tracing.Trace($"Conversion Rate: {conversionRate}");
                decimal priceInEUR = rateCardPrice.Value * conversionRate;
                tracing.Trace($"Price in EUR: {priceInEUR}");
                decimal annualContractValue = priceInEUR / (decimal)numberOfYears;
                annualContractValue = Math.Round(annualContractValue, 2);
                tracing.Trace($"Calculated ACV: {annualContractValue}");
                Money existingACV = quote.Contains("niq_annualcontractvalue") ? quote.GetAttributeValue<Money>("niq_annualcontractvalue") : null;
                tracing.Trace($"Existing ACV: {existingACV?.Value.ToString() ?? "null"}");
                bool pocValue = CalculatePOC(service, quote, annualContractValue, tracing);
                bool existingPOC = quote.Contains("niq_poc") && quote.GetAttributeValue<bool>("niq_poc");
                tracing.Trace($"Calculated POC: {pocValue}");
                tracing.Trace($"Existing POC: {existingPOC}");
                bool needsUpdate = false;
                if (existingACV == null || existingACV.Value != annualContractValue)
                {
                    needsUpdate = true;
                    tracing.Trace("ACV has changed. Update needed.");
                }
                if (existingPOC != pocValue)
                {
                    needsUpdate = true;
                    tracing.Trace("POC has changed. Update needed.");
                }
                if (needsUpdate)
                {
                    Entity quoteToUpdate = new Entity("quote", currentQuote.Id);
                    quoteToUpdate["niq_annualcontractvalue"] = new Money(annualContractValue);
                    quoteToUpdate["niq_poc"] = pocValue;
                    service.Update(quoteToUpdate);
                    tracing.Trace("ACV and POC updated successfully.");
                }
                else
                {
                    tracing.Trace("No changes in ACV or POC. Skipping update.");
                }
            }
            catch (Exception ex)
            {
                tracing.Trace($"Error in CalculateAnnualContractValue: {ex.Message}");
                throw new InvalidPluginExecutionException($"Error calculating Annual Contract Value: {ex.Message}", ex);
            }
        }

        private static bool CalculatePOC(IOrganizationService service, Entity quote, decimal annualContractValue, ITracingService tracing)
        {
            try
            {
                tracing.Trace("CalculatePOC: Started.");
                //QueryExpression ddarQuery = new QueryExpression("niq_dealdeskapprovalrequest");
                //ddarQuery.NoLock = true;
                //ddarQuery.TopCount = 1;
                //ddarQuery.ColumnSet = new ColumnSet("niq_dealdeskapprovalrequestid", "niq_poc_flag");
                //ddarQuery.Criteria.AddCondition("niq_quoteid", ConditionOperator.Equal, quote.Id);
                //ddarQuery.Criteria.AddCondition("statecode", ConditionOperator.Equal, 1); // Inactive/Approved
                //ddarQuery.Criteria.AddCondition("niq_poc_flag", ConditionOperator.Equal, true);
                //ddarQuery.AddOrder("createdon", OrderType.Descending);
                //var resultDDAR = service.RetrieveMultiple(ddarQuery);
                //if (resultDDAR.Entities.Count > 0)
                //{
                //    tracing.Trace("Found approved DDAR with POC flag = true. POC will remain FALSE.");
                //    return false;
                //}
                EntityReference salesOrgRef = quote.Contains("niq_salesorgid") ? quote.GetAttributeValue<EntityReference>("niq_salesorgid") : null;
                if (salesOrgRef == null)
                {
                    tracing.Trace("Sales Org ID is null. POC = FALSE.");
                    return false;
                }
                Guid salesOrgId = salesOrgRef.Id;
                tracing.Trace($"Sales Org ID: {salesOrgId}");
                Entity salesOrg = service.Retrieve("niq_salesorg", salesOrgId, new ColumnSet("niq_poc"));
                bool salesOrgPOC = salesOrg.Contains("niq_poc") && salesOrg.GetAttributeValue<bool>("niq_poc");
                tracing.Trace($"Sales Org POC: {salesOrgPOC}");
                if (!salesOrgPOC || annualContractValue < 375000)
                {
                    tracing.Trace($"Sales Org POC is FALSE or ACV ({annualContractValue}) < 375,000. POC = FALSE.");
                    return false;
                }
                string overallDealScore = quote.Contains("niq_overalldealscore") ? quote.GetAttributeValue<string>("niq_overalldealscore") : null;
                tracing.Trace($"Overall Deal Score: {overallDealScore ?? "null"}");
                if (!string.IsNullOrEmpty(overallDealScore))
                {
                    bool isRedOrYellow = overallDealScore.Equals("Red", StringComparison.OrdinalIgnoreCase) || overallDealScore.Equals("Yellow", StringComparison.OrdinalIgnoreCase);
                    tracing.Trace($"Overall Deal Score is Red or Yellow: {isRedOrYellow}");
                    return isRedOrYellow;
                }
                tracing.Trace("No Overall Deal Score. POC = TRUE.");
                return true;
            }
            catch (Exception ex)
            {
                tracing.Trace($"Error in CalculatePOC: {ex.Message}");
                throw new InvalidPluginExecutionException($"Error calculating POC: {ex.Message}", ex);
            }
        }
    }

}