﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.Plugins.Helper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.Plugins
{
    public class PostOperationOpportunitySetReadyForNextStage : IPlugin
    {
        private ITracingService tracing = null;
        private IOrganizationService service = null;
        private string previousStage = null;
        private Entity opportunity = null;
        private Entity mainQuote = new Entity("quote");
        public readonly int MismatchedScheduleDates = 610570000;
        public readonly int MatchedScheduleDates = 610570001;
        //common for revenue and billing 
        public readonly int QuoteCompleteSchedules = 610570001;
        public readonly int QuoteInCompleteSchedules = 610570002;
        public readonly int BASES = 100000000;


        //all trigger are only from opportunity
        string[] preProposalStage_OpportunityTrigger = {
            "niq_stage", //when there is change in stage 
            //sales related columns
            "niq_salesorgid",
            "niq_creatorsbusinessfunctionalunit", //sales group mandatory depends on it 
            "niq_salesgroupsalesorgid",

            "niq_businessarea",
            "niq_fieldingcountry",
            "niq_fieldingcountryci",
            
            //calculated field - depends on quote contract start and end date and main quote on opportunity
            "niq_forecastingdatapresence", //it will not trigger, calculate field
            "niq_mainquoteid",

            "niq_primarycontactid",

            "niq_revenuesharedeal",
            "niq_localcontributor"
        };

        string[] preProposalStage_QuoteTrigger =
        {
            //niq_forecastingdatapresence - calculated field 
            "niq_contractstartdate",
            "niq_contractenddate"
        };

        string[] proposalStage_OpportunityTrigger =
        {
            "niq_stage", //when there is change in stage 
            "niq_mainquotesdealdeskapprovalobtained",//it will not trigger, calculate field, but we the data of it
            //DDG trigger - 4
            "niq_dealguidanceerrortimestampopp"
        };

        //all are quote fields
        string[] proposalStage_QuoteTrigger = {
                         
            //Proposal, Negotiation
            "niq_overalldealdeskapproval",//niq_mainquotesdealdeskapprovalobtained

            //Proposal stage
            //schedule
            "niq_revenueschedulecomplete",
            "niq_billingschedulecomplete",
            "niq_tracecustomscheduledates",
            //ddg            
            "niq_dealguidanceexecutedatleastonce",//DDG trigger - 1
            "niq_dealscoringinprogress",//DDG trigger - 2
            "niq_overalldealscore"//DDG trigger - 3
        };



        string[] negotiationStage_OpportunityTrigger =
        {
            "niq_stage", //when there is change in stage 
            "niq_mainquotesdealdeskapprovalobtained",//it will not trigger, calculate field, but we the data of it

            "niq_soldtopartyverified",
            "niq_billtopartyverified",
            "niq_delivertopartyverified",
            "niq_tempeoafinallyexecutedagreementprovided", //niq_clmgate2
            "niq_billinginstructions",
            "niq_mandatorycharvaluesadded",

            "niq_businessarea",
            "niq_terminationclause",//business area

            "niq_signedagreementcreatedandexecutedfromquot", //niq_clmgate2
            "niq_invoicedispatchmethod", //business area

             //DDG trigger - 4
            "niq_dealguidanceerrortimestampopp",

            //checkforActiveOPERecords
            "niq_opportunitytype",
            "niq_product_enhancement_impact_provisions"
        };
        string[] negotiationStage_QuoteTrigger =
        {
            "niq_overalldealdeskapproval",//niq_mainquotesdealdeskapprovalobtained                
            "niq_clmgate2",
                
            //Bpf logic fields
            //schedule
            "niq_revenueschedulecomplete",
            "niq_billingschedulecomplete",
            "niq_tracecustomscheduledates",

            //ddg
            "niq_dealguidanceexecutedatleastonce",//DDG trigger - 1
            "niq_dealscoringinprogress",//DDG trigger - 2
            "niq_overalldealscore",//DDG trigger - 3

            //BPF - TothrowerrorforAgreementtype
            "niq_agreementtype"
        };

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                service = serviceFactory.CreateOrganizationService(context.UserId);


                // The InputParameters collection contains all the data 
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("PostOperationOpportunitySetReadyForNextStage");
                    tracing.Trace("Entity : " + context.PrimaryEntityName);
                    tracing.Trace("Message : " + context.MessageName);

                    string currentStage = null;
                    if (context.PrimaryEntityName == "opportunity" && context.MessageName.ToLower() == "update")
                    {
                        Entity targetOpportunity = (Entity)context.InputParameters["Target"];
                        Entity PostImageOpportunity = (Entity)context.PostEntityImages["PostImage"];
                        currentStage = PostImageOpportunity.Contains("niq_stage") && PostImageOpportunity["niq_stage"] != null ? PostImageOpportunity.GetAttributeValue<String>("niq_stage").ToLower() : null;
                        opportunity = targetOpportunity;

                        EntityReference oppQuote = PostImageOpportunity.GetAttributeValue<EntityReference>("niq_mainquoteid");
                        if (oppQuote != null)
                        {
                            mainQuote.Id = oppQuote.Id;
                        }

                        tracing.Trace("Opportunity ID: " + opportunity.Id);
                        RedirectToStage(targetOpportunity, currentStage);
                    }
                    if (context.PrimaryEntityName == "quote" && context.MessageName.ToLower() == "update")
                    {
                        Entity targetQuote = (Entity)context.InputParameters["Target"];
                        Entity PostImageQuote = (Entity)context.PostEntityImages["PostImage"];
                        EntityReference opportunityLookup = PostImageQuote.Contains("opportunityid") && PostImageQuote["opportunityid"] != null ? PostImageQuote.GetAttributeValue<EntityReference>("opportunityid") : null;
                        bool isMainQuote = PostImageQuote.Contains("niq_mainquote") && PostImageQuote["niq_mainquote"] != null ? PostImageQuote.GetAttributeValue<bool>("niq_mainquote") : false;
                        tracing.Trace("quote id : " + targetQuote.Id);
                        tracing.Trace("is Main quote : " + isMainQuote);

                        //Only if it is Main quote
                        if (isMainQuote)
                        {
                            Entity opportunityDetails = service.Retrieve(opportunityLookup.LogicalName, opportunityLookup.Id, new ColumnSet("niq_stage"));
                            currentStage = opportunityDetails.Contains("niq_stage") && opportunityDetails["niq_stage"] != null ? opportunityDetails.GetAttributeValue<string>("niq_stage") : null;
                            opportunity = opportunityDetails;
                            tracing.Trace("Opportunity ID: " + opportunity.Id);
                            //quote - preproposal
                            if (targetQuote.Contains("niq_contractstartdate") || targetQuote.Contains("niq_contractenddate"))
                            {
                                tracing.Trace("if there is change in Quote contract dates, check previous and current dates");
                                Entity PreImageQuote = (Entity)context.PreEntityImages["PreImage"];
                                DateTime? previousContractStartDate = PreImageQuote.Contains("niq_contractstartdate") && PreImageQuote["niq_contractstartdate"] != null ? PreImageQuote.GetAttributeValue<DateTime?>("niq_contractstartdate") : null;
                                DateTime? previousContractEndDate = PreImageQuote.Contains("niq_contractenddate") && PreImageQuote["niq_contractenddate"] != null ? PreImageQuote.GetAttributeValue<DateTime?>("niq_contractenddate") : null;
                                DateTime? currentContractStartDate = PostImageQuote.Contains("niq_contractstartdate") && PostImageQuote["niq_contractstartdate"] != null ? PostImageQuote.GetAttributeValue<DateTime?>("niq_contractstartdate") : null;
                                DateTime? currentContractEndDate = PostImageQuote.Contains("niq_contractenddate") && PostImageQuote["niq_contractenddate"] != null ? PostImageQuote.GetAttributeValue<DateTime?>("niq_contractenddate") : null;
                                tracing.Trace("previousContractStartDate : " + previousContractStartDate);
                                tracing.Trace("previousContractEndDate : " + previousContractEndDate);
                                tracing.Trace("currentContractStartDate : " + currentContractStartDate);
                                tracing.Trace("currentContractEndDate : " + currentContractEndDate);
                                if ((currentContractStartDate == null || currentContractEndDate == null) ||
                                   (previousContractStartDate == null && previousContractEndDate == null && currentContractStartDate != null && currentContractEndDate != null))// change of dates
                                {
                                    tracing.Trace("Dates got filled or dates got removed - check begins");
                                    //check stage - PreProposal 
                                    mainQuote = targetQuote;
                                    RedirectToStage(targetQuote, currentStage);
                                }
                            }
                            else
                            {
                                mainQuote = targetQuote;
                                tracing.Trace("There is no change in dates");
                                RedirectToStage(targetQuote, currentStage);
                            }
                        }

                    }
                    if (context.PrimaryEntityName == "niq_opportunityproductenhancement" && context.MessageName.ToLower() == "create")
                    {
                        tracing.Trace("niq_opportunityproductenhancement is created");
                        Entity opportunityproductenhancement = (Entity)context.InputParameters["Target"];
                        EntityReference opportunityNameId = opportunityproductenhancement.GetAttributeValue<EntityReference>("niq_opportunitynameid");
                        Entity opportunityDetails = service.Retrieve(opportunityNameId.LogicalName, opportunityNameId.Id, new ColumnSet("niq_stage", "niq_mainquoteid"));
                        currentStage = opportunityDetails.GetAttributeValue<string>("niq_stage");
                        EntityReference oppQuote = opportunityDetails.GetAttributeValue<EntityReference>("niq_mainquoteid");
                        if (oppQuote != null)
                        {
                            mainQuote.Id = oppQuote.Id;
                        }
                        if (!string.IsNullOrEmpty(currentStage) && string.Equals(currentStage.ToLower(), "negotiation"))
                        {

                            tracing.Trace("niq_opportunityproductenhancement checking can be done only if the stage is negotiation");
                            opportunity = opportunityDetails;
                            //as we retrieve the niq_stage, the function thinks the niq_stage got changed.
                            RedirectToStage(opportunityDetails, currentStage);
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("PostOperationOpportunitySetReadyForNextStage : " + ex.Message);
            }
        }

        public void RedirectToStage(Entity targetEntity, string currentStage)
        {
            tracing.Trace("func: RedirectToStage - stage :" + currentStage);
            currentStage = currentStage.ToLower();
            Entity updateOpportunity = new Entity("opportunity");
            updateOpportunity.Id = opportunity.Id;
            if (!string.IsNullOrEmpty(currentStage) && string.Equals(currentStage, "pre-proposal"))
            {
                if (isFieldGotTrigger(targetEntity, preProposalStage_OpportunityTrigger) || isFieldGotTrigger(targetEntity, preProposalStage_QuoteTrigger))
                {
                    updateOpportunity["niq_readyfornextstage"] = PreProposal();
                }
            }
            else if (!string.IsNullOrEmpty(currentStage) && string.Equals(currentStage, "proposal"))
            {
                if (isFieldGotTrigger(targetEntity, proposalStage_OpportunityTrigger) || isFieldGotTrigger(targetEntity, proposalStage_QuoteTrigger))
                    updateOpportunity["niq_readyfornextstage"] = Proposal();
            }
            else if (!string.IsNullOrEmpty(currentStage) && string.Equals(currentStage, "negotiation"))
            {
                if (isFieldGotTrigger(targetEntity, negotiationStage_QuoteTrigger) || isFieldGotTrigger(targetEntity, negotiationStage_OpportunityTrigger))
                    updateOpportunity["niq_readyfornextstage"] = Negotiation();
            }
            else
            {
                tracing.Trace("for all other stage it ready for next stage is false");
                updateOpportunity["niq_readyfornextstage"] = false;
            }
            service.Update(updateOpportunity);
        }
        public bool isFieldGotTrigger(Entity entity, string[] fields)
        {
            tracing.Trace("func: isFieldGotTrigger - Entity name: " + entity.LogicalName);
            foreach (var field in fields)
            {
                if (entity.Contains(field))
                {
                    tracing.Trace("Field Changed is:  --->> " + field);
                    return true;
                }
            }
            tracing.Trace("None of the required fields triggered");
            return false;
        }

        public bool PreProposal()
        {
            tracing.Trace("\nPreproposal Checking begins :");

            Entity opportunityDetails = service.Retrieve(opportunity.LogicalName, opportunity.Id, new ColumnSet(preProposalStage_OpportunityTrigger));

            if (!isSalesGroupFilled(opportunityDetails))
                return false;

            if (!checkFieldingCountry(opportunityDetails))
            {
                return false;
            }

            if (!checkLockForecastingdatapresenseOnBPF(opportunityDetails))
            {
                return false;
            };

            tracing.Trace("\tPrimary contact is filled ??");
            EntityReference primaryContact = opportunityDetails.Contains("niq_primarycontactid") && opportunityDetails["niq_primarycontactid"] != null ? opportunityDetails.GetAttributeValue<EntityReference>("niq_primarycontactid") : null;
            if (primaryContact == null)
            {
                tracing.Trace("\t\tPrimary contact should not be empty");
                return false;
            }
            tracing.Trace("\t\tprimary contact is not empty");

            if (!ConfigureLocalcontributor(opportunityDetails))
            {
                return false;
            }
            tracing.Trace("All the Required data is filled in \'Preproposal stage\'");
            return true;
        }
        public bool Proposal()
        {
            tracing.Trace("\nProposal Checking begins :");
            Entity quoteDetails = service.Retrieve("quote", mainQuote.Id, new ColumnSet(proposalStage_QuoteTrigger));
            Entity opportunityDetails = service.Retrieve("opportunity", opportunity.Id, new ColumnSet(proposalStage_OpportunityTrigger));
            if (!isDealDeskOptioned(opportunityDetails, quoteDetails))
            {
                return false;
            }
            if (!checkSchedules(quoteDetails))
            {
                return false;
            }
            if (!checkDDG(quoteDetails))
            {
                return false;
            }
            tracing.Trace("All the Required data is filled in \'Proposal stage\'");

            return true;
        }

        public bool Negotiation()
        {
            tracing.Trace("\tNegotiation Checking begins :");
            Entity quoteDetails = service.Retrieve("quote", mainQuote.Id, new ColumnSet(negotiationStage_QuoteTrigger));
            Entity opportunityDetails = service.Retrieve(opportunity.LogicalName, opportunity.Id, new ColumnSet(negotiationStage_OpportunityTrigger));

            if (!isDealDeskOptioned(opportunityDetails, quoteDetails))
            {
                return false;
            }

            tracing.Trace("\t sold to, bill to, delivery to party - verification begins");
            tracing.Trace("\t\tniq_soldtopartyverified :" + opportunityDetails.GetAttributeValue<bool>("niq_soldtopartyverified"));
            tracing.Trace("\t\tiq_billtopartyverified :" + opportunityDetails.GetAttributeValue<bool>("niq_billtopartyverified"));
            tracing.Trace("\t\tniq_delivertopartyverified :" + opportunityDetails.GetAttributeValue<bool>("niq_soldtopartyverified"));
            if (!(opportunityDetails.GetAttributeValue<bool>("niq_soldtopartyverified") && opportunityDetails.GetAttributeValue<bool>("niq_billtopartyverified") && opportunityDetails.GetAttributeValue<bool>("niq_delivertopartyverified")))
            {
                tracing.Trace("\t\tIn sold to, bill to, delivery to party one of the field is not verified");
                return false;
            }
            tracing.Trace("\t\t sold to, bill to, delivery to party - verification completed");


            if (!TempOrFinallyExecutedURLValidation(opportunityDetails, quoteDetails))
            {
                return false;
            }
            tracing.Trace("\tBilling instruction check");
            if (opportunityDetails.Contains("niq_billinginstructions") && opportunityDetails["niq_billinginstructions"] == null)
            {
                tracing.Trace("\t\tBillig instrucation can't be empty in negotiation stage");
                return false;
            }
            tracing.Trace("\t\tBilling instruction check is completed");

            tracing.Trace("\tniq_mandatorycharvaluesadded check");
            bool mandatoryCharValuesAdded = opportunityDetails.GetAttributeValue<bool>("niq_mandatorycharvaluesadded");
            if (mandatoryCharValuesAdded == false)
            {
                tracing.Trace("\t\tniq_mandatorycharvaluesadded should be yes");
                return false;
            }
            tracing.Trace("\t\tniq_mandatorycharvaluesadded check is completed");

            tracing.Trace("\tTermination clause check");
            OptionSetValue businessArea = opportunityDetails.GetAttributeValue<OptionSetValue>("niq_businessarea");
            OptionSetValue terminationClause = opportunityDetails.GetAttributeValue<OptionSetValue>("niq_terminationclause");
            if (businessArea != null && businessArea.Value == BASES && terminationClause == null)
            {
                tracing.Trace("\t\tTermination clause can't be empty for bases opportunity");
                return false;
            }
            tracing.Trace("\t\tTermination clause check is completed");



            tracing.Trace("\tinvoicedispatchmethod check");
            OptionSetValue shouldclientbeinvoicedforthisopportunity = opportunityDetails.GetAttributeValue<OptionSetValue>("niq_shouldclientbeinvoicedforthisopportunity");
            OptionSetValue invoicedispatchmethod = opportunityDetails.GetAttributeValue<OptionSetValue>("niq_invoicedispatchmethod");
            //yes
            if (shouldclientbeinvoicedforthisopportunity != null && shouldclientbeinvoicedforthisopportunity.Value == 100000000 &&
                businessArea != null && businessArea.Value == BASES && invoicedispatchmethod == null)
            {
                tracing.Trace("\t\tinvoicedispatchmethod can't be empty for bases opportunity when shouldclientbeinvoicedforthisopportunity is yes");
                return false;
            }
            tracing.Trace("\t\tinvoicedispatchmethod check");

            if (!checkSchedules(quoteDetails))
            {
                return false;
            }

            if (!checkDDG(quoteDetails))
            {
                return false;
            }
            if (!TothrowerrorforAgreementtype(quoteDetails))
            {
                return false;
            }


            if (!checkforActiveOPERecords(opportunityDetails))
            {
                return false;
            }
            tracing.Trace("All the Required data is filled in \'Negotiation stage\'");

            return true;

        }
        public bool ConfigureLocalcontributor(Entity opportunityDetails)
        {
            tracing.Trace("\tConfigureLocalcontributor check:");
            EntityReference localContributor = opportunityDetails.Contains("niq_localcontributor") && opportunityDetails["niq_localcontributor"] != null ? opportunityDetails.GetAttributeValue<EntityReference>("niq_localcontributor") : null;
            bool? revenueShareDeal = opportunityDetails.Contains("niq_revenuesharedeal") && opportunityDetails["niq_revenuesharedeal"] != null ? opportunityDetails.GetAttributeValue<bool?>("niq_revenuesharedeal") : null;
            tracing.Trace("\t\tniq_forecastingdatapresence : " + opportunityDetails.GetAttributeValue<bool>("niq_forecastingdatapresence"));

            if (revenueShareDeal != null && revenueShareDeal == true && localContributor == null)
            {
                tracing.Trace("\t\twhen revenue share deal is true, localContributor should not be null");
                return false;
            }
            tracing.Trace("\t\trevenue share deal is false and local contributor can be empty");
            return true;
        }
        //reference
        //js - LockForecastingdatapresenseOnBPF
        public bool checkLockForecastingdatapresenseOnBPF(Entity opportunityDetails)
        {
            tracing.Trace("\tcheckLockForecastingdatapresenseOnBPF");
            bool? forecastingdatapresence = opportunityDetails.Contains("niq_forecastingdatapresence") && opportunityDetails["niq_forecastingdatapresence"] != null ? opportunityDetails.GetAttributeValue<bool?>("niq_forecastingdatapresence") : null;
            bool? revenueShareDeal = opportunityDetails.Contains("niq_revenuesharedeal") && opportunityDetails["niq_revenuesharedeal"] != null ? opportunityDetails.GetAttributeValue<bool?>("niq_revenuesharedeal") : null;
            tracing.Trace("\t\tniq_forecastingdatapresence : " + opportunityDetails.GetAttributeValue<bool>("niq_forecastingdatapresence"));

            if (revenueShareDeal != null && revenueShareDeal == false && forecastingdatapresence == false)
            {
                tracing.Trace("\t\twhen revenue share deal is false, forecastingdatapresence should not be false");
                return false;
            }
            tracing.Trace("\t\tniq_forecastingdatapresence data is filled as per need");
            return true;
        }
        //reference
        //bpf - BR_show_hide_fielding_country_opt_opportunity_from_csat_on_opp_bpf
        //js -  BpfFieldingCountry_OnLoad,
        //js - fieldingCountryCI_OnChange
        public bool checkFieldingCountry(Entity opportunityDetails)
        {
            tracing.Trace("\tfunc: checkFieldingCountry");
            OptionSetValue BusinessArea = opportunityDetails.Contains("niq_businessarea") && opportunityDetails["niq_businessarea"] != null ? opportunityDetails.GetAttributeValue<OptionSetValue>("niq_businessarea") : null;
            EntityReference fieldingCountry = opportunityDetails.Contains("niq_fieldingcountry") && opportunityDetails["niq_fieldingcountry"] != null ? opportunityDetails.GetAttributeValue<EntityReference>("niq_fieldingcountry") : null;
            OptionSetValueCollection fieldingCountryCI = opportunityDetails.Contains("niq_fieldingcountryci") && opportunityDetails["niq_fieldingcountryci"] != null ? opportunityDetails.GetAttributeValue<OptionSetValueCollection>("niq_fieldingcountryci") : null;

            if (BusinessArea != null)
            {
                tracing.Trace("\t\tBusiness Area: " + BusinessArea.Value);
                if (BusinessArea.Value == 100000000 && fieldingCountry == null) //bases
                {
                    tracing.Trace("\t\tBusiness Area is bases and niq_fieldingcountry is not filled: false");
                    return false;
                }
                if (BusinessArea.Value == 100000001 && fieldingCountryCI == null)//CI
                {
                    tracing.Trace("\t\tBusiness Area is CI and niq_fieldingcountryci is not filled: false");
                    return false;
                }
            }
            tracing.Trace("\t\tFielding country details are filled as per need");
            return true;
        }

        //refered from js- SalesOrgSalesGroupRequired
        //js - OnCreateofOpportunity
        public bool isSalesGroupFilled(Entity opportunityDetails)
        {
            tracing.Trace("\tfunc: isSalesGroupFilled");
            EntityReference salesOrg = opportunityDetails.Contains("niq_salesorgid") ? opportunityDetails.GetAttributeValue<EntityReference>("niq_salesorgid") : null;
            EntityReference originalOppo = opportunityDetails.Contains("niq_originalopportunityid") ? opportunityDetails.GetAttributeValue<EntityReference>("niq_originalopportunityid") : null;
            string BU = opportunityDetails.Contains("niq_creatorsbusinessfunctionalunit") ? opportunityDetails.GetAttributeValue<string>("niq_creatorsbusinessfunctionalunit") : null;
            bool isrequired = false;
            if (salesOrg != null)
            {
                Entity salesOrgDetails = service.Retrieve(salesOrg.LogicalName, salesOrg.Id, new ColumnSet("niq_salesorgcode"));
                string salesOrgCode = salesOrgDetails.Contains("niq_salesorgcode") ? salesOrgDetails.GetAttributeValue<string>("niq_salesorgcode") : null;
                if (!string.IsNullOrEmpty(salesOrgCode))
                {
                    // Retrieve Sales Org List_Oppoortunity_Lead configurationsetting
                    var query = new QueryExpression("niq_configurationsetting")
                    {
                        ColumnSet = new ColumnSet("niq_to"),
                        Criteria = new FilterExpression
                        {
                            Conditions =
                            {
                                new ConditionExpression("niq_name", ConditionOperator.Equal, "Sales Org List_Oppoortunity_Lead")
                            }
                        }
                    };

                    var results = service.RetrieveMultiple(query);
                    if (results.Entities.Count > 0 && results.Entities[0].Contains("niq_to"))
                    {
                        var niq_to = results.Entities[0]["niq_to"].ToString();
                        if (niq_to.Contains(salesOrgCode) && BU == null)
                        {
                            isrequired = true;
                            if (originalOppo == null && BU == null)
                            {
                                isrequired = true;
                            }
                            else
                            {
                                isrequired = false;
                            }
                        }
                        else
                        {
                            isrequired = false;
                        }
                    }
                }
            }
            //it is required and it as to be filled
            if (isrequired && opportunityDetails.Contains("niq_salesgroupsalesorgid") && opportunityDetails["niq_salesgroupsalesorgid"] != null)
            {
                tracing.Trace("\t\tsales group is filled : true");
                return true;
            }

            if (!isrequired)
            {
                tracing.Trace("\t\tsales group is not required ");
                return true;
            }

            tracing.Trace("\t\tsales group is not filled : false");
            return false;

        }


        //note: dont need to trigger this DDG logic when the RMS product is added or removed because Anyway the schedules logic will trigger 
        //when it trigger the whole Proposal and negotation condition are validated.
        public bool checkDDG(Entity quoteDetails)
        {
            tracing.Trace("\tcheck DDG");
            // Retrieve opportunity
            Entity opportunityDetails = service.Retrieve("opportunity", opportunity.Id, new ColumnSet(
                "niq_existingcontractaction", "niq_businessarea", "niq_ishostopportunity", "niq_hostopportunity",
                "niq_dealguidanceerrortimestampopp", "niq_mainquoteid"));

            OptionSetValue existingContractAction = opportunityDetails.Contains("niq_existingcontractaction") ? opportunityDetails.GetAttributeValue<OptionSetValue>("niq_existingcontractaction") : null;
            OptionSetValue businessarea = opportunityDetails.Contains("niq_businessarea") ? opportunityDetails.GetAttributeValue<OptionSetValue>("niq_businessarea") : null;
            bool isHostOppo = opportunityDetails.GetAttributeValue<bool?>("niq_ishostopportunity") ?? false;
            EntityReference hostOppoRef = opportunityDetails.GetAttributeValue<EntityReference>("niq_hostopportunity");
            DateTime? timestampOpp = opportunityDetails.GetAttributeValue<DateTime?>("niq_dealguidanceerrortimestampopp");

            tracing.Trace("\t\t ishostopp:" + (!isHostOppo && hostOppoRef == null));
            tracing.Trace("\t\tbusiness check:" + ((businessarea == null) || (businessarea != null && businessarea.Value != 100000000 && businessarea.Value != 100000001)));
            tracing.Trace("\t\texisting contractaction check:" + ((existingContractAction == null) || (existingContractAction != null && existingContractAction.Value != 2 && existingContractAction.Value != 3)));
            //in js if the value is null, it is like ( null != value ) is true;

            /****DYNCRM31242_Start****/
            var brands = CommonHelper.GetEnvVarDefaultValue(service, "niq_RMSBrands", tracing);
            var eligibleBrands = brands.Split(',').Select(b => b.Trim()).ToArray();
            tracing.Trace("Eligible Brands: {0}", string.Join(", ", eligibleBrands));
            /****DYNCRM31242_End****/
            if (!isHostOppo && hostOppoRef == null &&
                ((businessarea == null) || (businessarea != null && businessarea.Value != 100000000 && businessarea.Value != 100000001))
                 &&
                 ((existingContractAction == null) || (existingContractAction != null && existingContractAction.Value != 2 && existingContractAction.Value != 3))
                 )
            {
                /****DYNCRM31242_Start****/
                string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                 <entity name='quotedetail'>
                  <attribute name='niq_brandid' />
                  <attribute name='quotedetailname' />
                  <attribute name='quotedetailid' />
                  <order attribute='niq_brandid' descending='false' />
                  <filter type='and'>
                   <condition attribute='quoteid' operator='eq' uitype='quote' value='{mainQuote.Id}' />
                  </filter>
                  <link-entity name='product' from='productid' to='niq_brandid' link-type='inner' alias='ac'>
                   <filter type='and'>
                    <condition attribute='name' operator='in' value='{eligibleBrands}'/>
                   </filter>
                  </link-entity>
                 </entity>
                </fetch>";
                /****DYNCRM31242_End****/
                var quoteProducts = service.RetrieveMultiple(new FetchExpression(fetchXml));
                tracing.Trace("\t\tNo of RMS product count is :" + quoteProducts.Entities.Count);
                if (quoteProducts.Entities.Count == 0)
                {
                    tracing.Trace("\t\tthere is NO RMS product so ddg validation is not needed.");
                    return true;
                }



                bool? executedOnce = quoteDetails.GetAttributeValue<bool?>("niq_dealguidanceexecutedatleastonce");
                bool? scoringInProgress = quoteDetails.GetAttributeValue<bool?>("niq_dealscoringinprogress");
                string overallScore = quoteDetails.Contains("niq_overalldealscore") && quoteDetails["niq_overalldealscore"] != null ? quoteDetails.GetAttributeValue<string>("niq_overalldealscore") : null;




                if (executedOnce == false)
                {
                    if (scoringInProgress == true)
                    {
                        tracing.Trace("\t\t1. A Deal Guidance flow is in progress. Please wait for the result to be available in MSD under the Deal Guidance tab of the Main Quote.");
                        return false;
                    }
                    else
                    {
                        tracing.Trace("\t\t2. Deal Guidance result is required. Please go to your Main Quote and click on the Trigger Deal Guidance button.");
                        return false;
                    }
                }
                else if (executedOnce == true && scoringInProgress == true)
                {
                    tracing.Trace("\t\t3. A Deal Guidance flow is in progress. Please wait for the result to be available in MSD under the Deal Guidance tab of the Main Quote.");
                    return false;
                }
                else if (executedOnce == true && scoringInProgress == false)
                {
                    if (overallScore == null && timestampOpp != null)
                    {
                        tracing.Trace("\t\t4. The last Deal Guidance flow failed. Please go to your Main Quote and retrigger the flow by clicking on the Trigger Deal Guidance button.");
                        return false;
                    }
                }

            }
            tracing.Trace("\t\tDDG is successfully completed");
            return true;
        }

        public bool checkSchedules(Entity quoteDetails)
        {
            tracing.Trace("\tcheckSchedules");
            OptionSetValue revenueScheduleComplete = quoteDetails.GetAttributeValue<OptionSetValue>("niq_revenueschedulecomplete");
            OptionSetValue billingschedulecomplete = quoteDetails.GetAttributeValue<OptionSetValue>("niq_billingschedulecomplete");
            OptionSetValue tracecustomscheduledates = quoteDetails.GetAttributeValue<OptionSetValue>("niq_tracecustomscheduledates");

            if (revenueScheduleComplete != null && revenueScheduleComplete.Value == QuoteCompleteSchedules
                && billingschedulecomplete != null && billingschedulecomplete.Value == QuoteCompleteSchedules
                && (tracecustomscheduledates == null || tracecustomscheduledates.Value == MatchedScheduleDates))
            {
                tracing.Trace("\t\tschedules are generated and within start and end date of quote product");
                return true;
            }
            tracing.Trace("\t\tMay be schedules are not generated and not within start and end date of quote product");

            return false;
        }
        public bool isDealDeskOptioned(Entity opportunityDetails, Entity quoteDetails)
        {
            tracing.Trace("\tfunc: isDealDeskOptioned");
            bool? isApproved = opportunityDetails.Contains("niq_mainquotesdealdeskapprovalobtained") && opportunityDetails["niq_mainquotesdealdeskapprovalobtained"] != null ? opportunityDetails.GetAttributeValue<bool?>("niq_mainquotesdealdeskapprovalobtained") : null;
            OptionSetValue overalldealdeskapproval = quoteDetails.GetAttributeValue<OptionSetValue>("niq_overalldealdeskapproval");
            if (isApproved != null &&
                overalldealdeskapproval != null && (overalldealdeskapproval.Value == 5 || overalldealdeskapproval.Value == 6)
                && isApproved == true)
            {
                tracing.Trace("\t\tniq_mainquotesdealdeskapprovalobtained is obtained, when overalldealdeskapproval is approved or no approval required.");
                return true;
            }
            tracing.Trace("\t\tniq_mainquotesdealdeskapprovalobtained is not obtained, check whether overalldealDesk is approved or no approval required");
            return false;

        }

        //header_process_niq_product_enhancement_impact_provisions -Has impact from related Opportunity Product Enhancements been provided?
        public bool checkforActiveOPERecords(Entity opportunityDetails)
        {
            tracing.Trace("\tfunc: checkforActiveOPERecords");
            OptionSetValue opportunitytype = opportunityDetails.GetAttributeValue<OptionSetValue>("niq_opportunitytype");
            if (opportunitytype != null && opportunitytype.Value == 2)
            {
                // Build query for related niq_opportunityproductenhancement records
                QueryExpression query = new QueryExpression("niq_opportunityproductenhancement")
                {
                    ColumnSet = new ColumnSet("niq_opportunityproductenhancementid"),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("statecode", ConditionOperator.Equal, 0),
                            new ConditionExpression("niq_opportunitynameid", ConditionOperator.Equal, opportunityDetails.Id)
                        }
                    }
                };
                EntityCollection OPEs = service.RetrieveMultiple(query);
                tracing.Trace("\t\tno of OPE records :" + OPEs.Entities.Count);
                if (OPEs.Entities.Count > 0)
                {
                    bool? productEnhancement = opportunityDetails.GetAttributeValue<bool?>("niq_product_enhancement_impact_provisions");
                    if (productEnhancement != null && productEnhancement == false)
                    {
                        tracing.Trace("\t\tniq_product_enhancement_impact_provisions field should not be false, as we have more than 1 ope record");
                        return false;
                    }
                }
            }
            tracing.Trace("\t\twe have niq_product_enhancement_impact_provisions field conditions are satisfied");
            return true;

        }
        //trigger - niq_agreementtype
        public bool TothrowerrorforAgreementtype(Entity quoteDetails)
        {
            tracing.Trace("\tTothrowerrorforAgreementtype");
            OptionSetValue agreementtype = quoteDetails.GetAttributeValue<OptionSetValue>("niq_agreementtype");
            if (agreementtype == null)
            {
                tracing.Trace("\t\tAgreement Type must be populated on the main quote before you can move past Negotiation stage");
                return false;
            }
            tracing.Trace("\t\tAgreement type is populated");
            return true;
        }
        //js - TempOrFinallyExecutedURLValidation
        //js - SetURLCheckboxNegotiationStage
        //br - BR_Opportunity_Temp EOA or Finally Executed Agreement Provided_validations
        public bool TempOrFinallyExecutedURLValidation(Entity opportunityDetails, Entity quoteDetails)
        {
            tracing.Trace("\tTempOrFinallyExecutedURLValidation");
            bool? clmgate2 = quoteDetails.Contains("niq_clmgate2") && quoteDetails["niq_clmgate2"] != null ? quoteDetails.GetAttributeValue<bool?>("niq_clmgate2") : null;
            bool signedagreementRequired = false;
            bool tempoaIsRequired = false;

            if (clmgate2 != null && clmgate2 == true)
            {
                signedagreementRequired = true;
                tempoaIsRequired = false;
            }
            else if (clmgate2 == false || clmgate2 == null)
            {
                signedagreementRequired = false;
                tempoaIsRequired = true;
            }
            bool signedAgreement = opportunityDetails.GetAttributeValue<bool>("niq_signedagreementcreatedandexecutedfromquot");
            bool tempeoaf = opportunityDetails.GetAttributeValue<bool>("niq_tempeoafinallyexecutedagreementprovided");
            if (signedagreementRequired && !signedAgreement)
            {
                tracing.Trace("\t\tniq_signedagreementcreatedandexecutedfromquot is required but not true");
                return false;
            }
            if (tempoaIsRequired && !tempeoaf)
            {
                tracing.Trace("\t\tniq_tempeoafinallyexecutedagreementprovided is required but not true");
                return false;
            }
            tracing.Trace("\t\tniq_signedagreementcreatedandexecutedfromquot and niq_tempeoafinallyexecutedagreementprovided is filled and satisfied the conditions");
            return true;
        }

    }
}
