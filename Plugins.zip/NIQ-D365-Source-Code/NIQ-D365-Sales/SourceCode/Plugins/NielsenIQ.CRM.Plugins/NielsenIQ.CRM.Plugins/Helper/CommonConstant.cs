﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.Plugins.Helper
{
    public static class CommonConstant
    {

        // common plugin related constants 
        internal static string PREIMAGE => "PreImage";
        internal static string IMAGE => "Image";
        internal static string POSTIMAGE => "PostImage";

        internal static string CREATEOPERATION => "create";
        internal static string UPDATEOPERATION => "update";
        internal static string TARGET => "Target";
        //request related text values 
        internal static string REQUESTENTITY => "bpf_opportunity";
        internal static string REQUESTID => "bpf_opportunityid";


        // Messages/exception throws from plugins
        internal static string PREVENTFINISHSTAGE => "Request process flow cannot be updated";
        internal static string ERRORMESSAGEFAILURE => "Error occurred while processing the request. ";

        //enum values 
    
        internal enum Probability
        {
            PreProposal = 100000001,
            Negotiation = 100000005,
            Proposal = 100000003,
            ClosedWon = 100000006
        }
        internal enum ApprovalStatus
        {
            Pending = 100000001
        }
        public static class ConfigurationSettings
        {
            internal const string LogicalName = "niq_configurationsetting";
            internal const string Id = "niq_configurationsettingid";
            internal const string Name = "niq_name";
            internal const string To = "niq_to";
            internal const string CC = "niq_cc";
        }
        internal enum PLUGINSTAGE { PreValidation = 10, PreStage = 20, PostStage = 40 }

        internal enum FrequencyValues
        {
            [Description("Monthly (time based)")]
            MonthlyTimeBased = 100000008,

            [Description("Monthly")]
            Monthly = 100000000,

            [Description("Bimonthly")]
            Bimonthly = 100000001,

            [Description("Quarterly")]
            Quarterly = 100000002,

            [Description("Annual")]
            Annual = 100000005,

            [Description("3x Annually")]
            ThreeTimesAnnually = 100000003,

            [Description("2x / year")]
            TwiceYearly = 100000004,

            [Description("Monthly with Lag")]
            MonthlyWithLag = 100000006,

            [Description("Bimonthly with Lag")]
            BimonthlyWithLag = 100000007,

            [Description("Quarterly with Lag")]
            QuarterlyWithLag = 100000008,  // Note: Duplicate values should be handled correctly

            [Description("50/50")]
            FiftyFifty = 100000010,

            [Description("80/20")]
            EightyTwenty = 100000011,

            [Description("0/100")]
            ZeroOneHundred = 100000012,

            [Description("One Time")]
            OneTime = 100000013,

            [Description("Custom")]
            Custom = 100000009,

            [Description("No Lag")]
            NoLag = 100000000,  // Note: Duplicate values should be handled correctly

            [Description("1 Month Lag")]
            OneMonthLag = 100000001,  // Note: Duplicate values should be handled correctly

            [Description("2 Months Lag")]
            TwoMonthsLag = 100000002  // Note: Duplicate values should be handled correctly
        }
        //Refactoring is required, inside of hardcoding the E series.//DYNCRM-30772
        public enum SalesOrgCode
        {
            EATA, EBEA, EHRD, EBGA, EBGB, ERSA, ECZA, EDKA, EEEA, EFIA, EFRA, EDEA, EGRA, EHUA, EIEA, EITA, EJPA, ELVA, ELTA, EMKA, EMEA, ENLA, ENOA, EPLA, EPTA, EROA, EHRC, ESGA, ESKA, ESIA, EESA, ESEA, ECHA, EGBA
        }
    }

}
