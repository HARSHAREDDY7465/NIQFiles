﻿using System;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using System.Text.RegularExpressions;
using System.Net.NetworkInformation;
using System.Runtime.Remoting.Services;


namespace NielsenIQ.CRM.Plugins.Helper
{
    public class CommonHelper
    {
        public static void SetFrequencyforRateCateProduct(ITracingService tracingService, IOrganizationService service, Entity quoteProduct, OptionSetValue productType, bool isTimeBased, ref Entity updateQuoteProduct)
        {
            tracingService.Trace("func: SetFrequencyforRateCateProduct");
            string updateFrequencyString = quoteProduct.GetAttributeValue<string>("niq_ratecardupdatefrequency");
            //DYNCRM-22461
            if (updateFrequencyString == "Adhoc" && productType.Value == 2 && isTimeBased == false)
            {
                int updateFrequencyValue = CommonHelper.RetrieveOptionSetValue(service, updateFrequencyString);
                if (updateFrequencyValue != 0)
                {
                    tracingService.Trace("updateFrequencyValue:" + updateFrequencyValue);
                    updateQuoteProduct["niq_updatefrequency"] = new OptionSetValue(updateFrequencyValue);
                    updateQuoteProduct["niq_deliveryfrequency"] = new OptionSetValue(100000000);
                }
            }

            else if (updateFrequencyString != "Adhoc" && productType.Value == 2 && isTimeBased == false)
            {
                int updateFrequencyValue = CommonHelper.RetrieveOptionSetValue(service, updateFrequencyString);
                if (updateFrequencyValue != 0)
                {
                    tracingService.Trace("updateFrequencyValue:" + updateFrequencyValue);
                    updateQuoteProduct["niq_updatefrequency"] = new OptionSetValue(updateFrequencyValue);
                    updateQuoteProduct["niq_deliveryfrequency"] = new OptionSetValue(100000000);
                }
            }
            else if (updateFrequencyString != "Adhoc" && productType.Value == 1 && isTimeBased == false)
            {
                int updateFrequencyValue = CommonHelper.RetrieveOptionSetValue(service, updateFrequencyString);
                if (updateFrequencyValue != 0)
                {
                    tracingService.Trace("updateFrequencyValue:" + updateFrequencyValue);
                    updateQuoteProduct["niq_updatefrequency"] = new OptionSetValue(updateFrequencyValue);
                    updateQuoteProduct["niq_deliveryfrequency"] = new OptionSetValue(100000000);
                }
            }
            else if (!string.IsNullOrEmpty(updateFrequencyString) && productType.Value == 2 && isTimeBased == true)
            {
                int updateFrequencyValue = CommonHelper.RetrieveOptionSetValue(service, updateFrequencyString);
                if (updateFrequencyValue != 0)
                {
                    tracingService.Trace("updateFrequencyValue:" + updateFrequencyValue);
                    updateQuoteProduct["niq_updatefrequency"] = new OptionSetValue(updateFrequencyValue);
                    updateQuoteProduct["niq_deliveryfrequency"] = new OptionSetValue(100000008);
                }
            }

            else
            {
                int updateFrequencyValue = CommonHelper.RetrieveOptionSetValue(service, updateFrequencyString);
                if (updateFrequencyValue != 0)
                {
                    tracingService.Trace("updateFrequencyValue:" + updateFrequencyValue);
                    updateQuoteProduct["niq_updatefrequency"] = new OptionSetValue(updateFrequencyValue);
                    if (updateFrequencyValue == 100000010 || updateFrequencyValue == 100000011) //if the frequency is weeekly or biweeekly
                        updateQuoteProduct["niq_deliveryfrequency"] = new OptionSetValue(100000000);//set the value as montly
                    else
                        updateQuoteProduct["niq_deliveryfrequency"] = new OptionSetValue(updateFrequencyValue);
                }
            }
        }
        public static int GetDeliveryFrequency(Entity priceListItemEnt, ITracingService tracingService)
        {
            tracingService.Trace("Inside GetDeliveryFrequency");
            int deliveryFrequencyOSV = priceListItemEnt.Contains("niq_revenuefrequency") && priceListItemEnt["niq_revenuefrequency"] is OptionSetValue
                ? ((OptionSetValue)priceListItemEnt["niq_revenuefrequency"]).Value
                : -1;
            tracingService.Trace("deliveryFrequencyOSV" + deliveryFrequencyOSV);

            return deliveryFrequencyOSV;
        }
        public static int SetLagRevenueRecognition(Entity priceListItemEnt, ITracingService tracingService)
        {
            int lagRevenueRecognitionOSV = (priceListItemEnt.Contains("niq_lagrevenuerecognition") && priceListItemEnt["niq_lagrevenuerecognition"] is OptionSetValue)
                ? ((OptionSetValue)priceListItemEnt["niq_lagrevenuerecognition"]).Value
                : -1;

            return lagRevenueRecognitionOSV;
        }
        public static int GetUpdateFrequency(Entity priceListItemEnt, ITracingService tracingService)
        {
            int updateFrequencyOSV = priceListItemEnt.Contains("niq_updatefrequency") && priceListItemEnt["niq_updatefrequency"] is OptionSetValue
                ? ((OptionSetValue)priceListItemEnt["niq_updatefrequency"]).Value
                : -1;

            return updateFrequencyOSV;
        }

        public static int SetBillingFrequency(Entity priceListItemEnt, Entity updateQuoteProduct, ITracingService tracingService)
        {
            int billingFrequencyOSV = priceListItemEnt.Contains("niq_billingfrequency") && priceListItemEnt.Attributes["niq_billingfrequency"] != null
                ? priceListItemEnt.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value
                : -1;

            tracingService.Trace("niq_billingfrequency set to: " + billingFrequencyOSV);
            return billingFrequencyOSV;
        }
        public static int GetRevenueFrequencyValue(int revenueFrequency, Double termLength, ITracingService tracing)
        {
            int value = -1;
            int termLengthInt = (int)termLength;
            try
            {
                switch (revenueFrequency)
                {
                    case 100000001: // BI-Monthly
                        if (termLengthInt % 2 != 0)
                        {
                            value = 100000000; // Set Revenue Frequency as Monthly 
                        }
                        else
                        {
                            value = 100000001;
                        }
                        break;
                    case 100000006://Bi-Monthly- Monthly Rev Rec	
                        if (termLengthInt % 2 != 0)
                        {
                            value = 100000000; // Set Revenue Frequency as Monthly 
                        }
                        else
                        {
                            value = 100000006;
                        }
                        break;
                    case 100000002: // Quarterly
                        if (termLengthInt % 4 != 0)
                        {
                            value = 100000000;
                        }
                        else
                        {
                            value = 100000002;
                        }
                        break;
                    case 100000007://Quarterly- Monthly Rev Rec	
                        if (termLengthInt % 4 != 0)
                        {
                            value = 100000000;
                        }
                        else
                        {
                            value = 100000007;
                        }
                        break;
                    case 100000004: // Half year
                        if (termLengthInt % 6 != 0)
                        {
                            value = 100000000;
                        }
                        else
                        {
                            value = 100000004;
                        }
                        break;
                    case 100000003: // 3 * Annually
                        if (termLengthInt % 3 != 0)
                        {
                            value = 100000000;
                        }
                        else
                        {
                            value = 100000003;
                        }
                        break;
                    case 100000005: // Annually
                        if (termLengthInt % 12 != 0)
                        {
                            value = 100000000;
                        }
                        else
                        {
                            value = 100000005;
                        }
                        break;
                }
                return value;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }

        }
        public static int RetrieveOptionSetValue(IOrganizationService service, string rateCardUpdateFrequency)
        {
            int optionValue = 0;
            try
            {
                string cleanedString = RemoveSpecialCharactersAndLowercase(rateCardUpdateFrequency);
                switch (cleanedString)
                {

                    case "monthly":
                        optionValue = 100000000;
                        break;
                    case "weekly":
                        optionValue = 100000010;
                        break;
                    case "biweekly":
                        optionValue = 100000011;
                        break;
                    case "monthlytimebased":
                        optionValue = 100000008;
                        break;
                    case "bimonthly":
                        optionValue = 100000001;
                        break;
                    case "quarterly":
                        optionValue = 100000002;
                        break;
                    case "2xyear":
                    case "halfyearly":
                        optionValue = 100000004;
                        break;
                    case "3xannually":
                        optionValue = 100000003;
                        break;
                    case "annual":
                    case "annually":
                        optionValue = 100000005;
                        break;
                    case "adhoc":
                        optionValue = 100000009;
                        break;
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }

            return optionValue;
        }
        static string RemoveSpecialCharactersAndLowercase(string input)
        {
            // Use Regex to replace all non-alphanumeric characters with an empty string
            string result = Regex.Replace(input, "[^a-zA-Z0-9]", "");
            // Convert the resulting string to lowercase
            return result.ToLower();
        }
        public static Guid GetTemplateId(string accessTeamName, IOrganizationService service)
        {
            try
            {
                string fetchXml = @"<fetch top='1'>
                                          <entity name='teamtemplate'>
                                            <attribute name='teamtemplateid' />
                                            <filter>
                                             <condition attribute='teamtemplatename' operator='eq' value='{0}' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                fetchXml = String.Format(fetchXml, accessTeamName);
                var fetchAccessTeam = new FetchExpression(fetchXml);
                var result = service.RetrieveMultiple(fetchAccessTeam).Entities.FirstOrDefault();
                if (result != null && (Guid)result["teamtemplateid"] != Guid.Empty)
                {
                    return (Guid)result["teamtemplateid"];
                }
                else
                {
                    return Guid.Empty;
                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public static void AddUserToAccessTeam(Entity record, Guid userId, Guid accessTeamTemplateId, ITracingService tracing, IOrganizationService service)
        {
            try
            {


                tracing.Trace(" inside adduser func");
                AddUserToRecordTeamRequest addUser = new AddUserToRecordTeamRequest()
                {
                    Record = new EntityReference(record.LogicalName, record.Id),
                    SystemUserId = userId,
                    TeamTemplateId = accessTeamTemplateId

                };
                tracing.Trace(" adding user to access team......");
                service.Execute(addUser);
                tracing.Trace(" User added succesful");
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public static void RemoveUserToAccessTeam(Entity record, Guid userId, Guid accessTeamTemplateId, ITracingService tracing, IOrganizationService service)
        {
            try
            {


                tracing.Trace(" inside Removes User func");


                var query_And2_teamtype = 1;

                // Instantiate QueryExpression query
                var query = new QueryExpression("team");

                // Add columns to query.ColumnSet
                query.ColumnSet.AddColumns("name", "teamid", "teamtemplateid", "teamtype", "regardingobjectid");

                // Add filter query_And1 to query.Criteria
                var query_And1 = new FilterExpression();
                query.Criteria.AddFilter(query_And1);

                // Add conditions to query_And1
                query_And1.AddCondition("teamtemplateid", ConditionOperator.Equal, accessTeamTemplateId);

                // Add filter query_And2 to query.Criteria
                var query_And2 = new FilterExpression();
                query.Criteria.AddFilter(query_And2);

                // Add conditions to query_And2
                query_And2.AddCondition("teamtype", ConditionOperator.Equal, query_And2_teamtype);

                // Add filter query_And3 to query.Criteria
                var query_And3 = new FilterExpression();
                query.Criteria.AddFilter(query_And3);

                // Add conditions to query_And3
                query_And3.AddCondition("regardingobjectid", ConditionOperator.Equal, record.Id);

                // Add link-entity query_teammembership
                var query_teammembership = query.AddLink("teammembership", "teamid", "teamid");

                // Add link-entity query_teammembership_systemuser
                var query_teammembership_systemuser = query_teammembership.AddLink("systemuser", "systemuserid", "systemuserid");
                // Add conditions to query_teammembership_systemuser.LinkCriteria
                query_teammembership_systemuser.LinkCriteria.AddCondition("systemuserid", ConditionOperator.Equal, userId);
                EntityCollection teammembers = service.RetrieveMultiple(query);
                tracing.Trace("teammembers" + teammembers.Entities.Count);
                if (teammembers.Entities.Count == 0)
                {
                    tracing.Trace("User is NOT in this Access Team → skipping removal.");
                    return;

                }
                RemoveUserFromRecordTeamRequest removeUser = new RemoveUserFromRecordTeamRequest()
                {
                    Record = new EntityReference(record.LogicalName, record.Id),
                    SystemUserId = userId,
                    TeamTemplateId = accessTeamTemplateId

                };
                tracing.Trace(" removing user to access team......");
                service.Execute(removeUser);
                tracing.Trace(" User removed succesful");
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public static void updateOpportunityMandatoryCharValueAddedValidation(Guid quoteId, ITracingService tracing, IOrganizationService service)
        {
            string fetchXMLAggregateRecordCount = @"<fetch distinct='true' no-lock='true' aggregate='true'><entity name='niq_quoteproductcharacteristic'>" +
                                "<attribute name='niq_quoteproductcharacteristicid' alias='qpc_count' aggregate='count' /><filter type='and'>" +
                                "<condition attribute='niq_quoteid' operator='eq' value='" + quoteId + "' /><condition attribute='niq_mandatory' operator='eq' value='1' /></filter></entity></fetch>";
            string fetchXMLAggregateRecordCountWithValue = @"<fetch distinct='true' no-lock='true' aggregate='true'><entity name='niq_quoteproductcharacteristic'>" +
                "<attribute name='niq_quoteproductcharacteristicid' alias='qpc_count' aggregate='count' /><filter type='and'>" +
                "<condition attribute='niq_quoteid' operator='eq' value='" + quoteId + "' /><condition attribute='niq_mandatory' operator='eq' value='1' />" +
                "<condition attribute='niq_materialcharacteristicvalueid' operator='not-null' /></filter></entity></fetch>";
            string fetchQuoteDetailsExist = @"<fetch distinct='true' no-lock='true' top='1' ><entity name='quotedetail'>" +
                                "<attribute name='quotedetailid' /><filter type='and'>" +
                                "<condition attribute='quoteid' operator='eq' value='" + quoteId + "' /><condition attribute='productid' operator='not-null' /></filter></entity></fetch>";

            string fetchXMLOpportunity = "<fetch distinct='true' no-lock='true'><entity name='opportunity'>" +
                "<attribute name='opportunityid' /><attribute name='niq_mandatorycharvaluesadded' /><attribute name='niq_approvalstatus' />" +
                "<link-entity name='quote' to='opportunityid' from='opportunityid' link-type='inner' alias='aa'><filter type='and'>" +
                "<condition attribute='quoteid' operator='eq' value='" + quoteId + "' /></filter></link-entity></entity></fetch>";

            Entity opportunityRecord = ((EntityCollection)service.RetrieveMultiple(new FetchExpression(fetchXMLOpportunity))).Entities.FirstOrDefault();
            if (opportunityRecord != null && opportunityRecord != new Entity() && opportunityRecord.Id != null && opportunityRecord.Id != new Guid())
            {
                Entity oppUpdateRec = new Entity(opportunityRecord.LogicalName);
                oppUpdateRec.Id = opportunityRecord.Id;
                int? actualRecordCount = 0, valueRecordCount = 0;
                tracing.Trace("in Update opp Mandatory char added");
                EntityCollection quoteDetail = service.RetrieveMultiple(new FetchExpression(fetchQuoteDetailsExist));
                EntityCollection totalQPCCollection = service.RetrieveMultiple(new FetchExpression(fetchXMLAggregateRecordCount));
                EntityCollection totalQPCValueCollection = service.RetrieveMultiple(new FetchExpression(fetchXMLAggregateRecordCountWithValue));
                foreach (var c in totalQPCCollection.Entities)
                {
                    actualRecordCount = (int?)((AliasedValue)c["qpc_count"]).Value;
                    break;
                }
                foreach (var c in totalQPCValueCollection.Entities)
                {
                    valueRecordCount = (int?)((AliasedValue)c["qpc_count"]).Value;
                    break;
                }
                if (quoteDetail.Entities.Count > 0)
                {
                    tracing.Trace("in actual record count : " + actualRecordCount.ToString());
                    if (actualRecordCount == valueRecordCount && (!opportunityRecord.Contains("niq_mandatorycharvaluesadded") || !(bool)opportunityRecord["niq_mandatorycharvaluesadded"]))
                    {
                        oppUpdateRec["niq_mandatorycharvaluesadded"] = true;
                        service.Update(oppUpdateRec);
                    }
                    else if (actualRecordCount != valueRecordCount && (!opportunityRecord.Contains("niq_mandatorycharvaluesadded") || (bool)opportunityRecord["niq_mandatorycharvaluesadded"]))
                    {
                        oppUpdateRec["niq_mandatorycharvaluesadded"] = false;
                        service.Update(oppUpdateRec);
                        rejectOpportunityFAR(quoteId, tracing, service);
                    }
                }
                else if (!opportunityRecord.Contains("niq_mandatorycharvaluesadded") || (bool)opportunityRecord["niq_mandatorycharvaluesadded"])
                {
                    tracing.Trace("in clear Blok");
                    oppUpdateRec["niq_mandatorycharvaluesadded"] = false;
                    service.Update(oppUpdateRec);
                    rejectOpportunityFAR(quoteId, tracing, service);
                }
            }
        }

        public static void rejectOpportunityFAR(Guid quoteId, ITracingService tracing, IOrganizationService service)
        {
            try
            {
                string fetchXMLFAR = @"<fetch distinct='true' no-lock='true'><entity name='niq_financeapprovalrequests'>" +
                                    "<attribute name='niq_financeapprovalrequestsid' /><filter type='and'><condition attribute='statecode' operator='eq' value='0' />" +
                                    "<condition attribute='niq_approvalstatus' operator='eq' value='100000001' /></filter>" +
                                    "<link-entity name='opportunity' to='niq_relatedopportunity' from='opportunityid' link-type='inner' alias='aa'>" +
                                    "<link-entity name='quote' to='niq_mainquoteid' from='quoteid' link-type='inner' alias='ab'>" +
                                    "<filter type='and'><condition attribute='quoteid' operator='eq' value='" + quoteId + "' /></filter>" +
                                    "</link-entity></link-entity></entity></fetch>";
                tracing.Trace("in reject FAR blcok");
                Entity farRecord = ((EntityCollection)service.RetrieveMultiple(new FetchExpression(fetchXMLFAR))).Entities.FirstOrDefault();
                if (farRecord != null && farRecord != new Entity() && farRecord.Id != new Guid())
                {
                    tracing.Trace("in FAR block FAR Id : " + farRecord.Id.ToString());
                    Entity rejectFarRequest = new Entity(farRecord.LogicalName);
                    rejectFarRequest.Id = farRecord.Id;
                    rejectFarRequest["niq_approvalstatus"] = new OptionSetValue(100000003);
                    rejectFarRequest["niq_rejectionreason"] = new OptionSetValue(4);
                    rejectFarRequest["niq_comments"] = "Auto Rejection: Duee to Quote Product Characteristics Mandatory values not been selected, so please fill all mandatory values and resubmit for approval.";
                    service.Update(rejectFarRequest);
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        public static EntityCollection ReturnQueryResult(string entityLogicalName, ColumnSet columns, FilterExpression filterExpression, LinkEntity linkentity, ITracingService tracing, IOrganizationService service)
        {
            EntityCollection result = new EntityCollection();
            try
            {
                QueryExpression query = new QueryExpression(entityLogicalName);
                query.ColumnSet = columns;
                query.Distinct = true;
                query.Criteria.AddFilter(filterExpression);
                if (linkentity != null && linkentity.LinkEntities.Count() > 0)
                    query.LinkEntities.Add(linkentity);
                /*QueryExpressionToFetchXmlRequest conversionRequest = new QueryExpressionToFetchXmlRequest { Query = query };
                var conversionResponse = (QueryExpressionToFetchXmlResponse)service.Execute(conversionRequest);
                var fetchXml = conversionResponse.FetchXml;*/
                result = (EntityCollection)service.RetrieveMultiple(query);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(CommonConstant.ERRORMESSAGEFAILURE + ex);
            }
            return result;
        }
        public static Guid CreateFieldHistory(IOrganizationService service, ITracingService tracer, string entityDisplayName, string targetEntity, Guid targetId, Guid updatedUserId, string newvalue, string oldvalue, DateTime updatedDatetime, string fieldDisplayName, string fieldapiname, EntityReference regOwner)
        {
            Guid fieldHistoryGuid = Guid.Empty;
            try
            {
                tracer.Trace("CreateFieldHistory newvalue: " + newvalue.ToString());
                tracer.Trace("CreateFieldHistory oldvalue: " + oldvalue.ToString());
                tracer.Trace("CreateFieldHistory regReqOwner: " + regOwner.Id.ToString());
                Entity fieldHistory = new Entity("niq_fieldhistory");
                fieldHistory["niq_userwhoupdated"] = new EntityReference("systemuser", updatedUserId);
                fieldHistory["niq_newvalue"] = newvalue;
                fieldHistory["niq_oldvalue"] = oldvalue;
                fieldHistory["niq_datetimechanged"] = updatedDatetime;
                fieldHistory["subject"] = fieldDisplayName;
                fieldHistory["niq_fieldapiname"] = fieldapiname;
                fieldHistory["niq_tabletype"] = entityDisplayName;
                if (regOwner != new EntityReference() && regOwner.LogicalName == "systemuser" && regOwner.Id != Guid.Empty)
                {
                    fieldHistory["niq_regardingrequestowner"] = regOwner;
                }
                else if (regOwner == new EntityReference() || regOwner.Id == Guid.Empty)
                {
                    fieldHistory["niq_regardingrequestowner"] = new EntityReference("systemuser", updatedUserId);
                }
                if (targetId != null)
                {
                    fieldHistory["regardingobjectid"] = new EntityReference(targetEntity, targetId);
                }
                fieldHistoryGuid = service.Create(fieldHistory);
                Entity updateFH = new Entity(fieldHistory.LogicalName, fieldHistoryGuid);
                updateFH["statecode"] = new OptionSetValue(1);
                updateFH["statuscode"] = new OptionSetValue(2);
                service.Update(updateFH);
                tracer.Trace("Field History created successfully with Guid Id: " + fieldHistoryGuid.ToString());
            }
            catch (Exception ex)
            {
                tracer.Trace("Exception in CreateFieldHistory: " + ex.Message);
                throw new InvalidPluginExecutionException("ERRORMESSAGEFAILURE" + ex);
            }
            return fieldHistoryGuid;
        }

        public static (string oppAccessTeam, string quoteAccessTeam) GetConfigSettingsAccessTeamTemplate(IOrganizationService service, ITracingService tracing)
        {
            tracing.Trace("Entering GetConfigSettingsAccessTeamTemplate");
            string OppAccessTeam = string.Empty;
            string QuoteAccessTeam = string.Empty;
            try
            {
                Entity ConfigSettings = new Entity();
                var query1 = new QueryExpression("niq_configurationsetting")
                {
                    ColumnSet = new ColumnSet(true),
                    Criteria =
                            {
                                Conditions =
                                {
                                    new ConditionExpression("niq_name", ConditionOperator.In, new object[] { "Opportunity Sales Team Template", "Quote Teams" })
                                }
                            }
                };
                EntityCollection entitylist = service.RetrieveMultiple(query1);
                if (entitylist.Entities.Count > 0 && entitylist.Entities != null)
                {
                    tracing.Trace("GetConfigSettingsAccessTeamTemplate Count: " + entitylist.Entities.Count.ToString());

                    foreach (var item in entitylist.Entities)
                    {
                        if (item.Attributes["niq_name"].ToString() != null && item.Attributes["niq_name"].ToString() == "Opportunity Sales Team Template")
                        {
                            OppAccessTeam = item.Attributes["niq_to"].ToString();
                        }
                        else if (item.Attributes["niq_name"].ToString() != null && item.Attributes["niq_name"].ToString() == "Quote Teams")
                        {
                            QuoteAccessTeam = item.Attributes["niq_to"].ToString();
                        }
                    }
                }
                tracing.Trace("OppAccessTeam: " + OppAccessTeam);
                tracing.Trace("QuoteAccessTeam: " + QuoteAccessTeam);
            }
            catch (Exception ex)
            {
                tracing.Trace("Exception in GetConfigSettingsAccessTeamTemplate: " + ex.Message);
                return (OppAccessTeam, QuoteAccessTeam);
            }
            tracing.Trace("Exiting GetConfigSettingsAccessTeamTemplate");
            return (OppAccessTeam, QuoteAccessTeam);
        }

        public static EntityCollection ReturnMinMaxContractStartEnddate(IOrganizationService service, Guid retQuoteid, ITracingService tracingService)
        {
            EntityCollection result = new EntityCollection();
            try
            {
                string fetchDateQP = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' no-lock='true' distinct='true' aggregate='true' >
                                                 <entity name='quotedetail' >
                                                     <attribute name='niq_lineitemstartdate' alias='minDate' aggregate='min' />
                                                     <attribute name='niq_lineitemenddate' alias='maxDate' aggregate='max' />
                                                     <filter type='and' >
                                                         <condition attribute='quoteid' operator='eq' uiname='testchanges' uitype='quote' value='{0}' />
                                                         <condition attribute='quotedetailname' operator='ne' value='SAP Deferred Revenue reconciliation placeholder' />
                                                     </filter>
                                                 </entity>
                                             </fetch>";
                fetchDateQP = string.Format(fetchDateQP, retQuoteid);
                result = service.RetrieveMultiple(new FetchExpression(fetchDateQP));
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(CommonConstant.ERRORMESSAGEFAILURE + ex);
            }
            return result;
        }
        /// <summary>
        /// Check if opportunity created using automation process
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntityId"></param>
        /// <returns></returns>
        public static bool IsAutomatedOpportunity(IOrganizationService service, Guid targetEntityId)
        {
            try
            {
                string fetchOpp = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                          <entity name='opportunity'>
                            <attribute name='name' />
                            <order attribute='customerid' descending='false' />
                            <filter type='and'>
                              <condition attribute='niq_automatedopportunity' operator='eq' value='1' />
                            </filter>
                            <link-entity name='quote' from='quoteid' to='niq_mainquoteid' link-type='inner' alias='aa'>
                              <link-entity name='quotedetail' from='quoteid' to='quoteid' link-type='inner' alias='ab'>
                                <filter type='and'>
                                  <condition attribute='quotedetailid' operator='eq' value='{targetEntityId}' />
                                </filter>
                              </link-entity>
                            </link-entity>
                          </entity>
                        </fetch>";

                EntityCollection oppColl = service.RetrieveMultiple(new FetchExpression(fetchOpp));
                return oppColl.Entities.Count > 0;
            }  // Return true if opportunity is an Automated Opportunity
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(CommonConstant.ERRORMESSAGEFAILURE + ex);
            }

        }
        //31242 - CommonFunction For Retreiving Env Variable value
        public static string GetEnvVarDefaultValue(IOrganizationService service, string schemaName, ITracingService tracingService)
        {
            var eligibleBrands = "";
            var query = new QueryExpression("environmentvariabledefinition")
            {
                ColumnSet = new ColumnSet("defaultvalue"),
                Criteria =
                {
                    Conditions =
                    {
                        new ConditionExpression("schemaname", ConditionOperator.Equal, schemaName)
                    }
                }
            };

            var results = service.RetrieveMultiple(query);
            if (results.Entities.Count > 0)
            {
                eligibleBrands = results.Entities[0]["defaultvalue"].ToString();
                tracingService.Trace("eligibleBrands:- " + eligibleBrands.ToString());
            }
            return eligibleBrands;
        }
    }
}