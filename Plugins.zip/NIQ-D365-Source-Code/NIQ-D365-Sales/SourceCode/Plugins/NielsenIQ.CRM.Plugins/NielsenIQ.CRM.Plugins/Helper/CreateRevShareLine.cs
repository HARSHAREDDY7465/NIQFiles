﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using System.Threading;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.Runtime.Remoting.Services;
using System.Collections;

namespace NielsenIQ.CRM.Plugins.Helper
{
    public class CreateRevShareLine
    {
        private static readonly HttpClient client = new HttpClient();
        /// <summary>
        /// This is First Function which will create a Rev Share Line from Opportunity
        /// </summary>
        /// <param name="service"></param>
        /// <param name="opportunityId"></param>
        /// <param name="tracingService"></param>
        public static void ProcessToCreateRevShareLineFromHostOpportunity(IOrganizationService service, Entity hostOpp, EntityCollection childOppColl, ITracingService tracing, bool isChild)
        {
            string functionName = "ProcessToCreateRevShareLineFromHostOpportunity";
            tracing.Trace("Inside :" + functionName);
            var updateRequests = new List<Entity>();
            //Initialize array
            List<Entity> QuoteProductsToBeCreated = new List<Entity>(); //ICPOC-24340
            try
            {
                tracing.Trace("childOppColl Count:" + childOppColl.Entities.Count);
                foreach (Entity childOpp in childOppColl.Entities)
                {
                    Entity quoteProduct = null;
                    Entity quote = null;
                    //Validate every child record has Rev share line on Host opportunity
                    if (!HasRevShareLineOnHostOpp(service, childOpp, hostOpp, tracing))
                    {
                        tracing.Trace("No Ravshare Line Exist");
                        //  Check Opportunity has Quote and its Quote Product execuling Sap Deferred product
                        tracing.Trace("Child Opp Id : " + childOpp.Id);
                        quote = IsVaildOpportunity(service, childOpp.Id, tracing);
                        tracing.Trace("Quote Details : " + quote);
                        if (quote != null)
                        {
                            tracing.Trace("Host Opp is valid  to create Rev Share Line");
                            EntityCollection oppStartEndDate = CommonHelper.ReturnMinMaxContractStartEnddate(service, quote.Id, tracing);
                            quoteProduct = CreateRevShareLineRecord(quote, hostOpp, childOpp, service, tracing, isChild, oppStartEndDate);
                            //Add Quote product object to array
                            QuoteProductsToBeCreated.Add(quoteProduct); //ICPOC-24340

                        }
                    }
                    else
                    {
                        tracing.Trace("Update the Exiting RevShare line");
                        UpdateExtingRevShareLine(service, childOpp, tracing);
                        UpdatePricingApprovalOnMainQuote(hostOpp, service, tracing);
                    }
                }

                //IC-POC #24340_B
                if (QuoteProductsToBeCreated.Count > 0)
                {
                    tracing.Trace("Host:- " + hostOpp.Id.ToString());
                    Entity opportunity = service.Retrieve(hostOpp.LogicalName, hostOpp.Id, new ColumnSet("niq_revsharelinecreationstatus"));
                    //In Progress(610570000)
                    if (opportunity != null)
                    {
                        opportunity["niq_revsharelinecreationstatus"] = new OptionSetValue(610570000);
                        service.Update(opportunity);
                    }

                    // Convert list of entities to JSON using NewtonSoft
                    string json = JsonConvert.SerializeObject(QuoteProductsToBeCreated, Formatting.Indented);
                    string configName = "HTTPRequest_OpportunityCreateRevShareLines";

                    //Call HTTP flow “PA_Opportunity_CreateRevShareLines_HTTP” in async mode and pass this json string 
                    // Retrieve configuration settings to HTTPRequest_OpportunityCreateRevShareLines

                    var query = new QueryExpression("niq_configurationsetting")
                    {
                        ColumnSet = new ColumnSet("niq_to"),
                        Criteria = new FilterExpression
                        {
                            Conditions =
                            {
                                new ConditionExpression("niq_name", ConditionOperator.Equal, configName)
                            }
                        }
                    };

                    var results = service.RetrieveMultiple(query);
                    if (results.Entities.Count > 0)
                    {
                        var url = results.Entities[0]["niq_to"].ToString();
                        tracing.Trace("URL:- " + url.ToString());
                        var content = new StringContent(json, Encoding.UTF8, "application/json");
                        var response = client.PostAsync(url, content).Result;
                    }

                }
                //IC-POC #24340_E


            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
        }

        public static void UpdatePricingApprovalOnMainQuote(Entity hostOpp, IOrganizationService service, ITracingService tracing)
        {
            Entity quote = new Entity("quote");
            try
            {
                EntityReference hostQuote = hostOpp.Contains("niq_mainquoteid") && hostOpp.Attributes["niq_mainquoteid"] != null ? hostOpp.GetAttributeValue<EntityReference>("niq_mainquoteid") : null;
                if (hostQuote != null)
                {
                    quote.Id = hostQuote.Id;
                    tracing.Trace("Retrieving Pricing Approval from the quote :");

                    // Define the FetchXML query
                    string fetchXml = @"<fetch>
                                    <entity name='quote'>
                                    <attribute name='quoteid' />
                                    <attribute name='niq_discount' />
                                    <attribute name='niq_dealdeskapproval' />
                                    <filter type='and'>
                                    <condition attribute='quoteid' operator='eq' value='" + hostQuote.Id + @"' />
                                    <condition attribute='niq_dealdeskapproval' operator='not-null' />
                                    <condition attribute='niq_dealdeskapproval' operator='eq' value='100000002' />
                                    <condition attribute='niq_discount' operator='eq' value='0' />
                                    </filter>
                                    </entity>
                                    </fetch>";

                    // Execute the FetchXML query
                    EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetchXml));
                    tracing.Trace("result.Entities.Count:" + result.Entities.Count);
                    // Check if any records were returned
                    if (result.Entities.Count > 0)
                    {
                        tracing.Trace("Updating Pricing Approval:");
                        //No approval Required(100000003)
                        quote["niq_dealdeskapproval"] = new OptionSetValue(100000003);
                        service.Update(quote);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Update contract Start/End on host opportunity and Quote
        /// </summary>
        /// <param name="oppStartEndDate"></param>
        /// <param name="hostOpp"></param>
        /// <param name="tracing"></param>
        /// <param name="service"></param>
        private static void UpdateContractStartAndEndDatesOnHost(EntityCollection oppStartEndDate, Entity hostOpp, ITracingService tracingService, IOrganizationService service)
        {
            Entity opportunity = new Entity("opportunity");
            Entity quote = new Entity("quote");
            DateTime? earliestStartDateRevShare = null;
            DateTime? latestEndDateRevShare = null;
            tracingService.Trace("Inside UpdateContractStartAndEndDatesOnHost");
            try
            {
                if (hostOpp != null)
                {
                    opportunity.Id = hostOpp.Id;

                    if (oppStartEndDate != null && oppStartEndDate.Entities != null && oppStartEndDate.Entities.Count > 0)
                    {
                        Entity dateQP = oppStartEndDate.Entities.FirstOrDefault();

                        if (dateQP.Contains("minDate"))
                        {
                            earliestStartDateRevShare = (DateTime)dateQP.GetAttributeValue<AliasedValue>("minDate").Value;
                            tracingService.Trace("earliestStartDateRevShare:" + earliestStartDateRevShare);
                        }
                        if (dateQP.Contains("maxDate"))
                        {
                            latestEndDateRevShare = (DateTime)dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                            tracingService.Trace("latestEndDateRevShare:" + latestEndDateRevShare);
                        }
                        if (hostOpp.Contains("niq_contractstartdate") && hostOpp.Attributes["niq_contractstartdate"] != null)
                        {
                            DateTime? oppContractStartDate = hostOpp.Contains("niq_contractstartdate") && hostOpp.Attributes["niq_contractstartdate"] != null ? hostOpp.GetAttributeValue<DateTime?>("niq_contractstartdate") : null;
                            tracingService.Trace("Opportunity Contract Start Date :" + oppContractStartDate);
                            if (oppContractStartDate != null && oppContractStartDate != null && oppContractStartDate > earliestStartDateRevShare)
                            {
                                opportunity["niq_contractstartdate"] = earliestStartDateRevShare;
                                quote["niq_contractstartdate"] = earliestStartDateRevShare;
                            }
                        }
                        else
                        {
                            opportunity["niq_contractstartdate"] = earliestStartDateRevShare;
                            quote["niq_contractstartdate"] = earliestStartDateRevShare;
                        }
                        if (hostOpp.Contains("niq_contractenddate") && hostOpp.Attributes["niq_contractenddate"] != null)
                        {
                            DateTime? oppContractEndDate = hostOpp.Contains("niq_contractenddate") && hostOpp.Attributes["niq_contractenddate"] != null ? hostOpp.GetAttributeValue<DateTime?>("niq_contractenddate") : null;
                            tracingService.Trace("Opportunity Contract End Date :" + oppContractEndDate);
                            if (oppContractEndDate != null && latestEndDateRevShare != null && oppContractEndDate < latestEndDateRevShare)
                            {
                                opportunity["niq_contractenddate"] = latestEndDateRevShare;
                                quote["niq_contractenddate"] = latestEndDateRevShare;
                            }
                        }
                        else
                        {
                            opportunity["niq_contractenddate"] = latestEndDateRevShare;
                            quote["niq_contractenddate"] = latestEndDateRevShare;
                        }
                        if (hostOpp.Contains("niq_mainquoteid") && hostOpp.Attributes["niq_mainquoteid"] != null)
                        {
                            EntityReference hostQuote = hostOpp.GetAttributeValue<EntityReference>("niq_mainquoteid");
                            quote.Id = hostQuote.Id;
                            tracingService.Trace("Retrieving Pricing Approval from the quote :");
                            Entity quoteEntity = service.Retrieve(hostQuote.LogicalName, hostQuote.Id, new ColumnSet("niq_dealdeskapproval"));
                            //Pricing Approval(niq_dealdeskapproval)
                            OptionSetValue pricingApproval = quoteEntity.GetAttributeValue<OptionSetValue>("niq_dealdeskapproval");
                            tracingService.Trace("Pricing Approval:" + pricingApproval);
                            //If pricing approval is null then set "No Approval Required"
                            if (pricingApproval == null)
                            {
                                //No approval Required(100000003)
                                quote["niq_dealdeskapproval"] = new OptionSetValue(100000003);
                            }
                            service.Update(quote);
                        }
                        service.Update(opportunity);

                    }
                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// delete duplicate Rev Share line
        /// </summary>
        /// <param name="service"></param>
        /// <param name="childOpp"></param>
        /// <param name="hostOpp"></param>
        /// <param name="tracingService"></param>
        public static void DeleteDuplicateRevshareLine(IOrganizationService service, Entity childOpp, Entity hostOpp, ITracingService tracingService)
        {
            try
            {

                string functionName = "DeleteDuplicateRevshareLine";
                tracingService.Trace("Inside:" + functionName);

                //int milliseconds = 10000;
                //Thread.Sleep(milliseconds);

                //tracingService.Trace("awintg for 5sec");

                // Define the FetchXML query
                string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                          <entity name='quotedetail'>
                            <attribute name='quotedetailid' />
                            <order attribute='createdon' descending='true' />
                            <filter type='and'>
                              <condition attribute='niq_correspondingchildopportunity' operator='eq' value='{" + childOpp.Id + @"}' />
                            </filter>
                            <link-entity name='quote' from='quoteid' to='quoteid' link-type='inner' alias='ac'>
                              <link-entity name='opportunity' from='niq_mainquoteid' to='quoteid' link-type='inner' alias='ad'>
                                <filter type='and'>
                                  <condition attribute='opportunityid' operator='eq' value='{" + hostOpp.Id + @"}' />
                                </filter>
                                      </link-entity>
                                    </link-entity>
                                  </entity>
                                </fetch>";

                // Execute the FetchXML query
                EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetchXml));
                tracingService.Trace("result.Entities.Count:" + result.Entities.Count);
                // Check if any records were returned
                if (result.Entities.Count > 1)
                {
                    // Get the latest quotedetail (first one in descending order of 'createdon')
                    Entity latestQuotedetail = result.Entities.Cast<Entity>().FirstOrDefault();
                    tracingService.Trace("Record ignore:" + latestQuotedetail.Id);

                    // Delete the other quotedetail records
                    if (result.Entities.Count > 1)
                    {
                        // Skip the first record and delete the rest
                        for (int i = 1; i < result.Entities.Count; i++)
                        {
                            Guid recordId = result.Entities[i].Id;
                            tracingService.Trace("recordId to be deleted:" + recordId);
                            service.Delete("quotedetail", recordId);
                            tracingService.Trace("recordID deleted successfully");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Error Message:" + ex.Message);
            }
        }

        /// <summary>
        /// Below function will Get the exting Rev share line will update the same rev share line
        /// </summary>
        /// <param name="service"></param>
        /// <param name="childOpp"></param>
        /// <param name="tracing"></param>
        public static void UpdateExtingRevShareLine(IOrganizationService service, Entity childOpp, ITracingService tracing)
        {
            string functionName = "UpdateExtingRevShareLine";
            try
            {
                tracing.Trace("Inside function:" + functionName);
                //below method is return existing rev share line product of child opportunity
                Entity existingRevShare = RetrieveExistingRevShare(service, childOpp, tracing);

                if (existingRevShare != null)
                {
                    Entity opportunityDetails = IsVaildOpportunity(service, childOpp.Id, tracing);
                    //Also pass preimage in update commmon function bcz check if values are same then don't update the that fields
                    Entity updateRevShareLine = UpdateRevShareLineProduct(service, existingRevShare, tracing, opportunityDetails);

                    //update the rev share line
                    service.Update(updateRevShareLine);

                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
        }
        /// <summary>
        /// update the exting Rev Share line
        /// </summary>
        /// <param name="service"></param>
        /// <param name="existingRevShare"></param>
        /// <param name="tracingService"></param>
        /// <param name="opportunityDetails"></param>
        /// <returns></returns>
        public static Entity UpdateRevShareLineProduct(IOrganizationService service, Entity existingRevShare, ITracingService tracingService, Entity opportunityDetails)
        {
            string functionName = "UpdateRevShareLineProduct";
            Entity revShareLineQuoteProduct = new Entity("quotedetail");
            tracingService.Trace("Inside:" + functionName);
            try
            {
                revShareLineQuoteProduct.Id = existingRevShare.Id;
                decimal? discountPercentageQuote = opportunityDetails.Contains("niq_discount") && opportunityDetails.Attributes["niq_discount"] != null ? (decimal?)opportunityDetails.GetAttributeValue<decimal>("niq_discount") : null;
                decimal? discountPercentageRevShareLine = existingRevShare.Contains("niq_discountqp") && existingRevShare.Attributes["niq_discountqp"] != null ? (decimal?)existingRevShare.GetAttributeValue<decimal>("niq_discountqp") : null;

                if (discountPercentageQuote != null && (discountPercentageRevShareLine == null || discountPercentageRevShareLine != discountPercentageQuote))
                {
                    revShareLineQuoteProduct["niq_discountqp"] = discountPercentageQuote;
                }

                Money discountAmount = opportunityDetails.Contains("niq_discountamount") && opportunityDetails.Attributes["niq_discountamount"] != null ? opportunityDetails.GetAttributeValue<Money>("niq_discountamount") : null;
                tracingService.Trace("discountAmount of Quote" + discountAmount);

                decimal? discountAmountRevSharLine = existingRevShare.Contains("manualdiscountamount") && existingRevShare.Attributes["manualdiscountamount"] != null ? (decimal?)existingRevShare.GetAttributeValue<Money>("manualdiscountamount").Value : null;
                tracingService.Trace("discountAmount of RevShare Line" + discountAmountRevSharLine);

                if (discountAmount != null && (discountAmountRevSharLine == null || discountAmount.Value != discountAmountRevSharLine))
                {
                    revShareLineQuoteProduct["manualdiscountamount"] = new Money(discountAmount.Value);
                }

                Decimal? TotalAmount = opportunityDetails.Contains("niq_ratecardprice") && opportunityDetails.Attributes["niq_ratecardprice"] != null ? (decimal?)opportunityDetails.GetAttributeValue<Money>("niq_ratecardprice").Value : null;
                tracingService.Trace("Opportunity Total Amount :" + TotalAmount);

                Decimal? revShareAmount = existingRevShare.Contains("extendedamount") && existingRevShare.Attributes["extendedamount"] != null ? (decimal?)existingRevShare.GetAttributeValue<Money>("extendedamount").Value : null;
                tracingService.Trace("Rev share product extend Amount :" + revShareAmount);

                if (revShareAmount.HasValue && TotalAmount != revShareAmount)
                {
                    revShareLineQuoteProduct["priceperunit"] = TotalAmount;
                    revShareLineQuoteProduct["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                    revShareLineQuoteProduct["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                }
                //revShareLineQuoteProduct["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                //revShareLineQuoteProduct["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
            return revShareLineQuoteProduct;
        }

        /// <summary>
        /// Retrieve existing rev share line product
        /// </summary>
        /// <param name="service"></param>
        /// <param name="childOpportunityId"></param>
        /// <param name="tracingService"></param>
        /// <returns></returns>
        public static Entity RetrieveExistingRevShare(IOrganizationService service, Entity childOpportunityId, ITracingService tracingService)
        {
            string functionName = "RetriveExistingRevShare";
            tracingService.Trace("Inside :" + functionName);
            string fetchRevshareDetails = string.Empty;
            Entity revShareLineProduct = null;

            try
            {
                fetchRevshareDetails = @"<fetch>
                        <entity name='quotedetail'>
                        <attribute name='quotedetailid' />
                          <attribute name='manualdiscountamount' />
                        <attribute name='niq_billingenddate' />
                        <attribute name='niq_billingstartdate' />
                        <attribute name='niq_correspondingchildopportunity' />
                        <attribute name='niq_lineitemenddate' />
                        <attribute name='extendedamount' />
                          <attribute name='niq_discountqp' />
                         <attribute name='niq_type' />
                         <attribute name='niq_istimebased' />
                        <attribute name='productname' />
                        <attribute name='niq_lineitemstartdate' />
                        <attribute name='niq_termlength' />
                        <attribute name='niq_calculatedtermlength' />
                        <filter type='and'>
                            <condition attribute='niq_correspondingchildopportunity' operator='not-null' />
                            <condition attribute='niq_correspondingchildopportunity' operator='eq' value='" + childOpportunityId.Id + @"' />
                        </filter>
                    </entity>
                   </fetch>";

                EntityCollection revShareLineColl = service.RetrieveMultiple(new FetchExpression(fetchRevshareDetails));
                tracingService.Trace("quotedetailColl Count:" + revShareLineColl.Entities.Count);
                if (revShareLineColl.Entities.Count > 0)
                {
                    revShareLineProduct = revShareLineColl.Entities.Cast<Entity>().FirstOrDefault();
                    tracingService.Trace("quotedetailColl Count:" + revShareLineProduct.Id);
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
            return revShareLineProduct;
        }
        /// <summary>
        /// Update Rev share line lookup field  in all quote products of child Opportunity
        /// </summary>
        /// <param name="createdRecordIds"></param>
        /// <param name="childOppColl"></param>
        /// <param name="service"></param>
        /// <param name="tracing"></param>
        private static void UpdateChildQuoteProductWithRevShareLine(List<Guid> createdRecordIds, EntityCollection childOppColl, IOrganizationService service, ITracingService tracing)
        {
            string functionName = "UpdateChildQuoteProductWithRevShareLine";
            tracing.Trace("Inside :" + functionName);

            try
            {
                // Loop through all createdRecordIds
                foreach (var createdRecordId in createdRecordIds)
                {
                    // Loop through all child opportunities (childOppColl)
                    foreach (Entity childOpportunity in childOppColl.Entities)
                    {
                        // FetchXML query to retrieve quote products (quotedetail) for each createdRecordId and childOpportunity
                        string fetchXml = $@"
                                <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='quotedetail'>
                                    <attribute name='quotedetailid' />
                                    <order attribute='createdon' descending='true' />
                                    <link-entity name='quote' from='quoteid' to='quoteid' link-type='inner' alias='a_210b34fe9bf4ec11bb3d00224887f29c'>
                                      <attribute name='opportunityid' />
                                      <filter type='and'>
                                        <condition attribute='opportunityid' operator='eq' value='{childOpportunity.Id}' />
                                      </filter>
                                    </link-entity>
                                  </entity>
                                </fetch>";

                        // Execute the FetchXML query to retrieve related quote products (quotedetails)
                        EntityCollection quoteProducts = service.RetrieveMultiple(new FetchExpression(fetchXml));

                        // Iterate over the retrieved quote products (quotedetail entities)
                        foreach (var quoteProduct in quoteProducts.Entities)
                        {
                            //  tracing.Trace($"quoteProduct.Id: {quoteProduct.Id}");

                            // Create an update entity for each retrieved quote product
                            Entity updateEntity = new Entity("quotedetail")
                            {
                                Id = quoteProduct.Id
                            };


                            // Set the 'niq_revshareline' field to the desired value (EntityReference to the quotedetail)
                            updateEntity["niq_revshareline"] = new EntityReference("quotedetail", createdRecordId);

                            service.Update(updateEntity);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="quoteDetail"></param>
        /// <param name="opportunity"></param>
        /// <param name="service"></param>
        /// <param name="tracing"></param>
        /// <returns></returns>
        private static Entity CreateRevShareLineRecord(Entity quote, Entity hostOpportunity, Entity childOpportunity, IOrganizationService service, ITracingService tracing, bool isChild, EntityCollection oppStartEndDate)
        {
            //  Money? totalAmount = null;
            DateTime? earliestStartDate = null;
            DateTime? latestEndDate = null;
            EntityReference salesOrg = null;
            int billingfrequency = 0;
            bool isTimeBased = false;
            int productType = 0;
            Entity quoteProduct = new Entity("quotedetail");
            string functionName = "CreateObjectQuoteProduct";
            double monthDifference = 0;
            bool isCompatiable = false;
            tracing.Trace("Inside :" + functionName);

            decimal? discountPercentageQuote = quote.Contains("niq_discount") && quote.Attributes["niq_discount"] != null ? (decimal?)quote.GetAttributeValue<decimal>("niq_discount") : null;
            tracing.Trace("discountPercentageQuote of Quote" + discountPercentageQuote);
            if (discountPercentageQuote != null)
            {
                quoteProduct["niq_discountqp"] = discountPercentageQuote;
            }

            Money discountAmount = quote.Contains("niq_discountamount") && quote.Attributes["niq_discountamount"] != null ? quote.GetAttributeValue<Money>("niq_discountamount") : null;
            tracing.Trace("discountAmount of Quote" + discountAmount);

            if (discountAmount != null)
            {
                quoteProduct["manualdiscountamount"] = new Money(discountAmount.Value);
            }

            Decimal? TotalAmount = quote.Contains("niq_ratecardprice") && quote.Attributes["niq_ratecardprice"] != null ? (decimal?)quote.GetAttributeValue<Money>("niq_ratecardprice").Value : null;
            tracing.Trace("Opportunity Total Amount :" + TotalAmount);
            quoteProduct["priceperunit"] = new Money(TotalAmount.Value);
            tracing.Trace("priceperunit");
            quoteProduct["quantity"] = new decimal(1);
            tracing.Trace("quantity");
            quoteProduct["ispriceoverridden"] = true;
            tracing.Trace("ispriceoverridden");

            //IC-POC #24340_B
            if (oppStartEndDate != null)
            {
                tracing.Trace("oppStartEndDate is not null");
                if (oppStartEndDate.Entities != null)
                {
                    if (oppStartEndDate.Entities.Count > 0)
                    {
                        tracing.Trace("oppStartEndDate.Entities.Count=" + oppStartEndDate.Entities.Count);
                        Entity dateQP = oppStartEndDate.Entities.FirstOrDefault();
                        if (dateQP.Contains("minDate"))
                        {
                            if (dateQP.GetAttributeValue<AliasedValue>("minDate") != null)
                            {
                                earliestStartDate = (DateTime)dateQP.GetAttributeValue<AliasedValue>("minDate").Value;
                                quoteProduct["niq_lineitemstartdate"] = earliestStartDate;
                            }
                        }
                        if (dateQP.Contains("maxDate"))
                        {
                            if (dateQP.GetAttributeValue<AliasedValue>("maxDate") != null)
                            {
                                latestEndDate = (DateTime)dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                quoteProduct["niq_lineitemenddate"] = latestEndDate;
                            }
                        }
                    }
                }
            }

            if (earliestStartDate != null && latestEndDate != null)
            {
                if (CheckFirstDayMonth(earliestStartDate, tracing) && CheckLastDayMonth(latestEndDate, tracing))
                {
                    if (earliestStartDate.HasValue && latestEndDate.HasValue)
                    {
                        monthDifference = GetMonthDifference(earliestStartDate.Value, latestEndDate.Value, tracing);
                        tracing.Trace("monthDifference:" + monthDifference);
                        //DYNCRM-21595
                        //quoteProduct["niq_termlength"] = monthDifference;
                        quoteProduct["niq_calculatedtermlength"] = monthDifference;

                    }
                }
                else
                {
                    //isCompatiable = true;
                    monthDifference = 0;
                    //DYNCRM-21595
                    //quoteProduct["niq_termlength"] = monthDifference;
                    quoteProduct["niq_calculatedtermlength"] = monthDifference;
                    tracing.Trace("Month Difference: " + monthDifference);
                }
            }
            //IC-POC #24340_E

            //Update the Host quote
            tracing.Trace("Child Opp. " + isChild);
            if (isChild)
            {
                tracing.Trace("Host Opp GUID. " + hostOpportunity.Id);
                Entity getMainQuote = service.Retrieve(hostOpportunity.LogicalName, hostOpportunity.Id, new ColumnSet("niq_mainquoteid"));
                quoteProduct["quoteid"] = getMainQuote.Contains("niq_mainquoteid") && getMainQuote.Attributes["niq_mainquoteid"] != null ? getMainQuote.GetAttributeValue<EntityReference>("niq_mainquoteid") : null;
                //quoteProduct["quoteid"] = quoteDetail.Contains("niq_mainquoteid") && quoteDetail.Attributes["niq_mainquoteid"] != null ? quoteDetail.GetAttributeValue<EntityReference>("niq_mainquoteid") : null;
            }
            else
            {
                quoteProduct["quoteid"] = hostOpportunity.Contains("niq_mainquoteid") && hostOpportunity.Attributes["niq_mainquoteid"] != null ? hostOpportunity.GetAttributeValue<EntityReference>("niq_mainquoteid") : null;
            }
            salesOrg = childOpportunity.Contains("niq_salesorgid") && childOpportunity.GetAttributeValue<EntityReference>("niq_salesorgid") != null ? childOpportunity.GetAttributeValue<EntityReference>("niq_salesorgid") : null;
            if (childOpportunity.Contains("transactioncurrencyid"))
            {
                tracing.Trace("Currency : " + childOpportunity.GetAttributeValue<EntityReference>("transactioncurrencyid"));
                quoteProduct["transactioncurrencyid"] = childOpportunity.GetAttributeValue<EntityReference>("transactioncurrencyid");
            }

            //Update child Opportunity for which rev share line is getting created
            quoteProduct["niq_correspondingchildopportunity"] = new EntityReference(childOpportunity.LogicalName, childOpportunity.Id);
            quoteProduct["niq_isrevshareline"] = true;
            if (salesOrg != null)
            {
                Entity salesOrgEntity = service.Retrieve("niq_salesorg", salesOrg.Id, new ColumnSet("niq_salesorgcode"));
                if (salesOrgEntity != null && salesOrgEntity.Contains("niq_salesorgcode"))
                {
                    string salesOrgCode = salesOrgEntity.GetAttributeValue<string>("niq_salesorgcode");
                    quoteProduct["niq_remark"] = salesOrgCode;
                }

                Entity priceListItem = GetPriceListItems(salesOrg, hostOpportunity, service, tracing);

                if (priceListItem != null)
                {
                    quoteProduct["niq_pricelistitem"] = Convert.ToString(priceListItem.Id);
                    if (priceListItem.Contains("niq_updatefrequency") && priceListItem.GetAttributeValue<OptionSetValue>("niq_updatefrequency") != null)
                    {
                        tracing.Trace("niq_updatefrequency:" + priceListItem.GetAttributeValue<OptionSetValue>("niq_updatefrequency"));
                        quoteProduct["niq_updatefrequency"] = priceListItem.GetAttributeValue<OptionSetValue>("niq_updatefrequency");
                    }
                    if (priceListItem.Contains("niq_revenuefrequency") && priceListItem.GetAttributeValue<OptionSetValue>("niq_revenuefrequency") != null)
                    {
                        tracing.Trace("niq_revenuefrequnecy:" + priceListItem.GetAttributeValue<OptionSetValue>("niq_revenuefrequency").Value);
                        if (monthDifference > 0)
                        {
                            isCompatiable = GetCompatibility(monthDifference, priceListItem.GetAttributeValue<OptionSetValue>("niq_revenuefrequency").Value, "niq_revenuefrequnecy", tracing);
                            if (isCompatiable)
                            {
                                tracing.Trace("IsCompatible");
                                tracing.Trace("Revenue Frequency Value: " + priceListItem.GetAttributeValue<OptionSetValue>("niq_revenuefrequency").Value);
                                quoteProduct["niq_deliveryfrequency"] = priceListItem.GetAttributeValue<OptionSetValue>("niq_revenuefrequency");
                            }
                            else
                            {
                                tracing.Trace("Is Not Compatible");
                                //quoteProduct["niq_deliveryfrequency"] = priceListItem.GetAttributeValue<OptionSetValue>("niq_revenuefrequnecy");
                                quoteProduct["niq_deliveryfrequency"] = new OptionSetValue(100000000);
                            }
                            isCompatiable = false;
                        }
                        else
                        {
                            tracing.Trace("Month Difference is 0");
                            //quoteProduct["niq_deliveryfrequency"] = priceListItem.GetAttributeValue<OptionSetValue>("niq_revenuefrequnecy");
                            quoteProduct["niq_deliveryfrequency"] = new OptionSetValue(100000008);
                        }
                    }
                    if (priceListItem.Contains("niq_billingfrequency") && priceListItem.GetAttributeValue<OptionSetValue>("niq_billingfrequency") != null)
                    {
                        tracing.Trace("niq_billingfrequency:" + priceListItem.GetAttributeValue<OptionSetValue>("niq_billingfrequency"));
                        OptionSetValue billingFrequencyOptionSet = priceListItem.GetAttributeValue<OptionSetValue>("niq_billingfrequency");
                        billingfrequency = billingFrequencyOptionSet.Value;
                        if (monthDifference > 0)
                        {
                            isCompatiable = GetCompatibility(monthDifference, priceListItem.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value, "niq_billingfrequency", tracing);
                            if (isCompatiable)
                            {
                                tracing.Trace("IsCompatible");
                                quoteProduct["niq_billingfrequency"] = priceListItem.GetAttributeValue<OptionSetValue>("niq_billingfrequency");
                            }
                            else
                            {
                                tracing.Trace("Is Not Compatible");
                                //quoteProduct["niq_billingfrequency"] = priceListItem.GetAttributeValue<OptionSetValue>("niq_billingfrequency");
                                quoteProduct["niq_billingfrequency"] = new OptionSetValue(100000000);
                            }
                            isCompatiable = false;
                        }
                        else
                        {
                            tracing.Trace("Month Difference is 0");
                            //quoteProduct["niq_billingfrequency"] = priceListItem.GetAttributeValue<OptionSetValue>("niq_billingfrequency");
                            quoteProduct["niq_billingfrequency"] = new OptionSetValue(100000009);
                        }
                    }
                    if (billingfrequency != 0 && (billingfrequency == 100000010 || billingfrequency == 100000011 || billingfrequency == 100000012 || billingfrequency == 100000013))
                    {
                        quoteProduct["niq_billingstartdate"] = earliestStartDate;
                        quoteProduct["niq_billingenddate"] = latestEndDate;
                    }
                    if (priceListItem.Contains("niq_lagrevenuerecognition") && priceListItem.GetAttributeValue<OptionSetValue>("niq_lagrevenuerecognition") != null)
                    {
                        tracing.Trace("niq_lagrevenuerecognition:" + priceListItem.GetAttributeValue<OptionSetValue>("niq_lagrevenuerecognition"));
                        quoteProduct["niq_lagrevenuerecognition"] = priceListItem.GetAttributeValue<OptionSetValue>("niq_lagrevenuerecognition");
                    }
                    if (priceListItem.Contains("niq_producttype") && priceListItem.GetAttributeValue<OptionSetValue>("niq_producttype") != null)
                    {
                        tracing.Trace("niq_type:" + priceListItem.GetAttributeValue<OptionSetValue>("niq_producttype"));
                        OptionSetValue type = priceListItem.GetAttributeValue<OptionSetValue>("niq_producttype");
                        productType = type.Value;
                        //If Product is adhoc return 1(adhoc)
                        if (priceListItem.GetAttributeValue<OptionSetValue>("niq_producttype").Value == 100000001)
                        {
                            quoteProduct["niq_type"] = new OptionSetValue(1);
                        }
                        else //If Product is Periodic return 2(Periodic)
                        {
                            quoteProduct["niq_type"] = new OptionSetValue(2);
                        }
                    }

                    if (priceListItem.Contains("niq_istimebased"))
                    {
                        tracing.Trace("niq_istimebased:" + priceListItem.GetAttributeValue<bool>("niq_istimebased"));
                        isTimeBased = priceListItem.GetAttributeValue<bool>("niq_istimebased");
                        quoteProduct["niq_istimebased"] = isTimeBased;
                    }
                    if (productType == 100000001 && !isTimeBased)
                    {
                        quoteProduct["niq_calculatedtermlength"] = monthDifference;
                    }
                    if (priceListItem.Contains("productid"))
                    {
                        tracing.Trace("Product ID : " + priceListItem.GetAttributeValue<EntityReference>("productid").Id);
                        quoteProduct["productid"] = priceListItem.GetAttributeValue<EntityReference>("productid");
                        tracing.Trace("Product Description : " + priceListItem.GetAttributeValue<EntityReference>("productid").Name);
                        quoteProduct["description"] = priceListItem.GetAttributeValue<EntityReference>("productid").Name;
                    }
                    if (priceListItem.Contains("uomid"))
                    {
                        tracing.Trace("Unit Id: " + priceListItem.GetAttributeValue<EntityReference>("uomid").Id);
                        quoteProduct["uomid"] = priceListItem.GetAttributeValue<EntityReference>("uomid");
                    }
                    //if (priceListItem.Contains("transactioncurrencyid"))
                    //{
                    //    tracing.Trace("Currency : " + priceListItem.GetAttributeValue<EntityReference>("transactioncurrencyid"));
                    //    quoteProduct["transactioncurrencyid"] = priceListItem.GetAttributeValue<EntityReference>("transactioncurrencyid");
                    //}
                    quoteProduct["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                    quoteProduct["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                }
            }
            return quoteProduct;
        }

        /// <summary>
        /// Check Opportunity is Revenue share line deal
        /// </summary>
        /// <param name="service"></param>
        /// <param name="hostOpportunityId"></param>
        /// <returns></returns>
        /// 
        public static Entity IsValidHostOppWithData(IOrganizationService service, string fetchOpp, ITracingService tracingService)
        {
            string functionName = "IsRevsharelineOpportunty";
            tracingService.Trace("Inside :" + functionName);
            Entity opportunity = null;

            EntityCollection hostOppColl = service.RetrieveMultiple(new FetchExpression(fetchOpp));

            if (hostOppColl.Entities.Count > 0)
            {
                opportunity = hostOppColl.Entities.Cast<Entity>().FirstOrDefault();
            }

            return opportunity;
        }
        /// <summary>
        /// Check if opportunity is editable in closed in review stage
        /// </summary>
        /// <param name="service"></param>
        /// <param name="opportunityId"></param>
        /// <returns></returns>
        public static string IsOpportunityEditable(IOrganizationService service, Guid opportunityId, ITracingService tracingService)
        {
            string functionName = "IsOpportunityEditable";
            tracingService.Trace("Inside :" + functionName);

            string fetchChildOpp = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='opportunity'>
                                                <attribute name='name' />
                                                <attribute name='niq_stage' />
                                                <attribute name='totalamount' />
                                                <attribute name='opportunityid' />
                                                  <attribute name='niq_contractstartdate' />
                                                  <attribute name='niq_contractenddate' />
                                                  <attribute name='niq_mainquoteid' />
                                                  <attribute name='niq_automatedopportunity' />
                                                <order attribute='estimatedclosedate' descending='false' />
                                                <order attribute='customerid' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='niq_revenuesharedeal' operator='eq' value='1' />
                                                  <filter type='or'>
                                                    <condition attribute='niq_stage' operator='eq' value='Proposal' />
                                                    <condition attribute='niq_stage' operator='eq' value='Negotiation' />
                                                    <filter type='and'>
                                                      <condition attribute='niq_stage' operator='eq' value='Closed Won - In Review' />
                                                      <condition attribute='niq_approvalstatus' operator='in'>
                                                        <value>100000004</value>
                                                        <value>100000005</value>
                                                        <value>100000006</value>
                                                        <value>100000003</value>
                                                      </condition>
                                                    </filter>
                                                  </filter>
                                                  <condition attribute='opportunityid' operator='eq' value='{" + opportunityId + @"}' />
                                                </filter>
                                              </entity>
                                            </fetch>";
            return fetchChildOpp;
        }
        /// <summary>
        /// Get Child Opportunity of Host Opportunity
        /// </summary>
        /// <param name="service"></param>
        /// <param name="hostOpportunityId"></param>
        /// <returns></returns>
        public static EntityCollection GetChildOpportunity(IOrganizationService service, Entity hostOpportunityId, ITracingService tracingService, Entity ChildEntity)
        {
            EntityCollection childOppColl = null;
            string functionName = "GetChildOpportunity";
            tracingService.Trace("Inside :" + functionName);
            string fetchChildOpp = string.Empty;
            try
            {
                tracingService.Trace("Child Entity: " + ChildEntity);
                //If trigger not from the child it'll go into if part
                if (ChildEntity == null)
                {
                    tracingService.Trace("Host to child :");
                    fetchChildOpp = @" <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                      <entity name='opportunity'>
                        <attribute name='niq_salesorgid' />
                         <attribute name='transactioncurrencyid' />
                        <filter type='and'>
                          <condition attribute='niq_hostopportunity' operator='eq' value='" + hostOpportunityId.Id + @"' />
                          <condition attribute='statecode' operator='eq' value='0' />
                        </filter>
                      </entity>
                    </fetch>";
                }
                //If trigger from the child it'll go into else part
                else
                {
                    tracingService.Trace("Child Opp Attribute :");
                    fetchChildOpp = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                      <entity name='opportunity'>
                        <attribute name='name' />
                        <attribute name='niq_salesorgid' />
                        <attribute name='transactioncurrencyid' />
                        <order attribute='name' descending='false' />
                        <filter type='and'>
                          <condition attribute='opportunityid' operator='eq' value='{" + ChildEntity.Id + @"}' />
                              <condition attribute='statecode' operator='eq' value='0' />
                        </filter>
                      </entity>
                    </fetch>";
                }

                childOppColl = service.RetrieveMultiple(new FetchExpression(fetchChildOpp));
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
            tracingService.Trace("Execution Completed :" + functionName);
            return childOppColl;
        }
        /// <summary>
        /// Get Date difference in months
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public static int GetMonthDifference(DateTime revShareStartDate, DateTime revShareEndDate, ITracingService tracing)
        {
            int totalMonths = 0;

            // Check if startDate is the 1st day of the month and endDate is the last day of the month
            if (revShareStartDate.Day != 1 || revShareEndDate.Day != DateTime.DaysInMonth(revShareEndDate.Year, revShareEndDate.Month))
            {
                // Log the issue with tracing
                tracing.Trace($"Invalid date range: Start date is not the 1st day of the month or end date is not the last day. Start: {revShareStartDate}, End: {revShareEndDate}");
                return totalMonths; // Return 0 if the dates don't meet the criteria
            }

            // Calculate the difference in years and months if startDate is the 1st and endDate is the last of the month
            int yearDiff = revShareEndDate.Year - revShareStartDate.Year;
            int monthDiff = revShareEndDate.Month - revShareStartDate.Month;

            // Total month difference
            totalMonths = yearDiff * 12 + monthDiff + 1; // +1 to include the start month

            // Trace the result for debugging purposes
            tracing.Trace($"Month difference calculated: {totalMonths} months (from {revShareStartDate:yyyy-MM-dd} to {revShareEndDate:yyyy-MM-dd})");

            return totalMonths;
        }


        /// <summary>
        /// Get Price List item entity
        /// </summary>
        /// <param name="salesOrg"></param>
        /// <param name="service"></param>
        /// <param name="tracing"></param>
        /// <returns></returns>
        public static Entity GetPriceListItems(EntityReference salesOrg, Entity hostOppoId, IOrganizationService service, ITracingService tracing)
        {
            string functionName = "GetPriceListItems";
            tracing.Trace("Inside :" + functionName);

            if (salesOrg == null)
            {
                tracing.Trace("SalesOrg entity reference is null.");
                return null;
            }

            tracing.Trace($"SalesOrg entity reference is provided with ID: {salesOrg.Id}");
            //Fetch Host Opportunity Sales Org code
            string fetchHostSalesOrgCode = $@"
                                        <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                        <entity name='niq_salesorg'>
                                            <attribute name='niq_salesorgcode' />
                                            <order attribute='niq_name' descending='false' />
                                            <link-entity name='opportunity' from='niq_salesorgid' to='niq_salesorgid' link-type='inner' alias='ab'>
                                            <filter type='and'>
                                                <condition attribute='opportunityid' operator='eq' value='{hostOppoId.Id}' />
                                            </filter>
                                            </link-entity>
                                        </entity>
                                        </fetch>";

            var hostSalesOrg = service.RetrieveMultiple(new FetchExpression(fetchHostSalesOrgCode));
            //Check hostSalesOrg Entity available
            if (hostSalesOrg.Entities.Count > 0)
            {
                var firstRecord = hostSalesOrg.Entities[0];

                if (firstRecord.Contains("niq_salesorgcode"))
                {
                    var hostSalesOrgCode = firstRecord["niq_salesorgcode"] as string;

                    tracing.Trace($"Host Sales Org Code: {hostSalesOrgCode}");
                    Entity result = service.Retrieve("niq_salesorg", salesOrg.Id, new ColumnSet("niq_salesorgcode"));

                    if (result == null)
                    {
                        tracing.Trace($"No salesOrg found with ID: {salesOrg.Id}");
                        return null;
                    }
                    string salesOrgCode = result.GetAttributeValue<string>("niq_salesorgcode");
                    tracing.Trace($"SalesOrgCode retrieved: {salesOrgCode}");
                    //Check hostsalesorg code available in enum or not  if available then move to INTRPOCREVSHR otherwise move to INTERCO REV SHARE
                    if (Enum.TryParse(salesOrgCode, out CommonConstant.SalesOrgCode salesOrgEnum))
                    {

                        string concateVar = salesOrgCode + " INTRPOCREVSHR";
                        tracing.Trace($"Concatenated product number: {concateVar}");

                        string fetchXmlTemplatePoc = @"<fetch distinct='true' mapping='logical' no-lock='false'>
                              <entity name='productpricelevel'>
                                <attribute name='productidname'/>
                                <attribute name='productid'/>
                                <attribute name='uomid'/>
                                <attribute name='transactioncurrencyid'/>
                                <attribute name='productnumber'/>
                                <order attribute='productid' descending='false'/>
                                <attribute name='niq_glaccountname'/>
                                <attribute name='niq_createevidence'/>
                                <attribute name='niq_updatefrequency' />
                              <attribute name='niq_revenuefrequency' />
                              <attribute name='niq_producttype' />
                              <attribute name='niq_lagrevenuerecognition' />
                              <attribute name='niq_istimebased' />
                              <attribute name='niq_billingfrequency' />
                                <filter type='and'>
                                  <condition attribute='productnumber' operator='like' value='%" + concateVar + @"%'/>
                                </filter>
                                <link-entity alias='ppoc' name='pricelevel' from='pricelevelid' to='pricelevelid' link-type='inner'>
                                  <attribute name='niq_pricelistcode'/>
                                  <filter type='and'>
                                    <condition attribute='niq_pricelistcode' operator='like' value='%" + hostSalesOrgCode + @"%'/>
                                  </filter>
                                </link-entity>
                                <attribute name='productpricelevelid'/>
                                <attribute name='productnumber'/>
                              </entity>
                            </fetch>";

                        var priceItemListPoc = service.RetrieveMultiple(new FetchExpression(fetchXmlTemplatePoc));
                        tracing.Trace("priceItemListPoc Count:" + priceItemListPoc.Entities.Count);
                        //If combination of HostSalesOrg and ChildSalesorg+INTRPOCREVSHR available then true otherwise moves to INTERCO REV SHARE
                        if (priceItemListPoc.Entities.Count > 0)
                        {
                            Entity priceListEntity = priceItemListPoc.Entities[0]; // Get the first entity
                            tracing.Trace("PriceList item found, returning the first record.");

                            return priceListEntity;
                        }
                        else
                        {
                            //Get POC Items for INTERCO REV SHARE product
                            return GetIntercoRevSharPriceListItems(hostSalesOrgCode, service, tracing);
                        }
                    }
                    else
                    {
                        //Get POC Items for INTERCO REV SHARE product
                        return GetIntercoRevSharPriceListItems(hostSalesOrgCode, service, tracing);
                    }
                }
                else
                {
                    tracing.Trace("niq_salesorgcode not found in the result.");
                    return null;
                }
            }
            else
            {
                tracing.Trace("No records found for the given opportunity ID.");
                return null;
            }
        }

        private static Entity GetIntercoRevSharPriceListItems(string hostSalesOrgCode, IOrganizationService service, ITracingService tracing)
        {
            string functionName = "GetIntercoRevSharPriceListItems";
            tracing.Trace("Inside :" + functionName);
            string productNumberString = "INTERCO REV SHARE";
            string fetchXmlTemplateFallback = @"<fetch distinct='true' mapping='logical' savedqueryid='ab4877e9-6d01-4d28-84c3-be7564c1bb09' no-lock='false'>
                          <entity name='productpricelevel'>
                            <attribute name='productidname'/>
                            <attribute name='productid'/>
                            <attribute name='uomid'/>
                            <attribute name='transactioncurrencyid'/>
                            <attribute name='productnumber'/>
                            <attribute name='productid'/>
                            <order attribute='productid' descending='false'/>
                            <attribute name='niq_glaccountname'/>
                            <attribute name='niq_createevidence'/>
                            <attribute name='niq_updatefrequency' />
                            <attribute name='niq_revenuefrequency' />
                            <attribute name='niq_producttype' />
                            <attribute name='niq_lagrevenuerecognition' />
                            <attribute name='niq_istimebased' />
                            <attribute name='niq_billingfrequency' />
                            <filter type='and'>
                              <condition attribute='productnumber' operator='like' value='%" + productNumberString + @"%'/>
                            </filter>
                            <link-entity alias='pp' name='pricelevel' from='pricelevelid' to='pricelevelid' link-type='inner'>
                              <attribute name='niq_pricelistcode'/>
                              <filter type='and'>
                                <condition attribute='niq_pricelistcode' operator='like' value='%" + hostSalesOrgCode + @"%'/>
                              </filter>
                            </link-entity>
                            <attribute name='productpricelevelid'/>
                            <attribute name='productnumber'/>
                          </entity>
                        </fetch>";

            var priceListItem = service.RetrieveMultiple(new FetchExpression(fetchXmlTemplateFallback));

            if (priceListItem.Entities.Count > 0)
            {
                Entity priceListEntity = priceListItem.Entities[0];
                tracing.Trace("Fallback PriceList item found, returning the first record.");

                return priceListEntity;
            }
            else
            {
                tracing.Trace("No matching PriceList items found in both queries.");
                return null;
            }

        }

        /// <summary>
        /// Check Child Opportunity has Quote and its Quote Product execuling Sap Deferred product
        /// </summary>
        /// <param name="service"></param>
        /// <param name="opportunityId"></param>
        /// <returns></returns>
        public static Entity IsVaildOpportunity(IOrganizationService service, Guid opportunityId, ITracingService tracingService)
        {
            string functionName = "IsVaildOpportunity";
            tracingService.Trace("Inside :" + functionName);

            string fetchQuoteDetails = string.Empty;
            Entity quotedetail = null;
            try
            {
                fetchQuoteDetails = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                  <entity name='quote'>
                                   <attribute name='niq_discountamount' />
                                   <attribute name='opportunityid' />
                                   <attribute name='totalamount' />
                                   <attribute name='niq_contractstartdate' />
                                     <attribute name='niq_ratecardprice' />
                                   <attribute name='niq_contractenddate' />
                                    <attribute name='niq_discount' />
                                   <attribute name='quoteid' />              
                                    <order attribute='name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='niq_contractenddate' operator='not-null' />
                                      <condition attribute='niq_contractstartdate' operator='not-null' />
                                    </filter>
                                    <link-entity name='opportunity' from='niq_mainquoteid' to='quoteid' link-type='inner' alias='af'>
                                      <filter type='and'>
                                        <condition attribute='opportunityid' operator='eq' uitype='opportunity' value='{" + opportunityId + @"}' />
                                      </filter>
                                    </link-entity>
                                    <link-entity name='quotedetail' from='quoteid' to='quoteid' link-type='inner' alias='ag'>
                                      <filter type='and'>
                                          <condition attribute='quotedetailname' operator='ne' value='SAP Deferred Revenue reconciliation placeholder' />
                                      </filter>
                                    </link-entity>
                                  </entity>
                                </fetch>";


                EntityCollection quotedetailColl = service.RetrieveMultiple(new FetchExpression(fetchQuoteDetails));
                tracingService.Trace("quotedetailColl Count:" + quotedetailColl.Entities.Count);
                if (quotedetailColl.Entities.Count > 0)
                {
                    quotedetail = quotedetailColl.Entities.Cast<Entity>().FirstOrDefault();
                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
            return quotedetail;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static bool CheckFirstDayMonth(DateTime? date, ITracingService tracingService)
        {
            string functionName = "CheckFirstDayMonth";
            tracingService.Trace("Inside :" + functionName);

            // Check if the date is null
            if (!date.HasValue)
            {
                return false; // If the date is null, return false (not the first day)
            }
            tracingService.Trace("Day:" + date.Value.Day);
            // Check if the date is the first day of the month
            return date.Value.Day == 1;
        }
        public static bool CheckLastDayMonth(DateTime? date, ITracingService tracingService)
        {
            string functionName = "CheckLastDayMonth";
            tracingService.Trace("Inside :" + functionName);

            // Check if the date is null
            if (!date.HasValue)
            {
                return false; // If the date is null, return false (it cannot be the last day)
            }

            // Extract the value of the nullable DateTime
            DateTime nonNullDate = date.Value;
            tracingService.Trace("nonNullDate:" + nonNullDate);

            // Calculate the last day of the month for the given date
            int daysInMonth = DateTime.DaysInMonth(nonNullDate.Year, nonNullDate.Month);
            tracingService.Trace("daysInMonth:" + daysInMonth);

            // Check if the date is the last day of the month
            return nonNullDate.Day == daysInMonth;
        }

        public static bool HasRevShareLineOnHostOpp(IOrganizationService service, Entity childOpp, Entity hostOpp, ITracingService tracingService)
        {
            string functionName = "HasRevShareLineOnHostOpp";
            tracingService.Trace("Inside:" + functionName);
            bool isValid = false;
            // Define the FetchXML query
            string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                          <entity name='quotedetail'>
                            <attribute name='productdescription' />
                            <order attribute='niq_brandid' descending='false' />
                            <filter type='and'>
                              <condition attribute='niq_correspondingchildopportunity' operator='eq' value='{" + childOpp.Id + @"}' />
                            </filter>
                            <link-entity name='quote' from='quoteid' to='quoteid' link-type='inner' alias='ac'>
                              <link-entity name='opportunity' from='niq_mainquoteid' to='quoteid' link-type='inner' alias='ad'>
                                <filter type='and'>
                                  <condition attribute='opportunityid' operator='eq' value='{" + hostOpp.Id + @"}' />
                                </filter>
                                      </link-entity>
                                    </link-entity>
                                  </entity>
                                </fetch>";

            // Execute the FetchXML query
            EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetchXml));
            tracingService.Trace("result.Entities.Count:" + result.Entities.Count);
            // Check if any records were returned
            if (result.Entities.Count > 0)
            {
                isValid = true;
            }
            return isValid;

        }
        public static bool GetCompatibility(double termLength, int frequencyValue, string frequencyType, ITracingService tracingService)
        {
            tracingService.Trace("InSide GetCompatibility.");
            switch (frequencyValue)
            {
                case 100000000: // Monthly
                    tracingService.Trace("GetCompatibility : Monthly");
                    return frequencyType == "niq_revenuefrequency" ? (termLength % 1 == 0) : (termLength % 1 == 0);

                case 100000001: // Bi-Monthly
                    tracingService.Trace("GetCompatibility : Bi-Monthly");
                    return (termLength % 2 == 0);

                case 100000002: // Quarterly
                    tracingService.Trace("GetCompatibility : Quarterly");
                    return (termLength % 3 == 0);

                case 100000003: // 3 * Annually or Half-Yearly (depending on type)
                    tracingService.Trace("GetCompatibility : Annually or Half-Yearly");
                    return frequencyType == "niq_revenuefrequency" ? (termLength % 4 == 0) : (termLength % 6 == 0);

                case 100000004: // Half-Yearly or 3 * Annually (depending on type)
                    tracingService.Trace("GetCompatibility : Half-Yearly or 3 * Annually");
                    return frequencyType == "niq_revenuefrequency" ? (termLength % 6 == 0) : (termLength % 4 == 0);

                case 100000005: // Annually
                    tracingService.Trace("GetCompatibility : Annually");
                    return (termLength % 12 == 0);

                default:
                    return true;
            }
        }

        /// <summary>
        /// Get Rev Share Line
        /// </summary>
        /// <param name="service"></param>
        /// <param name="childOpp"></param>
        /// <param name="hostOpp"></param>
        /// <param name="tracingService"></param>
        /// <returns></returns>
        public static Entity GetRevShareLineOfHostOpp(IOrganizationService service, Entity childOpp, Entity hostOpp, ITracingService tracingService)
        {
            string functionName = "GetRevShareLineOfHostOpp";
            tracingService.Trace("Inside:" + functionName);
            Entity quoteDetails = null;
            // Define the FetchXML query
            string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                          <entity name='quotedetail'>
                            <filter type='and'>
                              <condition attribute='niq_correspondingchildopportunity' operator='eq' value='{" + childOpp.Id + @"}' />
                            </filter>
                            <link-entity name='quote' from='quoteid' to='quoteid' link-type='inner' alias='ac'>
                              <link-entity name='opportunity' from='niq_mainquoteid' to='quoteid' link-type='inner' alias='ad'>
                                <filter type='and'>
                                  <condition attribute='opportunityid' operator='eq' value='{" + hostOpp.Id + @"}' />
                                </filter>
                                      </link-entity>
                                    </link-entity>
                                  </entity>
                                </fetch>";

            // Execute the FetchXML query
            EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetchXml));
            tracingService.Trace("result.Entities.Count:" + result.Entities.Count);
            // Check if any records were returned
            if (result.Entities.Count > 0)
            {
                quoteDetails = result.Entities.Cast<Entity>().FirstOrDefault();
            }
            return quoteDetails;

        }
        /// <summary>
        /// Get Opportunity of quote detaill
        /// </summary>
        /// <param name="service"></param>
        /// <param name="quoteDetail"></param>
        /// <param name="tracingService"></param>
        /// <returns></returns>
        public static Entity GetOppOfQuoteDetail(IOrganizationService service, Entity quoteDetail, ITracingService tracingService)
        {
            string functionName = "GetOppOfQuoteDetail";
            tracingService.Trace("Inside:" + functionName);
            Entity opportunity = null;
            // Define the FetchXML query
            string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >
                            <entity name='opportunity' >
                                <attribute name='niq_hostopportunity' />
                                 <attribute name='opportunityid' />
                                <filter type='and' >
                                    <condition attribute='niq_hostopportunity' operator='not-null' />
                                </filter>
                                <link-entity name='quote' from='opportunityid' to='opportunityid' link-type='inner' alias='aq' >
                                    <link-entity name='quotedetail' from='quoteid' to='quoteid' link-type='inner' alias='ar' >
                                        <filter type='and' >
                                            <condition attribute='quotedetailid' operator='eq' value='" + quoteDetail.Id + @"' />
                                        </filter>
                                    </link-entity>
                                </link-entity>
                            </entity>
                        </fetch>";

            // Execute the FetchXML query
            EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetchXml));
            tracingService.Trace("result.Entities.Count:" + result.Entities.Count);
            // Check if any records were returned
            if (result.Entities.Count > 0)
            {
                opportunity = result.Entities.Cast<Entity>().FirstOrDefault();
            }
            return opportunity;
        }
        /// <summary>
        /// Get Opportunity of child Quote 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="quote"></param>
        /// <param name="tracingService"></param>
        /// <returns></returns>
        public static Entity GetOppOfQuote(IOrganizationService service, Entity quote, ITracingService tracingService)
        {
            string functionName = "GetOppOfQuote";
            tracingService.Trace("Inside:" + functionName);
            Entity opportunity = null;
            // Define the FetchXML query
            string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                      <entity name='opportunity'>
                        <attribute name='opportunityid' />
                         <attribute name='niq_hostopportunity' />
                        <filter type='and'>
                          <condition attribute='niq_hostopportunity' operator='not-null' />
                          <condition attribute='niq_mainquoteid' operator='eq' value='{" + quote.Id + @"}' />
                        </filter>
                      </entity>
                    </fetch>";

            // Execute the FetchXML query
            EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetchXml));
            tracingService.Trace("result.Entities.Count:" + result.Entities.Count);
            // Check if any records were returned
            if (result.Entities.Count > 0)
            {
                opportunity = result.Entities.Cast<Entity>().FirstOrDefault();
            }
            return opportunity;
        }

        /// <summary>
        /// Get Rev Share Line of Host Opp
        /// </summary>
        /// <param name="service"></param>
        /// <param name="childOpp"></param>
        /// <param name="hostOpp"></param>
        /// <param name="tracingService"></param>
        /// <returns></returns>
        public static EntityCollection GetAllRevShareLineOfHostOppOnly(IOrganizationService service, Guid quoteId, ITracingService tracingService)
        {
            string functionName = "GetAllRevShareLineOfHostOppOnly";
            tracingService.Trace("Inside:" + functionName);
            EntityCollection quoteDetails = null;
            // Define the FetchXML query
            string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                  <entity name='quotedetail'>
                    <attribute name='quotedetailid' />
                    <filter type='and'>
                      <condition attribute='niq_correspondingchildopportunity' operator='not-null' />
                    </filter>
                    <link-entity name='quote' from='quoteid' to='quoteid' link-type='inner' alias='ac'>
                      <filter type='and'>
                        <condition attribute='quoteid' operator='eq' value='{" + quoteId + @"}' />
                      </filter>
                    </link-entity>
                  </entity>
                </fetch>";
            // Execute the FetchXML query
            EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetchXml));
            tracingService.Trace("result.Entities.Count:" + result.Entities.Count);
            // Check if any records were returned
            if (result.Entities.Count > 0)
            {
                quoteDetails = result;
            }
            return quoteDetails;

        }
    }
}