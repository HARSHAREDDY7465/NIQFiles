﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;
using System.Collections.Generic;
using System.Collections;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_ExperlogixFlag_ValidateData : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                int quoteProductCount = 0;
                int qpcount = 0;
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(null);
                DateTime? postContractStarteDate = null;
                DateTime? postContractEndDate = null;
                Entity postImage = null;

                if (context.Depth > 1)
                {
                    return;

                }
                if (context.PostEntityImages.Contains("PostImage"))
                {
                    postImage = context.PostEntityImages["PostImage"];

                    postContractStarteDate = postImage.Contains("niq_contractstartdate") && postImage.Attributes["niq_contractstartdate"] != null ? (DateTime?)postImage.Attributes["niq_contractstartdate"] : null;
                    tracing.Trace("Post Image Of contract start date:" + postContractStarteDate);

                    postContractEndDate = postImage.Contains("niq_contractenddate") && postImage.Attributes["niq_contractenddate"] != null ? (DateTime?)postImage.Attributes["niq_contractenddate"] : null;
                    tracing.Trace("Post Image Of contract end date:" + postContractEndDate);
                }
                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity entityObj = (Entity)context.InputParameters["Target"];
                    if (entityObj != null && entityObj.Id != Guid.Empty && entityObj.LogicalName.ToLower() == "quote" && entityObj.Contains("niq_expvalidation") && entityObj.GetAttributeValue<bool>("niq_expvalidation"))
                    {
                        tracing.Trace("quote id" + entityObj.Id);
                        Entity retQuote = service.Retrieve("quote", entityObj.Id, new ColumnSet("niq_salesorgid", "opportunityid", "niq_mainquote", "niq_quoteheaderdetailsapproval", "niq_overalldealdeskapproval", "niq_fundusageapproval"));
                        Entity opportunity = service.Retrieve(retQuote.GetAttributeValue<EntityReference>("opportunityid").LogicalName, retQuote.GetAttributeValue<EntityReference>("opportunityid").Id, new ColumnSet("niq_opportunitytype", "niq_triggerbidtoolintegration"));
                        Entity salesOrg = service.Retrieve(retQuote.GetAttributeValue<EntityReference>("niq_salesorgid").LogicalName, retQuote.GetAttributeValue<EntityReference>("niq_salesorgid").Id, new ColumnSet("niq_pilotmarket"));
                        if (retQuote != null && retQuote.Id != Guid.Empty && retQuote.Contains("niq_salesorgid"))
                        {
                            tracing.Trace("ret quote" + retQuote.Id);
                            bool update = false;
                            Entity updQuote = new Entity(retQuote.LogicalName, retQuote.Id);
                            Entity updOppo = new Entity(retQuote.GetAttributeValue<EntityReference>("opportunityid").LogicalName, retQuote.GetAttributeValue<EntityReference>("opportunityid").Id);

                            string fetchDateQP = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' aggregate='true' >
                                                        <entity name='quotedetail' >
                                                            <attribute name='niq_lineitemstartdate' alias='minDate' aggregate='min' />
                                                            <attribute name='niq_lineitemenddate' alias='maxDate' aggregate='max' />
                                                            <filter type='and' >
                                                                <condition attribute='quoteid' operator='eq' uiname='testchanges' uitype='quote' value='{0}' />
                                                                <condition attribute='quotedetailname' operator='ne' value='SAP Deferred Revenue reconciliation placeholder' />
                                                            </filter>
                                                        </entity>
                                                    </fetch>";
                            fetchDateQP = string.Format(fetchDateQP, retQuote.Id);
                            var resDateQP = service.RetrieveMultiple(new FetchExpression(fetchDateQP));
                            if (resDateQP != null && resDateQP.Entities != null && resDateQP.Entities.Count > 0)
                            {
                                Entity dateQP = resDateQP.Entities.FirstOrDefault();
                                if (dateQP.Contains("minDate") && dateQP.GetAttributeValue<AliasedValue>("minDate").Value != null)
                                {
                                    DateTime mindate = (DateTime)dateQP.GetAttributeValue<AliasedValue>("minDate")?.Value;
                                    if (postContractStarteDate != null && postContractStarteDate > mindate)
                                    {
                                        updQuote["niq_contractstartdate"] = mindate;
                                        updOppo["niq_contractstartdate"] = mindate;
                                        update = true;
                                    }
                                }
                                if (dateQP.Contains("maxDate") && dateQP.GetAttributeValue<AliasedValue>("maxDate").Value != null)
                                {
                                    DateTime maxDate = (DateTime)dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                    if (postContractEndDate != null && postContractEndDate < maxDate)
                                    {
                                        updQuote["niq_contractenddate"] = dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                        updOppo["niq_contractenddate"] = dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                        update = true;
                                    }
                                }
                                string fetchQPPlaceholder = @"<fetch top='1' version='1.0' output-format='xml-platform' mapping='logical' distinct='true' no-lock='true' >
                                                                <entity name='quotedetail' >
                                                                    <attribute name='quotedetailid' />
                                                                    <filter type='and' >
                                                                        <condition attribute='quotedetailname' operator='eq' value='Place Holder Product' />
                                                                        <condition attribute='productdescription' operator='eq' value='Place Holder Product' />
                                                                        <condition attribute='isproductoverridden' operator='eq' value='1' />
                                                                        <condition attribute='quoteid' operator='eq' uitype='quote' value='{0}' />
                                                                    </filter>
                                                                </entity>
                                                            </fetch>";
                                fetchQPPlaceholder = string.Format(fetchQPPlaceholder, retQuote.Id);
                                var quoteProducts = service.RetrieveMultiple(new FetchExpression(fetchQPPlaceholder));
                                if (quoteProducts != null && quoteProducts.Entities != null && quoteProducts.Entities.Count > 0)
                                {
                                    tracing.Trace("Found Placeholder Product ");
                                    updQuote["niq_overalldealdeskapproval"] = new OptionSetValue(1);
                                }

                            }
                            else
                            {
                                update = true;
                                updQuote["niq_contractstartdate"] = null;
                                updOppo["niq_contractstartdate"] = null;

                                updQuote["niq_contractenddate"] = null;
                                updOppo["niq_contractenddate"] = null;



                            }

                            //decimal rateCardPrice = 0;
                            //decimal discountPer = 0;
                            //decimal discountAmount = 0;
                            ////Entity UpdQuote = new Entity(retQuote.LogicalName, retQuote.Id);
                            //string fetchQP = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>
                            //                  <entity name='quotedetail'>
                            //                    <attribute name='manualdiscountamount' />
                            //                    <attribute name='quotedetailname' />
                            //                    <attribute name='quotedetailid' />
                            //                    <attribute name='niq_discountqp' />
                            //                    <attribute name='baseamount' />
                            //                    <order attribute='quotedetailname' descending='false' />
                            //                    <filter type='and'>
                            //                      <condition attribute='quoteid' operator='eq' uitype='quote' value='{0}' />
                            //                      <condition attribute='baseamount' operator='not-null' />
                            //                    </filter>
                            //                  </entity>
                            //                </fetch>";
                            //fetchQP = string.Format(fetchQP, retQuote.Id);
                            //var resultQP = service.RetrieveMultiple(new FetchExpression(fetchQP));
                            //if (resultQP != null && resultQP.Entities != null && resultQP.Entities.Count > 0)
                            //{

                            //    bool isUpdate = false;
                            //    foreach (Entity quoteP in resultQP.Entities)
                            //    {
                            //        if (quoteP.Attributes.Contains("baseamount"))
                            //        {
                            //            rateCardPrice += quoteP.GetAttributeValue<Money>("baseamount").Value;
                            //            isUpdate = true;
                            //            tracing.Trace("ratecardprice" + rateCardPrice);

                            //        }
                            //        if (quoteP.Attributes.Contains("manualdiscountamount"))
                            //        {
                            //            discountAmount += quoteP.GetAttributeValue<Money>("manualdiscountamount").Value;
                            //            isUpdate = true;
                            //            tracing.Trace("discountAmount" + discountAmount);

                            //        }
                            //        if (quoteP.Attributes.Contains("niq_discountqp") && (quoteP.GetAttributeValue<decimal>("niq_discountqp") != (decimal)0))
                            //        {
                            //            discountPer += quoteP.GetAttributeValue<decimal>("niq_discountqp");
                            //            isUpdate = true;
                            //            tracing.Trace("discountPer" + discountPer);
                            //        }

                            //    }
                            //    if (isUpdate)
                            //    {
                            //        updQuote["niq_discountamount"] = new Money((decimal)discountAmount);
                            //        updQuote["niq_ratecardprice"] = new Money((decimal)rateCardPrice);
                            //        tracing.Trace("discountamount" + (decimal)discountAmount);
                            //        tracing.Trace("ratecard" + (decimal)rateCardPrice);
                            //        if (rateCardPrice != 0)
                            //        {
                            //            updQuote["niq_discount"] = (decimal)((discountAmount / rateCardPrice) * 100);
                            //            tracing.Trace("niq_discount" + (decimal)((discountAmount / rateCardPrice) * 100));
                            //        }
                            //        else
                            //        {
                            //            updQuote["niq_discount"] = null;
                            //            tracing.Trace("niq_discount");
                            //        }
                            //        update = true;
                            //    }
                            //}
                            //else
                            //{
                            //    updQuote["niq_discountamount"] = null;
                            //    updQuote["niq_ratecardprice"] = null;
                            //    updQuote["niq_discount"] = null;
                            //    update = true;
                            //}


                            /*if (entityObj.Contains("niq_expvalidation") && entityObj.GetAttributeValue<bool>("niq_expvalidation"))
                            {
                                updQuote["niq_expvalidation"] = false;
                                update = true;
                            }*/
                            if (update)
                            {

                                service.Update(updQuote);

                                tracing.Trace("OnCreateUpdate_Experlogix_ValidateData: sucesfull update quote");
                                if (retQuote.Attributes.Contains("niq_mainquote") && retQuote.GetAttributeValue<bool>("niq_mainquote"))
                                {
                                    service.Update(updOppo);
                                    tracing.Trace("OnCreateUpdate_Experlogix_ValidateData: sucesfull updated Oppo");

                                }
                            }

                        }

                        

                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("OnUpdate_ExperlogixFlag_ValidateData: "+ex.Message);
            }
        }
    }
}
