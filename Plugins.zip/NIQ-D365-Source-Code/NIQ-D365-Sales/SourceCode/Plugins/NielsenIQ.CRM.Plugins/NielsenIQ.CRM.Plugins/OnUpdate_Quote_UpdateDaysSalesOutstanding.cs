﻿using System;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Collections.Generic;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Quote_UpdateDaysSalesOutstanding : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            try
            {                
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_Quote_UpdateDaysSalesOutstanding: Getting the target entity from Input Parameters.");
                    Entity quote = (Entity)context.InputParameters["Target"];
                    if (quote != null && quote.Id != Guid.Empty)
                    {
                        tracing.Trace("OnUpdate_Quote_UpdateDaysSalesOutstanding: Quote ID: " + quote.Id.ToString());
                        Entity retQuote = service.Retrieve(quote.LogicalName, quote.Id, new ColumnSet("niq_paymenttermsid", "niq_quotedefaultperiodicbillingfrequency"));
                        if (retQuote != null && retQuote.Id != Guid.Empty && retQuote.Attributes.Contains("niq_paymenttermsid") && retQuote.Attributes.Contains("niq_quotedefaultperiodicbillingfrequency"))
                        {
                            tracing.Trace("OnUpdate_Quote_UpdateDaysSalesOutstanding: retQuote not null");
                            string paytermValue = string.Empty;
                            Guid paymenttermId = retQuote.GetAttributeValue<EntityReference>("niq_paymenttermsid").Id;
                            paytermValue = GetPaytermName(service, tracing, paymenttermId.ToString());
                            tracing.Trace("paytermValue: " + paytermValue.ToString());

                            int billingFreq = retQuote.GetAttributeValue<OptionSetValue>("niq_quotedefaultperiodicbillingfrequency") != null ? retQuote.GetAttributeValue<OptionSetValue>("niq_quotedefaultperiodicbillingfrequency").Value : 0;
                            tracing.Trace("billingFreq: " + billingFreq.ToString());

                            if(paytermValue != null && billingFreq != 0)
                            {
                                string fetchXmlDaysSalesOutstanding = @"<fetch version='1.0' distinct='false'>
                                                      <entity name='niq_dayssalesoutstanding'>
                                                        <attribute name='niq_modeleddayssalesoutstanding' />
                                                        <attribute name='niq_billingfrequency' />
                                                        <attribute name='niq_agreementpaymentterms' />
                                                        <attribute name='niq_dayssalesoutstandingid' />
                                                        <filter type='and'>
      							                            <condition attribute='niq_agreementpaymentterms' operator='eq' value='" + paytermValue + @"'/>
                                                            <condition attribute = 'niq_billingfrequency' operator= 'eq' value= '" + billingFreq + @"'/></filter></entity></fetch>";

                                //tracing.Trace("OnUpdate_Quote_UpdateDaysSalesOutstanding: fetchXmlDaysSalesOutstanding:" + fetchXmlDaysSalesOutstanding);

                                Entity resultDaysSalesOutstanding = service.RetrieveMultiple(new FetchExpression(fetchXmlDaysSalesOutstanding)).Entities.FirstOrDefault();
                                if (resultDaysSalesOutstanding != null)
                                {
                                    tracing.Trace("OnUpdate_Quote_UpdateDaysSalesOutstanding: fetchXmlDaysSalesOutstanding Executed");
                                    string val = resultDaysSalesOutstanding.GetAttributeValue <String>( "niq_modeleddayssalesoutstanding");
                                    tracing.Trace("OnUpdate_Quote_UpdateDaysSalesOutstanding: niq_modeleddayssalesoutstanding:" + val);
                                    if (!string.IsNullOrEmpty(val))
                                    {
                                        Entity updQuote = new Entity("quote", quote.Id);
                                        updQuote["niq_modeleddayssalesoutstanding"] = val;
                                        service.Update(updQuote);
                                        tracing.Trace("OnUpdate_Quote_UpdateDaysSalesOutstanding: niq_modeleddayssalesoutstanding field updated successfully");
                                    }
                                }
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new InvalidPluginExecutionException(ex.Message);
                tracing.Trace("Exception in OnUpdate_Quote_UpdateDaysSalesOutstanding: " + ex.Message);
            }
        }

        public string GetPaytermName(IOrganizationService service, ITracingService tracer, string paytermId)
        {
            string payTermName = string.Empty;
            try
            {
                if (paytermId != null)
                {
                    var query1 = new QueryExpression("niq_paymentterm")
                    {
                        ColumnSet = new ColumnSet(true),
                        Criteria =
                            {
                                Conditions =
                                {
                                    new ConditionExpression("niq_paymenttermid", ConditionOperator.Equal, paytermId)
                                }
                            }
                    };
                    var entitylist = service.RetrieveMultiple(query1);
                    if (entitylist.Entities[0] != null)
                    {
                        payTermName = entitylist.Entities[0].Attributes["niq_paymenttermcode"].ToString();
                    }
                }

            }
            catch (Exception ex)
            {
                tracer.Trace("Exception in GetPaytermName: " + ex.Message);
                payTermName = "";
            }
            return payTermName;
        }
    }
}
