using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace NielsenIQ.CRM.Plugins
{
    public class OnExecute_OppQuoteProduct_UpdateWBSCode : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            Guid opportunityId = Guid.Empty;
            string[] wbsCodes;

            if (context.InputParameters.Contains("niq_OpportunityIdRequestParameter") && (Guid)context.InputParameters["niq_OpportunityIdRequestParameter"] != Guid.Empty)
                  
            {
                opportunityId = (Guid)context.InputParameters["niq_OpportunityIdRequestParameter"];
                tracingService.Trace("Opportunity Id: " + opportunityId.ToString());
            }
            else
            {
                throw new InvalidPluginExecutionException("OpportunityID is null");      
            }

            if (context.InputParameters.Contains("niq_WBSCode") && context.InputParameters["niq_WBSCode"] != null && ((string[])context.InputParameters["niq_WBSCode"]).Length>0 )
            {
                 wbsCodes = (string[])context.InputParameters["niq_WBSCode"];
                
            }
        
            else
            {
                throw new InvalidPluginExecutionException("WBS Code is null");
            }

            context.OutputParameters["niq_MSDRPSOutputResponse"] = PopulateWBSCodeOnQuoteProduct(service, tracingService, opportunityId, wbsCodes);
            
            
        }

        private string PopulateWBSCodeOnQuoteProduct(IOrganizationService service, ITracingService tracingService,Guid opportunityId, string[] wbsCodes)
        {
                // Instantiate QueryExpression query
                var query = new QueryExpression("quotedetail")
                {
                    // Add 3 columns to quotedetail
                    ColumnSet = new ColumnSet("niq_wbs", "quotedetailid", "quotedetailname"),
                    // Add 2 link-entity to query
                    LinkEntities =
                    {
                       // Add link-entity query_quote
                       new LinkEntity("quotedetail", "quote", "quoteid", "quoteid", JoinOperator.Inner)
                       {
                         // Add filter to quote with 1 conditions
                         LinkCriteria =
                         {
                           // Add 1 conditions to quote
                           Conditions =
                           {
                              new ConditionExpression("niq_mainquote", ConditionOperator.Equal, true)
                           }
                },
                    // Add 1 link-entity to query_quote
                    LinkEntities =
                    {
                        // Add link-entity query_quote_opportunity
                        new LinkEntity("quote", "opportunity", "opportunityid", "opportunityid", JoinOperator.Inner)
                        {
                            // Add filter to opportunity with 1 conditions
                            LinkCriteria =
                            {
                                // Add 1 conditions to opportunity
                                Conditions =
                                {
                                    new ConditionExpression("opportunityid", ConditionOperator.Equal, opportunityId)
                                }
                            }
                        }
                    }
                },
                        // Add link-entity query_product
                    new LinkEntity("quotedetail", "product", "niq_brandid", "productid", JoinOperator.Inner)
                    {
                        // Add filter to product with 1 conditions
                        LinkCriteria =
                        {
                            // Add 1 conditions to product
                            Conditions =
                            {
                                new ConditionExpression("name", ConditionOperator.Equal, "CI")
                            }
                        }
                    }
                }
                };
            EntityCollection quoteProducts = service.RetrieveMultiple(query);
            tracingService.Trace("QPs " + quoteProducts.Entities.Count);
            if(quoteProducts.Entities.Count > 0)
            {
                tracingService.Trace("QP Found:" + quoteProducts.Entities.Count);
                foreach(Entity quoteProduct in quoteProducts.Entities)
                {
                    if(quoteProduct.Attributes.Contains("niq_wbs") && quoteProduct["niq_wbs"] !=null)
                    {
                        throw new InvalidPluginExecutionException("An "+ quoteProduct["niq_wbs"] + " WBS code is already present. No action taken");
                    }
                   
                }

                if(quoteProducts.Entities.Count != wbsCodes.Length)
                {
                    throw new InvalidPluginExecutionException("XA WBS codes vs products: number of items mismatch. No action taken");
                }
                for(int i = 0; i < quoteProducts.Entities.Count; i++)
                {
                    Entity updateQuoteProducts = new Entity(quoteProducts.Entities[i].LogicalName, quoteProducts.Entities[i].Id);
                    updateQuoteProducts["niq_wbs"] = wbsCodes[i];
                    service.Update(updateQuoteProducts);
                    tracingService.Trace("WBS Code Updated");
                }
                
            }

        return "Success: All WBS Codes applied to CI Quote Products.";
        }
    }

}
