﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.Plugins.Helper;
using Microsoft.Xrm.Sdk.Messages;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Opportunity_Update_Quote_CongaData : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(null);

                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_Opportunity_Update_Quote_CongaData: Getting the target entity from Input Parameters.");
                    Entity relOppo = (Entity)context.InputParameters["Target"];
                    if (relOppo != null && relOppo.Id != Guid.Empty)
                    {
                        tracing.Trace("OnUpdate_Opportunity_Update_Quote_CongaData:rel oppo " + relOppo.Id);

                        bool update = false;

                        string fetchQuoteProd = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='quote'>
                                                        <attribute name='name' />
                                                        <attribute name='totalamount' />
                                                        <attribute name='opportunityid' />
                                                        <attribute name='niq_mainquote' />
                                                        <attribute name='niq_dealdeskapproval' />
                                                        <attribute name='niq_contractstartdate' />
                                                        <attribute name='niq_contractenddate' />
                                                        <attribute name='quoteid' />
                                                        <order attribute='name' descending='false' />
                                                        <filter type='and'>
                                                          <condition attribute='niq_mainquote' operator='eq' value='1' />
                                                          <condition attribute='opportunityid' operator='eq' uitype='opportunity' value='{0}' />
                                                        </filter>
                                                        <link-entity name='opportunity' from='opportunityid' to='opportunityid' visible='false' link-type='outer' alias='a_8722b5f2a2eceb11bacb000d3a35ee6d'>
                                                          <attribute name='niq_stage' />
                                                          <attribute name='niq_salesorgid' />
                                                          <attribute name='parentaccountid' />
                                                        </link-entity>
                                                      </entity>
                                                    </fetch>";
                        fetchQuoteProd = string.Format(fetchQuoteProd, relOppo.Id);
                        var result = service.RetrieveMultiple(new FetchExpression(fetchQuoteProd));
                        if (result != null && result.Entities != null && result.Entities.Count > 0)
                        {
                            tracing.Trace("OnUpdate_Opportunity_Update_Quote_CongaData: results" + result.Entities.Count);
                            foreach (Entity currentQuote in result.Entities)
                            {
                                tracing.Trace("OnUpdate_Opportunity_Update_Quote_CongaData:current quote " + currentQuote.Id);
                                Entity updQuote = new Entity(currentQuote.LogicalName, currentQuote.Id);
                                UpdateRequest updateRequest = new UpdateRequest { Target = updQuote };
                                if (relOppo.Attributes.Contains("parentaccountid") && relOppo.GetAttributeValue<EntityReference>("parentaccountid") != null && relOppo.GetAttributeValue<EntityReference>("parentaccountid").Id != Guid.Empty)
                                {
                                    tracing.Trace("OnUpdate_Opportunity_Update_Quote_CongaData:parentaccountid " + relOppo.GetAttributeValue<EntityReference>("parentaccountid").Id);

                                    Entity retAccount = service.Retrieve(relOppo.GetAttributeValue<EntityReference>("parentaccountid").LogicalName, relOppo.GetAttributeValue<EntityReference>("parentaccountid").Id, new ColumnSet("name", "address1_line1", "address1_city", "niq_stateprovince", "address1_postalcode", "niq_countryid", "niq_industry"));
                                    if (retAccount != null && retAccount.Id != Guid.Empty)
                                    {
                                        if (retAccount.Attributes.Contains("address1_line1"))
                                        {
                                            updQuote["niq_accountaddressstreet"] = retAccount.GetAttributeValue<string>("address1_line1");
                                        }
                                        else
                                        {
                                            updQuote["niq_accountaddressstreet"] = null;

                                        }
                                        if (retAccount.Attributes.Contains("address1_city"))
                                        {

                                            updQuote["niq_accountaddresscity"] = retAccount.GetAttributeValue<string>("address1_city");
                                        }
                                        else
                                        {
                                            updQuote["niq_accountaddresscity"] = null;

                                        }
                                        if (retAccount.Attributes.Contains("niq_stateprovince"))
                                        {
                                            updQuote["niq_accountaddressstateprovince"] = retAccount.FormattedValues["niq_stateprovince"];
                                        }
                                        else
                                        {
                                            updQuote["niq_accountaddressstateprovince"] = null;

                                        }
                                        if (retAccount.Attributes.Contains("address1_postalcode"))
                                        {

                                            updQuote["niq_accountaddresspostalcode"] = retAccount.GetAttributeValue<string>("address1_postalcode");
                                        }
                                        else
                                        {
                                            updQuote["niq_accountaddresspostalcode"] = null;

                                        }
                                        if (retAccount.Attributes.Contains("niq_countryid"))
                                        {

                                            updQuote["niq_accountaddresscountry"] = retAccount.GetAttributeValue<EntityReference>("niq_countryid").Name;
                                        }
                                        else
                                        {
                                            updQuote["niq_accountaddresscountry"] = null;

                                        }
                                        if (retAccount.Attributes.Contains("niq_industry"))
                                        {

                                            updQuote["niq_accountindustry"] = retAccount.FormattedValues["niq_industry"];
                                        }
                                        else
                                        {
                                            updQuote["niq_accountindustry"] = null;

                                        }
                                        if (retAccount.Attributes.Contains("name"))
                                        {
                                            updQuote["niq_account"] = retAccount.GetAttributeValue<string>("name");

                                        }
                                        else
                                        {
                                            updQuote["niq_account"] = null;

                                        }


                                        update = true;
                                    }
                                }
                                if (relOppo.Attributes.Contains("parentaccountid") && relOppo.GetAttributeValue<EntityReference>("parentaccountid") == null)
                                {
                                    tracing.Trace("OnUpdate_Opportunity_Update_Quote_CongaData:parentaccountid is null");
                                    updQuote["niq_accountaddressstreet"] = null;
                                    updQuote["niq_accountaddresscity"] = null;
                                    updQuote["niq_accountaddressstateprovince"] = null;
                                    updQuote["niq_accountaddresspostalcode"] = null;
                                    updQuote["niq_accountaddresscountry"] = null;
                                    updQuote["niq_accountindustry"] = null;
                                    updQuote["niq_account"] = null;
                                    update = true;

                                }

                                if (relOppo.Attributes.Contains("niq_billtoparty") && relOppo.GetAttributeValue<EntityReference>("niq_billtoparty") != null && relOppo.GetAttributeValue<EntityReference>("niq_billtoparty").Id != Guid.Empty)
                                {
                                    tracing.Trace("OnUpdate_Opportunity_Update_Quote_CongaData:niq_billtoparty " + relOppo.GetAttributeValue<EntityReference>("niq_billtoparty").Id);
                                    Entity retBillAccount = service.Retrieve(relOppo.GetAttributeValue<EntityReference>("niq_billtoparty").LogicalName, relOppo.GetAttributeValue<EntityReference>("niq_billtoparty").Id, new ColumnSet("name", "address1_line1", "address1_city", "niq_stateprovince", "address1_postalcode", "niq_countryid"));
                                    if (retBillAccount != null && retBillAccount.Id != Guid.Empty)
                                    {
                                        if (retBillAccount.Attributes.Contains("address1_line1"))
                                        {

                                            updQuote["niq_billtoaccountaddressstreet"] = retBillAccount.GetAttributeValue<string>("address1_line1");
                                        }
                                        if (retBillAccount.Attributes.Contains("address1_city"))
                                        {

                                            updQuote["niq_billtoaccountaddresscity"] = retBillAccount.GetAttributeValue<string>("address1_city");
                                        }
                                        if (retBillAccount.Attributes.Contains("niq_stateprovince"))
                                        {

                                            updQuote["niq_billtoaccountaddressstateprovince"] = retBillAccount.FormattedValues["niq_stateprovince"];
                                        }

                                        if (retBillAccount.Attributes.Contains("address1_postalcode"))
                                        {

                                            updQuote["niq_billtoaccountaddresspostalcode"] = retBillAccount.GetAttributeValue<string>("address1_postalcode");
                                        }
                                        if (retBillAccount.Attributes.Contains("niq_countryid"))
                                        {

                                            updQuote["niq_billtoaccountaddresscountry"] = retBillAccount.GetAttributeValue<EntityReference>("niq_countryid").Name;
                                        }
                                        if (retBillAccount.Attributes.Contains("name"))
                                        {
                                            updQuote["niq_billtoaccount"] = retBillAccount.GetAttributeValue<string>("name");

                                        }
                                        else
                                        {
                                            updQuote["niq_billtoaccount"] = null;

                                        }

                                        update = true;

                                    }
                                }
                                if (relOppo.Attributes.Contains("niq_billtoparty") && relOppo.GetAttributeValue<EntityReference>("niq_billtoparty") == null)
                                {
                                    tracing.Trace("OnUpdate_Opportunity_Update_Quote_CongaData:niq_billtoparty is null");
                                    updQuote["niq_billtoaccountaddressstreet"] = null;
                                    updQuote["niq_billtoaccountaddresscity"] = null;
                                    updQuote["niq_billtoaccountaddressstateprovince"] = null;
                                    updQuote["niq_billtoaccountaddresspostalcode"] = null;
                                    updQuote["niq_billtoaccountaddresscountry"] = null;
                                    updQuote["niq_billtoaccount"] = null;
                                    update = true;

                                }
                                if (relOppo.Attributes.Contains("niq_deliverytoparty") && relOppo.GetAttributeValue<EntityReference>("niq_deliverytoparty") != null && relOppo.GetAttributeValue<EntityReference>("niq_deliverytoparty").Id != Guid.Empty)
                                {
                                    tracing.Trace("OnUpdate_Opportunity_Update_Quote_CongaData:niq_deliverytoparty " + relOppo.GetAttributeValue<EntityReference>("niq_deliverytoparty").Id);

                                    Entity retShipAccount = service.Retrieve(relOppo.GetAttributeValue<EntityReference>("niq_deliverytoparty").LogicalName, relOppo.GetAttributeValue<EntityReference>("niq_deliverytoparty").Id, new ColumnSet("name", "address1_line1", "address1_city", "niq_stateprovince", "address1_postalcode", "niq_countryid"));
                                    if (retShipAccount != null && retShipAccount.Id != Guid.Empty)
                                    {
                                        if (retShipAccount.Attributes.Contains("address1_line1"))
                                        {

                                            updQuote["niq_shiptoaccountaddressstreet"] = retShipAccount.GetAttributeValue<string>("address1_line1");
                                        }
                                        if (retShipAccount.Attributes.Contains("address1_city"))
                                        {

                                            updQuote["niq_shiptoaccountaddresscity"] = retShipAccount.GetAttributeValue<string>("address1_city");
                                        }
                                        if (retShipAccount.Attributes.Contains("niq_stateprovince"))
                                        {

                                            updQuote["niq_shiptoaccountaddressstateprovince"] = retShipAccount.FormattedValues["niq_stateprovince"];
                                        }

                                        if (retShipAccount.Attributes.Contains("address1_postalcode"))
                                        {

                                            updQuote["niq_shiptoaccountaddresspostalcode"] = retShipAccount.GetAttributeValue<string>("address1_postalcode");
                                        }
                                        if (retShipAccount.Attributes.Contains("niq_countryid"))
                                        {

                                            updQuote["niq_shiptoaccountaddresscountry"] = retShipAccount.GetAttributeValue<EntityReference>("niq_countryid").Name;
                                        }
                                        if (retShipAccount.Attributes.Contains("name"))
                                        {
                                            updQuote["niq_shiptoaccount"] = retShipAccount.GetAttributeValue<string>("name");

                                        }
                                        else
                                        {
                                            updQuote["niq_shiptoaccount"] = null;

                                        }

                                        update = true;

                                    }
                                }
                                if (relOppo.Attributes.Contains("niq_deliverytoparty") && relOppo.GetAttributeValue<EntityReference>("niq_deliverytoparty") == null)
                                {
                                    tracing.Trace("OnUpdate_Opportunity_Update_Quote_CongaData:niq_deliverytoparty is null");
                                    updQuote["niq_shiptoaccountaddressstreet"] = null;
                                    updQuote["niq_shiptoaccountaddresscity"] = null;
                                    updQuote["niq_shiptoaccountaddressstateprovince"] = null;
                                    updQuote["niq_shiptoaccountaddresspostalcode"] = null;
                                    updQuote["niq_shiptoaccountaddresscountry"] = null;
                                    updQuote["niq_shiptoaccount"] = null;
                                    update = true;

                                }
                                if (relOppo.Attributes.Contains("name"))
                                {
                                    tracing.Trace("OnUpdate_Opportunity_Update_Quote_CongaData:oppo name" + relOppo.GetAttributeValue<string>("name"));
                                    updQuote["niq_opportunityname"] = relOppo.GetAttributeValue<string>("name");
                                    update = true;
                                }
                                if (relOppo.Attributes.Contains("niq_opportunitynumber"))
                                {
                                    tracing.Trace("OnUpdate_Opportunity_Update_Quote_CongaData:oppo niq_opportunitynumber" + relOppo.GetAttributeValue<string>("niq_opportunitynumber"));
                                    updQuote["niq_opportunitynumber"] = relOppo.GetAttributeValue<string>("niq_opportunitynumber");
                                    update = true;
                                }
                                if (relOppo.Attributes.Contains("niq_salesgroupsalesorgid") && relOppo.GetAttributeValue<EntityReference>("niq_salesgroupsalesorgid") != null && relOppo.GetAttributeValue<EntityReference>("niq_salesgroupsalesorgid").Id != Guid.Empty)
                                {
                                    tracing.Trace("OnUpdate_Opportunity_Update_Quote_CongaData:niq_salesgroupsalesorgid " + relOppo.GetAttributeValue<EntityReference>("niq_salesgroupsalesorgid").Id);

                                    updQuote["niq_salesgroup"] = relOppo.GetAttributeValue<EntityReference>("niq_salesgroupsalesorgid").Name;
                                    update = true;
                                }
                                if (relOppo.Attributes.Contains("transactioncurrencyid") && relOppo.GetAttributeValue<EntityReference>("transactioncurrencyid").Id != Guid.Empty)
                                {
                                    tracing.Trace("OnUpdate_Opportunity_Update_Quote_CongaData:transactioncurrencyid " + relOppo.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                                    Entity currency = service.Retrieve(relOppo.GetAttributeValue<EntityReference>("transactioncurrencyid").LogicalName, relOppo.GetAttributeValue<EntityReference>("transactioncurrencyid").Id, new ColumnSet("isocurrencycode"));
                                    if (currency != null && currency.Attributes.Contains("isocurrencycode"))
                                    {
                                        updQuote["niq_isocurrencycode"] = currency.GetAttributeValue<string>("isocurrencycode");
                                    }
                                }
                                if (update)
                                {
                                    tracing.Trace("OnUpdate_Opportunity_Update_Quote_CongaData:Updating quote Prod ");
                                    service.Update(updQuote);
                                    tracing.Trace("OnUpdate_Opportunity_Update_Quote_CongaData:update success ");

                                }
                            }

                        }
                    }

                }
            }
            catch (Exception ex)
            {

                throw new InvalidProgramException(ex.Message);
            }
        }
    }
}
