﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Collections.Generic;
using System.Linq;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_QuoteProducts_TriggerScheduleFlow : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);



                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_QuoteProducts_TriggerScheduleFlow: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity quoteProductobj = (Entity)context.InputParameters["Target"];
                    Entity quoteProduct = service.Retrieve(quoteProductobj.LogicalName, quoteProductobj.Id, new ColumnSet("niq_ismodified", "quoteid"));
                    if (quoteProduct != null && quoteProduct.Id != Guid.Empty && quoteProduct.Attributes.Contains("quoteid") && quoteProduct.GetAttributeValue<EntityReference>("quoteid").Id != Guid.Empty)
                    {
                        Entity quote = service.Retrieve(quoteProduct.GetAttributeValue<EntityReference>("quoteid").LogicalName, quoteProduct.GetAttributeValue<EntityReference>("quoteid").Id, new ColumnSet("niq_mainquote"));
                        if (quote != null && quote.Attributes.Contains("niq_mainquote") && quote.GetAttributeValue<bool>("niq_mainquote"))
                        {
                            Entity updQuoteProd = new Entity(quoteProduct.LogicalName, quoteProduct.Id);
                            string isModified = null;

                            tracing.Trace("OnUpdate_QuoteProducts_TriggerScheduleFlow: QP is from Main Quote");
                            if (quoteProduct.Attributes.Contains("niq_ismodified") && context.Depth == 1)
                            {

                                isModified = quoteProduct.GetAttributeValue<string>("niq_ismodified") != null ? quoteProduct.GetAttributeValue<string>("niq_ismodified") : null;
                                tracing.Trace("OnUpdate_QuoteProducts_TriggerScheduleFlow: is Modified->" + isModified);
                                switch (isModified)
                                {
                                    case null:
                                        updQuoteProd["niq_ismodified"] = "InProgress";
                                        updQuoteProd["niq_isqpscompleted"] = false;
                                        tracing.Trace("ismodified -> Inprogress");
                                        service.Update(updQuoteProd);
                                        break;
                                    case "InProgress":
                                        updQuoteProd["niq_ismodified"] = "InProgresss";
                                        updQuoteProd["niq_isqpscompleted"] = false;
                                        tracing.Trace("ismodified -> InProgress");
                                        service.Update(updQuoteProd);
                                        break;
                                    case "Completed":
                                        updQuoteProd["niq_ismodified"] = "InProgress";
                                        updQuoteProd["niq_isqpscompleted"] = false;
                                        tracing.Trace("ismodified -> InProgress");
                                        service.Update(updQuoteProd);
                                        break;
                                    default:
                                        updQuoteProd["niq_isqpscompleted"] = false;
                                        service.Update(updQuoteProd);
                                        break;
                                }
                            }
                            else if (!(quoteProduct.Attributes.Contains("niq_ismodified")) && context.Depth == 1)
                            {
                                tracing.Trace("ismodified -> Inprogress");
                                updQuoteProd["niq_ismodified"] = "InProgress";
                                service.Update(updQuoteProd);
                            }


                        }
                    }


                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
