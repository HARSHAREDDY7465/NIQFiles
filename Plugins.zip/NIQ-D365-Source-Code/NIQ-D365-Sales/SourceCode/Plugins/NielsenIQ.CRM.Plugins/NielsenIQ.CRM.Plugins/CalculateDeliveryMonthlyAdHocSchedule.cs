﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using System.Text.RegularExpressions;

namespace NielsenIQ.CRM.Plugins
{
    public class CalculateDeliveryMonthlyAdHocSchedule : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);

                DateTime startDate = (DateTime)context.InputParameters["startDate"];
                DateTime endDate = (DateTime)context.InputParameters["endDate"];
                double extendedAmount = (double)context.InputParameters["extendedAmount"];
                List<DateTime> allStartDates = new List<DateTime>();
                List<DateTime> allEndDates = new List<DateTime>();
                List<DateTime> allCalculatedScheduleDates = new List<DateTime>();
                List<Double> amounts = new List<Double>();
                //DYNCRM-31105
                DateTime estCLoseDate = (DateTime)context.InputParameters["estimatedCloseDate"];
                OptionSetValue revenueFrequency = (OptionSetValue)context.InputParameters["RevenueFrequency"];
                int calculatedTermLength = (int)context.InputParameters["CalculatedTermLength"];
                double datediff = (endDate - startDate).TotalDays + 1;
                //int months = ((endDate.Year - startDate.Year) * 12) + endDate.Month - startDate.Month;
                int months = ((endDate.Year - startDate.Year) * 12) + endDate.Month - startDate.Month + 1;
                double daysInLastMonth = 0.0;
                double daysInFirstMonth = 0.0;


                if (months == 1)
                {
                    if(!(revenueFrequency.Value == 100000008 && calculatedTermLength < 12))
                    {
                        if (estCLoseDate >= startDate)
                            allStartDates.Add(estCLoseDate);
                        else
                            allStartDates.Add(startDate);
                    }                       
                    else
                        allStartDates.Add(startDate);
                    allCalculatedScheduleDates.Add(startDate);
                    amounts.Add(extendedAmount);

                }
                else if (months == 2)
                {
                    DateTime currentMonth = new DateTime(startDate.AddMonths(1).Year, startDate.AddMonths(1).Month, 1);
                    currentMonth = currentMonth.AddDays(-1);
                    daysInFirstMonth = (currentMonth - startDate).TotalDays + 1;
                    amounts.Add(Math.Round(((daysInFirstMonth / datediff) * extendedAmount), 2));
                    allCalculatedScheduleDates.Add(startDate);
                    if (!(revenueFrequency.Value == 100000008 && calculatedTermLength < 12))
                    {
                        if(estCLoseDate >= startDate)
                             allStartDates.Add(estCLoseDate);
                        else 
                            allStartDates.Add(startDate);
                    }                        
                    else
                        allStartDates.Add(startDate);

                    currentMonth = new DateTime(currentMonth.AddMonths(1).Year, currentMonth.AddMonths(1).Month, 1);
                    daysInLastMonth = (endDate - currentMonth).TotalDays + 1;
                    if (!(revenueFrequency.Value == 100000008 && calculatedTermLength < 12))
                    {
                        if (estCLoseDate >= currentMonth)
                            allStartDates.Add(estCLoseDate);
                        else
                            allStartDates.Add(currentMonth);
                    }                        
                    else
                        allStartDates.Add(currentMonth);
                    amounts.Add(Math.Round(((daysInLastMonth / datediff) * extendedAmount), 2));
                    allCalculatedScheduleDates.Add(currentMonth);
                }
                else if (months > 2)
                {
                    DateTime currentMonth = new DateTime(startDate.AddMonths(1).Year, startDate.AddMonths(1).Month, 1);
                    currentMonth = currentMonth.AddDays(-1);
                    daysInFirstMonth = (currentMonth - startDate).TotalDays + 1;
                    amounts.Add(Math.Round(((daysInFirstMonth / datediff) * extendedAmount), 2));
                    allCalculatedScheduleDates.Add(startDate);
                    if (!(revenueFrequency.Value == 100000008 && calculatedTermLength < 12))
                    {
                        if (estCLoseDate >= startDate)
                            allStartDates.Add(estCLoseDate);
                        else
                            allStartDates.Add(startDate);
                    }
                    else
                        allStartDates.Add(startDate);

                    currentMonth = new DateTime(startDate.AddMonths(1).Year, startDate.AddMonths(1).Month, 1);
                    months -= 1;

                    while (months > 1) 
                    {
                        DateTime newDate = currentMonth.AddMonths(1);
                        DateTime lastDayOfMonth = new DateTime(newDate.Year, newDate.Month, 1).AddDays(-1);
                        double daysInMonth = (lastDayOfMonth - currentMonth).TotalDays + 1;
                        if (!(revenueFrequency.Value == 100000008 && calculatedTermLength < 12))
                        {
                            if (estCLoseDate >= currentMonth)
                                allStartDates.Add(estCLoseDate);
                            else
                                allStartDates.Add(currentMonth);
                        }
                        else
                            allStartDates.Add(currentMonth);
                        amounts.Add(Math.Round(((daysInMonth / datediff) * extendedAmount), 2));
                        allCalculatedScheduleDates.Add(currentMonth);
                        currentMonth = currentMonth.AddMonths(1);
                        months -= 1;
                    }
                    daysInLastMonth = (endDate - currentMonth).TotalDays + 1;
                    if (!(revenueFrequency.Value == 100000008 && calculatedTermLength < 12))
                    {
                        if (estCLoseDate >= currentMonth)
                            allStartDates.Add(estCLoseDate);
                        else
                            allStartDates.Add(currentMonth);
                    }
                    else
                        allStartDates.Add(currentMonth);
                    amounts.Add(Math.Round(((daysInLastMonth / datediff) * extendedAmount), 2));
                    allCalculatedScheduleDates.Add(currentMonth);
                }
                context.OutputParameters["allStartDates"] = string.Join(",", allStartDates);
                context.OutputParameters["amounts"] = string.Join(",", amounts);
                context.OutputParameters["allCalculatedScheduleDate"] = string.Join(",", allCalculatedScheduleDates);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message); 
            }
        }
    }
}