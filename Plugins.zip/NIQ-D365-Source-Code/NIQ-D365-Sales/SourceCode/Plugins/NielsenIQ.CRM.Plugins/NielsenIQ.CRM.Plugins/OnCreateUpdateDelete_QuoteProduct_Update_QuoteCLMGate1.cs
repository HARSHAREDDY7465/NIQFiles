﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.Plugins
{
    public class OnCreateUpdateDelete_QuoteProduct_Update_QuoteCLMGate1 : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                if (context.Depth > 2)
                {
                    return;

                }

                int qpcount = 0;
                int quoteProductCount = 0;
                if (context.MessageName == "Update")
                {
                    if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                    {
                        Entity entityObj = (Entity)context.InputParameters["Target"];
                        if (entityObj != null && entityObj.Id != Guid.Empty && entityObj.LogicalName.ToLower() == "quote" && entityObj.Contains("niq_expvalidation") && !entityObj.GetAttributeValue<bool>("niq_expvalidation"))
                        {

                            tracing.Trace("NielsenIQ.CRM.Plugins.OnCreateUpdateDelete_QuoteProduct_Update_QuoteCLMGate1: Getting the target entity from Input Parameters.");
                            // Obtain the target entity from the input parameters.
                            bool update = false;
                            Entity quote = service.Retrieve(entityObj.LogicalName, entityObj.Id, new ColumnSet("niq_salesorgid", "niq_mainquote", "opportunityid"));
                            Entity opportunity = service.Retrieve(quote.GetAttributeValue<EntityReference>("opportunityid").LogicalName, quote.GetAttributeValue<EntityReference>("opportunityid").Id, new ColumnSet("niq_opportunitytype", "niq_triggerbidtoolintegration", "niq_businessarea"));
                            Entity salesOrg = service.Retrieve(quote.GetAttributeValue<EntityReference>("niq_salesorgid").LogicalName, quote.GetAttributeValue<EntityReference>("niq_salesorgid").Id, new ColumnSet("niq_pilotmarket"));
                            Entity updQuote = new Entity(quote.LogicalName, quote.Id);
                            Entity updOppo = new Entity(quote.GetAttributeValue<EntityReference>("opportunityid").LogicalName, quote.GetAttributeValue<EntityReference>("opportunityid").Id);
                            if (opportunity.GetAttributeValue<OptionSetValue>("niq_opportunitytype").Value == 1 && salesOrg.GetAttributeValue<bool>("niq_pilotmarket"))
                            {
                                QueryExpression query = new QueryExpression("quotedetail");
                                query.ColumnSet = new ColumnSet("niq_profitcentreid", "niq_subbrandid");
                                query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, quote.Id);
                                query.Criteria.AddCondition("quotedetailname", ConditionOperator.NotEqual, "SAP Deferred Revenue reconciliation placeholder");
                                EntityCollection clmquoteProducts = service.RetrieveMultiple(query);
                                String fetchCLMgate1 = @"<fetch version=""1.0"" output-format=""xml-platform"" mapping=""logical"" distinct=""false"">
                                    <entity name=""niq_clmgate1"">                                    
                                    <attribute name=""niq_clmsubbrand"" />
                                    <attribute name=""niq_clmprofitcenter"" />                                    
                                    <order attribute=""niq_clmsubbrand"" descending=""false"" />
                                    </entity>
                                    </fetch>";
                                EntityCollection retrieveCLMGATE1 = service.RetrieveMultiple(new FetchExpression(fetchCLMgate1));
                                foreach (Entity QuoteProduct in clmquoteProducts.Entities)
                                {
                                    quoteProductCount++;
                                    tracing.Trace(quoteProductCount.ToString());
                                    if (QuoteProduct.Attributes.Contains("niq_subbrandid") && QuoteProduct.GetAttributeValue<EntityReference>("niq_subbrandid").Id != Guid.Empty && QuoteProduct.Attributes.Contains("niq_profitcentreid") && QuoteProduct.GetAttributeValue<EntityReference>("niq_profitcentreid").Id != Guid.Empty)
                                    {
                                        EntityReference subbrand = QuoteProduct.GetAttributeValue<EntityReference>("niq_subbrandid");
                                        string subbrandname = subbrand.Name;
                                        EntityReference profitcentre = QuoteProduct.GetAttributeValue<EntityReference>("niq_profitcentreid");
                                        string profitcentername = profitcentre.Name;
                                        tracing.Trace(subbrandname + profitcentername);
                                        foreach (Entity CLMGate1 in retrieveCLMGATE1.Entities)
                                        {
                                            if (CLMGate1.GetAttributeValue<string>("niq_clmsubbrand") == subbrandname && CLMGate1.GetAttributeValue<string>("niq_clmprofitcenter") == profitcentername)
                                            {
                                                qpcount++;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }

                            if (quoteProductCount > 0 && qpcount == quoteProductCount)
                            {
                                update = true;
                                updQuote["niq_clmgate1"] = true;
                            }
                            else
                            {
                                update = true;
                                updQuote["niq_clmgate1"] = false;
                            }

                            if (quote.GetAttributeValue<bool>("niq_mainquote") && opportunity != null 
                                && opportunity.GetAttributeValue<OptionSetValue>("niq_businessarea") != null
                                && opportunity.GetAttributeValue<OptionSetValue>("niq_businessarea").Value == 100000000)//bases
                            {
                                tracing.Trace("Opportunity not null");
                                if (opportunity.GetAttributeValue<string>("niq_triggerbidtoolintegration") == null)
                                {
                                    tracing.Trace("Opportunity not null condition");
                                    var number = new Random();
                                    update = true;
                                    updOppo["niq_triggerbidtoolintegration"] = number.Next(11111111, 99999999).ToString();
                                }
                                if (opportunity.GetAttributeValue<string>("niq_triggerbidtoolintegration") != null)
                                {
                                    var number = new Random();
                                    int bid = int.Parse(opportunity.GetAttributeValue<string>("niq_triggerbidtoolintegration"));
                                    int random = number.Next(11111111, 99999999);
                                    tracing.Trace(bid.ToString() + random.ToString());
                                    if (bid == random)
                                    {
                                        random++;
                                    }
                                    update = true;
                                    updOppo["niq_triggerbidtoolintegration"] = random.ToString();
                                }
                            }
                            
                            if (update)
                            {
                                service.Update(updQuote);
                                service.Update(updOppo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}


