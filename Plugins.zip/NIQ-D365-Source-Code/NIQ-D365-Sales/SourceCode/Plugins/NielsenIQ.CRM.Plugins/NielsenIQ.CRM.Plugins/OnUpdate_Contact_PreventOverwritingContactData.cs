using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;


namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Contact_PreventOverwritingContactData : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                Entity contactobj = context.InputParameters["Target"] as Entity;
                if (context.IsInTransaction)
                {
                    tracing.Trace("OnUpdate_Contact_PreventOverwritingContactData: Getting PreImage");
                    Entity preImageContact = (Entity)context.PreEntityImages["contact"];
                    SetContextPreImageValues(service, contactobj, preImageContact, tracing);
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public void SetContextPreImageValues(IOrganizationService service, Entity contactobj, Entity preImageContact, ITracingService tracing)
        {
            try
            {

                if (preImageContact.Contains("firstname") && preImageContact.GetAttributeValue<String>("firstname") != null)
                {
                    contactobj["firstname"] = preImageContact.GetAttributeValue<String>("firstname");
                    tracing.Trace("OnUpdate_Contact_PreventOverwritingContactData: firstname= " + preImageContact["firstname"]);
                }

                if (preImageContact.Contains("lastname") && preImageContact.GetAttributeValue<String>("lastname") != null)
                {
                    contactobj["lastname"] = preImageContact.GetAttributeValue<String>("lastname");
                    tracing.Trace("OnUpdate_Contact_PreventOverwritingContactData: lastname= " + preImageContact["lastname"]);
                }

                if (preImageContact.Contains("fullname") && preImageContact.GetAttributeValue<String>("fullname") != null)
                {
                    contactobj["fullname"] = preImageContact.GetAttributeValue<String>("fullname");
                    tracing.Trace("OnUpdate_Contact_PreventOverwritingContactData: fullname= " + preImageContact["fullname"]);
                }

                if (preImageContact.Contains("yomifullname") && preImageContact.GetAttributeValue<String>("yomifullname") != null)
                {
                    contactobj["yomifullname"] = preImageContact.GetAttributeValue<String>("yomifullname");
                    tracing.Trace("OnUpdate_Contact_PreventOverwritingContactData: yomifullname= " + preImageContact["yomifullname"]);
                }

                if (preImageContact.Contains("jobtitle") && preImageContact.GetAttributeValue<String>("jobtitle") != null)
                {
                    contactobj["jobtitle"] = preImageContact.GetAttributeValue<String>("jobtitle");
                    tracing.Trace("OnUpdate_Contact_PreventOverwritingContactData: jobtitle= " + preImageContact["jobtitle"]);
                }

                if (preImageContact.Contains("mobilephone") && preImageContact.GetAttributeValue<String>("mobilephone") != null)
                {
                    contactobj["mobilephone"] = preImageContact.GetAttributeValue<String>("mobilephone");
                    tracing.Trace("OnUpdate_Contact_PreventOverwritingContactData: mobilephone= " + preImageContact["mobilephone"]);
                }
                
                if (preImageContact.Contains("niq_managementlevel") && preImageContact.GetAttributeValue<OptionSetValue>("niq_managementlevel") != null)
                {
                    contactobj["niq_managementlevel"] = preImageContact.GetAttributeValue<OptionSetValue>("niq_managementlevel");
                    tracing.Trace("OnUpdate_Contact_PreventOverwritingContactData: niq_managementlevel= " + preImageContact.GetAttributeValue<OptionSetValue>("niq_managementlevel").Value);
                }

                if (preImageContact.Contains("niq_functionalarea") && preImageContact.GetAttributeValue<OptionSetValue>("niq_functionalarea") != null)
                {
                    contactobj["niq_functionalarea"] = preImageContact.GetAttributeValue<OptionSetValue>("niq_functionalarea");
                    tracing.Trace("OnUpdate_Contact_PreventOverwritingContactData: niq_funcionalarea= " + preImageContact.GetAttributeValue<OptionSetValue>("niq_functionalarea").Value);
                }

                if (preImageContact.Contains("niq_countryid") && preImageContact.GetAttributeValue<EntityReference>("niq_countryid") != null)
                {
                    contactobj["niq_countryid"] = preImageContact.GetAttributeValue<EntityReference>("niq_countryid");
                    tracing.Trace("OnUpdate_Contact_PreventOverwritingContactData: niq_countryid= " + preImageContact.GetAttributeValue<EntityReference>("niq_countryid").Name);
                }
                if (contactobj.Contains("donotbulkemail"))
                {
                    tracing.Trace("OnUpdate_Contact_PreventOverwritingContactData: Entity's donotbulkemail= " + contactobj.GetAttributeValue<bool>("donotbulkemail"));
                    if (contactobj.GetAttributeValue<bool>("donotbulkemail") == true)
                    {
                        tracing.Trace("test:" + contactobj.GetAttributeValue<EntityReference>("msgdpr_consentchangesourceformid"));

                        if (contactobj.Contains("msgdpr_consentchangesourceformid"))
                        {
                            tracing.Trace("preformid");
                            //tracing.Trace(preImageContact.GetAttributeValue<EntityReference>("msgdpr_consentchangesourceformid").Id.ToString());

                            tracing.Trace("postformid");
                            //tracing.Trace(contactobj.GetAttributeValue<EntityReference>("msgdpr_consentchangesourceformid").Id.ToString());


                            if (false == (preImageContact.Contains("msgdpr_consentchangesourceformid") &&
                                contactobj.GetAttributeValue<EntityReference>("msgdpr_consentchangesourceformid").Id.Equals
                                    (preImageContact.GetAttributeValue<EntityReference>("msgdpr_consentchangesourceformid").Id)))
                            {
                                tracing.Trace("enter to check formname");
                                Entity entForm = service.Retrieve(contactobj.GetAttributeValue<EntityReference>("msgdpr_consentchangesourceformid").LogicalName, contactobj.GetAttributeValue<EntityReference>("msgdpr_consentchangesourceformid").Id,new Microsoft.Xrm.Sdk.Query.ColumnSet("msdyncrm_name"));
                                tracing.Trace("formname:" + entForm["msdyncrm_name"].ToString());

                                if (entForm["msdyncrm_name"].ToString().ToLower() == "default subscription center form")
                                {
                                    return;
                                }
                            }
                            

                        }
                        contactobj["donotbulkemail"] = preImageContact["donotbulkemail"];
                        if (contactobj.Contains("niq_marketingoptin"))
                        {
                            tracing.Trace("OnUpdate_Contact_PreventOverwritingContactData: update step for marketingoptin");
                            contactobj["niq_marketingoptin"] = preImageContact["niq_marketingoptin"];
                        }

                    }
                }
            }

            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }

        }

    }
}