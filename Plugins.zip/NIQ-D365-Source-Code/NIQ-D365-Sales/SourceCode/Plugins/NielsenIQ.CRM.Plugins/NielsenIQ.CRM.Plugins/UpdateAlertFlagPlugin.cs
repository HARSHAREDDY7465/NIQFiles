﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;

namespace NielsenIQ.CRM.Plugins
{
    public class UpdateAlertFlagPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Extract the tracing service for debug logging.
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Obtain the execution context from the service provider.
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            // Check if the plugin is triggered on Update of the niq_ddgpricingapprovallevel field.
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity entity = (Entity)context.InputParameters["Target"];

                if (entity.LogicalName != "quote")
                    return;

                // Check if niq_ddgpricingapprovallevel field is being updated.
                if (entity.Attributes.Contains("niq_ddgpricingapprovallevel"))
                {
         
                    

                    try
                    {
                        // Retrieve the existing quote record to check the current value of niq_alertflag.
                        Entity existingQuote = service.Retrieve(entity.LogicalName, entity.Id, new ColumnSet("niq_alertflag"));

                        if (existingQuote != null && existingQuote.Contains("niq_alertflag"))
                        {
                            bool alertFlag = existingQuote.GetAttributeValue<bool>("niq_alertflag");

                            // If niq_alertflag is true, reset it to false.
                            if (alertFlag)
                            {
                                Entity updateEntity = new Entity(entity.LogicalName, entity.Id);
                                updateEntity["niq_alertflag"] = false;
                                service.Update(updateEntity);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        tracingService.Trace("UpdateAlertFlagPlugin: {0}", ex.ToString());
                        throw;
                    }
                }
            }
        }
    }
}
