﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace NielsenIQ.CRM.Plugins
{
    public class OnCreate_Lead_Create_Contact : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                // The InputParameters collection contains all the data 
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnCreateLeadCreateContact: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity leadobj = (Entity)context.InputParameters["Target"];

                    // Linked in Field Populate

                    PopulateLinkedInfields(tracing, service, leadobj);

                    if (leadobj != null && leadobj.Id != Guid.Empty && !leadobj.Attributes.Contains("parentcontactid"))
                    {
                        tracing.Trace("OnCreateLeadCreateContact: Getting the email from lead.");

                        if (leadobj.Attributes.Contains("emailaddress1") && leadobj["emailaddress1"] != null)
                        {
                            tracing.Trace("OnCreateLeadCreateContact: LeadObj attributes -> ." + leadobj.Attributes);
                            Entity contact = GetContactByLeadEmail(tracing, service, leadobj);

                            if (contact != null && contact.Id != Guid.Empty)
                            {
                                //Update Contact details
                                SetLeadContactMappings(tracing, leadobj, contact);
                                if ((leadobj.Contains("donotbulkemail") && leadobj.GetAttributeValue<bool>("donotbulkemail") == false))
                                {
                                    tracing.Trace("OnCreateLeadCreateContact: donotbulkemail ->" + leadobj.GetAttributeValue<bool>("donotbulkemail"));
                                    contact["donotbulkemail"] = leadobj.GetAttributeValue<bool>("donotbulkemail");
                                }
                               
                                service.Update(contact);

                                //Set Parent Contact on Lead
                                tracing.Trace("OnCreateLeadCreateContact: Contact Found ");
                                UpdateLeadParentContact(tracing, service, leadobj, contact.Id, false);
                            }
                            else
                            {
                                tracing.Trace("OnCreateLeadCreateContact: does not found contact");
                                //Create Contact record
                                Entity contactObj = new Entity("contact");
                                SetLeadContactMappings(tracing, leadobj, contactObj);
                                
                                
                                if ((leadobj.Contains("donotbulkemail")))
                                {
                                    tracing.Trace("OnCreateLeadCreateContact: donotbulkemail ->" + leadobj.GetAttributeValue<bool>("donotbulkemail"));
                                    contactObj["donotbulkemail"] = leadobj.GetAttributeValue<bool>("donotbulkemail");
                                }

                                string leadEmail = leadobj.GetAttributeValue<string>("emailaddress1");
                                if (leadEmail.EndsWith("@nielseniq.com", StringComparison.OrdinalIgnoreCase))
                                {
                                    tracing.Trace("Email with @nielseniq.com domain.");
                                    // Set the Contact Record Type as 'Internal Contact'
                                    contactObj["niq_contactrecordtype"] = true;
                                }

                                tracing.Trace("OnCreateLeadCreateContact: creating new contact");
                                Guid contactId = service.Create(contactObj);

                                if (contactId != Guid.Empty)
                                {
                                    //Set Parent Contact on Lead
                                    UpdateLeadParentContact(tracing, service, leadobj, contactId, true);
                                }
                            }
                        }
                    }

                    else if (leadobj != null && leadobj.Id != Guid.Empty && leadobj.Attributes.Contains("parentcontactid"))
                    {
                        EntityReference parentContactRef = leadobj.GetAttributeValue<EntityReference>("parentcontactid");
                        Entity contact = service.Retrieve(parentContactRef.LogicalName, parentContactRef.Id, new ColumnSet("emailaddress1"));
                        if (contact != null && contact.Id != Guid.Empty && leadobj.Attributes.Contains("emailaddress1") && contact.Attributes.Contains("emailaddress1"))
                        {
                            tracing.Trace("ret emails");
                            string leadEmail = leadobj.GetAttributeValue<string>("emailaddress1");
                            string contactEmail = contact.GetAttributeValue<string>("emailaddress1");
                            tracing.Trace("LeadObj email -> ." + leadEmail);
                            if (!string.Equals(leadEmail, contactEmail, StringComparison.OrdinalIgnoreCase))
                            {
                                tracing.Trace("Emails are not same");
                                leadobj["emailaddress1"] = contactEmail;
                                service.Update(leadobj);
                            }

                        }
                        
                    }
                   
                }
            }

            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        /// <summary>
        /// Method to update Contact value on Lead Record
        /// </summary>
        /// <param name="tracing"></param>
        /// <param name="service"></param>
        /// <param name="leadobj"></param>
        /// <param name="contactId"></param>
        private static void UpdateLeadParentContact(ITracingService tracing, IOrganizationService service, Entity leadobj, Guid contactId, bool niq_netnewcontact)
        {
            Entity updLead = new Entity("lead", leadobj.Id);
            updLead["parentcontactid"] = new EntityReference("contact", contactId);
            updLead["niq_netnewcontact"] = niq_netnewcontact;
            tracing.Trace("OnCreateLeadCreateContact: adding contact in related ");
            service.Update(updLead);
        }

        /// <summary>
        /// Method to set the Mapping
        /// </summary>
        /// <param name="tracing"></param>
        /// <param name="leadobj"></param>
        /// <param name="contactObj"></param>
        private static void SetLeadContactMappings(ITracingService tracing, Entity leadobj, Entity contactObj)
        {
            //update the contact field -only if contact obj does not have the field (for create) and if Contact exists ,contact field value does not contain data , lead field value contains data
            if ((leadobj.Contains("firstname") && !contactObj.Contains("firstname")) ||
               (contactObj.Contains("firstname") && string.IsNullOrEmpty(contactObj.GetAttributeValue<string>("firstname")) && !string.IsNullOrEmpty(leadobj.GetAttributeValue<string>("firstname"))))
            {
                tracing.Trace("OnCreateLeadCreateContact: firstname ->" + leadobj.GetAttributeValue<string>("firstname"));
                contactObj["firstname"] = leadobj.GetAttributeValue<string>("firstname");
            }

            if ((leadobj.Contains("lastname") && !contactObj.Contains("lastname")) ||
             (contactObj.Contains("lastname") && string.IsNullOrEmpty(contactObj.GetAttributeValue<string>("lastname")) && !string.IsNullOrEmpty(leadobj.GetAttributeValue<string>("lastname"))))
            {
                tracing.Trace("OnCreateLeadCreateContact: lastname ->" + leadobj.GetAttributeValue<string>("lastname"));
                contactObj["lastname"] = leadobj.GetAttributeValue<string>("lastname");
            }

            if ((leadobj.Contains("jobtitle") && !contactObj.Contains("jobtitle")) ||
             (contactObj.Contains("jobtitle") && string.IsNullOrEmpty(contactObj.GetAttributeValue<string>("jobtitle")) && !string.IsNullOrEmpty(leadobj.GetAttributeValue<string>("jobtitle"))))
            {
                tracing.Trace("OnCreateLeadCreateContact: jobtitle ->" + leadobj.GetAttributeValue<string>("jobtitle"));
                contactObj["jobtitle"] = leadobj.GetAttributeValue<string>("jobtitle");
            }

            if ((leadobj.Contains("emailaddress1") && !contactObj.Contains("emailaddress1")) ||
             (contactObj.Contains("emailaddress1") && string.IsNullOrEmpty(contactObj.GetAttributeValue<string>("emailaddress1")) && !string.IsNullOrEmpty(leadobj.GetAttributeValue<string>("emailaddress1"))))
            {
                tracing.Trace("OnCreateLeadCreateContact: emailaddress ->" + leadobj.GetAttributeValue<string>("emailaddress1"));
                contactObj["emailaddress1"] = leadobj.GetAttributeValue<string>("emailaddress1");
            }

            if ((leadobj.Contains("niq_country") && !contactObj.Contains("niq_countryid")) ||
            (contactObj.Contains("niq_countryid") && contactObj.GetAttributeValue<EntityReference>("niq_countryid") == null && leadobj.GetAttributeValue<EntityReference>("niq_country") != null))

            {
                tracing.Trace("OnCreateLeadCreateContact: country ->" + leadobj.GetAttributeValue<EntityReference>("niq_country").Name);
                contactObj["niq_countryid"] = leadobj.GetAttributeValue<EntityReference>("niq_country");
            }

            if ((leadobj.Contains("niq_functionalarea") && !contactObj.Contains("niq_functionalarea")) ||
            (contactObj.Contains("niq_functionalarea") && contactObj.GetAttributeValue<OptionSetValue>("niq_functionalarea") == null && leadobj.GetAttributeValue<OptionSetValue>("niq_functionalarea") != null))
            {
                tracing.Trace("OnCreateLeadCreateContact: niq_functionalarea ->" + leadobj.GetAttributeValue<OptionSetValue>("niq_functionalarea").Value.ToString());
                contactObj["niq_functionalarea"] = leadobj.GetAttributeValue<OptionSetValue>("niq_functionalarea");
            }

            if ((leadobj.Contains("niq_managementlevel") && !contactObj.Contains("niq_managementlevel")) ||
            (contactObj.Contains("niq_managementlevel") && contactObj.GetAttributeValue<OptionSetValue>("niq_managementlevel") == null && leadobj.GetAttributeValue<OptionSetValue>("niq_managementlevel") != null))
            {
                tracing.Trace("OnCreateLeadCreateContact: niq_managementlevel ->" + leadobj.GetAttributeValue<OptionSetValue>("niq_managementlevel").Value.ToString());
                contactObj["niq_managementlevel"] = leadobj.GetAttributeValue<OptionSetValue>("niq_managementlevel");
            }

            if ((leadobj.Contains("mobilephone") && !contactObj.Contains("mobilephone")) ||
             (contactObj.Contains("mobilephone") && string.IsNullOrEmpty(contactObj.GetAttributeValue<string>("mobilephone")) && !string.IsNullOrEmpty(leadobj.GetAttributeValue<string>("mobilephone"))))
            {
                tracing.Trace("OnCreateLeadCreateContact: mobilephone ->" + leadobj.GetAttributeValue<string>("mobilephone"));
                contactObj["mobilephone"] = leadobj.GetAttributeValue<string>("mobilephone");
            }



        }

        /// <summary>
        /// Method to Get the Contact record by lead email address
        /// </summary>
        /// <param name="tracing"></param>
        /// <param name="service"></param>
        /// <param name="leadobj"></param>
        /// <returns></returns>
        private static Entity GetContactByLeadEmail(ITracingService tracing, IOrganizationService service, Entity leadobj)
        {
            string emailadd = leadobj.GetAttributeValue<string>("emailaddress1");
            tracing.Trace("OnCreateLeadCreateContact: fetching Contact with email address ");
            string fetchXmlContact = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                            <entity name='contact'>
                                                <attribute name= 'firstname' />
                                                <attribute name= 'lastname' />
                                                <attribute name= 'emailaddress1' />
                                                <attribute name= 'jobtitle' />
                                                <attribute name= 'niq_functionalarea' />
                                                <attribute name= 'niq_countryid' />
                                                <attribute name= 'niq_managementlevel' />
                                                <attribute name= 'mobilephone' />
                                                <attribute name= 'donotbulkemail' />
                                                <attribute name='contactid' />
                                                <filter type='and'>
                                                    <condition attribute='emailaddress1' operator='eq' value='{0}' />
                                                </filter>
                                            </entity>
                                        </fetch>";
            fetchXmlContact = String.Format(fetchXmlContact, emailadd);
            tracing.Trace("OnCreateLeadCreateContact: Retrieving contact");
            Entity contact = service.RetrieveMultiple(new FetchExpression(fetchXmlContact)).Entities.FirstOrDefault();
            return contact;
        }

        #region LinkedIn Fieldsync

        private Entity PopulateLinkedInfields(ITracingService tracing, IOrganizationService service, Entity leadobj)
        {
            try
            {
                Entity updEntity = null;
                var attributelst = leadobj.Attributes.Where(f => f.Key == "niq_countrylnkin" || f.Key == "niq_functionalarealnkin" || f.Key == "niq_industrylnkin" || f.Key == "niq_senioritylnkin").ToList();
                if (attributelst.Count <= 0) return leadobj;

                var query = new QueryExpression("niq_linkedindynamicsmapping")
                {
                    ColumnSet = new ColumnSet(true),
                    Criteria ={ Conditions =
                                {
                                    new ConditionExpression("niq_entityname", ConditionOperator.Equal, "lead"),
                                }
                    }
                };
                EntityCollection entLinkedInmappinglist = service.RetrieveMultiple(query);

                foreach (var attribute in attributelst)
                {
                    tracing.Trace("OnUpdate_SyncLinkedInFieldMapping: Attribute Field: " + attribute.Key + ": value : " + attribute.Value);

                    Entity resultLinkedInData = entLinkedInmappinglist.Entities.Where(f => f["niq_linkedinfieldname"].ToString() == attribute.Key && f["niq_linkedinvalue"].ToString() == attribute.Value.ToString()).FirstOrDefault();

                    if (resultLinkedInData != null && resultLinkedInData.Contains("niq_dynamicsfieldtype"))
                    {
                        if (resultLinkedInData["niq_dynamicsfieldtype"] != null && resultLinkedInData["niq_dynamicsfieldtype"].ToString() == "OptionSet")
                        {

                            if (resultLinkedInData["niq_dynamicsfieldname"] != null && resultLinkedInData["niq_dynamicsschemavalue"] != null)
                            {
                                string val = resultLinkedInData["niq_dynamicsschemavalue"].ToString();
                                if (val.Contains(","))
                                {
                                    val = val.Replace(",", "");
                                }

                                if (updEntity == null) updEntity = new Entity(leadobj.LogicalName, leadobj.Id);

                                updEntity[resultLinkedInData["niq_dynamicsfieldname"].ToString()] = new OptionSetValue(Convert.ToInt32(val));
                                leadobj[resultLinkedInData["niq_dynamicsfieldname"].ToString()] = new OptionSetValue(Convert.ToInt32(val));

                                tracing.Trace("SyncLinkedInFieldMapping: " + resultLinkedInData["niq_dynamicsfieldname"].ToString() + "field added");
                            }
                        }
                        else if (resultLinkedInData["niq_dynamicsfieldtype"] != null && resultLinkedInData["niq_dynamicsfieldtype"].ToString().Contains("LookUp"))
                        {
                            string lookupEntity = string.Empty;
                            string lookupAltKey = string.Empty;
                            string fieldtype = resultLinkedInData["niq_dynamicsfieldtype"].ToString().Replace("LookUp", "");

                            if (fieldtype.Contains(","))
                            {
                                string[] values = fieldtype.Split(',');
                                for (int i = 0; i < values.Length; i++)
                                {
                                    values[i] = values[i].Trim();
                                }
                                lookupEntity = values[0].TrimStart('(');
                                lookupAltKey = values[1].TrimEnd(')');
                            }

                            tracing.Trace("SyncLinkedInFieldMapping: lookupEntity: " + lookupEntity + "-key:" + lookupAltKey);


                            if (!string.IsNullOrEmpty(lookupAltKey))
                            {
                                if (resultLinkedInData["niq_dynamicsfieldname"] != null && resultLinkedInData["niq_dynamicsschemavalue"] != null)
                                {
                                    if (updEntity == null) updEntity = new Entity(leadobj.LogicalName, leadobj.Id);

                                    updEntity[resultLinkedInData["niq_dynamicsfieldname"].ToString()] = new EntityReference(lookupEntity, lookupAltKey, resultLinkedInData["niq_dynamicsschemavalue"]);
                                    leadobj[resultLinkedInData["niq_dynamicsfieldname"].ToString()] = new EntityReference(lookupEntity, lookupAltKey, resultLinkedInData["niq_dynamicsschemavalue"]);

                                    tracing.Trace("SyncLinkedInFieldMapping: " + lookupEntity + " field added");
                                }
                            }
                            else
                            {
                                if (resultLinkedInData["niq_dynamicsdisplayvalue"] != null && resultLinkedInData["niq_dynamicsschemavalue"] != null && resultLinkedInData["niq_dynamicsfieldname"] != null)
                                {
                                    Guid lookupGuid = GetCountryGuid(service, tracing, resultLinkedInData["niq_dynamicsdisplayvalue"].ToString(), resultLinkedInData["niq_dynamicsschemavalue"].ToString());
                                    if (lookupGuid != null)
                                    {
                                        if (updEntity == null) updEntity = new Entity(leadobj.LogicalName, leadobj.Id);

                                        updEntity[resultLinkedInData["niq_dynamicsfieldname"].ToString()] = new EntityReference(lookupEntity, lookupGuid);
                                        leadobj[resultLinkedInData["niq_dynamicsfieldname"].ToString()] = new EntityReference(lookupEntity, lookupGuid);

                                        tracing.Trace("SyncLinkedInFieldMapping: " + lookupEntity + " field added");
                                    }
                                }
                            }
                        }
                    }
                }
                if (updEntity != null)
                    service.Update(updEntity);
                tracing.Trace("SyncLinkedInFieldMapping:  fields updated successfully");
                return leadobj;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private Guid GetCountryGuid(IOrganizationService service, ITracingService tracing, string countryName, string countryCode)
        {
            Guid countryGuid = new Guid();
            try
            {
                if (countryName != null && countryCode != null)
                {
                    var query1 = new QueryExpression("niq_country")
                    {
                        ColumnSet = new ColumnSet(true),
                        Criteria =
                            {
                                Conditions =
                                {
                                    new ConditionExpression("niq_name", ConditionOperator.Equal, countryName),
                                    new ConditionExpression("niq_countrycode", ConditionOperator.Equal, countryCode),
                                }
                            }
                    };
                    var entitylist = service.RetrieveMultiple(query1);
                    if (entitylist.Entities[0] != null)
                    {
                        countryGuid = entitylist.Entities[0].Id;
                        tracing.Trace("GetCountryGuid: countryGuid: " + countryGuid);
                    }
                }

            }
            catch (Exception ex)
            {
                tracing.Trace("Exception in GetCountryGuid: " + ex.Message);
            }
            return countryGuid;
        }

        #endregion
    }
}