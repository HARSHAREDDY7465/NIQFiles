﻿using System;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Services;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Quote_expValidation_UpdateQuoteAndOpportunity : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {

                    Entity quote = (Entity)context.InputParameters["Target"];
                    
                    Entity preImageAccount = (Entity)context.PreEntityImages["PreImage"];
                    Entity postImageAccount = (Entity)context.PostEntityImages["PostImage"];
                    if (quote.Contains("niq_mainquote") && !quote.Contains("niq_expvalidation"))
                    {
                        //getting pre and post image of niq_mainquote
                        bool preImageMainQuote = preImageAccount.GetAttributeValue<bool>("niq_mainquote");
                        bool postImageMainQuote = postImageAccount.GetAttributeValue<bool>("niq_mainquote");
                        tracingService.Trace("preimage" + preImageMainQuote.ToString());
                        tracingService.Trace("postimage" + postImageMainQuote.ToString());
                        //if pre and post image of main quote is same then the logic will not run
                        if (preImageMainQuote == postImageMainQuote)
                        {
                            return;
                        }
                    }
                    
                    Entity quoteObj = service.Retrieve(quote.LogicalName, quote.Id, new ColumnSet("niq_expvalidation", "niq_mainquote", "opportunityid"));
                    Entity quoteUpd = new Entity(quote.LogicalName, quote.Id);
                    if (quote != null && quote.Id != Guid.Empty)
                    {
                        string fetchQuoteProducts = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                <entity name='quotedetail'>
                                                <attribute name='quotedetailname' />
                                                <attribute name='quotedetailid' />
                                                <attribute name='niq_type' />

                                                <order attribute='quotedetailname' descending='false' />
                                                <filter type='and'>
                                                <condition attribute='niq_type' operator='eq' value='2' />
                                                <condition attribute='quoteid' operator='eq' value='{0}' />
                                                </filter>
                                                </entity>
                                                </fetch>";
                        fetchQuoteProducts = string.Format(fetchQuoteProducts, quoteObj.Id);
                        EntityCollection quoteProducts = service.RetrieveMultiple(new FetchExpression(fetchQuoteProducts));
                        if (quoteProducts != null && quoteProducts.Entities != null && quoteProducts.Entities.Count > 0)
                        {
                            quoteUpd["niq_adhocproductsonlyquote"] = false;
                        }
                        else
                        {
                            quoteUpd["niq_adhocproductsonlyquote"] = true;
                        }
                        service.Update(quoteUpd);
                    }

                    UpdateQuote(context, quote, quoteObj, service, tracingService);
                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public void UpdateQuote(IPluginExecutionContext context, Entity quote, Entity quoteObj, IOrganizationService service, ITracingService tracingService)
        {
            if (context.MessageName == "Update" && (quote.Contains("niq_expvalidation") || quote.Contains("niq_mainquote")))
            {

                string getQuoteProducts = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='quotedetail'>
                                        <attribute name='niq_subbrandid' />
                                        <attribute name='niq_brandid' />
                                        <attribute name='quotedetailname' />
                                        <attribute name='quotedetailid' />
                                        <order attribute='niq_brandid' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='quoteid' operator='eq' uiname='test' uitype='quote' value='{quoteObj.Id}' />
                                        </filter>
                                        <link-entity name='product' from='productid' to='niq_brandid' link-type='inner' alias='ac'>
                                          <attribute name='name' />
                                          <filter type='and'>
                                            <filter type='or'>
                                              <condition attribute='name' operator='eq' value='BASES' />
                                              <condition attribute='name' operator='eq' value='CI' />
                                            </filter>
                                          </filter>
                                        </link-entity>
                                      </entity>
                                    </fetch>";
                var quoteProducts = service.RetrieveMultiple(new FetchExpression(getQuoteProducts));

                var baseProductLines = quoteProducts.Entities.Where(ent => (ent.GetAttributeValue<AliasedValue>("ac.name").Value.ToString().Equals("BASES"))).Count();
                tracingService.Trace(baseProductLines.ToString());
                var ciProductLines = quoteProducts.Entities.Where(ent => (ent.GetAttributeValue<AliasedValue>("ac.name").Value.ToString().Equals("CI"))).Count();
                tracingService.Trace(ciProductLines.ToString());

                Entity quoteUpd = new Entity(quote.LogicalName, quote.Id);

                if (quoteProducts.Entities.Count > 0)
                {
                    quoteUpd["niq_termtype"] = new OptionSetValue(100000001);
                    service.Update(quoteUpd);
                }

                bool mainQuote = quoteObj.Attributes.Contains("niq_mainquote") ? quoteObj.GetAttributeValue<bool>("niq_mainquote") : false;
                EntityReference opportunity = quoteObj.Attributes.Contains("opportunityid") ? quoteObj.GetAttributeValue<EntityReference>("opportunityid") : null;
                if (mainQuote)
                {
                    Entity opportunityToUpdate = new Entity("opportunity");
                    opportunityToUpdate.Id = opportunity.Id;
                    bool isUpdaterequired = false;
                    if (baseProductLines > 0)
                    {
                        opportunityToUpdate["niq_businessarea"] = new OptionSetValue(100000000);
                        isUpdaterequired = true;
                    }
                    else if (ciProductLines > 0)
                    {
                        opportunityToUpdate["niq_businessarea"] = new OptionSetValue(100000001);
                        opportunityToUpdate["niq_fieldingcountry"] = null;
                        isUpdaterequired = true;
                    }
                    else
                    {
                        opportunityToUpdate["niq_businessarea"] = new OptionSetValue(100000002);
                        opportunityToUpdate["niq_fieldingcountry"] = null;
                        isUpdaterequired = true;
                    }

                    if (isUpdaterequired)
                        service.Update(opportunityToUpdate);
                }
            }
        }
    }
}
