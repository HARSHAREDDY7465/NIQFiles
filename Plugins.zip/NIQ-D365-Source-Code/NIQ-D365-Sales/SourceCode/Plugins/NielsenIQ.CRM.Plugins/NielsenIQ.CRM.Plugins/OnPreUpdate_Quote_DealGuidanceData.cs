using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;


namespace NielsenIQ.CRM.Plugins
{
    public class OnPreUpdate_Quote_DealGuidanceData : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            bool isSuccess = true;
            string resultMessage = string.Empty;
            Guid? quoteId = new Guid();

            try
            { // Retrieve JSON parameter from the context
                string jsonParameter = null;
                string jsonStatus = null;
                string jsonReqID = null;

                if (context.InputParameters.Contains("niq_CISMSDDealScoringOutputJasonObjectParameter") || context.InputParameters.Contains("niq_StatusReason") || context.InputParameters.Contains("niq_requestId"))
                {
                    jsonParameter = (string)context.InputParameters["niq_CISMSDDealScoringOutputJasonObjectParameter"];
                    jsonStatus = (string)context.InputParameters["niq_StatusReason"];
                    tracingService.Trace($"jsonStatus value: {jsonStatus}");
                    jsonReqID = (string)context.InputParameters["niq_requestId"];
                    tracingService.Trace($"jsonStatus value: {jsonReqID}");


                }
                if (context.InputParameters.Contains("niq_requestId"))
                {

                    EntityCollection quotes = null;
                    tracingService.Trace($"jsonRequestId value: {jsonReqID}");

                    QueryExpression query = new QueryExpression("quote")
                    {
                        ColumnSet = new ColumnSet("quoteid", "niq_cis_requestid", "opportunityid"),
                        Criteria = new FilterExpression
                        {
                            Conditions = {
                                  new ConditionExpression("niq_cis_requestid", ConditionOperator.Equal, jsonReqID)
                        }
                        }
                    };

                    quotes = service.RetrieveMultiple(query);
                    // Parse JSON (This has been added to handle partial scoring with data in dealscoring node)
                    JObject jsonObjectmain;
                    try
                    {
                        jsonObjectmain = JObject.Parse(jsonParameter);
                    }
                    catch (JsonException ex)
                    {
                        tracingService.Trace("Error parsing the JSON parameter: " + ex.Message);
                        throw new InvalidPluginExecutionException("Error parsing the JSON parameter.", ex);
                    }

                    // Extract dealScoringOutput array from JSON
                    JArray partialdealScoringOutput = jsonObjectmain["dealScoringOutput"] as JArray;
                    // Check if quotes are found
                    if (quotes.Entities.Count > 0)
                    {
                        foreach (var quote1 in quotes.Entities)
                        {
                            // Get the Quote ID and Opportunity ID
                            Guid quotesId = quote1.GetAttributeValue<Guid>("quoteid");
                            Entity retquote = service.Retrieve("quote", quotesId, new ColumnSet("quoteid", "quotenumber","niq_overalldealscore"));
                            EntityReference opportunityRef = quote1.GetAttributeValue<EntityReference>("opportunityid");
                            string ReqID = quote1.Contains("niq_cis_requestid") ? quote1.GetAttributeValue<string>("niq_cis_requestid") : null;
                            tracingService.Trace("RequestID :" + ReqID);

                            if (opportunityRef != null)
                            {
                                Guid opportunityId = opportunityRef.Id;
                                tracingService.Trace($"Quote ID: {quotesId}, Opportunity ID: {opportunityId}");
                                Entity opportunity = service.Retrieve("opportunity", opportunityId, new ColumnSet("ownerid", "niq_opportunitynumber"));
                                var opportunityNumber = opportunity.GetAttributeValue<string>("niq_opportunitynumber");
                                var quoteNumber = retquote.GetAttributeValue<string>("quotenumber");
                                if (jsonStatus != null && ReqID != null && jsonReqID != null && jsonStatus == "Error" && ReqID == jsonReqID)
                                {
                                    tracingService.Trace("Status is Error for opp");
                                    opportunity["niq_dealguidanceerrortimestampopp"] = DateTime.UtcNow;
                                    service.Update(opportunity);

                                    if (opportunity.Contains("ownerid") && opportunity["ownerid"] is EntityReference ownerRef)
                                    {
                                        tracingService.Trace("Triggering notification for opportunity owner.");

                                        Entity notification = new Entity("appnotification");
                                        notification["title"] = "Deal Guidance Error";
                                        notification["body"] = $"The Deal Guidance flow failed due to a technical issue. Please click the Trigger Deal Guidance button to trigger a new flow. **Quote ID**: [{quoteNumber}](?pagetype=entityrecord&etn=quote&id={quotesId}) **Opportunity Number**: [{opportunityNumber}](?pagetype=entityrecord&etn=opportunity&id={opportunityId}). If the issue persists, raise a Help & Support request.";
                                        notification["ownerid"] = new EntityReference("systemuser", ownerRef.Id);
                                        notification["toasttype"] = new OptionSetValue(200000001);
                                        notification["icontype"] = new OptionSetValue(100000002);
                                        notification["priority"] = new OptionSetValue(200000000);
                                        // notification["data"] = "{\"body\":\"The Deal Guidance flow failed due to a technical issue. Please click the Trigger Deal Guidance button to trigger a new flow for QuoteID: [{quoteNumber}](?pagetype=entityrecord&etn=quote&id={quotesId}) Opportunity number: [" + opportunity.GetAttributeValue<string>("niq_opportunitynumber") + "](?pagetype=entityrecord&etn=opportunity&id=" + opportunityId + ") . If the issue persists, raise a Help & Support request.\"}";
                                        notification["ttlinseconds"] = 1800;

                                        service.Create(notification);
                                        tracingService.Trace("Bell notification sent to opportunity owner.");
                                    }
                                }
                                if (jsonStatus != null && ReqID != null && jsonReqID != null && jsonStatus == "Success" && ReqID == jsonReqID)
                                {
                                    tracingService.Trace("Status is success for opp");
                                    opportunity["niq_dealguidanceerrortimestampopp"] = null;
                                    service.Update(opportunity);

                                }
                                if (jsonStatus != null && ReqID != null && jsonReqID != null && jsonStatus == "Error" && ReqID == jsonReqID)
                                {
                                    tracingService.Trace("update the Deal stamp trigger");
                                    quote1["niq_dealguidanceerrortimestampquote"] = DateTime.UtcNow;
                                    quote1["niq_dealscoringinprogress"] = false;
                                    service.Update(quote1);
                                }
                                if (jsonStatus != null && ReqID != null && jsonReqID != null && jsonStatus == "PartialScoring" && ReqID == jsonReqID)
                                {
                                    tracingService.Trace("We got the Partial scoring,timestamp is erased");
                                    quote1["niq_dealscoringinprogress"] = false;
                                    opportunity["niq_dealguidanceerrortimestampopp"] = null;
                                    service.Update(opportunity);
                                    quote1["niq_dealguidanceerrortimestampquote"] = null;
                                    service.Update(quote1);
                                }
                                if (jsonStatus != null && ReqID != null && jsonReqID != null && jsonStatus == "PartialScoring" && ReqID == jsonReqID && (partialdealScoringOutput == null || !partialdealScoringOutput.Any()))
                                {
                                    tracingService.Trace("We got the Partial scoring");

                                    quote1["niq_dealscoringinprogress"] = false;
                                    opportunity["niq_dealguidanceerrortimestampopp"] = null;
                                    service.Update(opportunity);
                                    quote1["niq_dealguidanceerrortimestampquote"] = null;
                                    service.Update(quote1);
                                    if (opportunity.Contains("ownerid") && opportunity["ownerid"] is EntityReference ownerRef)
                                    {
                                        tracingService.Trace("Triggering partial scoring notification for opportunity owner.");
                                        Entity notification = new Entity("appnotification");
                                        notification["title"] = "Deal Guidance not possible";

                                        tracingService.Trace("Quote ID: {0}, Quote Number: {1}", quotesId, quoteNumber);
                                        notification["body"] = $"Dynamic Deal Guidance is not possible for this quote. Resave the Configuration so that the Quote approval can be determined based on Discount % and Quote Header Details values applies.If you change the Configuration, try to retrigger the Deal Guidance flow. Quote ID: [{quoteNumber}](?pagetype=entityrecord&etn=quote&id={quotesId}) Opportunity Number: [{opportunityNumber}](?pagetype=entityrecord&etn=opportunity&id={opportunityId}).";
                                        notification["ownerid"] = new EntityReference("systemuser", ownerRef.Id);
                                        notification["toasttype"] = new OptionSetValue(200000000);
                                        notification["icontype"] = new OptionSetValue(100000000);
                                        notification["priority"] = new OptionSetValue(200000000);
                                        notification["ttlinseconds"] = 1800;
                                        service.Create(notification);
                                        tracingService.Trace("Partial scoring Bell notification is sent to opportunity owner.");
                                    }
                                    if (retquote.Contains("niq_overalldealscore") && retquote["niq_overalldealscore"] != null)
                                    {
                                        retquote["niq_overalldealscore"] = null; //AC4- 20266 to make the partial scoring work
                                        service.Update(retquote);
                                        
                                    }
                                }

                                else if (jsonStatus != null && ReqID != null && jsonReqID != null && jsonStatus == "Success" && ReqID == jsonReqID)
                                {
                                    tracingService.Trace("update the Deal stamp trigger as null");
                                    quote1["niq_dealguidanceerrortimestampquote"] = null;
                                    service.Update(quote1);
                                }
                                else
                                {
                                    tracingService.Trace("Status reason is empty");
                                }

                            }
                        }
                    }
                    else
                    {
                        tracingService.Trace("No quotes found with the given niq_cis_requestid.");
                    }
                }

                else
                {
                    tracingService.Trace("Error: Missing parameter: niq_CISMSDDealScoringOutputJasonObjectParameter");
                    throw new InvalidPluginExecutionException("Missing parameter: niq_CISMSDDealScoringOutputJasonObjectParameter");
                }

                // Parse JSON
                JObject jsonObject;
                try
                {
                    jsonObject = JObject.Parse(jsonParameter);
                }
                catch (JsonException ex)
                {
                    tracingService.Trace("Error parsing the JSON parameter: " + ex.Message);
                    throw new InvalidPluginExecutionException("Error parsing the JSON parameter.", ex);
                }

                // Extract dealScoringOutput array from JSON
                JArray dealScoringOutput = jsonObject["dealScoringOutput"] as JArray;
                if (dealScoringOutput == null || dealScoringOutput.Count == 0)
                {
                    tracingService.Trace("Error: No deal scoring output data found.");
                    context.OutputParameters["niq_CISMSDDealScoringOutputResponse"] = "Processing for Error is completed successfully.";
                    return;

                }

                // Track if any errors occurred

                Entity quote = new Entity("quote");
                Entity existingquote = new Entity();
                tracingService.Trace("Json is retrived from the input parameter");
                // Iterate through each item in the deal scoring output (1)
                foreach (JObject item in dealScoringOutput.Cast<JObject>())
                {
                    tracingService.Trace("Dealscoring output is being processed");

                    // Check if "quoteId" exists before processing the item
                    if (!item.ContainsKey("quoteId"))
                    {
                        tracingService.Trace("Error: Missing quoteId in the item.");
                        resultMessage += $"Error processing item: Missing quoteId\n";
                        throw new InvalidPluginExecutionException(resultMessage);
                    }

                    Guid? opportunityId = item["opportunityId"]?.ToObject<Guid>();
                    quoteId = item["quoteId"]?.ToObject<Guid>();

                    // Validate if opportunityId and quoteId exist
                    if (opportunityId == null || quoteId == null)
                    {
                        tracingService.Trace("Error: Opportunity ID or Quote ID is missing or empty.");
                        resultMessage += $"Error processing item: Opportunity ID or Quote ID is missing or empty\n";
                        throw new InvalidPluginExecutionException(resultMessage);
                    }
                    tracingService.Trace("Retrieving the Quote entity with ID: {0}", quoteId.Value);
                    // Retrieve the Quote entity
                    existingquote = service.Retrieve("quote", quoteId.Value, new ColumnSet("quotenumber", "totalamount", "transactioncurrencyid", "niq_isocurrencycode", "niq_previousprice", "niq_previousratecardattainment", "niq_ratecardprice", "niq_contractduration", "niq_existingcontractaction", "niq_cis_requestid"));
                    if (existingquote == null)
                    {
                        tracingService.Trace("Error: Quote with ID {0} not found.", quoteId);
                        resultMessage += $"Error processing item: Quote with ID {quoteId} not found\n";
                        throw new InvalidPluginExecutionException(resultMessage);
                    }
                    quote.Id = existingquote.Id;

                    // Validate totalamount field
                    if (existingquote.Contains("totalamount") && existingquote["totalamount"] is Money totalAmount)
                    {
                        // Retrieve the transactioncurrencyid (lookup to the transactioncurrency entity)
                        if (existingquote.Contains("transactioncurrencyid") && existingquote["transactioncurrencyid"] is EntityReference currencyRef)
                        {
                            // Retrieve the corresponding transactioncurrency entity
                            Entity transactionCurrency = service.Retrieve(currencyRef.LogicalName, currencyRef.Id, new ColumnSet("isocurrencycode", "currencysymbol"));
                            if (transactionCurrency == null)
                            {
                                tracingService.Trace("Error: Transaction Currency with ID {0} not found.", currencyRef.Id);
                                resultMessage += $"Error processing item: Transaction Currency with ID {currencyRef.Id} not found\n";
                                throw new InvalidPluginExecutionException(resultMessage);
                            }

                            string currencyCode = transactionCurrency.Contains("isocurrencycode") ? transactionCurrency["isocurrencycode"]?.ToString() : string.Empty;
                            string currencySymbol = transactionCurrency.Contains("currencysymbol") ? transactionCurrency["currencysymbol"]?.ToString() : string.Empty;

                            // Validate the currency code or symbol
                            if (string.IsNullOrEmpty(currencyCode))
                            {
                                tracingService.Trace("Error: Currency code is missing or invalid.");
                                resultMessage += "Error processing item: Currency code is missing or invalid\n";
                                throw new InvalidPluginExecutionException(resultMessage);
                            }

                            // Update the numeric fields with the respective values (set to null if empty)
                            quote["niq_outperformamount"] = SetDecimalToNullIfEmpty(item, "niq_outperformamount");
                            quote["niq_basetargetamount"] = SetDecimalToNullIfEmpty(item, "niq_basetargetamount");
                            quote["niq_underperformamount"] = SetDecimalToNullIfEmpty(item, "niq_underperformamount");

                            // Update the Fields based on forumale
                            // For niq_outperform field
                            decimal? niqOutperform = SetDecimalToNullIfEmpty(item, "niq_outperform")?.Value;
                            quote["niq_outperform"] = niqOutperform.HasValue
                                ? 100 + (niqOutperform.Value) * 100 // Apply the formula 100% + (niq_underperform) * 100%
                                : (decimal?)null;

                            // For niq_basetarget field
                            decimal? niqBasetarget = SetDecimalToNullIfEmpty(item, "niq_basetarget")?.Value;
                            quote["niq_basetarget"] = niqBasetarget.HasValue
                                ? 100 + (niqBasetarget.Value) * 100 // Apply the formula 100% + (niq_underperform) * 100%
                                : (decimal?)null;

                            // For niq_underperform field
                            decimal? niqUnderperform = SetDecimalToNullIfEmpty(item, "niq_underperform")?.Value;
                            quote["niq_underperform"] = niqUnderperform.HasValue
                                ? 100 + (niqUnderperform.Value) * 100// Apply the formula 100% + (niq_underperform) * 100%
                                : (decimal?)null;

                            // Handle niq_previousprice (calculation based on niq_currencyconversionfactor)
                            if (item.ContainsKey("niq_previousprice") && item.ContainsKey("niq_currencyconversionfactor"))
                            {
                                // Retrieve niq_previousprice as a decimal from JSON and niq_currencyconversionfactor as decimal
                                var niq_previousprice = SetDecimalToNullIfEmpty(item, "niq_previousprice");
                                var niq_currencyconversionfactor = SetDecimalToNullIfEmpty(item, "niq_currencyconversionfactor");

                                tracingService.Trace($"niq_previousprice: {(niq_previousprice != null ? niq_previousprice.Value.ToString() : "null")}");
                                tracingService.Trace($"niq_currencyconversionfactor: {(niq_currencyconversionfactor != null ? niq_currencyconversionfactor.Value.ToString() : "null")}");

                                // Check if niq_previousprice is 0, in which case directly update the field
                                if (niq_previousprice != null && niq_previousprice.Value == 0)
                                {
                                    if (niq_currencyconversionfactor.Value == 0)
                                    {
                                        quote["niq_previousprice"] = null;
                                        tracingService.Trace("0/0. Setting niq_previousprice to null.");
                                    }
                                    else// Set the niq_previousprice to 0 
                                    {
                                        quote["niq_previousprice"] = 0m;
                                        tracingService.Trace("niq_previousprice is 0. Setting niq_previousprice to 0.");
                                    }

                                }
                                // Check if both niq_previousprice and niq_currencyconversionfactor are valid (not null and niq_currencyconversionfactor != 0)
                                else if (niq_previousprice != null && niq_currencyconversionfactor != null && niq_currencyconversionfactor.Value != 0)
                                {
                                    // Perform the calculation if both values are valid
                                    decimal calculatedValue = niq_previousprice.Value / niq_currencyconversionfactor.Value;

                                    // Update the Dynamics field as a Money field
                                    quote["niq_previousprice"] = new Money(calculatedValue);
                                    tracingService.Trace($"Calculated and updated niq_previousprice: {calculatedValue} based on currency conversion factor.");
                                }
                                else
                                {
                                    // For any other case (either of them is null or invalid, or niq_currencyconversionfactor is zero), set niq_previousprice to null
                                    quote["niq_previousprice"] = null;
                                    tracingService.Trace("Invalid niq_previousprice or niq_currencyconversionfactor. Setting niq_previousprice to null.");
                                }
                            }
                            else
                            {
                                // If the necessary fields don't exist in the item, reset niq_previousprice to null
                                quote["niq_previousprice"] = null;
                                tracingService.Trace("Required fields not found. Setting niq_previousprice to null.");
                            }

                            tracingService.Trace(
                              $"Assigned values for Quote ID: {quoteId} - " +
                              $"niq_outperformamount: {(quote.Contains("niq_outperformamount") ? (quote["niq_outperformamount"] as Money)?.Value.ToString() ?? "null" : "null")}, " +
                              $"niq_basetargetamount: {(quote.Contains("niq_basetargetamount") ? (quote["niq_basetargetamount"] as Money)?.Value.ToString() ?? "null" : "null")}, " +
                              $"niq_underperformamount: {(quote.Contains("niq_underperformamount") ? (quote["niq_underperformamount"] as Money)?.Value.ToString() ?? "null" : "null")}, " +
                              $"niq_outperform: {(quote.Contains("niq_outperform") ? quote["niq_outperform"]?.ToString() ?? "null" : "null")}, " +
                              $"niq_basetarget: {(quote.Contains("niq_basetarget") ? quote["niq_basetarget"]?.ToString() ?? "null" : "null")}, " +
                              $"niq_underperform: {(quote.Contains("niq_underperform") ? quote["niq_underperform"]?.ToString() ?? "null" : "null")}"
                              );


                            // Handle niq_previousratecardattainment (formula)
                            if (quote.Contains("niq_previousprice") && item.ContainsKey("niq_previousratecardattainment"))
                            {
                                // Retrieve the previousRateCardAttainment field as a decimal
                                decimal? previousRateCardAttainment = SetDecimalToNullIfEmpty(item, "niq_previousratecardattainment")?.Value;

                                // Retrieve the previousPrice field as a Money type
                                var previousPriceMoney = SetDecimalToNullIfEmpty(item, "niq_previousprice");
                                decimal? previousPrice = previousPriceMoney?.Value;

                                // Trace the values of previousPrice and previousRateCardAttainment
                                tracingService.Trace($"previousPrice: {previousPrice?.ToString() ?? "null"}");
                                tracingService.Trace($"previousRateCardAttainment: {previousRateCardAttainment?.ToString() ?? "null"}");

                                // If previousPrice is 0, directly update niq_previousratecardattainment to 0
                                if (previousPrice != null && previousPrice.Value == 0)
                                {
                                    if (previousRateCardAttainment.Value == 0)
                                    {
                                        quote["niq_previousratecardattainment"] = null;
                                        tracingService.Trace("0/0. Setting niq_previousratecardattainment to null.");
                                    }
                                    else
                                    {
                                        quote["niq_previousratecardattainment"] = 0m;
                                        tracingService.Trace("previousPrice is 0. Setting niq_previousratecardattainment to 0.");
                                    }

                                }
                                // If both previousPrice and previousRateCardAttainment have values, calculate and update the field
                                else if (previousPrice != null && previousRateCardAttainment != null && previousRateCardAttainment.Value != 0)
                                {
                                    decimal calculatedValue = previousPrice.Value / previousRateCardAttainment.Value;
                                    quote["niq_previousratecardattainment"] = calculatedValue * 100;
                                    tracingService.Trace($"Calculated and updated niq_previousratecardattainment: {calculatedValue * 100}.");
                                }
                                // For all other cases (either previousPrice or previousRateCardAttainment is invalid), set niq_previousratecardattainment to null
                                else
                                {
                                    quote["niq_previousratecardattainment"] = null;
                                    tracingService.Trace("Invalid previousPrice or previousRateCardAttainment. Setting niq_previousratecardattainment to null.");
                                }
                            }


                            // Handle niq_proposedratecardattainment (formula)
                            if (existingquote.Contains("totalamount") && existingquote.Contains("niq_ratecardprice"))
                            {
                                Money rateCardPrice = existingquote["niq_ratecardprice"] as Money;

                                // Check if rateCardPrice and totalAmount are valid
                                if (rateCardPrice != null && existingquote["totalamount"] != null)
                                {
                                    Money quotetotalAmount = existingquote["totalamount"] as Money;

                                    // If quotetotalAmount is 0, directly set niq_proposedratecardattainment to 0
                                    if (quotetotalAmount.Value == 0)
                                    {
                                        if (rateCardPrice.Value == 0)
                                        {
                                            quote["niq_proposedratecardattainment"] = null;
                                            tracingService.Trace("As 0/0. Setting niq_proposedratecardattainment to null.");
                                        }
                                        else
                                        {
                                            quote["niq_proposedratecardattainment"] = 0m;
                                            tracingService.Trace("quotetotalAmount is 0. Setting niq_proposedratecardattainment to 0.");
                                        }

                                    }
                                    // If both quotetotalAmount and rateCardPrice have values, perform the calculation
                                    else if (quotetotalAmount.Value > 0 && rateCardPrice.Value > 0)
                                    {
                                        decimal proposedRateCardAttainment = quotetotalAmount.Value / rateCardPrice.Value;
                                        quote["niq_proposedratecardattainment"] = proposedRateCardAttainment * 100;
                                        tracingService.Trace($"Calculated and updated niq_proposedratecardattainment: {proposedRateCardAttainment * 100}.");
                                    }
                                    // For all other cases, set niq_proposedratecardattainment to null
                                    else
                                    {
                                        quote["niq_proposedratecardattainment"] = null;
                                        tracingService.Trace("Invalid quotetotalAmount or rateCardPrice. Setting niq_proposedratecardattainment to null.");
                                    }
                                }
                                else
                                {
                                    // If rateCardPrice or totalAmount is null, set the result to null
                                    quote["niq_proposedratecardattainment"] = null;
                                    tracingService.Trace("rateCardPrice or totalAmount is null. Setting niq_proposedratecardattainment to null.");
                                }
                            }
                            else
                            {
                                // If totalamount or niq_ratecardprice doesn't exist, set the result to null
                                quote["niq_proposedratecardattainment"] = null;
                                tracingService.Trace("totalamount or niq_ratecardprice doesn't exist. Setting niq_proposedratecardattainment to null.");
                            }





                            tracingService.Trace($"Assigned values for Quote ID: {quoteId} - " +
                            $"niq_previousratecardattainment: {item["niq_previousratecardattainment"]}, " +
                            $"niq_proposedratecardattainment: {quote["niq_proposedratecardattainment"]}");


                            // Handle niq_ddgpricingapprovallevel (formula)
                            if (item.ContainsKey("niq_overalldealscore") && string.IsNullOrEmpty(item["niq_overalldealscore"]?.ToString() ?? ""))
                            {
                                // If niq_overalldealscore is null or empty, set niq_ddgpricingapprovallevel to blank
                                quote["niq_ddgpricingapprovallevel"] = "";
                            }
                            else
                            {
                                // If niq_overalldealscore is not null or empty, apply the logic for "Dark Green"
                                quote["niq_ddgpricingapprovallevel"] = item["niq_overalldealscore"]?.ToString() == "Dark Green" ? "No Review Needed" : "Review Needed";
                            }

                            tracingService.Trace($"Assigned values for Quote ID: {quoteId} - " +
                            $"niq_overalldealscore: {item["niq_overalldealscore"]?.ToString() ?? "null"}, " +
                            $"niq_ddgpricingapprovallevel: {quote["niq_ddgpricingapprovallevel"]?.ToString() ?? "null"}");

                        }
                        else
                        {
                            tracingService.Trace("Error: Transaction Currency is missing in the Quote entity.");
                            resultMessage += "Error processing item: Transaction Currency is missing in the Quote entity\n";
                            throw new InvalidPluginExecutionException(resultMessage);
                        }
                    }
                    else
                    {
                        tracingService.Trace("Error: The totalamount field is missing or not of type Money.");
                        resultMessage += "Error processing item: The totalamount field is missing or not of type Money\n";
                        throw new InvalidPluginExecutionException(resultMessage);
                    }

                    //Handle the error exception if these two fields are null in MSD and null from Json
                    if (!(!existingquote.Contains("niq_contractduration") && string.IsNullOrEmpty(item["niq_contractduration"]?.ToString())))
                    {
                        quote["niq_contractduration"] = item["niq_contractduration"]?.ToString() ?? "";
                    }

                    if (!(!existingquote.Contains("niq_existingcontractaction") && string.IsNullOrEmpty(item["niq_existingcontractaction"]?.ToString())))
                    {
                        quote["niq_existingcontractaction"] = item["niq_existingcontractaction"]?.ToString() ?? "";
                    }

                    tracingService.Trace($"Assigned values for Quote ID: {quoteId} - " +
                    $"niq_contractduration: {item["niq_contractduration"]?.ToString() ?? "null"}, " +
                    $"niq_existingcontractaction: {item["niq_existingcontractaction"]?.ToString() ?? "null"}");

                    // Map All fields from JSON to Quote entity
                    quote["niq_overalldealscore"] = item.ContainsKey("niq_overalldealscore") && !string.IsNullOrEmpty(item["niq_overalldealscore"]?.ToString())
                        ? item["niq_overalldealscore"].ToString()
                        : null;
                    quote["niq_clientsegment"] = item.ContainsKey("niq_clientsegment") && !string.IsNullOrEmpty(item["niq_clientsegment"]?.ToString())
                        ? item["niq_clientsegment"].ToString()
                        : null;

                    quote["niq_industryforddg"] = item.ContainsKey("niq_industryforddg") && !string.IsNullOrEmpty(item["niq_industryforddg"]?.ToString())
                        ? item["niq_industryforddg"].ToString()
                        : null;

                    quote["niq_vertical"] = item.ContainsKey("niq_vertical") && !string.IsNullOrEmpty(item["niq_vertical"]?.ToString())
                        ? item["niq_vertical"].ToString()
                        : null;

                    quote["niq_rmscompetitor"] = item.ContainsKey("niq_rmscompetitor") && !string.IsNullOrEmpty(item["niq_rmscompetitor"]?.ToString())
                        ? item["niq_rmscompetitor"].ToString()
                        : null;

                    quote["niq_msa"] = item.ContainsKey("niq_msa") && !string.IsNullOrEmpty(item["niq_msa"]?.ToString())
                        ? item["niq_msa"].ToString().Replace("_GlobalMSA", "")
                        : null;

                    quote["niq_clienttenure"] = item.ContainsKey("niq_clienttenure") && !string.IsNullOrEmpty(item["niq_clienttenure"]?.ToString())
                        ? item["niq_clienttenure"].ToString()
                        : null;

                    quote["niq_transactiontypetext"] = item.ContainsKey("niq_transactiontypetext") && !string.IsNullOrEmpty(item["niq_transactiontypetext"]?.ToString())
                        ? item["niq_transactiontypetext"].ToString()
                        : null;

                    quote["niq_niq_dd_niq_priorprice"] = item.ContainsKey("niq_niq_dd_niq_priorprice") && !string.IsNullOrEmpty(item["niq_niq_dd_niq_priorprice"]?.ToString())
                        ? item["niq_niq_dd_niq_priorprice"].ToString()
                        : null;

                    quote["niq_dd_changeinscope"] = item.ContainsKey("niq_dd_changeinscope") && !string.IsNullOrEmpty(item["niq_dd_changeinscope"]?.ToString())
                        ? item["niq_dd_changeinscope"].ToString()
                        : null;

                    quote["niq_dd_niq_dso"] = item.ContainsKey("niq_dd_niq_dso") && !string.IsNullOrEmpty(item["niq_dd_niq_dso"]?.ToString())
                        ? item["niq_dd_niq_dso"].ToString()
                        : null;

                    quote["niq_dd_niq_smbdiscount"] = item.ContainsKey("niq_dd_niq_smbdiscount") && !string.IsNullOrEmpty(item["niq_dd_niq_smbdiscount"]?.ToString())
                        ? item["niq_dd_niq_smbdiscount"].ToString()
                        : null;

                    quote["niq_dd_niq_dealscoredstatus"] = item.ContainsKey("niq_dd_niq_dealscoredstatus") && !string.IsNullOrEmpty(item["niq_dd_niq_dealscoredstatus"]?.ToString())
                        ? item["niq_dd_niq_dealscoredstatus"].ToString()
                        : null;

                    quote["niq_dd_niq_priceguidance"] = item.ContainsKey("niq_dd_niq_priceguidance") && !string.IsNullOrEmpty(item["niq_dd_niq_priceguidance"]?.ToString())
                        ? item["niq_dd_niq_priceguidance"].ToString()
                        : null;


                    tracingService.Trace($"Assigned values for Quote ID: {quoteId} - " +
                   $"niq_overalldealscore: {item["niq_overalldealscore"]?.ToString() ?? "null"}, " +
                   $"niq_clientsegment: {item["niq_clientsegment"]?.ToString() ?? "null"}, " +
                   $"niq_industryforddg: {item["niq_industryforddg"]?.ToString() ?? "null"}, " +
                   $"niq_vertical: {item["niq_vertical"]?.ToString() ?? "null"}, " +
                   $"niq_rmscompetitor: {item["niq_rmscompetitor"]?.ToString() ?? "null"}, " +
                   $"niq_msa: {item["niq_msa"]?.ToString() ?? "null"}, " +
                   $"niq_clienttenure: {item["niq_clienttenure"]?.ToString() ?? "null"}, " +
                   $"niq_transactiontypetext: {item["niq_transactiontypetext"]?.ToString() ?? "null"}");

                    //Logic for the section Business Rules and Notes
                    string currentPriorPrice = quote.GetAttributeValue<string>("niq_niq_dd_niq_priorprice");
                    if (!string.IsNullOrEmpty(currentPriorPrice))
                    {
                        switch (currentPriorPrice)
                        {
                            case "Missing data":

                                quote["niq_niq_dd_niq_priorprice"] = $"{currentPriorPrice} - This opportunity could not be associated with a prior deal. Stop the review and inform seller they have to follow correct MSD process for renewals, by linking your Opportunity to previous year Opportunity.";
                                quote["niq_priorprice"] = "This opportunity could not be associated with a prior deal. Please make sure you have followed correct MSD process for renewals, by linking your Opportunity to previous year Opportunity.";
                                break;

                            case "Yes (triggered)":

                                quote["niq_niq_dd_niq_priorprice"] = $"{currentPriorPrice} - Rate card attainment decreased contract-over-contract. Deep-dive review to understand the rationale or change it.";
                                quote["niq_priorprice"] = "Rate card attainment decreased contract-over-contract. ";
                                break;

                            case "No":

                                quote["niq_niq_dd_niq_priorprice"] = currentPriorPrice;
                                quote["niq_priorprice"] = null;
                                break;

                            case "Not applicable":
                                quote["niq_niq_dd_niq_priorprice"] = currentPriorPrice;
                                quote["niq_priorprice"] = null;
                                break;
                        }
                    }
                    // For niq_changeinscope
                    string currentChangeInScope = quote.GetAttributeValue<string>("niq_dd_changeinscope");
                    if (!string.IsNullOrEmpty(currentChangeInScope))
                    {
                        switch (currentChangeInScope)
                        {
                            case "Missing data":
                                quote["niq_dd_changeinscope"] = $"{currentChangeInScope} - This opportunity could not be associated with a prior deal. Stop the review and inform seller they have to follow correct MSD process for renewals, by linking your Opportunity to previous year Opportunity.";
                                quote["niq_changeinscope"] = "This opportunity could not be associated with a prior deal. Please make sure you have followed correct MSD process for renewals, by linking your Opportunity to previous year Opportunity.";
                                break;

                            case "Yes (triggered)":
                                quote["niq_dd_changeinscope"] = $"{currentChangeInScope} - Deal scope decreased significantly compared to the prior contract. Ensure rate card attainment significantly increases in line with the Descoping policy";
                                quote["niq_changeinscope"] = "Deal scope decreased significantly compared to the prior contract. Make sure you follow the Descoping policy. ";
                                break;

                            case "No":
                                quote["niq_dd_changeinscope"] = currentChangeInScope;
                                quote["niq_changeinscope"] = null;
                                break;

                            case "Not applicable":
                                quote["niq_dd_changeinscope"] = currentChangeInScope;
                                quote["niq_changeinscope"] = null;
                                break;
                        }
                    }

                    // For niq_smbdiscount
                    string currentSmbDiscount = quote.GetAttributeValue<string>("niq_dd_niq_smbdiscount");
                    if (!string.IsNullOrEmpty(currentSmbDiscount))
                    {
                        switch (currentSmbDiscount)
                        {
                            case "Missing data":
                                quote["niq_dd_niq_smbdiscount"] = $"{currentSmbDiscount} - This opportunity comes from an SMB customer, but SMB discount information is not available. To ensure quick turnaround, talk to the seller, agree on correct MFG Tier, make sure seller reaches out to Price Setting team to update the MFG Tier and then approve.";
                                quote["niq_smbdiscount"] = "This opportunity comes from an SMB customer, but SMB discount information is not available. Please reach out to Deal Desk team.";
                                break;

                            case "Yes (triggered)":
                                quote["niq_dd_niq_smbdiscount"] = $"{currentSmbDiscount} - This opportunity offers a discount beyond that allowed by NIQ's SMB discount policy.  Deep-dive review to understand the rationale or change it.";
                                quote["niq_smbdiscount"] = "This opportunity offers a discount beyond that allowed by NIQ's SMB discount policy.";
                                break;

                            case "No":
                                quote["niq_dd_niq_smbdiscount"] = currentSmbDiscount;
                                quote["niq_smbdiscount"] = null;
                                break;

                            case "Not applicable":
                                quote["niq_dd_niq_smbdiscount"] = currentSmbDiscount;
                                quote["niq_smbdiscount"] = null;
                                break;
                        }
                    }

                    // For niq_dso
                    string currentDso = quote.GetAttributeValue<string>("niq_dd_niq_dso");
                    if (!string.IsNullOrEmpty(currentDso))
                    {
                        switch (currentDso)
                        {
                            case "Missing data":
                                quote["niq_dd_niq_dso"] = $"{currentDso} - This opportunity could not be associated with payment and billing terms. Stop the review and make sure seller updates the opportunity with payment and billing term information.";
                                quote["niq_dso"] = "This opportunity could not be associated with payment and billing terms. Please update the opportunity with payment and billing term information.";
                                break;

                            case "Yes (triggered)":
                                quote["niq_dd_niq_dso"] = $"{currentDso} - This opportunity offers out-of-policy payment and billing terms. Deep-dive review to understand the rationale or change it.";
                                quote["niq_dso"] = "This opportunity offers out-of-policy payment and billing terms.";
                                break;

                            case "No":
                                quote["niq_dd_niq_dso"] = currentDso;
                                quote["niq_dso"] = null;
                                break;

                            case "Not applicable":
                                quote["niq_dd_niq_dso"] = currentDso;
                                quote["niq_dso"] = null;
                                break;
                        }
                    }

                    // For niq_priceguidance based on niq_overalldealscore
                    string currentPriceGuidance = quote.GetAttributeValue<string>("niq_overalldealscore");
                    if (!string.IsNullOrEmpty(currentPriceGuidance))
                    {
                        switch (currentPriceGuidance)
                        {
                            case "Dark Green":
                                quote["niq_dd_niq_priceguidance"] = "No review is needed for this opportunity.";
                                quote["niq_priceguidance"] = "No review needed  - Consider whether there is opportunity to capture more price or to expand scope.";
                                break;

                            case "Light Green":
                                quote["niq_dd_niq_priceguidance"] = "This opportunity is subject to Deal Desk review. Offer the seller the cluster's Outperform target price as a baseline goal but encourage them to capture further price or expand scope if possible.";
                                quote["niq_priceguidance"] = "Review needed.";
                                break;

                            case "Yellow":
                                quote["niq_dd_niq_priceguidance"] = "This opportunity is subject to Deal Desk review.  Offer the seller the cluster's Outperform target price as a baseline goal but accept Base Target price as a walkaway.";
                                quote["niq_priceguidance"] = "Review needed ";
                                break;

                            case "Red":
                                quote["niq_dd_niq_priceguidance"] = "This opportunity is subject to Deal Desk review.  Offer the seller the cluster's Base Target price as a baseline goal but accept Underperform Target price as a walkaway.";
                                quote["niq_priceguidance"] = "Review needed ";
                                break;
                        }
                    }

                    // For niq_dealscoredstatus
                    string currentDealScoreStatus = quote.GetAttributeValue<string>("niq_dd_niq_dealscoredstatus");
                    if (!string.IsNullOrEmpty(currentDealScoreStatus))
                    {
                        switch (currentDealScoreStatus)
                        {
                            case "Yes":
                                quote["niq_dd_niq_dealscoredstatus"] = "Sellers should start their negotiations higher to be able to close at or above the target price, defined for each cluster. For opportunities priced below Outperform target price, the seller should notify the customer that NIQ expects to charge market price for future opportunities.";
                                quote["niq_dealscoredstatus"] = null;
                                break;

                            case "No":
                                quote["niq_dd_niq_dealscoredstatus"] = "Deal information has some missing data. Perform review only when seller  updates the opportunity with  missing data.";
                                quote["niq_dealscoredstatus"] = "Deal information has some missing data. Please make sure you have followed correct MSD input process for your opportunity type.";
                                break;


                        }
                    }
                    tracingService.Trace($"Assigned values for Quote ID: {quoteId} - " +
                   $"niq_niq_dd_niq_priorprice: {(item.ContainsKey("niq_niq_dd_niq_priorprice") ? item["niq_niq_dd_niq_priorprice"] ?? "null" : "null")}, " +
                   $"niq_dd_changeinscope: {(item.ContainsKey("niq_dd_changeinscope") ? item["niq_dd_changeinscope"] ?? "null" : "null")}, " +
                   $"niq_dd_niq_dso: {(item.ContainsKey("niq_dd_niq_dso") ? item["niq_dd_niq_dso"] ?? "null" : "null")}, " +
                   $"niq_dd_niq_smbdiscount: {(item.ContainsKey("niq_dd_niq_smbdiscount") ? item["niq_dd_niq_smbdiscount"] ?? "null" : "null")}, " +
                   $"niq_dd_niq_dealscoredstatus: {(item.ContainsKey("niq_dd_niq_dealscoredstatus") ? item["niq_dd_niq_dealscoredstatus"] ?? "null" : "null")}");

                    // Handle cluster field (Whole number)
                    string quoteclusterNumber = "niq_clusternumber";

                    // Get value from 'item'
                    var clusterValue = item.ContainsKey(quoteclusterNumber) ? item[quoteclusterNumber]?.ToString() : null;

                    // Set field to null if the value is empty or invalid, otherwise assign valid number
                    if (string.IsNullOrEmpty(clusterValue) || !int.TryParse(clusterValue, out int clusterNumber))
                    {
                        quote[quoteclusterNumber] = 0;  // Use null for nullable integer field
                        tracingService.Trace("niq_clusternumber is empty or invalid. Field set to null.");
                    }
                    else
                    {
                        quote[quoteclusterNumber] = clusterNumber;  // Assign valid number
                        tracingService.Trace($"Assigned {clusterNumber} to niq_clusternumber.");
                    }


                    // Retrieve the price band score from CIS
                    var priceBandScoreCIS = item["niq_pricebandscore"]?.ToString() ?? "";

                    // Declare a variable to hold the value to update in MSD
                    string priceBandScoreMSD = "";

                    // Map the value based on the given table
                    switch (priceBandScoreCIS)
                    {
                        case "Dark Green":
                            priceBandScoreMSD = "Outperforming";
                            break;
                        case "Light Green":
                            priceBandScoreMSD = "Above Base Target";
                            break;
                        case "Yellow":
                            priceBandScoreMSD = "Below Base Target";
                            break;
                        case "Red":
                            priceBandScoreMSD = "Underperforming";
                            break;
                        default:
                            priceBandScoreMSD = ""; // In case of an unexpected value
                            break;
                    }

                    // Update the field in MSD
                    quote["niq_pricebandscore"] = priceBandScoreMSD;
                    tracingService.Trace($"Assigned value to niq_pricebandscore: {item["niq_pricebandscore"]} for Quote ID: {quoteId}");


                    // Copy totalamount to niq_proposedprice 
                    Money existingtotalAmount = existingquote["totalamount"] as Money; // Ensure this is declared only once
                    if (existingtotalAmount != null && existingtotalAmount.Value != 0)
                    {
                        quote["niq_proposedprice"] = existingtotalAmount;
                        tracingService.Trace("copied totalamount to niq_proposedprice ");
                    }
                    else if (existingtotalAmount.Value == 0)
                    {
                        quote["niq_proposedprice"] = 0m;
                        tracingService.Trace("copied totalamount to niq_proposedprice as 0 ");
                    }
                    else
                    {
                        quote["niq_proposedprice"] = null;
                        tracingService.Trace("copied totalamount to niq_proposedprice as null ");
                    }

                    tracingService.Trace($"Assigned value for niq_proposedprice: {(quote.Contains("niq_proposedprice") && quote["niq_proposedprice"] is Money proposedPrice ? proposedPrice.Value.ToString() : "null")} from existing quote totalamount: {(existingtotalAmount != null ? existingtotalAmount.Value.ToString() : "null")} for Quote ID: {quoteId}");

                    // Retrieve the Opportunity entity to copy fields
                    Entity opportunity = service.Retrieve("opportunity", opportunityId.Value, new ColumnSet("parentaccountid", "niq_opportunitytype", "name", "niq_valueofproductenhancements", "statecode", "niq_dealguidanceerrortimestampopp", "ownerid", "niq_opportunitynumber", "opportunityid"));
                    if (opportunity == null)
                    {
                        tracingService.Trace("Error: Opportunity with ID {0} not found.", opportunityId);
                        resultMessage += $"Error processing item: Opportunity with ID {opportunityId} not found\n";
                        throw new InvalidPluginExecutionException(resultMessage);
                    }

                    // Retrieve the associated Account ID from the parentaccountid lookup field
                    if (opportunity.Contains("parentaccountid") && opportunity["parentaccountid"] is EntityReference accountRef)
                    {
                        // Retrieve the Account entity to get the Account Name
                        Entity account = service.Retrieve(accountRef.LogicalName, accountRef.Id, new ColumnSet("name"));
                        if (account != null) // No need to check if 'account' is null, since Retrieve will throw an exception if not found
                        {
                            // Set the Account Name (From opportunity) to the niq_accountname field (Quote)
                            quote["niq_accountname"] = account["name"]?.ToString() ?? "";
                            tracingService.Trace($"Assigned value for niq_accountname: {quote["niq_accountname"]?.ToString() ?? "null"} from account name: {account["name"]?.ToString() ?? "null"} for Quote ID: {quoteId}");
                        }
                        else
                        {
                            tracingService.Trace($"Error: Account with ID {accountRef.Id} not found.");
                            resultMessage += $"Error processing item: Account with ID {accountRef.Id} not found\n";
                            throw new InvalidPluginExecutionException(resultMessage);
                        }
                    }

                    // Handle the opportunity type (OptionSetValue) and map to a string value for the Quote
                    if (opportunity.Contains("niq_opportunitytype") && opportunity["niq_opportunitytype"] is OptionSetValue opportunityType)
                    {
                        string opportunityTypeString = MapOpportunityTypeToString(opportunityType.Value);
                        quote["niq_opportunitytype"] = opportunityTypeString;
                        tracingService.Trace($"Assigned opportunity type '{opportunityTypeString}' to niq_opportunitytype for Quote ID: {quoteId}");
                    }
                    else
                    {
                        quote["niq_opportunitytype"] = null;
                        tracingService.Trace($"No opportunity type found. Set niq_opportunitytype to null for Quote ID: {quoteId}");
                    }

                    // Handle niq_pe (calculated based on niq_valueofproductenhancements from Opportunity and niq_ratecardprice from Quote)
                    if (opportunity.Contains("niq_valueofproductenhancements") && existingquote.Contains("niq_ratecardprice"))
                    {
                        // Retrieve niq_valueofproductenhancements from Opportunity and niq_ratecardprice from Quote
                        Money niq_valueofproductenhancements = opportunity.Contains("niq_valueofproductenhancements") ? (Money)opportunity["niq_valueofproductenhancements"] : null;
                        Money niq_ratecardprice = existingquote.Contains("niq_ratecardprice") ? (Money)existingquote["niq_ratecardprice"] : null;

                        // Trace the values of niq_valueofproductenhancements and niq_ratecardprice
                        tracingService.Trace($"niq_valueofproductenhancements: {niq_valueofproductenhancements?.Value.ToString() ?? "null"}");
                        tracingService.Trace($"niq_ratecardprice: {niq_ratecardprice?.Value.ToString() ?? "null"}");

                        // If niq_valueofproductenhancements is 0, set niq_pe to 0
                        if (niq_valueofproductenhancements != null && niq_valueofproductenhancements.Value == 0)
                        {
                            if (niq_ratecardprice.Value == 0)
                            {
                                quote["niq_pe"] = null;
                                tracingService.Trace($"As 0/0 . Setting niq_pe to null. Quote ID: {quoteId}");
                            }
                            else
                            {
                                quote["niq_pe"] = 0m;
                                tracingService.Trace($"niq_valueofproductenhancements is 0. Setting niq_pe to 0. Quote ID: {quoteId}");
                            }

                        }
                        // If niq_ratecardprice is 0 and niq_valueofproductenhancements has a value, set niq_pe to null
                        else if (niq_ratecardprice != null && niq_ratecardprice.Value == 0 && niq_valueofproductenhancements != null && niq_valueofproductenhancements.Value != 0)
                        {
                            quote["niq_pe"] = null;
                            tracingService.Trace($"niq_ratecardprice is 0 and niq_valueofproductenhancements has a value. Setting niq_pe to null. Quote ID: {quoteId}");
                        }
                        // If both niq_valueofproductenhancements and niq_ratecardprice are valid, calculate niq_pe
                        else if (niq_valueofproductenhancements != null && niq_ratecardprice != null && niq_valueofproductenhancements.Value != 0 && niq_ratecardprice.Value != 0)
                        {
                            decimal calculatedValue = niq_valueofproductenhancements.Value / niq_ratecardprice.Value;
                            quote["niq_pe"] = calculatedValue * 100;
                            tracingService.Trace($"Calculated and updated niq_pe: {calculatedValue * 100}. Quote ID: {quoteId}");
                        }
                        // For any other cases (either value is missing or invalid), set niq_pe to null
                        else
                        {
                            quote["niq_pe"] = null;
                            tracingService.Trace($"Invalid values for niq_valueofproductenhancements or niq_ratecardprice. Setting niq_pe to null. Quote ID: {quoteId}");
                        }
                    }
                    else
                    {
                        // If either niq_valueofproductenhancements or niq_ratecardprice is missing, set niq_pe to null
                        quote["niq_pe"] = null;
                        tracingService.Trace($"Missing niq_valueofproductenhancements from Opportunity or niq_ratecardprice from Quote. Setting niq_pe to null. Quote ID: {quoteId}");
                    }




                    // Trace logs for debugging
                    tracingService.Trace("Successfully updated Quote: {0}, Opportunity: {1}",
                        existingquote["quotenumber"], opportunity["name"]);
                }

                // Iterate through each item in the deal scoring output(2)
                foreach (JObject item in dealScoringOutput)
                {

                    // Check if "quoteId" exists before processing the item
                    if (!item.ContainsKey("quoteId"))
                    {
                        tracingService.Trace("Error: Missing quoteId in the item.");
                        resultMessage += $"Error processing item: Missing quoteId\n";
                        throw new InvalidPluginExecutionException(resultMessage);
                    }

                    Guid? opportunityId = item["opportunityId"]?.ToObject<Guid>();
                    quoteId = item["quoteId"]?.ToObject<Guid>();

                    // Validate if opportunityId and quoteId exist
                    if (opportunityId == null || quoteId == null)
                    {
                        tracingService.Trace("Error: Opportunity ID or Quote ID is missing or empty.");
                        resultMessage += $"Error processing item: Opportunity ID or Quote ID is missing or empty\n";
                        throw new InvalidPluginExecutionException(resultMessage);
                    }

                    // Get clusterNumber and transactionTypeText from the item
                    string clusterNumber = item["niq_clusternumber"]?.ToString();
                    string transactionTypeText = item["niq_transactiontypetext"]?.ToString();
                    var currentQuoteId = quoteId.Value.ToString();
                    // Instantiate QueryExpression query
                    var stepAquery = new QueryExpression("quote");
                    stepAquery.Distinct = true;
                    stepAquery.ColumnSet.AddColumns("niq_proposedratecardattainment", "niq_mainquote", "niq_discount", "niq_transactiontypetext", "niq_clusternumber", "niq_dealscoringinprogress", "quoteid");


                    // Add conditions to query.Criteria
                    stepAquery.Criteria.AddCondition("niq_mainquote", ConditionOperator.Equal, true);
                    stepAquery.Criteria.AddCondition("niq_transactiontypetext", ConditionOperator.Equal, transactionTypeText ?? "");
                    if (string.IsNullOrEmpty(clusterNumber))
                    {
                        stepAquery.Criteria.AddCondition("niq_clusternumber", ConditionOperator.Null);
                    }
                    else
                    {
                        stepAquery.Criteria.AddCondition("niq_clusternumber", ConditionOperator.Equal, clusterNumber);
                    }
                    stepAquery.Criteria.AddCondition("quoteid", ConditionOperator.NotEqual, currentQuoteId);

                    // Add link-entity Opportunity
                    var Opportunity = stepAquery.AddLink("opportunity", "opportunityid", "opportunityid");
                    Opportunity.EntityAlias = "Opportunity";

                    // Add conditions to Opportunity.LinkCriteria
                    Opportunity.LinkCriteria.AddCondition("statecode", ConditionOperator.Equal, 1);

                    // Add link-entity QuoteProduct to retrieve quote product details
                    var QuoteProduct = stepAquery.AddLink("quotedetail", "quoteid", "quoteid");
                    QuoteProduct.EntityAlias = "QuoteProduct";
                    QuoteProduct.Columns.AddColumn("niq_databasename");


                    // Retrieve all the quotes
                    EntityCollection allQuotes = service.RetrieveMultiple(stepAquery);

                    //var groupbyquote =  
                    var groupedQuotes = allQuotes.Entities
                    .GroupBy(q => q.Id)
                    .Select(g => new
                    {
                        QuoteId = g.Key,
                        Quotes = g.ToList()
                    });


                    // Initialize a list to store the filtered quotes
                    var quoteEntities = new List<Entity>();

                    // Iterate through the grouped quotes and apply the conditions
                    foreach (var group in groupedQuotes)
                    {
                        bool hasDatabaseName = group.Quotes.Any(q => q.Contains("QuoteProduct.niq_databasename"));
                        bool hasNonZeroDiscount = group.Quotes.Any(q => q.Contains("niq_discount") && (decimal)q["niq_discount"] != 0);

                        if (hasDatabaseName || (!hasDatabaseName && hasNonZeroDiscount))
                        {
                            // Add the quote to the list if it meets the conditions
                            quoteEntities.AddRange(group.Quotes);
                        }
                    }

                    // Remove duplicate quotes
                    quoteEntities = quoteEntities.GroupBy(q => q.Id).Select(g => g.First()).ToList();
                    // Log the results of filtered quotes
                    string quoteIdsLog = string.Join(", ", quoteEntities.Select(q => q.GetAttributeValue<Guid>("quoteid")));
                    //tracingService.Trace("Quotes found in quote query: {0}. Quote IDs: {1}", quoteEntities.Count, quoteIdsLog);


                    // Step 2: Compare the proposed rate card attainment to all valid quotes
                    decimal updatedProposedRateCardAttainment = Convert.ToDecimal(quote["niq_proposedratecardattainment"] ?? 0);
                    List<Entity> validquotes = new List<Entity>();

                    tracingService.Trace("Comparing proposedRateCardAttainment with the current quote's proposed rate card attainment: {0}", updatedProposedRateCardAttainment);

                    // Filter valid quotes based on the proposed rate card attainment
                    validquotes = quoteEntities.Where(q =>
                    {
                        decimal proposedRateCardAttainment = q.Contains("niq_proposedratecardattainment")
                            ? Convert.ToDecimal(q["niq_proposedratecardattainment"] ?? 0)
                            : 0;
                        return proposedRateCardAttainment > updatedProposedRateCardAttainment;
                    }).ToList();

                    // Trace the count of valid quotes in Step A and Step B
                    tracingService.Trace("Step A: {0} valid quotes found.", quoteEntities.Count);
                    tracingService.Trace("Step B: {0} valid quotes found with proposed rate card attainment greater than current quote's.", validquotes.Count);

                    // Step 3: Calculate the percentage for deals above quoted price
                    decimal stepBCount = validquotes.Count();
                    decimal stepACount = quoteEntities.Count();
                    if (stepACount > 0)
                    {
                        // Calculate the percentage if stepACount > 0
                        decimal dealsAboveQuotedPriceAttainment = (stepBCount / stepACount) * 100;
                        quote["niq_dealsaboveyourquotedpriceattainment"] = dealsAboveQuotedPriceAttainment;

                        // Trace the calculation of the percentage
                        tracingService.Trace("Calculated niq_dealsaboveyourquotedpriceattainment: {0}%", dealsAboveQuotedPriceAttainment);
                    }
                    else
                    {
                        // If no valid quotes (stepACount is 0), set the attainment value to zero
                        quote["niq_dealsaboveyourquotedpriceattainment"] = 0m;

                        // Trace the case where stepACount is 0
                        tracingService.Trace("No valid quotes found. Set niq_dealsaboveyourquotedpriceattainment to Zero");
                    }
                    // Trace the result for deals above quoted price
                    tracingService.Trace("Updated Quote: {0}, Opportunity: {1}, Deals Above Quoted Price Attainment: {2}%",
                        existingquote["quotenumber"], opportunityId, quote["niq_dealsaboveyourquotedpriceattainment"]);

                    tracingService.Trace("Going to update the quote");

                    // Update the Quote entity
                    quote["niq_dealscoringinprogress"] = false;
                    // Try updating the quote and catch any potential errors
                    try
                    {
                        service.Update(quote);

                        tracingService.Trace("Updated niq_dealscoringinprogress: " + quote["niq_dealscoringinprogress"]);

                        tracingService.Trace("Successfully updated CIS - MSD Fields");

                        context.OutputParameters["niq_CISMSDDealScoringOutputResponse"] = "Processing for Success is completed successfully.";

                    }
                    catch (Exception ex)
                    {
                        // If update fails, log the exception message
                        tracingService.Trace("Error updating quote: " + ex.Message);
                        context.OutputParameters["niq_CISMSDDealScoringOutputResponse"] = $"Error occurred during update: {ex.Message}";
                        return;
                    }



                }
            }
            catch (Exception ex)
            {
                isSuccess = false;
                resultMessage += $"Error processing quoteId: {quoteId} - {ex.Message}\n";
                context.OutputParameters["niq_CISMSDDealScoringOutputResponse"] = $"Error occurred during update: {ex.Message}";
                throw new InvalidPluginExecutionException(ex.Message);
            }

        }

        // Helper method to safely parse decimal values and return null if value is empty
        private Money SetDecimalToNullIfEmpty(JObject item, string fieldName)
        {
            if (item[fieldName] == null || string.IsNullOrEmpty(item[fieldName]?.ToString()))
            {
                return null;  // Return null if the field is empty or null
            }
            else
            {
                decimal parsedValue;
                if (Decimal.TryParse(item[fieldName]?.ToString(), out parsedValue))
                {
                    return new Money(parsedValue);
                }
                return new Money(0);  // Return 0 if unable to parse
            }
        }

        // Method to map OptionSetValue to string representation
        private string MapOpportunityTypeToString(int optionSetValue)
        {
            switch (optionSetValue)
            {
                case 1:
                    return "Completely New Sale";
                case 2:
                    return "Existing Contract Management";
                default:
                    return "Unknown"; // You can handle default cases as needed
            }
        }
    }
}
