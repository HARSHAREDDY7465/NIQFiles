﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
namespace NielsenIQ.CRM.Plugins
{
    public class OnScheduleCompletion_CreateQPS : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(null);
                if (context.Depth > 1)
                {
                    tracing.Trace("depth->" + context.Depth);
                    return;
                }

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnScheduleCompletion_CreateQPS: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity entityObj = (Entity)context.InputParameters["Target"];

                    if (entityObj != null && entityObj.Id != Guid.Empty && entityObj.LogicalName == "quotedetail" && entityObj.Attributes.Contains("niq_ismodified") && entityObj.GetAttributeValue<string>("niq_ismodified") == "Completed")
                    {
                        tracing.Trace("OnScheduleCompletion_CreateQPS: qp id" + entityObj.Id);
                        tracing.Trace("OnScheduleCompletion_CreateQPS: isModified = Completed ");
                        string fetchQPSXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='niq_quotepaymentschedule'>
                                                                <attribute name='niq_quotepaymentscheduleid' />
                                                                <attribute name='niq_name' />
                                                                <attribute name='createdon' />
                                                                <order attribute='niq_name' descending='false' />
                                                                <filter type='and'>
                                                                  <condition attribute='niq_quoteproductid' operator='eq' uitype='quotedetail' value='{0}' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";
                        fetchQPSXml = string.Format(fetchQPSXml, entityObj.Id);
                        var resultQPS = service.RetrieveMultiple(new FetchExpression(fetchQPSXml));
                        if (resultQPS != null && resultQPS.Entities != null && resultQPS.Entities.Count > 0)
                        {
                            foreach (Entity qpsobj in resultQPS.Entities)
                            {
                                service.Delete(qpsobj.LogicalName, qpsobj.Id);
                            }
                        }
                        Entity retQP = service.Retrieve(entityObj.LogicalName, entityObj.Id, new ColumnSet("niq_billingfrequency", "productid", "niq_lineitemstartdate", "niq_lineitemenddate", "extendedamount", "quoteid"));

                        if (retQP != null && retQP.Id != Guid.Empty && retQP.Attributes.Contains("niq_lineitemenddate") && retQP.Attributes.Contains("productid") && retQP.GetAttributeValue<EntityReference>("productid").Id != Guid.Empty && retQP.Attributes.Contains("quoteid") && retQP.GetAttributeValue<EntityReference>("quoteid").Id != Guid.Empty && retQP.Attributes.Contains("niq_lineitemstartdate") && retQP.GetAttributeValue<OptionSetValue>("niq_billingfrequency") != null && (retQP.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value == 100000000 || retQP.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value == 100000002 || retQP.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value == 100000003 || retQP.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value == 100000005))
                        {
                            tracing.Trace("OnScheduleCompletion_CreateQPS: ret qp" + retQP.Id);
                            Entity retQuote = service.Retrieve(retQP.GetAttributeValue<EntityReference>("quoteid").LogicalName, retQP.GetAttributeValue<EntityReference>("quoteid").Id, new ColumnSet("niq_annualapicola", "transactioncurrencyid", "niq_annualincreasetype", "niq_agreementtype"));

                            if (retQuote != null && retQuote.Id != Guid.Empty && retQuote.Attributes.Contains("niq_agreementtype") && retQuote.GetAttributeValue<OptionSetValue>("niq_agreementtype") != null && (retQuote.GetAttributeValue<OptionSetValue>("niq_agreementtype").Value == 100000001 || retQuote.GetAttributeValue<OptionSetValue>("niq_agreementtype").Value == 100000002))
                            {
                                tracing.Trace("OnScheduleCompletion_CreateQPS: ret quote" + retQuote.Id);

                                int billingFreq = retQP.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value;
                                tracing.Trace("OnScheduleCompletion_CreateQPS: billing freq" + billingFreq);
                                int divisor = -1;
                                switch (billingFreq)
                                {
                                    case 100000000:
                                        tracing.Trace("OnScheduleCompletion_CreateQPS: freq Monthly");
                                        divisor = 12;
                                        break;
                                    case 100000002:
                                        tracing.Trace("OnScheduleCompletion_CreateQPS: freq quterly");
                                        divisor = 4;
                                        break;
                                    case 100000003:
                                        tracing.Trace("OnScheduleCompletion_CreateQPS: freq half yearly");
                                        divisor = 2;
                                        break;
                                    case 100000005:
                                        tracing.Trace("OnScheduleCompletion_CreateQPS: freq Yearly");
                                        divisor = 1;
                                        break;

                                }
                                if (divisor > 0)
                                {
                                    decimal annualApi = 0;
                                    if (retQuote.Attributes.Contains("niq_annualincreasetype") && retQuote.GetAttributeValue<OptionSetValue>("niq_annualincreasetype") != null && retQuote.GetAttributeValue<OptionSetValue>("niq_annualincreasetype").Value == 100000000 && retQuote.Attributes.Contains("niq_annualapicola"))
                                    {
                                        annualApi = (decimal)retQuote.GetAttributeValue<decimal>("niq_annualapicola");
                                        tracing.Trace("OnScheduleCompletion_CreateQPS: annualapi" + annualApi);
                                    }

                                    bool isFundingType = false;
                                    if (retQP.Attributes.Contains("productid") && retQP.GetAttributeValue<EntityReference>("productid").Id != Guid.Empty)
                                    {
                                        string fetchProductXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                                          <entity name='product'>
                                                            <attribute name='name' />
                                                            <attribute name='productnumber' />
                                                            <attribute name='description' />
                                                            <attribute name='statecode' />
                                                            <attribute name='modifiedon' />
                                                            <attribute name='productid' />
                                                            <order attribute='name' descending='false' />
                                                            <filter type='and'>
                                                              <filter type='or'>
                                                                <condition attribute='productnumber' operator='like' value='%MATCHED-FUND%' />
                                                                <condition attribute='productnumber' operator='like' value='%CLIENT-FUND%' />
                                                                <condition attribute='productnumber' operator='like' value='%NIELSEN-FUND%' />
                                                              </filter>
                                                            </filter>
                                                            <link-entity name='quotedetail' from='productid' to='productid' link-type='inner' alias='ac'>
                                                              <filter type='and'>
                                                                <condition attribute='productid' operator='eq' uitype='product' value='{0}' />
                                                              </filter>
                                                            </link-entity>
                                                          </entity>
                                                        </fetch>";
                                        fetchProductXml = string.Format(fetchProductXml, retQP.GetAttributeValue<EntityReference>("productid").Id);
                                        var resultProd = service.RetrieveMultiple(new FetchExpression(fetchProductXml));
                                        if (resultProd != null && resultProd.Entities != null && resultProd.Entities.Count > 0)
                                        {
                                            tracing.Trace("OnScheduleCompletion_CreateQPS: result prod count" + resultProd.Entities.Count);
                                            isFundingType = true;
                                        }
                                    }
                                    tracing.Trace("OnScheduleCompletion_CreateQPS:isfundingType " + isFundingType);
                                    DateTime startDate = retQP.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                                    tracing.Trace("OnScheduleCompletion_CreateQPS: start date " + startDate);
                                    DateTime endDate = retQP.GetAttributeValue<DateTime>("niq_lineitemenddate");
                                    tracing.Trace("OnScheduleCompletion_CreateQPS: end date " + endDate);
                                    int years = endDate.Year - startDate.Year;
                                    tracing.Trace("OnScheduleCompletion_CreateQPS: years " + years);
                                    DateTime currentDate = startDate;
                                    tracing.Trace("OnScheduleCompletion_CreateQPS: current date " + currentDate);
                                    DateTime lastDateOfYear = startDate.AddMonths(12);
                                    lastDateOfYear = lastDateOfYear.AddDays(-1);
                                    tracing.Trace("OnScheduleCompletion_CreateQPS: last date of year " + lastDateOfYear);
                                    DateTime firstDateOfYear = new DateTime(currentDate.Year, 01, 01);
                                    tracing.Trace("OnScheduleCompletion_CreateQPS:first date of year " + firstDateOfYear);
                                    decimal fp_FY1 = retQP.GetAttributeValue<Money>("extendedamount").Value;
                                    decimal netPerYear = retQP.GetAttributeValue<Money>("extendedamount").Value;
                                    tracing.Trace("OnScheduleCompletion_CreateQPS: fp_FY1 " + fp_FY1);
                                    Entity createQPS = new Entity("niq_quotepaymentschedule");
                                    bool isEnd = false;

                                    string currencyCode = "";
                                    if (retQuote.Attributes.Contains("transactioncurrencyid") && retQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id != Guid.Empty)
                                    {
                                        Entity currency = service.Retrieve(retQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").LogicalName, retQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id, new ColumnSet("isocurrencycode"));
                                        if (currency != null && currency.Id != Guid.Empty && currency.Attributes.Contains("isocurrencycode"))
                                        {
                                            currencyCode = currency.GetAttributeValue<string>("isocurrencycode");
                                        }
                                    }

                                    for (int i = 0; i <= years; i++)
                                    {
                                        if (!isEnd)
                                        {
                                            tracing.Trace("OnScheduleCompletion_CreateQPS: i = " + i);
                                            int result = DateTime.Compare(endDate, lastDateOfYear);
                                            tracing.Trace("OnScheduleCompletion_CreateQPS: result " + result);
                                            if (i == 0)
                                            {
                                                createQPS["transactioncurrencyid"] = new EntityReference(retQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").LogicalName, retQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                                                createQPS["niq_isocurrencycode"] = currencyCode;
                                                createQPS["niq_startdateofyear"] = startDate;
                                                tracing.Trace("OnScheduleCompletion_CreateQPS:startdate" + startDate);

                                                if (result <= 0)
                                                {
                                                    tracing.Trace("OnScheduleCompletion_CreateQPS:enddate" + endDate);
                                                    createQPS["niq_enddateofyear"] = endDate;
                                                    createQPS["niq_name"] = currentDate.ToString("MM/dd/yyyy") + "-" + endDate.ToString("MM/dd/yyyy");
                                                    isEnd = true;
                                                }
                                                else
                                                {

                                                    tracing.Trace("OnScheduleCompletion_CreateQPS:enddate lastday" + lastDateOfYear);
                                                    createQPS["niq_enddateofyear"] = lastDateOfYear;
                                                    createQPS["niq_name"] = currentDate.ToString("MM/dd/yyyy") + "-" + lastDateOfYear.ToString("MM/dd/yyyy");
                                                    lastDateOfYear = lastDateOfYear.AddMonths(12);
                                                    firstDateOfYear = firstDateOfYear.AddMonths(12);
                                                    currentDate = currentDate.AddMonths(12);
                                                }
                                                tracing.Trace("OnScheduleCompletion_CreateQPS:balance " + (fp_FY1 / divisor));
                                                fp_FY1 = fp_FY1 / divisor;
                                                createQPS["niq_netperyearcharge"] = new Money((decimal)netPerYear);
                                                if (isFundingType)
                                                {
                                                    createQPS["niq_fundpaymentperbillingfrequency"] = new Money((decimal)(fp_FY1));
                                                }
                                                else
                                                {
                                                    createQPS["niq_nonfundpaymentperbillingfrequency"] = new Money((decimal)(fp_FY1 / divisor));
                                                }
                                                createQPS["niq_year"] = (int)(i + 1);
                                                createQPS["niq_synctoclm"] = false;
                                                createQPS["niq_quoteproductid"] = new EntityReference(retQP.LogicalName, retQP.Id);
                                                createQPS["niq_quoteid"] = new EntityReference(retQuote.LogicalName, retQuote.Id);


                                            }
                                            else
                                            {
                                                createQPS["transactioncurrencyid"] = new EntityReference(retQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").LogicalName, retQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                                                createQPS["niq_isocurrencycode"] = currencyCode;
                                                tracing.Trace("OnScheduleCompletion_CreateQPS:inside else i =" + i);
                                                int isLastDay = DateTime.Compare(endDate, lastDateOfYear);
                                                tracing.Trace("OnScheduleCompletion_CreateQPS:islastday " + isLastDay);

                                                tracing.Trace("OnScheduleCompletion_CreateQPS:startdate " + currentDate);
                                                createQPS["niq_startdateofyear"] = currentDate;
                                                if (isLastDay <= 0)
                                                {
                                                    tracing.Trace("OnScheduleCompletion_CreateQPS:end date " + endDate);
                                                    createQPS["niq_enddateofyear"] = endDate;
                                                    createQPS["niq_name"] = currentDate.ToString("MM/dd/yyyy") + "-" + endDate.ToString("MM/dd/yyyy");
                                                    isEnd = true;
                                                }
                                                else
                                                {

                                                    tracing.Trace("OnScheduleCompletion_CreateQPS:last day of year" + lastDateOfYear);
                                                    createQPS["niq_enddateofyear"] = lastDateOfYear;
                                                    createQPS["niq_name"] = currentDate.ToString("MM/dd/yyyy") + "-" + lastDateOfYear.ToString("MM/dd/yyyy");

                                                    lastDateOfYear = lastDateOfYear.AddYears(1);
                                                    firstDateOfYear = firstDateOfYear.AddYears(1);
                                                    currentDate = currentDate.AddYears(1);
                                                }
                                                fp_FY1 += (fp_FY1 * annualApi) / 100;
                                                netPerYear += (netPerYear * annualApi) / 100;
                                                tracing.Trace("OnScheduleCompletion_CreateQPS:fp+fy" + (i + 1) + " " + fp_FY1);
                                                createQPS["niq_netperyearcharge"] = new Money((decimal)netPerYear);
                                                if (isFundingType)
                                                {
                                                    createQPS["niq_fundpaymentperbillingfrequency"] = new Money((decimal)fp_FY1);
                                                }
                                                else
                                                {
                                                    createQPS["niq_nonfundpaymentperbillingfrequency"] = new Money((decimal)fp_FY1);
                                                }
                                                createQPS["niq_year"] = (int)(i + 1);
                                                createQPS["niq_quoteproductid"] = new EntityReference(retQP.LogicalName, retQP.Id);
                                                createQPS["niq_quoteid"] = new EntityReference(retQuote.LogicalName, retQuote.Id);

                                                createQPS["niq_synctoclm"] = false;
                                            }
                                            service.Create(createQPS);
                                        }
                                    }

                                }
                            }
                        }

                        Entity updQuoteProd = new Entity(entityObj.LogicalName, entityObj.Id);
                        updQuoteProd["niq_isqpscompleted"] = true;
                        service.Update(updQuoteProd);

                    }

                    if (entityObj != null && entityObj.Id != Guid.Empty && entityObj.LogicalName == "quote")
                    {
                        Entity retQuote = service.Retrieve(entityObj.LogicalName, entityObj.Id, new ColumnSet("niq_annualapicola", "transactioncurrencyid", "niq_annualincreasetype", "niq_agreementtype"));
                        if (retQuote != null && retQuote.Id != Guid.Empty)
                        {
                            string fetchQuotesXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='quotedetail'>
                                                            <attribute name='quotedetailname' />
                                                            <attribute name='quotedetailid' />
                                                            <attribute name='niq_ismodified' />
                                                            <attribute name='niq_billingfrequency' />
                                                            <attribute name='niq_iscreatedrun' />
                                                            <order attribute='niq_brandid' descending='false' />
                                                            <filter type='and'>                                                             
                                                              <condition attribute='niq_ismodified' operator='eq' value='Completed' />
                                                              <condition attribute='quoteid' operator='eq' uitype='quote' value='{0}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                            fetchQuotesXml = string.Format(fetchQuotesXml, entityObj.Id);
                            var resultQuotes = service.RetrieveMultiple(new FetchExpression(fetchQuotesXml));
                            if (resultQuotes != null && resultQuotes.Entities != null && resultQuotes.Entities.Count > 0)
                            {
                                foreach (Entity quoteObj in resultQuotes.Entities)
                                {
                                    tracing.Trace("OnScheduleCompletion_CreateQPS: qp id" + quoteObj.Id);

                                    Entity retQP = service.Retrieve(quoteObj.LogicalName, quoteObj.Id, new ColumnSet("niq_billingfrequency", "productid", "niq_lineitemstartdate", "niq_lineitemenddate", "extendedamount", "quoteid"));
                                    string fetchQPSXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='niq_quotepaymentschedule'>
                                                                <attribute name='niq_quotepaymentscheduleid' />
                                                                <attribute name='niq_name' />
                                                                <attribute name='createdon' />
                                                                <order attribute='niq_name' descending='false' />
                                                                <filter type='and'>
                                                                  <condition attribute='niq_quoteproductid' operator='eq' uitype='quotedetail' value='{0}' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";
                                    fetchQPSXml = string.Format(fetchQPSXml, quoteObj.Id);
                                    var resultQPS = service.RetrieveMultiple(new FetchExpression(fetchQPSXml));
                                    if (resultQPS != null && resultQPS.Entities != null && resultQPS.Entities.Count > 0)
                                    {
                                        foreach (Entity qpsobj in resultQPS.Entities)
                                        {
                                            service.Delete(qpsobj.LogicalName, qpsobj.Id);
                                        }
                                    }
                                    if (retQuote.Attributes.Contains("niq_agreementtype") && retQuote.GetAttributeValue<OptionSetValue>("niq_agreementtype") != null && (retQuote.GetAttributeValue<OptionSetValue>("niq_agreementtype").Value == 100000001 || retQuote.GetAttributeValue<OptionSetValue>("niq_agreementtype").Value == 100000002) && retQP != null && retQP.Id != Guid.Empty && retQP.Attributes.Contains("niq_lineitemenddate") && retQP.Attributes.Contains("productid") && retQP.GetAttributeValue<EntityReference>("productid").Id != Guid.Empty && retQP.Attributes.Contains("quoteid") && retQP.GetAttributeValue<EntityReference>("quoteid").Id != Guid.Empty && retQP.Attributes.Contains("niq_lineitemstartdate") && retQP.GetAttributeValue<OptionSetValue>("niq_billingfrequency") != null && (retQP.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value == 100000000 || retQP.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value == 100000002 || retQP.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value == 100000003 || retQP.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value == 100000005))
                                    {
                                        tracing.Trace("OnScheduleCompletion_CreateQPS: ret qp" + retQP.Id);
                                        tracing.Trace("OnScheduleCompletion_CreateQPS: ret quote" + retQuote.Id);
                                        int billingFreq = retQP.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value;
                                        tracing.Trace("OnScheduleCompletion_CreateQPS: billing freq" + billingFreq);
                                        int divisor = -1;
                                        switch (billingFreq)
                                        {
                                            case 100000000:
                                                tracing.Trace("OnScheduleCompletion_CreateQPS: freq Monthly");
                                                divisor = 12;
                                                break;
                                            case 100000002:
                                                tracing.Trace("OnScheduleCompletion_CreateQPS: freq quterly");
                                                divisor = 4;
                                                break;
                                            case 100000003:
                                                tracing.Trace("OnScheduleCompletion_CreateQPS: freq half yearly");
                                                divisor = 2;
                                                break;
                                            case 100000005:
                                                tracing.Trace("OnScheduleCompletion_CreateQPS: freq Yearly");
                                                divisor = 1;
                                                break;

                                        }
                                        if (divisor > 0)
                                        {
                                            decimal annualApi = 0;
                                            if (retQuote.Attributes.Contains("niq_annualincreasetype") && retQuote.GetAttributeValue<OptionSetValue>("niq_annualincreasetype") != null && retQuote.GetAttributeValue<OptionSetValue>("niq_annualincreasetype").Value == 100000000 && retQuote.Attributes.Contains("niq_annualapicola"))
                                            {
                                                annualApi = (decimal)retQuote.GetAttributeValue<decimal>("niq_annualapicola");
                                                tracing.Trace("OnScheduleCompletion_CreateQPS: annualapi" + annualApi);
                                            }

                                            bool isFundingType = false;
                                            if (retQP.Attributes.Contains("productid") && retQP.GetAttributeValue<EntityReference>("productid").Id != Guid.Empty)
                                            {
                                                string fetchProductXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                                          <entity name='product'>
                                                            <attribute name='name' />
                                                            <attribute name='productnumber' />
                                                            <attribute name='description' />
                                                            <attribute name='statecode' />
                                                            <attribute name='modifiedon' />
                                                            <attribute name='productid' />
                                                            <order attribute='name' descending='false' />
                                                            <filter type='and'>
                                                              <filter type='or'>
                                                                <condition attribute='productnumber' operator='like' value='%MATCHED-FUND%' />
                                                                <condition attribute='productnumber' operator='like' value='%CLIENT-FUND%' />
                                                                <condition attribute='productnumber' operator='like' value='%NIELSEN-FUND%' />
                                                              </filter>
                                                            </filter>
                                                            <link-entity name='quotedetail' from='productid' to='productid' link-type='inner' alias='ac'>
                                                              <filter type='and'>
                                                                <condition attribute='productid' operator='eq' uitype='product' value='{0}' />
                                                              </filter>
                                                            </link-entity>
                                                          </entity>
                                                        </fetch>";
                                                fetchProductXml = string.Format(fetchProductXml, retQP.GetAttributeValue<EntityReference>("productid").Id);
                                                var resultProd = service.RetrieveMultiple(new FetchExpression(fetchProductXml));
                                                if (resultProd != null && resultProd.Entities != null && resultProd.Entities.Count > 0)
                                                {
                                                    tracing.Trace("OnScheduleCompletion_CreateQPS: result prod count" + resultProd.Entities.Count);
                                                    isFundingType = true;
                                                }
                                            }
                                            tracing.Trace("OnScheduleCompletion_CreateQPS:isfundingType " + isFundingType);
                                            DateTime startDate = retQP.GetAttributeValue<DateTime>("niq_lineitemstartdate");
                                            tracing.Trace("OnScheduleCompletion_CreateQPS: start date " + startDate);
                                            DateTime endDate = retQP.GetAttributeValue<DateTime>("niq_lineitemenddate");
                                            tracing.Trace("OnScheduleCompletion_CreateQPS: end date " + endDate);
                                            int years = endDate.Year - startDate.Year;
                                            tracing.Trace("OnScheduleCompletion_CreateQPS: years " + years);
                                            DateTime currentDate = startDate;
                                            tracing.Trace("OnScheduleCompletion_CreateQPS: current date " + currentDate);
                                            DateTime lastDateOfYear = startDate.AddMonths(12);
                                            lastDateOfYear = lastDateOfYear.AddDays(-1);
                                            tracing.Trace("OnScheduleCompletion_CreateQPS: last date of year " + lastDateOfYear);
                                            DateTime firstDateOfYear = new DateTime(currentDate.Year, 01, 01);
                                            tracing.Trace("OnScheduleCompletion_CreateQPS:first date of year " + firstDateOfYear);
                                            decimal fp_FY1 = retQP.GetAttributeValue<Money>("extendedamount").Value;
                                            decimal netPerYear = retQP.GetAttributeValue<Money>("extendedamount").Value;
                                            tracing.Trace("OnScheduleCompletion_CreateQPS: fp_FY1 " + fp_FY1);
                                            Entity createQPS = new Entity("niq_quotepaymentschedule");
                                            bool isEnd = false;



                                            string currencyCode = "";
                                            if (retQuote.Attributes.Contains("transactioncurrencyid") && retQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id != Guid.Empty)
                                            {
                                                Entity currency = service.Retrieve(retQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").LogicalName, retQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id, new ColumnSet("isocurrencycode"));
                                                if (currency != null && currency.Id != Guid.Empty && currency.Attributes.Contains("isocurrencycode"))
                                                {
                                                    currencyCode = currency.GetAttributeValue<string>("isocurrencycode");
                                                }
                                            }

                                            if (quoteObj.Attributes.Contains("niq_ismodified") && quoteObj.GetAttributeValue<string>("niq_ismodified") == "Completed")
                                            {
                                                tracing.Trace("OnScheduleCompletion_CreateQPS: isModified = Completed ");
                                                for (int i = 0; i <= years; i++)
                                                {
                                                    if (!isEnd)
                                                    {
                                                        tracing.Trace("OnScheduleCompletion_CreateQPS: i = " + i);
                                                        int result = DateTime.Compare(endDate, lastDateOfYear);
                                                        tracing.Trace("OnScheduleCompletion_CreateQPS: result " + result);
                                                        if (i == 0)
                                                        {
                                                            createQPS["transactioncurrencyid"] = new EntityReference(retQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").LogicalName, retQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                                                            createQPS["niq_isocurrencycode"] = currencyCode;
                                                            createQPS["niq_startdateofyear"] = startDate;
                                                            tracing.Trace("OnScheduleCompletion_CreateQPS:startdate" + startDate);

                                                            if (result <= 0)
                                                            {
                                                                tracing.Trace("OnScheduleCompletion_CreateQPS:enddate" + endDate);
                                                                createQPS["niq_enddateofyear"] = endDate;
                                                                createQPS["niq_name"] = currentDate.ToString("MM/dd/yyyy") + "-" + endDate.ToString("MM/dd/yyyy");
                                                                isEnd = true;
                                                            }
                                                            else
                                                            {

                                                                tracing.Trace("OnScheduleCompletion_CreateQPS:enddate lastday" + lastDateOfYear);
                                                                createQPS["niq_enddateofyear"] = lastDateOfYear;
                                                                createQPS["niq_name"] = currentDate.ToString("MM/dd/yyyy") + "-" + lastDateOfYear.ToString("MM/dd/yyyy");
                                                                lastDateOfYear = lastDateOfYear.AddMonths(12);
                                                                firstDateOfYear = firstDateOfYear.AddMonths(12);
                                                                currentDate = currentDate.AddMonths(12);
                                                            }
                                                            tracing.Trace("OnScheduleCompletion_CreateQPS:balance " + (fp_FY1 / divisor));
                                                            fp_FY1 = fp_FY1 / divisor;
                                                            createQPS["niq_netperyearcharge"] = new Money((decimal)netPerYear);
                                                            if (isFundingType)
                                                            {
                                                                createQPS["niq_fundpaymentperbillingfrequency"] = new Money((decimal)(fp_FY1));
                                                            }
                                                            else
                                                            {
                                                                createQPS["niq_nonfundpaymentperbillingfrequency"] = new Money((decimal)(fp_FY1 / divisor));
                                                            }
                                                            createQPS["niq_year"] = (int)(i + 1);
                                                            createQPS["niq_synctoclm"] = false;
                                                            createQPS["niq_quoteproductid"] = new EntityReference(retQP.LogicalName, retQP.Id);
                                                            createQPS["niq_quoteid"] = new EntityReference(retQuote.LogicalName, retQuote.Id);


                                                        }
                                                        else
                                                        {
                                                            createQPS["transactioncurrencyid"] = new EntityReference(retQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").LogicalName, retQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                                                            createQPS["niq_isocurrencycode"] = currencyCode;
                                                            tracing.Trace("OnScheduleCompletion_CreateQPS:inside else i =" + i);
                                                            int isLastDay = DateTime.Compare(endDate, lastDateOfYear);
                                                            tracing.Trace("OnScheduleCompletion_CreateQPS:islastday " + isLastDay);

                                                            tracing.Trace("OnScheduleCompletion_CreateQPS:startdate " + currentDate);
                                                            createQPS["niq_startdateofyear"] = currentDate;
                                                            if (isLastDay <= 0)
                                                            {
                                                                tracing.Trace("OnScheduleCompletion_CreateQPS:end date " + endDate);
                                                                createQPS["niq_enddateofyear"] = endDate;
                                                                createQPS["niq_name"] = currentDate.ToString("MM/dd/yyyy") + "-" + endDate.ToString("MM/dd/yyyy");
                                                                isEnd = true;
                                                            }
                                                            else
                                                            {

                                                                tracing.Trace("OnScheduleCompletion_CreateQPS:last day of year" + lastDateOfYear);
                                                                createQPS["niq_enddateofyear"] = lastDateOfYear;
                                                                createQPS["niq_name"] = currentDate.ToString("MM/dd/yyyy") + "-" + lastDateOfYear.ToString("MM/dd/yyyy");

                                                                lastDateOfYear = lastDateOfYear.AddYears(1);
                                                                firstDateOfYear = firstDateOfYear.AddYears(1);
                                                                currentDate = currentDate.AddYears(1);
                                                            }
                                                            fp_FY1 += (fp_FY1 * annualApi) / 100;
                                                            netPerYear += (netPerYear * annualApi) / 100;
                                                            tracing.Trace("OnScheduleCompletion_CreateQPS:fp+fy" + (i + 1) + " " + fp_FY1);
                                                            createQPS["niq_netperyearcharge"] = new Money((decimal)netPerYear);
                                                            if (isFundingType)
                                                            {
                                                                createQPS["niq_fundpaymentperbillingfrequency"] = new Money((decimal)fp_FY1);
                                                            }
                                                            else
                                                            {
                                                                createQPS["niq_nonfundpaymentperbillingfrequency"] = new Money((decimal)fp_FY1);
                                                            }
                                                            createQPS["niq_year"] = (int)(i + 1);
                                                            createQPS["niq_quoteproductid"] = new EntityReference(retQP.LogicalName, retQP.Id);
                                                            createQPS["niq_quoteid"] = new EntityReference(retQuote.LogicalName, retQuote.Id);

                                                            createQPS["niq_synctoclm"] = false;
                                                        }
                                                        service.Create(createQPS);
                                                    }
                                                }

                                            }
                                        }

                                    }



                                    Entity updQuoteProd = new Entity(quoteObj.LogicalName, quoteObj.Id);
                                    updQuoteProd["niq_isqpscompleted"] = true;
                                    service.Update(updQuoteProd);


                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
