﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.Plugins.Helper;


namespace NielsenIQ.CRM.Plugins
{
    public class OnAssociate_DeAssociate_Member_OpportunityAccessTeam : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                if (context.Depth >1)
                {
                    return;
                }

                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                tracing.Trace("Checking Target");
                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("TeamTemplateId") && context.InputParameters["TeamTemplateId"] is Guid)
                {
                    var responseConfigSettings = CommonHelper.GetConfigSettingsAccessTeamTemplate(service, tracing);
                    if(responseConfigSettings.oppAccessTeam != null && responseConfigSettings.quoteAccessTeam != null)
                    {
                        //Guid templateId = CommonHelper.GetTemplateId("Opportunity Sales Team Template", service);
                        Guid templateId = CommonHelper.GetTemplateId(responseConfigSettings.oppAccessTeam, service);
                        tracing.Trace("PostassignorPostCreate: Result = " + templateId);
                        Guid userId = (Guid)context.InputParameters["SystemUserId"];
                        EntityReference opppRef = (EntityReference)context.InputParameters["Record"];
                        Entity retUser = service.Retrieve("systemuser", userId, new ColumnSet("isdisabled"));
                        if (templateId != Guid.Empty && templateId == (Guid)context.InputParameters["TeamTemplateId"] && userId != Guid.Empty)
                        {
                            //Guid quouteTemplateId = CommonHelper.GetTemplateId("Quote Teams", service);
                            Guid quouteTemplateId = CommonHelper.GetTemplateId(responseConfigSettings.quoteAccessTeam, service);
                            if (quouteTemplateId != Guid.Empty)
                            {
                                string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='quote'>
                                                        <attribute name='name' />
                                                        <attribute name='quoteid' />
                                                        <order attribute='name' descending='false' />
                                                        <filter type='and'>
                                                          <condition attribute='opportunityid' operator='eq' uitype='opportunity' value='{0}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";
                                fetchXml = string.Format(fetchXml, opppRef.Id);
                                var fetchQuotes = service.RetrieveMultiple(new FetchExpression(fetchXml));
                                if (fetchQuotes != null && fetchQuotes.Entities.Count > 0)
                                {
                                    foreach (Entity quote in fetchQuotes.Entities)
                                    {
                                        if (context.MessageName == "AddUserToRecordTeam" && retUser.Attributes.Contains("isdisabled") && !(retUser.GetAttributeValue<bool>("isdisabled")))
                                        {
                                            tracing.Trace("AddUsertoaccesteam: adding user to access team");
                                            CommonHelper.AddUserToAccessTeam(quote, userId, quouteTemplateId, tracing, service);
                                        }
                                        if (context.MessageName == "RemoveUserFromRecordTeam")
                                        {
                                            tracing.Trace("RemoveUserFromRecordTeam: Removing user from access team");
                                            CommonHelper.RemoveUserToAccessTeam(quote, userId, quouteTemplateId, tracing, service);
                                        }

                                    }
                                }
                            }
                        }
                        else
                        {
                            return;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
