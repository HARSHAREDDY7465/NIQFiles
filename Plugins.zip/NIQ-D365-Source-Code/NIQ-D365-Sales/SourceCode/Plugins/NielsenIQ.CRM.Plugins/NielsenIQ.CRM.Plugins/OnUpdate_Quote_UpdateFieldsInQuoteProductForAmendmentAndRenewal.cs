﻿// This plugin will update start date, end date and frequency fields.
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using NielsenIQ.CRM.Plugins.Helper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Quote_UpdateFieldsInQuoteProductForAmendmentAndRenewal : IPlugin
    {
        EntityReference salesOrg = new EntityReference();
        OrganizationRequestCollection updateRequests = new OrganizationRequestCollection();
        ExecuteMultipleResponse executeMultipleResponse = new ExecuteMultipleResponse();
        Entity targetEntity = new Entity();
        Entity quoteEntity = new Entity();
        ITracingService tracingService;
        IOrganizationService service;
        ArrayList startDateArrayList = new ArrayList();
        ArrayList endDateArrayList = new ArrayList();
        string url = string.Empty;
        Entity quote = new Entity("quote");
        string fetchXml = string.Empty;
        DateTime[] startdate = null;
        DateTime[] enddate = null;
        bool expValidation = false;
        // Step 3: Map PriceListItem records by their primary id
        Dictionary<Guid, Entity> priceListItemMapping = new Dictionary<Guid, Entity>();
        Dictionary<string, Entity> productsMapping = new Dictionary<string, Entity>();
        Entity opportunity = new Entity("opportunity");
        EntityCollection priceListItemResults = null;
        OptionSetValue InCompleteManualInput = new OptionSetValue(610570001);
        OptionSetValue InCompleteSchedulesAuto = new OptionSetValue(610570002);
        private static readonly HttpClient client = new HttpClient();

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                service = serviceFactory.CreateOrganizationService(context.UserId);
                int billingFrequencyOSV = -1;
                int deliveryfrequencyOSV = -1;
                int updateFrequnencyOSV = -1;
                bool isRevenueFrequencyCustomforAdhocProduct = false;
                bool isBillingFrequencyAdhocforAdhocProduct = false;
                tracingService.Trace("context.Depth:" + context.Depth);
                tracingService.Trace("context.MessageName:" + context.MessageName.ToLower());
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity && context.MessageName.ToLower() == "update")
                {

                    tracingService.Trace("Execution Begins");
                    //Get Target quoteProduct
                    targetEntity = (Entity)context.InputParameters["Target"];

                    //get expvalidation field
                    if (targetEntity.Contains("niq_expvalidation") && targetEntity.Attributes["niq_expvalidation"] != null)
                    {
                        expValidation = targetEntity.GetAttributeValue<bool>("niq_expvalidation");
                    }
                    if (context.Depth == 1)
                    {
                        quote.Id = targetEntity.Id;
                        if (expValidation)
                        {
                            quote["niq_asyncprocessinprogress"] = true;
                        }
                        else
                        {
                            quote["niq_asyncprocessinprogress"] = false;
                        }

                        service.Update(quote);
                        tracingService.Trace("Quote Updated");
                    }
                    //Validate Target Entity
                    if (context.Depth == 2 && context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity && context.MessageName.ToLower() == "update")
                    {
                        tracingService.Trace("expValidation:" + expValidation);
                        //Check Entity Name and Message Nam]
                        tracingService.Trace("LogicalName" + targetEntity.LogicalName);
                        tracingService.Trace("MessageName" + context.MessageName.ToLower());

                        string currentStage = "";
                        Guid amendedfromOpp = Guid.Empty;
                        int oppType = -1;
                        int contractAction = -1;
                        bool autoRenewal = false;
                        bool isManualRenewal = false;
                        bool isAmendment = false;
                        if (context.PostEntityImages.Contains("PostImage"))
                        {
                            Entity postImage = context.PostEntityImages["PostImage"];
                            EntityReference opportunityEntRef = postImage.Contains("opportunityid") && postImage.GetAttributeValue<EntityReference>("opportunityid") != null ? postImage.GetAttributeValue<EntityReference>("opportunityid") : null;
                            Entity opportunityDetails = service.Retrieve(opportunityEntRef.LogicalName, opportunityEntRef.Id, new ColumnSet("niq_stage", "niq_opportunitytype", "niq_existingcontractaction", "niq_automaticrenewal", "niq_opportunitynumber", "niq_amendedfromopportunity"));
                            tracingService.Trace("opportunityID: " + opportunityEntRef.Id);
                            string oppNumber = opportunityDetails.Contains("niq_opportunitynumber") && opportunityDetails["niq_opportunitynumber"] != null ? opportunityDetails.GetAttributeValue<string>("niq_opportunitynumber") : null;
                            tracingService.Trace("opportunityNumber: " + oppNumber);
                            if (opportunityDetails.Contains("niq_amendedfromopportunity") && opportunityDetails["niq_amendedfromopportunity"] != null)
                            {
                                EntityReference amendedOpp = opportunityDetails.GetAttributeValue<EntityReference>("niq_amendedfromopportunity");
                                amendedfromOpp = amendedOpp.Id;
                                tracingService.Trace("amendedfromOpportunity: " + amendedOpp.Id);
                            }
                            oppType = opportunityDetails.Contains("niq_opportunitytype") && opportunityDetails["niq_opportunitytype"] != null ? opportunityDetails.GetAttributeValue<OptionSetValue>("niq_opportunitytype").Value : -1;
                            tracingService.Trace("OpportunityType: " + oppType);
                            contractAction = opportunityDetails.Contains("niq_existingcontractaction") && opportunityDetails["niq_existingcontractaction"] != null ? opportunityDetails.GetAttributeValue<OptionSetValue>("niq_existingcontractaction").Value : -1;
                            tracingService.Trace("ExistingContractAction: " + contractAction);
                            autoRenewal = opportunityDetails.Contains("niq_automaticrenewal") ? opportunityDetails.GetAttributeValue<bool>("niq_automaticrenewal") : false;
                            tracingService.Trace("AutoRenewal: " + autoRenewal);

                            isManualRenewal = oppType == 2 && contractAction == 1 && !autoRenewal;
                            isAmendment = oppType == 2 && contractAction == 4;

                            if (isManualRenewal || isAmendment)
                            {
                                tracingService.Trace("This is either a Amendment or manual renewal opportunity. Continuing execution.  Manual Renewal - " + isManualRenewal + ", Amendment - " + isAmendment);
                            }
                            else
                            {
                                tracingService.Trace("Not an Amendment or manual renewal opportunity. Terminating execution.  Manual Renewal - " + isManualRenewal + ", Amendment - " + isAmendment);
                                return;
                            }
                            if (opportunityDetails.Contains("niq_stage") && opportunityDetails["niq_stage"] != null)
                            {
                                currentStage = opportunityDetails.GetAttributeValue<string>("niq_stage");
                                tracingService.Trace("current stage: " + currentStage);
                            }
                        }

                        if (targetEntity.Id != Guid.Empty && !expValidation)
                        {
                            Guid opportunityId = amendedfromOpp;
                            // Validate OpportunityId input
                            tracingService.Trace($"OpportunityId received: {opportunityId}");
                            if (opportunityId == null)
                            {
                                tracingService.Trace("OpportunityId not found in InputParameters. Exiting plugin.");
                                return;
                            }
                            var originalProductsquery = BuildQuoteProductQueryForOriginalOpportunity(opportunityId);
                            EntityCollection originalProducts = service.RetrieveMultiple(originalProductsquery);
                            tracingService.Trace("Original Products Count: " + originalProducts.Entities.Count);

                            foreach (Entity ogProduct in originalProducts.Entities)
                            {
                                if (ogProduct.Contains("niq_isrevshareline") && ogProduct.GetAttributeValue<bool>("niq_isrevshareline") == false)
                                {
                                    string assetId = ogProduct.GetAttributeValue<string>("niq_elassetid").Replace("-", "").ToLower() ?? string.Empty;
                                    string productName = ogProduct.GetAttributeValue<string>("niq_contractproductname") ?? string.Empty;
                                    string key = $"{assetId}_{productName}";
                                    tracingService.Trace("Key = " + key);
                                    if (!productsMapping.ContainsKey(key))
                                    {
                                        productsMapping.Add(key, ogProduct);
                                    }
                                }
                            }
                            tracingService.Trace($"Mappings Added = {productsMapping.Count}, Keys = [{string.Join(", ", productsMapping.Keys)}]");

                            //Create query to get all quote products associated with quote
                            var quoteProdycuctQuery = BuildQuoteProductQuery(targetEntity.Id);
                            quoteProdycuctQuery.NoLock = true;
                            ///Get all quote products associated with quote
                            EntityCollection quoteProductResults = service.RetrieveMultiple(quoteProdycuctQuery);
                            tracingService.Trace("Count" + quoteProductResults.Entities.Count);

                            if (quoteProductResults.Entities.Count == 0)
                            {
                                quote.Id = targetEntity.Id;
                                quote["niq_asyncprocessinprogress"] = false;
                                service.Update(quote);
                                tracingService.Trace("Quote Updated");
                                return;
                            }

                            List<Guid> productPriceLevelIds = new List<Guid>();
                            foreach (Entity quoteProduct in quoteProductResults.Entities)
                            {
                                string priceListItemId = quoteProduct.Contains("niq_pricelistitem") && quoteProduct.Attributes["niq_pricelistitem"] != null ? quoteProduct.GetAttributeValue<string>("niq_pricelistitem") : string.Empty;
                                tracingService.Trace("priceListItemId:" + priceListItemId);

                                if (priceListItemId != string.Empty)
                                {
                                    productPriceLevelIds.Add(new Guid(priceListItemId));
                                }
                            }
                            tracingService.Trace("productPriceLevelIds:" + productPriceLevelIds.Count);

                            if (productPriceLevelIds.Count > 0)
                            {
                                // Step 2: Retrieve PriceListItem records
                                QueryExpression query = new QueryExpression("productpricelevel");
                                query.ColumnSet = new ColumnSet("productpricelevelid", "niq_billingfrequency", "niq_lagrevenuerecognition", "niq_revenuefrequency", "niq_updatefrequency", "productid", "niq_istimebased");
                                query.Criteria = new FilterExpression(); // Initialize the Criteria property
                                ConditionExpression condition = new ConditionExpression("productpricelevelid", ConditionOperator.In, productPriceLevelIds.ToArray()); // Convert the list to an array
                                query.Criteria.AddCondition(condition);
                                query.NoLock = true;

                                priceListItemResults = service.RetrieveMultiple(query);
                                tracingService.Trace("priceListItemResults:" + priceListItemResults.Entities.Count);

                                foreach (Entity priceListItem in priceListItemResults.Entities)
                                {
                                    if (priceListItem.Contains("productpricelevelid"))
                                    {
                                        priceListItemMapping[priceListItem.Id] = priceListItem;
                                    }
                                }
                            }

                            foreach (Entity quoteProduct in quoteProductResults.Entities)
                            {
                                Entity updateQuoteProduct = new Entity("quotedetail");
                                Guid amendedQuoteProduct = quoteProduct.Id;
                                string priceListItemGuid = quoteProduct.Contains("niq_pricelistitem") && quoteProduct.GetAttributeValue<string>("niq_pricelistitem") != null ? quoteProduct.GetAttributeValue<string>("niq_pricelistitem") : string.Empty;
                                string databaseName = quoteProduct.Contains("niq_databasename") && quoteProduct.GetAttributeValue<string>("niq_databasename") != null ? quoteProduct.GetAttributeValue<string>("niq_databasename") : string.Empty;
                                OptionSetValue productType = quoteProduct.Contains("niq_type") ? quoteProduct.GetAttributeValue<OptionSetValue>("niq_type") : null;
                                bool isTimeBasedAmend = quoteProduct.Contains("niq_istimebased") ? quoteProduct.GetAttributeValue<bool>("niq_istimebased") : false;
                                string rateCardId = quoteProduct.Contains("niq_ratecardid") && quoteProduct.GetAttributeValue<string>("niq_ratecardid") != null ? quoteProduct.GetAttributeValue<string>("niq_ratecardid") : null;
                                tracingService.Trace("RateCard: " + rateCardId);
                                DateTime quoteProductCreatedOrStartDate = quoteProduct.GetAttributeValue<DateTime>("createdon");
                                double termLength = quoteProduct.Contains("niq_termlength") && quoteProduct.Attributes["niq_termlength"] != null ? quoteProduct.GetAttributeValue<double>("niq_termlength") : 0;
                                tracingService.Trace("termLength" + termLength);
                                string rateCardUpdateFrequency = quoteProduct.Contains("niq_ratecardupdatefrequency") && quoteProduct.GetAttributeValue<string>("niq_ratecardupdatefrequency") != null ? quoteProduct.GetAttributeValue<string>("niq_ratecardupdatefrequency") : string.Empty;
                                tracingService.Trace("rateCardUpdateFrequency:" + rateCardUpdateFrequency);
                                bool isTimeBased = false;
                                if (!string.IsNullOrEmpty(priceListItemGuid) && priceListItemMapping.ContainsKey(new Guid(priceListItemGuid)))
                                {
                                    Entity priceListItemEnt = priceListItemMapping[new Guid(priceListItemGuid)];
                                    isTimeBased = priceListItemEnt.GetAttributeValue<bool>("niq_istimebased");
                                    tracingService.Trace("isTimeBased:" + isTimeBased);
                                    if (productType != null && productType.Value == 1 && !isTimeBased & termLength == 0 && rateCardUpdateFrequency == string.Empty)
                                    {
                                        updateQuoteProduct["niq_istimebased"] = isTimeBased;
                                        tracingService.Trace("isTimeBased:" + isTimeBased);

                                        billingFrequencyOSV = CommonHelper.SetBillingFrequency(priceListItemEnt, updateQuoteProduct, tracingService);
                                        if (billingFrequencyOSV != -1) updateQuoteProduct["niq_billingfrequency"] = new OptionSetValue(billingFrequencyOSV);
                                        tracingService.Trace("niq_billingfrequency" + billingFrequencyOSV);

                                        updateQuoteProduct["niq_lagrevenuerecognition"] = new OptionSetValue(100000000);

                                        if (!quoteProduct.Contains("niq_updatefrequency") && !quoteProduct.Contains("niq_ratecardupdatefrequency"))
                                        {
                                            updateFrequnencyOSV = CommonHelper.GetUpdateFrequency(priceListItemEnt, tracingService);
                                            if (updateFrequnencyOSV != -1) updateQuoteProduct["niq_updatefrequency"] = new OptionSetValue(updateFrequnencyOSV);

                                            deliveryfrequencyOSV = CommonHelper.GetDeliveryFrequency(priceListItemEnt, tracingService);
                                            if (deliveryfrequencyOSV != -1)
                                            {
                                                updateQuoteProduct["niq_deliveryfrequency"] = new OptionSetValue(deliveryfrequencyOSV);
                                                tracingService.Trace("niq_deliveryfrequency" + deliveryfrequencyOSV);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        updateQuoteProduct["niq_istimebased"] = isTimeBased;
                                        tracingService.Trace("isTimeBased:" + isTimeBased);
                                        billingFrequencyOSV = CommonHelper.SetBillingFrequency(priceListItemEnt, updateQuoteProduct, tracingService);
                                        if (billingFrequencyOSV != -1) updateQuoteProduct["niq_billingfrequency"] = new OptionSetValue(billingFrequencyOSV);
                                        tracingService.Trace("niq_billingfrequency" + billingFrequencyOSV);
                                        tracingService.Trace("databaseName:" + databaseName);

                                        int lagRevenueRecognitionOSV = CommonHelper.SetLagRevenueRecognition(priceListItemEnt, tracingService);
                                        if (lagRevenueRecognitionOSV != -1)
                                        {
                                            //always no lag
                                            updateQuoteProduct["niq_lagrevenuerecognition"] = new OptionSetValue(lagRevenueRecognitionOSV);
                                            tracingService.Trace("niq_lagrevenuerecognition" + lagRevenueRecognitionOSV);
                                        }

                                        //int deliveryfrequencyOSV = GetDeliveryFrequency(priceListItemEnt, tracingService);
                                        //if (deliveryfrequencyOSV != -1)
                                        //{
                                        //    updateQuoteProduct["niq_deliveryfrequency"] = new OptionSetValue(deliveryfrequencyOSV);
                                        //    tracingService.Trace("niq_deliveryfrequency" + deliveryfrequencyOSV);
                                        //}
                                        //    }

                                        if (!quoteProduct.Contains("niq_updatefrequency") && quoteProduct.Contains("niq_ratecardupdatefrequency"))
                                        {
                                            CommonHelper.SetFrequencyforRateCateProduct(tracingService, service, quoteProduct, productType, isTimeBased, ref updateQuoteProduct);
                                        }
                                        else if (!quoteProduct.Contains("niq_updatefrequency") && !quoteProduct.Contains("niq_ratecardupdatefrequency"))
                                        {
                                            updateFrequnencyOSV = CommonHelper.GetUpdateFrequency(priceListItemEnt, tracingService);
                                            if (updateFrequnencyOSV != -1) updateQuoteProduct["niq_updatefrequency"] = new OptionSetValue(updateFrequnencyOSV);

                                            deliveryfrequencyOSV = CommonHelper.GetDeliveryFrequency(priceListItemEnt, tracingService);
                                            if (deliveryfrequencyOSV != -1)
                                            {
                                                updateQuoteProduct["niq_deliveryfrequency"] = new OptionSetValue(deliveryfrequencyOSV);
                                                tracingService.Trace("niq_deliveryfrequency" + deliveryfrequencyOSV);
                                            }
                                        }
                                    }
                                }
                                else if (quoteProduct.Contains("quotedetailname"))
                                {
                                    string productName = quoteProduct.GetAttributeValue<string>("quotedetailname");
                                    tracingService.Trace("productName:" + productName);
                                    if (productName == "Place Holder Product" || productName == "SAP Deferred Revenue reconciliation placeholder")
                                    {
                                        int defaultValue = 100000000;
                                        updateQuoteProduct["niq_lagrevenuerecognition"] = new OptionSetValue(defaultValue);
                                        updateQuoteProduct["niq_deliveryfrequency"] = new OptionSetValue(defaultValue);
                                        updateQuoteProduct["niq_billingfrequency"] = new OptionSetValue(defaultValue);
                                        updateQuoteProduct["niq_updatefrequency"] = new OptionSetValue(defaultValue);
                                        tracingService.Trace("Updating Defaulting values");
                                    }
                                }
                                tracingService.Trace("isTimeBased:" + isTimeBased);
                                tracingService.Trace("termLength:" + termLength);
                                tracingService.Trace("rateCardUpdateFrequency:" + rateCardUpdateFrequency);
                                DateTime nextMonthStartDate = quoteProductCreatedOrStartDate.Day > 1
                                        ? new DateTime(quoteProductCreatedOrStartDate.Year, quoteProductCreatedOrStartDate.Month, 1).AddMonths(1)
                                        : quoteProductCreatedOrStartDate.Date;
                                DateTime endDateTermLength = nextMonthStartDate;
                                tracingService.Trace("nextMonthStartDate:" + nextMonthStartDate);

                                //Getting FrequFields from Original Products for stopping schedule autogeneration and copying schedules from original product
                                Entity original = null;
                                int ogbillingFrequency = -1;
                                int ogrevenueFrequency = -1;
                                int ogupdateFrequency = -1;
                                string assetIdamended = quoteProduct.GetAttributeValue<string>("niq_elassetid").Replace("-", "").ToLower() ?? string.Empty;
                                tracingService.Trace("AssetId: " + assetIdamended);
                                string productNameamended = quoteProduct.GetAttributeValue<string>("niq_contractproductname") ?? string.Empty;
                                tracingService.Trace("ContractProductName: " + productNameamended);
                                string keyamended = $"{assetIdamended}_{productNameamended}";
                                tracingService.Trace("CurrentAmendedProductKey: " + keyamended);
                                if (productsMapping.ContainsKey(keyamended) && productType.Value == 1)
                                {
                                    original = productsMapping[keyamended];
                                    ogbillingFrequency = original.GetAttributeValue<OptionSetValue>("niq_billingfrequency") != null
                                                                ? original.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value
                                                                : -1;
                                    ogrevenueFrequency = original.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency") != null
                                                                ? original.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency").Value
                                                                : -1;
                                    ogupdateFrequency = original.GetAttributeValue<OptionSetValue>("niq_updatefrequency") != null
                                                                ? original.GetAttributeValue<OptionSetValue>("niq_updatefrequency").Value
                                                                : -1;
                                }
                                isRevenueFrequencyCustomforAdhocProduct = (ogrevenueFrequency == 100000009 || ogupdateFrequency == 100000009);
                                tracingService.Trace("Revenue Frequency for original product is custom? " + isRevenueFrequencyCustomforAdhocProduct);
                                isBillingFrequencyAdhocforAdhocProduct = (ogbillingFrequency == 100000009);
                                tracingService.Trace("BillingFrequency for original product is adhoc? " + isBillingFrequencyAdhocforAdhocProduct);
                                if (productType != null && productType.Value == 1 && !isTimeBased && termLength == 0 && rateCardUpdateFrequency == string.Empty)
                                {
                                    endDateTermLength = nextMonthStartDate.AddMonths(1).AddDays(-1);
                                    tracingService.Trace("endDateTermLength:" + endDateTermLength);
                                    updateQuoteProduct["niq_lineitemstartdate"] = nextMonthStartDate;
                                    updateQuoteProduct["niq_lineitemenddate"] = endDateTermLength;
                                    if (!isRevenueFrequencyCustomforAdhocProduct)
                                    {
                                        updateQuoteProduct["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                                    }
                                    if (!isBillingFrequencyAdhocforAdhocProduct)
                                    {
                                        if (!string.IsNullOrEmpty(currentStage) && !string.Equals(currentStage.ToLower(), "pre-proposal"))
                                            updateQuoteProduct["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");

                                    }
                                }
                                else
                                {
                                    tracingService.Trace("Set Start date and End date");
                                    endDateTermLength = termLength == 0.0f
                                        ? nextMonthStartDate
                                        : nextMonthStartDate.AddMonths((int)termLength).AddDays(-1);

                                    tracingService.Trace("endDateTermLength:" + endDateTermLength);

                                    updateQuoteProduct["niq_lineitemstartdate"] = nextMonthStartDate;
                                    updateQuoteProduct["niq_lineitemenddate"] = endDateTermLength;

                                    if (!isBillingFrequencyAdhocforAdhocProduct)
                                    {
                                        if (!string.IsNullOrEmpty(currentStage) && !string.Equals(currentStage.ToLower(), "pre-proposal"))
                                            updateQuoteProduct["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                                    }
                                    if (!isRevenueFrequencyCustomforAdhocProduct)
                                    {
                                        updateQuoteProduct["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                                    }

                                    tracingService.Trace("niq_lineitemstartdate:" + nextMonthStartDate);
                                    tracingService.Trace("niq_lineitemenddate:" + endDateTermLength);

                                    startDateArrayList.Add(nextMonthStartDate.Date);
                                    endDateArrayList.Add(endDateTermLength.Date);
                                }

                                // Update billing start/end date for Adhoc Product Type and if Billing frequency is 50/50,80/20,0/100,One Time
                                if (productType != null && productType.Value == 1 && (billingFrequencyOSV == 100000010 || billingFrequencyOSV == 100000011 || billingFrequencyOSV == 100000012 || billingFrequencyOSV == 100000013))
                                {
                                    updateQuoteProduct["niq_billingstartdate"] = nextMonthStartDate;
                                    updateQuoteProduct["niq_billingenddate"] = endDateTermLength;
                                }

                                tracingService.Trace("After data population, revenue and billing schedule status as to be: ");

                                if (!isRevenueFrequencyCustomforAdhocProduct)
                                {
                                    //if the revenue frequency is auto populated.
                                    if (updateQuoteProduct.Attributes.Contains("niq_deliveryfrequency") && updateQuoteProduct["niq_deliveryfrequency"] != null)
                                    {
                                        if (updateQuoteProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency").Value == 100000009)
                                        {
                                            tracingService.Trace("delivery frequency is custom, so status is IncompleteManualInput");
                                            updateQuoteProduct["niq_revenueschedulestatus"] = new OptionSetValue(InCompleteManualInput.Value);
                                        }
                                        else
                                        {
                                            tracingService.Trace("delivery frequency not custom, so status is IncompleteSchedulesAuto");
                                            updateQuoteProduct["niq_revenueschedulestatus"] = new OptionSetValue(InCompleteSchedulesAuto.Value);
                                        }
                                    }
                                }
                                if (!isBillingFrequencyAdhocforAdhocProduct)
                                {
                                    //if the billing frequency is auto populated. 
                                    if (updateQuoteProduct.Attributes.Contains("niq_billingfrequency") && updateQuoteProduct["niq_billingfrequency"] != null)
                                    {
                                        if (updateQuoteProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value == 100000009)
                                        {
                                            tracingService.Trace("billing frequency as custom, so status is IncompleteManualInput");
                                            updateQuoteProduct["niq_billingschedulestatus"] = new OptionSetValue(InCompleteManualInput.Value);
                                        }
                                        else
                                        {
                                            tracingService.Trace("billing frequency not custom, so status is IncompleteSchedulesAuto");
                                            updateQuoteProduct["niq_billingschedulestatus"] = new OptionSetValue(InCompleteSchedulesAuto.Value);
                                        }
                                    }
                                }
                                //If amended product match found in original then copy fields logic

                                if (productsMapping.ContainsKey(keyamended))
                                {
                                    original = productsMapping[keyamended];
                                    Guid originalQuoteProduct = original.Id;
                                    tracingService.Trace($"Copying from Original: {productsMapping[keyamended].Id}");
                                    CopyFieldsFromOriginalProduct(original, updateQuoteProduct, termLength, isAmendment, isManualRenewal, productType, isTimeBasedAmend, rateCardId, originalQuoteProduct, amendedQuoteProduct, isBillingFrequencyAdhocforAdhocProduct, isRevenueFrequencyCustomforAdhocProduct, tracingService,rateCardUpdateFrequency);
                                }
                                updateQuoteProduct.Id = quoteProduct.Id;
                                var updateRequest = new UpdateRequest { Target = updateQuoteProduct };
                                updateRequests.Add(updateRequest);
                                tracingService.Trace($"Added UpdateRequest for Product: {quoteProduct.Id}");

                                Entity opportunity = CreateRevShareLine.GetOppOfQuoteDetail(service, quoteProduct, tracingService);
                                if (opportunity != null && opportunity.Contains("niq_hostopportunity") && opportunity.Attributes["niq_hostopportunity"] != null)
                                {
                                    tracingService.Trace("Child Opp:" + opportunity.Id);
                                    EntityReference hostOppRef = opportunity.GetAttributeValue<EntityReference>("niq_hostopportunity");
                                    Entity hostOpp = service.Retrieve(hostOppRef.LogicalName, hostOppRef.Id, new ColumnSet("name"));
                                    //  tracingService.Trace("hostOpp:" + hostOpp.Id);
                                    Entity revSharLine = CreateRevShareLine.GetRevShareLineOfHostOpp(service, opportunity, hostOpp, tracingService);
                                    if (revSharLine != null)
                                    {
                                        updateQuoteProduct["niq_revshareline"] = new EntityReference(revSharLine.LogicalName, revSharLine.Id);
                                    }

                                }
                            }

                            tracingService.Trace("startDateArrayList.Count:" + startDateArrayList.Count);
                            //if (startDateArrayList.Count > 0)
                            //{
                            //    startdate = (DateTime[])startDateArrayList.ToArray(typeof(DateTime));
                            //    Array.Sort(startdate);
                            //    quote["niq_contractstartdate"] = startdate[0];
                            //    opportunity["niq_contractstartdate"] = startdate[0];
                            //    tracingService.Trace("startdate:" + startdate[0]);
                            //}
                            //tracingService.Trace("endDateArrayList.Count:" + endDateArrayList.Count);

                            //if (endDateArrayList.Count > 0)
                            //{
                            //    enddate = (DateTime[])endDateArrayList.ToArray(typeof(DateTime));
                            //    Array.Reverse(enddate);
                            //    quote["niq_contractenddate"] = enddate[0];
                            //    opportunity["niq_contractenddate"] = enddate[0];
                            //    tracingService.Trace("Enddate:" + enddate[0]);
                            //}

                            quote.Id = targetEntity.Id;
                            quote["niq_asyncprocessinprogress"] = false;
                            service.Update(quote);
                            if (context.PostEntityImages.Contains("PostImage"))
                            {
                                Entity postImage = context.PostEntityImages["PostImage"];
                                EntityReference opportunityEntRef = postImage.Contains("opportunityid") && postImage.GetAttributeValue<EntityReference>("opportunityid") != null ? postImage.GetAttributeValue<EntityReference>("opportunityid") : null;
                                if (opportunity != null)
                                {
                                    tracingService.Trace("opportunityEntRef" + opportunityEntRef.Id);
                                    opportunity.Id = opportunityEntRef.Id;
                                    service.Update(opportunity);
                                    tracingService.Trace("Contract start Date and end date are Updated on Opportunity");
                                }
                            }

                            //}
                            tracingService.Trace("updateRequests Count" + updateRequests.Count);
                            if (updateRequests.Count > 0)
                            {
                                tracingService.Trace("updateRequests Count:" + updateRequests.Count);
                                // Create the ExecuteMultipleRequest object
                                var executeMultipleRequest = new ExecuteMultipleRequest()
                                {
                                    Requests = updateRequests,
                                    Settings = new ExecuteMultipleSettings()
                                    {
                                        ContinueOnError = false,
                                        ReturnResponses = true
                                    }
                                };
                                // Execute the batch request
                                executeMultipleResponse = (ExecuteMultipleResponse)service.Execute(executeMultipleRequest);
                                tracingService.Trace("Quote Detail Records Updated");
                            }
                        }
                    }
                    tracingService.Trace("Plugin execution completed successfully.");
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }

        }

        private void CopyFieldsFromOriginalProduct(Entity original, Entity updateQuoteProduct, double termLength, bool isAmendment, bool isManualRenewal, OptionSetValue productType, bool isTimeBased, string rateCardId, Guid originalQuoteProductId, Guid amendedQuoteProductId, bool isBillingFrequencyAdhocforAdhocProduct, bool isRevenueFrequencyCustomforAdhocProduct, ITracingService tracingService, string rateCardUpdateFrequency)
        {
            // Copy fields from original to amended
            //****Getting required values from original product****
            DateTime? startDate = original.GetAttributeValue<DateTime?>("niq_lineitemstartdate") ?? null;
            DateTime? endDate = original.GetAttributeValue<DateTime?>("niq_lineitemenddate") ?? null;
            string wbs = original.GetAttributeValue<string>("niq_wbs") ?? string.Empty;
            string invoiceText = original.GetAttributeValue<string>("niq_invoicetext") ?? string.Empty;
            OptionSetValue lagRevenue = original.GetAttributeValue<OptionSetValue>("niq_lagrevenuerecognition") != null
                ? original.GetAttributeValue<OptionSetValue>("niq_lagrevenuerecognition")
                : new OptionSetValue(0);
            string basesNumber = original.GetAttributeValue<string>("niq_basesstudynumber") ?? string.Empty;
            string platformDelivery = original.GetAttributeValue<string>("niq_onplatformdelivery") ?? string.Empty;
            EntityReference revShareProduct = (original != null && original.Contains("niq_revshareproductid"))
                ? original.GetAttributeValue<EntityReference>("niq_revshareproductid")
                : null;
            OptionSetValue billingFrequency = original.GetAttributeValue<OptionSetValue>("niq_billingfrequency") != null
                                        ? original.GetAttributeValue<OptionSetValue>("niq_billingfrequency")
                                        : new OptionSetValue(0);
            OptionSetValue revenueFrequency = original.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency") != null
                                        ? original.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency")
                                        : new OptionSetValue(0);
            OptionSetValue updateFrequency = original.GetAttributeValue<OptionSetValue>("niq_updatefrequency") != null
                                        ? original.GetAttributeValue<OptionSetValue>("niq_updatefrequency")
                                        : new OptionSetValue(0);

            string billingFrequencyText = original.FormattedValues.Contains("niq_billingfrequency")
                                        ? original.FormattedValues["niq_billingfrequency"]
                                        : string.Empty;
            string revenueFrequencyText = original.FormattedValues.Contains("niq_deliveryfrequency")
                                        ? original.FormattedValues["niq_deliveryfrequency"]
                                        : string.Empty;
            string updateFrequencyText = original.FormattedValues.Contains("niq_updatefrequency")
                                        ? original.FormattedValues["niq_updatefrequency"]
                                        : string.Empty;

            DateTime? billingStartDate = original.GetAttributeValue<DateTime?>("niq_billingstartdate") ?? null;
            tracingService.Trace("Billing Start Date: " + billingStartDate);
            DateTime? billingEndDate = original.GetAttributeValue<DateTime?>("niq_billingenddate") ?? null;
            tracingService.Trace("Billing End Date: " + billingEndDate);

            double calculatedTermLength = original.GetAttributeValue<double>("niq_calculatedtermlength");
            tracingService.Trace("Original_CalculatedTermLength: " + calculatedTermLength);

            //****Getting required values from amended product****
            // double termLength = quoteProduct.Contains("niq_termlength") && quoteProduct.Attributes["niq_termlength"] != null ? amendedProduct.GetAttributeValue<double>("niq_termlength") : 0;
            tracingService.Trace($"TermLenght: " + termLength);

            DateTime updatedstartdate = new DateTime();
            DateTime updatedenddate = new DateTime();

            if (productType.Value == 2)   //periodic
            {
                if (isManualRenewal)
                {
                    if (endDate.HasValue)
                    {
                        updatedstartdate = endDate.Value.AddDays(1);
                        updateQuoteProduct["niq_lineitemstartdate"] = updatedstartdate;
                        tracingService.Trace($"StartDateforRenewal: " + updatedstartdate);
                    }
                }
                else if (isAmendment)
                {
                    if (startDate.HasValue)
                    {
                        updatedstartdate = startDate.Value;
                        updateQuoteProduct["niq_lineitemstartdate"] = updatedstartdate;
                        tracingService.Trace($"StartDateforAmendment: " + updatedstartdate);
                    }
                    if (revShareProduct != null)
                    {
                        updateQuoteProduct["niq_revshareproductid"] = new EntityReference("quotedetail", revShareProduct.Id);
                        tracingService.Trace($"RevShareProduct: " + revShareProduct.Id);
                    }
                }

                if (updatedstartdate != null)
                {
                    DateTime tempDate = updatedstartdate.AddMonths((int)termLength - 1);
                    updatedenddate = new DateTime(tempDate.Year, tempDate.Month, DateTime.DaysInMonth(tempDate.Year, tempDate.Month));
                }
                updateQuoteProduct["niq_lineitemenddate"] = updatedenddate;
                tracingService.Trace($"EndDate: " + updatedenddate);

                if (!string.IsNullOrEmpty(lagRevenue.Value.ToString()))
                    updateQuoteProduct["niq_lagrevenuerecognition"] = lagRevenue;
                tracingService.Trace($"LagRevenue: " + lagRevenue.Value);

                bool isBillingCompatible = CheckWithTermLenght(termLength, billingFrequencyText);
                tracingService.Trace("isBillingCompatible: " + isBillingCompatible);
                if (isBillingCompatible)
                    updateQuoteProduct["niq_billingfrequency"] = billingFrequency;

                bool isRevenueCompatible = CheckWithTermLenght(termLength, revenueFrequencyText);
                tracingService.Trace("isRevenueCompatible: " + isRevenueCompatible);
                if (isRevenueCompatible)
                    updateQuoteProduct["niq_deliveryfrequency"] = revenueFrequency;

                bool isUpdateCompatible = CheckWithTermLenght(termLength, updateFrequencyText);
                tracingService.Trace("isUpdateCompatible: " + isUpdateCompatible);
                if (isUpdateCompatible)
                    updateQuoteProduct["niq_updatefrequency"] = updateFrequency;
            }
            else if (productType.Value == 1)  //Adhoc
            {
                tracingService.Trace($"Start adhoc product Type: " + productType.Value);
                if ((isTimeBased) || (!isTimeBased && rateCardId == null))    //Adhoc Time based & Service based product
                {
                    tracingService.Trace($"Start adhoc product Time/Service based : " + isTimeBased);
                    if (startDate.HasValue)
                    {
                        updateQuoteProduct["niq_lineitemstartdate"] = startDate;
                        tracingService.Trace($"StartDateforAdhoc: " + startDate);
                    }
                    if (endDate.HasValue)
                    {
                        updateQuoteProduct["niq_lineitemenddate"] = endDate;
                        tracingService.Trace($"EndDateforAdhoc: " + endDate);
                    }
                    updateQuoteProduct["niq_calculatedtermlength"] = calculatedTermLength;
                    tracingService.Trace($"CalculatedTermLengthforAdhoc: " + calculatedTermLength);
                }
                else if (!isTimeBased && rateCardId != null)    //rate card adhoc product
                {
                    tracingService.Trace($"Start rate card adhoc service product");
                    if (rateCardUpdateFrequency == "Adhoc")
                    {
                        updateQuoteProduct["niq_calculatedtermlength"] = calculatedTermLength;
                        tracingService.Trace($"CalculatedTermLengthforAdhoc: " + calculatedTermLength);
                    }

                    if (isManualRenewal)
                    {
                        if (endDate.HasValue)
                        {
                            tracingService.Trace($"End Date for Renewal " + endDate.Value);
                            updatedstartdate = endDate.Value.AddDays(1);
                            updateQuoteProduct["niq_lineitemstartdate"] = updatedstartdate;
                            tracingService.Trace($"StartDateforRenewal: " + updatedstartdate);
                        }
                    }
                    else if (isAmendment)
                    {
                        if (startDate.HasValue)
                        {
                            updatedstartdate = startDate.Value;
                            updateQuoteProduct["niq_lineitemstartdate"] = updatedstartdate;
                            tracingService.Trace($"StartDateforAmendment: " + updatedstartdate);
                        }
                    }

                    if (updatedstartdate != null)
                    {
                        DateTime tempDate = updatedstartdate.AddMonths((int)calculatedTermLength - 1);
                        updatedenddate = new DateTime(tempDate.Year, tempDate.Month, DateTime.DaysInMonth(tempDate.Year, tempDate.Month));
                    }
                    updateQuoteProduct["niq_lineitemenddate"] = updatedenddate;
                    tracingService.Trace($"EndDate: " + updatedenddate);

                }
                //Below fields are common for adhoc time based, service based & ratecard products
                if (isAmendment)
                {
                    if (revShareProduct != null)
                    {
                        updateQuoteProduct["niq_revshareproductid"] = new EntityReference("quotedetail", revShareProduct.Id);
                        tracingService.Trace($"RevShareProduct: " + revShareProduct.Id);
                    }
                }
                updateQuoteProduct["niq_billingfrequency"] = billingFrequency;
                tracingService.Trace($"BillingFrequencyforAdhoc: " + billingFrequency.Value);

                updateQuoteProduct["niq_deliveryfrequency"] = revenueFrequency;
                tracingService.Trace($"RevenueFrequencyforAdhoc: " + revenueFrequency.Value);

                updateQuoteProduct["niq_updatefrequency"] = updateFrequency;
                tracingService.Trace($"UpdateFrequencyforAdhoc: " + updateFrequency.Value);

                updateQuoteProduct["niq_lagrevenuerecognition"] = lagRevenue;
                tracingService.Trace($"LagRevenueforAdhoc: " + lagRevenue.Value);

                updateQuoteProduct["niq_billingstartdate"] = billingStartDate;
                tracingService.Trace($"BillingStartDateforAdhoc: " + billingStartDate);

                updateQuoteProduct["niq_billingenddate"] = billingEndDate;
                tracingService.Trace($"BillingEndDateforAdhoc: " + billingEndDate);

                //updateQuoteProduct["niq_calculatedtermlength"] = calculatedTermLength;
                //tracingService.Trace($"CalculatedTermLengthforAdhoc: " + calculatedTermLength);

                isBillingFrequencyAdhocforAdhocProduct = billingFrequency.Value == 100000009;
                //Call HTTP Flow for schedules copy over
                if (isRevenueFrequencyCustomforAdhocProduct || isBillingFrequencyAdhocforAdhocProduct)
                {
                    var payload = new { HostQuoteProductID = originalQuoteProductId.ToString(), AmendRenewProductID = amendedQuoteProductId.ToString(), isBillingFrequencyAdhocforAdhocProduct, isRevenueFrequencyCustomforAdhocProduct };
                    tracingService.Trace("Payload - " + payload);
                    string json = JsonConvert.SerializeObject(payload);
                    tracingService.Trace("JSONPayload - " + json);
                    string configName = "HTTPRequest_CopySchedulesForAdhocProducts";

                    var query = new QueryExpression("niq_configurationsetting")
                    {
                        ColumnSet = new ColumnSet("niq_to"),
                        Criteria = new FilterExpression
                        {
                            Conditions =
                            {
                                new ConditionExpression("niq_name", ConditionOperator.Equal, configName)
                            }
                        }
                    };

                    var results = service.RetrieveMultiple(query);
                    if (results.Entities.Count > 0)
                    {
                        var url = results.Entities[0]["niq_to"].ToString();
                        tracingService.Trace("URL:- " + url.ToString());
                        tracingService.Trace("JSONPayload - " + json);
                        var content = new StringContent(json, Encoding.UTF8, "application/json");
                        tracingService.Trace("Content - " + content.ToString());
                        var response = client.PostAsync(url, content).Result;
                    }
                }
            }

            //Below fields are common for periodic and adhoc products
            if (!string.IsNullOrEmpty(wbs))
                updateQuoteProduct["niq_wbs"] = wbs;
            tracingService.Trace($"WBS: " + wbs);

            if (!string.IsNullOrEmpty(invoiceText))
                updateQuoteProduct["niq_invoicetext"] = invoiceText;
            tracingService.Trace($"InvoiceText: " + invoiceText);

            if (!string.IsNullOrEmpty(basesNumber))
                updateQuoteProduct["niq_basesstudynumber"] = basesNumber;
            tracingService.Trace($"BasesNumber: " + basesNumber);

            if (!string.IsNullOrEmpty(platformDelivery))
                updateQuoteProduct["niq_onplatformdelivery"] = platformDelivery;
            tracingService.Trace($"PlatformDelivery: " + platformDelivery);

        }

        public bool CheckWithTermLenght(double termLength, string frequency)
        {
            tracingService.Trace("\nfunc: CheckWithTermLenght");
            tracingService.Trace("termlenght :" + termLength);
            tracingService.Trace("frequency name :" + frequency);
            switch (frequency)
            {
                case "BI-Monthly":
                case "Bimonthly":
                case "Bimonthly with Lag":
                case "Bi-Monthly with Lag":
                    if (termLength % 2 == 0) { break; }
                    else { return false; }
                case "Quarterly":
                case "Quarterly with Lag":
                    if (termLength % 3 == 0) { break; }
                    else { return false; }
                case "3 * Annually":
                case "3 X Annually":
                case "3x Annually":
                case "3x / Year":
                    if (termLength % 4 == 0) { break; }
                    else { return false; }
                case "Half-Yearly":
                case "2x / year":
                case "2x / Year":
                    if (termLength % 6 == 0) { break; }
                    else { return false; }
                case "Annually":
                case "Annual":
                    if (termLength % 12 == 0) { break; }
                    else { return false; }
            }
            tracingService.Trace("frequency is compatible with termlength");
            return true;
        }

        public static QueryExpression CreateQuotedetailQuery(Guid quoteId, string databaseName)
        {
            // Create QueryExpression for entity "quotedetail"
            QueryExpression query = new QueryExpression("quotedetail");

            // Define attributes to retrieve (optional based on your requirement)
            query.ColumnSet = new ColumnSet(true); // Retrieve all columns or specify specific ones as needed

            // Define filter criteria
            FilterExpression filter = new FilterExpression(LogicalOperator.And);
            filter.AddCondition("quoteid", ConditionOperator.Equal, quoteId);
            filter.AddCondition("niq_type", ConditionOperator.Equal, 1);
            filter.AddCondition("niq_databasename", ConditionOperator.Equal, databaseName);

            query.Criteria = filter;

            // Execute query to retrieve results from Dynamics 365
            return query;
        }
        public int GetDeliveryFrequency(Entity priceListItemEnt, ITracingService tracingService)
        {
            tracingService.Trace("Inside GetDeliveryFrequency");
            int deliveryFrequencyOSV = priceListItemEnt.Contains("niq_revenuefrequency") && priceListItemEnt["niq_revenuefrequency"] is OptionSetValue
                ? ((OptionSetValue)priceListItemEnt["niq_revenuefrequency"]).Value
                : -1;
            tracingService.Trace("deliveryFrequencyOSV" + deliveryFrequencyOSV);

            return deliveryFrequencyOSV;
        }
        public int SetLagRevenueRecognition(Entity priceListItemEnt, ITracingService tracingService)
        {
            int lagRevenueRecognitionOSV = (priceListItemEnt.Contains("niq_lagrevenuerecognition") && priceListItemEnt["niq_lagrevenuerecognition"] is OptionSetValue)
                ? ((OptionSetValue)priceListItemEnt["niq_lagrevenuerecognition"]).Value
                : -1;

            return lagRevenueRecognitionOSV;
        }
        public int GetUpdateFrequency(Entity priceListItemEnt, ITracingService tracingService)
        {
            int updateFrequencyOSV = priceListItemEnt.Contains("niq_updatefrequency") && priceListItemEnt["niq_updatefrequency"] is OptionSetValue
                ? ((OptionSetValue)priceListItemEnt["niq_updatefrequency"]).Value
                : -1;

            return updateFrequencyOSV;
        }

        public int SetBillingFrequency(Entity priceListItemEnt, Entity updateQuoteProduct, ITracingService tracingService)
        {
            int billingFrequencyOSV = priceListItemEnt.Contains("niq_billingfrequency") && priceListItemEnt.Attributes["niq_billingfrequency"] != null
                ? priceListItemEnt.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value
                : -1;

            tracingService.Trace("niq_billingfrequency set to: " + billingFrequencyOSV);
            return billingFrequencyOSV;
        }

        private Entity isAdhocProductBehavesAsPeriodic(EntityCollection quoteProductResults, string databaseName, IOrganizationService service, IPluginExecutionContext context, ITracingService tracingService)
        {
            Entity entity = null;
            try
            {
                tracingService.Trace("Count:" + quoteProductResults.Entities.Count);
                // Retrieve the first entity matching the criteria
                entity = quoteProductResults.Entities
                    .FirstOrDefault(p => p.Contains("niq_type") && p.GetAttributeValue<OptionSetValue>("niq_type").Value == 2 &&
                                    p.Contains("niq_onplatformdelivery") &&
                                    p.GetAttributeValue<string>("niq_onplatformdelivery") == "Yes" && p.Contains("niq_databasename") &&
                                    p.GetAttributeValue<string>("niq_databasename") == databaseName);

                if (entity != null)
                {
                    return entity;
                }
                else
                {
                    return null;
                }


            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }

        }
        private QueryExpression BuildQuoteProductQuery(Guid _quoteId)
        {
            QueryExpression query = new QueryExpression("quotedetail");

            query.ColumnSet = new ColumnSet("niq_databasename", "quotedetailid", "niq_pricelistitem", "niq_billingfrequency", "niq_deliveryfrequency", "niq_lagrevenuerecognition", "niq_updatefrequency", "createdon", "niq_termlength", "niq_type", "isproductoverridden", "niq_ratecardupdatefrequency", "quotedetailname", "niq_onplatformdelivery", "niq_elassetid", "niq_contractproductname", "niq_istimebased", "niq_ratecardid");

            FilterExpression filter = new FilterExpression(LogicalOperator.And);
            filter.AddCondition("niq_lineitemstartdate", ConditionOperator.Null);
            filter.AddCondition("niq_lineitemenddate", ConditionOperator.Null);
            filter.AddCondition("niq_updatefrequency", ConditionOperator.Null);
            filter.AddCondition("niq_lagrevenuerecognition", ConditionOperator.Null);
            filter.AddCondition("niq_billingfrequency", ConditionOperator.Null);
            filter.AddCondition("niq_deliveryfrequency", ConditionOperator.Null);
            filter.AddCondition("quoteid", ConditionOperator.Equal, _quoteId);
            //filter.AddCondition("niq_elassetid", ConditionOperator.Equal, _elassetId);
            //filter.AddCondition("niq_contractproductname", ConditionOperator.Equal, _contractProductNumber);
            query.Criteria = filter;

            return query;

        }

        //This is function is retrieve the all values of Update frequency option set field.
        //And also return the value where rateCardUpdateFrequency eq option set's text.

        private QueryExpression BuildQuoteProductQueryForOriginalOpportunity(Guid opportunityId)
        {
            tracingService.Trace($"OpportunityId received: {opportunityId}");
            // Build QueryExpression for quotedetail
            var query = new QueryExpression("quotedetail")
            {
                ColumnSet = new ColumnSet(
                    "niq_lineitemstartdate",
                    "niq_lineitemenddate",
                    "niq_elassetid",
                    "niq_wbs",
                    "niq_ratecardid",
                    "niq_invoicetext",
                    "quotedetailid",
                    "productdescription",
                    "niq_contractproductname",
                    "niq_billingfrequency",
                    "niq_lagrevenuerecognition",
                    "niq_onplatformdelivery",
                    "niq_basesstudynumber",
                    "niq_updatefrequency",
                    "niq_deliveryfrequency",
                    "niq_revshareproductid",
                    "niq_lineitemnumberforsap",
                    "sequencenumber",
                    "niq_isrevshareline",
                    "niq_billingstartdate",
                    "niq_billingenddate",
                    "niq_calculatedtermlength")
            };

            query.AddOrder("productdescription", OrderType.Ascending);
            query.Criteria.AddCondition("quotestatecode", ConditionOperator.NotEqual, 1); // Exclude inactive
            query.Criteria.AddCondition("quotedetailname", ConditionOperator.NotEqual, "SAP Deferred Revenue reconciliation placeholder");
            //query.Criteria.AddCondition("niq_isrevshareline", ConditionOperator.Equal, false);
            // Link to Quote
            var quoteLink = query.AddLink("quote", "quoteid", "quoteid");
            quoteLink.EntityAlias = "quote";
            quoteLink.Columns.AddColumns("name", "quotenumber");

            // Link to Opportunity
            var oppLink = quoteLink.AddLink("opportunity", "opportunityid", "opportunityid");
            oppLink.EntityAlias = "opp";
            oppLink.Columns.AddColumns("name", "opportunityid");

            // Add condition for OpportunityId
            oppLink.LinkCriteria.AddCondition("opportunityid", ConditionOperator.Equal, opportunityId);

            tracingService.Trace("Executing RetrieveMultiple for quotedetail records...");

            return query;
        }
    }
}
