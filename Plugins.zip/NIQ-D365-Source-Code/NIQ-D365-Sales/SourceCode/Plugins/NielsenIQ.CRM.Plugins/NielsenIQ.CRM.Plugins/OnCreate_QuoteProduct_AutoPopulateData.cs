﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;
using System.Collections.Generic;

namespace NielsenIQ.CRM.Plugins
{
    public class OnCreate_QuoteProduct_AutoPopulateData : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnCreate_QuoteProduct_AutoPopulateData: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity quoteProductobj = (Entity)context.InputParameters["Target"];
                    Entity quoteProduct = service.Retrieve(quoteProductobj.LogicalName, quoteProductobj.Id, new ColumnSet("productid", "quoteid"));
                    if (quoteProduct != null && quoteProduct.Id != Guid.Empty)
                    {
                        tracing.Trace("OnCreate_QuoteProduct_AutoPopulateData: quote Product ID " + quoteProduct.Id);
                        if (quoteProduct.Attributes.Contains("quoteid") && quoteProduct.GetAttributeValue<EntityReference>("quoteid").Id != Guid.Empty)
                        {
                            bool update = false;
                            Entity updQuoteProduct = new Entity(quoteProduct.LogicalName, quoteProduct.Id);
                            Entity retQuote = service.Retrieve(quoteProduct.GetAttributeValue<EntityReference>("quoteid").LogicalName, quoteProduct.GetAttributeValue<EntityReference>("quoteid").Id, new ColumnSet("opportunityid", "pricelevelid", "niq_mainquote", "niq_contractstartdate", "niq_contractenddate"));
                            if (retQuote != null && retQuote.Id != Guid.Empty && retQuote.Attributes.Contains("opportunityid") && retQuote.Attributes.Contains("pricelevelid"))
                            {
                                tracing.Trace("OnCreate_QuoteProduct_AutoPopulateData: ret quote ID" + retQuote.Id);
                                Entity relOppo = service.Retrieve(retQuote.GetAttributeValue<EntityReference>("opportunityid").LogicalName, retQuote.GetAttributeValue<EntityReference>("opportunityid").Id, new ColumnSet("niq_salesorgid"));

                                if (relOppo != null && relOppo.Id != Guid.Empty && relOppo.Attributes.Contains("niq_salesorgid") && relOppo.GetAttributeValue<EntityReference>("niq_salesorgid").Id != Guid.Empty)
                                {
                                    tracing.Trace("OnCreate_QuoteProduct_AutoPopulateData: Getting the Sales Org." + relOppo.GetAttributeValue<EntityReference>("niq_salesorgid").Id);
                                    string fetchXmlPriceList = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                    <entity name='pricelevel'>
                                                                    <attribute name='name' />
                                                                    <attribute name='pricelevelid' />
                                                                    <order attribute='name' descending='false' />
                                                                    <filter type='and'>
                                                                        <condition attribute='niq_salesorg' operator='eq' uitype='niq_salesorg' value='{0}' />
                                                                    </filter>
                                                                    </entity>
                                                                </fetch>";
                                    fetchXmlPriceList = string.Format(fetchXmlPriceList, relOppo.GetAttributeValue<EntityReference>("niq_salesorgid").Id);
                                    var resultPriceList = service.RetrieveMultiple(new FetchExpression(fetchXmlPriceList));

                                    if (quoteProduct.Attributes.Contains("productid") && quoteProduct.GetAttributeValue<EntityReference>("productid").Id != Guid.Empty && resultPriceList != null && resultPriceList.Entities != null && resultPriceList.Entities.Count > 0)
                                    {

                                        Entity priceList = resultPriceList.Entities.FirstOrDefault();
                                        tracing.Trace("OnCreate_QuoteProduct_AutoPopulateData: PriceList ID" + priceList.Id);
                                        string fetchXmlPricelistItems = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='productpricelevel'>
                                                                <attribute name='productid' />                                                                
                                                                <attribute name='productpricelevelid' />                                                                
                                                                <attribute name='niq_profitcentrecode' />
                                                                <attribute name='niq_glaccountnumber' />
                                                                <order attribute='productid' descending='false' />
                                                                <filter type='and'>
                                                                  <condition attribute='pricelevelid' operator='eq' uitype='pricelevel' value='{0}' />
                                                                  <condition attribute='productid' operator='eq' uitype='product' value='{1}' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";
                                        fetchXmlPricelistItems = string.Format(fetchXmlPricelistItems, priceList.Id, quoteProduct.GetAttributeValue<EntityReference>("productid").Id);

                                        var resultPriceListItems = service.RetrieveMultiple(new FetchExpression(fetchXmlPricelistItems));
                                        if (resultPriceListItems != null && resultPriceListItems.Entities != null)
                                        {
                                            Entity priceListItems = service.RetrieveMultiple(new FetchExpression(fetchXmlPricelistItems)).Entities.FirstOrDefault();

                                            if (priceListItems != null && priceListItems.Id != Guid.Empty)
                                            {
                                                tracing.Trace("OnCreate_QuoteProduct_AutoPopulateData: Getting the pricelistitem." + priceListItems.Id);
                                                if (priceListItems.Attributes.Contains("niq_glaccountnumber") && !quoteProduct.Attributes.Contains("niq_glaccountid"))
                                                {
                                                    string fetchXmlGlAccount = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='niq_glaccount'>
                                                                <attribute name='niq_glaccountid' />
                                                                <attribute name='niq_name' />                                                                
                                                                <order attribute='niq_name' descending='false' />
                                                                <filter type='and'>                                                                 
                                                                  <condition attribute='niq_glaccountnumber' operator='eq' value='{0}' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";
                                                    fetchXmlGlAccount = string.Format(fetchXmlGlAccount, priceListItems.GetAttributeValue<string>("niq_glaccountnumber"));

                                                    var resultGlAccount = service.RetrieveMultiple(new FetchExpression(fetchXmlGlAccount));

                                                    if (resultGlAccount != null && resultGlAccount.Entities != null)
                                                    {
                                                        Entity glAccount = service.RetrieveMultiple(new FetchExpression(fetchXmlGlAccount)).Entities.FirstOrDefault();
                                                        if (glAccount != null && glAccount.Id != Guid.Empty)
                                                        {
                                                            updQuoteProduct["niq_glaccountid"] = new EntityReference(glAccount.LogicalName, glAccount.Id);
                                                            update = true;
                                                        }
                                                    }
                                                }
                                                if (priceListItems.Attributes.Contains("niq_profitcentrecode") && !quoteProduct.Attributes.Contains("niq_profitcentreid"))
                                                {
                                                    string fetchXmlProfitCentre = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='niq_profitcentre'>
                                                                    <attribute name='niq_profitcentreid' />
                                                                    <attribute name='niq_name' />
                                                                    <order attribute='niq_name' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='niq_profitcentrecode' operator='eq' value='{0}' />                                                                      
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";
                                                    fetchXmlProfitCentre = string.Format(fetchXmlProfitCentre, priceListItems.GetAttributeValue<string>("niq_profitcentrecode"));
                                                    var resultProfitCentre = service.RetrieveMultiple(new FetchExpression(fetchXmlProfitCentre));

                                                    if (resultProfitCentre != null && resultProfitCentre.Entities != null)
                                                    {
                                                        Entity profitCentre = service.RetrieveMultiple(new FetchExpression(fetchXmlProfitCentre)).Entities.FirstOrDefault();
                                                        if (profitCentre != null && profitCentre.Id != Guid.Empty)
                                                        {
                                                            updQuoteProduct["niq_profitcentreid"] = new EntityReference(profitCentre.LogicalName, profitCentre.Id);
                                                            update = true;
                                                        }
                                                    }
                                                }

                                                if (relOppo.Attributes.Contains("niq_salesorgid") && !quoteProduct.Attributes.Contains("niq_salesorgcodeid"))
                                                {
                                                    updQuoteProduct["niq_salesorgcodeid"] = relOppo.GetAttributeValue<EntityReference>("niq_salesorgid");
                                                    update = true;
                                                }

                                            }
                                        }

                                    }

                                }
                                if (retQuote != null && retQuote.Id != Guid.Empty && retQuote.Attributes.Contains("niq_mainquote") && retQuote.GetAttributeValue<bool>("niq_mainquote"))
                                {
                                    updQuoteProduct["niq_ismodified"] = "InProgress";
                                    update = true;

                                }
                                //string fetchDateQP = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' aggregate='true' >
                                //                        <entity name='quotedetail' >
                                //                            <attribute name='niq_lineitemstartdate' alias='minDate' aggregate='min' />
                                //                            <attribute name='niq_lineitemenddate' alias='maxDate' aggregate='max' />
                                //                            <filter type='and' >
                                //                                <condition attribute='quoteid' operator='eq' uiname='testchanges' uitype='quote' value='{0}' />
                                //                                <condition attribute='quotedetailname' operator='ne' value='SAP Deferred Revenue reconciliation placeholder' />
                                //                            </filter>
                                //                        </entity>
                                //                    </fetch>";
                                //fetchDateQP = string.Format(fetchDateQP, retQuote.Id);
                                //var resDateQP = service.RetrieveMultiple(new FetchExpression(fetchDateQP));
                                //Entity updQuote = new Entity(retQuote.LogicalName, retQuote.Id);
                                //Entity updOppo = new Entity(retQuote.GetAttributeValue<EntityReference>("opportunityid").LogicalName, retQuote.GetAttributeValue<EntityReference>("opportunityid").Id);
                                //bool updateQuote = false;
                                //if (resDateQP != null && resDateQP.Entities != null && resDateQP.Entities.Count > 0)
                                //{

                                //    Entity dateQP = resDateQP.Entities.FirstOrDefault();
                                //    if (dateQP.Contains("minDate"))
                                //    {
                                //        updQuote["niq_contractstartdate"] = dateQP.GetAttributeValue<AliasedValue>("minDate").Value;
                                //        updOppo["niq_contractstartdate"] = dateQP.GetAttributeValue<AliasedValue>("minDate").Value;
                                //        updateQuote = true;
                                //    }
                                //    if (dateQP.Contains("maxDate"))
                                //    {
                                //        updQuote["niq_contractenddate"] = dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                //        updOppo["niq_contractenddate"] = dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                //        updateQuote = true;
                                //    }


                                //}
                                //else
                                //{
                                //    updateQuote = true;
                                //    updQuote["niq_contractstartdate"] = null;
                                //    updOppo["niq_contractstartdate"] = null;

                                //    updQuote["niq_contractenddate"] = null;
                                //    updOppo["niq_contractenddate"] = null;



                                //}

                                //if (updateQuote)
                                //{
                                //    service.Update(updQuote);
                                //    tracing.Trace("OnCreate_QuoteProduct_AutoPopulateData: sucesfull update quote");
                                //    if (retQuote.Attributes.Contains("niq_mainquote") && retQuote.GetAttributeValue<bool>("niq_mainquote"))
                                //    {
                                //        service.Update(updOppo);
                                //        tracing.Trace("OnCreate_QuoteProduct_AutoPopulateData: sucesfull updated Oppo");

                                //    }
                                //}

                                if (update)
                                {
                                    service.Update(updQuoteProduct);
                                }

                            }

                        }
                    }

                }

            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
