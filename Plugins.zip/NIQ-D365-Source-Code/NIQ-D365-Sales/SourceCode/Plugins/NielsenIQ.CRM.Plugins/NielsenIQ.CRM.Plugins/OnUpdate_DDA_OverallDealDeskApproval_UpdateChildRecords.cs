using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_DDA_OverallDealDeskApproval_UpdateChildRecords : IPlugin
    {
        private ITracingService tracingService;
        private IOrganizationService service;

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                var serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                service = serviceFactory.CreateOrganizationService(context.UserId);

                //Check Depth and message
                if (IsRecursionOrInvalidMessage(context)) return;

                tracingService.Trace("Execution Begins");

                if (context.InputParameters.TryGetValue("Target", out var target) && target is Entity targetEntity)
                {
                    // Check if Overall Deal Desk is approved
                    if (IsApproved(targetEntity, tracingService))
                    {
                        // Get Post Image
                        var postImage = GetPostImage(context, tracingService);


                        if (postImage == null || postImage.GetAttributeValue<EntityReference>("niq_opportunityid") == null) return;

                        //Get Opportunity id
                        var opportunityId = postImage.Contains("niq_opportunityid") && postImage.Attributes["niq_opportunityid"] != null ? postImage.GetAttributeValue<EntityReference>("niq_opportunityid").Id : Guid.Empty;
                        tracingService.Trace("opportunityId:" + opportunityId);

                        if (opportunityId == Guid.Empty) { return; }

                        // Check Opportunity is revshare deal or not
                        Entity opportunity = service.Retrieve("opportunity", opportunityId, new ColumnSet("niq_revenuesharedeal"));

                        bool isRevenueShareDeal = opportunity.GetAttributeValue<bool>("niq_revenuesharedeal");

                        if (!isRevenueShareDeal) { return; }

                        //  UpdateChildDDA(opportunityId, tracingService, postImage, opportunityId);

                        tracingService.Trace("postImage:" + postImage);
                        // tracingService.Trace("niq_quoteid:" + postImage.GetAttributeValue<EntityReference>("niq_quoteid"));

                        if (postImage == null || postImage.GetAttributeValue<EntityReference>("niq_quoteid") == null) return;

                        //Get Quote
                        var quote = postImage.Contains("niq_quoteid") && postImage.Attributes["niq_quoteid"] != null ? postImage.GetAttributeValue<EntityReference>("niq_quoteid") : null;

                        //Update the all child quotes from Host opportunity
                        UpdateChildQuotes(opportunityId, quote, postImage, tracingService);

                    }
                }
                tracingService.Trace("Execution Completed");
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
        }

        private bool IsRecursionOrInvalidMessage(IPluginExecutionContext context)
        {
            string functionName = "IsRecursionOrInvalidMessage";
            tracingService.Trace("Inside " + functionName);

            tracingService.Trace($"Message: {context.MessageName.ToLower()}");
            tracingService.Trace($"Context Depth: {context.Depth}");
            return context.Depth > 2 || context.MessageName.ToLower() != "update";

        }

        private bool IsApproved(Entity targetEntity, ITracingService tracingService)
        {
            string functionName = "IsApproved";
            tracingService.Trace("Inside " + functionName);

            return targetEntity.Attributes.TryGetValue("niq_approvalstatus", out var approvalStatus) &&
                   approvalStatus is OptionSetValue status && status.Value == 4; // Approved
        }

        private Entity GetPostImage(IPluginExecutionContext context, ITracingService tracingService)
        {
            string functionName = "GetPostImage";
            tracingService.Trace("Inside " + functionName);

            return context.PostEntityImages.Contains("PostImage") ?
                (Entity)context.PostEntityImages["PostImage"] : null;
        }

        private void UpdateChildQuotes(Guid opportunityId, EntityReference quote, Entity postImageDDA, ITracingService tracingService)
        {
            string functionName = "UpdateChildQuotes";
            tracingService.Trace("Inside " + functionName);

            Entity resultParentQuote = null;
            EntityCollection quoteColl = null;
            OrganizationRequestCollection updateRequests = new OrganizationRequestCollection();
            string fetchXML = string.Empty;
            try
            {
                if (quote == null) { return; }

                resultParentQuote = service.Retrieve(quote.LogicalName, quote.Id, new ColumnSet("niq_customertype", "niq_termtype", "niq_agreementtype", "niq_annualincreasetype", "niq_annualapicola", "niq_apistructure", "niq_evergreenautorenewalannualapi", "niq_terminationnotificationmonths", "niq_numberofftes", "niq_quotedefaultperiodicbillingfrequency", "niq_incentivetype", "niq_incentivevalueniqannualimpact", "niq_incentivecomments", "niq_linktononstandardapprovalrequests", "niq_interestrateonlatepayment", "niq_nonstandardbillingterm", "niq_paymenttermsid", "niq_paymenttermdescription", "niq_adhocproductsonlyquote", "niq_fieldsrequiringapproval", "niq_parentmsaquoteid", "niq_msapaymentterm", "niq_msapaymenttermdescription", "niq_msapaymenttermdays", "niq_modeleddayssalesoutstanding", "niq_dealdeskapproval", "niq_fundusageapproval", "niq_quoteheaderdetailsapproval"));

                fetchXML = BuildQuoteQuery(opportunityId, tracingService);

                if (fetchXML == string.Empty) { return; }

                quoteColl = service.RetrieveMultiple(new FetchExpression(fetchXML));
                tracingService.Trace("quoteColl: " + quoteColl.Entities.Count);

                ColumnSet columns = new ColumnSet("niq_revenuesharedeal");
                Entity opportunity = service.Retrieve("opportunity", opportunityId, columns);

                if (opportunity.GetAttributeValue<bool>("niq_revenuesharedeal"))
                {
                    if (quoteColl.Entities.Count > 0)
                    {
                        foreach (var childQuoteEnt in quoteColl.Entities)
                        {
                            Entity quoteEntity = CreateQuoteUpdateRequestRevShare(childQuoteEnt, resultParentQuote, postImageDDA, tracingService, service);

                            var updateRequest = new UpdateRequest { Target = quoteEntity };
                            updateRequests.Add(updateRequest);
                        }

                        ExecuteBatchUpdate(updateRequests, tracingService);
                    }
                }


                if (!opportunity.GetAttributeValue<bool>("niq_revenuesharedeal"))
                {
                    if (quoteColl.Entities.Count > 0)
                    {
                        foreach (var childQuoteEnt in quoteColl.Entities)
                        {
                            Entity quoteEntity = CreateQuoteUpdateRequest(childQuoteEnt, resultParentQuote, postImageDDA, tracingService, service);

                            var updateRequest = new UpdateRequest { Target = quoteEntity };
                            updateRequests.Add(updateRequest);
                        }

                        ExecuteBatchUpdate(updateRequests, tracingService);
                    }
                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
        }

        private Entity CreateQuoteUpdateRequest(Entity quote, Entity resultQuote, Entity postImageDDA, ITracingService tracingService, IOrganizationService service)
        {
            try
            {
                string functionName = "CreateQuoteUpdateRequest";
                tracingService.Trace("Inside " + functionName);

                Entity updateQuote = new Entity("quote");
                updateQuote.Id = quote.Id;
                tracingService.Trace("quote.Id:" + quote.Id);
                //Get and update Customer type
                if (resultQuote.Attributes.Contains("niq_customertype") && resultQuote.Attributes["niq_customertype"] != null)
                {
                    tracingService.Trace("Updating niq_customertype");
                    updateQuote["niq_customertype"] = new OptionSetValue(resultQuote.GetAttributeValue<OptionSetValue>("niq_customertype").Value);
                    tracingService.Trace("niq_customertype:" + resultQuote.GetAttributeValue<OptionSetValue>("niq_customertype").Value);
                }
                if (resultQuote.Attributes.Contains("niq_termtype") && resultQuote.Attributes["niq_termtype"] != null)
                {
                    tracingService.Trace("Updating niq_termtype");
                    updateQuote["niq_termtype"] = new OptionSetValue(resultQuote.GetAttributeValue<OptionSetValue>("niq_termtype").Value);
                    tracingService.Trace("niq_termtype:" + resultQuote.GetAttributeValue<OptionSetValue>("niq_termtype").Value);
                }

                if (resultQuote.Attributes.Contains("niq_agreementtype") && resultQuote.Attributes["niq_agreementtype"] != null)
                {
                    tracingService.Trace("Updating niq_agreementtype");
                    updateQuote["niq_agreementtype"] = new OptionSetValue(resultQuote.GetAttributeValue<OptionSetValue>("niq_agreementtype").Value);
                    tracingService.Trace("niq_agreementtype:" + resultQuote.GetAttributeValue<OptionSetValue>("niq_agreementtype").Value);
                }
                //DYNCRM-22351 - No need to set Annual Increase Type from DDAR
                //if (resultQuote.Attributes.Contains("niq_annualincreasetype") && resultQuote.Attributes["niq_annualincreasetype"] != null)
                //{
                //    tracingService.Trace("Updating niq_annualincreasetype");
                //    updateQuote["niq_annualincreasetype"] = new OptionSetValue(resultQuote.GetAttributeValue<OptionSetValue>("niq_annualincreasetype").Value);
                //    tracingService.Trace("niq_annualincreasetype:" + resultQuote.GetAttributeValue<OptionSetValue>("niq_annualincreasetype").Value);
                //}

                if (resultQuote.Attributes.Contains("niq_apistructure") && resultQuote.Attributes["niq_apistructure"] != null)
                {
                    tracingService.Trace("Updating niq_apistructure");
                    updateQuote["niq_apistructure"] = new OptionSetValue(resultQuote.GetAttributeValue<OptionSetValue>("niq_apistructure").Value);
                    tracingService.Trace("niq_apistructure:" + resultQuote.GetAttributeValue<OptionSetValue>("niq_apistructure").Value);
                }

                if (resultQuote.Attributes.Contains("niq_quotedefaultperiodicbillingfrequency") && resultQuote.Attributes["niq_quotedefaultperiodicbillingfrequency"] != null)
                {
                    tracingService.Trace("Updating niq_quotedefaultperiodicbillingfrequency");
                    updateQuote["niq_quotedefaultperiodicbillingfrequency"] = new OptionSetValue(resultQuote.GetAttributeValue<OptionSetValue>("niq_quotedefaultperiodicbillingfrequency").Value);
                    tracingService.Trace("niq_quotedefaultperiodicbillingfrequency:" + resultQuote.GetAttributeValue<OptionSetValue>("niq_quotedefaultperiodicbillingfrequency").Value);
                }
                //DYNCRM-21869 - Remove fields from Form
                //if (resultQuote.Attributes.Contains("niq_incentivetype") && resultQuote.Attributes["niq_incentivetype"] != null)
                //{
                //    tracingService.Trace("Updating niq_incentivetype");
                //    updateQuote["niq_incentivetype"] = new OptionSetValue(resultQuote.GetAttributeValue<OptionSetValue>("niq_incentivetype").Value);
                //    tracingService.Trace("niq_incentivetype:" + resultQuote.GetAttributeValue<OptionSetValue>("niq_incentivetype").Value);
                //}


                if (resultQuote.Attributes.Contains("niq_annualapicola") && resultQuote.Attributes["niq_annualapicola"] != null)
                {
                    tracingService.Trace("Updating niq_annualapicola");
                    updateQuote["niq_annualapicola"] = resultQuote.GetAttributeValue<decimal>("niq_annualapicola");
                    tracingService.Trace("niq_annualapicola:" + resultQuote.GetAttributeValue<decimal>("niq_annualapicola"));
                }
                if (resultQuote.Attributes.Contains("niq_evergreenautorenewalannualapi") && resultQuote.Attributes["niq_evergreenautorenewalannualapi"] != null)
                {
                    tracingService.Trace("Updating niq_evergreenautorenewalannualapi");
                    updateQuote["niq_evergreenautorenewalannualapi"] = resultQuote.GetAttributeValue<decimal>("niq_evergreenautorenewalannualapi");
                    tracingService.Trace("niq_evergreenautorenewalannualapi:" + resultQuote.GetAttributeValue<decimal>("niq_evergreenautorenewalannualapi"));
                }
                if (resultQuote.Attributes.Contains("niq_numberofftes") && resultQuote.Attributes["niq_numberofftes"] != null)
                {
                    tracingService.Trace("Updating niq_numberofftes");
                    updateQuote["niq_numberofftes"] = resultQuote.GetAttributeValue<decimal>("niq_numberofftes");
                    tracingService.Trace("niq_numberofftes:" + resultQuote.GetAttributeValue<decimal>("niq_numberofftes"));
                }
                if (resultQuote.Attributes.Contains("niq_interestrateonlatepayment") && resultQuote.Attributes["niq_interestrateonlatepayment"] != null)
                {
                    tracingService.Trace("Updating niq_interestrateonlatepayment");
                    updateQuote["niq_interestrateonlatepayment"] = resultQuote.GetAttributeValue<decimal>("niq_interestrateonlatepayment");
                    tracingService.Trace("niq_interestrateonlatepayment:" + resultQuote.GetAttributeValue<decimal>("niq_interestrateonlatepayment"));
                }

                if (resultQuote.Attributes.Contains("niq_terminationnotificationmonths") && resultQuote.Attributes["niq_terminationnotificationmonths"] != null)
                {
                    tracingService.Trace("Updating niq_terminationnotificationmonths");
                    updateQuote["niq_terminationnotificationmonths"] = resultQuote.GetAttributeValue<int>("niq_terminationnotificationmonths");
                    tracingService.Trace("niq_terminationnotificationmonths:" + resultQuote.GetAttributeValue<int>("niq_terminationnotificationmonths"));
                }
                //DYNCRM-21869 - Remove fields from Form
                //if (resultQuote.Attributes.Contains("niq_incentivevalueniqannualimpact") && resultQuote.Attributes["niq_incentivevalueniqannualimpact"] != null)
                //{
                //    tracingService.Trace("Updating niq_incentivevalueniqannualimpact");
                //    updateQuote["niq_incentivevalueniqannualimpact"] = resultQuote.GetAttributeValue<int>("niq_incentivevalueniqannualimpact");
                //    tracingService.Trace("niq_incentivevalueniqannualimpact:" + resultQuote.GetAttributeValue<int>("niq_incentivevalueniqannualimpact"));
                //}

                if (resultQuote.Attributes.Contains("niq_msapaymenttermdays") && resultQuote.Attributes["niq_msapaymenttermdays"] != null)
                {
                    tracingService.Trace("Updating niq_msapaymenttermdays");
                    updateQuote["niq_msapaymenttermdays"] = resultQuote.GetAttributeValue<int>("niq_msapaymenttermdays");
                    tracingService.Trace("niq_msapaymenttermdays:" + resultQuote.GetAttributeValue<int>("niq_msapaymenttermdays"));
                }

                if (resultQuote.Attributes.Contains("niq_modeleddayssalesoutstanding") && resultQuote.Attributes["niq_modeleddayssalesoutstanding"] != null)
                {
                    tracingService.Trace("Updating niq_modeleddayssalesoutstanding");
                    updateQuote["niq_modeleddayssalesoutstanding"] = resultQuote.GetAttributeValue<string>("niq_modeleddayssalesoutstanding");
                    tracingService.Trace("niq_modeleddayssalesoutstanding:" + resultQuote.GetAttributeValue<string>("niq_modeleddayssalesoutstanding"));
                }
                if (resultQuote.Attributes.Contains("niq_msapaymenttermdescription") && resultQuote.Attributes["niq_msapaymenttermdescription"] != null)
                {
                    tracingService.Trace("Updating niq_msapaymenttermdescription");
                    updateQuote["niq_msapaymenttermdescription"] = resultQuote.GetAttributeValue<string>("niq_msapaymenttermdescription");
                    tracingService.Trace("niq_msapaymenttermdescription:" + resultQuote.GetAttributeValue<string>("niq_msapaymenttermdescription"));
                }
                if (resultQuote.Attributes.Contains("niq_incentivecomments") && resultQuote.Attributes["niq_incentivecomments"] != null)
                {
                    tracingService.Trace("Updating niq_incentivecomments");
                    updateQuote["niq_incentivecomments"] = resultQuote.GetAttributeValue<string>("niq_incentivecomments");
                    tracingService.Trace("niq_incentivecomments:" + resultQuote.GetAttributeValue<string>("niq_incentivecomments"));
                }
                if (resultQuote.Attributes.Contains("niq_linktononstandardapprovalrequests") && resultQuote.Attributes["niq_linktononstandardapprovalrequests"] != null)
                {
                    tracingService.Trace("Updating niq_linktononstandardapprovalrequests");
                    updateQuote["niq_linktononstandardapprovalrequests"] = resultQuote.GetAttributeValue<string>("niq_linktononstandardapprovalrequests");
                    tracingService.Trace("niq_linktononstandardapprovalrequests:" + resultQuote.GetAttributeValue<string>("niq_linktononstandardapprovalrequests"));
                }
                if (resultQuote.Attributes.Contains("niq_paymenttermdescription") && resultQuote.Attributes["niq_paymenttermdescription"] != null)
                {
                    tracingService.Trace("Updating niq_paymenttermdescription");
                    updateQuote["niq_paymenttermdescription"] = resultQuote.GetAttributeValue<string>("niq_paymenttermdescription");
                    tracingService.Trace("niq_paymenttermdescription:" + resultQuote.GetAttributeValue<string>("niq_paymenttermdescription"));
                }
                if (resultQuote.Attributes.Contains("niq_fieldsrequiringapproval") && resultQuote.Attributes["niq_fieldsrequiringapproval"] != null)
                {
                    tracingService.Trace("Updating niq_fieldsrequiringapproval");
                    updateQuote["niq_fieldsrequiringapproval"] = resultQuote.GetAttributeValue<string>("niq_fieldsrequiringapproval");
                    tracingService.Trace("niq_fieldsrequiringapproval:" + resultQuote.GetAttributeValue<string>("niq_fieldsrequiringapproval"));
                }

                if (resultQuote.Attributes.Contains("niq_nonstandardbillingterm") && resultQuote.Attributes["niq_nonstandardbillingterm"] != null)
                {
                    tracingService.Trace("Updating niq_nonstandardbillingterm");
                    updateQuote["niq_nonstandardbillingterm"] = resultQuote.GetAttributeValue<bool>("niq_nonstandardbillingterm");
                    tracingService.Trace("niq_nonstandardbillingterm:" + resultQuote.GetAttributeValue<bool>("niq_nonstandardbillingterm"));
                }
                if (resultQuote.Attributes.Contains("niq_adhocproductsonlyquote") && resultQuote.Attributes["niq_adhocproductsonlyquote"] != null)
                {
                    tracingService.Trace("Updating niq_adhocproductsonlyquote");
                    updateQuote["niq_adhocproductsonlyquote"] = resultQuote.GetAttributeValue<bool>("niq_adhocproductsonlyquote");
                    tracingService.Trace("niq_adhocproductsonlyquote:" + resultQuote.GetAttributeValue<bool>("niq_adhocproductsonlyquote"));
                }

                if (resultQuote.Attributes.Contains("niq_paymenttermsid") && resultQuote.Attributes["niq_paymenttermsid"] != null)
                {
                    tracingService.Trace("Updating niq_paymenttermsid");
                    updateQuote["niq_paymenttermsid"] = resultQuote.GetAttributeValue<EntityReference>("niq_paymenttermsid");
                    tracingService.Trace("niq_paymenttermsid:" + resultQuote.GetAttributeValue<EntityReference>("niq_paymenttermsid"));
                }
                if (resultQuote.Attributes.Contains("niq_parentmsaquoteid") && resultQuote.Attributes["niq_parentmsaquoteid"] != null)
                {
                    tracingService.Trace("Updating niq_parentmsaquoteid");
                    updateQuote["niq_parentmsaquoteid"] = resultQuote.GetAttributeValue<EntityReference>("niq_parentmsaquoteid");
                    tracingService.Trace("niq_parentmsaquoteid:" + resultQuote.GetAttributeValue<EntityReference>("niq_parentmsaquoteid"));
                }
                if (resultQuote.Attributes.Contains("niq_msapaymentterm") && resultQuote.Attributes["niq_msapaymentterm"] != null)
                {
                    tracingService.Trace("Updating niq_msapaymentterm");
                    updateQuote["niq_msapaymentterm"] = resultQuote.GetAttributeValue<EntityReference>("niq_msapaymentterm");
                    tracingService.Trace("niq_msapaymentterm:" + resultQuote.GetAttributeValue<EntityReference>("niq_msapaymentterm"));
                }
                //if (resultQuote.Contains("niq_quoteheaderdetailsapproval") && resultQuote.Attributes["niq_quoteheaderdetailsapproval"] != null)
                //{
                //    tracingService.Trace("Updating niq_quoteheaderdetailsapproval");
                //    updateQuote["niq_quoteheaderdetailsapproval"] = resultQuote.Attributes["niq_quoteheaderdetailsapproval"];
                //}
                //if (resultQuote.Contains("niq_overalldealdeskapproval") && resultQuote.Attributes["niq_overalldealdeskapproval"] != null)
                //{
                //    tracingService.Trace("Updating niq_overalldealdeskapproval");
                //    updateQuote["niq_overalldealdeskapproval"] = resultQuote.Attributes["niq_overalldealdeskapproval"];
                //}

                //if (resultQuote.Contains("niq_dealdeskapproval") && resultQuote.Attributes["niq_dealdeskapproval"] != null)
                //{
                //    tracingService.Trace("Updating niq_pricingapproval");
                //    updateQuote["niq_dealdeskapproval"] = resultQuote.Attributes["niq_dealdeskapproval"];
                //}
                //if (resultQuote.Contains("niq_fundusageapproval") && resultQuote.Attributes["niq_fundusageapproval"] != null)
                //{
                //    tracingService.Trace("Updating niq_fundusageapproval");
                //    updateQuote["niq_fundusageapproval"] = resultQuote.Attributes["niq_fundusageapproval"];
                //}
                if (postImageDDA.Contains("niq_overalldealdeskapproval") && postImageDDA.Attributes["niq_overalldealdeskapproval"] != null)
                {
                    tracingService.Trace("Updating niq_overalldealdeskapproval");
                    updateQuote["niq_overalldealdeskapproval"] = postImageDDA.Attributes["niq_overalldealdeskapproval"];
                }
                if (postImageDDA.Contains("niq_pricingapproval") && postImageDDA.Attributes["niq_pricingapproval"] != null)
                {
                    tracingService.Trace("Updating niq_pricingapproval");
                    updateQuote["niq_dealdeskapproval"] = postImageDDA.Attributes["niq_pricingapproval"];
                }
                if (postImageDDA.Contains("niq_fundusageapproval") && postImageDDA.Attributes["niq_fundusageapproval"] != null)
                {
                    tracingService.Trace("Updating niq_fundusageapproval");
                    updateQuote["niq_fundusageapproval"] = postImageDDA.Attributes["niq_fundusageapproval"];
                }
                if (postImageDDA.Contains("niq_quoteheaderdetailsapproval") && postImageDDA.Attributes["niq_quoteheaderdetailsapproval"] != null)
                {
                    tracingService.Trace("Updating niq_quoteheaderdetailsapproval");
                    updateQuote["niq_quoteheaderdetailsapproval"] = postImageDDA.Attributes["niq_quoteheaderdetailsapproval"];
                }
                return updateQuote;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
        }

        private Entity CreateQuoteUpdateRequestRevShare(Entity quote, Entity resultQuote, Entity postImageDDA, ITracingService tracingService, IOrganizationService service)
        {
            try
            {
                string functionName = "CreateQuoteUpdateRequest";
                tracingService.Trace("Inside " + functionName);

                Entity updateQuote = new Entity("quote");
                updateQuote.Id = quote.Id;
                tracingService.Trace("quote.Id:" + quote.Id);

                //Get and update Customer type
                if (resultQuote.Attributes.Contains("niq_customertype") && resultQuote.Attributes["niq_customertype"] != null)
                {
                    tracingService.Trace("Updating niq_customertype");
                    updateQuote["niq_customertype"] = new OptionSetValue(resultQuote.GetAttributeValue<OptionSetValue>("niq_customertype").Value);
                    tracingService.Trace("niq_customertype:" + resultQuote.GetAttributeValue<OptionSetValue>("niq_customertype").Value);
                }
                if (resultQuote.Attributes.Contains("niq_termtype") && resultQuote.Attributes["niq_termtype"] != null)
                {
                    tracingService.Trace("Updating niq_termtype");
                    updateQuote["niq_termtype"] = new OptionSetValue(resultQuote.GetAttributeValue<OptionSetValue>("niq_termtype").Value);
                    tracingService.Trace("niq_termtype:" + resultQuote.GetAttributeValue<OptionSetValue>("niq_termtype").Value);
                }

                if (resultQuote.Attributes.Contains("niq_agreementtype") && resultQuote.Attributes["niq_agreementtype"] != null)
                {
                    tracingService.Trace("Updating niq_agreementtype");
                    updateQuote["niq_agreementtype"] = new OptionSetValue(resultQuote.GetAttributeValue<OptionSetValue>("niq_agreementtype").Value);
                    tracingService.Trace("niq_agreementtype:" + resultQuote.GetAttributeValue<OptionSetValue>("niq_agreementtype").Value);
                }

                if (resultQuote.Attributes.Contains("niq_apistructure") && resultQuote.Attributes["niq_apistructure"] != null)
                {
                    tracingService.Trace("Updating niq_apistructure");
                    updateQuote["niq_apistructure"] = new OptionSetValue(resultQuote.GetAttributeValue<OptionSetValue>("niq_apistructure").Value);
                    tracingService.Trace("niq_apistructure:" + resultQuote.GetAttributeValue<OptionSetValue>("niq_apistructure").Value);
                }

                if (resultQuote.Attributes.Contains("niq_quotedefaultperiodicbillingfrequency") && resultQuote.Attributes["niq_quotedefaultperiodicbillingfrequency"] != null)
                {
                    tracingService.Trace("Updating niq_quotedefaultperiodicbillingfrequency");
                    updateQuote["niq_quotedefaultperiodicbillingfrequency"] = new OptionSetValue(resultQuote.GetAttributeValue<OptionSetValue>("niq_quotedefaultperiodicbillingfrequency").Value);
                    tracingService.Trace("niq_quotedefaultperiodicbillingfrequency:" + resultQuote.GetAttributeValue<OptionSetValue>("niq_quotedefaultperiodicbillingfrequency").Value);
                }

                if (resultQuote.Attributes.Contains("niq_annualapicola") && resultQuote.Attributes["niq_annualapicola"] != null)
                {
                    tracingService.Trace("Updating niq_annualapicola");
                    updateQuote["niq_annualapicola"] = resultQuote.GetAttributeValue<decimal>("niq_annualapicola");
                    tracingService.Trace("niq_annualapicola:" + resultQuote.GetAttributeValue<decimal>("niq_annualapicola"));
                }

                if (resultQuote.Attributes.Contains("niq_evergreenautorenewalannualapi") && resultQuote.Attributes["niq_evergreenautorenewalannualapi"] != null)
                {
                    tracingService.Trace("Updating niq_evergreenautorenewalannualapi");
                    updateQuote["niq_evergreenautorenewalannualapi"] = resultQuote.GetAttributeValue<decimal>("niq_evergreenautorenewalannualapi");
                    tracingService.Trace("niq_evergreenautorenewalannualapi:" + resultQuote.GetAttributeValue<decimal>("niq_evergreenautorenewalannualapi"));
                }

                if (resultQuote.Attributes.Contains("niq_numberofftes") && resultQuote.Attributes["niq_numberofftes"] != null)
                {
                    tracingService.Trace("Updating niq_numberofftes");
                    updateQuote["niq_numberofftes"] = resultQuote.GetAttributeValue<decimal>("niq_numberofftes");
                    tracingService.Trace("niq_numberofftes:" + resultQuote.GetAttributeValue<decimal>("niq_numberofftes"));
                }

                if (resultQuote.Attributes.Contains("niq_interestrateonlatepayment") && resultQuote.Attributes["niq_interestrateonlatepayment"] != null)
                {
                    tracingService.Trace("Updating niq_interestrateonlatepayment");
                    updateQuote["niq_interestrateonlatepayment"] = resultQuote.GetAttributeValue<decimal>("niq_interestrateonlatepayment");
                    tracingService.Trace("niq_interestrateonlatepayment:" + resultQuote.GetAttributeValue<decimal>("niq_interestrateonlatepayment"));
                }

                if (resultQuote.Attributes.Contains("niq_terminationnotificationmonths") && resultQuote.Attributes["niq_terminationnotificationmonths"] != null)
                {
                    tracingService.Trace("Updating niq_terminationnotificationmonths");
                    updateQuote["niq_terminationnotificationmonths"] = resultQuote.GetAttributeValue<int>("niq_terminationnotificationmonths");
                    tracingService.Trace("niq_terminationnotificationmonths:" + resultQuote.GetAttributeValue<int>("niq_terminationnotificationmonths"));
                }

                if (resultQuote.Attributes.Contains("niq_msapaymenttermdays") && resultQuote.Attributes["niq_msapaymenttermdays"] != null)
                {
                    tracingService.Trace("Updating niq_msapaymenttermdays");
                    updateQuote["niq_msapaymenttermdays"] = resultQuote.GetAttributeValue<int>("niq_msapaymenttermdays");
                    tracingService.Trace("niq_msapaymenttermdays:" + resultQuote.GetAttributeValue<int>("niq_msapaymenttermdays"));
                }

                if (resultQuote.Attributes.Contains("niq_modeleddayssalesoutstanding") && resultQuote.Attributes["niq_modeleddayssalesoutstanding"] != null)
                {
                    tracingService.Trace("Updating niq_modeleddayssalesoutstanding");
                    updateQuote["niq_modeleddayssalesoutstanding"] = resultQuote.GetAttributeValue<string>("niq_modeleddayssalesoutstanding");
                    tracingService.Trace("niq_modeleddayssalesoutstanding:" + resultQuote.GetAttributeValue<string>("niq_modeleddayssalesoutstanding"));
                }
                if (resultQuote.Attributes.Contains("niq_msapaymenttermdescription") && resultQuote.Attributes["niq_msapaymenttermdescription"] != null)
                {
                    tracingService.Trace("Updating niq_msapaymenttermdescription");
                    updateQuote["niq_msapaymenttermdescription"] = resultQuote.GetAttributeValue<string>("niq_msapaymenttermdescription");
                    tracingService.Trace("niq_msapaymenttermdescription:" + resultQuote.GetAttributeValue<string>("niq_msapaymenttermdescription"));
                }
                if (resultQuote.Attributes.Contains("niq_incentivecomments") && resultQuote.Attributes["niq_incentivecomments"] != null)
                {
                    tracingService.Trace("Updating niq_incentivecomments");
                    updateQuote["niq_incentivecomments"] = resultQuote.GetAttributeValue<string>("niq_incentivecomments");
                    tracingService.Trace("niq_incentivecomments:" + resultQuote.GetAttributeValue<string>("niq_incentivecomments"));
                }
                if (resultQuote.Attributes.Contains("niq_linktononstandardapprovalrequests") && resultQuote.Attributes["niq_linktononstandardapprovalrequests"] != null)
                {
                    tracingService.Trace("Updating niq_linktononstandardapprovalrequests");
                    updateQuote["niq_linktononstandardapprovalrequests"] = resultQuote.GetAttributeValue<string>("niq_linktononstandardapprovalrequests");
                    tracingService.Trace("niq_linktononstandardapprovalrequests:" + resultQuote.GetAttributeValue<string>("niq_linktononstandardapprovalrequests"));
                }

                if (resultQuote.Attributes.Contains("niq_fieldsrequiringapproval") && resultQuote.Attributes["niq_fieldsrequiringapproval"] != null)
                {
                    tracingService.Trace("Updating niq_fieldsrequiringapproval");
                    updateQuote["niq_fieldsrequiringapproval"] = resultQuote.GetAttributeValue<string>("niq_fieldsrequiringapproval");
                    tracingService.Trace("niq_fieldsrequiringapproval:" + resultQuote.GetAttributeValue<string>("niq_fieldsrequiringapproval"));
                }

                if (resultQuote.Attributes.Contains("niq_nonstandardbillingterm") && resultQuote.Attributes["niq_nonstandardbillingterm"] != null)
                {
                    tracingService.Trace("Updating niq_nonstandardbillingterm");
                    updateQuote["niq_nonstandardbillingterm"] = resultQuote.GetAttributeValue<bool>("niq_nonstandardbillingterm");
                    tracingService.Trace("niq_nonstandardbillingterm:" + resultQuote.GetAttributeValue<bool>("niq_nonstandardbillingterm"));
                }
                if (resultQuote.Attributes.Contains("niq_adhocproductsonlyquote") && resultQuote.Attributes["niq_adhocproductsonlyquote"] != null)
                {
                    tracingService.Trace("Updating niq_adhocproductsonlyquote");
                    updateQuote["niq_adhocproductsonlyquote"] = resultQuote.GetAttributeValue<bool>("niq_adhocproductsonlyquote");
                    tracingService.Trace("niq_adhocproductsonlyquote:" + resultQuote.GetAttributeValue<bool>("niq_adhocproductsonlyquote"));
                }

                if (resultQuote.Attributes.Contains("niq_parentmsaquoteid") && resultQuote.Attributes["niq_parentmsaquoteid"] != null)
                {
                    tracingService.Trace("Updating niq_parentmsaquoteid");
                    updateQuote["niq_parentmsaquoteid"] = resultQuote.GetAttributeValue<EntityReference>("niq_parentmsaquoteid");
                    tracingService.Trace("niq_parentmsaquoteid:" + resultQuote.GetAttributeValue<EntityReference>("niq_parentmsaquoteid"));
                }
                if (resultQuote.Attributes.Contains("niq_msapaymentterm") && resultQuote.Attributes["niq_msapaymentterm"] != null)
                {
                    tracingService.Trace("Updating niq_msapaymentterm");
                    updateQuote["niq_msapaymentterm"] = resultQuote.GetAttributeValue<EntityReference>("niq_msapaymentterm");
                    tracingService.Trace("niq_msapaymentterm:" + resultQuote.GetAttributeValue<EntityReference>("niq_msapaymentterm"));
                }

                if (postImageDDA.Contains("niq_overalldealdeskapproval") && postImageDDA.Attributes["niq_overalldealdeskapproval"] != null)
                {
                    tracingService.Trace("Updating niq_overalldealdeskapproval");
                    updateQuote["niq_overalldealdeskapproval"] = postImageDDA.Attributes["niq_overalldealdeskapproval"];
                }
                if (postImageDDA.Contains("niq_pricingapproval") && postImageDDA.Attributes["niq_pricingapproval"] != null)
                {
                    tracingService.Trace("Updating niq_pricingapproval");
                    updateQuote["niq_dealdeskapproval"] = postImageDDA.Attributes["niq_pricingapproval"];
                }
                if (postImageDDA.Contains("niq_fundusageapproval") && postImageDDA.Attributes["niq_fundusageapproval"] != null)
                {
                    tracingService.Trace("Updating niq_fundusageapproval");
                    updateQuote["niq_fundusageapproval"] = postImageDDA.Attributes["niq_fundusageapproval"];
                }
                if (postImageDDA.Contains("niq_quoteheaderdetailsapproval") && postImageDDA.Attributes["niq_quoteheaderdetailsapproval"] != null)
                {
                    tracingService.Trace("Updating niq_quoteheaderdetailsapproval");
                    updateQuote["niq_quoteheaderdetailsapproval"] = postImageDDA.Attributes["niq_quoteheaderdetailsapproval"];
                }
                return updateQuote;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
        }

        private void UpdateChildDDA(Guid id, ITracingService tracingService, Entity postImage, Guid opportunityId)
        {
            var updateRequests = new OrganizationRequestCollection();
            string functionName = "UpdateChildDDA";
            string fetchDDA = string.Empty;
            try
            {

                tracingService.Trace("Inside " + functionName);
                fetchDDA = BuildFetchDDAQuery(id, tracingService);

                EntityCollection results = service.RetrieveMultiple(new FetchExpression(fetchDDA));
                tracingService.Trace("results: " + results.Entities.Count);

                if (results.Entities.Count > 0)
                {
                    foreach (var childDDA in results.Entities)
                    {
                        var updateRequest = CreateUpdateRequest(childDDA.Id, tracingService);
                        updateRequests.Add(updateRequest);
                    }

                    ExecuteBatchUpdate(updateRequests, tracingService);


                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
        }

        private string BuildFetchDDAQuery(Guid id, ITracingService tracingService)
        {
            string functionName = "BuildFetchDDAQuery";
            tracingService.Trace("Inside " + functionName);

            return @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >
                    <entity name='niq_dealdeskapprovalrequest' >
                        <attribute name='niq_approvalstatus' />
                        <attribute name='niq_dealdeskapprovalrequestid' />
                        <link-entity name='quote' from='quoteid' to='niq_quoteid' visible='false' link-type='outer' alias='a_d96f887e7c52ec118c62000d3a5bc8e4' >
                                    </link-entity>
                        <link-entity name='opportunity' from='opportunityid' to='niq_opportunityid' visible='false' link-type='outer' alias='a_115cf1557c52ec118c62000d3a5bc8e4' >        </link-entity>
                        <link-entity name='quote' from='quoteid' to='niq_quoteid' link-type='inner' alias='bo' >
                            <link-entity name='opportunity' from='niq_mainquoteid' to='quoteid' link-type='inner' alias='bp' >
                                <filter type='and' >
                                    <condition attribute='niq_hostopportunity' operator='eq' value='{" + id + @"}' />
                                </filter>
                            </link-entity>
                        </link-entity>
                    </entity>
                </fetch>";
        }
        private string BuildQuoteQuery(Guid id, ITracingService tracingService)
        {
            string functionName = "BuildQuoteQuery";
            tracingService.Trace("Inside " + functionName);

            if (id != Guid.Empty)
            {
                return $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                      <entity name='quote'> 
                        <link-entity name='opportunity' from='opportunityid' to='opportunityid' link-type='inner' alias='opp'>
                          <attribute name='niq_stage' />
                          <attribute name='niq_salesorgid' />
                          <attribute name='parentaccountid' />
                          <filter type='and'>
                            <condition attribute='niq_hostopportunity' operator='eq' value='{{{id}}}' />
                          </filter>
                        </link-entity>
                      </entity>
                    </fetch>";
            }
            else
            {
                return string.Empty;
            }
        }

        private UpdateRequest CreateUpdateRequest(Guid childDDAId, ITracingService tracingService)
        {
            string functionName = "CreateUpdateRequest";
            tracingService.Trace("Inside " + functionName);

            var updateDDA = new Entity("niq_dealdeskapprovalrequest")
            {
                Id = childDDAId,
                ["niq_overalldealdeskapproval"] = new OptionSetValue(6)
            };
            return new UpdateRequest { Target = updateDDA };
        }

        private void ExecuteBatchUpdate(OrganizationRequestCollection updateRequests, ITracingService tracingService)
        {
            string functionName = "ExecuteBatchUpdate";
            tracingService.Trace("Inside " + functionName);

            if (updateRequests.Count > 0)
            {
                tracingService.Trace("updateRequests Count: " + updateRequests.Count);
                var executeMultipleRequest = new ExecuteMultipleRequest
                {
                    Requests = updateRequests,
                    Settings = new ExecuteMultipleSettings
                    {
                        ContinueOnError = false,
                        ReturnResponses = true
                    }
                };
                service.Execute(executeMultipleRequest);
                tracingService.Trace("Records Updated");
            }
        }
    }
}