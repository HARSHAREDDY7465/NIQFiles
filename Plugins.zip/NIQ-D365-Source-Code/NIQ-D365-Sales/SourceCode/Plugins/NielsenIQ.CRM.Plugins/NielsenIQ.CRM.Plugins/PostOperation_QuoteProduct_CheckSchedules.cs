﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace NielsenIQ.CRM.Plugins
{
    public class PostOperation_QuoteProduct_CheckSchedules : IPlugin
    {
        private ITracingService tracing = null;
        private IOrganizationService service = null;
        public readonly int CompleteManualInput = 610570004;
        public readonly int RevenuefrequencyCustom = 100000009;

        //common for revenue and billing 
        public readonly int QuoteCompleteSchedules = 610570001;
        public readonly int QuoteInCompleteSchedules = 610570002;
        private Entity UpdateQuote = new Entity("quote");

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                service = serviceFactory.CreateOrganizationService(context.UserId);
                ScheduleHelper scheduleHelper = new ScheduleHelper(tracing, service);

                // The InputParameters collection contains all the data 
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("PostOperation_QuoteProduct_CheckSchedules");
                    tracing.Trace("Entity : " + context.PrimaryEntityName);
                    tracing.Trace("Message : " + context.MessageName);

                    //trigger - niq_billingschedulestatus,niq_lineitemenddate,niq_revenueschedulestatus,niq_lineitemstartdate
                    if (context.PrimaryEntityName == "quotedetail" && context.MessageName.ToLower() == "update")
                    {
                        tracing.Trace("Quote product operations begins");
                        Entity targetQuoteProduct = (Entity)context.InputParameters["Target"];
                        tracing.Trace("quote product id:" + targetQuoteProduct.Id);

                        Entity PreImageQuoteProduct = (Entity)context.PreEntityImages["PreImage"];
                        //niq_lineitemenddate,quoteid,niq_deliveryfrequency,niq_revenueschedulestatus,niq_lineitemstartdate
                        Entity PostImageQuoteProduct = (Entity)context.PostEntityImages["PostImage"];//freqs, quoteid, revenu status, billing status

                        DateTime? CurrentStartDate = PostImageQuoteProduct.Contains("niq_lineitemstartdate") && PostImageQuoteProduct["niq_lineitemstartdate"] != null ? PostImageQuoteProduct.GetAttributeValue<DateTime?>("niq_lineitemstartdate") : null;
                        DateTime? CurrentEndDate = PostImageQuoteProduct.Contains("niq_lineitemenddate") && PostImageQuoteProduct["niq_lineitemenddate"] != null ? PostImageQuoteProduct.GetAttributeValue<DateTime?>("niq_lineitemenddate") : null;
                        DateTime? PreviousStartDate = PreImageQuoteProduct.Contains("niq_lineitemstartdate") && PreImageQuoteProduct["niq_lineitemstartdate"] != null ? PreImageQuoteProduct.GetAttributeValue<DateTime?>("niq_lineitemstartdate") : null;
                        DateTime? PreviousEndDate = PreImageQuoteProduct.Contains("niq_lineitemenddate") && PreImageQuoteProduct["niq_lineitemenddate"] != null ? PreImageQuoteProduct.GetAttributeValue<DateTime?>("niq_lineitemenddate") : null;


                        EntityReference Quote = PostImageQuoteProduct.GetAttributeValue<EntityReference>("quoteid");
                        tracing.Trace("quoteid :" + Quote.Id);
                        UpdateQuote.Id = Quote.Id;
                        tracing.Trace("niq_revenueschedulestatus - is changed ? : " + targetQuoteProduct.Contains("niq_revenueschedulestatus"));
                        tracing.Trace("niq_billingschedulestatus - is changed ? : " + targetQuoteProduct.Contains("niq_billingschedulestatus"));

                        if (targetQuoteProduct.Contains("niq_revenueschedulestatus") && targetQuoteProduct["niq_revenueschedulestatus"] != null)
                        {
                            tracing.Trace("Revenue schedule status: " + targetQuoteProduct.GetAttributeValue<OptionSetValue>("niq_revenueschedulestatus").Value);
                            UpdateQuote["niq_revenueschedulecomplete"] = scheduleHelper.checkIsRevenueSchedulesGenerated(Quote) ? new OptionSetValue(QuoteCompleteSchedules) : new OptionSetValue(QuoteInCompleteSchedules);
                        }


                        if (targetQuoteProduct.Contains("niq_billingschedulestatus") && targetQuoteProduct["niq_billingschedulestatus"] != null)
                        {
                            tracing.Trace("billingschedulestatus: " + targetQuoteProduct.GetAttributeValue<OptionSetValue>("niq_billingschedulestatus").Value);
                            UpdateQuote["niq_billingschedulecomplete"] = scheduleHelper.checkIsBillingSchedulesGenerated(Quote) ? new OptionSetValue(QuoteCompleteSchedules) : new OptionSetValue(QuoteInCompleteSchedules);

                        }

                        tracing.Trace("1: " + (targetQuoteProduct.Contains("niq_lineitemstartdate") || targetQuoteProduct.Contains("niq_lineitemenddate")));
                        tracing.Trace("2: " + (CurrentStartDate != null && PreviousStartDate != null && CurrentStartDate != PreviousStartDate));
                        tracing.Trace("3: " + (PreviousEndDate != null && PreviousEndDate != null && CurrentEndDate != PreviousEndDate));
                        tracing.Trace("4: " + (PostImageQuoteProduct.Contains("niq_deliveryfrequency") && PostImageQuoteProduct["niq_deliveryfrequency"] != null));
                        tracing.Trace("5: " + (PostImageQuoteProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency").Value == RevenuefrequencyCustom));
                        tracing.Trace("6: " + (PostImageQuoteProduct.GetAttributeValue<OptionSetValue>("niq_revenueschedulestatus").Value == CompleteManualInput));
                        //refactor  check for schedule completion -- rev completed
                        if ((targetQuoteProduct.Contains("niq_lineitemstartdate") || targetQuoteProduct.Contains("niq_lineitemenddate")) &&
                            ((CurrentStartDate != null && PreviousStartDate != null && CurrentStartDate != PreviousStartDate) ||
                            (PreviousEndDate != null && PreviousEndDate != null && CurrentEndDate != PreviousEndDate)) &&
                            PostImageQuoteProduct.Contains("niq_deliveryfrequency") && PostImageQuoteProduct["niq_deliveryfrequency"] != null &&
                            PostImageQuoteProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency").Value == RevenuefrequencyCustom &&
                            PostImageQuoteProduct.GetAttributeValue<OptionSetValue>("niq_revenueschedulestatus").Value == CompleteManualInput)
                        {
                            tracing.Trace("Custom schedule check Starts, because the dates on quote products changed");
                            UpdateQuote["niq_tracecustomscheduledates"] = scheduleHelper.IsSchedulesWithQuoteProductDates(Quote);
                        }
                    }
                    //when a qp is delete it is handled in OnUpdate_Quote_DD_ValidateDealDesk;
                    if (context.PrimaryEntityName == "quotedetail" && context.MessageName.ToLower() == "create")
                    {
                        tracing.Trace("when the product is deleted or created.");
                        Entity targetQuoteProduct = (Entity)context.InputParameters["Target"];
                        Entity quoteProductImage = null;
                        if (context.MessageName.ToLower() == "create")
                        {
                            tracing.Trace("For create take the postImage data for quoteid");
                            quoteProductImage = (Entity)context.PostEntityImages["PostImage"];
                        }

                        EntityReference Quote = quoteProductImage.GetAttributeValue<EntityReference>("quoteid");
                        UpdateQuote.Id = Quote.Id;
                        bool revenueScheduleCompleted = scheduleHelper.checkIsRevenueSchedulesGenerated(Quote);
                        UpdateQuote["niq_revenueschedulecomplete"] = revenueScheduleCompleted ? new OptionSetValue(QuoteCompleteSchedules) : new OptionSetValue(QuoteInCompleteSchedules);
                        UpdateQuote["niq_billingschedulecomplete"] = scheduleHelper.checkIsBillingSchedulesGenerated(Quote) ? new OptionSetValue(QuoteCompleteSchedules) : new OptionSetValue(QuoteInCompleteSchedules);

                        if (revenueScheduleCompleted)
                        {
                            UpdateQuote["niq_tracecustomscheduledates"] = scheduleHelper.IsSchedulesWithQuoteProductDates(Quote);
                        }

                    }
                    if (context.PrimaryEntityName == "niq_schedule")
                    {
                        tracing.Trace("schedule operations begins");

                        Entity targetSchedule = (Entity)context.InputParameters["Target"];
                        if (targetSchedule.Contains("niq_scheduledate"))
                        {
                            tracing.Trace("schedule date is changed");
                            //niq_lineitemid
                            Entity PostSchedule = (Entity)context.PostEntityImages["PostImage"];
                            if (PostSchedule.Contains("niq_lineitemid") && PostSchedule["niq_lineitemid"] != null)
                            {
                                Entity QuoteProduct = service.Retrieve("quotedetail",
                                    PostSchedule.GetAttributeValue<EntityReference>("niq_lineitemid").Id,
                                    new ColumnSet("niq_lineitemstartdate", "niq_lineitemenddate", "niq_deliveryfrequency", "niq_revenueschedulestatus", "quoteid"));
                                //refactor  check for schedule completion -- rev completed
                                if (QuoteProduct.Contains("niq_deliveryfrequency") && QuoteProduct["niq_deliveryfrequency"] != null &&
                                    QuoteProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency").Value == RevenuefrequencyCustom &&
                                    QuoteProduct.GetAttributeValue<OptionSetValue>("niq_revenueschedulestatus").Value == CompleteManualInput)
                                {
                                    EntityReference Quote = QuoteProduct.GetAttributeValue<EntityReference>("quoteid");
                                    UpdateQuote.Id = Quote.Id;
                                    UpdateQuote["niq_tracecustomscheduledates"] = scheduleHelper.IsSchedulesWithQuoteProductDates(Quote);
                                }

                            }
                        }

                    }

                    if (UpdateQuote.Attributes.Count > 0)
                    {
                        service.Update(UpdateQuote);
                        tracing.Trace("Quote is updated");
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("PostOperation_QuoteProduct_CheckSchedules : " + ex.Message);
            }
        }


    }


    public class ScheduleHelper
    {
        private ITracingService tracing = null;
        private IOrganizationService service = null;

        public readonly int IncompleteDataAuto = 610570000;
        public readonly int IncompleteManualInput = 610570001;
        public readonly int IncompleteSchedulesAuto = 610570002;
        public readonly int CompleteSchedulesAuto = 610570003;
        public readonly int CompleteManualInput = 610570004;

        public readonly int RevenuefrequencyCustom = 100000009;

        public readonly int MismatchedScheduleDates = 610570000;
        public readonly int MatchedScheduleDates = 610570001;
        //common for revenue and billing 
        public readonly int QuoteCompleteSchedules = 610570001;
        public readonly int QuoteInCompleteSchedules = 610570002;

        public ScheduleHelper(ITracingService tracingService, IOrganizationService service)
        {
            this.tracing = tracingService;
            this.service = service;
        }

        public bool checkIsRevenueSchedulesGenerated(EntityReference Quote)
        {
            tracing.Trace("CheckRevenueSchedule");
            QueryExpression query = new QueryExpression("quotedetail")
            {
                ColumnSet = new ColumnSet("niq_revenueschedulestatus"),
                Criteria =
                {
                      Filters =
                        {
                            new FilterExpression
                            {
                                FilterOperator = LogicalOperator.Or,
                                Conditions =
                                {
                                    new ConditionExpression("niq_revenueschedulestatus", ConditionOperator.Equal, IncompleteDataAuto),
                                    new ConditionExpression("niq_revenueschedulestatus", ConditionOperator.Equal, IncompleteManualInput),
                                    new ConditionExpression("niq_revenueschedulestatus", ConditionOperator.Equal, IncompleteSchedulesAuto),
                                    new ConditionExpression("niq_revenueschedulestatus", ConditionOperator.Null)
                                }
                            },
                            new FilterExpression
                            {
                                Conditions =
                                {
                                    new ConditionExpression("quoteid", ConditionOperator.Equal, Quote.Id)
                                }
                            }
                        }
                }
            };
            EntityCollection quoteProducts = service.RetrieveMultiple(query);
            tracing.Trace($"Total quote products: {quoteProducts.Entities.Count}");

            if (quoteProducts.Entities.Count > 0)
            {
                tracing.Trace("Incomplete revenue schedules are present in the Quote");
                return false;
            }
            return true;
        }

        public bool checkIsBillingSchedulesGenerated(EntityReference Quote)
        {
            tracing.Trace("CheckBillingSchedule");

            QueryExpression query = new QueryExpression("quotedetail")
            {
                ColumnSet = new ColumnSet("niq_billingschedulestatus"),
                Criteria =
                {
                      Filters =
                        {
                            new FilterExpression
                            {
                                FilterOperator = LogicalOperator.Or,
                                Conditions =
                                {
                                    new ConditionExpression("niq_billingschedulestatus", ConditionOperator.Equal, IncompleteDataAuto),
                                    new ConditionExpression("niq_billingschedulestatus", ConditionOperator.Equal, IncompleteManualInput),
                                    new ConditionExpression("niq_billingschedulestatus", ConditionOperator.Equal, IncompleteSchedulesAuto),
                                    new ConditionExpression("niq_billingschedulestatus", ConditionOperator.Null)
                                }
                            },
                            new FilterExpression
                            {
                                Conditions =
                                {
                                    new ConditionExpression("quoteid", ConditionOperator.Equal, Quote.Id)
                                }
                            }
                        }
                }
            };
            EntityCollection quoteProducts = service.RetrieveMultiple(query);
            tracing.Trace($"Total quote products: {quoteProducts.Entities.Count}");

            if (quoteProducts.Entities.Count > 0)
            {
                tracing.Trace("Incomplete Billing schedules are present in the Quote");
                return false;
            }
            return true;
        }

        //pass quote
        //fetchxml
        //if schedules are within limit or not
        // if no custom schedules
        // niq_tracecustomscheduledates - nulll
        // 

        //Before considering the "niq_tracecustomscheduledates" 
        public OptionSetValue IsSchedulesWithQuoteProductDates(EntityReference Quote)
        {
            tracing.Trace("Inside IsSchedulesWithQuoteProductDates");
            Entity quoteDetails = service.Retrieve("quote", Quote.Id, new ColumnSet("niq_revenueschedulecomplete"));
            OptionSetValue quoteScheduleStatus = quoteDetails.GetAttributeValue<OptionSetValue>("niq_revenueschedulecomplete");
            if (quoteScheduleStatus != null && quoteScheduleStatus.Value == QuoteCompleteSchedules)
            {
                var scheduletypeRevenueSchedule = 100000001;
                var scheduletypeRevenueForCastExcludedSchedule = 100000002;
                var fetchXml = $@"<fetch>
                    <entity name=""niq_schedule"">
                    <attribute name=""niq_lineitemid"" />
                    <attribute name=""niq_scheduledate"" />
                    <attribute name=""niq_scheduletype"" />
                    <filter type=""or"">
                        <condition attribute=""niq_scheduletype"" operator=""eq"" value=""{scheduletypeRevenueSchedule}"" />
                        <condition attribute=""niq_scheduletype"" operator=""eq"" value=""{scheduletypeRevenueForCastExcludedSchedule}"" />
                    </filter>
                    <link-entity name=""quotedetail"" from=""quotedetailid"" to=""niq_lineitemid"" alias=""qp"">
                        <attribute name=""niq_lineitemenddate"" />
                        <attribute name=""niq_lineitemstartdate"" />
                        <filter>
                        <condition attribute=""niq_revenueschedulestatus"" operator=""eq"" value=""{CompleteManualInput}"" />
                        <condition attribute=""niq_lineitemstartdate"" operator=""not-null""  />
                        <condition attribute=""niq_lineitemenddate"" operator=""not-null"" />
                        <condition attribute=""niq_deliveryfrequency"" operator=""eq"" value=""{RevenuefrequencyCustom}"" />
                        </filter>
                        <link-entity name=""quote"" from=""quoteid"" to=""quoteid"" alias=""quote"">
                        <filter>
                            <condition attribute=""quoteid"" operator=""eq"" value=""{Quote.Id}"" />
                        </filter>
                        </link-entity>
                    </link-entity>
                    </entity>
                </fetch>";

                EntityCollection schedules = service.RetrieveMultiple(new FetchExpression(fetchXml));
                tracing.Trace("Existing no of Schedules: " + schedules.Entities.Count);

                if (schedules.Entities.Count == 0)
                {
                    tracing.Trace("There is no custom products, so make the niq_tracecustomscheduledates is empty");
                    return null;
                }
                else
                {
                    int validSchedules = schedules.Entities.Select(e => new
                    {
                        scheduleDate = e.GetAttributeValue<DateTime>("niq_scheduledate"),
                        startDate = (DateTime)e.GetAttributeValue<AliasedValue>("qp.niq_lineitemstartdate").Value,
                        endDate = (DateTime)e.GetAttributeValue<AliasedValue>("qp.niq_lineitemenddate").Value
                    }).Where(e => e.scheduleDate >= e.startDate && e.scheduleDate <= e.endDate).ToList().Count;

                    tracing.Trace("No of Valid schedules :" + validSchedules);
                    tracing.Trace("trace custom scheduels dates status is  : " + ((schedules.Entities.Count == validSchedules) ? "Match schedule dates" : "Mistmatch schedules date"));
                    return schedules.Entities.Count == validSchedules ? new OptionSetValue(MatchedScheduleDates) : new OptionSetValue(MismatchedScheduleDates);
                }
            }
            return null;
        }
    }
}
