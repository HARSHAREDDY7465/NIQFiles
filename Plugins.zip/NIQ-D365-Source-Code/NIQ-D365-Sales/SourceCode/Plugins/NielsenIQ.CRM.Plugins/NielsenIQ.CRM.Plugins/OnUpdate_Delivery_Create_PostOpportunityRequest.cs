﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;


namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Delivery_Create_PostOpportunityRequest : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                IOrganizationService serviceEodSubmittedUser = service;
                Guid InitiatingUser = context.InitiatingUserId;
                IOrganizationService InitiatingUserService = serviceFactory.CreateOrganizationService(InitiatingUser);

                if (context.Depth > 2)
                {
                    return;
                }

                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_Delivery_Create_PostOpportunityRequest: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters
                    Entity deliveryObj = (Entity)context.InputParameters["Target"];

                    if (deliveryObj != null && deliveryObj.Id != Guid.Empty)
                    {
                        Entity retDelivery = service.Retrieve(deliveryObj.LogicalName, deliveryObj.Id, new ColumnSet("niq_opportunityid", "statecode", "niq_dateofdelivery", "niq_deliverystatus", "niq_eodfilesubmittedbyuser"));
                        if (retDelivery != null && retDelivery.Id != Guid.Empty)
                        {
                            tracing.Trace("OnUpdate_Delivery_Create_PostOpportunityRequests: EOD user." + retDelivery.GetAttributeValue<string>("niq_eodfilesubmittedbyuser"));

                            //Obtain the "EOD File Submitted By User" credentials 

                            if (retDelivery.Attributes.Contains("niq_eodfilesubmittedbyuser"))
                            {
                                QueryExpression qe = new QueryExpression("systemuser");
                                qe.Criteria.AddCondition("internalemailaddress", ConditionOperator.Equal, retDelivery.GetAttributeValue<string>("niq_eodfilesubmittedbyuser"));
                                qe.Criteria.AddCondition("isdisabled", ConditionOperator.Equal, false);
                                EntityCollection userCol = service.RetrieveMultiple(qe);
                                tracing.Trace("OnUpdate_Delivery_Create_PostOpportunityRequests:user count." + userCol.Entities.Count.ToString());

                                //check the user exists in crm or not
                                if (userCol != null && userCol.Entities.Count > 0)
                                {
                                    Guid UserGuid = userCol.Entities[0].Id;
                                    serviceEodSubmittedUser = serviceFactory.CreateOrganizationService(UserGuid);
                                }
                            }

                            tracing.Trace("OnUpdate_Delivery_Create_PostOpportunityRequest: retDelivery1" + retDelivery.Id);
                            if (deliveryObj.Attributes.Contains("niq_proposeddeliverydate") && ((OptionSetValue)retDelivery.Attributes["niq_deliverystatus"]) != null && (retDelivery.GetAttributeValue<OptionSetValue>("niq_deliverystatus")).Value != 100000003)
                            {
                                tracing.Trace("OnUpdate_Delivery_Create_PostOpportunityRequest: dateofdelivery triggers ");
                                Entity postOpportunityReq = new Entity("niq_postopportunity");
                                postOpportunityReq["niq_typeofchange"] = new OptionSetValue(100000003);
                                postOpportunityReq["niq_deliveryid"] = new EntityReference(deliveryObj.LogicalName, deliveryObj.Id);
                                postOpportunityReq["niq_descriptionofchange"] = "Delivery Date Change";
                                if (retDelivery.Attributes.Contains("niq_opportunityid"))
                                {
                                    postOpportunityReq["niq_opportunity"] = (EntityReference)retDelivery.GetAttributeValue<EntityReference>("niq_opportunityid");
                                    tracing.Trace("OnUpdate_Delivery_Create_PostOpportunityRequest: contains oppo ");
                                    Entity retOppo = service.Retrieve(retDelivery.GetAttributeValue<EntityReference>("niq_opportunityid").LogicalName, retDelivery.GetAttributeValue<EntityReference>("niq_opportunityid").Id, new ColumnSet("niq_salesorgid"));
                                    if (retOppo != null && retOppo.Id != Guid.Empty)
                                    {
                                        tracing.Trace("OnUpdate_Delivery_Create_PostOpportunityRequest: retOppo" + retOppo.Id);
                                        if (retOppo.Attributes.Contains("niq_salesorgid"))
                                        {
                                            Entity retFinanceTeam = service.Retrieve(retOppo.GetAttributeValue<EntityReference>("niq_salesorgid").LogicalName, retOppo.GetAttributeValue<EntityReference>("niq_salesorgid").Id, new ColumnSet("niq_financeteam"));
                                            if (retFinanceTeam != null && retFinanceTeam.Id != Guid.Empty && retFinanceTeam.Attributes.Contains("niq_financeteam"))
                                            {
                                                //tracing.Trace("initiating user: " + InitiatingUser);
                                                //tracing.Trace("calling user: " + context.UserId);
                                                Guid postOppoReq = InitiatingUserService.Create(postOpportunityReq);

                                                Entity createdPostOppoReqchange = new Entity("niq_postopportunity");
                                                createdPostOppoReqchange.Id = postOppoReq;
                                                createdPostOppoReqchange["niq_approvalstatus"] = new OptionSetValue(1);
                                                createdPostOppoReqchange["ownerid"] = (EntityReference)retFinanceTeam.GetAttributeValue<EntityReference>("niq_financeteam");
                                                service.Update(createdPostOppoReqchange);
                                                tracing.Trace("OnUpdate_Delivery_Create_PostOpportunityRequest: record created " + postOppoReq);

                                            }
                                        }
                                    }
                                }

                            }
                            if (deliveryObj.Attributes.Contains("niq_deliverystatus") && ((OptionSetValue)deliveryObj.Attributes["niq_deliverystatus"]) != null && (deliveryObj.GetAttributeValue<OptionSetValue>("niq_deliverystatus")).Value == 100000003)
                            {
                                tracing.Trace("OnUpdate_Delivery_Create_PostOpportunityRequest: trigger eod document");

                                if (retDelivery.Attributes.Contains("statecode") && retDelivery.GetAttributeValue<OptionSetValue>("statecode").Value == 1)
                                {
                                    tracing.Trace("OnUpdate_Delivery_Create_PostOpportunityRequest: Returning because Delivery is inactive");
                                    return;
                                }

                                // Retrieve and update the "Deliverydatechange" pocrs to Rejected.
                                string pocrfetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='niq_postopportunity'>                                                                                                               
                                                        <attribute name='niq_postopportunityid' />                                                        
                                                        <filter type='and'>
                                                          <condition attribute='niq_deliveryid' operator='eq'  value='{0}' />
                                                          <condition attribute='niq_typeofchange' operator='eq' value='100000003' />                                                         
                                                          <condition attribute='niq_approvalstatus' operator='eq' value='1' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";
                                pocrfetchXml = string.Format(pocrfetchXml, retDelivery.Id);
                                var pocrresult = service.RetrieveMultiple(new FetchExpression(pocrfetchXml));
                                if (pocrresult != null && pocrresult.Entities != null && pocrresult.Entities.Count > 0)
                                {
                                    foreach (Entity pocr in pocrresult.Entities)
                                    {
                                        tracing.Trace("Pocr name:" + pocr.GetAttributeValue<string>("niq_postopportunity"));
                                        Entity updatedPocr = new Entity(pocr.LogicalName, pocr.Id);
                                        updatedPocr["niq_approvalstatus"] = new OptionSetValue(3);
                                        updatedPocr["niq_comments"] = "Auto-rejection due to submitted EOD.";
                                        service.Update(updatedPocr);
                                    }
                                }


                                if (retDelivery.Attributes.Contains("niq_opportunityid"))
                                {
                                    Entity retOppo = service.Retrieve(retDelivery.GetAttributeValue<EntityReference>("niq_opportunityid").LogicalName, retDelivery.GetAttributeValue<EntityReference>("niq_opportunityid").Id, new ColumnSet("niq_salesorgid", "niq_businessarea"));
                                    if (retOppo.Contains("niq_businessarea") && retOppo.GetAttributeValue<OptionSetValue>("niq_businessarea").Value == 100000000 && retDelivery.Contains("niq_dateofdelivery"))
                                    {
                                        DateTime todayDate = DateTime.Now;
                                        DateTime priviousConfirmDeliveryDate = (DateTime)retDelivery.Attributes["niq_dateofdelivery"];
                                        if (priviousConfirmDeliveryDate.Date != todayDate.Date)
                                        {
                                            Entity deliveryToUpdate = new Entity(retDelivery.LogicalName, retDelivery.Id);
                                            deliveryToUpdate["niq_proposeddeliverydate"] = todayDate;
                                            service.Update(deliveryToUpdate);
                                        }
                                    }
                                    Entity postOpportunityReq = new Entity("niq_postopportunity");
                                    postOpportunityReq["niq_opportunity"] = (EntityReference)retDelivery.GetAttributeValue<EntityReference>("niq_opportunityid");
                                    postOpportunityReq["niq_descriptionofchange"] = "Evidence of Delivery (EoD) Submission";
                                    tracing.Trace("OnUpdate_Delivery_Create_PostOpportunityRequest:contains oppo id ");

                                    if (retOppo != null && retOppo.Id != Guid.Empty)
                                    {
                                        /*if (retOppo.Attributes.Contains("niq_businessarea") && ((OptionSetValue)retOppo.Attributes["niq_businessarea"]).Value == 100000000)
                                        {
                                            postOpportunityReq["niq_approvalstatus"] = new OptionSetValue(2);

                                            tracing.Trace("OnUpdate_Delivery_Create_PostOpportunityRequest:Update approval status for bases BA ");
                                        }
                                        */
                                        string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='niq_postopportunity'>
                                                        <attribute name='niq_postopportunity' />
                                                        <attribute name='createdon' />
                                                        <attribute name='niq_postopportunityid' />
                                                        <order attribute='niq_postopportunity' descending='false' />
                                                        <filter type='and'>
                                                          <condition attribute='niq_deliveryid' operator='eq' uitype='niq_delivery' value='{0}' />
                                                          <condition attribute='niq_typeofchange' operator='eq' value='100000004' />
                                                          <condition attribute='niq_opportunity' operator='eq'  uitype='opportunity' value='{1}' />
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";
                                        fetchXml = string.Format(fetchXml, retDelivery.Id, retOppo.Id);
                                        var result = service.RetrieveMultiple(new FetchExpression(fetchXml));
                                        if (result != null && result.Entities != null && result.Entities.Count > 0)
                                        {
                                            foreach (Entity postOppo in result.Entities)
                                            {
                                                Entity updPostOppo = new Entity(postOppo.LogicalName, postOppo.Id);
                                                updPostOppo["statecode"] = new OptionSetValue(1);
                                                service.Update(updPostOppo);
                                            }
                                        }
                                        postOpportunityReq["niq_typeofchange"] = new OptionSetValue(100000004);
                                        postOpportunityReq["niq_deliveryid"] = new EntityReference(deliveryObj.LogicalName, deliveryObj.Id);

                                        tracing.Trace("OnUpdate_Delivery_Create_PostOpportunityRequest: retOppo" + retOppo.Id);

                                        if (retOppo.Attributes.Contains("niq_salesorgid"))
                                        {
                                            Entity retFinanceTeam = service.Retrieve(retOppo.GetAttributeValue<EntityReference>("niq_salesorgid").LogicalName, retOppo.GetAttributeValue<EntityReference>("niq_salesorgid").Id, new ColumnSet("niq_financeteam"));
                                            if (retFinanceTeam != null && retFinanceTeam.Id != Guid.Empty && retFinanceTeam.Attributes.Contains("niq_financeteam"))
                                            {
                                                tracing.Trace("financeteam");
                                                /* if (!postOpportunityReq.Attributes.Contains("niq_approvalstatus"))
                                                 {
                                                    postOpportunityReq["niq_approvalstatus"] = new OptionSetValue(1);
                                                 }
                                                postOpportunityReq["ownerid"] = (EntityReference)retFinanceTeam.GetAttributeValue<EntityReference>("niq_financeteam");
                                               */
                                                Guid postOppoReq = serviceEodSubmittedUser.Create(postOpportunityReq);
                                                tracing.Trace("aftercreatenew");

                                                Entity createdPostOppoReq = service.Retrieve("niq_postopportunity", postOppoReq, new ColumnSet("statecode", "niq_approvalstatus"));

                                                if (retOppo.Attributes.Contains("niq_businessarea") && ((OptionSetValue)retOppo.Attributes["niq_businessarea"]) != null && ((OptionSetValue)retOppo.Attributes["niq_businessarea"]).Value == 100000000)
                                                {
                                                    createdPostOppoReq["niq_approvalstatus"] = new OptionSetValue(2);

                                                    tracing.Trace("OnUpdate_Delivery_Create_PostOpportunityRequest:Update approval status for bases BA ");
                                                }

                                                if (!createdPostOppoReq.Attributes.Contains("niq_approvalstatus"))
                                                {
                                                    tracing.Trace("approvalstatus");
                                                    createdPostOppoReq["niq_approvalstatus"] = new OptionSetValue(1);
                                                }

                                                createdPostOppoReq["ownerid"] = (EntityReference)retFinanceTeam.GetAttributeValue<EntityReference>("niq_financeteam");

                                                if (createdPostOppoReq.Attributes.Contains("niq_approvalstatus") && (createdPostOppoReq.GetAttributeValue<OptionSetValue>("niq_approvalstatus")).Value == 2)
                                                {
                                                    tracing.Trace("statecode");
                                                    createdPostOppoReq["statecode"] = new OptionSetValue(1);
                                                }
                                                service.Update(createdPostOppoReq);
                                                tracing.Trace("OnUpdate_Delivery_Create_PostOpportunityRequest: created record " + postOppoReq);

                                            }
                                        }
                                    }
                                }

                            }


                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
