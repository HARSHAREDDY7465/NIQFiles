﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Opportunity_SalesOrg_ValidateChange : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                if (context.Depth > 1)
                {
                    tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange: Context Depth > 1");
                    return;
                }



                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity oppoObj = (Entity)context.InputParameters["Target"];
                    if (oppoObj != null && oppoObj.Id != Guid.Empty && oppoObj.Attributes.Contains("niq_salesorgid") && oppoObj.GetAttributeValue<EntityReference>("niq_salesorgid").Id != Guid.Empty)
                    {
                        tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange:Oppo ID" + oppoObj.Id);
                        string fetchQuoteRP = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                              <entity name='quote'>
                                                <attribute name='name' />                                                
                                                <attribute name='opportunityid' />
                                                <attribute name='niq_mainquote' />                                               
                                                <attribute name='quoteid' />
                                                <order attribute='name' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='opportunityid' operator='eq' uitype='opportunity' value='{0}' />
                                                </filter>
                                                <link-entity name='opportunity' from='opportunityid' to='opportunityid' visible='false' link-type='outer' alias='a_8722b5f2a2eceb11bacb000d3a35ee6d'>
                                                  <attribute name='niq_stage' />
                                                  <attribute name='niq_salesorgid' />
                                                  <attribute name='parentaccountid' />
                                                </link-entity>
                                                <link-entity name='quotedetail' from='quoteid' to='quoteid' link-type='inner' alias='by'>
                                                  <filter type='and'>
                                                    <condition attribute='productid' operator='not-null' />
                                                  </filter>
                                                </link-entity>
                                              </entity>
                                            </fetch>";
                        fetchQuoteRP = string.Format(fetchQuoteRP, oppoObj.Id);
                        var resultQuoteRP = service.RetrieveMultiple(new FetchExpression(fetchQuoteRP));
                        if (resultQuoteRP != null && resultQuoteRP.Entities != null && resultQuoteRP.Entities.Count > 0)
                        {
                            tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange: resultQuoteRP Count" + resultQuoteRP.Entities.Count);
                            throw new InvalidPluginExecutionException("This opportunity has one or several related quotes with products selected for the previous sales org. Before sales org value can be changed, these quotes have to be closed. Please close all related quotes first by clicking \"Close Open Quotes As Lost\" button");
                        }
                        else
                        {
                            Entity retOppo = service.Retrieve(oppoObj.LogicalName, oppoObj.Id, new ColumnSet("parentaccountid", "ownerid", "transactioncurrencyid", "name", "niq_salesorgid"));
                            tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange: ret Oppo" + retOppo.Id);
                            string fetchQuoteNP = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                                      <entity name='quote'>
                                                        <attribute name='name' />                                                        
                                                        <attribute name='opportunityid' />
                                                        <attribute name='niq_mainquote' />                                                       
                                                        <attribute name='quoteid' />
                                                        <order attribute='name' descending='false' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='opportunityid' operator='eq' uitype='opportunity' value='{0}' />
                                                        </filter>
                                                        <link-entity name='opportunity' from='opportunityid' to='opportunityid' visible='false' link-type='outer' alias='a_8722b5f2a2eceb11bacb000d3a35ee6d'>
                                                          <attribute name='niq_stage' />
                                                          <attribute name='niq_salesorgid' />
                                                          <attribute name='parentaccountid' />
                                                        </link-entity>
                                                        <link-entity name='quotedetail' from='quoteid' to='quoteid' link-type='outer' alias='bz' />
                                                        <filter type='and'>
                                                          <condition entityname='bz' attribute='quoteid' operator='null' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";
                            fetchQuoteNP = string.Format(fetchQuoteNP, oppoObj.Id);
                            var resultQuoteNP = service.RetrieveMultiple(new FetchExpression(fetchQuoteNP));
                            if (resultQuoteNP != null && resultQuoteNP.Entities != null && resultQuoteNP.Entities.Count > 0)
                            {
                                tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange: resultQuoteNP" + resultQuoteNP.Entities.Count);
                                foreach (Entity quote in resultQuoteNP.Entities)
                                {
                                    Entity updQuote = new Entity(quote.LogicalName, quote.Id);
                                    tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange: quote id" + quote.Id);
                                    updQuote["niq_salesorgid"] = (EntityReference)retOppo.GetAttributeValue<EntityReference>("niq_salesorgid");

                                    Guid salesOrgId = ((EntityReference)retOppo["niq_salesorgid"]).Id;
                                    QueryExpression salesOrgQuery = new QueryExpression("niq_salesorg");
                                    salesOrgQuery.TopCount = 1;
                                    salesOrgQuery.ColumnSet.AddColumns("niq_operatingcountryid");
                                    salesOrgQuery.Criteria.AddCondition("niq_salesorgid", ConditionOperator.Equal, salesOrgId);
                                    var salesOrgRecords = service.RetrieveMultiple(salesOrgQuery);
                                    if (salesOrgRecords != null && salesOrgRecords.Entities != null && salesOrgRecords.Entities.Count > 0)
                                    {
                                        foreach (Entity record in salesOrgRecords.Entities)
                                        {
                                            if (record.Attributes.Contains("niq_operatingcountryid"))
                                            {
                                                Entity country = service.Retrieve(record.GetAttributeValue<EntityReference>("niq_operatingcountryid").LogicalName, record.GetAttributeValue<EntityReference>("niq_operatingcountryid").Id, new ColumnSet("niq_countrycode"));
                                                if (country != null && country.Id != Guid.Empty && country.Attributes.Contains("niq_countrycode"))
                                                {
                                                    updQuote["niq_market"] = country.GetAttributeValue<string>("niq_countrycode");
                                                    tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange: niqMarket is " + country.GetAttributeValue<string>("niq_countrycode"));
                                                    break;
                                                }
                                                else
                                                {
                                                    updQuote["niq_market"] = null;
                                                    tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange: niqMarket is null");
                                                    break;
                                                }

                                            }
                                            else
                                            {
                                                updQuote["niq_market"] = null;
                                                tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange: niqMarket is null");

                                            }
                                        }
                                    }
                                    else
                                    {
                                        updQuote["niq_market"] = null;
                                        tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange: niqMarket is null");

                                    }

                                    tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange: updating sales org for quote" + quote.Id);
                                    service.Update(updQuote);
                                    tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange: sales org updated for quote" + quote.Id);

                                }

                            }
                            else
                            {
                                tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange:No Result for NP or RP");
                                if (retOppo != null && retOppo.Id != Guid.Empty && retOppo.Attributes.Contains("niq_salesorgid") && retOppo.Attributes.Contains("parentaccountid") && retOppo.Attributes.Contains("ownerid") && retOppo.Attributes.Contains("transactioncurrencyid") && retOppo.Attributes.Contains("name"))
                                {
                                    tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange:retOppo Contains Data");
                                    Entity createQuote = new Entity("quote");
                                    createQuote["niq_salesorgid"] = new EntityReference(retOppo.GetAttributeValue<EntityReference>("niq_salesorgid").LogicalName, retOppo.GetAttributeValue<EntityReference>("niq_salesorgid").Id);
                                    createQuote["customerid"] = new EntityReference(retOppo.GetAttributeValue<EntityReference>("parentaccountid").LogicalName, retOppo.GetAttributeValue<EntityReference>("parentaccountid").Id);
                                    createQuote["ownerid"] = new EntityReference(retOppo.GetAttributeValue<EntityReference>("ownerid").LogicalName, retOppo.GetAttributeValue<EntityReference>("ownerid").Id);
                                    createQuote["transactioncurrencyid"] = new EntityReference(retOppo.GetAttributeValue<EntityReference>("transactioncurrencyid").LogicalName, retOppo.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                                    createQuote["opportunityid"] = new EntityReference(retOppo.LogicalName, retOppo.Id);
                                    createQuote["name"] = "Quote1_" + retOppo.GetAttributeValue<string>("name");
                                    Guid quoteId = service.Create(createQuote);
                                    if (quoteId != Guid.Empty)
                                    {
                                        tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange:retOppo quote id" + quoteId);
                                        tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange:Updating Main quote for oppo " + retOppo.Id);
                                        Entity updOppo = new Entity(retOppo.LogicalName, retOppo.Id);
                                        updOppo["niq_mainquoteid"] = new EntityReference("quote", quoteId);
                                        service.Update(updOppo);
                                        tracing.Trace("OnUpdate_Opportunity_SalesOrg_ValidateChange: Update Main quote success");
                                    }
                                }
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
