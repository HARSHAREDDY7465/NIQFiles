﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.Plugins
{
    public class PaymentTermsApproval : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                int ModeledDaysSalesOutstandingNew = Int32.Parse(context.InputParameters["ModeledDaysSalesOutstandingNew"] as string);
                int ModeledDaysSalesOutstandingOld = Int32.Parse(context.InputParameters["ModeledDaysSalesOutstandingOld"] as string);
                string PaymentTermsNameNew = context.InputParameters["PaymentTermsNameNew"] as string;
                string PaymentTermsNameOld = context.InputParameters["PaymentTermsNameOld"] as string;
                int PaymentTermInDaysNew = (int)context.InputParameters["PaymentTermInDaysNew"];
                int MSAPaymentTermsNew = (int)context.InputParameters["MSAPaymentTermsNew"];
                OptionSetValue accountCustomerType = (OptionSetValue)context.InputParameters["CustomerTypeAccountNew"];
                OptionSetValue quoteCustomerType = (OptionSetValue)context.InputParameters["CustomerTypeNew"];
                OptionSetValue accountCustomerTypeDDAR = (OptionSetValue)context.InputParameters["CustomerTypeAccountOld"];
                OptionSetValue quoteCustomerTypeDDAR = (OptionSetValue)context.InputParameters["CustomerTypeOld"];
                OptionSetValue termTypeDDAR = (OptionSetValue)context.InputParameters["TermTypeOld"];
                OptionSetValue termTypeQuote = (OptionSetValue)context.InputParameters["TermTypeNew"];
                OptionSetValue annualIncreaseTypeDDAR = (OptionSetValue)context.InputParameters["AnnualIncreaseTypeOld"];
                OptionSetValue annualIncreaseTypeQuote = (OptionSetValue)context.InputParameters["AnnualIncreaseTypeNew"];
                bool salesOrg0500 = (bool)context.InputParameters["SalesOrg0500"];
                bool salesOrg = (bool)context.InputParameters["SalesOrg"];
                int contractDuration = (int)context.InputParameters["ContractDuration"];
                int contractDurationDDAR = (int)context.InputParameters["ContractDurationDDAR"];
                decimal annualApiColaQuote = (decimal)context.InputParameters["AnnualApiColaNew"];
                decimal annualApiColaDDAR = (decimal)context.InputParameters["AnnualApiColaOld"];
                OptionSetValue annualApiColaStructureDDAR = (OptionSetValue)context.InputParameters["AnnualApiColaStructureOld"];
                OptionSetValue annualApiColaStructureQuote = (OptionSetValue)context.InputParameters["AnnualApiColaStructureNew"];
                decimal evergreenAutoRenewalAPIQuote = (decimal)context.InputParameters["EvergreenAutoRenewalAPINew"];
                decimal evergreenAutoRenewalAPIDDAR = (decimal)context.InputParameters["EvergreenAutoRenewalAPIOld"];
                decimal numberOfFTEsQuote = (decimal)context.InputParameters["NumberOfFTEsNew"];
                decimal numberOfFTEsDDAR = (decimal)context.InputParameters["NumberOfFTEsOld"];
                decimal latePaymentPenaltyQuote = (decimal)context.InputParameters["LatePaymentPenaltyQuoteNew"];
                decimal latePaymentPenaltysDDAR = (decimal)context.InputParameters["LatePaymentPenaltyQuoteOld"];
                bool nonStandardBillingTermQuote = (bool)context.InputParameters["NonStandardBillingTermNew"];
                bool nonStandardBillingTermDDAR = (bool)context.InputParameters["NonStandardBillingTermOld"];
                OptionSetValue quoteDefaultPeriodicBillingFrequencyDDAR = (OptionSetValue)context.InputParameters["QuoteDefaultPeriodicBillingFrequencyOld"];
                OptionSetValue quoteDefaultPeriodicBillingFrequencyQuote = (OptionSetValue)context.InputParameters["QuoteDefaultPeriodicBillingFrequencyNew"];
                string linktoNonStandardApprovalRequestsDDAR = context.InputParameters["LinktoNonStandardApprovalRequestsOld"] as string;
                string linktoNonStandardApprovalRequestsQuote = context.InputParameters["LinktoNonStandardApprovalRequestsNew"] as string;
                int terminationNotificationMonthQuote = (int)context.InputParameters["TerminationNotificationMonth"];
                int terminationNotificationMonthDDAR = (int)context.InputParameters["TerminationNotificationMonthOld"];
                OptionSetValue incentiveTypeQuote = (OptionSetValue)context.InputParameters["IncentiveType"];
                OptionSetValue incentiveTypeDDAR = (OptionSetValue)context.InputParameters["IncentiveTypeOld"];
                int incentiveValueQuote = (int)context.InputParameters["IncentiveValue"];
                int incentiveValueDDAR = (int)context.InputParameters["IncentiveValueOld"];
                bool isPOC = (bool)context.InputParameters["POC"];
                string approvalFields = null;
                context.OutputParameters["Result"] = false;

                // Agreement Payment Terms Conditions 
                if (MSAPaymentTermsNew == 0 && PaymentTermsNameOld == "0" && ModeledDaysSalesOutstandingOld == 0 && PaymentTermInDaysNew > 30)
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = "Agreement Payment Terms";
                }
                if (MSAPaymentTermsNew == 0 && PaymentTermsNameOld != PaymentTermsNameNew && ModeledDaysSalesOutstandingOld != 0 && ModeledDaysSalesOutstandingNew > ModeledDaysSalesOutstandingOld && PaymentTermsNameNew != "NM01" && PaymentTermsNameNew != "ND14" && PaymentTermsNameNew != "ND00" && PaymentTermsNameNew != "ND20" && PaymentTermsNameNew != "ND15" && PaymentTermsNameNew != "ND21" && PaymentTermsNameNew != "ND10" && PaymentTermsNameNew != "ND28" && PaymentTermsNameNew != "ND05" && PaymentTermsNameNew != "ND07")
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = "Agreement Payment Terms";
                }
                if (ModeledDaysSalesOutstandingOld == 0 && PaymentTermsNameOld == "0" && MSAPaymentTermsNew < PaymentTermInDaysNew && PaymentTermInDaysNew > 30)
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = "Agreement Payment Terms";
                }
                if (MSAPaymentTermsNew != 0 && PaymentTermsNameOld != PaymentTermsNameNew && ModeledDaysSalesOutstandingOld != 0 && MSAPaymentTermsNew < PaymentTermInDaysNew && ModeledDaysSalesOutstandingNew > ModeledDaysSalesOutstandingOld && PaymentTermsNameNew != "NM01" && PaymentTermsNameNew != "ND14" && PaymentTermsNameNew != "ND00" && PaymentTermsNameNew != "ND20" && PaymentTermsNameNew != "ND15" && PaymentTermsNameNew != "ND21" && PaymentTermsNameNew != "ND10" && PaymentTermsNameNew != "ND28" && PaymentTermsNameNew != "ND05" && PaymentTermsNameNew != "ND07")
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = "Agreement Payment Terms";
                }
                // Customer Type
                if (quoteCustomerTypeDDAR == null && accountCustomerType != null && quoteCustomerType != null && accountCustomerType.Value != quoteCustomerType.Value)
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = approvalFields == null ? "Customer Type" : approvalFields + "," + " Customer Type";
                }
                if (quoteCustomerTypeDDAR != null && accountCustomerTypeDDAR != null && accountCustomerType != null && quoteCustomerType != null && ((accountCustomerTypeDDAR.Value == 100000000 && accountCustomerType.Value == 100000001 && ((quoteCustomerTypeDDAR.Value == 100000000 && quoteCustomerType.Value == 100000000) || (quoteCustomerTypeDDAR.Value == 100000001 && quoteCustomerType.Value == 100000000))) || (accountCustomerTypeDDAR.Value == 100000001 && accountCustomerType.Value == 100000001 && quoteCustomerTypeDDAR.Value == 100000001 && quoteCustomerType.Value == 100000000) || (accountCustomerTypeDDAR.Value == 100000000 && accountCustomerType.Value == 100000000 && quoteCustomerTypeDDAR.Value == 100000000 && quoteCustomerType.Value == 100000001) || (accountCustomerTypeDDAR.Value == 100000001 && accountCustomerType.Value == 100000000 && ((quoteCustomerTypeDDAR.Value == 100000000 && quoteCustomerType.Value == 100000001) || (quoteCustomerTypeDDAR.Value == 100000001 && quoteCustomerType.Value == 100000001)))))
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = approvalFields == null ? "Customer Type" : approvalFields + "," + " Customer Type";
                }
                // Term Type
                if (termTypeDDAR == null && (termTypeQuote.Value == 100000002 || termTypeQuote.Value == 100000003))
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = approvalFields == null ? "Term Type" : approvalFields + "," + " Term Type";
                }
                //Commented for the story DYNCRM-25920
                //if (termTypeDDAR != null && termTypeQuote != null && ((termTypeDDAR.Value == 100000002 && (termTypeQuote.Value == 100000003 || (termTypeQuote.Value == 100000000 && !salesOrg))) || (termTypeDDAR.Value == 100000003 && (termTypeQuote.Value == 100000002 || (termTypeQuote.Value == 100000000 && !salesOrg))) || (termTypeDDAR.Value == 100000001 && (termTypeQuote.Value == 100000002 || termTypeQuote.Value == 100000003 || (termTypeQuote.Value == 100000000 && !salesOrg))) || (termTypeDDAR.Value == 100000000 && (termTypeQuote.Value == 100000002 || termTypeQuote.Value == 100000003))))
                //{
                //    context.OutputParameters["Result"] = true;
                //    approvalFields = approvalFields == null ? "Term Type" : approvalFields + "," + " Term Type";
                //}
                if (termTypeDDAR != null && termTypeQuote != null && ((termTypeDDAR.Value == 100000002 && termTypeQuote.Value == 100000003) || (termTypeDDAR.Value == 100000003 && termTypeQuote.Value == 100000002) || (termTypeDDAR.Value == 100000001 && (termTypeQuote.Value == 100000002 || termTypeQuote.Value == 100000003))))
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = approvalFields == null ? "Term Type" : approvalFields + "," + " Term Type";
                }
                // Annual Increase Type & Annual API/COLA % & API / COLA structure
                if ((termTypeQuote.Value == 100000001) && contractDuration > 12)
                {
                    // Annual Increase Type
                    if (termTypeDDAR == null && annualIncreaseTypeQuote != null && annualIncreaseTypeQuote.Value == 100000000)
                    {
                        context.OutputParameters["Result"] = true;
                        approvalFields = approvalFields == null ? "Annual Increase Type" : approvalFields + "," + " Annual Increase Type";
                    }
                    if (annualIncreaseTypeDDAR != null && annualIncreaseTypeQuote != null && ((annualIncreaseTypeDDAR.Value == 100000001 && annualIncreaseTypeQuote.Value == 100000000) || (annualIncreaseTypeDDAR.Value == 100000000 && annualIncreaseTypeQuote.Value == 100000000 && contractDurationDDAR <= 12)))
                    {
                        context.OutputParameters["Result"] = true;
                        approvalFields = approvalFields == null ? "Annual Increase Type" : approvalFields + "," + " Annual Increase Type";
                    }
                    // Annual API/COLA %
                    if (termTypeDDAR == null && salesOrg0500 && annualApiColaQuote != 0 && annualApiColaQuote < 3)
                    {
                        context.OutputParameters["Result"] = true;
                        approvalFields = approvalFields == null ? "Annual API %" : approvalFields + "," + " Annual API %";
                    }
                    if (annualApiColaDDAR != 0 && annualApiColaQuote != 0 && annualApiColaQuote < annualApiColaDDAR && annualApiColaQuote < 3 && salesOrg0500)
                    {
                        context.OutputParameters["Result"] = true;
                        approvalFields = approvalFields == null ? "Annual API %" : approvalFields + "," + " Annual API %";
                    }
                    // API / COLA structure
                    //DYNCRM-22351 no approval needed for new option "Standard WTW Index" (100000004).
                    if (termTypeDDAR == null && annualApiColaStructureQuote != null && annualApiColaStructureQuote.Value != 100000003 && annualApiColaStructureQuote.Value != 100000004)
                    {
                        context.OutputParameters["Result"] = true;
                        approvalFields = approvalFields == null ? "API / COLA structure" : approvalFields + "," + " API / COLA structure";
                    }
                    //DYNCRM-22351 no approval needed for new option "Standard WTW Index".
                    if (annualApiColaStructureDDAR != null && annualApiColaStructureQuote != null && annualApiColaStructureDDAR.Value != annualApiColaStructureQuote.Value && annualApiColaStructureQuote.Value != 100000003 && annualApiColaStructureQuote.Value != 100000004)
                    {
                        context.OutputParameters["Result"] = true;
                        approvalFields = approvalFields == null ? "API / COLA structure" : approvalFields + "," + " API / COLA structure";
                    }
                }
                //Commented for the story DYNCRM-25920
                //// Evergreen/Auto Renewal API % 
                //if (termTypeDDAR == null && termTypeQuote != null && termTypeQuote.Value == 100000000 && evergreenAutoRenewalAPIQuote != 0 && evergreenAutoRenewalAPIQuote < 5)
                //{
                //    context.OutputParameters["Result"] = true;
                //    approvalFields = approvalFields == null ? "Evergreen/Auto Renewal Annual API %" : approvalFields + "," + " Evergreen/Auto Renewal Annual API %";
                //}

                //if (evergreenAutoRenewalAPIDDAR != 0 && evergreenAutoRenewalAPIQuote != 0 && termTypeQuote != null && termTypeDDAR != null && ((termTypeDDAR.Value != 100000000 && termTypeQuote.Value == 100000000 && evergreenAutoRenewalAPIQuote < 5) || (termTypeDDAR.Value == 100000000 && termTypeQuote.Value == 100000000 && evergreenAutoRenewalAPIQuote < evergreenAutoRenewalAPIDDAR && evergreenAutoRenewalAPIQuote < 5)))
                //{
                //    context.OutputParameters["Result"] = true;
                //    approvalFields = approvalFields == null ? "Evergreen/Auto Renewal Annual API %" : approvalFields + "," + " Evergreen/Auto Renewal Annual API %";
                //}
                // Number of FTEs
                if (numberOfFTEsDDAR == 0 && numberOfFTEsQuote > 0)
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = approvalFields == null ? "Number of FTEs" : approvalFields + "," + " Number of FTEs";
                }
                if (numberOfFTEsDDAR != 0 && numberOfFTEsQuote > 0 && numberOfFTEsQuote > numberOfFTEsDDAR)
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = approvalFields == null ? "Number of FTEs" : approvalFields + "," + " Number of FTEs";
                }
                /*commented based on DYNCRM-29225
                // Late Payment Penalty Fee in %
                if (latePaymentPenaltysDDAR == 0 && latePaymentPenaltyQuote >= 0 && latePaymentPenaltyQuote < 1.50M)
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = approvalFields == null ? "Late Payment Penalty Fee in %" : approvalFields + "," + " Late Payment Penalty Fee in %";
                }
                if (latePaymentPenaltysDDAR != 0 && latePaymentPenaltyQuote >= 0 && latePaymentPenaltyQuote < latePaymentPenaltysDDAR && latePaymentPenaltyQuote < 1.50M)
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = approvalFields == null ? "Late Payment Penalty Fee in %" : approvalFields + "," + " Late Payment Penalty Fee in %";
                }
                */
                // Non-Standard Billing term
                if (!nonStandardBillingTermDDAR && nonStandardBillingTermQuote)
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = approvalFields == null ? "Non-Standard Billing term" : approvalFields + "," + " Non-Standard Billing term";
                }
                // Quote Default Periodic Billing Frequency
                if (quoteDefaultPeriodicBillingFrequencyDDAR == null && quoteDefaultPeriodicBillingFrequencyQuote != null && (quoteDefaultPeriodicBillingFrequencyQuote.Value == 100000006 || quoteDefaultPeriodicBillingFrequencyQuote.Value == 100000007 || quoteDefaultPeriodicBillingFrequencyQuote.Value == 100000008))
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = approvalFields == null ? "Quote Default Periodic Billing Frequency" : approvalFields + "," + " Quote Default Periodic Billing Frequency";
                }
                if (quoteDefaultPeriodicBillingFrequencyDDAR != null && quoteDefaultPeriodicBillingFrequencyQuote != null && quoteDefaultPeriodicBillingFrequencyDDAR.Value != quoteDefaultPeriodicBillingFrequencyQuote.Value && (quoteDefaultPeriodicBillingFrequencyQuote.Value == 100000006 || quoteDefaultPeriodicBillingFrequencyQuote.Value == 100000007 || quoteDefaultPeriodicBillingFrequencyQuote.Value == 100000008))
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = approvalFields == null ? "Quote Default Periodic Billing Frequency" : approvalFields + "," + " Quote Default Periodic Billing Frequency";
                }
                // Link to Non-Standard Approval Requests
                if ((linktoNonStandardApprovalRequestsDDAR == null && linktoNonStandardApprovalRequestsQuote != null) || (linktoNonStandardApprovalRequestsDDAR != null && linktoNonStandardApprovalRequestsQuote != null && linktoNonStandardApprovalRequestsDDAR != linktoNonStandardApprovalRequestsQuote))
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = approvalFields == null ? "Link to Non-Standard Approval Requests" : approvalFields + "," + " Link to Non-Standard Approval Requests";
                }
                //DYNCRM30336 - If POC true, set Quote Header Details Approval required
                if (isPOC)
                {
                    context.OutputParameters["Result"] = true;
                    approvalFields = approvalFields == null ? "POC" : approvalFields + "," + " POC";
                }
                // Termination Notification (Months)
                //DYNCRM-21863 - Deal Desk approval will no longer be required based on the Termination Notification (Months) field value
                // if (terminationNotificationMonthDDAR == 0 && terminationNotificationMonthQuote > 0 && ((contractDuration < 24 && terminationNotificationMonthQuote < 4) || (contractDuration >= 24 && contractDuration < 36 && terminationNotificationMonthQuote < 6) || (contractDuration >= 36 && terminationNotificationMonthQuote < 12)))
                // {
                //     context.OutputParameters["Result"] = true;
                //     approvalFields = approvalFields == null ? "Termination Notification (Months)" : approvalFields + "," + " Termination Notification (Months)";
                // }
                // if (terminationNotificationMonthDDAR != 0 && terminationNotificationMonthDDAR != terminationNotificationMonthQuote && terminationNotificationMonthQuote > 0 && ((contractDuration < 24 && terminationNotificationMonthQuote < 4) || (contractDuration >= 24 && contractDuration < 36 && terminationNotificationMonthQuote < 6) || (contractDuration >= 36 && terminationNotificationMonthQuote < 12)))
                // {
                //     context.OutputParameters["Result"] = true;
                //     approvalFields = approvalFields == null ? "Termination Notification (Months)" : approvalFields + "," + " Termination Notification (Months)";
                // }

                // Incentive Type                
                // DYNCRM-21869  iNCENTIVE incentive fields are hidden on the form and won't trigger Quote header details approval.
                // if (incentiveTypeDDAR == null && incentiveTypeQuote != null && incentiveTypeQuote.Value != 100000000)
                // {
                //     context.OutputParameters["Result"] = true;
                //     approvalFields = approvalFields == null ? "Incentive Type" : approvalFields + "," + " Incentive Type";
                // }
                // if (incentiveTypeDDAR != null && incentiveTypeDDAR.Value != incentiveTypeQuote.Value && incentiveTypeQuote != null && incentiveTypeQuote.Value != 100000000)
                // {
                //     context.OutputParameters["Result"] = true;
                //     approvalFields = approvalFields == null ? "Incentive Type" : approvalFields + "," + " Incentive Type";
                // }
                // // Incentive Value (NIQ Annual Impact)
                // if ((incentiveValueDDAR == 0 && incentiveValueQuote > 0) || (incentiveValueDDAR != 0 && incentiveValueQuote != incentiveValueDDAR && incentiveValueQuote > 0))
                // {
                //     context.OutputParameters["Result"] = true;
                //     approvalFields = approvalFields == null ? "Incentive Value (NIQ Annual Impact)" : approvalFields + "," + " Incentive Value (NIQ Annual Impact)";
                // }
                context.OutputParameters["ApprovalFields"] = approvalFields;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
