﻿using System;
using System.Diagnostics;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.Plugins.Helper;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Quote_CalculatePricingApprovals : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Initialize the context, service, and tracing service
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            // Check if the "Target" parameter exists and is of type "Entity"
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity targetEntity)
            {
                if (targetEntity.LogicalName == "quote")
                {
                    var currentQuote = targetEntity;
                    tracingService.Trace("Going inside the try with currentQuote ID: " + currentQuote.Id);

                    try
                    {
                        /****DYNCRM31242_Start****/
                        var brands = CommonHelper.GetEnvVarDefaultValue(service, "niq_RMSBrands", tracingService);
                        var eligibleBrands = brands.Split(',').Select(b => b.Trim()).ToArray();
                        tracingService.Trace("Eligible Brands: {0}", string.Join(", ", eligibleBrands));
                        /****DYNCRM31242_End****/

                        // To store updates
                        Entity quoteToUpdate = new Entity("quote", currentQuote.Id);

                        // AC2: Check for specific Brand ID in Quote Products and check for specific product name ("RMS")
                        var query = new QueryExpression("quotedetail")
                        {
                            ColumnSet = new ColumnSet("productname", "quotedetailname"),
                            Criteria = new FilterExpression
                            {
                                Conditions =
                                {
                                    new ConditionExpression("quoteid", ConditionOperator.Equal, currentQuote.Id) // match the quoteId
                                }
                            },
                            LinkEntities =
                            {
                                // Link to the 'product' entity to check for the brand "RMS"
                                new LinkEntity("quotedetail", "product", "niq_brandid", "productid", JoinOperator.Inner)
                                {
                                    LinkCriteria =
                                    {
                                        Conditions =
                                        {
                                            new ConditionExpression("name", ConditionOperator.In, eligibleBrands) // DYNCRM31242 filter by brand name present in env variable
                                        }
                                    }
                                },

                                // Link to the 'quote' entity to apply additional filtering from FetchXML
                                new LinkEntity("quotedetail", "quote", "quoteid", "quoteid", JoinOperator.Inner)
                                {
                                    LinkCriteria =
                                    {
                                        Conditions =
                                        {
                                            new ConditionExpression("niq_overalldealdeskapproval", ConditionOperator.NotEqual, 1) // niq_overalldealdeskapproval != 1
                                        }
                                    },
                                    LinkEntities =
                                    {
                                        // Link to the 'opportunity' entity and apply further filters
                                        new LinkEntity("quote", "opportunity", "opportunityid", "opportunityid", JoinOperator.Inner)
                                        {
                                            LinkCriteria =
                                            {
                                                Conditions =
                                                {
                                                    new ConditionExpression("niq_businessarea", ConditionOperator.NotIn, new object[] { 100000001, 100000000 }), // business area not in [100000001, 100000000]
                                                    new ConditionExpression("niq_existingcontractaction", ConditionOperator.NotIn, new object[] { 2, 3 }), // existing contract action not in [2, 3]
                                                    new ConditionExpression("niq_ishostopportunity", ConditionOperator.Equal, false), // ishostopportunity = false
                                                    new ConditionExpression("niq_hostopportunity", ConditionOperator.Null), // hostopportunity is null
                                                    new ConditionExpression("niq_revenuesharedeal", ConditionOperator.NotEqual, true)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        };

                        var result = service.RetrieveMultiple(query);
                        tracingService.Trace("Number of records returned by query: " + result.Entities.Count);
                        var RetrivecurrentQuote = service.Retrieve("quote", currentQuote.Id, new ColumnSet("niq_dealdeskapproval", "niq_elpricingapproval", "niq_dealguidanceexecutedatleastonce", "niq_quoteheaderdetailsapproval", "niq_overalldealscore", "niq_discount", "totalamount", "niq_contractenddate", "niq_contractstartdate"));

                        var elPricingApproval = currentQuote.GetAttributeValue<OptionSetValue>("niq_elpricingapproval");
                        var PricingApproval = RetrivecurrentQuote.GetAttributeValue<OptionSetValue>("niq_dealdeskapproval");

                        if (result.Entities.Count > 0)
                        {
                            tracingService.Trace("Going inside the dealscoring record");

                            // Log the value of PricingApproval to confirm it's null
                            if (PricingApproval == null)
                            {
                                // If quote contains products with the RMS brand and meets all other FetchXML criteria
                                quoteToUpdate["niq_dealdeskapproval"] = new OptionSetValue(100000000); // To be determined
                                tracingService.Trace("Products with brand 'RMS' found and all conditions met. Setting 'niq_dealdeskapproval' to 'To be Determined'.");
                            }
                            else
                            {
                                // If PricingApproval has a value and the deal has not been scored yet, and user changes the RMS products
                                if (PricingApproval != null && RetrivecurrentQuote.GetAttributeValue<bool>("niq_dealguidanceexecutedatleastonce") == false)
                                {
                                    quoteToUpdate["niq_dealdeskapproval"] = new OptionSetValue(100000000);
                                    tracingService.Trace("niq_dealdeskapproval already has a value, but user changed the products again to RMS.");
                                }
                            }
                        }
                        else
                        {

                            // copy if niq_dealdeskapproval is null/notnull as it has other quote products
                            if (PricingApproval == null || PricingApproval != null && elPricingApproval != null)
                            {
                                tracingService.Trace("Other quote products or conditions found.");
                                quoteToUpdate["niq_dealdeskapproval"] = elPricingApproval; // Copy value to niq_dealdeskapproval
                                tracingService.Trace("Updated 'niq_dealdeskapproval' with 'niq_elpricingapproval' value as it doesn't qualify for dealscoring.");
                            }

                        }


                        string overallDealscore = RetrivecurrentQuote.GetAttributeValue<string>("niq_overalldealscore");
                        tracingService.Trace("Deal is scored 1 condition: " + RetrivecurrentQuote.GetAttributeValue<bool>("niq_dealguidanceexecutedatleastonce"));
                        tracingService.Trace("Deal is scored 2 condition: niq_overalldealscore = " + (overallDealscore?.ToString() ?? "null"));

                        // AC4: if the deal was not scored and no approved DDAR, copy the value of niq_elpricingapproval to niq_dealdeskapproval
                        if (RetrivecurrentQuote.GetAttributeValue<string>("niq_overalldealscore") == null &&
                            RetrivecurrentQuote.GetAttributeValue<bool>("niq_dealguidanceexecutedatleastonce") == true)

                        {
                            tracingService.Trace("Deal is not scored. Checking for approved DDAR.");

                            // Check if no approved DDAR exists
                            var queryDDAR = new QueryExpression("niq_dealdeskapprovalrequest")
                            {
                                ColumnSet = new ColumnSet("niq_approvalstatus"),
                                Criteria = new FilterExpression
                                {
                                    Conditions =
                                    {
                                        new ConditionExpression("niq_quoteid", ConditionOperator.Equal, currentQuote.Id),
                                        new ConditionExpression("niq_approvalstatus", ConditionOperator.Equal, 4) // Approved status
                                    }
                                }
                            };

                            var ddarResult = service.RetrieveMultiple(queryDDAR);
                            tracingService.Trace("Number of DDAR records returned: " + ddarResult.Entities.Count);

                            if (ddarResult.Entities.Count == 0)
                            {
                                tracingService.Trace("No approved DDAR found. Setting 'niq_dealdeskapproval' to 'niq_elpricingapproval' value.");
                                // If no approved DDAR, copy 'niq_elpricingapproval' value to 'niq_dealdeskapproval'
                                if (elPricingApproval != null)
                                {
                                    quoteToUpdate["niq_dealdeskapproval"] = elPricingApproval; // Copy value to niq_dealdeskapproval
                                    tracingService.Trace("Updated 'niq_dealdeskapproval' with 'niq_elpricingapproval' value.");
                                }

                            }

                        }
                        else
                        {
                            tracingService.Trace("Conditions are not met for deal was not scored and no approved DDAR. Exiting.");
                        }


                        // Initialize the QueryExpression for quotedetail
                        var userquery = new QueryExpression("quotedetail")
                        {
                            ColumnSet = new ColumnSet("productname", "quotedetailname"),
                            Criteria = new FilterExpression
                            {
                                Conditions =
                                    {
                                        new ConditionExpression("quoteid", ConditionOperator.Equal, currentQuote.Id) // match the quoteId
                                    }
                            },
                            LinkEntities =
                            {
                            // Link to the 'product' entity to check for the brand "RMS"
                            new LinkEntity("quotedetail", "product", "niq_brandid", "productid", JoinOperator.Inner)
                            {
                                LinkCriteria =
                                {
                                    Conditions =
                                    {
                                        new ConditionExpression("name", ConditionOperator.In, eligibleBrands) // filter by product name "RMS"
                                    }
                                }
                            }
                        }
                        };

                        // Execute the query
                        EntityCollection userresult = service.RetrieveMultiple(userquery);
                        tracingService.Trace("Number of records returned by query: " + userresult.Entities.Count);
                        // Check if there are any RMS products
                        if (userresult.Entities.Count > 0)
                        {
                            tracingService.Trace("Found RMS products in the quote. Proceeding with the logic.");

                            // Check if the niq_overalldealscore exists and if the deal guidance has been executed at least once
                            if (RetrivecurrentQuote.GetAttributeValue<string>("niq_overalldealscore") != null &&
                                RetrivecurrentQuote.GetAttributeValue<bool>("niq_dealguidanceexecutedatleastonce") == true)
                            {
                                tracingService.Trace("Entering the condition where overalldeal score is not null & triggered");

                                // Check if the Preimage exists
                                if (context.PreEntityImages.Contains("PreImage"))
                                {
                                    // Fetch the Preimage values (old values of the quote record before update)
                                    Entity preImage = context.PreEntityImages["PreImage"];

                                    // Initialize all values to zero/default
                                    decimal currentDiscount = 0m;  // Zero decimal value
                                    Money currentTotalAmount = null;  // Null for Money type
                                    DateTime currentpreviousStartdate = DateTime.MinValue;  // Default DateTime (January 1, 0001)
                                    DateTime currentpreviousEnddate = DateTime.MinValue;  // Default DateTime (January 1, 0001)

                                    // Retrieve current values (override defaults if available)
                                    currentDiscount = RetrivecurrentQuote.GetAttributeValue<decimal>("niq_discount");
                                    currentTotalAmount = RetrivecurrentQuote.GetAttributeValue<Money>("totalamount");
                                    currentpreviousStartdate = RetrivecurrentQuote.GetAttributeValue<DateTime>("niq_contractstartdate");
                                    currentpreviousEnddate = RetrivecurrentQuote.GetAttributeValue<DateTime>("niq_contractenddate");

                                    // Retrieve Preimage (previous values)
                                    decimal previousDiscount = preImage.GetAttributeValue<decimal>("niq_discount");
                                    Money previousTotalAmount = preImage.GetAttributeValue<Money>("totalamount");
                                    DateTime previousStartdate = preImage.GetAttributeValue<DateTime>("niq_contractstartdate");
                                    DateTime previousEnddate = preImage.GetAttributeValue<DateTime>("niq_contractenddate");

                                    // Check if there are changes in the relevant fields (Discount %, Total Amount, or Contract Duration)
                                    bool isDiscountChanged = currentDiscount != previousDiscount;
                                    bool isTotalAmountChanged = currentTotalAmount?.Value != previousTotalAmount?.Value;
                                    bool ispreviousStartdateChanged = currentpreviousStartdate != previousStartdate;
                                    bool ispreviousEnddateChanged = currentpreviousEnddate != previousEnddate;

                                    // Trace any changes in the values
                                    if (isDiscountChanged)
                                    {
                                        tracingService.Trace($"Discount changed: {previousDiscount} -> {currentDiscount}");
                                    }
                                    else
                                    {
                                        tracingService.Trace($"No change in Discount: {previousDiscount}");
                                    }

                                    if (isTotalAmountChanged)
                                    {
                                        tracingService.Trace($"Total Amount changed: {previousTotalAmount?.Value} -> {currentTotalAmount?.Value}");
                                    }
                                    else
                                    {
                                        tracingService.Trace($"No change in Total Amount: {previousTotalAmount?.Value}");
                                    }

                                    if (ispreviousStartdateChanged)
                                    {
                                        tracingService.Trace($"Contract Start Date changed: {previousStartdate} -> {currentpreviousStartdate}");
                                    }
                                    else
                                    {
                                        tracingService.Trace($"No change in Contract Start Date: {previousStartdate}");
                                    }

                                    if (ispreviousEnddateChanged)
                                    {
                                        tracingService.Trace($"Contract End Date changed: {previousEnddate} -> {currentpreviousEnddate}");
                                    }
                                    else
                                    {
                                        tracingService.Trace($"No change in Contract End Date: {previousEnddate}");
                                    }

                                    // If any of these values have changed, update the pricing approval field
                                    if (isDiscountChanged || isTotalAmountChanged || ispreviousStartdateChanged || ispreviousEnddateChanged)
                                    {
                                        // Set the pricing approval field to 'To Be Determined'
                                        quoteToUpdate["niq_dealdeskapproval"] = new OptionSetValue(100000000); // Assuming 'To Be Determined'
                                        tracingService.Trace("Updating the Pricing approval to 'To Be Determined'");

                                        // Make sure the quote is the same entity you're working on
                                        service.Update(quoteToUpdate);
                                    }
                                }
                                else
                                {
                                    tracingService.Trace("PreImage not found. Cannot compare old values.");
                                }
                            }
                            else
                            {
                                tracingService.Trace("Condition not met: niq_overalldealscore is null or deal guidance not executed.");
                            }
                        }
                        else
                        {
                            if (elPricingApproval != null)
                            {
                                quoteToUpdate["niq_dealdeskapproval"] = elPricingApproval; // Copy value to niq_dealdeskapproval
                                tracingService.Trace("Updated 'niq_dealdeskapproval' with 'niq_elpricingapproval' value.");
                            }
                        }


                        // Update the quote with the new value of 'niq_dealdeskapproval']
                        tracingService.Trace("Updating quote with ID: " + quoteToUpdate.Id);
                        service.Update(quoteToUpdate);
                        tracingService.Trace("Quote updated with final 'niq_dealdeskapproval' value.");
                    }
                    catch (Exception ex)
                    {
                        tracingService.Trace("An error occurred: {0}", ex.ToString());
                        throw new InvalidPluginExecutionException("An error occurred in the OnUpdate_Quote_CalculatePricingApprovals plugin.", ex);
                    }
                }
            }
        }
    }
}
