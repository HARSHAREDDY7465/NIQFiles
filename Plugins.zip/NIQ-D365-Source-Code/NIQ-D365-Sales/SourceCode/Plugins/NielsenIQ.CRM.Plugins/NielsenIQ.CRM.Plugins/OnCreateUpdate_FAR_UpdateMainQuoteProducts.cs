﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace NielsenIQ.CRM.Plugins
{
    public class OnCreateUpdate_FAR_UpdateMainQuoteProducts : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                if (context.PostEntityImages.Contains("Image") && context.PostEntityImages["Image"] is Entity)
                {
                    Entity fARObj = (Entity)context.PostEntityImages["Image"];
                    if (context.MessageName == "Create" && fARObj.Contains("niq_relatedopportunity"))
                    {
                        string previousRejectFetchXML = @"<fetch distinct='true' no-lock='true' mapping='logical' top='1'><entity name='niq_financeapprovalrequests'>
                                                            <attribute name='niq_financeapprovalrequestsid' />
                                                            <filter type='and'>
                                                              <condition attribute='niq_approvalstatus' operator='eq' value='100000003' />
                                                              <condition attribute='niq_relatedopportunity' operator='eq' value='" + ((EntityReference)fARObj["niq_relatedopportunity"]).Id + "' />"+
                                                            "</filter></entity></fetch>";
                        EntityCollection rejectionCheckRecords = service.RetrieveMultiple(new FetchExpression(previousRejectFetchXML));
                        if (rejectionCheckRecords.Entities.Count > 0)
                        {
                            string quoteProductFetchXML = @"<fetch distinct='true' no-lock='true' mapping='logical'><entity name='quotedetail'><attribute name='quotedetailid' />
                                                        <attribute name='niq_billingfrequency' /><attribute name='niq_deliveryfrequency' />
                                                        <attribute name='niq_lineitemenddate' /><attribute name='extendedamount' />
                                                        <attribute name='niq_lagrevenuerecognition' /><attribute name='niq_lineitemstartdate' />
                                                        <attribute name='niq_billingfrequencylastrejection' /><attribute name='niq_deliveryfrequencylastrejection' />
                                                        <attribute name='niq_enddatelastrejection' /><attribute name='niq_extendedamountlastrejection' />
                                                        <attribute name='niq_lagrevenuerecognitionlastejection' /><attribute name='niq_startdatelastrejection' />
                                                        <link-entity name='quote' to='quoteid' from='quoteid' link-type='inner' alias='aa'>
                                                        <link-entity name='opportunity' to='quoteid' from='niq_mainquoteid' link-type='inner' alias='ab'>
                                                        <filter type='and'><condition attribute='opportunityid' operator='eq' value='" + ((EntityReference)fARObj["niq_relatedopportunity"]).Id + "' /></filter>" +
                                                        "</link-entity></link-entity></entity></fetch>";
                            EntityCollection qpRecords = service.RetrieveMultiple(new FetchExpression(quoteProductFetchXML));
                            foreach (Entity rec in qpRecords.Entities)
                            {
                                Entity updateRec = new Entity(rec.LogicalName, rec.Id);
                                if ((rec.Contains("niq_billingfrequency") && rec.Contains("niq_billingfrequencylastrejection") && ((OptionSetValue)rec["niq_billingfrequency"]).Value != ((OptionSetValue)rec["niq_billingfrequencylastrejection"]).Value) ||
                                    (rec.Contains("niq_billingfrequency") && !rec.Contains("niq_billingfrequencylastrejection")) || (!rec.Contains("niq_billingfrequency") && rec.Contains("niq_billingfrequencylastrejection")))
                                    updateRec["niq_billingfrequencychange"] = rec["niq_billingfrequency"];
                                else
                                    updateRec["niq_billingfrequencychange"] = null;

                                if ((rec.Contains("niq_deliveryfrequency") && rec.Contains("niq_deliveryfrequencylastrejection") && ((OptionSetValue)rec["niq_deliveryfrequency"]).Value != ((OptionSetValue)rec["niq_deliveryfrequencylastrejection"]).Value) ||
                                    (rec.Contains("niq_deliveryfrequency") && !rec.Contains("niq_deliveryfrequencylastrejection")) || (!rec.Contains("niq_deliveryfrequency") && rec.Contains("niq_deliveryfrequencylastrejection")))
                                    updateRec["niq_deliveryfrequencychange"] = rec["niq_deliveryfrequency"];
                                else
                                    updateRec["niq_deliveryfrequencychange"] = null;

                                if ((rec.Contains("niq_lineitemenddate") && rec.Contains("niq_enddatelastrejection") && (DateTime)rec["niq_lineitemenddate"] != (DateTime)rec["niq_enddatelastrejection"]) ||
                                    (rec.Contains("niq_lineitemenddate") && !rec.Contains("niq_enddatelastrejection")) || (!rec.Contains("niq_lineitemenddate") && rec.Contains("niq_enddatelastrejection")))
                                    updateRec["niq_enddatechange"] = rec["niq_lineitemenddate"];
                                else
                                    updateRec["niq_enddatechange"] = null;

                                if ((rec.Contains("niq_lineitemstartdate") && rec.Contains("niq_startdatelastrejection") && (DateTime)rec["niq_lineitemstartdate"] != (DateTime)rec["niq_startdatelastrejection"]) ||
                                    (rec.Contains("niq_lineitemstartdate") && !rec.Contains("niq_startdatelastrejection")) || (!rec.Contains("niq_lineitemstartdate") && rec.Contains("niq_startdatelastrejection")))
                                    updateRec["niq_startdatechange"] = rec["niq_lineitemstartdate"];
                                else
                                    updateRec["niq_startdatechange"] = null;

                                if ((rec.Contains("extendedamount") && rec.Contains("niq_extendedamountlastrejection") && ((Money)rec["extendedamount"]).Value != ((Money)rec["niq_extendedamountlastrejection"]).Value) ||
                                    (rec.Contains("extendedamount") && !rec.Contains("niq_extendedamountlastrejection")) || (!rec.Contains("extendedamount") && rec.Contains("niq_extendedamountlastrejection")))
                                    updateRec["niq_extendedamountchange"] = rec["extendedamount"];
                                else
                                    updateRec["niq_extendedamountchange"] = null;

                                if ((rec.Contains("niq_lagrevenuerecognition") && rec.Contains("niq_lagrevenuerecognitionlastejection") && ((OptionSetValue)rec["niq_lagrevenuerecognition"]).Value != ((OptionSetValue)rec["niq_lagrevenuerecognitionlastejection"]).Value) ||
                                    (rec.Contains("niq_lagrevenuerecognition") && !rec.Contains("niq_lagrevenuerecognitionlastejection")) || (!rec.Contains("niq_lagrevenuerecognition") && rec.Contains("niq_lagrevenuerecognitionlastejection")))
                                    updateRec["niq_lagrevenuerecognitionchange"] = rec["niq_lagrevenuerecognition"];
                                else
                                    updateRec["niq_lagrevenuerecognitionchange"] = null;
                                service.Update(updateRec);
                            }
                        }
                    }
                    else if (context.MessageName == "Update" && fARObj.Contains("niq_approvalstatus") && ((OptionSetValue)fARObj["niq_approvalstatus"]).Value == 100000003 &&
                        fARObj.Contains("niq_relatedopportunity"))
                    {
                        string quoteProductFetchXML = @"<fetch distinct='true' no-lock='true' mapping='logical'><entity name='quotedetail'><attribute name='quotedetailid' />
                                                        <attribute name='niq_billingfrequency' /><attribute name='niq_deliveryfrequency' />
                                                        <attribute name='niq_lineitemenddate' /><attribute name='extendedamount' />
                                                        <attribute name='niq_lagrevenuerecognition' /><attribute name='niq_lineitemstartdate' />
                                                        <link-entity name='quote' to='quoteid' from='quoteid' link-type='inner' alias='aa'>
                                                        <link-entity name='opportunity' to='quoteid' from='niq_mainquoteid' link-type='inner' alias='ab'>
                                                        <filter type='and'><condition attribute='opportunityid' operator='eq' value='" + ((EntityReference)fARObj["niq_relatedopportunity"]).Id + "' /></filter>" +
                                                        "</link-entity></link-entity></entity></fetch>";
                        EntityCollection qpRecords = service.RetrieveMultiple(new FetchExpression(quoteProductFetchXML));
                        foreach (Entity rec in qpRecords.Entities)
                        {
                            Entity updateRec = new Entity(rec.LogicalName, rec.Id);
                            if (rec.Contains("niq_billingfrequency"))
                                updateRec["niq_billingfrequencylastrejection"] = rec["niq_billingfrequency"];
                            if (rec.Contains("niq_deliveryfrequency"))
                                updateRec["niq_deliveryfrequencylastrejection"] = rec["niq_deliveryfrequency"];
                            if (rec.Contains("niq_lineitemenddate"))
                                updateRec["niq_enddatelastrejection"] = rec["niq_lineitemenddate"];
                            if (rec.Contains("niq_lineitemstartdate"))
                                updateRec["niq_startdatelastrejection"] = rec["niq_lineitemstartdate"];
                            if (rec.Contains("extendedamount"))
                                updateRec["niq_extendedamountlastrejection"] = rec["extendedamount"];
                            if (rec.Contains("niq_lagrevenuerecognition"))
                                updateRec["niq_lagrevenuerecognitionlastejection"] = rec["niq_lagrevenuerecognition"];

                            updateRec["niq_billingfrequencychange"] = null;
                            updateRec["niq_deliveryfrequencychange"] = null;
                            updateRec["niq_enddatechange"] = null;
                            updateRec["niq_startdatechange"] = null;
                            updateRec["niq_extendedamountchange"] = null;
                            updateRec["niq_lagrevenuerecognitionchange"] = null;

                            service.Update(updateRec);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}