﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.Plugins.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static NielsenIQ.CRM.Plugins.Helper.CommonConstant;

namespace NielsenIQ.CRM.Plugins
{
    public class OnCreateUpdate_CreateFieldHistory : IPlugin
    {
        ITracingService tracer = null;
        public void Execute(IServiceProvider serviceProvider)
        {
            //Extract the tracing service for use in debugging sandboxed plug-ins.
            ITracingService tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            // Obtain the execution context from the service provider.
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            // Obtain the organization service reference.
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                Entity contextEntity = (Entity)context.InputParameters[CommonConstant.TARGET];
                Entity preImageEntity = context.PreEntityImages.Contains(CommonConstant.IMAGE) ? (Entity)context.PreEntityImages[CommonConstant.IMAGE] : new Entity();
                Entity PostImageEntity = context.PostEntityImages.Contains(CommonConstant.IMAGE) ? (Entity)context.PostEntityImages[CommonConstant.IMAGE] : new Entity();
                tracer.Trace("Guid id of Current record: " + contextEntity.Id.ToString());
                FilterExpression filterCS = new FilterExpression();
                filterCS.AddCondition(ConfigurationSettings.Name, ConditionOperator.BeginsWith, "FieldHistory__" + contextEntity.LogicalName);
                EntityCollection ConfigEntityCollection = CommonHelper.ReturnQueryResult(ConfigurationSettings.LogicalName, new ColumnSet(ConfigurationSettings.Name, ConfigurationSettings.To, ConfigurationSettings.CC), filterCS, new LinkEntity(), tracer, service);
                if (ConfigEntityCollection != null && ConfigEntityCollection.Entities.Count == 0) { return; }

                Guid fieldHistoryId = new Guid();
                EntityReference recOwner = (contextEntity.Attributes.Contains("ownerid") && contextEntity.GetAttributeValue<EntityReference>("ownerid").Id != null) ? contextEntity.GetAttributeValue<EntityReference>("ownerid") : ((preImageEntity.Attributes.Contains("ownerid") && preImageEntity.GetAttributeValue<EntityReference>("ownerid").Id != null) ? preImageEntity.GetAttributeValue<EntityReference>("ownerid") : new EntityReference());
                tracer.Trace("reqOwnerid: " + recOwner.ToString());
                string recOwnerName = (recOwner != new EntityReference()) ? GetUserFullName(service, tracer, recOwner) : null;
                tracer.Trace("contextreqOwner: " + recOwner);
                Guid recModifiedbyid = (contextEntity.Attributes.Contains("modifiedby") && contextEntity.GetAttributeValue<EntityReference>("modifiedby").Id != null) ? contextEntity.GetAttributeValue<EntityReference>("modifiedby").Id : Guid.Empty;
                string recModifiedBy = recModifiedbyid.ToString();
                tracer.Trace("contextreqModifiedBy: " + recModifiedBy);
                DateTime recModifiedOn = (contextEntity.Attributes.Contains("modifiedon") && contextEntity.GetAttributeValue<DateTime>("modifiedon") != null) ? contextEntity.GetAttributeValue<DateTime>("modifiedon") : DateTime.Now;
                tracer.Trace("reqModifiedOn: " + recModifiedOn);
                string[] stringSeperator = { "__" };
                string entityDisplayName = ConfigEntityCollection.Entities[0][ConfigurationSettings.Name].ToString().Split(stringSeperator, StringSplitOptions.RemoveEmptyEntries).Count() > 2 ? ConfigEntityCollection.Entities[0][ConfigurationSettings.Name].ToString().Split(stringSeperator, StringSplitOptions.RemoveEmptyEntries)[2] : contextEntity.LogicalName.ToString();
                if (context.MessageName.ToLower() == CommonConstant.CREATEOPERATION)
                {
                    tracer.Trace("Entering Create Mode");
                    DateTime recCreatedOn = contextEntity.GetAttributeValue<DateTime>("createdon");
                    foreach (string attrCollection in ConfigEntityCollection.Entities[0][ConfigurationSettings.To].ToString().Split(','))
                    {
                        if (!string.IsNullOrEmpty(attrCollection.Trim()) && attrCollection.Trim().Split('|').Count() > 0)
                        {
                            if (contextEntity.Contains(attrCollection.Trim().Split('|')[0]))
                            {
                                fieldHistoryId = FetchAttributeValue(entityDisplayName, attrCollection.Trim().Split('|')[0], attrCollection.Trim().Split('|')[1], recModifiedbyid, recModifiedOn, recOwner, contextEntity, new Entity(), false, service, tracer);
                                tracer.Trace("Field History for " + attrCollection.Trim().Split('|')[1] + " created successfully in Create Mode with RecordId: " + fieldHistoryId.ToString());
                            }

                        }
                    }
                }
                else if (context.MessageName.ToLower() == CommonConstant.UPDATEOPERATION)
                {
                    tracer.Trace("Entering Update Mode");
                    foreach (string attrCollection in ConfigEntityCollection.Entities[0][ConfigurationSettings.To].ToString().Split(','))
                    {
                        if (!string.IsNullOrEmpty(attrCollection.Trim()) && attrCollection.Trim().Split('|').Count() > 0)
                        {
                            if (contextEntity.Contains(attrCollection.Trim().Split('|')[0]))
                            {
                                fieldHistoryId = FetchAttributeValue(entityDisplayName, attrCollection.Trim().Split('|')[0], attrCollection.Trim().Split('|')[1], recModifiedbyid, recModifiedOn, recOwner, PostImageEntity, preImageEntity, true, service, tracer);
                                tracer.Trace("Field History for " + attrCollection.Trim().Split('|')[1] + " created successfully in Update Mode with RecordId: " + fieldHistoryId.ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("ERRORMESSAGEFAILURE" + ex);
            }
        }

        public string GetUserFullName(IOrganizationService service, ITracingService tracer, EntityReference userGuid)
        {
            tracer.Trace("Entering Get User Full Name");
            string userFullName = string.Empty;
            try
            {
                if (userGuid != null)
                {
                    var query1 = new QueryExpression(userGuid.LogicalName)
                    {
                        ColumnSet = new ColumnSet(true),
                        Criteria = { Conditions = { new ConditionExpression(userGuid.LogicalName + "id", ConditionOperator.Equal, userGuid.Id) } }
                    };
                    var entitylist = service.RetrieveMultiple(query1);
                    if (entitylist.Entities.Count() > 0 && entitylist.Entities[0] != null)
                    {
                        userFullName = (userGuid.LogicalName == "systemuser") ? entitylist.Entities[0].Attributes["fullname"].ToString() : entitylist.Entities[0].Attributes["name"].ToString();
                    }
                }
            }
            catch (Exception ex) { tracer.Trace("Exception in GetUserFullName: " + ex.Message); throw; }
            return userFullName;
        }

        public static Guid FetchAttributeValue(string entityDisplayName, string attrName, string attrDisplayName, Guid updatedUserId, DateTime updatedDateTime, EntityReference recordOwner, Entity record, Entity preImage, bool isForUpdate, IOrganizationService service, ITracingService trace)
        {
            trace.Trace("Entering Fetch Attribute Value");
            Guid fieldHistoryId = new Guid();
            try
            {
                if (record.TryGetAttributeValue<OptionSetValue>(attrName, out OptionSetValue attrOptValue) && record.FormattedValues.Contains(attrName))
                    fieldHistoryId = CommonHelper.CreateFieldHistory(service, trace, entityDisplayName, record.LogicalName, record.Id, updatedUserId, record.FormattedValues[attrName], (isForUpdate && record[attrName] != preImage[attrName] ? preImage.FormattedValues[attrName] : ""), updatedDateTime, attrDisplayName, attrName, recordOwner);
                else if ((record.TryGetAttributeValue<EntityReference>(attrName, out EntityReference attrERValue) && record.Contains(attrName)) || (record.Contains(attrName) && !preImage.Attributes.ContainsKey(attrName) && record.Attributes[attrName].GetType().Name == "EntityReference"))
                {
                    string nameAttribute = "name";
                    if (((EntityReference)record[attrName]).LogicalName.Split('_').Count() > 1)
                        nameAttribute = ((EntityReference)record[attrName]).LogicalName.Split('_')[0] + "_name";
                    Entity attrRecord = service.Retrieve(((EntityReference)record[attrName]).LogicalName, ((EntityReference)record[attrName]).Id, new ColumnSet(nameAttribute));
                    Entity preImageAttrRecord = new Entity();
                    if (isForUpdate)
                    {
                        if (preImage.Attributes.ContainsKey(attrName))
                            preImageAttrRecord = service.Retrieve(((EntityReference)preImage[attrName]).LogicalName, ((EntityReference)preImage[attrName]).Id, new ColumnSet(nameAttribute));
                    }
                    fieldHistoryId = CommonHelper.CreateFieldHistory(service, trace, entityDisplayName, record.LogicalName, record.Id, updatedUserId, attrRecord[nameAttribute].ToString(),
                        (isForUpdate && preImage.Attributes.ContainsKey(attrName) ? preImageAttrRecord[nameAttribute].ToString() : ""), updatedDateTime, attrDisplayName, attrName, recordOwner);
                }
                else if (record.TryGetAttributeValue<Money>(attrName, out Money attrMValue))
                    fieldHistoryId = CommonHelper.CreateFieldHistory(service, trace, entityDisplayName, record.LogicalName, record.Id, updatedUserId, attrMValue.Value.ToString(), (isForUpdate && record[attrName] != preImage[attrName] ? ((Money)preImage[attrName]).Value.ToString() : ""), updatedDateTime, attrDisplayName, attrName, recordOwner);
                else if (record.Attributes.Contains(attrName) || (!record.Attributes.Contains(attrName) && preImage.Attributes.Contains(attrName) && preImage[attrName] != null))
                {

                    string oldValue = string.Empty;
                    string newValue = record.Attributes.Contains(attrName) && record.Attributes[attrName] != null ? record.Attributes[attrName].ToString() : string.Empty;
                    oldValue = preImage.Attributes.Contains(attrName) && preImage[attrName] != null ? preImage[attrName].ToString() : string.Empty;
                    fieldHistoryId = CommonHelper.CreateFieldHistory(service, trace, entityDisplayName, record.LogicalName, record.Id, updatedUserId, newValue, oldValue, updatedDateTime, attrDisplayName, attrName, recordOwner);
                }


                else if (record.Contains(attrName))
                    fieldHistoryId = CommonHelper.CreateFieldHistory(service, trace, entityDisplayName, record.LogicalName, record.Id, updatedUserId, record[attrName].ToString(), (isForUpdate && record[attrName] != preImage[attrName] ? preImage[attrName].ToString() : ""), updatedDateTime, attrDisplayName, attrName, recordOwner);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("ERRORMESSAGEFAILURE" + ex);
            }
            return fieldHistoryId;
        }
    }
}
