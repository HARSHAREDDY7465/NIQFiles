﻿using Microsoft.Xrm.Sdk;
using System;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk.Query;


namespace NielsenIQ.CRM.Plugins
{
    public class StopLeadConversion : IPlugin
    {
          public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory orgServiceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService orgService = (IOrganizationService)orgServiceFactory.CreateOrganizationService(context.InitiatingUserId);
            //take the input parameters

            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            try
            {
                tracing.Trace($"inside the plugin SetOpportunityQualifyParameters on plugin Mssage: {context.MessageName} and recordid is {context.InputParameters.Contains("LeadId")}");
                if (context.MessageName.Equals("QualifyLead") && context.InputParameters.Contains("LeadId"))
                {
                    EntityReference leadId = (EntityReference)context.InputParameters["LeadId"]; ;
                    tracing.Trace($"Plugin Primary entity '{context.PrimaryEntityName}' and record id {leadId.Id}");

                    Entity lead = orgService.Retrieve(leadId.LogicalName, leadId.Id, new ColumnSet("niq_futureopportunitydecision","qualifyingopportunityid", "campaignid"));
                    tracing.Trace("LeadId" + lead.Id);
                    tracing.Trace(lead.GetAttributeValue<OptionSetValue>("niq_futureopportunitydecision").Value.ToString());
                    if (lead.Attributes.Contains("niq_futureopportunitydecision") && lead.GetAttributeValue<OptionSetValue>("niq_futureopportunitydecision") != null)
                    {
                        tracing.Trace("niq_futureopportunitydecision is not null.");
                        if (lead.GetAttributeValue<OptionSetValue>("niq_futureopportunitydecision").Value == 100000001)
                        {
                            context.InputParameters["CreateOpportunity"] = false;
                            tracing.Trace($"niq_futureopportunitydecision is {lead.GetAttributeValue<OptionSetValue>("niq_futureopportunitydecision").Value} and CreateOpportunity set to false.");
                            //Update originatingleadid if qualifyingopportunityid exist
                            if (lead.Attributes.Contains("qualifyingopportunityid"))
                            {
                                EntityReference qualifyingopportunityid = lead.GetAttributeValue<EntityReference>("qualifyingopportunityid");
                                Entity oppToUpdate = new Entity(qualifyingopportunityid.LogicalName, qualifyingopportunityid.Id);
                                oppToUpdate["originatingleadid"] = leadId;
                                tracing.Trace("StopLeadConversion: contains originatinglead ");
                                if (lead.Contains("campaignid") && lead.GetAttributeValue<EntityReference>("campaignid") != null)
                                {
                                    tracing.Trace("campaignid" + lead.GetAttributeValue<EntityReference>("campaignid"));
                                    oppToUpdate["campaignid"] = lead.GetAttributeValue<EntityReference>("campaignid");
                                    tracing.Trace("StopLeadConversion: contains campaigncode ");
                                }
                                orgService.Update(oppToUpdate);
                                tracing.Trace("StopLeadConversion:Primary campaign code- record Updated ");

                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);

            }
        }
    }
}