﻿using System;
using System.Linq;
using System.Text;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Newtonsoft.Json.Linq;
using System.Data;
using System.Globalization;
using System.Collections.Generic;

namespace NielsenIQ.CRM.Plugins.WF
{
    public class GetDeliverySchedulePayLoad : CodeActivity
    {
        [RequiredArgument]
        [Input("QuoteProducts PayLoad")]
        public InArgument<string> QuoteProductsPayLoad { get; set; }

        [RequiredArgument]
        [Input("Schedules PayLoad")]
        public InArgument<string> SchedulesPayLoad { get; set; }

        [Input("QuoteProductChar Payload")]
        public InArgument<string> QuoteProductCharPayLoad { get; set; }

        [RequiredArgument]
        [Output("DeliveryResponse PayLoad")]
        public OutArgument<string> DeliveryResponsePayLoad { get; set; }

        StringBuilder sbPayload;
        protected override void Execute(CodeActivityContext context)
        {
            IWorkflowContext workflowContext = context.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
            ITracingService tracingService = context.GetExtension<ITracingService>();

            try
            {
                sbPayload = new StringBuilder();
                var jobjQuoteProductsPayLoad = JObject.Parse(QuoteProductsPayLoad.Get(context));
                var jobjSchedulesPayLoad = JObject.Parse(SchedulesPayLoad.Get(context));
                // var jobjQuoteProductCharPayLoad = JObject.Parse(QuoteProductCharPayLoad.Get(context));
                /*create a list of dbname where the on platform delivery is yes pseudo code something like this
                list dbname = QP.where(product's delivery plantfomr=yes).select(databasename).tolist().distinct()*/
                tracingService.Trace("CheckStart");
                var dbnameList = jobjQuoteProductsPayLoad["value"]
                    .Where(qp => qp["product.niq_onplatformdelivery@OData.Community.Display.V1.FormattedValue"] != null
                      && qp["product.niq_onplatformdelivery@OData.Community.Display.V1.FormattedValue"].ToString() == "Yes")
                   .Select(qp => qp["niq_databasename"]?.ToString())
                   .Where(dbName => !string.IsNullOrEmpty(dbName))
                    .Distinct()
                    .ToList();


                BuildDeliverySchedulePayload(jobjQuoteProductsPayLoad, jobjSchedulesPayLoad, dbnameList, tracingService);
                if (sbPayload.Length > 10)
                {
                    DeliveryResponsePayLoad.Set(context, "{\"value\":[" + sbPayload.ToString(0, sbPayload.Length - 3) + "]}");
                }
                else
                    DeliveryResponsePayLoad.Set(context, "");

            }
            catch (Exception ex)
            {
                tracingService.Trace("Execute error");
                throw ex;
            }
        }

        public void BuildDeliverySchedulePayload(JObject jobjQuoteProductsPayLoad, JObject jobjSchedulesPayLoad, List<string> dbnameList, ITracingService tracingService)
        {
            try
            {

                JArray QuoteProductsJarry = (JArray)jobjQuoteProductsPayLoad["value"];
                // JArray QuoteProductCharJarry = (JArray)jobjQuoteProductCharPayLoad["value"];
                JArray SchedulesJarry = (JArray)jobjSchedulesPayLoad["value"];


                var filteredProducts = QuoteProductsJarry
                         .Where(prod => !dbnameList.Contains(prod["niq_databasename"]?.ToString()) &&
                                        (prod["product.niq_onplatformdelivery@OData.Community.Display.V1.FormattedValue"]?.ToString() != "Yes" ||
                                         prod["product.niq_onplatformdelivery@OData.Community.Display.V1.FormattedValue"] == null));




                tracingService.Trace("FIRSTTRACE");
                foreach (var prod in filteredProducts)
                {

                    tracingService.Trace("2");
                    //bool istimebased = (bool)prod["productpricelevel.niq_istimebased"];
                    var producttype = (Int32)prod["productpricelevel.niq_producttype"];
                    tracingService.Trace("producttype" + producttype.ToString());
                    var istimebased = (bool)prod["productpricelevel.niq_istimebased"];
                    tracingService.Trace("istimebased" + istimebased.ToString());
                    //string deliveryfrequency = (OptionSetValue)prod["quotedetail.niq_deliveryfrequency"].;
                    //   string deliveryfrequency1 = ((Int32)prod["quotedetail.niq_deliveryfrequency"]);
                    tracingService.Trace("FIRSTTRACE df");
                    //var deliveryfrequency = (Int32)prod["quotedetail.niq_deliveryfrequency"];
                    //int value = ((OptionSetValue)prod["quotedetail.niq_deliveryfrequency"]).Value;
                    var deliveryfrequency = (Int32)prod["niq_deliveryfrequency"];
                    tracingService.Trace("deliveryfrequency" + deliveryfrequency.ToString());

                    tracingService.Trace("1 FIRSTTRACE");
                    /*
                    tracingService.Trace("startdate2"+ prod["quotedetail.niq_lineitemstartdate"].ToString());
                    if(prod.a
                        DateTime lineitemstartdate = (DateTime)prod["quotedetail.niq_lineitemstartdate"];
                    tracingService.Trace("enddate" + prod["quotedetail.niq_lineitemenddate"].ToString());

                    DateTime lineitemenddate = (DateTime)prod["quotedetail.niq_lineitemenddate"];
                    // var deliveryfrequency = (Int32)prod["quotedetail.niq_deliveryfrequency"];
                    tracingService.Trace("deliveryfrequency" + deliveryfrequency.ToString());*/
                    int quoteLineDurationMonths = CalculateDurationInMonths(Convert.ToDateTime(prod["niq_lineitemstartdate"]), Convert.ToDateTime(prod["niq_lineitemenddate"]));
                    tracingService.Trace("Before IF qld" + quoteLineDurationMonths.ToString());
                    tracingService.Trace("Before IF df" + deliveryfrequency.ToString());
                    Boolean enddateofproduct = false;
                    Boolean eachrevenueschedules = false;
                    if ((quoteLineDurationMonths < 12 && quoteLineDurationMonths != 0) && (deliveryfrequency == 100000003 || deliveryfrequency == 100000009 || deliveryfrequency == 100000005 || deliveryfrequency == 100000001 || deliveryfrequency == 100000006 || deliveryfrequency == 100000004 || deliveryfrequency == 100000000 || deliveryfrequency == 100000008 || deliveryfrequency == 100000002 || deliveryfrequency == 100000007))

                    {
                        tracingService.Trace("INSIDE IF");
                        // istimebased = null;
                        if (producttype == 100000001 && istimebased == true)

                        {
                            enddateofproduct = true;

                        }

                        else if ((producttype == 100000001 && istimebased == false) || (producttype == 100000000 && istimebased == true) || (producttype == 100000000 && istimebased == false))

                        {
                            eachrevenueschedules = true;

                        }
                    }
                    else if (quoteLineDurationMonths >= 12 && quoteLineDurationMonths != 0)
                    {
                        tracingService.Trace("INSIDE else IF 2");
                        if (deliveryfrequency == 100000008)
                        {
                            if (producttype == 100000001 && istimebased == true)
                            {
                                enddateofproduct = true;
                            }

                        }
                        else if (deliveryfrequency == 100000009)
                        {
                            if (producttype == 100000001 && istimebased == false)
                            {
                                eachrevenueschedules = true;

                            }
                        }

                        else if (deliveryfrequency == 100000003 || deliveryfrequency == 100000004 || deliveryfrequency == 100000005)
                        {
                            if ((producttype == 100000000 && istimebased == false))
                            {
                                eachrevenueschedules = true;


                            }

                        }

                    }
                    if (enddateofproduct == true)
                    {
                        JArray endSchedulesJson = JArray.FromObject(SchedulesJarry.Where(o => (string)o["_niq_lineitemid_value"] == (string)prod["quotedetailid"]).OrderByDescending(x => x["niq_scheduledate"]));
                        tracingService.Trace("BuildDeliverySchedulePayload:endSchedulesJson count " + endSchedulesJson.Count().ToString());
                        if (endSchedulesJson != null && endSchedulesJson.Count() > 0)
                        {
                            if (endSchedulesJson.FirstOrDefault()?["niq_scheduleid"]?.Value<string>() != null
                                && endSchedulesJson.FirstOrDefault()?["niq_scheduledate"]?.Value<string>() != null
                                && endSchedulesJson.FirstOrDefault()?["createdon"]?.Value<string>() != null)
                            {
                                tracingService.Trace("BuildDeliverySchedulePayload: contains schedule date & created on" + Convert.ToDateTime(endSchedulesJson.FirstOrDefault()?["niq_scheduledate"]?.Value<string>()) + " created on " + Convert.ToDateTime(endSchedulesJson.FirstOrDefault()?["createdon"]?.Value<string>()));
                                CreateDelivery(Convert.ToDateTime(prod["niq_lineitemenddate"]),
                                                          prod["quotedetailname"].ToString(),
                                                          endSchedulesJson.FirstOrDefault()?["niq_amount"]?.Value<string>(),
                                                          prod["quotedetailid"].ToString(),
                                                          endSchedulesJson.FirstOrDefault()?["niq_scheduleid"]?.Value<string>());

                            }

                        }
                    }
                    if (eachrevenueschedules == true)
                    {
                        JArray allSchedulesJson = JArray.FromObject(SchedulesJarry.Where(o => (string)o["_niq_lineitemid_value"] == (string)prod["quotedetailid"]));
                        if (allSchedulesJson != null && allSchedulesJson.Count > 0)
                        {
                            foreach (var schedule in allSchedulesJson)
                            {
                                if (schedule["niq_scheduledate"] != null && schedule["createdon"] != null)
                                {
                                    tracingService.Trace("BuildDeliverySchedulePayload: contains schedule date & created on" + Convert.ToDateTime(schedule["niq_scheduledate"]).ToString() + " created on " + Convert.ToDateTime(schedule["createdon"]).ToString());
                                    CreateDelivery(Convert.ToDateTime(schedule["niq_scheduledate"]), prod["quotedetailname"].ToString(), schedule["niq_amount"].ToString(), prod["quotedetailid"].ToString(), schedule["niq_scheduleid"].ToString());

                                }

                            }

                        }
                    }

                }
            }

            catch (Exception ex)
            {
                tracingService.Trace("BuildDeliverySchedulePayload error");
                throw ex;
            }
        }

        public void CreateDelivery(DateTime scheduledate, string quotedetailname, string deliveryamount, string quoteProductid, string quoteProdScheduleid)
        {

            sbPayload.AppendLine("{");
            sbPayload.AppendLine(string.Format("\"name\":\"{0}\",", scheduledate.ToString("dd.MM.yyyy", CultureInfo.CurrentCulture) + "_" + quotedetailname));
            sbPayload.AppendLine(string.Format("\"niq_deliveryamount\":\"{0}\",", Convert.ToString(deliveryamount)));
            sbPayload.AppendLine(string.Format("\"niq_scheduledate\":\"{0}\",", Convert.ToString(scheduledate)));
            sbPayload.AppendLine(string.Format("\"niq_relatedquotelineitemid\":\"/quotedetails({0})\",", Convert.ToString(quoteProductid)));
            sbPayload.AppendLine(string.Format("\"niq_scheduleid\":\"/niq_schedules({0})\"", Convert.ToString(quoteProdScheduleid)));
            sbPayload.AppendLine("},");

        }
        public int CalculateDurationInMonths(DateTime lineitemstartdate, DateTime lineitemenddate)

        {
            int monthsApart = 0;

            if (lineitemenddate != null && lineitemstartdate != null)
            {
                monthsApart = (lineitemenddate.Month - lineitemstartdate.Month) + 12 * (lineitemenddate.Year - lineitemstartdate.Year) + 1;

            }

            return monthsApart;

        }


    }
}
