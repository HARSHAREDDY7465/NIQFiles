﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;

namespace NielsenIQ.CRM.Plugins
{
    public class OnCreate_PostOpportunityChangeReq_ValidateReqType : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                if (context.MessageName == "Create")
                {
                    // The InputParameters collection contains all the data  
                    if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                    {
                        tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: Getting the target entity from Input Parameters.");
                        // Obtain the target entity from the input parameters
                        Entity entityObj = (Entity)context.InputParameters["Target"];
                        if (entityObj != null && entityObj.Id != Guid.Empty)
                        {
                            tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: postOppo" + entityObj.Id);
                            if (entityObj.Attributes.Contains("niq_opportunity") && entityObj.Attributes.Contains("niq_typeofchange"))
                            {
                                tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: Contains Oppo & Type");
                                int type = entityObj.GetAttributeValue<OptionSetValue>("niq_typeofchange").Value;
                                Guid oppoId = entityObj.GetAttributeValue<EntityReference>("niq_opportunity").Id;
                                tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: oppo." + oppoId);
                                tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: type" + type);
                                //1218 - Fetch POCR for same details and delete if rejected status
                                string fetchxmlPOCRRejected = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='niq_postopportunity'>
                                        <attribute name='niq_postopportunity' />
                                        <attribute name='niq_postopportunityid' />
                                        <filter type='and'>
                                          <condition attribute='niq_approvalstatus' operator='eq' value='3' />
                                          <condition attribute='niq_opportunity' operator='eq' value='" + oppoId + @"'/>
                                          <condition attribute='niq_typeofchange' operator='eq' value='" + type + @"' />
                                        </filter>
                                      </entity>
                                    </fetch>";
                                fetchxmlPOCRRejected = string.Format(fetchxmlPOCRRejected, oppoId);
                                var resultPOCRRejected = service.RetrieveMultiple(new FetchExpression(fetchxmlPOCRRejected));
                                if (resultPOCRRejected != null && resultPOCRRejected.Entities != null && resultPOCRRejected.Entities.Count > 0)
                                {
                                    tracing.Trace("resultPOCRRejected count" + resultPOCRRejected.Entities.Count);
                                    foreach (Entity en in resultPOCRRejected.Entities)
                                    {
                                        Entity enPOCR = new Entity("niq_postopportunity");
                                        enPOCR.Id = en.Id;
                                        enPOCR["niq_approvalstatus"] = new OptionSetValue(4);
                                        service.Update(enPOCR);
                                        tracing.Trace("Closed " + en.Id);
                                    }
                                }

                                // DYNCRM-1076- Start line: Changes as per story DYNCRM-1076: Added the condition for Assigned Gatekeeper field in POCR on create event of POCR
                                if (type != 100000005)// if POCR type is not equal to Business Segmentation
                                {
                                    int updateCount = 0; //this updateCount variable is taken to check Assigned gatekeeper from fetchxml retrieved Approved/Rejected POCR or Approved Opportunity Approval FAR records shown below
                                    string fetchxmlPOCR = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                <entity name='niq_postopportunity'>
                                                                    <attribute name='createdon'/>
                                                                    <attribute name='niq_postopportunityid'/>
                                                                    <attribute name='niq_typeofchange'/>
                                                                    <attribute name='niq_opportunity'/>
                                                                    <attribute name='niq_assignedtoid'/>
                                                                    <attribute name='niq_approvalstatus'/>
                                                                    <order attribute='niq_postopportunity' descending='true'/>                                                               
                                                                    <filter type='and'>
                                                                        <condition attribute='createdon' operator='on-or-after' value='2023-10-01'/>
                                                                        <condition attribute='modifiedon' operator='last-x-months' value='3'/>
                                                                        <condition attribute='niq_approvalstatus' operator='in'>
                                                                            <value>2</value>
                                                                            <value>3</value>
                                                                        </condition>
                                                                        <condition attribute='niq_opportunity' operator='eq' uitype='opportunity' value='{0}'/>
                                                                    </filter>
                                                                </entity>
                                                            </fetch>";
                                    fetchxmlPOCR = string.Format(fetchxmlPOCR, oppoId);
                                    var resultPOCR = service.RetrieveMultiple(new FetchExpression(fetchxmlPOCR));
                                    if (resultPOCR != null && resultPOCR.Entities != null && resultPOCR.Entities.Count > 0)
                                    {
                                        updateCount += 1;  //if the Fetch results contain data then updateCount=1
                                        //assigned gatekeeper from approved/rejected POCR record(getPOCR) and assigning it to newly created POCR's Assigned gatekeeper
                                        Entity getPOCR = resultPOCR.Entities.FirstOrDefault();
                                        if (getPOCR.Attributes.Contains("niq_assignedtoid"))
                                        {
                                            Entity getUser = service.Retrieve("systemuser", getPOCR.GetAttributeValue<EntityReference>("niq_assignedtoid").Id, new ColumnSet("isdisabled"));
                                            if (getUser.GetAttributeValue<bool>("isdisabled").ToString().ToLower() == "false")
                                            {
                                                entityObj["niq_assignedtoid"] = getPOCR.GetAttributeValue<EntityReference>("niq_assignedtoid");
                                                service.Update(entityObj);
                                                tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: updated from POCR success");
                                                updateCount += 1;   //this means that the assigned gatekeeper's status is Enabled user
                                            }
                                            updateCount += 1;   //if we take firstordefault() record from the records list then that record contains assigned gatekeeper value but if it is disabled user then updateCount=2 otherwise updateCount=3
                                        }
                                    }
                                    tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: count: " + updateCount);
                                    if (updateCount <= 2)    //if the POCR record doesn't have Assigned Gatekeeper Value or if the assigned gatekeeper's status is disabled then this will go for FAR records
                                    {
                                        string fetchxmlFAR = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                             <entity name='niq_financeapprovalrequests'>
                                                                <attribute name='niq_financeapprovalrequests'/>
                                                                <attribute name='createdon'/>
                                                                <attribute name='modifiedby'/>
                                                                <attribute name='niq_assignedtoid'/>
                                                                <attribute name='niq_financeapprovalrequestsid'/>
                                                                <attribute name='modifiedon'/>
                                                                <order attribute='niq_financeapprovalrequests' descending='true'/>
                                                                <filter type='and'>
                                                                  <condition attribute='niq_approvalstatus' operator='eq' value='100000002'/>
                                                                  <condition attribute='niq_approvaltype' operator='eq' value='100000000'/>
                                                                  <condition attribute='niq_relatedopportunity' operator='eq' uiname='' uitype='opportunity' value='{0}'/>
                                                                  <condition attribute='niq_assignedtoid' operator='not-null'/>
                                                                  <condition attribute='modifiedon' operator='last-x-months' value='3'/>
                                                                </filter>
                                                                <link-entity name='systemuser' from='systemuserid' to='niq_assignedtoid' link-type='inner' alias='ae'>
                                                                <filter type='and'>
                                                                    <condition attribute='isdisabled' operator='eq' value='0'/>
                                                                </filter>
                                                            </link-entity>
                                                          </entity>
                                                       </fetch>";
                                        fetchxmlFAR = string.Format(fetchxmlFAR, oppoId);
                                        var resultFAR = service.RetrieveMultiple(new FetchExpression(fetchxmlFAR));
                                        if (resultFAR != null && resultFAR.Entities != null && resultFAR.Entities.Count > 0)
                                        {
                                            tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: assigned gatekeeper value from approved FAR");
                                            //assigned gatekeeper from approved opportunity FAR record(getFAR) and assign to newly crated POCR Assigned gatekeeper
                                            Entity getFAR = resultFAR.Entities.FirstOrDefault();
                                            tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: gatekeeper from approved FAR" + getFAR.GetAttributeValue<EntityReference>("niq_assignedtoid").Name);
                                            entityObj["niq_assignedtoid"] = getFAR.GetAttributeValue<EntityReference>("niq_assignedtoid");
                                            service.Update(entityObj);
                                            tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: updated from FAR success ");
                                        }
                                    }
                                }
                                // DYNCRM-1076- End line: Changes as per story DYNCRM-1076: Added the condition for Assigned Gatekeeper field in POCR on create event of POCR
                                if (type != 100000003 && type != 100000004)
                                {
                                    tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: typ is not 3 & 4 ");
                                    string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='niq_postopportunity'>
                                                    <attribute name='niq_postopportunity' />
                                                    <attribute name='createdon' />
                                                    <attribute name='niq_postopportunityid' />
                                                    <order attribute='niq_postopportunity' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='niq_typeofchange' operator='eq' value='{0}' />
                                                      <condition attribute='niq_typeofchange' operator='not-in'>
                                                        <value>100000003</value>
                                                        <value>100000004</value>
                                                        <value>100000000</value>
                                                        <value>100000001</value>
                                                      </condition>
                                                      <condition attribute='niq_opportunity' operator='eq' uitype='opportunity' value='{1}' />
                                                      <condition attribute='niq_approvalstatus' operator='eq' value='1' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";
                                    fetchXml = string.Format(fetchXml, type, oppoId);
                                    var result = service.RetrieveMultiple(new FetchExpression(fetchXml));
                                    if (result != null && result.Entities != null && result.Entities.Count > 0)
                                    {
                                        tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: duplicate throwing error");
                                        throw new InvalidPluginExecutionException("There is already a Post Opportunity Change Request of the same type related to this opportunity and pending Finance approval. Please review its details on \"Post Opportunity Change Requests\" tab and ask Finance to approve or reject it before creating a new one.");
                                    }
                                    else
                                    {
                                        tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: distict record");
                                        if (type == 100000005)//set status aproved
                                        {
                                            tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: type is Business segment");
                                            Entity updPostOppo = new Entity(entityObj.LogicalName, entityObj.Id);
                                            updPostOppo["niq_approvalstatus"] = new OptionSetValue(2);
                                            updPostOppo["statecode"] = new OptionSetValue(1);
                                            tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: updating post Oppo req");
                                            service.Update(updPostOppo);
                                            tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: updated success ");
                                        }
                                        else//set status pending and assigned to finance team
                                        {
                                            tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: type is non segment ");
                                            Entity updPostOppo = new Entity(entityObj.LogicalName, entityObj.Id);
                                            Entity retOppo = service.Retrieve(entityObj.GetAttributeValue<EntityReference>("niq_opportunity").LogicalName, entityObj.GetAttributeValue<EntityReference>("niq_opportunity").Id, new ColumnSet("niq_salesorgid"));
                                            if (retOppo != null && retOppo.Id != Guid.Empty)
                                            {
                                                tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: ret Oppo " + retOppo.Id);
                                                if (retOppo.Attributes.Contains("niq_salesorgid"))
                                                {
                                                    Entity retFinanceTeam = service.Retrieve(retOppo.GetAttributeValue<EntityReference>("niq_salesorgid").LogicalName, retOppo.GetAttributeValue<EntityReference>("niq_salesorgid").Id, new ColumnSet("niq_financeteam"));
                                                    if (retFinanceTeam != null && retFinanceTeam.Id != Guid.Empty && retFinanceTeam.Attributes.Contains("niq_financeteam"))
                                                    {
                                                        tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType:retfinance" + retFinanceTeam.Id);
                                                        updPostOppo["ownerid"] = (EntityReference)retFinanceTeam.GetAttributeValue<EntityReference>("niq_financeteam");
                                                        updPostOppo["niq_approvalstatus"] = new OptionSetValue(1);
                                                        tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType:updating ");
                                                        service.Update(updPostOppo);
                                                        tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: sucess updating ");

                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if (type == 100000005)//business segmentation ---- Changes for DYNCRM-2662 to write back POCR Competitor to Opportunity
                                {
                                    tracing.Trace("Entering business segmentation on Create of POCR");
                                    Entity retpostOppo = service.Retrieve(entityObj.LogicalName, entityObj.Id, new ColumnSet("niq_opportunity", "niq_competitor1", "niq_competitor2", "niq_competitor3", "niq_competitor4", "niq_competitor5", "niq_competitor6", "niq_competitorsdetails", "niq_othercompetitor"));
                                    if (retpostOppo != null && retpostOppo.Id != Guid.Empty && retpostOppo.Attributes.Contains("niq_opportunity"))
                                    {
                                        tracing.Trace("Entering business segmentation contains OppId");
                                        Entity updOppo = new Entity(retpostOppo.GetAttributeValue<EntityReference>("niq_opportunity").LogicalName, retpostOppo.GetAttributeValue<EntityReference>("niq_opportunity").Id);
                                        tracing.Trace("Entering business segmentation: OppID: " + retpostOppo.GetAttributeValue<EntityReference>("niq_opportunity").Id.ToString());
                                        bool update = false;
                                        if (retpostOppo.Attributes.Contains("niq_competitor1"))
                                        {
                                            tracing.Trace("Entering business segmentation contains niq_competitor1");
                                            updOppo["niq_competitor1"] = (EntityReference)retpostOppo.GetAttributeValue<EntityReference>("niq_competitor1");
                                            update = true;
                                        }
                                        else
                                        {
                                            updOppo["niq_competitor1"] = null;
                                            update = true;
                                        }
                                        if (retpostOppo.Attributes.Contains("niq_competitor2"))
                                        {
                                            tracing.Trace("Entering business segmentation contains niq_competitor2");
                                            updOppo["niq_competitor2"] = (EntityReference)retpostOppo.GetAttributeValue<EntityReference>("niq_competitor2");
                                            update = true;
                                        }
                                        else
                                        {
                                            updOppo["niq_competitor2"] = null;
                                            update = true;
                                        }
                                        if (retpostOppo.Attributes.Contains("niq_competitor3"))
                                        {
                                            tracing.Trace("Entering business segmentation contains niq_competitor3");
                                            updOppo["niq_competitor3"] = (EntityReference)retpostOppo.GetAttributeValue<EntityReference>("niq_competitor3");
                                            update = true;
                                        }
                                        else
                                        {
                                            updOppo["niq_competitor3"] = null;
                                            update = true;
                                        }
                                        if (retpostOppo.Attributes.Contains("niq_competitor4"))
                                        {
                                            tracing.Trace("Entering business segmentation contains niq_competitor4");
                                            updOppo["niq_competitor4"] = (EntityReference)retpostOppo.GetAttributeValue<EntityReference>("niq_competitor4");
                                            update = true;
                                        }
                                        else
                                        {
                                            updOppo["niq_competitor4"] = null;
                                            update = true;
                                        }
                                        if (retpostOppo.Attributes.Contains("niq_competitor5"))
                                        {
                                            tracing.Trace("Entering business segmentation contains niq_competitor5");
                                            updOppo["niq_competitor5"] = (EntityReference)retpostOppo.GetAttributeValue<EntityReference>("niq_competitor5");
                                            update = true;
                                        }
                                        else
                                        {
                                            updOppo["niq_competitor5"] = null;
                                            update = true;
                                        }
                                        if (retpostOppo.Attributes.Contains("niq_competitor6"))
                                        {
                                            tracing.Trace("Entering business segmentation contains niq_competitor6");
                                            updOppo["niq_competitor6"] = (EntityReference)retpostOppo.GetAttributeValue<EntityReference>("niq_competitor6");
                                            update = true;
                                        }
                                        else
                                        {
                                            updOppo["niq_competitor6"] = null;
                                            update = true;
                                        }
                                        if (retpostOppo.Attributes.Contains("niq_competitorsdetails") && !string.IsNullOrEmpty(retpostOppo.GetAttributeValue<string>("niq_competitorsdetails")))
                                        {
                                            tracing.Trace("Entering business segmentation contains niq_competitorsdetails");
                                            updOppo["niq_competitorsdetails"] = retpostOppo.GetAttributeValue<string>("niq_competitorsdetails");
                                            update = true;
                                        }
                                        else
                                        {
                                            updOppo["niq_competitorsdetails"] = null;
                                            update = true;
                                        }
                                        if (retpostOppo.Attributes.Contains("niq_othercompetitor") && !string.IsNullOrEmpty(retpostOppo.GetAttributeValue<string>("niq_othercompetitor")))
                                        {
                                            tracing.Trace("Entering business segmentation contains niq_othercompetitor");
                                            updOppo["niq_othercompetitor"] = retpostOppo.GetAttributeValue<string>("niq_othercompetitor");
                                            update = true;
                                        }
                                        else
                                        {
                                            updOppo["niq_othercompetitor"] = null;
                                            update = true;
                                        }
                                        if (update)
                                        {
                                            service.Update(updOppo);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (context.MessageName == "Update")
                {
                    tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters
                    Entity entityObj = (Entity)context.InputParameters["Target"];
                    if (entityObj != null && entityObj.LogicalName == "niq_postopportunity" && entityObj.Id != Guid.Empty && entityObj.Attributes.Contains("niq_approvalstatus"))
                    {
                        tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: postOppo " + entityObj.Id);
                        int appStatus = entityObj.GetAttributeValue<OptionSetValue>("niq_approvalstatus").Value;
                        tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: app status" + appStatus);
                        Entity preImage = (Entity)context.PreEntityImages["Image"];
                        if (appStatus == 3)
                        {
                            if (preImage != null && preImage.Attributes.Contains("niq_typeofchange"))
                            {
                                int type = preImage.GetAttributeValue<OptionSetValue>("niq_typeofchange").Value;
                                tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: type of change req" + type);
                                if (type == 100000004)//EOD
                                {
                                    Entity retpocr = service.Retrieve(entityObj.LogicalName, entityObj.Id, new ColumnSet("niq_deliveryid", "niq_comments"));
                                    if (retpocr != null && retpocr.Id != Guid.Empty && retpocr.Attributes.Contains("niq_deliveryid"))
                                    {
                                        Entity updtDelivery = new Entity(retpocr.GetAttributeValue<EntityReference>("niq_deliveryid").LogicalName, retpocr.GetAttributeValue<EntityReference>("niq_deliveryid").Id);
                                        updtDelivery["niq_eoddocumentationurl"] = "";
                                        updtDelivery["niq_eodfilename"] = "";
                                        if (!retpocr.Attributes.Contains("niq_comments") || (retpocr.Attributes.Contains("niq_comments") && retpocr.GetAttributeValue<String>("niq_comments").ToLower() != "auto-rejection due a recalled eod."))
                                        {
                                            updtDelivery["niq_deliverystatus"] = new OptionSetValue(100000005);
                                        }
                                        service.Update(updtDelivery);
                                    }
                                }
                            }
                             tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: making post oppo inactive");
                            Entity updPostOppo = new Entity(entityObj.LogicalName, entityObj.Id);
                            updPostOppo["statecode"] = new OptionSetValue(1);
                            service.Update(updPostOppo);
                            tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType:inactivated post Oppo ");
                        }
                        if (appStatus == 2)
                        {
                            tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: app status is approved ");
                           // Entity preImage = (Entity)context.PreEntityImages["Image"];
                            if (preImage != null && preImage.Attributes.Contains("niq_typeofchange"))
                            {

                                int type = preImage.GetAttributeValue<OptionSetValue>("niq_typeofchange").Value;
                                tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: type of change req" + type);
                                if (type == 100000000)//Finally Executed Agreement & Payment term Submission
                                {

                                    Entity retpostOppo = service.Retrieve(entityObj.LogicalName, entityObj.Id, new ColumnSet("niq_finallyexecutedagreementurl", "niq_opportunity", "niq_paymenttermsid"));
                                    if (retpostOppo != null && retpostOppo.Id != Guid.Empty && retpostOppo.Attributes.Contains("niq_opportunity"))
                                    {
                                        tracing.Trace("retr pocr id " + retpostOppo.Id);
                                        if (retpostOppo.Attributes.Contains("niq_paymenttermsid"))
                                        {
                                            tracing.Trace("contains new payment termsid: " + retpostOppo.GetAttributeValue<EntityReference>("niq_paymenttermsid").Id.ToString());
                                            Entity retOppo = service.Retrieve(retpostOppo.GetAttributeValue<EntityReference>("niq_opportunity").LogicalName, retpostOppo.GetAttributeValue<EntityReference>("niq_opportunity").Id, new ColumnSet("niq_mainquoteid"));
                                            if (retOppo != null && retOppo.Id != Guid.Empty && retOppo.Attributes.Contains("niq_mainquoteid") && retOppo.GetAttributeValue<EntityReference>("niq_mainquoteid").Id != Guid.Empty)
                                            {
                                                tracing.Trace("ret Oppo " + retOppo.Id);
                                                tracing.Trace("main quote id " + retOppo.GetAttributeValue<EntityReference>("niq_mainquoteid").Id);
                                                Entity updMainQuote = new Entity(retOppo.GetAttributeValue<EntityReference>("niq_mainquoteid").LogicalName, retOppo.GetAttributeValue<EntityReference>("niq_mainquoteid").Id);
                                                updMainQuote["niq_paymenttermsid"] = new EntityReference(retpostOppo.GetAttributeValue<EntityReference>("niq_paymenttermsid").LogicalName, retpostOppo.GetAttributeValue<EntityReference>("niq_paymenttermsid").Id);
                                                service.Update(updMainQuote);
                                                tracing.Trace("updMainQuote success");
                                            }
                                        }
                                        if (retpostOppo.Attributes.Contains("niq_finallyexecutedagreementurl"))
                                        {
                                            tracing.Trace("contains finallyexe");
                                            Entity updOppo = new Entity(retpostOppo.GetAttributeValue<EntityReference>("niq_opportunity").LogicalName, retpostOppo.GetAttributeValue<EntityReference>("niq_opportunity").Id);
                                            updOppo["niq_finallyexecutedagreementurl"] = retpostOppo.GetAttributeValue<string>("niq_finallyexecutedagreementurl");
                                            service.Update(updOppo);
                                        }
                                    }
                                }
                                if (type == 100000001)//po detail
                                {
                                    Entity retpostOppo = service.Retrieve(entityObj.LogicalName, entityObj.Id, new ColumnSet("niq_customerpo", "niq_opportunity", "niq_customerpodate", "niq_podocumentationurl", "niq_newbilltopartyid", "niq_newdeliverytoparty"));
                                    if (retpostOppo != null && retpostOppo.Id != Guid.Empty && retpostOppo.Attributes.Contains("niq_opportunity"))
                                    {
                                        Entity updOppo = new Entity(retpostOppo.GetAttributeValue<EntityReference>("niq_opportunity").LogicalName, retpostOppo.GetAttributeValue<EntityReference>("niq_opportunity").Id);
                                        bool update = false;
                                        if (retpostOppo.Attributes.Contains("niq_customerpo"))
                                        {
                                            updOppo["niq_customerponumber"] = retpostOppo.GetAttributeValue<string>("niq_customerpo");
                                            update = true;
                                        }
                                        if (retpostOppo.Attributes.Contains("niq_customerpodate"))
                                        {
                                            updOppo["niq_customerpodate"] = retpostOppo.GetAttributeValue<DateTime>("niq_customerpodate");
                                            update = true;
                                        }
                                        if (retpostOppo.Attributes.Contains("niq_podocumentationurl"))
                                        {
                                            updOppo["niq_podocumentationurl"] = retpostOppo.GetAttributeValue<string>("niq_podocumentationurl");
                                            update = true;
                                        }
                                        if (retpostOppo.Attributes.Contains("niq_newbilltopartyid"))
                                        {
                                            tracing.Trace("contains new niq_newbilltopartyid: " + retpostOppo.GetAttributeValue<EntityReference>("niq_newbilltopartyid").Id.ToString());
                                            updOppo["niq_billtoparty"] = (EntityReference)retpostOppo.GetAttributeValue<EntityReference>("niq_newbilltopartyid");
                                            update = true;
                                        }
                                        if (retpostOppo.Attributes.Contains("niq_newdeliverytoparty"))
                                        {
                                            tracing.Trace("contains new niq_newdeliverytoparty: " + retpostOppo.GetAttributeValue<EntityReference>("niq_newdeliverytoparty").Id.ToString());
                                            updOppo["niq_deliverytoparty"] = (EntityReference)retpostOppo.GetAttributeValue<EntityReference>("niq_newdeliverytoparty");
                                            update = true;
                                        }
                                        if (update)
                                        {
                                            service.Update(updOppo);
                                        }
                                    }
                                }
                                if (type == 100000002)//bill to client
                                {
                                    Entity retpostOppo = service.Retrieve(entityObj.LogicalName, entityObj.Id, new ColumnSet("niq_newbilltopartyid", "niq_opportunity", "niq_newdeliverytoparty"));
                                    if (retpostOppo != null && retpostOppo.Id != Guid.Empty && retpostOppo.Attributes.Contains("niq_opportunity"))
                                    {
                                        Entity updOppo = new Entity(retpostOppo.GetAttributeValue<EntityReference>("niq_opportunity").LogicalName, retpostOppo.GetAttributeValue<EntityReference>("niq_opportunity").Id);
                                        if (retpostOppo.Attributes.Contains("niq_newbilltopartyid"))
                                        {
                                            updOppo["niq_billtoparty"] = (EntityReference)retpostOppo.GetAttributeValue<EntityReference>("niq_newbilltopartyid");
                                            updOppo["niq_deliverytoparty"] = (EntityReference)retpostOppo.GetAttributeValue<EntityReference>("niq_newdeliverytoparty");
                                            service.Update(updOppo);
                                            tracing.Trace("OnCreate_PostOpportunityChangeReq_ValidateReqType: updOppo success");
                                        }
                                    }

                                }
                                if (type == 100000005)//business segmentation
                                {
                                    Entity retpostOppo = service.Retrieve(entityObj.LogicalName, entityObj.Id, new ColumnSet("niq_primarymarketingcampaignid", "niq_opportunity", "niq_internalinitiative", "niq_niqaccountgoalid"));
                                    if (retpostOppo != null && retpostOppo.Id != Guid.Empty && retpostOppo.Attributes.Contains("niq_opportunity"))
                                    {
                                        Entity updOppo = new Entity(retpostOppo.GetAttributeValue<EntityReference>("niq_opportunity").LogicalName, retpostOppo.GetAttributeValue<EntityReference>("niq_opportunity").Id);
                                        bool update = false;
                                        if (retpostOppo.Attributes.Contains("niq_primarymarketingcampaignid"))
                                        {
                                            updOppo["campaignid"] = (EntityReference)retpostOppo.GetAttributeValue<EntityReference>("niq_primarymarketingcampaignid");
                                            update = true;
                                        }
                                        else
                                        {
                                            updOppo["campaignid"] = null;
                                            update = true;
                                        }
                                        if (retpostOppo.Attributes.Contains("niq_internalinitiative"))
                                        {
                                            updOppo["niq_internalinitiative"] = (EntityReference)retpostOppo.GetAttributeValue<EntityReference>("niq_internalinitiative");
                                            update = true;
                                        }
                                        else
                                        {
                                            updOppo["niq_internalinitiative"] = null;
                                            update = true;
                                        }
                                        if (retpostOppo.Attributes.Contains("niq_niqaccountgoalid"))
                                        {
                                            updOppo["niq_accountgoalid"] = (EntityReference)retpostOppo.GetAttributeValue<EntityReference>("niq_niqaccountgoalid");
                                            update = true;
                                        }
                                        else
                                        {
                                            updOppo["niq_accountgoalid"] = null;
                                            update = true;
                                        }
                                        if (update)
                                        {
                                            service.Update(updOppo);
                                        }
                                    }
                                }
                                if (type == 100000003)//Date Change
                                {
                                    Entity retpostOppo = service.Retrieve(entityObj.LogicalName, entityObj.Id, new ColumnSet("niq_deliveryid"));
                                    if (retpostOppo != null && retpostOppo.Id != Guid.Empty && retpostOppo.Attributes.Contains("niq_deliveryid"))
                                    {
                                        Entity retDelivery = service.Retrieve(retpostOppo.GetAttributeValue<EntityReference>("niq_deliveryid").LogicalName, retpostOppo.GetAttributeValue<EntityReference>("niq_deliveryid").Id, new ColumnSet("niq_proposeddeliverydate"));
                                        if (retDelivery != null && retDelivery.Id != Guid.Empty && retDelivery.Attributes.Contains("niq_proposeddeliverydate"))
                                        {
                                            Entity updDelivery = new Entity(retDelivery.LogicalName, retDelivery.Id);
                                            updDelivery["niq_dateofdelivery"] = retDelivery.GetAttributeValue<DateTime>("niq_proposeddeliverydate");
                                            service.Update(updDelivery);
                                        }
                                    }

                                }
                                if (type == 100000004)//EOD
                                {
                                    Entity retpostOppo = service.Retrieve(entityObj.LogicalName, entityObj.Id, new ColumnSet("niq_deliveryid"));
                                    if (retpostOppo != null && retpostOppo.Id != Guid.Empty && retpostOppo.Attributes.Contains("niq_deliveryid"))
                                    {
                                        Entity updDelivery = new Entity(retpostOppo.GetAttributeValue<EntityReference>("niq_deliveryid").LogicalName, retpostOppo.GetAttributeValue<EntityReference>("niq_deliveryid").Id);

                                        // retrieve "Forecasted delivery date" of delivery and update to "Previously confirmed date"
                                        Entity delivry = service.Retrieve(retpostOppo.GetAttributeValue<EntityReference>("niq_deliveryid").LogicalName, retpostOppo.GetAttributeValue<EntityReference>("niq_deliveryid").Id, new ColumnSet("niq_proposeddeliverydate"));

                                        if (delivry != null && delivry.Attributes.Contains("niq_proposeddeliverydate"))
                                        {
                                           tracing.Trace("date:" + (DateTime)delivry.Attributes["niq_proposeddeliverydate"]);
                                           updDelivery["niq_dateofdelivery"] = (DateTime)delivry.Attributes["niq_proposeddeliverydate"];
                                        }
                                           updDelivery["statecode"] = new OptionSetValue(1);
                                           updDelivery["statuscode"] = new OptionSetValue(2);
                                           //updDelivery["niq_deliverystatus"] = new OptionSetValue(100000002);
                                           updDelivery["niq_deliverystatus"] = new OptionSetValue(100000006);
                                           service.Update(updDelivery);
                                    }

                                }
                                if (type == 100000010)//Invoice recipient Updates
                                {
                                    Entity retpostOppo = service.Retrieve(entityObj.LogicalName, entityObj.Id, new ColumnSet("niq_parentcontactid", "niq_opportunity", "niq_invoicerecipient2", "niq_invoicerecipient3", "niq_invoicerecipient4", "niq_invoicerecipient5", "niq_nameoninvoiceifdifffrominvoicerecipient"));
                                    if (retpostOppo != null && retpostOppo.Id != Guid.Empty && retpostOppo.Attributes.Contains("niq_opportunity"))
                                    {
                                        Entity updOppo = new Entity(retpostOppo.GetAttributeValue<EntityReference>("niq_opportunity").LogicalName, retpostOppo.GetAttributeValue<EntityReference>("niq_opportunity").Id);
                                        // DYNMSM-5162- start line: Changes as per story DYNMSM-5162: updated the condition for the 6 invoice fields to update in Opportunity for Type of change= invoice Recipient Updates
                                        updOppo["parentcontactid"] = retpostOppo.Attributes.Contains("niq_parentcontactid") ? retpostOppo.GetAttributeValue<EntityReference>("niq_parentcontactid") : null;
                                        updOppo["niq_invoicerecipient2"] = retpostOppo.Attributes.Contains("niq_invoicerecipient2") ? retpostOppo.GetAttributeValue<EntityReference>("niq_invoicerecipient2") : null;
                                        updOppo["niq_invoicerecipient3"] = retpostOppo.Attributes.Contains("niq_invoicerecipient3") ? retpostOppo.GetAttributeValue<EntityReference>("niq_invoicerecipient3") : null;
                                        updOppo["niq_invoicerecipient4"] = retpostOppo.Attributes.Contains("niq_invoicerecipient4") ? retpostOppo.GetAttributeValue<EntityReference>("niq_invoicerecipient4") : null;
                                        updOppo["niq_invoicerecipient5"] = retpostOppo.Attributes.Contains("niq_invoicerecipient5") ? retpostOppo.GetAttributeValue<EntityReference>("niq_invoicerecipient5") : null;
                                        updOppo["niq_nameoninvoiceifdifffrominvoicerecipient"] = retpostOppo.Attributes.Contains("niq_nameoninvoiceifdifffrominvoicerecipient") ? retpostOppo.GetAttributeValue<EntityReference>("niq_nameoninvoiceifdifffrominvoicerecipient") : null;
                                        service.Update(updOppo);
                                        //bool update = false;
                                        //if (retpostOppo.Attributes.Contains("niq_parentcontactid"))
                                        //{
                                        //    updOppo["parentcontactid"] = retpostOppo.GetAttributeValue<EntityReference>("niq_parentcontactid");
                                        //    update = true;
                                        //}
                                        //if (retpostOppo.Attributes.Contains("niq_invoicerecipient2"))
                                        //{
                                        //    updOppo["niq_invoicerecipient2"] = retpostOppo.GetAttributeValue<EntityReference>("niq_invoicerecipient2");
                                        //    update = true;
                                        //}
                                        //if (retpostOppo.Attributes.Contains("niq_invoicerecipient3"))
                                        //{
                                        //    updOppo["niq_invoicerecipient3"] = retpostOppo.GetAttributeValue<EntityReference>("niq_invoicerecipient3");
                                        //    update = true;
                                        //}
                                        //if (retpostOppo.Attributes.Contains("niq_invoicerecipient4"))
                                        //{
                                        //    updOppo["niq_invoicerecipient4"] = retpostOppo.GetAttributeValue<EntityReference>("niq_invoicerecipient4");
                                        //    update = true;
                                        //}
                                        //if (retpostOppo.Attributes.Contains("niq_invoicerecipient5"))
                                        //{
                                        //    updOppo["niq_invoicerecipient5"] = retpostOppo.GetAttributeValue<EntityReference>("niq_invoicerecipient5");
                                        //    update = true;
                                        //}
                                        //if (retpostOppo.Attributes.Contains("niq_nameoninvoiceifdifffrominvoicerecipient"))
                                        //{
                                        //    updOppo["niq_nameoninvoiceifdifffrominvoicerecipient"] = retpostOppo.GetAttributeValue<EntityReference>("niq_nameoninvoiceifdifffrominvoicerecipient");
                                        //    update = true;
                                        //}
                                        //if (update)
                                        //{
                                        //    service.Update(updOppo);
                                        //}
                                        // DYNMSM-5162- end line: Changes as per story DYNMSM-5162: updated the condition for the 6 invoice fields to update in Opportunity for Type of change= invoice Recipient Updates
                                    }
                                }

                                Entity updPostOppo = new Entity(entityObj.LogicalName, entityObj.Id);
                                updPostOppo["statecode"] = new OptionSetValue(1);
                                service.Update(updPostOppo);
                            }
                        }
                    }

                    if (entityObj != null && entityObj.LogicalName == "opportunity" && entityObj.Id != Guid.Empty && entityObj.Attributes.Contains("niq_finallyexecutedagreementurl"))
                    {
                        Entity oppo = service.Retrieve(entityObj.LogicalName, entityObj.Id, new ColumnSet("modifiedby", "niq_stage", "niq_finallyexecutedagreementurl"));
                        EntityReference modifiedBy = oppo.GetAttributeValue<EntityReference>("modifiedby");
                        Entity accessType = service.Retrieve(modifiedBy.LogicalName, modifiedBy.Id, new ColumnSet("accessmode", "fullname"));
                        string modify = (string)accessType["fullname"];
                        tracing.Trace("Modified By username" + modify);
                        if (accessType.GetAttributeValue<OptionSetValue>("accessmode").Value == 4 && modify.Contains("Boomi") && oppo.GetAttributeValue<string>("niq_stage") == "Closed Won - Approved")
                        {
                            tracing.Trace("Entered If loop");
                            Entity pocrRecord = new Entity("niq_postopportunity");
                            Entity opportunity = service.Retrieve(entityObj.LogicalName, entityObj.Id, new ColumnSet("niq_finallyexecutedagreementurl", "niq_mainquoteid"));
                            EntityReference mainQuote = opportunity.GetAttributeValue<EntityReference>("niq_mainquoteid");
                            Entity retQuote = service.Retrieve(mainQuote.LogicalName, mainQuote.Id, new ColumnSet("opportunityid", "niq_salesorgid", "niq_paymenttermsid"));
                            if (retQuote != null && retQuote.Id != Guid.Empty && retQuote.Attributes.Contains("opportunityid") && retQuote.GetAttributeValue<EntityReference>("opportunityid").Id != Guid.Empty)
                            {
                                string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='niq_postopportunity'>
                                                    <attribute name='niq_postopportunity' />
                                                    <attribute name='createdon' />
                                                    <attribute name='niq_postopportunityid' />
                                                    <order attribute='niq_postopportunity' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='niq_typeofchange' operator='eq' value='100000000' />
                                                      <condition attribute='niq_typeofchange' operator='not-in'>
                                                        <value>100000003</value>
                                                        <value>100000004</value>
                                                      </condition>
                                                      <condition attribute='niq_opportunity' operator='eq' uitype='opportunity' value='{0}' />
                                                      <condition attribute='niq_approvalstatus' operator='eq' value='1' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";
                                fetchXml = string.Format(fetchXml, retQuote.GetAttributeValue<EntityReference>("opportunityid").Id);
                                var result = service.RetrieveMultiple(new FetchExpression(fetchXml));
                                if (result != null && result.Entities != null && result.Entities.Count > 0)
                                {
                                    Entity pocrObj = result.Entities.FirstOrDefault();
                                    pocrObj["niq_finallyexecutedagreementurl"] = entityObj.GetAttributeValue<string>("niq_finallyexecutedagreementurl");
                                    service.Update(pocrObj);
                                }
                                else
                                {
                                    tracing.Trace("Entered else loop for POCR generation");
                                    pocrRecord["niq_finallyexecutedagreementurl"] = entityObj.GetAttributeValue<string>("niq_finallyexecutedagreementurl");
                                    pocrRecord["niq_typeofchange"] = new OptionSetValue(100000000);
                                    pocrRecord["niq_descriptionofchange"] = "Changed By Conga Team";
                                    pocrRecord["niq_paymenttermsid"] = new EntityReference(retQuote.GetAttributeValue<EntityReference>("niq_paymenttermsid").LogicalName, retQuote.GetAttributeValue<EntityReference>("niq_paymenttermsid").Id);
                                    pocrRecord["niq_opportunity"] = new EntityReference(retQuote.GetAttributeValue<EntityReference>("opportunityid").LogicalName, retQuote.GetAttributeValue<EntityReference>("opportunityid").Id);
                                    service.Create(pocrRecord);

                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
