﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.Plugins.Helper;
using System;
using System.Collections.Generic;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Entities_UpdateIsModifiedOnQuoteProduct : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                tracingService.Trace("Execution Begins");
                OptionSetValue preBillingFrequency = new OptionSetValue();
                OptionSetValue postBillingFrequency = new OptionSetValue();
                OptionSetValue preRevenueFrequency = new OptionSetValue();
                OptionSetValue postRevenueFrequency = new OptionSetValue();
                tracingService.Trace("context.Depth:" + context.Depth);
                tracingService.Trace("context.Depth:" + context.Depth);
                //Get Target Entity
                Entity targetEntity = GetTargetEntity(context);
                Entity postImageQuoteProduct = null;
                Entity preImageQuoteProduct = null;

                if (context.PreEntityImages.Contains("Image"))
                {
                    preImageQuoteProduct = (Entity)context.PreEntityImages["Image"];
                }


                if (context.PostEntityImages.Contains("Image"))
                {
                    postImageQuoteProduct = (Entity)context.PostEntityImages["Image"];
                }

                if (preImageQuoteProduct != null)
                {
                    preBillingFrequency = preImageQuoteProduct.Contains("niq_billingfrequency") && preImageQuoteProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency") != null ? preImageQuoteProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency") : null;
                    // tracingService.Trace("Pre Billing frequency = " + preBillingFrequency.Value);
                    preRevenueFrequency = preImageQuoteProduct.Contains("niq_deliveryfrequency") && preImageQuoteProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency") != null ? preImageQuoteProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency") : null;
                }
                if (postImageQuoteProduct != null)
                {
                    postBillingFrequency = postImageQuoteProduct.Contains("niq_billingfrequency") && postImageQuoteProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency") != null ? postImageQuoteProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency") : null;
                    //  tracingService.Trace("Post Billing frequency = " + postBillingFrequency.Value);
                    postRevenueFrequency = postImageQuoteProduct.Contains("niq_deliveryfrequency") && postImageQuoteProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency") != null ? postImageQuoteProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency") : null;
                    //tracingService.Trace("Post Billing frequency = " + postRevenueFrequency.Value);
                }

                if (targetEntity == null)
                    return;

                if (context.PrimaryEntityName == "opportunity" && targetEntity.Contains("niq_stage") && context.Depth == 2)
                {
                    //  tracingService.Trace("opportunity");
                    UpdateQuoteProductsForOpportunity(postImageQuoteProduct, service, tracingService, targetEntity, context);
                }
                else if (context.PrimaryEntityName == "opportunity" && (targetEntity.Contains("niq_mainquoteid") || targetEntity.Contains("estimatedclosedate")) && context.Depth == 1)
                {
                    //  tracingService.Trace("opportunity");
                    UpdateQuoteProductsForOpportunity(postImageQuoteProduct, service, tracingService, targetEntity, context);
                }
                else if (context.PrimaryEntityName == "niq_quoteproductcharacteristic" && context.Depth == 1)
                {
                    UpdateQuoteDetailForQuoteProductCharacteristic(service, tracingService, context);
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
        }


        /// <summary>
        /// Get Target Entity
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        private Entity GetTargetEntity(IPluginExecutionContext context)
        {
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                return (Entity)context.InputParameters["Target"];
            }
            return null;
        }
        /// <summary>
        ///  Update Is modified Revenue on quote product if Start Date, End Date,Revenue frequency fields are updated in Quote Product
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="quoteProduct"></param>
        private void UpdateQuoteDetailModifiedFields(Entity preImageQuoteProduct, Entity postImageQuoteProduct, IOrganizationService service, ITracingService tracingService, Entity quoteProduct, IPluginExecutionContext context, OptionSetValue preBillingFrequency, OptionSetValue postBillingFrequency, OptionSetValue preRevenueFrequency, OptionSetValue postRevenueFrequency)

        {
            string functionName = "UpdateQuoteDetailModifiedFields";
            tracingService.Trace("Inside" + functionName);
            Entity quotedetailEnt = new Entity("quotedetail");
            quotedetailEnt.Id = quoteProduct.Id;

            if (quoteProduct.Contains("niq_billingfrequency"))
            {
                quotedetailEnt["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
            }
            else if (quoteProduct.Contains("niq_deliveryfrequency") ||
                     quoteProduct.Contains("niq_lagrevenuerecognition"))
            {
                quotedetailEnt["niq_isrevenuemodified"] =  DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
            }
            service.Update(quotedetailEnt);
        }
        /// <summary>
        /// Update Is modified Revenue on quote product if Stage,est Close date is updated in Opportunity
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="opportunity"></param>
        private void UpdateQuoteProductsForOpportunity(Entity postImageQuoteProduct, IOrganizationService service, ITracingService tracingService, Entity opportunity, IPluginExecutionContext context)
        {
            try
            {
                //Validate and get Stage
                if (opportunity.Contains("niq_stage") && opportunity.GetAttributeValue<string>("niq_stage").ToLower() == "proposal")
                {
                    tracingService.Trace("Opportunity Stage Changed");
                    //   Entity postOpportunity = context.PostEntityImages["PostImage"] ? (Entity)context.PostEntityImages["PostImage"] : null;
                    EntityReference quoteErf = postImageQuoteProduct.Contains("niq_mainquoteid") && postImageQuoteProduct.Attributes["niq_mainquoteid"] != null ? postImageQuoteProduct.GetAttributeValue<EntityReference>("niq_mainquoteid") : null;
                    tracingService.Trace("quoteErf:" + quoteErf.Id);
                    UpdateIsModifiedOnQuote(quoteErf, service, tracingService, false);
                }
                else if (opportunity.Contains("niq_mainquoteid"))
                {
                    tracingService.Trace("onchange of mainquote");
                    EntityReference quoteErf = opportunity.GetAttributeValue<EntityReference>("niq_mainquoteid");
                    UpdateIsModifiedOnQuote(quoteErf, service, tracingService, true);
                }
                else if (opportunity.Contains("estimatedclosedate"))
                {
                    string preEstCloseDate = GetEstimatedCloseDate(context.PreEntityImages, "PreImage", tracingService);
                    tracingService.Trace("preEstCloseDate:" + preEstCloseDate);

                    string postEstCloseDate = GetEstimatedCloseDate(context.PostEntityImages, "Image", tracingService);
                    tracingService.Trace("postEstCloseDate:" + postEstCloseDate);

                    if (preEstCloseDate != null && postEstCloseDate != null && preEstCloseDate != postEstCloseDate)
                    {
                        tracingService.Trace("Est Close Date triggered");
                        Guid opportunityId = opportunity.Id;
                        string fetchQuoteProduct = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                        <entity name='quotedetail'>
                                                        <attribute name='quotedetailid' />
                                                        <order attribute='niq_brandid' descending='false' />
                                                        <filter type='and'>
                                                        <condition attribute='niq_deliveryfrequency' operator='ne' value='100000009' />
                                                        </filter>
                                                        <link-entity name='quote' from='quoteid' to='quoteid' link-type='inner' alias='aa'>
                                                        <filter type='and'>
                                                        <condition attribute='opportunityid' operator='eq' value='{" + opportunityId + @"}' />
                                                        </filter>
                                                        </link-entity>
                                                        </entity>
                                                        </fetch>";

                        EntityCollection quoteProducts = service.RetrieveMultiple(new FetchExpression(fetchQuoteProduct));
                        tracingService.Trace("Count:" + quoteProducts.Entities.Count);
                        if (quoteProducts.Entities.Count > 0)
                        {
                            var updateRequests = new List<Entity>();
                            foreach (var quoteProduct in quoteProducts.Entities)
                            {
                                Entity updateQuoteProduct = new Entity("quotedetail");
                                updateQuoteProduct.Id = quoteProduct.Id;
                                bool isAutomated = CommonHelper.IsAutomatedOpportunity(service, quoteProduct.Id);
                                if(!isAutomated)
                                {
                                    updateQuoteProduct["niq_isrevenuemodified"] =  DateTime.Now.ToString();
                                }
                              
                                updateRequests.Add(updateQuoteProduct);
                            }

                            ExecuteMultipleRequest(service, updateRequests, tracingService);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
        }/// <summary>
         /// Get Est close Date from Pre and Post Image
         /// </summary>
         /// <param name="images"></param>
         /// <param name="imageName"></param>
         /// <param name="tracingService"></param>
         /// <returns></returns>
        private string GetEstimatedCloseDate(EntityImageCollection images, string imageName, ITracingService tracingService)
        {
            tracingService.Trace("images.Contains(imageName): " + images.Contains(imageName));
            if (images.Contains(imageName))
            {
                var entity = images[imageName];
                tracingService.Trace("entity:" + entity);
                tracingService.Trace("estimatedclosedate:" + entity.Attributes.Contains("estimatedclosedate"));
                tracingService.Trace("estimatedclosedate:" + entity["estimatedclosedate"]);

                if (entity.Attributes.Contains("estimatedclosedate") &&
                    entity["estimatedclosedate"] is DateTime estimatedCloseDate)
                {
                    return estimatedCloseDate.ToString("MM/dd/yyyy"); ;
                }
            }
            return null; // Return null if not found
        }
        /// <summary>
        /// Update is revenue modified in Quote product For Quote Product Characteristic
        /// </summary>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="quoteProductCharacteristic"></param>
        private void UpdateQuoteDetailForQuoteProductCharacteristic(IOrganizationService service, ITracingService tracingService, IPluginExecutionContext context)
        {
            try
            {
                string functionName = "UpdateQuoteDetailForQuoteProductCharacteristic";
                tracingService.Trace("Inside:" + functionName);
                //Get Image
                Entity quoteProductCharacteristic = context.PostEntityImages.Contains("PostImage") ? (Entity)context.PostEntityImages["PostImage"] : null;
                EntityReference quoteProductRef = quoteProductCharacteristic.GetAttributeValue<EntityReference>("niq_quoteproductid");
                if (quoteProductRef != null)
                {
                    Entity quoteProduct = service.Retrieve("quotedetail", quoteProductRef.Id, new ColumnSet("niq_clonequoteproduct"));        
                    bool hasCloneValue = quoteProduct.Contains("niq_clonequoteproduct") && quoteProduct.GetAttributeValue<EntityReference>("niq_clonequoteproduct") != null;
                    tracingService.Trace("Has Clone Value: " + hasCloneValue);
                    string fetchQuoteProduct = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                          <entity name='niq_quoteproductcharacteristic'>
                            <attribute name='niq_name' />
                            <filter type='and'>
                              <condition attribute='niq_quoteproductid' operator='eq' uitype='quotedetail' value='{" + quoteProductRef.Id + @"}' />
                            </filter>
                            <link-entity name='niq_characteristicvalue' from='niq_characteristicvalueid' to='niq_materialcharacteristicvalueid' link-type='inner' alias='ac'>
                              <filter type='and'>
                                <condition attribute='niq_characteristicvaluecode' operator='eq' value='SC000003' />
                              </filter>
                            </link-entity>
                          </entity>
                        </fetch>";

                    EntityCollection quoteProductCharacteristicColl = service.RetrieveMultiple(new FetchExpression(fetchQuoteProduct));
                    tracingService.Trace("Count:" + quoteProductCharacteristicColl.Entities.Count);
                    if (quoteProductCharacteristicColl.Entities.Count > 0)
                    {
                        Entity quotedetailEnt = new Entity("quotedetail");
                        quotedetailEnt.Id = quoteProductRef.Id;
                        bool isAutomated = CommonHelper.IsAutomatedOpportunity(service, quoteProductRef.Id);
                        if (!isAutomated && !hasCloneValue)
                        {
                            // Handle the automated opportunity case
                            quotedetailEnt["niq_isrevenuemodified"] =  DateTime.Now.ToString().ToString();
                        }
                       
                        service.Update(quotedetailEnt);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
        }
        /// <summary>
        /// Update Is Revenue Modified On Quote record
        /// </summary>
        /// <param name="quoteErf"></param>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
        /// <param name="triggerRevenueGeneration"></param>
        private void UpdateIsModifiedOnQuote(EntityReference quoteErf, IOrganizationService service, ITracingService tracingService, bool triggerRevenueGeneration)
        {
            try
            {
                string functionName = "UpdateIsModifiedOnQuote";
                tracingService.Trace("Inside:" + functionName);
                if (quoteErf != null && quoteErf.Id != Guid.Empty)
                {
                    QueryExpression quoteProductQuery = new QueryExpression("quotedetail");
                    quoteProductQuery.ColumnSet.AddColumns("niq_billingfrequency", "niq_type");
                    quoteProductQuery.Criteria.AddCondition("quoteid", ConditionOperator.Equal, quoteErf.Id);
                    quoteProductQuery.Criteria.AddCondition("niq_isrevshareline", ConditionOperator.Equal, false);

                    EntityCollection quoteProducts = service.RetrieveMultiple(quoteProductQuery);
                    var updateRequests = new List<Entity>();
                    foreach (var quoteProduct in quoteProducts.Entities)
                    {
                        Entity updateQuoteProduct = new Entity("quotedetail");
                        updateQuoteProduct.Id = quoteProduct.Id;

                        //DYNCRM-22341: if billingfrequency is not adhoc, then trigger the flow.
                        if (!(quoteProduct.Contains("niq_type") && quoteProduct["niq_type"] != null && quoteProduct.GetAttributeValue<OptionSetValue>("niq_type").Value == 1 &&
                   quoteProduct.Contains("niq_billingfrequency") && quoteProduct["niq_billingfrequency"] != null && quoteProduct.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value == 100000009))
                        {
                            updateQuoteProduct["niq_isbillingmodified"] = DateTime.Now.ToString();
                        }

                        if (triggerRevenueGeneration)
                        {
                            updateQuoteProduct["niq_isrevenuemodified"] = DateTime.Now.ToString();
                        }
                        updateRequests.Add(updateQuoteProduct);
                    }

                    ExecuteMultipleRequest(service, updateRequests, tracingService);
                    tracingService.Trace("Records are updated");
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
        }
        /// <summary>
        /// Update all record at onec using execute Multiple request
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entities"></param>
        /// <param name="tracingService"></param>
        private void ExecuteMultipleRequest(IOrganizationService service, List<Entity> entities, ITracingService tracingService)
        {
            string functionName = "ExecuteMultipleRequest";
            tracingService.Trace("Inside:" + functionName);
            if (entities.Count > 0)
            {
                var requestWithResults = new ExecuteMultipleRequest()
                {
                    Requests = new OrganizationRequestCollection(),
                    Settings = new ExecuteMultipleSettings()
                    {
                        ContinueOnError = false,
                        ReturnResponses = true
                    }
                };

                foreach (var entity in entities)
                {
                    requestWithResults.Requests.Add(new UpdateRequest { Target = entity });
                }

                var responseWithResults = (ExecuteMultipleResponse)service.Execute(requestWithResults);
            }
        }
    }
}