﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json.Linq;
using System;
using System.ComponentModel;
using System.Linq;
using static NielsenIQ.CRM.Plugins.Helper.CommonConstant;
using NielsenIQ.CRM.Plugins.Helper;

namespace NielsenIQ.CRM.Plugins
{
    public class OnCreate_PriceListItem_UpdateFrequencies : IPlugin
    {
        private ITracingService tracingService;
        private IOrganizationService service;
        private Entity priceListItemEnt;

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                service = serviceFactory.CreateOrganizationService(context.UserId);
                tracingService.Trace("message" + context.MessageName.ToLower());
                tracingService.Trace("context.Depth:" + context.Depth);
                if (context.Depth > 1)
                    return;
                switch (context.MessageName.ToLower())
                {
                    case "update":
                        priceListItemEnt = (Entity)context.PostEntityImages["PostImage"];
                        break;
                    case "create":
                        tracingService.Trace("Create Switch");
                        priceListItemEnt = (Entity)context.PostEntityImages["PostImage"];
                        break;
                }
                //Get Is Time based field value
                string isTimeBasedValue = GetIsTimeBasedValue(priceListItemEnt);
                tracingService.Trace("isTimeBasedValue:" + isTimeBasedValue);

                //Get Product Type 
                string productType = GetProductType(priceListItemEnt);
                tracingService.Trace("productType:" + productType);

                //Get product entity
                Entity product = GetProductEntity(priceListItemEnt);

                //Get onPlatform delievry
                string isOnPlatformDelivery = GetIsOnPlatformDelivery(product);
                tracingService.Trace("isOnPlatformDelivery:" + isOnPlatformDelivery);

                //Get json file for frequency
                string frequencies = GetFrequencies();
                tracingService.Trace("frequencies:" + frequencies);


                //Get product name
                string productName = GetProductName(priceListItemEnt);

                JObject jsonArray = JObject.Parse(frequencies);
                tracingService.Trace("jsonArray:" + jsonArray);

                UpdateFrequency(productName, jsonArray, isTimeBasedValue, isOnPlatformDelivery, productType, priceListItemEnt, service, tracingService);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }
        }

        private string GetIsTimeBasedValue(Entity priceListItemTarget)
        {
            tracingService.Trace("Inside GetIsTimeBasedValue");
            bool isTimeBased = priceListItemEnt.Contains("niq_istimebased") ? priceListItemTarget.GetAttributeValue<bool>("niq_istimebased") : false;
            return isTimeBased ? "Yes" : "No";
        }

        private string GetProductType(Entity priceListItemTarget)
        {
            tracingService.Trace("Inside GetProductType");
            string productType = string.Empty;
            if (priceListItemTarget.Contains("niq_producttype"))
            {

                int productTypeValue = priceListItemTarget.GetAttributeValue<OptionSetValue>("niq_producttype").Value;
                if (productTypeValue == 100000000)
                {
                    productType = "Periodic";
                }
                else
                {
                    productType = "Ad-hoc";
                }

            }
            else if (priceListItemTarget.Contains("niq_itemcategorygroup"))
            {
                int itemCategoryGroup = priceListItemTarget.GetAttributeValue<OptionSetValue>("niq_itemcategorygroup").Value;
                switch (itemCategoryGroup)
                {
                    case 100000000:
                    case 100000003:
                    case 100000004:
                    case 100000013:
                    case 100000014:
                    case 100000020:
                    case 100000021:
                        productType = "Periodic";
                        break;
                    default:
                        productType = "Ad-hoc";
                        break;
                }

            }
            return productType;
        }

        private string GetIsOnPlatformDelivery(Entity productEnt)
        {
            tracingService.Trace("Inside GetIsOnPlatformDelivery");

            bool onPlatformDelivery = false;

            if (productEnt != null && productEnt.Contains("niq_onplatformdelivery"))
            {
                onPlatformDelivery = productEnt.GetAttributeValue<bool>("niq_onplatformdelivery");
            }

            return onPlatformDelivery ? "Yes" : "No";
        }
        private string GetProductName(Entity quoteProductEnt)
        {

            if (quoteProductEnt == null || !quoteProductEnt.Attributes.Contains("quotedetailname")) return string.Empty;

            string productName = quoteProductEnt.GetAttributeValue<string>("quotedetailname");
            return productName;
        }
        //Get SalesOrg Code from PriceList Item
        private string GetSalesOrg(Entity quoteProductEnt)
        {
            try
            {
                tracingService.Trace("Inside GetSalesOrg");
                if (quoteProductEnt == null || !quoteProductEnt.Attributes.Contains("pricelevelid")) return string.Empty;
                tracingService.Trace("GetSalesOrg");
                EntityReference priceListSalesOrg = quoteProductEnt.GetAttributeValue<EntityReference>("pricelevelid");
                tracingService.Trace("priceListSalesOrg: " + priceListSalesOrg);
                string salesOrgCode = "";
                string fetchXml = $@"
                        <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                          <entity name='niq_salesorg'>
                            <attribute name='niq_salesorgcode' />
                            <order attribute='niq_name' descending='false' />
                            <link-entity name='pricelevel' from='niq_salesorg' to='niq_salesorgid' link-type='inner' alias='ak'>
                              <filter type='and'>
                                <condition attribute='pricelevelid' operator='eq' value='{priceListSalesOrg.Id}' />
                              </filter>
                            </link-entity>
                          </entity>
                        </fetch>";
                tracingService.Trace("fetchXml :" + fetchXml);
                // Execute the FetchXML query
                EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetchXml));
                tracingService.Trace("result Count :" + result.Entities.Count);
                // Check if any records are returned and process the first one
                if (result.Entities.Count > 0)
                {
                    tracingService.Trace("Inside GetProductId If");
                    // Get the first record
                    Entity record = result.Entities.Cast<Entity>().FirstOrDefault(); ;

                    // Example: Get the niq_salesorgcode attribute value from the first record
                    if (record.Contains("niq_salesorgcode"))
                    {
                        salesOrgCode = record["niq_salesorgcode"].ToString();
                        tracingService.Trace("salesOrgCode: " + salesOrgCode);
                    }
                }

                return salesOrgCode;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }

        }
        //Get ProductId from PriceListItem
        private string GetProductId(Entity quoteProductEnt)
        {
            try
            {
                tracingService.Trace("Inside GetProductId");
                if (quoteProductEnt == null || !quoteProductEnt.Attributes.Contains("productnumber")) return string.Empty;

                string productId = quoteProductEnt.GetAttributeValue<string>("productnumber");
                tracingService.Trace("productId: " + productId);
                return productId;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }

        }
        //Check Product is rev Shar or not
        private bool CheckRevShareProduct(Entity priceListEnt)
        {
            try
            {
                bool revShare = false;
                tracingService.Trace("Inside CheckRevShareProduct");
                string SalesOrg = GetSalesOrg(priceListEnt);
                string productId = GetProductId(priceListEnt);
                //if ProductID is Interco Rev Share then product is rev share
                if (productId == "INTERCO REV SHARE")
                {
                    revShare = true;
                }
                //if ProductID is contain INTRPOCREVSHR and that product hase sales org contain in enum then product is rev share
                //Concate of enumsalesorg+INTRPOCREVSHR = Productid then rev share product
                else if (productId.Contains("INTRPOCREVSHR"))
                {
                    //if (Enum.TryParse(SalesOrg, out CommonConstant.SalesOrgCode salesOrgEnum))
                    //{
                    foreach (var salesOrgEnum in Enum.GetValues(typeof(SalesOrgCode)))
                    {
                        tracingService.Trace("salesOrgEnum: " + salesOrgEnum);
                        string conCateProductId = salesOrgEnum + " INTRPOCREVSHR";
                        tracingService.Trace("productID: " + conCateProductId);
                        if (conCateProductId == productId)
                        {
                            tracingService.Trace("Inside conCateProductId If");
                            revShare = true;
                            break;
                        }
                    }
                        
                }

                return revShare;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }

        }

        private Entity GetProductEntity(Entity priceListItemTarget)
        {
            if (!priceListItemTarget.Contains("productid")) return null;

            EntityReference productEntRef = priceListItemTarget.GetAttributeValue<EntityReference>("productid");

            string fetchProductDetails = $@"
                        <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                            <entity name='product'>
                                <attribute name='niq_onplatformdelivery' />
                                <link-entity name='productpricelevel' from='productid' to='productid' link-type='inner' alias='ab'>
                                    <filter type='and'>
                                        <condition attribute='productid' operator='eq' value='{productEntRef.Id}' />
                                    </filter>
                                </link-entity>
                            </entity>
                        </fetch>";

            EntityCollection productEntCol = service.RetrieveMultiple(new FetchExpression(fetchProductDetails));
            Entity productEnt = productEntCol.Entities.FirstOrDefault();
            return productEnt;

        }

        private string GetFrequencies()
        {
            Guid configurationSettingID = new Guid("adfca5dc-bc28-ef11-840a-000d3a2f0c5a");
            Entity setting = service.Retrieve("niq_configurationsetting", configurationSettingID, new ColumnSet("niq_to"));

            return setting?.GetAttributeValue<string>("niq_to") ?? string.Empty;
        }

        private void UpdateFrequency(string productName, JObject obj, string isTimeBased, string isOnPlatformDelivery, string productType, Entity priceListItemTarget, IOrganizationService service, ITracingService tracingService)
        {
            try
            {

                string onPlatformDelivery = string.Empty;
                string type = string.Empty;
                if (productName == "Place Holder Product")
                {
                    onPlatformDelivery = "Any";
                    type = "PlaceholderProducts";
                }
                else if (productName == "SAP Deferred Revenue reconciliation placeholder")
                {
                    onPlatformDelivery = "Any";
                    type = "SAPDeferredline";
                }
                else if (isTimeBased == "Yes")
                {
                    if (productType == "Ad-hoc")
                    {
                        onPlatformDelivery = "Any";
                        type = "AdhocTimeBased";
                    }
                    else if (productType == "Periodic")
                    {
                        onPlatformDelivery = "Any";
                        type = "PeriodicTimeBased";
                    }
                }
                else
                {
                    if (productType == "Ad-hoc")
                    {
                        type = "AdhocServiceBased";
                    }
                    else if (productType == "Periodic")
                    {
                        type = "PeriodicServiceBased";
                    }

                    onPlatformDelivery = isOnPlatformDelivery;
                }
                tracingService.Trace("onPlatformDelivery:" + onPlatformDelivery);
                tracingService.Trace("type:" + type);

                if (string.IsNullOrEmpty(onPlatformDelivery) || string.IsNullOrEmpty(type)) return;
                //Check Product is rev Share product or not
                if (CheckRevShareProduct(priceListItemTarget))
                {
                    tracingService.Trace("Inside  If");
                    Entity priceListItem = new Entity("productpricelevel");
                    priceListItem["niq_updatefrequency"] = new OptionSetValue(100000009);
                    priceListItem["niq_lagrevenuerecognition"] = new OptionSetValue(100000000);
                    priceListItem["niq_revenuefrequency"] = new OptionSetValue(100000000);
                    priceListItem["niq_billingfrequency"] = new OptionSetValue(100000000);
                    //priceListItem["niq_excludefrommanualpriceentry"] = true;
                    tracingService.Trace("set all value");
                    priceListItem.Id = priceListItemTarget.Id;
                    service.Update(priceListItem);
                }
                else
                {

                    string updateFrequency = (string)obj["OnPlatformDelievry"][onPlatformDelivery][type]["UpdateFrequency"];
                    tracingService.Trace("updateFrequency:" + updateFrequency);
                    string revenueFrequency = (string)obj["OnPlatformDelievry"][onPlatformDelivery][type]["RevenueFrequency"];
                    tracingService.Trace("revenueFrequency:" + revenueFrequency);
                    string billingFrequency = (string)obj["OnPlatformDelievry"][onPlatformDelivery][type]["BillingFrequency"];
                    tracingService.Trace("revenueFrequency:" + revenueFrequency);
                    string lagRevenueRecognition = (string)obj["OnPlatformDelievry"][onPlatformDelivery][type]["LagRevenueRecognition"];
                    tracingService.Trace("lagRevenueRecognition:" + lagRevenueRecognition);

                    Entity quoteProduct = new Entity("productpricelevel");

                    if (!string.IsNullOrEmpty(updateFrequency)) quoteProduct["niq_updatefrequency"] = GetOptionSetValue(updateFrequency);
                    if (!string.IsNullOrEmpty(lagRevenueRecognition)) quoteProduct["niq_lagrevenuerecognition"] = GetOptionSetValue(lagRevenueRecognition);
                    if (!string.IsNullOrEmpty(revenueFrequency)) quoteProduct["niq_revenuefrequency"] = GetOptionSetValue(revenueFrequency);
                    if (!string.IsNullOrEmpty(billingFrequency)) quoteProduct["niq_billingfrequency"] = GetOptionSetValue(billingFrequency);

                    quoteProduct.Id = priceListItemTarget.Id;
                    service.Update(quoteProduct);
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }

        }

        private OptionSetValue GetOptionSetValue(string frequency)
        {
            return new OptionSetValue((int)EnumExtensions.GetValueFromDescription<FrequencyValues>(frequency));
        }
    }

    public static class EnumExtensions
    {
        public static string GetDescription(this Enum value)
        {
            var field = value.GetType().GetField(value.ToString());
            var attribute = Attribute.GetCustomAttribute(field, typeof(DescriptionAttribute)) as DescriptionAttribute;
            return attribute == null ? value.ToString() : attribute.Description;
        }

        public static T GetValueFromDescription<T>(string description) where T : struct, IConvertible
        {
            if (!typeof(T).IsEnum) throw new InvalidOperationException("T must be an enumerated type");

            foreach (var field in typeof(T).GetFields())
            {
                if (Attribute.GetCustomAttribute(field, typeof(DescriptionAttribute)) is DescriptionAttribute attribute)
                {
                    if (attribute.Description == description) return (T)field.GetValue(null);
                }
                else if (field.Name == description)
                {
                    return (T)field.GetValue(null);
                }
            }

            throw new ArgumentException("Not found.", nameof(description));
        }
    }
}