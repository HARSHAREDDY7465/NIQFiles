﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.Plugins
{
    public class CheckWriteAccessOnOpportunity : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                if (context.InputParameters.Contains("OpportunityIds") && !string.IsNullOrEmpty(context.InputParameters["OpportunityIds"].ToString())
                    && context.InputParameters.Contains("CurrentLoggedInUser") && !string.IsNullOrEmpty(context.InputParameters["CurrentLoggedInUser"].ToString()))
                {
                    tracing.Trace("Opportunity Ids: " + context.InputParameters["OpportunityIds"]);
                    tracing.Trace("CurrentLoggedInUser: " + context.InputParameters["CurrentLoggedInUser"]);
                    string[] OpportunityIds = context.InputParameters["OpportunityIds"].ToString().Split(',');


                    //Create an ExecuteMultipleRequest object.
                    ExecuteMultipleRequest requestWithResults = new ExecuteMultipleRequest()
                    {
                        // Assign settings that define execution behavior: continue on error, return responses. 
                        Settings = new ExecuteMultipleSettings()
                        {
                            ContinueOnError = true,
                            ReturnResponses = true
                        },
                        // Create an empty organization request collection.
                        Requests = new OrganizationRequestCollection()
                    };

                    foreach (string opportunityId in OpportunityIds)
                    {
                        var accessRequest = new RetrievePrincipalAccessRequest
                        {
                            Principal = new EntityReference("systemuser", new Guid(context.InputParameters["CurrentLoggedInUser"].ToString())),
                            Target = new EntityReference("opportunity", new Guid(opportunityId)),
                        };
                        requestWithResults.Requests.Add(accessRequest);
                    }

                    ExecuteMultipleResponse responseWithResults = (ExecuteMultipleResponse)service.Execute(requestWithResults);
                    tracing.Trace("ExecuteMultiple response count: " + responseWithResults.Responses.Count);


                    // Display the results returned in the responses.
                    for (int i = 0; i < responseWithResults.Responses.Count; i++)
                    {
                        tracing.Trace("Opportunity id : " + OpportunityIds[i]);
                        // A invalid response.
                        if (responseWithResults.Responses[i].Response == null)
                        {
                            tracing.Trace("Restricted");
                            context.OutputParameters["WriteAccess"] = "Restricted";
                            return;
                        }

                        RetrievePrincipalAccessResponse principalAccess = (RetrievePrincipalAccessResponse)responseWithResults.Responses[i].Response;
                        tracing.Trace(principalAccess.AccessRights + " -- > " + principalAccess.AccessRights.HasFlag(AccessRights.WriteAccess));
                        if (!principalAccess.AccessRights.HasFlag(AccessRights.WriteAccess))
                        {
                            tracing.Trace("Restricted");
                            context.OutputParameters["WriteAccess"] = "Restricted";
                            return;
                        }

                    }
                    context.OutputParameters["WriteAccess"] = "Granted";
                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("Exception from CheckWriteAccessOnOpportunity: \n" + ex.Message);
            }
        }
    }
}
