﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
namespace NielsenIQ.CRM.Plugins
{
    public class OnCreateUpdate_OPE_Update_Opportunity_VPE : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(null);

                if (context.MessageName == "Delete")
                {
                    if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
                    {
                        EntityReference opeObj = (EntityReference)context.InputParameters["Target"];
                        Entity retOPE = service.Retrieve(opeObj.LogicalName, opeObj.Id, new ColumnSet("niq_opportunitynameid"));
                        if (retOPE != null && retOPE.Id != Guid.Empty && retOPE.Attributes.Contains("niq_opportunitynameid") && retOPE.GetAttributeValue<EntityReference>("niq_opportunitynameid").Id != Guid.Empty)
                        {
                            tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: ret OPE oppo id." + retOPE.GetAttributeValue<EntityReference>("niq_opportunitynameid").Id);
                            decimal amount = 0;
                            Entity updOppo = new Entity(retOPE.GetAttributeValue<EntityReference>("niq_opportunitynameid").LogicalName, retOPE.GetAttributeValue<EntityReference>("niq_opportunitynameid").Id);
                            Entity retOppo = service.Retrieve(updOppo.LogicalName, updOppo.Id, new ColumnSet("niq_approvalstatus"));
                            if (retOppo != null && retOppo.Id != Guid.Empty && retOppo.Attributes.Contains("niq_approvalstatus") && retOppo.GetAttributeValue<OptionSetValue>("niq_approvalstatus").Value != 100000001)
                            {
                                tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: oppo Status " + retOppo.GetAttributeValue<OptionSetValue>("niq_approvalstatus").Value);

                                string fetchXmlOPE = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                                  <entity name='niq_opportunityproductenhancement'>
                                                    <attribute name='niq_actualamountincreaseannualvalue' />
                                                    <attribute name='niq_opportunityproductenhancementid' />
                                                    <order attribute='niq_actualamountincreaseannualvalue' descending='true' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='niq_opportunityproductenhancementid' operator= 'ne' value='{1}' />
                                                         </filter>
                                                    <link-entity name='opportunity' from='opportunityid' to='niq_opportunitynameid' link-type='inner' alias='aa'>
                                                      <filter type='and'>
                                                        <condition attribute='statecode' operator='eq' value='0' />
                                                        <condition attribute='niq_approvalstatus' operator='ne' value='100000001' />
                                                        <condition attribute='opportunityid' operator='eq' uitype='opportunity' value='{0}' />
                                                      </filter>
                                                    </link-entity>
                                                  </entity>
                                                </fetch>";
                                fetchXmlOPE = string.Format(fetchXmlOPE, retOPE.GetAttributeValue<EntityReference>("niq_opportunitynameid").Id, opeObj.Id);
                                var result = service.RetrieveMultiple(new FetchExpression(fetchXmlOPE));
                                if (result != null && result.Entities != null && result.Entities.Count > 0)
                                {
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: result entity count." + result.Entities.Count);
                                    foreach (Entity opeRecord in result.Entities)
                                    {
                                        if (opeRecord.Attributes.Contains("niq_actualamountincreaseannualvalue"))
                                        {
                                            amount += opeRecord.GetAttributeValue<Money>("niq_actualamountincreaseannualvalue").Value;
                                        }
                                    }
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: total amount" + amount);
                                    updOppo["niq_valueofproductenhancements"] = new Money(amount);
                                    service.Update(updOppo);
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: Updated success");
                                }
                                else
                                {
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: total amount" + amount);
                                    updOppo["niq_valueofproductenhancements"] = new Money(amount);
                                    service.Update(updOppo);
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: Updated success");
                                }
                            }

                            else if (retOppo != null && retOppo.Id != Guid.Empty && !retOppo.Attributes.Contains("niq_approvalstatus"))
                            {
                                tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: oppo Status is null ");

                                string fetchXmlOPE = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                                  <entity name='niq_opportunityproductenhancement'>
                                                    <attribute name='niq_actualamountincreaseannualvalue' />
                                                    <attribute name='niq_opportunityproductenhancementid' />
                                                    <order attribute='niq_actualamountincreaseannualvalue' descending='true' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='niq_opportunityproductenhancementid' operator= 'ne' value='{1}' />
                                                    </filter>
                                                    <link-entity name='opportunity' from='opportunityid' to='niq_opportunitynameid' link-type='inner' alias='aa'>
                                                      <filter type='and'>
                                                        <condition attribute='statecode' operator='eq' value='0' />
                                                        <condition attribute='niq_approvalstatus' operator='ne' value='100000001' />
                                                        <condition attribute='opportunityid' operator='eq' uitype='opportunity' value='{0}' />
                                                      </filter>
                                                    </link-entity>
                                                  </entity>
                                                </fetch>";
                                fetchXmlOPE = string.Format(fetchXmlOPE, retOPE.GetAttributeValue<EntityReference>("niq_opportunitynameid").Id, opeObj.Id);
                                var result = service.RetrieveMultiple(new FetchExpression(fetchXmlOPE));
                                if (result != null && result.Entities != null && result.Entities.Count > 0)
                                {
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: result entity count." + result.Entities.Count);
                                    foreach (Entity opeRecord in result.Entities)
                                    {
                                        if (opeRecord.Attributes.Contains("niq_actualamountincreaseannualvalue"))
                                        {
                                            amount += opeRecord.GetAttributeValue<Money>("niq_actualamountincreaseannualvalue").Value;
                                        }
                                    }
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: total amount" + amount);
                                    updOppo["niq_valueofproductenhancements"] = new Money(amount);
                                    service.Update(updOppo);
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: Updated success");
                                }
                                else
                                {
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: total amount" + amount);
                                    updOppo["niq_valueofproductenhancements"] = new Money(amount);
                                    service.Update(updOppo);
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: Updated success");
                                }
                            }

                        }
                    }
                }

                else if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity entity = (Entity)context.InputParameters["Target"];
                    if (entity != null && entity.LogicalName == "niq_opportunityproductenhancement" && entity.Id != Guid.Empty)
                    {
                        tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: OPE ID " + entity.Id);
                        Entity retOPE = service.Retrieve(entity.LogicalName, entity.Id, new ColumnSet("niq_opportunitynameid"));
                        if (retOPE != null && retOPE.Id != Guid.Empty && retOPE.Attributes.Contains("niq_opportunitynameid") && retOPE.GetAttributeValue<EntityReference>("niq_opportunitynameid").Id != Guid.Empty)
                        {
                            tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: ret OPE oppo id." + retOPE.GetAttributeValue<EntityReference>("niq_opportunitynameid").Id);
                            decimal amount = 0;
                            Entity updOppo = new Entity(retOPE.GetAttributeValue<EntityReference>("niq_opportunitynameid").LogicalName, retOPE.GetAttributeValue<EntityReference>("niq_opportunitynameid").Id);
                            Entity retOppo = service.Retrieve(updOppo.LogicalName, updOppo.Id, new ColumnSet("niq_approvalstatus"));
                            if (retOppo != null && retOppo.Id != Guid.Empty && retOppo.Attributes.Contains("niq_approvalstatus") && retOppo.GetAttributeValue<OptionSetValue>("niq_approvalstatus").Value != 100000001)
                            {
                                tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: oppo Status " + retOppo.GetAttributeValue<OptionSetValue>("niq_approvalstatus").Value);

                                string fetchXmlOPE = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                                  <entity name='niq_opportunityproductenhancement'>
                                                    <attribute name='niq_actualamountincreaseannualvalue' />
                                                    <attribute name='niq_opportunityproductenhancementid' />
                                                    <order attribute='niq_actualamountincreaseannualvalue' descending='true' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                    </filter>
                                                    <link-entity name='opportunity' from='opportunityid' to='niq_opportunitynameid' link-type='inner' alias='aa'>
                                                      <filter type='and'>
                                                        <condition attribute='statecode' operator='eq' value='0' />
                                                        <condition attribute='niq_approvalstatus' operator='ne' value='100000001' />
                                                        <condition attribute='opportunityid' operator='eq' uitype='opportunity' value='{0}' />
                                                      </filter>
                                                    </link-entity>
                                                  </entity>
                                                </fetch>";
                                fetchXmlOPE = string.Format(fetchXmlOPE, retOPE.GetAttributeValue<EntityReference>("niq_opportunitynameid").Id);
                                var result = service.RetrieveMultiple(new FetchExpression(fetchXmlOPE));
                                if (result != null && result.Entities != null && result.Entities.Count > 0)
                                {
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: result entity count." + result.Entities.Count);
                                    foreach (Entity opeRecord in result.Entities)
                                    {
                                        if (opeRecord.Attributes.Contains("niq_actualamountincreaseannualvalue"))
                                        {
                                            amount += opeRecord.GetAttributeValue<Money>("niq_actualamountincreaseannualvalue").Value;
                                        }
                                    }
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: total amount" + amount);
                                    updOppo["niq_valueofproductenhancements"] = new Money(amount);
                                    service.Update(updOppo);
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: Updated success");
                                }
                                else
                                {
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: total amount" + amount);
                                    updOppo["niq_valueofproductenhancements"] = new Money(amount);
                                    service.Update(updOppo);
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: Updated success");
                                }
                            }

                            else if (retOppo != null && retOppo.Id != Guid.Empty && !retOppo.Attributes.Contains("niq_approvalstatus"))
                            {
                                tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: oppo Status is null ");

                                string fetchXmlOPE = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                                  <entity name='niq_opportunityproductenhancement'>
                                                    <attribute name='niq_actualamountincreaseannualvalue' />
                                                    <attribute name='niq_opportunityproductenhancementid' />
                                                    <order attribute='niq_actualamountincreaseannualvalue' descending='true' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                    </filter>
                                                    <link-entity name='opportunity' from='opportunityid' to='niq_opportunitynameid' link-type='inner' alias='aa'>
                                                      <filter type='and'>
                                                        <condition attribute='statecode' operator='eq' value='0' />
                                                        <condition attribute='niq_approvalstatus' operator='ne' value='100000001' />
                                                        <condition attribute='opportunityid' operator='eq' uitype='opportunity' value='{0}' />
                                                      </filter>
                                                    </link-entity>
                                                  </entity>
                                                </fetch>";
                                fetchXmlOPE = string.Format(fetchXmlOPE, retOPE.GetAttributeValue<EntityReference>("niq_opportunitynameid").Id);
                                var result = service.RetrieveMultiple(new FetchExpression(fetchXmlOPE));
                                if (result != null && result.Entities != null && result.Entities.Count > 0)
                                {
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: result entity count." + result.Entities.Count);
                                    foreach (Entity opeRecord in result.Entities)
                                    {
                                        if (opeRecord.Attributes.Contains("niq_actualamountincreaseannualvalue"))
                                        {
                                            amount += opeRecord.GetAttributeValue<Money>("niq_actualamountincreaseannualvalue").Value;
                                        }
                                    }
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: total amount" + amount);
                                    updOppo["niq_valueofproductenhancements"] = new Money(amount);
                                    service.Update(updOppo);
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: Updated success");
                                }
                                else
                                {
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: total amount" + amount);
                                    updOppo["niq_valueofproductenhancements"] = new Money(amount);
                                    service.Update(updOppo);
                                    tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: Updated success");
                                }
                            }

                        }
                    }

                    if (context.MessageName == "Update" && entity != null && entity.LogicalName == "opportunity" && entity.Id != Guid.Empty && entity.Attributes.Contains("niq_approvalstatus") && entity.GetAttributeValue<OptionSetValue>("niq_approvalstatus") != null && 
                        (entity.GetAttributeValue<OptionSetValue>("niq_approvalstatus").Value == 100000004 || entity.GetAttributeValue<OptionSetValue>("niq_approvalstatus").Value == 100000003 || 
                        entity.GetAttributeValue<OptionSetValue>("niq_approvalstatus").Value == 100000005 || entity.GetAttributeValue<OptionSetValue>("niq_approvalstatus").Value == 100000006))
                    {

                        tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE:  oppo id." + entity.Id);
                        decimal amount = 0;
                        Entity updOppo = new Entity(entity.LogicalName, entity.Id);

                        string fetchXmlOPE = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                                  <entity name='niq_opportunityproductenhancement'>
                                                    <attribute name='niq_actualamountincreaseannualvalue' />
                                                    <attribute name='niq_opportunityproductenhancementid' />
                                                    <order attribute='niq_actualamountincreaseannualvalue' descending='true' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                    </filter>
                                                    <link-entity name='opportunity' from='opportunityid' to='niq_opportunitynameid' link-type='inner' alias='aa'>
                                                      <filter type='and'>
                                                        <condition attribute='statecode' operator='eq' value='0' />
                                                        <condition attribute='niq_approvalstatus' operator='ne' value='100000001' />
                                                        <condition attribute='opportunityid' operator='eq' uitype='opportunity' value='{0}' />
                                                      </filter>
                                                    </link-entity>
                                                  </entity>
                                                </fetch>";
                        fetchXmlOPE = string.Format(fetchXmlOPE, entity.Id);
                        var result = service.RetrieveMultiple(new FetchExpression(fetchXmlOPE));
                        if (result != null && result.Entities != null && result.Entities.Count > 0)
                        {
                            tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: result entity count." + result.Entities.Count);
                            foreach (Entity opeRecord in result.Entities)
                            {
                                if (opeRecord.Attributes.Contains("niq_actualamountincreaseannualvalue"))
                                {
                                    amount += opeRecord.GetAttributeValue<Money>("niq_actualamountincreaseannualvalue").Value;
                                }
                            }
                            tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: total amount" + amount);
                            updOppo["niq_valueofproductenhancements"] = new Money(amount);
                            service.Update(updOppo);
                            tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: Updated success");
                        }
                        else
                        {
                            tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: total amount" + amount);
                            updOppo["niq_valueofproductenhancements"] = new Money(amount);
                            service.Update(updOppo);
                            tracing.Trace("OnUpdate_OPE_Update_Opportunity_VPE: Updated success");
                        }

                    }
                }

            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
