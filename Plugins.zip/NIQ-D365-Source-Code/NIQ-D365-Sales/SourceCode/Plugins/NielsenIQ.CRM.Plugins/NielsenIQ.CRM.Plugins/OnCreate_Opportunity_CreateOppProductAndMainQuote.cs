﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.Plugins
{
    public class OnCreate_Opportunity_CreateOppProductAndMainQuote : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));                
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                if (context.MessageName.ToLower() == "create")
                {
                    Entity opportunity = (Entity)context.InputParameters["Target"];
                    EntityReference currencyref = new EntityReference();
                    if (opportunity.Attributes.Contains("transactioncurrencyid") && opportunity.GetAttributeValue<EntityReference>("transactioncurrencyid").Id != Guid.Empty)
                    {
                        currencyref = opportunity.GetAttributeValue<EntityReference>("transactioncurrencyid");
                    }
                   if (!opportunity.Attributes.Contains("niq_originalopportunityid"))
                    {                        
                        Entity opportunityProducts = new Entity("opportunityproduct");
                        opportunityProducts["productdescription"] = "Dummy Product For Total Amount Set";
                        opportunityProducts["opportunityproductname"] = "Dummy Product For Total Amount Set";
                        opportunityProducts["ispriceoverridden"] = true;
                        opportunityProducts["isproductoverridden"] = true;
                        opportunityProducts["quantity"] = (decimal)1.00000;                        
                        opportunityProducts["priceperunit"] = new Money(0);
                        opportunityProducts["opportunityid"] = new EntityReference("opportunity",opportunity.Id);                        
                        opportunityProducts["transactioncurrencyid"] = currencyref;                                            
                        service.Create(opportunityProducts);                      
                        
                    }

                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}