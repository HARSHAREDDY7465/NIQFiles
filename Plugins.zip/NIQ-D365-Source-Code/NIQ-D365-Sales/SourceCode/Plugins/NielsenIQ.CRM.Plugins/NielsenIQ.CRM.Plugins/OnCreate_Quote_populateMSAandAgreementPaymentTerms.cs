﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace NielsenIQ.CRM.Plugins
{
    public class OnCreate_Quote_populateMSAandAgreementPaymentTerms : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity targetEntity = (Entity)context.InputParameters["Target"];
                    //DYNCRM_30832- Because While cloning Host Opportunity is not populated while creation, it is updated after creation.
                    if (targetEntity.LogicalName == "opportunity")
                    {
                        tracing.Trace("Plugin triggered by Opportunity Update");
                        if (!targetEntity.Contains("niq_hostopportunity"))
                        {
                            tracing.Trace("niq_hostopportunity not in target. Exiting plugin.");
                            return;
                        }

                        Guid opportunityId = targetEntity.Id;
                        tracing.Trace($"OnCreate_Quote_populateMSAandAgreementPaymentTerms: Processing Opportunity Update - {opportunityId}");

                        Entity Opty = service.Retrieve("opportunity", opportunityId, new ColumnSet("niq_hostopportunity", "niq_revenuesharedeal"));
                        EntityReference hostOptyRef = Opty.GetAttributeValue<EntityReference>("niq_hostopportunity");
                        Entity hostOpty = null;
                        bool IsRevshare = false;

                        if (hostOptyRef != null)
                        {
                            hostOpty = service.Retrieve("opportunity", hostOptyRef.Id, new ColumnSet("niq_revenuesharedeal"));
                            if (hostOpty != null && hostOpty.Contains("niq_revenuesharedeal"))
                            {
                                bool revShareValue = hostOpty.GetAttributeValue<bool>("niq_revenuesharedeal");
                                tracing.Trace($"OnCreate_Quote_populateMSAandAgreementPaymentTerms: Host Opportunity Revenue Share Deal - {revShareValue}");
                                if (revShareValue == true)
                                {
                                    IsRevshare = true;
                                    tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: REVENUE SHARE DEAL  Will apply NM01");
                                }
                            }
                        }

                        QueryExpression quoteQuery = new QueryExpression("quote");
                        quoteQuery.ColumnSet.AddColumn("quoteid");
                        quoteQuery.Criteria.AddCondition("opportunityid", ConditionOperator.Equal, opportunityId);
                        quoteQuery.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0); // Active quotes only
                        EntityCollection quotes = service.RetrieveMultiple(quoteQuery);

                        if (quotes.Entities.Count == 0)
                        {
                            tracing.Trace("No active quote found for this opportunity. Exiting plugin.");
                            return;
                        }

                        tracing.Trace($"Found {quotes.Entities.Count} active quote(s) to update");

                        if (IsRevshare)
                        {
                            tracing.Trace("child opportunity with rev share == yes");
                            QueryExpression paymenttermQuery = new QueryExpression("niq_paymentterm");
                            paymenttermQuery.ColumnSet = new ColumnSet("niq_paymenttermcode", "niq_paymenttermname");
                            paymenttermQuery.Criteria.AddCondition("niq_paymenttermcode", ConditionOperator.Equal, "NM01");
                            paymenttermQuery.NoLock = true;
                            EntityCollection paymenttermRecords = service.RetrieveMultiple(paymenttermQuery);

                            if (paymenttermRecords.Entities.Count > 0)
                            {
                                Entity paymentTermRecord = paymenttermRecords.Entities.FirstOrDefault();
                                tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: fetch payment terms records");

                                foreach (Entity quote in quotes.Entities)
                                {
                                    Entity updQuoteRecord = new Entity("quote", quote.Id);
                                    updQuoteRecord["niq_paymenttermsid"] = new EntityReference(paymentTermRecord.LogicalName, paymentTermRecord.Id);

                                    if (paymentTermRecord.Contains("niq_paymenttermname"))
                                    {
                                        updQuoteRecord["niq_paymenttermdescription"] = paymentTermRecord["niq_paymenttermname"];
                                    }

                                    service.Update(updQuoteRecord);
                                    tracing.Trace($"OnCreate_Quote_populateMSAandAgreementPaymentTerms: NM01 applied to Quote {quote.Id} due to child opportunity with revenue share deal.");
                                }
                            }
                        }
                        else
                        {
                            tracing.Trace("IsRevshare is false. No quote updates needed.");
                        }

                        return; 
                    }

                    Entity quoteRecord = targetEntity;

                    if (quoteRecord != null && quoteRecord.Id != Guid.Empty)
                    {
                        if (quoteRecord.Attributes.Contains("opportunityid"))
                        {
                            tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: entering the block");

                            //get opty record with fields opty type, contract decision, original opty, account(with ultimateparent field), salesorg
                            var query = new QueryExpression("opportunity");
                            query.ColumnSet.AddColumns("niq_contractdecision", "opportunityid", "niq_originalopportunityid", "niq_salesorgid", "parentaccountid", "niq_opportunitytype", "niq_hostopportunity", "niq_revenuesharedeal", "niq_existingcontractaction", "niq_amendedfromopportunity");
                            query.Criteria.AddCondition("opportunityid", ConditionOperator.Equal, quoteRecord.GetAttributeValue<EntityReference>("opportunityid").Id);
                            var acc = query.AddLink("account", "parentaccountid", "accountid", JoinOperator.Inner);
                            acc.EntityAlias = "acc";
                            acc.Columns.AddColumn("niq_ultimateparentid");
                            Entity Opty = service.RetrieveMultiple(query).Entities.FirstOrDefault();
                            tracing.Trace($"OnCreate_Quote_populateMSAandAgreementPaymentTerms: Opportunity ID - {Opty.Id}");
                            tracing.Trace($"OnCreate_Quote_populateMSAandAgreementPaymentTerms: Has Host Opportunity - {Opty.Contains("niq_hostopportunity")}");

                            EntityReference hostOptyRef = Opty.GetAttributeValue<EntityReference>("niq_hostopportunity"); //
                            Entity hostOpty = null;

                            bool IsRevshare = false;
                            bool skipPaymentTermsUpdate = false;
                            //As part of 30324 we are copying Quoteheader details from originating opp for Amendment and renewal
                            if (Opty.Contains("niq_existingcontractaction") && Opty.Contains("niq_amendedfromopportunity"))
                            {
                                int existingContractAction = Opty.GetAttributeValue<OptionSetValue>("niq_existingcontractaction").Value;
                                EntityReference amendedFrom = Opty.GetAttributeValue<EntityReference>("niq_amendedfromopportunity");

                                if ((existingContractAction == 1 || existingContractAction == 4) && amendedFrom != null)
                                {
                                    skipPaymentTermsUpdate = true;
                                    tracing.Trace($"OnCreate_Quote_populateMSAandAgreementPaymentTerms: Skipping niq_paymenttermsid update - ExistingContractAction: {existingContractAction}, AmendedFrom: {amendedFrom.Id}");
                                }
                            }

                            if (hostOptyRef != null)
                            {
                                hostOpty = service.Retrieve("opportunity", hostOptyRef.Id, new ColumnSet("niq_revenuesharedeal")); //
                                if (hostOpty != null && hostOpty.Contains("niq_revenuesharedeal"))
                                {
                                    bool revShareValue = hostOpty.GetAttributeValue<bool>("niq_revenuesharedeal");
                                    tracing.Trace($"OnCreate_Quote_populateMSAandAgreementPaymentTerms: Host Opportunity Revenue Share Deal - {revShareValue}");
                                    if (revShareValue == true)
                                    {
                                        IsRevshare = true;
                                        tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: REVENUE SHARE DEAL  Will apply NM01");
                                    }
                                }
                            }

                            //opportunity type, contract decision, ultimate account and sales org variables taken:
                            int OptyType = Opty.GetAttributeValue<OptionSetValue>("niq_opportunitytype").Value;
                            int ContractDecision = Opty.Contains("niq_contractdecision") ? Opty.GetAttributeValue<OptionSetValue>("niq_contractdecision").Value : 0;
                            var ultAccount = (Opty.Contains("acc.niq_ultimateparentid") && Opty.GetAttributeValue<AliasedValue>("acc.niq_ultimateparentid").Value != null) ? ((EntityReference)((AliasedValue)Opty["acc.niq_ultimateparentid"]).Value).Id : ((EntityReference)Opty["parentaccountid"]).Id;
                            var salesOrg = ((EntityReference)Opty["niq_salesorgid"]).Id;
                            bool update = false;
                            tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: opty,account,ultimate parent account,salesorg retrieved");
                            Entity updQuoteRecord = new Entity(quoteRecord.LogicalName, quoteRecord.Id);

                            //check if there is MSA Payment term record associated with Ultaccount and Salesorg
                            QueryExpression MSAQuery = new QueryExpression("niq_msapaymentterm");
                            MSAQuery.ColumnSet.AddColumns("niq_paymenttermsmsaid");
                            FilterExpression filter = MSAQuery.Criteria.AddFilter(LogicalOperator.And);
                            filter.AddCondition("niq_ultimateparentaccountid", ConditionOperator.Equal, ultAccount);
                            filter.AddCondition("niq_salesorgid", ConditionOperator.Equal, salesOrg);
                            var paymentterm = MSAQuery.AddLink("niq_paymentterm", "niq_paymenttermsmsaid", "niq_paymenttermid", JoinOperator.Inner);
                            paymentterm.EntityAlias = "pt";
                            paymentterm.Columns.AddColumns("niq_paymenttermname", "niq_paymenttermsindays", "niq_paymenttermcode");
                            EntityCollection MSApaymenttermRecords = service.RetrieveMultiple(MSAQuery);

                            if (MSApaymenttermRecords.Entities.Count > 0 && MSApaymenttermRecords.Entities.Count <= 1)
                            {
                                tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: MSA contains a record");
                                Entity MSARecord = MSApaymenttermRecords.Entities.FirstOrDefault();
                                tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: payment terms related to MSA - " + MSARecord.GetAttributeValue<AliasedValue>("pt.niq_paymenttermcode").Value);
                                if (OptyType == 1 || (OptyType == 2 /*&& ContractDecision == 100000002*/ && Opty.Contains("niq_originalopportunityid")))
                                {
                                    //As part of DYNCRM31243 commented this condition ContractDecision == 100000002
                                    //update MSA fields on quote if Opty is either new sale or amendment opty
                                    updQuoteRecord["niq_msapaymentterm"] = new EntityReference("niq_paymentterm", ((EntityReference)MSARecord["niq_paymenttermsmsaid"]).Id);
                                    if (MSARecord.Contains("pt.niq_paymenttermname"))
                                    {
                                        updQuoteRecord["niq_msapaymenttermdescription"] = MSARecord.GetAttributeValue<AliasedValue>("pt.niq_paymenttermname").Value;
                                    }
                                    if (MSARecord.Contains("pt.niq_paymenttermsindays"))
                                    {
                                        updQuoteRecord["niq_msapaymenttermdays"] = MSARecord.GetAttributeValue<AliasedValue>("pt.niq_paymenttermsindays").Value;
                                    }
                                    update = true;
                                    tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: Quote's MSA fields updated");
                                }

                                //DYNCRM-28252 - T&D
                                if (IsRevshare)
                                {
                                    tracing.Trace("child opportunity with rev share == yes");

                                    if (!skipPaymentTermsUpdate)
                                    {
                                        QueryExpression paymenttermQuery = new QueryExpression("niq_paymentterm");
                                        paymenttermQuery.ColumnSet = new ColumnSet("niq_paymenttermcode", "niq_paymenttermname");
                                        paymenttermQuery.Criteria.AddCondition("niq_paymenttermcode", ConditionOperator.Equal, "NM01");
                                        paymenttermQuery.NoLock = true;

                                        EntityCollection paymenttermRecords = service.RetrieveMultiple(paymenttermQuery);
                                        foreach (Entity record in paymenttermRecords.Entities)
                                        {
                                            tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: fetch payment terms records");
                                            updQuoteRecord["niq_paymenttermsid"] = new EntityReference(record.LogicalName, record.Id);
                                            if (record.Contains("niq_paymenttermname"))
                                            {
                                                updQuoteRecord["niq_paymenttermdescription"] = record["niq_paymenttermname"];
                                            }
                                            update = true;
                                            tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: NM01 applied due to child opportunity with revenue share deal.");
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: Skipped niq_paymenttermsid update due to existing contract action condition.");
                                    }
                                }
                                else
                                {
                                    //for Agreement terms, check if opty is New sale
                                    if (OptyType == 1)
                                    {
                                        if (!skipPaymentTermsUpdate)
                                        {
                                            updQuoteRecord["niq_paymenttermsid"] = new EntityReference("niq_paymentterm", ((EntityReference)MSARecord["niq_paymenttermsmsaid"]).Id);
                                            if (MSARecord.Contains("pt.niq_paymenttermname"))
                                            {
                                                updQuoteRecord["niq_paymenttermdescription"] = MSARecord.GetAttributeValue<AliasedValue>("pt.niq_paymenttermname").Value;
                                            }
                                            update = true;
                                            tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: agreement terms updated for New sale opty");
                                        }
                                        else
                                        {
                                            tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: Skipped niq_paymenttermsid update for New sale due to existing contract action condition.");
                                        }
                                    }
                                    //if not new sale, check if it is amendment opty and original opty contains data
                                    else if (OptyType == 2 && ContractDecision == 100000002 && Opty.Contains("niq_originalopportunityid"))
                                    {
                                        if (!skipPaymentTermsUpdate)
                                        {
                                            //get agreement payment terms from original opportunity's quote
                                            QueryExpression originalOpty = new QueryExpression("opportunity");
                                            originalOpty.ColumnSet.AddColumn("opportunityid");
                                            originalOpty.Criteria.AddCondition("opportunityid", ConditionOperator.Equal, ((EntityReference)Opty["niq_originalopportunityid"]).Id);
                                            var orgquote = originalOpty.AddLink("quote", "niq_mainquoteid", "quoteid", JoinOperator.Inner);
                                            orgquote.EntityAlias = "orgquote";
                                            orgquote.Columns.AddColumn("niq_paymenttermsid");
                                            var quotept = orgquote.AddLink("niq_paymentterm", "niq_paymenttermsid", "niq_paymenttermid", JoinOperator.Inner);
                                            quotept.EntityAlias = "qpt";
                                            quotept.Columns.AddColumn("niq_paymenttermname");
                                            Entity originalOppo = service.RetrieveMultiple(originalOpty).Entities.FirstOrDefault();
                                            //update quote's Agreement PT from Original Opty's Quote
                                            updQuoteRecord["niq_paymenttermsid"] = new EntityReference("niq_paymentterm", ((EntityReference)((AliasedValue)originalOppo["orgquote.niq_paymenttermsid"]).Value).Id);

                                            if (originalOppo.Contains("qpt.niq_paymenttermname"))
                                            {
                                                updQuoteRecord["niq_paymenttermdescription"] = originalOppo.GetAttributeValue<AliasedValue>("qpt.niq_paymenttermname").Value;
                                            }
                                            update = true;
                                            tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: agreement payment terms updated for amendment opty, Payment terms taken from Original Opty's quote");
                                        }
                                        else
                                        {
                                            tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: Skipped niq_paymenttermsid update for amendment due to existing contract action condition.");
                                        }
                                    }

                                }
                            }
                            else
                            {
                                //if there is no MSA payment data then update Agreement payment terms= NM01
                                if (!skipPaymentTermsUpdate)
                                {
                                    QueryExpression paymenttermQuery = new QueryExpression("niq_paymentterm");
                                    paymenttermQuery.ColumnSet = new ColumnSet("niq_paymenttermcode", "niq_paymenttermname");
                                    paymenttermQuery.Criteria.AddCondition("niq_paymenttermcode", ConditionOperator.Equal, "NM01");
                                    paymenttermQuery.NoLock = true;
                                    EntityCollection paymenttermRecords = service.RetrieveMultiple(paymenttermQuery);
                                    foreach (Entity record in paymenttermRecords.Entities)
                                    {
                                        updQuoteRecord["niq_paymenttermsid"] = new EntityReference(record.LogicalName, record.Id);
                                        if (record.Contains("niq_paymenttermname"))
                                        {
                                            updQuoteRecord["niq_paymenttermdescription"] = record["niq_paymenttermname"];
                                        }
                                        update = true;
                                        tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: as No MSA records exist, agreement Payment terms updated with NM01");
                                        break;
                                    }
                                }
                                else
                                {
                                    tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: Skipped niq_paymenttermsid update (No MSA) due to existing contract action condition.");
                                }
                            }
                            if (update)
                            {
                                //with all the updates being done, finally update the quote action
                                service.Update(updQuoteRecord);
                                tracing.Trace("OnCreate_Quote_populateMSAandAgreementPaymentTerms: Quote updated successfully");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}