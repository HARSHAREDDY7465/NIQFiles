﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using NielsenIQ.CRM.Plugins.Helper;
using Microsoft.Xrm.Sdk.Client;
using System.Collections;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_ExperlogicFlag_AutopopulateData : IPlugin
    {

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(null);
                //5281 Fix
                if (context.Depth > 1)
                {
                    tracing.Trace("Depth checking >1");
                    return;
                }
                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains(CommonConstant.TARGET) && context.InputParameters[CommonConstant.TARGET] is Entity)
                {
                    tracing.Trace("Inside Autopopulate");
                    Entity entityObj = (Entity)context.InputParameters[CommonConstant.TARGET];
                    Entity PostImageObj = context.PostEntityImages[CommonConstant.POSTIMAGE] as Entity;
                    //5281 Fix
                    Entity PreImageObj = context.PreEntityImages[CommonConstant.PREIMAGE] as Entity;

                    tracing.Trace("Quote ID: " + entityObj.Id);
                    tracing.Trace("preImage contains attri: niq_expvalidation : " + PreImageObj.Attributes.Contains("niq_expvalidation"));
                    if (PreImageObj.Attributes.Contains("niq_expvalidation") && PreImageObj.GetAttributeValue<bool>("niq_expvalidation") == true)
                    {
                        tracing.Trace("PreImageObj.GetAttributeValue<bool>('niq_expvalidation') : " + PreImageObj.GetAttributeValue<bool>("niq_expvalidation"));
                        tracing.Trace("Returning");
                        return;
                    }

                    tracing.Trace("before second if - Exp validation begins");
                    tracing.Trace("Entity object (contains): " + entityObj.Contains("niq_expvalidation"));
                    tracing.Trace("checkup [is it null ??]: " + (entityObj["niq_expvalidation"] == null));
                    //21459 - Allow "null" condition
                    if (entityObj.Contains("niq_expvalidation") && ((entityObj["niq_expvalidation"] != null && (bool)entityObj["niq_expvalidation"]) || entityObj["niq_expvalidation"] == null))
                    {
                        //Commented for DYNCRM-4770 ----- Begin
                        ////// Defect DYNCRM-2394 Fix getting all the quote products to Update Ismodified 
                        ////QueryExpression query = new QueryExpression("quotedetail");
                        ////query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, entityObj.Id);
                        ////EntityCollection results = service.RetrieveMultiple(query);
                        ////tracing.Trace("count of all quote products" + results.Entities.Count);
                        ////foreach (Entity rec in results.Entities)
                        ////{
                        ////    Entity updateQP1 = new Entity(rec.LogicalName, rec.Id);
                        ////    if (!rec.Contains("niq_ismodified"))// || (rec["niq_ismodified"].ToString().ToLower() != "inprogress" && rec["niq_ismodified"].ToString().ToLower() != "inprogresss"))
                        ////    {
                        ////        updateQP1["niq_ismodified"] = "InProgress";
                        ////        tracing.Trace("if true making is modified inprogress");
                        ////    }
                        ////    else
                        ////    {
                        ////        tracing.Trace("else check rec.contains niqismodified");
                        ////        string isModified = null;
                        ////        //Entity updQuoteProd = new Entity(rec.LogicalName, rec.Id);
                        ////        isModified = rec.GetAttributeValue<string>("niq_ismodified") != null ? rec.GetAttributeValue<string>("niq_ismodified") : null;
                        ////        tracing.Trace("OnUpdate_QuoteProducts_TriggerScheduleFlow: is Modified->" + isModified);
                        ////        switch (isModified)
                        ////        {
                        ////            case null:
                        ////                updateQP1["niq_ismodified"] = "InProgress";
                        ////                updateQP1["niq_isqpscompleted"] = false;
                        ////                tracing.Trace("ismodified -> Inprogress");
                        ////                //service.Update(updateQP);
                        ////                break;
                        ////            case "InProgress":
                        ////                updateQP1["niq_ismodified"] = "InProgresss";
                        ////                updateQP1["niq_isqpscompleted"] = false;
                        ////                tracing.Trace("ismodified -> InProgress");
                        ////                //service.Update(updQuoteProd);
                        ////                break;
                        ////            case "Completed":
                        ////                updateQP1["niq_ismodified"] = "InProgress";
                        ////                updateQP1["niq_isqpscompleted"] = false;
                        ////                tracing.Trace("ismodified -> InProgress");
                        ////                // service.Update(updQuoteProd);
                        ////                break;
                        ////            default:
                        ////                updateQP1["niq_isqpscompleted"] = false;
                        ////                // service.Update(updQuoteProd);
                        ////                break;
                        ////        }
                        ////    }
                        ////    service.Update(updateQP1);
                        ////}
                        //Commented for DYNCRM-4770 ----- End

                        tracing.Trace("Quote ID: " + entityObj.Id);
                        QueryByAttribute queryPL = new QueryByAttribute("pricelevel");
                        queryPL.Attributes.AddRange("niq_salesorg");
                        queryPL.Values.AddRange(((EntityReference)PostImageObj["niq_salesorgid"]).Id);
                        queryPL.ColumnSet = new ColumnSet("pricelevelid");
                        Entity priceLevel = service.RetrieveMultiple(queryPL).Entities.FirstOrDefault();
                        FilterExpression filterQL = new FilterExpression();
                        filterQL.AddCondition("quoteid", ConditionOperator.Equal, entityObj.Id);
                        filterQL.FilterOperator = LogicalOperator.And;
                        FilterExpression filterQP = new FilterExpression();
                        filterQP.AddCondition("niq_ismodified", ConditionOperator.NotIn, new object[] { "InProgress", "InProgresss" });
                        filterQP.AddCondition("niq_glaccountid", ConditionOperator.Null);
                        filterQP.AddCondition("niq_profitcentreid", ConditionOperator.Null);
                        filterQP.FilterOperator = LogicalOperator.Or;
                        filterQL.Filters.Add(filterQP);
                        LinkEntity linkProduct = new LinkEntity();
                        linkProduct.LinkFromEntityName = "quotedetail";
                        linkProduct.LinkFromAttributeName = "productid";
                        linkProduct.LinkToEntityName = "product";
                        linkProduct.LinkToAttributeName = "productid";
                        linkProduct.EntityAlias = "p";
                        LinkEntity linkPricelist = new LinkEntity();
                        linkPricelist.LinkFromEntityName = "product";
                        linkPricelist.LinkFromAttributeName = "productid";
                        linkPricelist.LinkToEntityName = "productpricelevel";
                        linkPricelist.LinkToAttributeName = "productid";
                        linkPricelist.Columns = new ColumnSet("niq_profitcentrecode", "niq_glaccountnumber");
                        linkPricelist.EntityAlias = "pl";
                        linkPricelist.LinkCriteria.AddCondition("pricelevelid", ConditionOperator.Equal, priceLevel.Id);
                        linkProduct.LinkEntities.Add(linkPricelist);
                        LinkEntity relatedEntity = new LinkEntity();
                        relatedEntity.LinkEntities.Add(linkProduct);
                        EntityCollection quoteProducts = CommonHelper.ReturnQueryResult("quotedetail", new ColumnSet("quotedetailid", "productid", "niq_glaccountid", "niq_salesorgcodeid",
                            "niq_profitcentreid", "niq_ismodified"), filterQL, linkProduct, tracing, service);
                        Entity relatedOpportunity = service.Retrieve("opportunity", ((EntityReference)PostImageObj["opportunityid"]).Id, new ColumnSet("niq_salesorgid"));
                        if (quoteProducts.Entities.Count() > 0)
                        {
                            ExecuteMultipleRequest request = new ExecuteMultipleRequest()
                            {
                                Requests = new OrganizationRequestCollection(),
                                Settings = new ExecuteMultipleSettings
                                {
                                    ContinueOnError = false,
                                    ReturnResponses = true
                                }
                            };
                            List<string> glaccount = new List<string>();
                            List<string> profitcenterCode = new List<string>();
                            foreach (Entity rec in quoteProducts.Entities)
                            {
                                if (rec.Contains("pl.niq_glaccountnumber"))
                                    glaccount.Add(((AliasedValue)rec["pl.niq_glaccountnumber"]).Value.ToString());
                                if (rec.Contains("pl.niq_profitcentrecode"))
                                    profitcenterCode.Add(((AliasedValue)rec["pl.niq_profitcentrecode"]).Value.ToString());
                            }
                            string[] glaccountUnique = glaccount.Distinct().ToArray<string>();
                            string[] profitcenterCodeUniqe = profitcenterCode.Distinct().ToArray<string>();
                            FilterExpression filterGLAcc = new FilterExpression();
                            filterGLAcc.AddCondition("niq_glaccountnumber", ConditionOperator.In, glaccountUnique);
                            FilterExpression filterPC = new FilterExpression();
                            if (profitcenterCodeUniqe.Length > 0)
                                filterPC.AddCondition("niq_profitcentrecode", ConditionOperator.In, profitcenterCodeUniqe);
                            EntityCollection glAccounts = CommonHelper.ReturnQueryResult("niq_glaccount", new ColumnSet("niq_glaccountid", "niq_glaccountnumber"), filterGLAcc, new LinkEntity(), tracing, service);
                            EntityCollection profitCenters = CommonHelper.ReturnQueryResult("niq_profitcentre", new ColumnSet("niq_profitcentreid", "niq_profitcentrecode"), filterPC, new LinkEntity(), tracing, service);

                            foreach (Entity rec in quoteProducts.Entities)
                            {
                                Entity updateQP = new Entity(rec.LogicalName, rec.Id);
                                tracing.Trace("before check rec.contains niqismodified");

                                if (!rec.Contains("niq_salesorgcodeid") && relatedOpportunity.Contains("niq_salesorgid"))
                                    updateQP["niq_salesorgcodeid"] = relatedOpportunity["niq_salesorgid"];

                                if (!rec.Contains("niq_glaccountid") && rec.Contains("pl.niq_glaccountnumber") && glAccounts.Entities.Where(a => a["niq_glaccountnumber"].ToString() == ((AliasedValue)rec["pl.niq_glaccountnumber"]).Value.ToString()).Any())
                                    updateQP["niq_glaccountid"] = new EntityReference("niq_glaccount", glAccounts.Entities.Where(a => a["niq_glaccountnumber"].ToString() == ((AliasedValue)rec["pl.niq_glaccountnumber"]).Value.ToString()).FirstOrDefault().Id);

                                if (!rec.Contains("niq_profitcentreid") && rec.Contains("pl.niq_profitcentrecode") && profitCenters.Entities.Where(a => a["niq_profitcentrecode"].ToString() == ((AliasedValue)rec["pl.niq_profitcentrecode"]).Value.ToString()).Any())
                                    updateQP["niq_profitcentreid"] = new EntityReference("niq_profitcentre", profitCenters.Entities.Where(a => a["niq_profitcentrecode"].ToString() == ((AliasedValue)rec["pl.niq_profitcentrecode"]).Value.ToString()).FirstOrDefault().Id);
                                if (updateQP.Attributes.Any())
                                {
                                    UpdateRequest updateRequest = new UpdateRequest()
                                    {
                                        Target = updateQP
                                    };
                                    request.Requests.Add(updateRequest);
                                }
                            }
                            if (request.Requests.Count() > 0)
                            {
                                ExecuteMultipleResponse response = (ExecuteMultipleResponse)service.Execute(request);
                                string errorResponse = "";
                                foreach (ExecuteMultipleResponseItem res in response.Responses)
                                {
                                    if (res.Fault != null)
                                    {
                                        errorResponse += res.Fault + "\n";
                                    }
                                }
                                if (!string.IsNullOrEmpty(errorResponse))
                                    throw new InvalidPluginExecutionException("Error oocured in Execute Multiple Request : " + errorResponse);
                            }
                        }


                        Entity updateQuote = new Entity(entityObj.LogicalName, entityObj.Id);
                        updateQuote["niq_expvalidation"] = false;
                        service.Update(updateQuote);
                    }

                }
            }
            catch (Exception e)
            {
                throw new InvalidPluginExecutionException(e.Message);
            }
        }
    }
}
