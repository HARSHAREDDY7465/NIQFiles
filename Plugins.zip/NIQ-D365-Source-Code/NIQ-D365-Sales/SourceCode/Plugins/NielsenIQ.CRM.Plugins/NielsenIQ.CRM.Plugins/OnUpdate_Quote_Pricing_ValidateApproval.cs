﻿using System;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Quote_Pricing_ValidateApproval : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity targetEntity)
            {
                tracingService.Trace("Plugin execution started for entity: {0}, Id: {1}", targetEntity.LogicalName, targetEntity.Id);

                Entity updateEntity = new Entity(targetEntity.LogicalName, targetEntity.Id);

                // Retrieve the full Quote entity including niq_salesorgid
                Entity fullQuote = service.Retrieve(targetEntity.LogicalName, targetEntity.Id, new ColumnSet("niq_overalldealscore", "niq_salesorgid", "niq_discount", "niq_proposedratecardattainment"));

                // Trace the values of the retrieved fields
                string overallDealScore = fullQuote.GetAttributeValue<string>("niq_overalldealscore");
                tracingService.Trace("Retrieved values - niq_overalldealscore: {0}", overallDealScore);

                decimal proposedratecardattainment = fullQuote.GetAttributeValue<decimal>("niq_proposedratecardattainment");
                tracingService.Trace("Retrieved values - niq_proposedratecardattainment: {0}", proposedratecardattainment);

                var salesOrgReference = fullQuote.GetAttributeValue<EntityReference>("niq_salesorgid");
                if (salesOrgReference != null)
                {
                    tracingService.Trace("Retrieved values - Sales Org ID: {0}", salesOrgReference.Id);

                    // Retrieve Sales Org entity to get its name
                    Entity salesOrg = service.Retrieve(salesOrgReference.LogicalName, salesOrgReference.Id, new ColumnSet("niq_name"));
                    string salesOrgName = salesOrg.GetAttributeValue<string>("niq_name");
                    tracingService.Trace("Retrieved values - Sales Org Name: {0}", salesOrgName);
                }
                else
                {
                    tracingService.Trace("Sales Org ID is null.");
                }

                // Trace the discount value
                decimal? discount = fullQuote.GetAttributeValue<decimal?>("niq_discount");
                tracingService.Trace("Retrieved values - niq_discount: {0}", discount);

                // Check if the quote was scored
                if (overallDealScore != null)
                {
                    // Query to check if there is no initially approved DDAR linked to the quote
                    QueryExpression ddarQuery = new QueryExpression("niq_dealdeskapprovalrequest")
                    {
                        ColumnSet = new ColumnSet("niq_approvalstatus"),
                        Criteria =
                        {
                            Conditions =
                            {
                                new ConditionExpression("niq_quoteid", ConditionOperator.Equal, targetEntity.Id),
                                new ConditionExpression("niq_approvalstatus", ConditionOperator.Equal, 4) // Initially approved status
                            }
                        }
                    };

                    // Retrieve the results
                    EntityCollection resultDDAR = service.RetrieveMultiple(ddarQuery);
                    tracingService.Trace("Number of DDAR records found: {0}", resultDDAR.Entities.Count);
                    // new logic as per DYNCRM-29540

                    // Check if no initially approved DDAR exists
                    if (!string.IsNullOrEmpty(overallDealScore))
                    {
                        bool isDDARApproved = resultDDAR.Entities.Count > 0;
                        bool reApprovalNeeded = fullQuote.GetAttributeValue<bool?>("niq_reapprovalneeded") ?? false;

                        // New logic as per AC
                        if (overallDealScore == "Dark Green")
                        {
                            tracingService.Trace("Overall Deal Score is Dark Green.");
                            updateEntity["niq_dealdeskapproval"] = new OptionSetValue(100000006); // No approval required
                        }
                        else if (overallDealScore == "Light Green")
                        {
                            tracingService.Trace("Overall Deal Score is Light Green - applying new logic.");

                            // bool isDDARApproved = resultDDAR.Entities.Count > 0; // DDAR exists if query returned records
                            //bool reApprovalNeeded = fullQuote.GetAttributeValue<bool?>("niq_reapprovalneeded") ?? false;

                            if (!isDDARApproved)
                            {
                                updateEntity["niq_dealdeskapproval"] = new OptionSetValue(100000006); // Deal Score Sufficient
                                tracingService.Trace("Light Green, no DDAR → No approval required.");
                            }
                            else
                            {
                                if (!reApprovalNeeded)
                                {
                                    updateEntity["niq_dealdeskapproval"] = new OptionSetValue(100000006); // Deal Score Sufficient
                                    tracingService.Trace("Light Green, DDAR exists, re-approval NO → No approval required.");
                                }
                                else
                                {
                                    updateEntity["niq_dealdeskapproval"] = new OptionSetValue(100000001); // Segment Lead Approval Required
                                    tracingService.Trace("Light Green, DDAR exists, re-approval YES → Approval required.");
                                }
                            }
                        }


                        else if (overallDealScore == "Yellow" || overallDealScore == "Red")
                        {
                            tracingService.Trace("Overall Deal Score is Yellow or Red.");
                            updateEntity["niq_dealdeskapproval"] = new OptionSetValue(100000002); // Approval required
                        }

                        else
                        {
                            tracingService.Trace("Target entity does not contain 'niq_overalldealscore'.");
                        }
                    }

                    // Check if no initially approved DDAR exists
                    //if (resultDDAR.Entities.Count == 0)
                    //{
                    //  tracingService.Trace("No initially approved DDAR found. Proceeding with deal score logic.");

                    // if (overallDealScore == "Dark Green")
                    //{
                    //  tracingService.Trace("Overall Deal Score is Dark Green.");
                    //  updateEntity["niq_dealdeskapproval"] = new OptionSetValue(100000006); // No approval required
                    // }
                    //else if (overallDealScore == "Light Green")//26199 based on niq_proposedratecardattainment change the value of niq_dealdeskapproval
                    //{
                    //  if (proposedratecardattainment >= 100)
                    //{
                    // updateEntity["niq_dealdeskapproval"] = new OptionSetValue(100000006); // Deal Score Sufficient, No Approval Required
                    // tracingService.Trace("Overall Deal Score is LightGreen and based on propsedratecardattainment, pricing approval -Dealscoresufficient.");
                    //}
                    //else
                    //{
                    // updateEntity["niq_dealdeskapproval"] = new OptionSetValue(100000001); // Segment Lead Approval Required
                    // tracingService.Trace("Overall Deal Score is LightGreen and based on propsedratecardattainment, pricing approval -Segmentlead.");

                    // }
                    // commented (84-145) as part of 22130
                    //if (salesOrgReference != null)
                    //{
                    //    string salesOrgName = service.Retrieve(salesOrgReference.LogicalName, salesOrgReference.Id, new ColumnSet("niq_name")).GetAttributeValue<string>("niq_name");

                    //    if (salesOrgName == "0500 - Nielsen Consumer LLC" || salesOrgName == "0560 - ACNielsen - Canada") // North America
                    //    {
                    //        if (discount.HasValue && discount.Value > 20)
                    //        {
                    //            tracingService.Trace("Discount greater than 20. Setting Deal Desk Approval Required.");
                    //            updateEntity["niq_dealdeskapproval"] = new OptionSetValue(100000002); // Deal Desk Approval Required
                    //        }
                    //        else
                    //        {
                    //            tracingService.Trace("Discount not greater than 20. Segment approval required.");
                    //            updateEntity["niq_dealdeskapproval"] = new OptionSetValue(100000001); // Segment approval required
                    //        }
                    //    }
                    //    else // International
                    //    {
                    //        tracingService.Trace("International Sales Org. Fetching related Quote Detail records.");

                    //        // Fetch related "quotedetail" records to check for brands
                    //        QueryExpression quoteDetailQuery = new QueryExpression("quotedetail")
                    //        {
                    //            ColumnSet = new ColumnSet("niq_brandid"),
                    //            Criteria =
                    //            {
                    //                Conditions =
                    //                {
                    //                    new ConditionExpression("quoteid", ConditionOperator.Equal, targetEntity.Id)
                    //                }
                    //            }
                    //        };

                    //        var quoteDetailResults = service.RetrieveMultiple(quoteDetailQuery);
                    //        tracingService.Trace("Number of Quote Detail records found: {0}", quoteDetailResults.Entities.Count);

                    //        bool hasRMSorCPS = quoteDetailResults.Entities.Any(qd =>
                    //            qd.GetAttributeValue<EntityReference>("niq_brandid")?.Name == "RMS" ||
                    //            qd.GetAttributeValue<EntityReference>("niq_brandid")?.Name == "CPS");
                    //        bool hasAAC = quoteDetailResults.Entities.Any(qd =>
                    //            qd.GetAttributeValue<EntityReference>("niq_brandid")?.Name == "AAC");
                    //        bool hasBASES = quoteDetailResults.Entities.Any(qd =>
                    //            qd.GetAttributeValue<EntityReference>("niq_brandid")?.Name == "BASES");

                    //        tracingService.Trace("Brands present - RMS/CPS: {0}, AAC: {1}, BASES: {2}", hasRMSorCPS, hasAAC, hasBASES);

                    //        if ((hasRMSorCPS && discount.HasValue && discount.Value > 10) ||
                    //            (hasAAC && discount.HasValue && discount.Value > 0) ||
                    //            (hasBASES && discount.HasValue && discount.Value > 20))
                    //        {
                    //            tracingService.Trace("Conditions met for Deal Desk Approval Required.");
                    //            updateEntity["niq_dealdeskapproval"] = new OptionSetValue(100000002); // Deal Desk Approval Required
                    //        }
                    //        else
                    //        {
                    //            tracingService.Trace("Conditions not met. Segment approval required.");
                    //            updateEntity["niq_dealdeskapproval"] = new OptionSetValue(100000001); // Segment approval required
                    //        }
                    //    }
                    //}
                    // }
                    //else if (overallDealScore == "Yellow" || overallDealScore == "Red")
                    //{
                    //    tracingService.Trace("Overall Deal Score is Yellow or Red.");
                    //    updateEntity["niq_dealdeskapproval"] = new OptionSetValue(100000002); // Approval required
                    //}

                    //else
                    //{
                    //    tracingService.Trace("Initial DDAR records found. No further action required.");
                    //}
                }
                else
                {
                    tracingService.Trace("Target entity does not contain 'niq_overalldealscore'.");
                }

                // Update the quote record
                if (updateEntity.Attributes.Count > 0)
                {
                    tracingService.Trace("Updating quote record with Id: {0}", targetEntity.Id);
                    service.Update(updateEntity);
                }
                else
                {
                    tracingService.Trace("No changes to update.");
                }
            }

            else
            {
                tracingService.Trace("No Target entity found in InputParameters.");
            }
        }
    }
}