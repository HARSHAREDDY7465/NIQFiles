﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;


namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_OppUrlFields_CreatePOCR : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_OppUrlFields_CreatePOCR: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity oppoObj = (Entity)context.InputParameters["Target"];
                    int oppStatus;
                    string prefinalurl = string.Empty;
                    string prepourl = string.Empty;
                    if (oppoObj.Contains("niq_finallyexecutedagreementurl") || oppoObj.Contains("niq_podocumentationurl"))
                    {
                        Entity postImage = context.PostEntityImages.Contains("OpportunityImage") ? (Entity)context.PostEntityImages["OpportunityImage"] : null;
                        Entity preImage = context.PreEntityImages.Contains("OpportunityImage") ? (Entity)context.PreEntityImages["OpportunityImage"] : null;
                        tracing.Trace("postImage != null");
                        if (postImage != null)
                        {
                            oppStatus = postImage.GetAttributeValue<OptionSetValue>("statecode").Value;
                            tracing.Trace("status: " + oppStatus);
                            //check if status is not won
                            if (oppStatus != 1)
                                return;
                        }
                        if (preImage != null)
                        {
                            if (preImage.Contains("niq_finallyexecutedagreementurl") && preImage["niq_finallyexecutedagreementurl"].ToString() != null)
                            {
                                prefinalurl = preImage["niq_finallyexecutedagreementurl"].ToString();
                            }
                            if (preImage.Contains("niq_podocumentationurl") && preImage["niq_podocumentationurl"].ToString() != null)
                            {
                                prepourl = preImage["niq_podocumentationurl"].ToString();
                            }

                        }
                        if (oppoObj.Contains("niq_finallyexecutedagreementurl") && (oppoObj["niq_finallyexecutedagreementurl"].ToString().Length > 0) && prefinalurl != oppoObj["niq_finallyexecutedagreementurl"].ToString())
                        {
                            tracing.Trace("niq_finallyexecutedagreementurl: " + oppoObj["niq_finallyexecutedagreementurl"].ToString());
                            Entity POCR = new Entity("niq_postopportunity");
                            POCR["niq_finallyexecutedagreementurl"] = oppoObj["niq_finallyexecutedagreementurl"];
                            POCR["niq_descriptionofchange"] = "Finally Executed EOA file submission";
                            POCR["niq_opportunity"] = new EntityReference(oppoObj.LogicalName, oppoObj.Id);

                            if (postImage != null)
                            {
                                Guid quoteGuid = postImage.Attributes.Contains("niq_mainquoteid") ? postImage.GetAttributeValue<EntityReference>("niq_mainquoteid").Id : Guid.Empty;
                                tracing.Trace("quoteGuid " + quoteGuid);
                                if (quoteGuid != Guid.Empty)
                                {
                                    Entity localQuote;
                                    localQuote = service.Retrieve("quote", quoteGuid, new ColumnSet("niq_paymenttermsid"));
                                    POCR["niq_paymenttermsid"] = localQuote.Attributes.Contains("niq_paymenttermsid") ? localQuote.GetAttributeValue<EntityReference>("niq_paymenttermsid") : null; //display Payment Terms from the main quote of the opportunity
                                }
                            }
                            POCR["niq_typeofchange"] = new OptionSetValue(100000000);// "Finally executed agreement and payment terms submission"; // 
                            service.Create(POCR);
                            tracing.Trace("Final: POCR created");
                        }
                        if (oppoObj.Contains("niq_podocumentationurl") && (oppoObj["niq_podocumentationurl"].ToString().Length > 0) && prepourl != oppoObj["niq_podocumentationurl"].ToString())
                        {
                            tracing.Trace("niq_podocumentationurl " + oppoObj["niq_podocumentationurl"].ToString());
                            Entity POCR1 = new Entity("niq_postopportunity");
                            //Get main quote payment terms
                            POCR1["niq_opportunity"] = new EntityReference(oppoObj.LogicalName, oppoObj.Id);
                            POCR1["niq_podocumentationurl"] = oppoObj["niq_podocumentationurl"];
                            POCR1["niq_customerpo"] = "See Opportunity Files";//"See Opportunity Files" text
                            POCR1["niq_descriptionofchange"] = "PO file submission";
                            POCR1["niq_typeofchange"] = new OptionSetValue(100000001);// "PO details submission"; //
                            service.Create(POCR1);
                            tracing.Trace("poducment POCR created");
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
