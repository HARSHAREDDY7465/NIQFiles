﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.Remoting.Services;
using Newtonsoft.Json.Linq;
using System.Diagnostics;
using System.Security.Cryptography;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Quote_DD_ValidateDealDesk : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                bool isOppoPriority = false;
                bool isApprovalRequired = false;
                bool isPlaceholder = false;
                string approvalFields = null;


                if (context.MessageName == "Delete")
                {
                    tracing.Trace("Calling Delete");
                    Entity preImage = context.PreEntityImages.Contains("Image") ? (Entity)context.PreEntityImages["Image"] : new Entity();
                    if (preImage.Contains("quotedetailname") && preImage.GetAttributeValue<string>("quotedetailname") == "Place Holder Product" && preImage.Contains("quoteid") && preImage.GetAttributeValue<EntityReference>("quoteid").Id != Guid.Empty)
                    {
                        tracing.Trace("Post Operation On" + context.MessageName + " of OnUpdate_Quote_DD_ValidateDealDesk: Getting the target entity from Input Parameters.");
                        Entity retQuote = service.Retrieve(preImage.GetAttributeValue<EntityReference>("quoteid").LogicalName, preImage.GetAttributeValue<EntityReference>("quoteid").Id, new ColumnSet("niq_quoteheaderdetailsapproval"));
                        if (retQuote != null && retQuote.Id != Guid.Empty)
                        {
                            tracing.Trace("ret quote " + retQuote.Id);
                            Entity updQuoteHeader = new Entity(preImage.GetAttributeValue<EntityReference>("quoteid").LogicalName, preImage.GetAttributeValue<EntityReference>("quoteid").Id);

                            if (retQuote.Attributes.Contains("niq_quoteheaderdetailsapproval") && retQuote.GetAttributeValue<OptionSetValue>("niq_quoteheaderdetailsapproval") != null)
                            {
                                tracing.Trace("niq_quoteheaderdetailsapproval " + retQuote.GetAttributeValue<OptionSetValue>("niq_quoteheaderdetailsapproval").Value);
                                updQuoteHeader["niq_quoteheaderdetailsapproval"] = new OptionSetValue(retQuote.GetAttributeValue<OptionSetValue>("niq_quoteheaderdetailsapproval").Value);
                                tracing.Trace("updating.......");
                                service.Update(updQuoteHeader);
                                tracing.Trace("Success");
                            }
                            else
                            {
                                tracing.Trace(" niq_quoteheaderdetailsapproval is null");
                                updQuoteHeader["niq_quoteheaderdetailsapproval"] = null;
                                tracing.Trace("updating.......");
                                service.Update(updQuoteHeader);
                                tracing.Trace("updating.......");
                            }
                        }
                    }

                    if (preImage.Contains("quoteid") && preImage.GetAttributeValue<EntityReference>("quoteid").Id != Guid.Empty)
                    {
                        Entity retQuote = service.Retrieve(preImage.GetAttributeValue<EntityReference>("quoteid").LogicalName, preImage.GetAttributeValue<EntityReference>("quoteid").Id, new ColumnSet("opportunityid", "niq_mainquote", "niq_contractstartdate", "niq_contractenddate"));



                        if (retQuote != null && retQuote.Id != Guid.Empty && retQuote.Attributes.Contains("opportunityid"))
                        {
                            string fetchDateQP = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' aggregate='true' >
                                                <entity name='quotedetail' >
                                                    <attribute name='niq_lineitemstartdate' alias='minDate' aggregate='min' />
                                                    <attribute name='niq_lineitemenddate' alias='maxDate' aggregate='max' />
                                                    <filter type='and' >
                                                        <condition attribute='quoteid' operator='eq' uiname='testchanges' uitype='quote' value='{0}' />
                                                        <condition attribute='quotedetailname' operator='ne' value='SAP Deferred Revenue reconciliation placeholder' />
                                                    </filter>
                                                </entity>
                                            </fetch>";
                            fetchDateQP = string.Format(fetchDateQP, retQuote.Id);
                            var resDateQP = service.RetrieveMultiple(new FetchExpression(fetchDateQP));
                            Entity updQuote = new Entity(retQuote.LogicalName, retQuote.Id);
                            Entity updOppo = new Entity(retQuote.GetAttributeValue<EntityReference>("opportunityid").LogicalName, retQuote.GetAttributeValue<EntityReference>("opportunityid").Id);
                            bool updateQuote = false;

                            if (resDateQP != null && resDateQP.Entities != null && resDateQP.Entities.Count > 0)
                            {

                                Entity dateQP = resDateQP.Entities.FirstOrDefault();
                                if (dateQP.Contains("minDate") && dateQP.GetAttributeValue<AliasedValue>("minDate").Value != null)
                                {
                                    DateTime mindate = (DateTime)dateQP.GetAttributeValue<AliasedValue>("minDate").Value;
                                    updQuote["niq_contractstartdate"] = mindate;
                                    updOppo["niq_contractstartdate"] = mindate;
                                    updateQuote = true;

                                }
                                if (dateQP.Contains("maxDate") && dateQP.GetAttributeValue<AliasedValue>("maxDate").Value != null)
                                {
                                    DateTime maxDate = (DateTime)dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                    updQuote["niq_contractenddate"] = maxDate;
                                    updOppo["niq_contractenddate"] = maxDate;
                                    updateQuote = true;

                                }
                            }
                            else
                            {
                                updateQuote = true;
                                updQuote["niq_contractstartdate"] = null;
                                updOppo["niq_contractstartdate"] = null;

                                updQuote["niq_contractenddate"] = null;
                                updOppo["niq_contractenddate"] = null;



                            }

                            if (updateQuote)
                            {
                                service.Update(updQuote);
                                tracing.Trace("OnDeleteQP: sucesfull update quote");
                                if (retQuote.Attributes.Contains("niq_mainquote") && retQuote.GetAttributeValue<bool>("niq_mainquote"))
                                {
                                    service.Update(updOppo);
                                    tracing.Trace("OnDeleteQP: sucesfull updated Oppo");

                                }
                            }
                        }
                    }
                    //tracing.Trace("dd: " + preImage.Contains("quoteid"));
                    //tracing.Trace("dd: " + (preImage.GetAttributeValue<EntityReference>("quoteid").Id != Guid.Empty));
                    if (preImage.Contains("quoteid") && preImage.GetAttributeValue<EntityReference>("quoteid").Id != Guid.Empty)
                    {
                        tracing.Trace("Schedule checkup begins");
                        EntityReference Quote = preImage.GetAttributeValue<EntityReference>("quoteid");
                        Entity UpdateQuote = new Entity("quote");
                        ScheduleHelper scheduleHelper = new ScheduleHelper(tracing, service);
                        int QuoteCompleteSchedules = 610570001;
                        int QuoteInCompleteSchedules = 610570002;
                        UpdateQuote.Id = preImage.GetAttributeValue<EntityReference>("quoteid").Id;

                        bool revenueScheduleCompleted = scheduleHelper.checkIsRevenueSchedulesGenerated(Quote);
                        UpdateQuote["niq_revenueschedulecomplete"] = revenueScheduleCompleted ? new OptionSetValue(QuoteCompleteSchedules) : new OptionSetValue(QuoteInCompleteSchedules);
                        UpdateQuote["niq_billingschedulecomplete"] = scheduleHelper.checkIsBillingSchedulesGenerated(Quote) ? new OptionSetValue(QuoteCompleteSchedules) : new OptionSetValue(QuoteInCompleteSchedules);

                        if (revenueScheduleCompleted)
                        {
                            UpdateQuote["niq_tracecustomscheduledates"] = scheduleHelper.IsSchedulesWithQuoteProductDates(Quote);
                        }
                        service.Update(UpdateQuote);
                        tracing.Trace("schedule checkup ends");
                    }
                }

                //if (context.MessageName == "Create" && context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity && ((Entity)context.InputParameters["Target"]).LogicalName == "quotedetail")
                //{
                //    tracing.Trace("Calling Create on QP");
                //    Entity postImage = context.PostEntityImages.Contains("Image") ? (Entity)context.PostEntityImages["Image"] : new Entity();
                //    if (postImage.Attributes.Contains("quotedetailname") && postImage.GetAttributeValue<string>("quotedetailname").ToLower() == "place holder product" && postImage.Contains("quoteid") && postImage.GetAttributeValue<EntityReference>("quoteid").Id != Guid.Empty)
                //    {
                //        tracing.Trace("Post Operation On" + context.MessageName + " of OnUpdate_Quote_DD_ValidateDealDesk: Getting the target entity from Input Parameters.");
                //        Entity retQuote = service.Retrieve(postImage.GetAttributeValue<EntityReference>("quoteid").LogicalName, postImage.GetAttributeValue<EntityReference>("quoteid").Id, new ColumnSet("niq_quoteheaderdetailsapproval"));
                //        if (retQuote != null && retQuote.Id != Guid.Empty)
                //        {
                //            tracing.Trace("ret quote " + retQuote.Id);
                //            Entity updQuote = new Entity(postImage.GetAttributeValue<EntityReference>("quoteid").LogicalName, postImage.GetAttributeValue<EntityReference>("quoteid").Id);
                //            updQuote["niq_overalldealdeskapproval"] = new OptionSetValue(1);
                //            service.Update(updQuote);
                //        }
                //    }



                //}


                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity && ((Entity)context.InputParameters["Target"]).LogicalName == "quote")
                {
                    tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: On Change of Quote");
                    tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity quoteObj = (Entity)context.InputParameters["Target"];
                    if (quoteObj != null && quoteObj.Id != Guid.Empty)
                    {
                        tracing.Trace("quote id:" + quoteObj.Id);
                        tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: inside update for overall");
                        bool update = false;
                        Entity updQuote = new Entity(quoteObj.LogicalName, quoteObj.Id);
                        string fetchQuoteNRP = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='quotedetail'>
                                                        <attribute name='productdescription' />
                                                        <attribute name='quotedetailname' />
                                                        <attribute name='quotedetailid' />
                                                        <order attribute='niq_brandid' descending='false' />
                                                        <filter type='and'>
                                                          <condition attribute='quoteid' operator='eq' uitype='quote' value='{0}' />
                                                          <condition attribute='isproductoverridden' operator='eq' value='1' />
                                                          <condition attribute='productdescription' operator='eq' value='Place Holder Product' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";
                        fetchQuoteNRP = string.Format(fetchQuoteNRP, quoteObj.Id);
                        var resultQuoteNRP = service.RetrieveMultiple(new FetchExpression(fetchQuoteNRP));
                        if (resultQuoteNRP != null && resultQuoteNRP.Entities != null && resultQuoteNRP.Entities.Count > 0)
                        {
                            tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: Getting the placeholder Prod");
                            //If at least one placeholder product is present on the quote, set to "Remove placeholder product". This logical condition only relates to Placeholder product and not "SAP deferred revenue reconciliation product"
                            isPlaceholder = true;
                            updQuote["niq_overalldealdeskapproval"] = new OptionSetValue(1);
                            update = true;
                        }
                        Entity retQuote = service.Retrieve(quoteObj.LogicalName, quoteObj.Id, new ColumnSet("opportunityid", "niq_dealdeskapproval", "niq_fundusageapproval", "niq_quoteheaderdetailsapproval", "niq_overalldealdeskapproval","statecode","niq_discount"));
                        if (!isPlaceholder && retQuote != null && retQuote.Id != Guid.Empty && (retQuote.Attributes.Contains("opportunityid") && retQuote.GetAttributeValue<EntityReference>("opportunityid").Id != Guid.Empty))
                        {
                            tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk:if not placeholder");

                            Entity retOppo = service.Retrieve(retQuote.GetAttributeValue<EntityReference>("opportunityid").LogicalName, retQuote.GetAttributeValue<EntityReference>("opportunityid").Id, new ColumnSet("niq_existingcontractaction"));
                            if (retOppo != null && retOppo.Id != Guid.Empty && (retOppo.Attributes.Contains("niq_existingcontractaction") && retOppo.GetAttributeValue<OptionSetValue>("niq_existingcontractaction") != null && (retOppo.GetAttributeValue<OptionSetValue>("niq_existingcontractaction").Value == 2 || retOppo.GetAttributeValue<OptionSetValue>("niq_existingcontractaction").Value == 3)))
                            {
                                tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: Opportunity Priority");

                                var pricingApproval = -1;
                                var fundUsage = -1;
                                var quoteHeader = -1;
                                var overAll = -1;
                                if (retQuote.Attributes.Contains("niq_dealdeskapproval") && retQuote.GetAttributeValue<OptionSetValue>("niq_dealdeskapproval") != null)
                                {
                                    pricingApproval = retQuote.GetAttributeValue<OptionSetValue>("niq_dealdeskapproval").Value;

                                }
                                if (retQuote.Attributes.Contains("niq_fundusageapproval") && retQuote.GetAttributeValue<OptionSetValue>("niq_fundusageapproval") != null)
                                {
                                    fundUsage = retQuote.GetAttributeValue<OptionSetValue>("niq_fundusageapproval").Value;

                                }
                                if (retQuote.Attributes.Contains("niq_quoteheaderdetailsapproval") && retQuote.GetAttributeValue<OptionSetValue>("niq_quoteheaderdetailsapproval") != null)
                                {
                                    quoteHeader = retQuote.GetAttributeValue<OptionSetValue>("niq_quoteheaderdetailsapproval").Value;

                                }
                                if (retQuote.Attributes.Contains("niq_overalldealdeskapproval") && retQuote.GetAttributeValue<OptionSetValue>("niq_overalldealdeskapproval") != null)
                                {
                                    overAll = retQuote.GetAttributeValue<OptionSetValue>("niq_overalldealdeskapproval").Value;

                                }
                                //IC-POC #24192_B
                                tracing.Trace("lineno 231");
                                if ((pricingApproval != -1 && pricingApproval != 100000003) || (fundUsage != -1 && fundUsage != 3) || (quoteHeader != -1 && quoteHeader != 3) || (overAll != -1 && overAll != 5))
                                {
                                    tracing.Trace("lineno 234");
                                    Entity updQuotes = new Entity(retQuote.LogicalName, retQuote.Id);
                                    updQuotes["niq_overalldealdeskapproval"] = new OptionSetValue(5);
                                    updQuotes["niq_quoteheaderdetailsapproval"] = new OptionSetValue(3);
                                    updQuotes["niq_fundusageapproval"] = new OptionSetValue(3);
                                    updQuotes["niq_dealdeskapproval"] = new OptionSetValue(100000003);
                                    service.Update(updQuotes);
                                }
                                tracing.Trace("lineno 242");
                                //IC-POC #24192_E
                                isOppoPriority = true;
                            }
                        }


                        if (!isPlaceholder && !isOppoPriority && context.MessageName == "Update")
                        {
                            tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk:Other Priortites");

                            tracing.Trace("niq_overalldealscore : " + quoteObj.Attributes.Contains("niq_overalldealscore"));
                            if (quoteObj != null && quoteObj.Id != Guid.Empty && (quoteObj.Attributes.Contains("niq_overalldealscore") || quoteObj.Attributes.Contains("niq_discount") || quoteObj.Attributes.Contains("niq_customertype") || quoteObj.Attributes.Contains("niq_msapaymenttermdays") || quoteObj.Attributes.Contains("niq_termtype") || quoteObj.Attributes.Contains("niq_annualincreasetype") || quoteObj.Attributes.Contains("niq_annualapicola") || quoteObj.Attributes.Contains("niq_apistructure") || quoteObj.Attributes.Contains("niq_evergreenautorenewalannualapi") || quoteObj.Attributes.Contains("niq_terminationnotificationmonths") || quoteObj.Attributes.Contains("niq_numberofftes") || quoteObj.Attributes.Contains("niq_interestrateonlatepayment") || quoteObj.Attributes.Contains("niq_paymenttermsid") || quoteObj.Attributes.Contains("niq_incentivetype") || quoteObj.Attributes.Contains("niq_incentivevalueniqannualimpact") || quoteObj.Attributes.Contains("niq_linktononstandardapprovalrequests") || quoteObj.Attributes.Contains("niq_quotedefaultperiodicbillingfrequency") || quoteObj.Attributes.Contains("niq_nonstandardbillingterm")))
                            {
                                tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: Inside quote header validation");
                                Entity retQuoteHeader = service.Retrieve(quoteObj.LogicalName, quoteObj.Id, new ColumnSet("niq_discount", "totalamount", "niq_msapaymenttermdays", "niq_overalldealscore", "niq_modeleddayssalesoutstanding", "niq_quoteheaderdetailsapproval", "niq_dealdeskapproval", "niq_contractenddate", "niq_contractstartdate", "niq_salesorgid", "customerid", "niq_customertype", "niq_termtype", "niq_annualincreasetype", "niq_annualapicola", "niq_apistructure", "niq_evergreenautorenewalannualapi", "niq_terminationnotificationmonths", "niq_numberofftes", "niq_interestrateonlatepayment", "niq_paymenttermsid", "niq_msapaymentterm", "niq_linktononstandardapprovalrequests", "niq_incentivevalueniqannualimpact", "niq_incentivetype", "niq_nonstandardbillingterm", "niq_quotedefaultperiodicbillingfrequency"));
                                if (retQuoteHeader != null && retQuoteHeader.Id != Guid.Empty)
                                {
                                    tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk:ret quote" + retQuoteHeader.Id);
                                    //Entity updQuoteHeader = new Entity(retQuoteHeader.LogicalName, retQuoteHeader.Id);
                                    tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk:ret termtype" + retQuoteHeader.Attributes.Contains("niq_termtype"));
                                    if (!retQuoteHeader.Attributes.Contains("niq_termtype"))
                                    {
                                        updQuote["niq_quoteheaderdetailsapproval"] = new OptionSetValue(1);
                                        update = true;
                                    }
                                    else
                                    {
                                        /*if (retQuoteHeader.Attributes.Contains("niq_termtype") && retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_termtype") != null)
                                        {
                                            //Approval required if Indefinite or Perpetual is selected
                                            if (retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_termtype").Value == 100000002 || retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_termtype").Value == 100000003)
                                            {
                                                isApprovalRequired = true;
                                                approvalFields = "Term Type";
                                                tracing.Trace("Approval required if Indefinite or Perpetual is selected");

                                            }
                                            //if (Term Type = fixed term or evergreen)
                                            if (retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_termtype").Value == 100000001 || retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_termtype").Value == 100000000)
                                            {
                                                if (retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_termtype").Value == 100000000)
                                                {
                                                    //Approval Required if Term Type = Evergreen and Sales Org is not 0500 or 0560
                                                    var salesorgQuery = @"<fetch version=""1.0"" output-format=""xml-platform"" mapping=""logical"" distinct=""false"">
                                                                           <entity name=""niq_salesorg"">
                                                                           <attribute name=""niq_salesorgid"" />
                                                                           <attribute name=""niq_name"" />
                                                                           <attribute name=""createdon"" />
                                                                           <order attribute=""niq_name"" descending=""false"" />
                                                                           <filter type=""and"">
                                                                             <filter type=""or"">
                                                                              <condition attribute=""niq_salesorgcode"" operator=""eq"" value=""0500"" />
                                                                              <condition attribute=""niq_salesorgcode"" operator=""eq"" value=""0560"" />
                                                                             </filter>
                                                                           <condition attribute=""niq_salesorgid"" operator=""eq"" uiname=""0500 - Nielsen Consumer LLC"" uitype=""niq_salesorg"" value=""{0}"" />
                                                                           </filter>
                                                                         </entity>
                                                                        </fetch>";
                                                    salesorgQuery = string.Format(salesorgQuery, retQuoteHeader.GetAttributeValue<EntityReference>("niq_salesorgid").Id);
                                                    var salesRecords = service.RetrieveMultiple(new FetchExpression(salesorgQuery));
                                                    if (salesRecords != null && salesRecords.Entities != null && salesRecords.Entities.Count == 0)
                                                    {
                                                        isApprovalRequired = true;
                                                        approvalFields = "Term Type";
                                                    }
                                                }
                                                if (retQuoteHeader.GetAttributeValue<DateTime>("niq_contractenddate") != null && retQuoteHeader.GetAttributeValue<DateTime>("niq_contractstartdate") != null)
                                                {
                                                    int monthsDiff = GetMonthDifference(retQuoteHeader.GetAttributeValue<DateTime>("niq_contractstartdate"), retQuoteHeader.GetAttributeValue<DateTime>("niq_contractenddate").AddDays(1));
                                                    if (monthsDiff > 12)
                                                    {
                                                        bool isSalesOrg = false;
                                                        var salesorgQuery = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                                  <entity name='niq_salesorg'>
                                                                                    <attribute name='niq_salesorgid' />
                                                                                    <attribute name='niq_name' />
                                                                                    <attribute name='createdon' />
                                                                                    <order attribute='niq_name' descending='false' />
                                                                                    <filter type='and'>
                                                                                      <condition attribute='niq_salesorgcode' operator='eq' value='0500' />
                                                                                      <condition attribute='niq_salesorgid' operator='eq' uitype='niq_salesorg' value='{0}' />
                                                                                    </filter>
                                                                                  </entity>
                                                                                </fetch>";
                                                        salesorgQuery = string.Format(salesorgQuery, retQuoteHeader.GetAttributeValue<EntityReference>("niq_salesorgid").Id);
                                                        var salesRecords = service.RetrieveMultiple(new FetchExpression(salesorgQuery));
                                                        if (salesRecords != null && salesRecords.Entities != null && salesRecords.Entities.Count == 1)
                                                        {
                                                            isSalesOrg = true;
                                                        }
                                                        //Approval required if (Term Type = fixed term or evergreen) AND (contract duration based on Quote Start/End Date > 12 months) AND ((field value <> API for 0500 sales org OR (field value <> COLA for all other sales orgs))
                                                        if (retQuoteHeader.Attributes.Contains("niq_annualincreasetype") && retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_annualincreasetype") != null)
                                                        {
                                                            if (retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_annualincreasetype").Value == 100000000)
                                                            {
                                                                tracing.Trace("Approval required if (Term Type = fixed term or evergreen) AND (contract duration based on Quote Start/End Date > 12 months) AND ((field value <> API for 0500 sales org OR (field value <> COLA for all other sales orgs))");
                                                                isApprovalRequired = true;
                                                                approvalFields = approvalFields == null ? "Annual Increase Type" : approvalFields + "," + " Annual Increase Type";
                                                            }
                                                        }
                                                        //Approval required if (Term Type = fixed term or evergreen) AND (contract duration based on Quote Start/End Date > 12 months) AND Sales org = 0500 AND field value is <3%
                                                        if (retQuoteHeader.Attributes.Contains("niq_annualapicola") && (retQuoteHeader.GetAttributeValue<decimal>("niq_annualapicola") < 3 && isSalesOrg))
                                                        {
                                                            tracing.Trace("Approval required if (Term Type = fixed term or evergreen) AND (contract duration based on Quote Start/End Date > 12 months) AND Sales org = 0500 AND field value is <3%");
                                                            isApprovalRequired = true;
                                                            approvalFields = approvalFields == null ? "Annual API/COLA %" : approvalFields + "," + " Annual API/COLA %";
                                                        }
                                                        //Approval required if (Term Type = fixed term or evergreen) AND (contract duration based on Quote Start/End Date > 12 months) AND (field value <> "Standard")
                                                        if (retQuoteHeader.Attributes.Contains("niq_apistructure") && retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_apistructure") != null && retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_apistructure").Value != 100000003)
                                                        {
                                                            tracing.Trace("Approval required if (Term Type = fixed term or evergreen) AND (contract duration based on Quote Start/End Date > 12 months) AND (field value <> \"Standard\")");
                                                            isApprovalRequired = true;
                                                            approvalFields = approvalFields == null ? "API / COLA structure" : approvalFields + "," + " API / COLA structure";
                                                        }

                                                    }
                                                    // Approval required if Term Type <> perpetual or indefinite or fixed and entered value is less then the default value defined based on Start and End date: less than 4 months if difference between Contract Start/End Date is less than 24 Months; less than 6 months if difference between Contract Start/End Date equals or more than 24 and less than 36 months; less than 12 months if difference between contract Start / End Date is equal or more than 36 months
                                                    if (retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_termtype").Value == 100000000)
                                                    {
                                                        if (retQuoteHeader.Attributes.Contains("niq_terminationnotificationmonths"))
                                                        {
                                                            int tnm = retQuoteHeader.GetAttributeValue<int>("niq_terminationnotificationmonths");
                                                            tracing.Trace("tnm =" + tnm);
                                                            tracing.Trace("monthsdiif = " + monthsDiff);
                                                            if (monthsDiff < 24 && tnm < 4)
                                                            {
                                                                tracing.Trace("Approval required if Term Type <> perpetual or indefinite and entered value is less then the default value defined based on Start and End date: less than 4 months if difference between Contract Start/End Date is less than 24 Months; less than 6 months if difference between Contract Start/End Date equals or more than 24 and less than 36 months; less than 12 months if difference between contract Start / End Date is equal or more than 36 months");
                                                                isApprovalRequired = true;
                                                                approvalFields = approvalFields == null ? "Termination Notification(Months)" : approvalFields + "," + " Termination Notification(Months)";
                                                            }
                                                            if ((monthsDiff >= 24 && monthsDiff < 36) && tnm < 6)
                                                            {
                                                                tracing.Trace("Approval required if Term Type <> perpetual or indefinite and entered value is less then the default value defined based on Start and End date: less than 4 months if difference between Contract Start/End Date is less than 24 Months; less than 6 months if difference between Contract Start/End Date equals or more than 24 and less than 36 months; less than 12 months if difference between contract Start / End Date is equal or more than 36 months");
                                                                isApprovalRequired = true;
                                                                approvalFields = approvalFields == null ? "Termination Notification (Months)" : approvalFields + "," + " Termination Notification (Months)";
                                                            }
                                                            if (monthsDiff >= 36 && tnm < 12)
                                                            {
                                                                tracing.Trace("Approval required if Term Type <> perpetual or indefinite and entered value is less then the default value defined based on Start and End date: less than 4 months if difference between Contract Start/End Date is less than 24 Months; less than 6 months if difference between Contract Start/End Date equals or more than 24 and less than 36 months; less than 12 months if difference between contract Start / End Date is equal or more than 36 months");
                                                                isApprovalRequired = true;
                                                                approvalFields = approvalFields == null ? "Termination Notification (Months)" : approvalFields + "," + " Termination Notification (Months)";
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            //Approval required if term type = Evergreen and field value < 5%
                                            if (retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_termtype").Value == 100000000 && retQuoteHeader.Attributes.Contains("niq_evergreenautorenewalannualapi") && retQuoteHeader.GetAttributeValue<decimal>("niq_evergreenautorenewalannualapi") < 5)
                                            {
                                                tracing.Trace("Approval required if term type = Evergreen and field value < 5%");
                                                isApprovalRequired = true;
                                                approvalFields = approvalFields == null ? "Evergreen/Auto Renewal Annual API %" : approvalFields + "," + " Evergreen/Auto Renewal Annual API %";
                                            }

                                        }
                                        //Approval required when Incentive Type is not none
                                        if (retQuoteHeader.Attributes.Contains("niq_incentivetype") && retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_incentivetype") != null && retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_incentivetype").Value != 100000000)
                                        {
                                            isApprovalRequired = true;
                                            approvalFields = approvalFields == null ? "Incentive Type" : approvalFields + "," + " Incentive Type";
                                        }
                                        //Approval required when Incentive Value is not zero
                                        if (retQuoteHeader.Attributes.Contains("niq_incentivevalueniqannualimpact") && retQuoteHeader.GetAttributeValue<int>("niq_incentivevalueniqannualimpact") > 0)
                                        {
                                            isApprovalRequired = true;
                                            approvalFields = approvalFields == null ? "Incentive Value (NIQ Annual Impact)" : approvalFields + "," + " Incentive Value (NIQ Annual Impact)";
                                        }
                                        //Approval required when Link to Non-Standard Approval Requests is filled
                                        if (retQuoteHeader.Attributes.Contains("niq_linktononstandardapprovalrequests") && retQuoteHeader.GetAttributeValue<string>("niq_linktononstandardapprovalrequests") != null)
                                        {
                                            isApprovalRequired = true;
                                            approvalFields = approvalFields == null ? "Link to Non-Standard Approval Requests" : approvalFields + "," + " Link to Non-Standard Approval Requests";
                                        }
                                        //Approval Required when Customer Type on Account  and Customer Type on Quote are not equal
                                        if (retQuoteHeader.Attributes.Contains("customerid") && retQuoteHeader.GetAttributeValue<EntityReference>("customerid").Id != Guid.Empty)
                                        {
                                            Guid accountId = retQuoteHeader.GetAttributeValue<EntityReference>("customerid").Id;
                                            QueryExpression accountQuery = new QueryExpression("account");
                                            accountQuery.TopCount = 1;
                                            accountQuery.ColumnSet.AddColumns("niq_customertype");
                                            accountQuery.Criteria.AddCondition("accountid", ConditionOperator.Equal, accountId);
                                            var accountRecords = service.RetrieveMultiple(accountQuery);
                                            if (accountRecords != null && accountRecords.Entities != null && accountRecords.Entities.Count > 0)
                                            {
                                                foreach (Entity record in accountRecords.Entities)
                                                {

                                                    if (record.Attributes.Contains("niq_customertype") && record.GetAttributeValue<OptionSetValue>("niq_customertype") != null && retQuoteHeader.Attributes.Contains("niq_customertype") && retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_customertype") != null && record.GetAttributeValue<OptionSetValue>("niq_customertype").Value != retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_customertype").Value)
                                                    {
                                                        tracing.Trace("Approval Required when Customer Type on Account  and Customer Type on Quote are not equal");
                                                        isApprovalRequired = true;
                                                        approvalFields = approvalFields == null ? "Customer Type" : approvalFields + "," + " Customer Type";
                                                        break;
                                                    }
                                                    else if (!record.Attributes.Contains("niq_customertype") && retQuoteHeader.Attributes.Contains("niq_customertype"))
                                                    {
                                                        tracing.Trace("Approval Required when Customer Type on Account  and Customer Type on Quote are not equal");
                                                        isApprovalRequired = true;
                                                        approvalFields = approvalFields == null ? "Customer Type" : approvalFields + "," + " Customer Type";
                                                        break;
                                                    }
                                                    else if (record.Attributes.Contains("niq_customertype") && !retQuoteHeader.Attributes.Contains("niq_customertype"))
                                                    {
                                                        tracing.Trace("Approval Required when Customer Type on Account  and Customer Type on Quote are not equal");
                                                        isApprovalRequired = true;
                                                        approvalFields = approvalFields == null ? "Customer Type" : approvalFields + "," + " Customer Type";
                                                        break;
                                                    }

                                                }
                                            }
                                        }


                                        //Approval Required if value >0
                                        if (retQuoteHeader.Attributes.Contains("niq_numberofftes") && retQuoteHeader.GetAttributeValue<decimal>("niq_numberofftes") > 0)
                                        {
                                            tracing.Trace("Approval Required if value of fte >0");
                                            isApprovalRequired = true;
                                            approvalFields = approvalFields == null ? "Number of FTEs" : approvalFields + "," + " Number of FTEs";
                                        }
                                        //Approval Required if value is less than 1.5%
                                        if (retQuoteHeader.Attributes.Contains("niq_interestrateonlatepayment") && retQuoteHeader.GetAttributeValue<decimal>("niq_interestrateonlatepayment") < 1.50M)
                                        {
                                            tracing.Trace("Approval Required if value of niq_interestrateonlatepayment <1.50");
                                            isApprovalRequired = true;
                                            approvalFields = approvalFields == null ? "Late Payment Penalty Fee in %" : approvalFields + "," + " Late Payment Penalty Fee in %";
                                        }
                                        if (retQuoteHeader.Attributes.Contains("niq_nonstandardbillingterm") && retQuoteHeader.GetAttributeValue<bool>("niq_nonstandardbillingterm"))
                                        {
                                            tracing.Trace("Approval Required if value of niq_nonstandardbillingterm is true");
                                            isApprovalRequired = true;
                                            approvalFields = approvalFields == null ? "Non-Standard Billing term" : approvalFields + "," + " Non-Standard Billing term";
                                        }
                                        //Approval Required if value is different from NM01, ND14, ND00, ND20, ND15, ND21, ND10, ND28, ND05 and ND07
                                        //if (retQuoteHeader.Attributes.Contains("niq_paymenttermsid"))
                                        //{
                                        //    Guid paymenttermId = retQuoteHeader.GetAttributeValue<EntityReference>("niq_paymenttermsid").Id;
                                        //    QueryExpression paymenttermQuery = new QueryExpression("niq_paymentterm");
                                        //    paymenttermQuery.TopCount = 1;
                                        //    paymenttermQuery.ColumnSet.AddColumns("niq_paymenttermcode");
                                        //    paymenttermQuery.Criteria.AddCondition("niq_paymenttermid", ConditionOperator.Equal, paymenttermId);
                                        //    EntityCollection paymenttermRecords = service.RetrieveMultiple(paymenttermQuery);
                                        //    foreach (Entity record in paymenttermRecords.Entities)
                                        //    {
                                        //        if (record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "NM01" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND14" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND00" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND20" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND15" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND21" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND10" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND28" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND05" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND07")
                                        //        {
                                        //            tracing.Trace("Approval Required if value is different from NM01, ND14, ND00, ND20, ND15, ND21, ND10, ND28, ND05 and ND07");
                                        //            isApprovalRequired = true;
                                        //            break;
                                        //        }

                                        //    }
                                        //}
                                        //Approval Required if Agreement payment term days is greater than MSA payment term days and greater than 30 days - DYNCRM-2373
                                        if (retQuoteHeader.Attributes.Contains("niq_paymenttermsid"))
                                        {
                                            tracing.Trace("line no 487");
                                            if (!retQuoteHeader.Attributes.Contains("niq_msapaymentterm") || retQuoteHeader.Attributes["niq_msapaymentterm"] == null)
                                            {
                                                tracing.Trace("line no 490");
                                                Guid paymenttermId = retQuoteHeader.GetAttributeValue<EntityReference>("niq_paymenttermsid").Id;
                                                QueryExpression paymenttermQuery = new QueryExpression("niq_paymentterm");
                                                paymenttermQuery.TopCount = 1;
                                                paymenttermQuery.ColumnSet.AddColumns("niq_paymenttermcode", "niq_paymenttermsindays");
                                                paymenttermQuery.Criteria.AddCondition("niq_paymenttermid", ConditionOperator.Equal, paymenttermId);
                                                EntityCollection paymenttermRecords = service.RetrieveMultiple(paymenttermQuery);
                                                foreach (Entity record in paymenttermRecords.Entities)
                                                {
                                                    //if (record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "NM01" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND14" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND00" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND20" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND15" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND21" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND10" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND28" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND05" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND07")
                                                    //{
                                                    //    tracing.Trace("Approval Required if value is different from NM01, ND14, ND00, ND20, ND15, ND21, ND10, ND28, ND05 and ND07");
                                                    //    isApprovalRequired = true;
                                                    //    break;
                                                    //}
                                                    int paymenttermsindays = record.GetAttributeValue<int>("niq_paymenttermsindays");
                                                    tracing.Trace("PaymentTermsDays :" + paymenttermsindays);
                                                    if (record.Attributes.Contains("niq_paymenttermsindays") && record.GetAttributeValue<int>("niq_paymenttermsindays") > 30)
                                                    {
                                                        tracing.Trace("Approval required if MSA payment term is null and Agreement paymant days is grater than 30 days");
                                                        //isApprovalRequired = true;
                                                        approvalFields = approvalFields == null ? "Agreement Payment Terms" : approvalFields + "," + " Agreement Payment Terms";
                                                        //updQuote["niq_dealdeskapproval"] = new OptionSetValue(100000002);//approval required
                                                    }
                                                    /*else if (paymenttermsindays <= 30)
                                                    {
                                                        tracing.Trace("Line no 516");
                                                        updQuote["niq_dealdeskapproval"] = new OptionSetValue(100000003);//approval required
                                                        updQuote["niq_quoteheaderdetailsapproval"] = new OptionSetValue(3); // approval required
                                                    }

                                                }
                                            }
                                            else
                                            {
                                                tracing.Trace("512");
                                                int msapaymenttermsindays = 0;
                                                int paymenttermsindays = 0;
                                                // Get Agreement Payment terms days
                                                if (retQuoteHeader.Attributes.Contains("niq_paymenttermsid"))
                                                {
                                                    Guid getpaymenttermId = retQuoteHeader.GetAttributeValue<EntityReference>("niq_paymenttermsid").Id;
                                                    QueryExpression pQuery = new QueryExpression("niq_paymentterm");
                                                    pQuery.NoLock = true;
                                                    pQuery.TopCount = 1;
                                                    pQuery.ColumnSet.AddColumns("niq_paymenttermid", "niq_paymenttermsindays");
                                                    pQuery.Criteria.AddCondition("niq_paymenttermid", ConditionOperator.Equal, getpaymenttermId);
                                                    //ddarQuery.Criteria.AddCondition("niq_quoteid", ConditionOperator.Equal, retQuote.Id);
                                                    var resultp = service.RetrieveMultiple(pQuery);
                                                    foreach (Entity record in resultp.Entities)
                                                    {
                                                        paymenttermsindays = record.GetAttributeValue<int>("niq_paymenttermsindays");
                                                    }
                                                }
                                                // Get MSA Payment terms days
                                                if (retQuoteHeader.Attributes.Contains("niq_msapaymentterm"))
                                                {

                                                    Guid getmsapaymenttermId = retQuoteHeader.GetAttributeValue<EntityReference>("niq_msapaymentterm").Id;
                                                    QueryExpression msapQuery = new QueryExpression("niq_paymentterm");
                                                    msapQuery.NoLock = true;
                                                    msapQuery.TopCount = 1;
                                                    msapQuery.ColumnSet.AddColumns("niq_paymenttermid");
                                                    msapQuery.ColumnSet.AddColumns("niq_paymenttermsindays");
                                                    msapQuery.Criteria.AddCondition("niq_paymenttermid", ConditionOperator.Equal, getmsapaymenttermId);
                                                    //ddarQuery.Criteria.AddCondition("niq_quoteid", ConditionOperator.Equal, retQuote.Id);
                                                    var resultmsap = service.RetrieveMultiple(msapQuery);
                                                    foreach (Entity record in resultmsap.Entities)
                                                    {
                                                        msapaymenttermsindays = record.GetAttributeValue<int>("niq_paymenttermsindays");
                                                    }
                                                }

                                                if (msapaymenttermsindays < paymenttermsindays && paymenttermsindays > 30)
                                                {
                                                    tracing.Trace("Approval required if Agreement Payment term days is greater than MSA payment term days and Agreement payment term days greater than 30 days");
                                                    //isApprovalRequired = true;
                                                    //tracing.Trace("isApprovalRequired line no 568 : " + isApprovalRequired);
                                                    approvalFields = approvalFields == null ? "Agreement Payment Terms" : approvalFields + "," + " Agreement Payment Terms";
                                                    //updQuote["niq_dealdeskapproval"] = new OptionSetValue(100000002);//approval required
                                                    //updQuote["niq_quoteheaderdetailsapproval"] = new OptionSetValue(2); // approval required


                                                }
                                                /* //DYNCRM-21385
                                                else if (msapaymenttermsindays >= paymenttermsindays && paymenttermsindays < 30)
                                                {
                                                    tracing.Trace("paymentermsindays: " + paymenttermsindays);

                                                    isApprovalRequired = false;
                                                    tracing.Trace("Is Approval required 580 :" + isApprovalRequired);
                                                    updQuote["niq_dealdeskapproval"] = new OptionSetValue(100000003);// No approval required

                                                }
                                                else if (msapaymenttermsindays >= paymenttermsindays && paymenttermsindays > 30)
                                                {
                                                    tracing.Trace("Line no 588");
                                                    updQuote["niq_dealdeskapproval"] = new OptionSetValue(100000002);//approval required
                                                    isApprovalRequired = true;
                                                    tracing.Trace("isApprovalRequired line no 589 : " + isApprovalRequired);
                                                }
                                                else if (msapaymenttermsindays >= paymenttermsindays && paymenttermsindays <= 30)
                                                {
                                                    tracing.Trace("Line no 592");
                                                    updQuote["niq_dealdeskapproval"] = new OptionSetValue(100000003);// No approval required
                                                    isApprovalRequired = false;
                                                    tracing.Trace("isApprovalRequired line no 596 : " + isApprovalRequired);
                                                }
                                                else if (msapaymenttermsindays < paymenttermsindays && paymenttermsindays <= 30)
                                                {
                                                    tracing.Trace("Line no 600");
                                                    updQuote["niq_dealdeskapproval"] = new OptionSetValue(100000003);//No approval required
                                                    tracing.Trace("isApprovalRequired : " + isApprovalRequired);
                                                    isApprovalRequired = false;
                                                    tracing.Trace("isApprovalRequired line no 604 : " + isApprovalRequired);
                                                }
                                                
                                                //According to Irina we will consider below case later
                                                /*else if (retQuoteHeader.Attributes.Contains("niq_modeleddayssalesoutstanding") && retQuoteHeader["niq_modeleddayssalesoutstanding"] != null)
                                                {

                                                    var modeleddayssalesoutstanding = retQuoteHeader.GetAttributeValue<string>("niq_modeleddayssalesoutstanding");
                                                    int msapaymenttermdays = retQuoteHeader.GetAttributeValue<int>("niq_msapaymenttermdays");
                                                    int modeldayssales = int.Parse(modeleddayssalesoutstanding);

                                                    tracing.Trace("modeldayssales");
                                                    tracing.Trace("msapaymenttermdays :" + msapaymenttermdays);
                                                    tracing.Trace("modeldayssales :" + modeldayssales);
                                                    tracing.Trace("modeldayssales > msapaymenttermdays : " + (modeldayssales > msapaymenttermdays));
                                                    tracing.Trace("modeldayssales <= msapaymenttermdays : " + (modeldayssales <= msapaymenttermdays));

                                                    if (retQuoteHeader.Attributes.Contains("niq_paymenttermsid"))
                                                    {
                                                            if(paymenttermsindays > 30)
                                                            {
                                                                tracing.Trace("lineno no 580");
                                                                tracing.Trace("tracing" + retQuoteHeader.Attributes.Contains("niq_dealdeskapproval"));
                                                                //int pricingOption = retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_dealdeskapproval").Value;
                                                                tracing.Trace("Approval Required if value is different from NM01, ND14, ND00, ND20, ND15, ND21, ND10, ND28, ND05 and ND07");

                                                                // Determine if approval is required based on conditions
                                                                bool isDealDeskApprovalRequired = modeldayssales > msapaymenttermdays;
                                                                                                      
                                                                tracing.Trace("isDealDeskApprovalRequired :" + isDealDeskApprovalRequired);

                                                                // Determine if no approval is required based on conditions
                                                                bool isNoDealDeskApprovalRequired = modeldayssales <= msapaymenttermdays;
                                                                                                        
                                                                
                                                                tracing.Trace("isNoDealDeskApprovalRequired :" + isNoDealDeskApprovalRequired);

                                                                if (isDealDeskApprovalRequired)
                                                                {
                                                                    tracing.Trace("Approval Required Line 610");

                                                                    updQuote["niq_dealdeskapproval"] = new OptionSetValue(100000002); // approval required
                                                                    updQuote["niq_quoteheaderdetailsapproval"] = new OptionSetValue(2); // approval required
                                                                }
                                                                else if (isNoDealDeskApprovalRequired)
                                                                {
                                                                    tracing.Trace("No Approval Required as model days are less and eq to MSA payment terms days");
                                                                    tracing.Trace("MSApayment term days are greater and equal");
                                                                    updQuote["niq_dealdeskapproval"] = new OptionSetValue(100000003); // No approval required
                                                                }
                                                                else
                                                                {
                                                                    // Handle cases where none of the conditions are met
                                                                    tracing.Trace("Conditions for approval or non-approval are not met.");
                                                                } 
                                                            

                                                            }
                                                            else
                                                            {
                                                                tracing.Trace("else if: standadrd Agreement Payement termso no approval req ");
                                                               
                                                                updQuote["niq_dealdeskapproval"] = new OptionSetValue(100000003);//no approval required.
                                                         
                                                            }

                                                    }

                                                }


                                            }
                                        }
                                        // Approval Required if Quote Default Billing Frequency contains Lag
                                        if (retQuoteHeader.Attributes.Contains("niq_quotedefaultperiodicbillingfrequency"))
                                        {
                                            var billFrequency = retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_quotedefaultperiodicbillingfrequency").Value;
                                            if (billFrequency == 100000006 || billFrequency == 100000007 || billFrequency == 100000008)
                                            {
                                                tracing.Trace("Approval required if Quote default periodic billing frequency contains lag");
                                                isApprovalRequired = true;
                                                approvalFields = approvalFields == null ? "Quote Default Periodic Billing Frequency" : approvalFields + "," + " Quote Default Periodic Billing Frequency";
                                            }

                                        }*/

                                        tracing.Trace("niq_discount quoteobj: " + quoteObj.Contains("niq_discount"));
                                        tracing.Trace("niq_discount retquoteheader: " + retQuoteHeader.Contains("niq_discount"));
                                        tracing.Trace("total amount retquoteheader: " + retQuoteHeader.Contains("totalamount"));
                                        tracing.Trace("isApprovalRequired : " + isApprovalRequired);


                                        if (!isApprovalRequired && (retQuoteHeader.Contains("niq_discount") || retQuoteHeader.Contains("totalamount") || retQuoteHeader.Contains("niq_overalldealscore")))
                                        {
                                            tracing.Trace("Discount contains data.");


                                            QueryExpression ddarQuery = new QueryExpression("niq_dealdeskapprovalrequest")
                                            {
                                                TopCount = 1,
                                                ColumnSet = new ColumnSet("niq_approvalstatus", "niq_reapprovalforanydiscountchange", "niq_lastapprovedoveralldealscore", "niq_totalamount", "niq_discount", "niq_lastapprovedoveralldealscore"),
                                                Orders =
                                            {
                                                new OrderExpression("createdon", OrderType.Descending) // Sorting by creation date in descending order
                                            }
                                            };

                                            ddarQuery.Criteria.AddCondition("statecode", ConditionOperator.Equal, 1); // Approved record will be InActive.
                                            ddarQuery.Criteria.AddCondition("niq_quoteid", ConditionOperator.Equal, quoteObj.Id);

                                            var resultDDAR = service.RetrieveMultiple(ddarQuery);
                                            tracing.Trace("Fetched niq_dealdeskapprovalrequest records: {0}", resultDDAR.Entities.Count);

                                            if (resultDDAR != null && resultDDAR.Entities.Count > 0)
                                            {
                                                tracing.Trace("we have one ddar");
                                                Entity ddarEntity = resultDDAR.Entities.FirstOrDefault();

                                                // Check if "niq_approvalstatus" is "4" and "niq_ReapprovalwillbeneededforanyDiscountchan" is "Yes"
                                                if (ddarEntity != null
                                                    && ddarEntity.GetAttributeValue<OptionSetValue>("niq_approvalstatus")?.Value == 4
                                                    && ddarEntity.GetAttributeValue<bool>("niq_reapprovalforanydiscountchange"))
                                                {
                                                    tracing.Trace("ddar is aproved and niq_reapprovalforanydiscountchange == yes");

                                                    tracing.Trace("quote discount : " + (retQuoteHeader.Attributes.Contains("niq_discount") ? retQuoteHeader["niq_discount"] : "no value"));
                                                    tracing.Trace("ddar  discount : " + (ddarEntity.Attributes.Contains("niq_discount") ? ddarEntity["niq_discount"] : "no value"));

                                                    tracing.Trace("quote amount : " + (retQuoteHeader.Attributes.Contains("totalamount") ? retQuoteHeader.GetAttributeValue<Money>("totalamount").Value.ToString() : "no value"));
                                                    tracing.Trace("ddar  amount  : " + (ddarEntity.Attributes.Contains("niq_totalamount") ? ddarEntity.GetAttributeValue<Money>("niq_totalamount").Value.ToString() : "no value"));
                                                    tracing.Trace("quote  overall score  : " + (retQuoteHeader.Attributes.Contains("niq_overalldealscore") ? retQuoteHeader["niq_overalldealscore"] : "no value"));
                                                    tracing.Trace("ddar  overall score  : " + (retQuoteHeader.Attributes.Contains("niq_lastapprovedoveralldealscore") ? retQuoteHeader["niq_lastapprovedoveralldealscore"] : "no value"));


                                                    if (
                                                        (retQuoteHeader.Attributes.Contains("niq_discount") && ddarEntity.Attributes.Contains("niq_discount") && retQuoteHeader.GetAttributeValue<decimal>("niq_discount") != ddarEntity.GetAttributeValue<decimal>("niq_discount")) ||
                                                        (retQuoteHeader.Attributes.Contains("totalamount") && ddarEntity.Attributes.Contains("niq_totalamount") && retQuoteHeader.GetAttributeValue<Money>("totalamount").Value != ddarEntity.GetAttributeValue<Money>("niq_totalamount").Value) ||
                                                        (retQuoteHeader.Attributes.Contains("niq_discount") && !ddarEntity.Attributes.Contains("niq_discount")) ||
                                                        (!retQuoteHeader.Attributes.Contains("niq_discount") && ddarEntity.Attributes.Contains("niq_discount")) ||
                                                        (retQuoteHeader.Attributes.Contains("niq_overalldealscore") && ddarEntity.Attributes.Contains("niq_lastapprovedoveralldealscore") && retQuoteHeader.GetAttributeValue<string>("niq_overalldealscore") != ddarEntity.GetAttributeValue<string>("niq_lastapprovedoveralldealscore")) ||
                                                        (retQuoteHeader.Attributes.Contains("niq_overalldealscore") && !ddarEntity.Attributes.Contains("niq_lastapprovedoveralldealscore")) ||
                                                        (!retQuoteHeader.Attributes.Contains("niq_overalldealscore") && ddarEntity.Attributes.Contains("niq_lastapprovedoveralldealscore"))
                                                        )

                                                    {
                                                        tracing.Trace("Something got changed - approval required");
                                                        isApprovalRequired = true;

                                                    }

                                                }
                                            }

                                        }


                                        tracing.Trace("isapproval " + isApprovalRequired);

                                        if (isApprovalRequired)
                                        {
                                            tracing.Trace("approval required");
                                            updQuote["niq_quoteheaderdetailsapproval"] = new OptionSetValue(2);
                                            update = true;
                                        }
                                        //else
                                        //{
                                            /*Guid paymenttermId = retQuoteHeader.GetAttributeValue<EntityReference>("niq_paymenttermsid").Id;
                                            QueryExpression paymenttermQuery = new QueryExpression("niq_paymentterm");
                                            paymenttermQuery.TopCount = 1;
                                            paymenttermQuery.ColumnSet.AddColumns("niq_paymenttermcode");
                                            paymenttermQuery.Criteria.AddCondition("niq_paymenttermid", ConditionOperator.Equal, paymenttermId);
                                            EntityCollection paymenttermRecords = service.RetrieveMultiple(paymenttermQuery);
                                            tracing.Trace("Agreementpaymentterm");
                                            tracing.Trace("count " + paymenttermRecords.Entities.Count);
                                            foreach (Entity record in paymenttermRecords.Entities)
                                            {
                                                tracing.Trace("foreach");
                                                bool nonstandard1 = record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "NM01" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND00" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND05" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND07" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND10" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND14" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND15" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND21" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND28";
                                                tracing.Trace("bool value :" + nonstandard1);
                                                if(!nonstandard1)
                                                {
                                                    tracing.Trace("quoteheaderdetails No approval required line 748");
                                                    updQuote["niq_quoteheaderdetailsapproval"] = new OptionSetValue(3);
                                                    updQuote["niq_dealdeskapproval"] = new OptionSetValue(100000003);
                                                }
                                            }*/
                                            //DYNCRM-31243
                                            //    tracing.Trace("No Approval required");
                                            //    tracing.Trace("line no 791");

                                            //    updQuote["niq_quoteheaderdetailsapproval"] = new OptionSetValue(3);

                                            //    updQuote["niq_fieldsrequiringapproval"] = null;
                                            //    update = true;
                                            //}
                                        }
                                    }
                            }

                            if (quoteObj != null && quoteObj.Id != Guid.Empty && (quoteObj.Attributes.Contains("niq_dealdeskapproval") || quoteObj.Attributes.Contains("niq_fundusageapproval") || quoteObj.Attributes.Contains("niq_quoteheaderdetailsapproval")))
                            {
                                tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: Update from DealDesk");


                                string fetchQuoteNRPDD = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='quotedetail'>
                                                        <attribute name='productdescription' />
                                                        <attribute name='quotedetailname' />
                                                        <attribute name='quotedetailid' />
                                                        <order attribute='niq_brandid' descending='false' />
                                                        <filter type='and'>
                                                          <condition attribute='quoteid' operator='eq' uitype='quote' value='{0}' />
                                                          <condition attribute='isproductoverridden' operator='eq' value='1' />
                                                          <condition attribute='productdescription' operator='eq' value='Place Holder Product' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";
                                fetchQuoteNRPDD = string.Format(fetchQuoteNRPDD, quoteObj.Id);
                                var resultQuoteNRPDD = service.RetrieveMultiple(new FetchExpression(fetchQuoteNRPDD));
                                if (resultQuoteNRPDD != null && resultQuoteNRPDD.Entities != null && resultQuoteNRPDD.Entities.Count > 0)
                                {
                                    tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: Getting the placeholder Prod");
                                    //If at least one placeholder product is present on the quote, set to "Remove placeholder product". This logical condition only relates to Placeholder product and not "SAP deferred revenue reconciliation product"

                                    updQuote["niq_overalldealdeskapproval"] = new OptionSetValue(1);
                                    update = true;
                                }
                                else
                                {
                                    tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: does not contain Placeholder Prod");

                                    // When placeholder product is not present, run the following logic:
                                    Entity retQuoteDD = service.Retrieve(quoteObj.LogicalName, quoteObj.Id, new ColumnSet("niq_dealdeskapproval", "niq_fundusageapproval", "niq_quoteheaderdetailsapproval", "niq_overalldealdeskapproval"));

                                    if (retQuoteDD != null && retQuoteDD.Id != Guid.Empty && retQuoteDD.Attributes.Contains("niq_dealdeskapproval") && retQuoteDD.Attributes.Contains("niq_fundusageapproval") && retQuoteDD.Attributes.Contains("niq_quoteheaderdetailsapproval"))
                                    {
                                        bool isSubmitted = false;
                                        var pricingApproval = retQuote.GetAttributeValue<OptionSetValue>("niq_dealdeskapproval").Value;
                                        var fundUsage = retQuote.GetAttributeValue<OptionSetValue>("niq_fundusageapproval").Value;
                                        var quoteHeader = retQuote.GetAttributeValue<OptionSetValue>("niq_quoteheaderdetailsapproval").Value;

                                        QueryExpression ddarQuery = new QueryExpression("niq_dealdeskapprovalrequest");
                                        ddarQuery.NoLock = true;
                                        ddarQuery.TopCount = 1;
                                        ddarQuery.ColumnSet.AddColumns("niq_dealdeskapprovalrequestid");
                                        ddarQuery.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
                                        ddarQuery.Criteria.AddCondition("niq_quoteid", ConditionOperator.Equal, retQuote.Id);
                                        var resultDDAR = service.RetrieveMultiple(ddarQuery);
                                        if (resultDDAR != null && resultDDAR.Entities != null && resultDDAR.Entities.Count > 0 && resultDDAR.Entities.FirstOrDefault().Id != Guid.Empty)
                                        {
                                            Entity updDDAR = new Entity(resultDDAR.Entities.FirstOrDefault().LogicalName, resultDDAR.Entities.FirstOrDefault().Id);
                                            updDDAR["niq_pricingapproval"] = new OptionSetValue(pricingApproval);
                                            updDDAR["niq_fundusageapproval"] = new OptionSetValue(fundUsage);
                                            updDDAR["niq_quoteheaderdetailsapproval"] = new OptionSetValue(quoteHeader);
                                            service.Update(updDDAR);
                                            if (retQuote.Attributes.Contains("niq_overalldealdeskapproval") && retQuote.GetAttributeValue<OptionSetValue>("niq_overalldealdeskapproval").Value == 7)
                                            {
                                                tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: is submitted = true");
                                                isSubmitted = true;
                                            }
                                        }

                                        tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: isSubmitted" + isSubmitted);
                                        //In case approval status = "To be determined" for at least one of the 3 approval fields (pricing, fund or quote header), Deal Desk Approval should equal to "To be determined" as well.
                                        if (!isSubmitted && (pricingApproval == 100000000 || fundUsage == 1 || quoteHeader == 1))
                                        {
                                            tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk://In case approval status = \"To be determined\" for at least one of the 3 approval fields (pricing, fund or quote header), Deal Desk Approval should equal to \"To be determined\" as well.");
                                            update = true;
                                            updQuote["niq_overalldealdeskapproval"] = new OptionSetValue(2);
                                        }
                                        //In case pricing approval status = Segment Lead Approval Required and (Fund Usage Approval and Quote Header details approval = No approval required or approved) => set Overall Deal Desk Approval to Segment Lead Approval Required
                                        else if (!isSubmitted && pricingApproval == 100000001 && ((fundUsage == 3 && quoteHeader == 3) || (fundUsage == 4 && quoteHeader == 4) || (fundUsage == 3 && quoteHeader == 4) || (fundUsage == 4 && quoteHeader == 3)))
                                        {
                                            tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk://In case pricing approval status = Segment Lead Approval Required and (Fund Usage Approval and Quote Header details approval = No approval required or approved) => set Overall Deal Desk Approval to Segment Lead Approval Required");
                                            update = true;
                                            updQuote["niq_overalldealdeskapproval"] = new OptionSetValue(3);
                                        }
                                        //In case pricing approval status = Segment Lead Approval Required and (Fund Usage Approval OR Quote Header details approval = approval required) => set Overall Deal Desk Approval to Approval Required
                                        else if (!isSubmitted && pricingApproval == 100000001 && (fundUsage == 2 || quoteHeader == 2))
                                        {
                                            tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk:In case pricing approval status = Segment Lead Approval Required and (Fund Usage Approval OR Quote Header details approval = approval required) => set Overall Deal Desk Approval to Approval Required");
                                            update = true;
                                            updQuote["niq_overalldealdeskapproval"] = new OptionSetValue(4);
                                        }
                                        // In case any of the 3 fields equal to "Rejected", set Overall Deal Desk status to Rejected
                                        else if (!isSubmitted && pricingApproval == 100000005 || fundUsage == 5)
                                        {
                                            tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: In case any of the 3 fields equal to \"Rejected\", set Overall Deal Desk status to Rejected");
                                            update = true;
                                            updQuote["niq_overalldealdeskapproval"] = new OptionSetValue(8);
                                        }
                                        //In case any of the 3 fields equal to "Approval Required" and none of them equal to "Rejected" or "to be determined", set Deal Desk status to "Approval required"
                                        else if (!isSubmitted && ((pricingApproval == 100000002 && (fundUsage != 5 && fundUsage != 1 && quoteHeader != 1)) || ((pricingApproval != 100000005 && fundUsage != 5 && pricingApproval != 100000000 && fundUsage != 1) && quoteHeader == 2) || (fundUsage == 2 && (pricingApproval != 100000005 && quoteHeader != 5 && pricingApproval != 100000000 && quoteHeader != 1))))
                                        {
                                            tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk:In case any of the 3 fields equal to Approval Required and none of them equal to Rejected or to be determined, set Deal Desk status to Approval required");
                                            update = true;
                                            updQuote["niq_overalldealdeskapproval"] = new OptionSetValue(4);//approved required
                                        }
                                        // In case all 3 fields = "No approval required" => set value to "No approval required"
                                        else if (!isSubmitted && ((pricingApproval == 100000003 || pricingApproval == 100000006) && fundUsage == 3 && quoteHeader == 3))
                                        {
                                            tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: In case all 3 fields = \"No approval required\" => set value to \"No approval required\"");
                                            update = true;
                                            updQuote["niq_overalldealdeskapproval"] = new OptionSetValue(5);
                                        }
                                        //In case at least one field equals "Approved" and other equal to "No approval required" => set value to "Approved"
                                        else if (!isSubmitted && ((pricingApproval == 100000004 && fundUsage == 3 && quoteHeader == 3) || (pricingApproval == 100000006 && fundUsage == 4 && quoteHeader == 3) || (pricingApproval == 100000003 && fundUsage == 4 && quoteHeader == 3) || (pricingApproval == 100000006 && fundUsage == 3 && quoteHeader == 4) || (pricingApproval == 100000003 && fundUsage == 3 && quoteHeader == 4) || (pricingApproval == 100000004 && fundUsage == 4 && quoteHeader == 4) || (pricingApproval == 100000004 && fundUsage == 4 && quoteHeader == 3) || (pricingApproval == 100000004 && fundUsage == 3 && quoteHeader == 4) || (pricingApproval == 100000006 && fundUsage == 4 && quoteHeader == 4) || (pricingApproval == 100000003 && fundUsage == 4 && quoteHeader == 4)))
                                        {
                                            tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: In case at least one field equals \"Approved\" and other equal to \"No approval required\" => set value to \"Approved\"");
                                            update = true;
                                            updQuote["niq_overalldealdeskapproval"] = new OptionSetValue(6);//Approved
                                        }




                                    }
                                }

                            }

                            decimal quoteDiscount = quoteObj.GetAttributeValue<decimal>("niq_discount");
                            //This if block will execute when the opportunity is a Rev Share Opportunity and the total amount is less than the Rate Card Price. In this case, set the pricing approval to 'Approval Required.'
                            if (quoteObj.Attributes.Contains("totalamount") || quoteObj.Attributes.Contains("niq_ratecardprice"))

                            {
                                tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: Inside Rev Share Opportunity functionlity");
                                //Get Post Image
                                Entity postImage = (Entity)context.PostEntityImages["PostImage"];

                                //Retrieve new value of Rate Card Price ,Total Amount, Pricing Approval              
                                // Money rateCardPrice = postImage.Contains("niq_ratecardprice") && postImage.GetAttributeValue<Money>("niq_ratecardprice") != null ? postImage.GetAttributeValue<Money>("niq_ratecardprice") : new Money(0);
                                decimal? rateCardPrice = postImage.Contains("niq_ratecardprice") && postImage.GetAttributeValue<Money>("niq_ratecardprice") != null ? postImage.GetAttributeValue<Money>("niq_ratecardprice")?.Value : -1;
                                tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: rateCardPrice-" + rateCardPrice);
                                //Money totalAmount = postImage.Contains("totalamount") ? postImage.GetAttributeValue<Money>("totalamount") : new Money(0);
                                decimal? totalAmount = postImage.Contains("totalamount") && postImage.GetAttributeValue<Money>("totalamount") != null ? postImage.GetAttributeValue<Money>("totalamount")?.Value : -1;
                                tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: totalAmount-" + totalAmount);
                                int pricingApprovalVal = postImage.Contains("niq_dealdeskapproval") && postImage.Attributes["niq_dealdeskapproval"] != null ? postImage.GetAttributeValue<OptionSetValue>("niq_dealdeskapproval").Value : 0;
                                //tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: pricingApprovalVal-" + pricingApprovalVal);
                                tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: pricingApprovalVal-Hi");

                                if (rateCardPrice != -1 || totalAmount != -1)
                                {
                                    //pricingApprovalVal not eq "Rejected" or "Approved" or "Approval Required"  
                                    if ((pricingApprovalVal > 0 && (pricingApprovalVal != 100000005 || pricingApprovalVal != 100000004 || pricingApprovalVal != 100000002)) || pricingApprovalVal == 0)
                                    {
                                        tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: pricingApprovalVal Validated:" + pricingApprovalVal);
                                        tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: pricingApprovalVal Validated and need to update ");
                                        //revenue share deal eq "Yes"
                                        string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='opportunity'>
                                                      <attribute name='opportunityid' />
                                                        <filter type='and'>
                                                          <condition attribute='niq_mainquoteid' operator='eq' value='{" + quoteObj.Id + @"}' />
                                                          <condition attribute='niq_revenuesharedeal' operator='eq' value='1' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";
                                        // Execute FetchXML
                                        EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetchXml));
                                        //IC-POC #24192_B
                                        tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: is rev share check result :  " + result.Entities.Count);
                                        if (result.Entities.Count > 0)
                                        {
                                            tracing.Trace("Rev Share deal = Yes");
                                            //Check if amount deviation
                                            //DYNCRM-30797 -When removing QP and making the child opp lost there's a change in totalamount and ratecard price, if totalAmount < rateCardPrice, it makes Approval Required.
                                            //When Discount is null don't make it approval required as per DDAR logic
                                            if (totalAmount < rateCardPrice && quoteDiscount != 0m)
                                            {
                                                tracing.Trace("Total amount deviation is present and discount is not null");
                                                tracing.Trace("Updating the Pricing Approval..");
                                                updQuote["niq_dealdeskapproval"] = new OptionSetValue(100000002); // Approval Required
                                                update = true;
                                                tracing.Trace("Updated the Pricing Approval successfully..");
                                            }
                                            else if (totalAmount < rateCardPrice && quoteDiscount == 0m)
                                            {
                                                tracing.Trace("Total amount deviation is present and discount is null");
                                                tracing.Trace("No Update to the Pricing Approval");
                                            }
                                            else
                                            {
                                                tracing.Trace("No total amount deviation");
                                                if (pricingApprovalVal == 100000000) // To be determined
                                                {
                                                    updQuote["niq_dealdeskapproval"] = new OptionSetValue(100000003); // No Approval Required
                                                    update = true;
                                                    tracing.Trace("Updated the Pricing Approval as No Approval Required..");
                                                }
                                            }
                                            //IC-POC #24192_E
                                        }
                                    }
                                }
                            }
                        }

                            if (update)
                        {
                            // Check if opp is host
                            EntityReference opportunityRef = retQuote.GetAttributeValue<EntityReference>("opportunityid");
                            if (opportunityRef != null)
                            {
                                Entity opp = service.Retrieve(opportunityRef.LogicalName, opportunityRef.Id, new ColumnSet("niq_ishostopportunity"));
                                if (opp != null && opp.Id != Guid.Empty &&
                                    opp.Attributes.Contains("niq_ishostopportunity") &&
                                    opp.GetAttributeValue<bool>("niq_ishostopportunity") == true)
                                {
                                    tracing.Trace("update: niq_ishostopportunity is true");
                                    service.Update(updQuote);

                                }

                                tracing.Trace("932");
                                // Check if opp is child
                                if (opp != null && opp.Id != Guid.Empty &&
                                    opp.Attributes.Contains("niq_ishostopportunity") &&
                                    opp.GetAttributeValue<bool>("niq_ishostopportunity") == false)
                                {
                                    tracing.Trace("938");
                                    Entity opportunity = service.Retrieve(opportunityRef.LogicalName, opportunityRef.Id, new ColumnSet("niq_hostopportunity"));
                                    if (opportunity != null)
                                    {
                                        EntityReference hostOpportunityRef = opportunity.GetAttributeValue<EntityReference>("niq_hostopportunity");
                                        if (hostOpportunityRef == null || hostOpportunityRef.Id == Guid.Empty)
                                        {
                                            tracing.Trace("update: niq_ishostopportunity is empty");
                                            service.Update(updQuote);
                                        }
                                        else
                                        {
                                            Entity hostOpp = service.Retrieve(opportunityRef.LogicalName, hostOpportunityRef.Id, new ColumnSet("niq_revenuesharedeal"));
                                            if (hostOpp != null)
                                            {
                                                if (hostOpp.GetAttributeValue<bool>("niq_revenuesharedeal") == false)
                                                {
                                                    tracing.Trace("update: niq_revenuesharedeal is false");
                                                    service.Update(updQuote);
                                                }
                                                else if (hostOpp.GetAttributeValue<bool>("niq_revenuesharedeal") == true)
                                                {
                                                    // Define the query to retrieve records from "niq_dealdeskapprovalrequest"
                                                    QueryExpression query = new QueryExpression("niq_dealdeskapprovalrequest")
                                                    {
                                                        ColumnSet = new ColumnSet("niq_approvalstatus"),
                                                        Criteria = new FilterExpression
                                                        {
                                                            Conditions =
                                                            {
                                                                new ConditionExpression("niq_opportunityid", ConditionOperator.Equal, hostOpp.Id)
                                                            }
                                                        }
                                                    };

                                                    EntityCollection results = service.RetrieveMultiple(query);
                                                    if (results != null)
                                                    {
                                                        bool hasApprovalStatus4 = results.Entities.Any(e => e.GetAttributeValue<OptionSetValue>("niq_approvalstatus")?.Value == 4);
                                                        if (!hasApprovalStatus4)
                                                        {
                                                            tracing.Trace("update: niq_approvalstatus is 4");
                                                            service.Update(updQuote);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity && ((Entity)context.InputParameters["Target"]).LogicalName == "opportunity")
                {
                    tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk:On Change of Opportunity");
                    Entity retOppo = (Entity)context.InputParameters["Target"];
                    //IC-POC #24119_B
                    Entity preImage = context.PreEntityImages.Contains("PreImage") ? (Entity)context.PreEntityImages["PreImage"] : new Entity();
                    //Run the logic only when change in field niq_existingcontractaction as this plugin on oppportunity is registered only on update of this field. However due to same value updates it was misfiring
                    if (retOppo != null
                          && retOppo.Id != Guid.Empty
                          && retOppo.Attributes.Contains("niq_existingcontractaction")
                          && retOppo.GetAttributeValue<OptionSetValue>("niq_existingcontractaction") != null
                          && preImage != null
                          && preImage.Attributes.Contains("niq_existingcontractaction")
                          && preImage.GetAttributeValue<OptionSetValue>("niq_existingcontractaction") != null
                          && retOppo.GetAttributeValue<OptionSetValue>("niq_existingcontractaction").Value != preImage.GetAttributeValue<OptionSetValue>("niq_existingcontractaction").Value)
                    {
                        tracing.Trace("Exsting contract action value changed");
                        if (retOppo.GetAttributeValue<OptionSetValue>("niq_existingcontractaction").Value == 2 || retOppo.GetAttributeValue<OptionSetValue>("niq_existingcontractaction").Value == 3)
                        {
                            tracing.Trace("Exsting contract action 2 or 3");
                            //IC-POC #24119_E
                            string fetchQuotes = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='quote'>
                                                    <attribute name='niq_dealdeskapproval' />
                                                    <attribute name='quoteid' />
                                                    <attribute name='niq_quoteheaderdetailsapproval' />
                                                    <attribute name='niq_overalldealdeskapproval' />
                                                    <attribute name='niq_fundusageapproval' />
                                                    <order attribute='niq_mainquote' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='opportunityid' operator='eq' uitype='opportunity' value='{0}' />
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                    </filter>
                                                    <link-entity name='opportunity' from='opportunityid' to='opportunityid' visible='false' link-type='outer' alias='a_8722b5f2a2eceb11bacb000d3a35ee6d'>
                                                      <attribute name='niq_salesorgid' />
                                                    </link-entity>
                                                  </entity>
                                                </fetch>";
                            fetchQuotes = string.Format(fetchQuotes, retOppo.Id);
                            var resultQuotes = service.RetrieveMultiple(new FetchExpression(fetchQuotes));
                            if (resultQuotes != null && resultQuotes.Entities != null && resultQuotes.Entities.Count > 0)
                            {
                                foreach (Entity retQuote in resultQuotes.Entities)
                                {
                                    var pricingApproval = -1;
                                    var fundUsage = -1;
                                    var quoteHeader = -1;
                                    var overAll = -1;
                                    if (retQuote.Attributes.Contains("niq_dealdeskapproval") && retQuote.GetAttributeValue<OptionSetValue>("niq_dealdeskapproval") != null)
                                    {
                                        pricingApproval = retQuote.GetAttributeValue<OptionSetValue>("niq_dealdeskapproval").Value;

                                    }
                                    if (retQuote.Attributes.Contains("niq_fundusageapproval") && retQuote.GetAttributeValue<OptionSetValue>("niq_fundusageapproval") != null)
                                    {
                                        fundUsage = retQuote.GetAttributeValue<OptionSetValue>("niq_fundusageapproval").Value;

                                    }
                                    if (retQuote.Attributes.Contains("niq_quoteheaderdetailsapproval") && retQuote.GetAttributeValue<OptionSetValue>("niq_quoteheaderdetailsapproval") != null)
                                    {
                                        quoteHeader = retQuote.GetAttributeValue<OptionSetValue>("niq_quoteheaderdetailsapproval").Value;

                                    }
                                    if (retQuote.Attributes.Contains("niq_overalldealdeskapproval") && retQuote.GetAttributeValue<OptionSetValue>("niq_overalldealdeskapproval") != null)
                                    {
                                        overAll = retQuote.GetAttributeValue<OptionSetValue>("niq_overalldealdeskapproval").Value;

                                    }
                                    if ((pricingApproval != -1) && (fundUsage != -1) && (quoteHeader != -1) && (overAll != -1 && overAll != 1))
                                    {
                                        tracing.Trace("lineno:1147 ApprovedRequiredval" + isApprovalRequired);
                                        Entity updQuotes = new Entity(retQuote.LogicalName, retQuote.Id);
                                        updQuotes["niq_overalldealdeskapproval"] = new OptionSetValue(5);
                                        tracing.Trace("line no 926");
                                        updQuotes["niq_quoteheaderdetailsapproval"] = new OptionSetValue(3);
                                        updQuotes["niq_fundusageapproval"] = new OptionSetValue(3);
                                        updQuotes["niq_dealdeskapproval"] = new OptionSetValue(100000003);
                                        service.Update(updQuotes);
                                    }

                                }
                            }
                        }


                        else
                        {
                            tracing.Trace("Exsting contract action not in 2 or 3");
                            tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: To Set Pricing Approval -> To Be dtermined & Re Evaluate Quote Header");
                            string fetchQuotes = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='quote'>
                                                    <attribute name='niq_dealdeskapproval' />
                                                    <attribute name='quoteid' />
                                                    <attribute name='niq_quoteheaderdetailsapproval' />
                                                    <attribute name='niq_overalldealdeskapproval' />
                                                    <attribute name='niq_fundusageapproval' />
                                                    <order attribute='niq_mainquote' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='opportunityid' operator='eq' uitype='opportunity' value='{0}' />
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                    </filter>
                                                    <link-entity name='opportunity' from='opportunityid' to='opportunityid' visible='false' link-type='outer' alias='a_8722b5f2a2eceb11bacb000d3a35ee6d'>
                                                      <attribute name='niq_salesorgid' />
                                                    </link-entity>
                                                  </entity>
                                                </fetch>";
                            fetchQuotes = string.Format(fetchQuotes, retOppo.Id);
                            var resultQuotes = service.RetrieveMultiple(new FetchExpression(fetchQuotes));
                            if (resultQuotes != null && resultQuotes.Entities != null && resultQuotes.Entities.Count > 0)
                            {
                                foreach (Entity retQuote in resultQuotes.Entities)
                                {
                                    tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk:Ret Quote id " + retQuote.Id);
                                    Entity retQuoteHeader = service.Retrieve(retQuote.LogicalName, retQuote.Id, new ColumnSet("niq_contractenddate", "niq_contractstartdate", "niq_salesorgid", "customerid", "niq_customertype", "niq_termtype", "niq_annualincreasetype", "niq_annualapicola", "niq_apistructure", "niq_evergreenautorenewalannualapi", "niq_terminationnotificationmonths", "niq_numberofftes", "niq_interestrateonlatepayment", "niq_paymenttermsid", "niq_incentivetype", "niq_incentivevalueniqannualimpact", "niq_linktononstandardapprovalrequests"));
                                    if (retQuoteHeader != null && retQuoteHeader.Id != Guid.Empty)
                                    {
                                        tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk:ret quote" + retQuoteHeader.Id);
                                        Entity updQuoteHeader = new Entity(retQuoteHeader.LogicalName, retQuoteHeader.Id);
                                        tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk:ret termtype" + retQuoteHeader.Attributes.Contains("niq_termtype"));
                                        if (!retQuoteHeader.Attributes.Contains("niq_termtype"))
                                        {
                                            tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: Pricing & Quote header -> To Be detemined");
                                            updQuoteHeader["niq_quoteheaderdetailsapproval"] = new OptionSetValue(1);
                                            updQuoteHeader["niq_dealdeskapproval"] = new OptionSetValue(100000000);
                                            service.Update(updQuoteHeader);
                                        }
                                        else
                                        {
                                            tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk:re evaluate quote header ");
                                            tracing.Trace("lineno:1196 ApprovedRequiredval" + isApprovalRequired);
                                            if (retQuoteHeader.Attributes.Contains("niq_termtype") && retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_termtype") != null)
                                            {
                                                //Approval required if Indefinite or Perpetual is selected
                                                if (retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_termtype").Value == 100000002 || retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_termtype").Value == 100000003)
                                                {
                                                    isApprovalRequired = true;
                                                    approvalFields = "Term Type";

                                                }
                                                ////if (Term Type = fixed term or evergreen)
                                                //if (retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_termtype").Value == 100000000)
                                                //{
                                                //    //Approval Required if Term Type = Evergreen and Sales Org is not 0500 or 0560
                                                //    var salesorgQuery = @"<fetch version=""1.0"" output-format=""xml-platform"" mapping=""logical"" distinct=""false"">
                                                //                           <entity name=""niq_salesorg"">
                                                //                           <attribute name=""niq_salesorgid"" />
                                                //                           <attribute name=""niq_name"" />
                                                //                           <attribute name=""createdon"" />
                                                //                           <order attribute=""niq_name"" descending=""false"" />
                                                //                           <filter type=""and"">
                                                //                             <filter type=""or"">
                                                //                              <condition attribute=""niq_salesorgcode"" operator=""eq"" value=""0500"" />
                                                //                              <condition attribute=""niq_salesorgcode"" operator=""eq"" value=""0560"" />
                                                //                             </filter>
                                                //                           <condition attribute=""niq_salesorgid"" operator=""eq"" uiname=""0500 - Nielsen Consumer LLC"" uitype=""niq_salesorg"" value=""{0}"" />
                                                //                           </filter>
                                                //                         </entity>
                                                //                        </fetch>";
                                                //    salesorgQuery = string.Format(salesorgQuery, retQuoteHeader.GetAttributeValue<EntityReference>("niq_salesorgid").Id);
                                                //    var salesRecords = service.RetrieveMultiple(new FetchExpression(salesorgQuery));
                                                //    if (salesRecords != null && salesRecords.Entities != null && salesRecords.Entities.Count == 0)
                                                //    {
                                                //        isApprovalRequired = true;
                                                //        approvalFields = "Term Type";
                                                //    }
                                                //}
                                                if (retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_termtype").Value == 100000001 || retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_termtype").Value == 100000000)
                                                {
                                                    if (retQuoteHeader.GetAttributeValue<DateTime>("niq_contractenddate") != null && retQuoteHeader.GetAttributeValue<DateTime>("niq_contractstartdate") != null)
                                                    {

                                                        int monthsDiff = GetMonthDifference(retQuoteHeader.GetAttributeValue<DateTime>("niq_contractstartdate"), retQuoteHeader.GetAttributeValue<DateTime>("niq_contractenddate").AddDays(1));
                                                        if (monthsDiff > 12)
                                                        {
                                                            bool isSalesOrg = false;

                                                            var salesorgQuery = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                                  <entity name='niq_salesorg'>
                                                                                    <attribute name='niq_salesorgid' />
                                                                                    <attribute name='niq_name' />
                                                                                    <attribute name='createdon' />
                                                                                    <order attribute='niq_name' descending='false' />
                                                                                    <filter type='and'>
                                                                                      <condition attribute='niq_salesorgcode' operator='eq' value='0500' />
                                                                                      <condition attribute='niq_salesorgid' operator='eq' uitype='niq_salesorg' value='{0}' />
                                                                                    </filter>
                                                                                  </entity>
                                                                                </fetch>";
                                                            salesorgQuery = string.Format(salesorgQuery, retQuoteHeader.GetAttributeValue<EntityReference>("niq_salesorgid").Id);
                                                            var salesRecords = service.RetrieveMultiple(new FetchExpression(salesorgQuery));
                                                            if (salesRecords != null && salesRecords.Entities != null && salesRecords.Entities.Count == 1)
                                                            {
                                                                isSalesOrg = true;
                                                            }
                                                            //Approval required if (Term Type = fixed term or evergreen) AND (contract duration based on Quote Start/End Date > 12 months) AND ((field value <> API for 0500 sales org OR (field value <> COLA for all other sales orgs))
                                                            if (retQuoteHeader.Attributes.Contains("niq_annualincreasetype") && retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_annualincreasetype") != null)
                                                            {
                                                                if (retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_annualincreasetype").Value == 100000000)
                                                                {
                                                                    isApprovalRequired = true;
                                                                    approvalFields = approvalFields == null ? "Annual Increase Type" : approvalFields + "," + " Annual Increase Type";
                                                                }
                                                            }
                                                            //Approval required if (Term Type = fixed term or evergreen) AND (contract duration based on Quote Start/End Date > 12 months) AND Sales org = 0500 AND field value is <3%
                                                            if (retQuoteHeader.Attributes.Contains("niq_annualapicola") && (retQuoteHeader.GetAttributeValue<decimal>("niq_annualapicola") < 3 && isSalesOrg))
                                                            {
                                                                isApprovalRequired = true;
                                                                approvalFields = approvalFields == null ? "Annual API/COLA %" : approvalFields + "," + " Annual API/COLA %";
                                                            }
                                                            //Approval required if (Term Type = fixed term or evergreen) AND (contract duration based on Quote Start/End Date > 12 months) AND (field value <> "Standard")
                                                            if (retQuoteHeader.Attributes.Contains("niq_apistructure") && retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_apistructure") != null && retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_apistructure").Value != 100000003)
                                                            {
                                                                isApprovalRequired = true;
                                                                approvalFields = approvalFields == null ? "API/COLA structure" : approvalFields + "," + " API/COLA structure";
                                                            }

                                                        }
                                                        // Commented for the story DYNCRM - 25920
                                                        // Approval required if Term Type <> perpetual or indefinite or fixed and entered value is less then the default value defined based on Start and End date: less than 4 months if difference between Contract Start/End Date is less than 24 Months; less than 6 months if difference between Contract Start/End Date equals or more than 24 and less than 36 months; less than 12 months if difference between contract Start / End Date is equal or more than 36 months
                                            //            if (retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_termtype").Value == 100000000)
                                            //            {
                                            //                if (retQuoteHeader.Attributes.Contains("niq_terminationnotificationmonths"))
                                            //                {
                                            //                    int tnm = retQuoteHeader.GetAttributeValue<int>("niq_terminationnotificationmonths");
                                            //                    tracing.Trace("tnm = " + tnm);
                                            //                    tracing.Trace("diffmonths " + monthsDiff);
                                            //                    if (monthsDiff < 24 && tnm < 4)
                                            //                    {
                                            //                        isApprovalRequired = true;
                                            //                        approvalFields = approvalFields == null ? "Termination Notification (Months)" : approvalFields + "," + " Termination Notification (Months)";
                                            //                    }
                                            //                    else if ((monthsDiff >= 24 && monthsDiff < 36) && tnm < 6)
                                            //                    {
                                            //                        isApprovalRequired = true;
                                            //                        approvalFields = approvalFields == null ? "Termination Notification (Months)" : approvalFields + "," + " Termination Notification (Months)";
                                            //                    }
                                            //                    else if (monthsDiff >= 36 && tnm < 12)
                                            //                    {
                                            //                        isApprovalRequired = true;
                                            //                        approvalFields = approvalFields == null ? "Termination Notification (Months)" : approvalFields + "," + " Termination Notification (Months)";
                                            //                    }
                                            //                }
                                            //            }
                                                    }
                                              }
                                            //    //Approval required if term type = Evergreen and field value < 5%
                                            //    if (retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_termtype").Value == 100000000 && retQuoteHeader.Attributes.Contains("niq_evergreenautorenewalannualapi") && retQuoteHeader.GetAttributeValue<decimal>("niq_evergreenautorenewalannualapi") < 5)
                                            //    {
                                            //        isApprovalRequired = true;
                                            //        approvalFields = approvalFields == null ? "Evergreen/Auto Renewal Annual API %" : approvalFields + "," + " Evergreen/Auto Renewal Annual API %";
                                            //    }

                                            }
                                            //Approval required when Incentive Type is not none
                                            if (retQuoteHeader.Attributes.Contains("niq_incentivetype") && retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_incentivetype") != null && retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_incentivetype").Value != 100000000)
                                            {
                                                isApprovalRequired = true;
                                                approvalFields = approvalFields == null ? "Incentive Type" : approvalFields + "," + " Incentive Type";
                                            }
                                            //Approval required when Incentive Value is not zero
                                            if (retQuoteHeader.Attributes.Contains("niq_incentivevalueniqannualimpact") && retQuoteHeader.GetAttributeValue<int>("niq_incentivevalueniqannualimpact") > 0)
                                            {
                                                isApprovalRequired = true;
                                                approvalFields = approvalFields == null ? "Incentive Value (NIQ Annual Impact)" : approvalFields + "," + " Incentive Value (NIQ Annual Impact)";
                                            }
                                            //Approval required when Link to Non-Standard Approval Requests is filled
                                            if (retQuoteHeader.Attributes.Contains("niq_linktononstandardapprovalrequests") && retQuoteHeader.GetAttributeValue<string>("niq_linktononstandardapprovalrequests") != null)
                                            {
                                                isApprovalRequired = true;
                                                approvalFields = approvalFields == null ? "Link to Non-Standard Approval Requests" : approvalFields + "," + " Link to Non-Standard Approval Requests";
                                            }
                                            //Approval Required when Customer Type on Account = Non-Core and Customer Type on Quote = Core
                                            if (retQuoteHeader.Attributes.Contains("niq_customertype") && retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_customertype") != null)
                                            {
                                                if (retQuoteHeader.Attributes.Contains("customerid"))
                                                {
                                                    Guid accountId = retQuoteHeader.GetAttributeValue<EntityReference>("customerid").Id;
                                                    QueryExpression accountQuery = new QueryExpression("account");
                                                    accountQuery.TopCount = 1;
                                                    accountQuery.ColumnSet.AddColumns("niq_customertype");
                                                    accountQuery.Criteria.AddCondition("accountid", ConditionOperator.Equal, accountId);
                                                    EntityCollection accountRecords = service.RetrieveMultiple(accountQuery);
                                                    foreach (Entity record in accountRecords.Entities)
                                                    {
                                                        if (record.GetAttributeValue<OptionSetValue>("niq_customertype").Value != retQuoteHeader.GetAttributeValue<OptionSetValue>("niq_customertype").Value)
                                                        {
                                                            isApprovalRequired = true;
                                                            approvalFields = approvalFields == null ? "Customer Type" : approvalFields + "," + " Customer Type";
                                                            break;
                                                        }

                                                    }

                                                }
                                            }

                                            //Approval Required if value >0
                                            if (retQuoteHeader.Attributes.Contains("niq_numberofftes") && retQuoteHeader.GetAttributeValue<decimal>("niq_numberofftes") > 0)
                                            {
                                                isApprovalRequired = true;
                                                approvalFields = approvalFields == null ? "Number of FTEs" : approvalFields + "," + " Number of FTEs";
                                            }
                                            tracing.Trace("commented based on DYNCRM-29225");
                                            /*commented based on DYNCRM-29225
                                            //Approval Required if value is less than 1.5%
                                            if (retQuoteHeader.Attributes.Contains("niq_interestrateonlatepayment") && retQuoteHeader.GetAttributeValue<decimal>("niq_interestrateonlatepayment") < 1.50M)
                                            {
                                                isApprovalRequired = true;
                                                approvalFields = approvalFields == null ? "Late Payment Penalty Fee in %" : approvalFields + "," + " Late Payment Penalty Fee in %";
                                            }
                                            */
                                            //Approval Required if value is different from NM01, ND14, ND00, ND20, ND15, ND21, ND10, ND28, ND05 and ND07
                                            if (retQuoteHeader.Attributes.Contains("niq_paymenttermsid"))
                                            {
                                                Guid paymenttermId = retQuoteHeader.GetAttributeValue<EntityReference>("niq_paymenttermsid").Id;
                                                QueryExpression paymenttermQuery = new QueryExpression("niq_paymentterm");
                                                paymenttermQuery.TopCount = 1;
                                                paymenttermQuery.ColumnSet.AddColumns("niq_paymenttermcode");
                                                paymenttermQuery.Criteria.AddCondition("niq_paymenttermid", ConditionOperator.Equal, paymenttermId);
                                                EntityCollection paymenttermRecords = service.RetrieveMultiple(paymenttermQuery);
                                                foreach (Entity record in paymenttermRecords.Entities)
                                                {
                                                    if (record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "NM01" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND14" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND00" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND20" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND15" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND21" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND10" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND28" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND05" && record.GetAttributeValue<string>("niq_paymenttermcode").ToUpper() != "ND07")
                                                    {
                                                        isApprovalRequired = true;
                                                        approvalFields = approvalFields == null ? "Agreement Payment Terms" : approvalFields + "," + " Agreement Payment Terms";
                                                        break;
                                                    }

                                                }
                                            }
                                            //IC-POC #24119_B
                                            tracing.Trace("Start - ApprovedRequiredval:" + isApprovalRequired.ToString());
                                            if (isApprovalRequired)
                                            {
                                                tracing.Trace("InsideIf - ApprovedRequiredval:" + isApprovalRequired.ToString());
                                                updQuoteHeader["niq_dealdeskapproval"] = new OptionSetValue(100000002);
                                                updQuoteHeader["niq_quoteheaderdetailsapproval"] = new OptionSetValue(2);
                                                updQuoteHeader["niq_fieldsrequiringapproval"] = approvalFields;
                                                service.Update(updQuoteHeader);
                                            }
                                            else
                                            {
                                                tracing.Trace("Insideelse - ApprovedRequiredval:" + isApprovalRequired.ToString());
                                                updQuoteHeader["niq_dealdeskapproval"] = new OptionSetValue(100000003);
                                                updQuoteHeader["niq_quoteheaderdetailsapproval"] = new OptionSetValue(3);
                                                updQuoteHeader["niq_fieldsrequiringapproval"] = null;
                                                service.Update(updQuoteHeader);
                                            }
                                            tracing.Trace("End - ApprovedRequiredval:" + isApprovalRequired.ToString());
                                            //IC-POC #24119_E
                                        }
                                    }


                                }
                            }
                        }
                    }
                }

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity && ((Entity)context.InputParameters["Target"]).LogicalName == "niq_dealdeskapprovalrequest")
                {
                    Entity ddarObj = (Entity)context.InputParameters["Target"];
                    if (ddarObj != null && ddarObj.Id != Guid.Empty)
                    {
                        // When placeholder product is not present, run the following logic:
                        Entity retDDAR = service.Retrieve(ddarObj.LogicalName, ddarObj.Id, new ColumnSet("niq_pricingapproval", "niq_fundusageapproval", "niq_quoteheaderdetailsapproval"));
                        Entity updDDAR = new Entity(retDDAR.LogicalName, retDDAR.Id);
                        bool update = false;
                        if (retDDAR != null && retDDAR.Id != Guid.Empty && retDDAR.Attributes.Contains("niq_pricingapproval") && retDDAR.Attributes.Contains("niq_fundusageapproval") && retDDAR.Attributes.Contains("niq_quoteheaderdetailsapproval"))
                        {
                            var pricingApproval = retDDAR.GetAttributeValue<OptionSetValue>("niq_pricingapproval").Value;
                            var fundUsage = retDDAR.GetAttributeValue<OptionSetValue>("niq_fundusageapproval").Value;
                            var quoteHeader = retDDAR.GetAttributeValue<OptionSetValue>("niq_quoteheaderdetailsapproval").Value;
                            //In case approval status = "To be determined" for at least one of the 3 approval fields (pricing, fund or quote header), Deal Desk Approval should equal to "To be determined" as well.
                            if (pricingApproval == 100000000 || fundUsage == 1 || quoteHeader == 1)
                            {
                                tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk://In case approval status = \"To be determined\" for at least one of the 3 approval fields (pricing, fund or quote header), Deal Desk Approval should equal to \"To be determined\" as well.");
                                update = true;
                                updDDAR["niq_overalldealdeskapproval"] = new OptionSetValue(2);
                            }
                            //In case pricing approval status = Segment Lead Approval Required and (Fund Usage Approval and Quote Header details approval = No approval required or approved) => set Overall Deal Desk Approval to Segment Lead Approval Required
                            else if (pricingApproval == 100000001 && ((fundUsage == 3 && quoteHeader == 3) || (fundUsage == 4 && quoteHeader == 4) || (fundUsage == 3 && quoteHeader == 4) || (fundUsage == 4 && quoteHeader == 3)))
                            {
                                tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk://In case pricing approval status = Segment Lead Approval Required and (Fund Usage Approval and Quote Header details approval = No approval required or approved) => set Overall Deal Desk Approval to Segment Lead Approval Required");
                                update = true;
                                updDDAR["niq_overalldealdeskapproval"] = new OptionSetValue(3);
                            }
                            //In case pricing approval status = Segment Lead Approval Required and (Fund Usage Approval OR Quote Header details approval = approval required) => set Overall Deal Desk Approval to Approval Required
                            else if (pricingApproval == 100000001 && (fundUsage == 2 || quoteHeader == 2))
                            {
                                tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk:In case pricing approval status = Segment Lead Approval Required and (Fund Usage Approval OR Quote Header details approval = approval required) => set Overall Deal Desk Approval to Approval Required");
                                update = true;
                                updDDAR["niq_overalldealdeskapproval"] = new OptionSetValue(4);
                            }
                            // In case any of the 3 fields equal to "Rejected", set Overall Deal Desk status to Rejected
                            else if (pricingApproval == 100000005 || fundUsage == 5)
                            {
                                tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: In case any of the 3 fields equal to \"Rejected\", set Overall Deal Desk status to Rejected");
                                update = true;
                                updDDAR["niq_overalldealdeskapproval"] = new OptionSetValue(8);
                            }
                            //In case any of the 3 fields equal to "Approval Required" and none of them equal to "Rejected" or "to be determined", set Deal Desk status to "Approval required"
                            else if ((pricingApproval == 100000002 && (fundUsage != 5 && fundUsage != 1 && quoteHeader != 1)) || ((pricingApproval != 100000005 && fundUsage != 5 && pricingApproval != 100000000 && fundUsage != 1) && quoteHeader == 2) || (fundUsage == 2 && (pricingApproval != 100000005 && quoteHeader != 5 && pricingApproval != 100000000 && quoteHeader != 1)))
                            {
                                tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk:In case any of the 3 fields equal to Approval Required and none of them equal to Rejected or to be determined, set Deal Desk status to Approval required");
                                update = true;
                                updDDAR["niq_overalldealdeskapproval"] = new OptionSetValue(4);
                            }
                            // In case all 3 fields = "No approval required" => set value to "No approval required"
                            else if ((pricingApproval == 100000003 || pricingApproval == 100000006) && fundUsage == 3 && quoteHeader == 3)
                            {
                                tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: In case all 3 fields = \"No approval required\" => set value to \"No approval required\"");
                                update = true;
                                updDDAR["niq_overalldealdeskapproval"] = new OptionSetValue(5);
                            }
                            //In case at least one field equals "Approved" and other equal to "No approval required" => set value to "Approved"
                            else if ((pricingApproval == 100000004 && fundUsage == 3 && quoteHeader == 3) || (pricingApproval == 100000003 && fundUsage == 4 && quoteHeader == 3) || (pricingApproval == 100000006 && fundUsage == 4 && quoteHeader == 3) || (pricingApproval == 100000006 && fundUsage == 3 && quoteHeader == 4) || (pricingApproval == 100000003 && fundUsage == 3 && quoteHeader == 4) || (pricingApproval == 100000004 && fundUsage == 4 && quoteHeader == 4) || (pricingApproval == 100000004 && fundUsage == 4 && quoteHeader == 3) || (pricingApproval == 100000004 && fundUsage == 3 && quoteHeader == 4) || (pricingApproval == 100000006 && fundUsage == 4 && quoteHeader == 4) || (pricingApproval == 100000003 && fundUsage == 4 && quoteHeader == 4))
                            {
                                tracing.Trace("OnUpdate_Quote_DD_ValidateDealDesk: In case at least one field equals \"Approved\" and other equal to \"No approval required\" => set value to \"Approved\"");
                                update = true;
                                updDDAR["niq_overalldealdeskapproval"] = new OptionSetValue(6);
                            }

                            if (update)
                            {
                                service.Update(updDDAR);
                            }
                        }
                    }

                }

            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException("OnUpdate_Quote_DD_ValidateDealDesk: " + ex.Message);
            }
        }

        public static int GetMonthDifference(DateTime startDate, DateTime endDate)
        {
            int monthsApart = 12 * (startDate.Year - endDate.Year) + startDate.Month - endDate.Month;
            return Math.Abs(monthsApart);
        }
    }
}