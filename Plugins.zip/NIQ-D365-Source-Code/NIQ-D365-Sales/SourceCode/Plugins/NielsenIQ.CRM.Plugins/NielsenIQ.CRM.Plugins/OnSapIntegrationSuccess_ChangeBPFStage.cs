﻿using System;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;


namespace NielsenIQ.CRM.Plugins
{
    public class OnSapIntegrationStatusChange : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                string logicalNameOfBPF = "niq_bpf_opportunity";
                if (context.Depth > 2)
                {
                    return;
                }
                if (context.MessageName == "Update")
                {
                    if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                    {
                        Entity OpporObj = (Entity)context.InputParameters["Target"];
                        string oppoStage;
                        tracing.Trace("Target Opportunity");

                        if (OpporObj != null && OpporObj.Id != Guid.Empty && OpporObj.Attributes.Contains("niq_sapintegrationstatus") && OpporObj.GetAttributeValue<OptionSetValue>("niq_sapintegrationstatus") != null)
                        {
                            string[] OptyCols =new string[] { "niq_sapintegrationstatus", "statecode", "niq_stage", "niq_mainquoteid" };
                            Entity retOppo = service.Retrieve(OpporObj.LogicalName, OpporObj.Id, new ColumnSet(OptyCols));
                            int SapIntegrationStatus = retOppo.GetAttributeValue<OptionSetValue>("niq_sapintegrationstatus").Value;
                            int Status = retOppo.GetAttributeValue<OptionSetValue>("statecode").Value;
                            oppoStage = retOppo.GetAttributeValue<string>("niq_stage");
                            tracing.Trace("Getting SapIntegrationStatus and Status Values");
                            tracing.Trace("1:" + DateTime.Now.ToString());
                            if (SapIntegrationStatus != 0 && SapIntegrationStatus == 100000000 && Status == 0)
                            {
                                if (oppoStage == "Closed Won - In Review")
                                {
                                    if (retOppo != null && retOppo.Attributes.Contains("niq_mainquoteid"))
                                    {
                                       

                                        //Quote Close

                                        EntityReference mainQuoteRef = retOppo.GetAttributeValue<EntityReference>("niq_mainquoteid");
                                        //Entity OpporMainQuote = service.Retrieve(mainQuoteRef.LogicalName, mainQuoteRef.Id, new ColumnSet("statecode", "statuscode"));
                                        if (mainQuoteRef != null)
                                        {
                                            tracing.Trace("2:" + DateTime.Now.ToString());
                                            // Activate the quote
                                            SetStateRequest activateQuote = new SetStateRequest()
                                            {
                                                EntityMoniker = mainQuoteRef,
                                                State = new OptionSetValue(1),
                                                Status = new OptionSetValue(2) //in progress
                                            };
                                            service.Execute(activateQuote);
                                            tracing.Trace("3:" + DateTime.Now.ToString());
                                            /*
                                            Entity UpdQuote = new Entity(OpporMainQuote.LogicalName, OpporMainQuote.Id);
                                            UpdQuote["statecode"] = new OptionSetValue(2);
                                            UpdQuote["statuscode"] = new OptionSetValue(4);
                                              service.Update(UpdQuote);
                                            */

                                            tracing.Trace("4:" + DateTime.Now.ToString());
                                            WinQuoteRequest winQuoteRequest = new WinQuoteRequest();
                                            Entity quoteClose = new Entity("quoteclose");
                                            quoteClose.Attributes["quoteid"] = mainQuoteRef;
                                            quoteClose.Attributes["subject"] = string.Format("Quote Close-{0}_{1}", mainQuoteRef.Name,DateTime.Now.ToString());
                                            winQuoteRequest.QuoteClose = quoteClose;
                                            winQuoteRequest.Status = new OptionSetValue(-1);
                                            service.Execute(winQuoteRequest);
                                            tracing.Trace("5:" + DateTime.Now.ToString());
                                            tracing.Trace("main quote updated successfully");
                                           

                                        }
                                        
                                        string fetchXmlQuote = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='quote'>
                                                        <attribute name='quoteid' />
                                                        <attribute name='name' />
                                                        <filter type='and'>
                                                          <condition attribute='niq_mainquote' operator='eq' value='0' />
                                                          <condition attribute='opportunityid' operator='eq' value='{(retOppo.Id).ToString()}' />
                                                          <condition attribute='statecode' operator='ne' value='3' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";
                                        EntityCollection quotelst = service.RetrieveMultiple(new FetchExpression(fetchXmlQuote));
                                        tracing.Trace("6:" + DateTime.Now.ToString());
                                        tracing.Trace("retriev all non quote");
                                        if (quotelst != null && quotelst.Entities.Count > 0)
                                        {
                                            foreach (var a in quotelst.Entities)
                                            {     /*                                           
                                                Entity UpdQuote1 = new Entity(a.LogicalName, a.Id);
                                                UpdQuote1["statecode"] = new OptionSetValue(3);
                                                UpdQuote1["statuscode"] = new OptionSetValue(6);
                                                service.Update(UpdQuote1);
                                            */
                                                  // Activate the quote
                                                tracing.Trace("7:" + DateTime.Now.ToString());
                                                SetStateRequest activateQuote = new SetStateRequest()
                                                {
                                                    EntityMoniker =new  EntityReference(a.LogicalName, a.Id),
                                                    State = new OptionSetValue(1),
                                                    Status = new OptionSetValue(2) //in progress
                                                };
                                                service.Execute(activateQuote);
                                                tracing.Trace("8:" + DateTime.Now.ToString());

                                                CloseQuoteRequest closeQuoteRequest = new CloseQuoteRequest();
                                                Entity quoteClose = new Entity("quoteclose");
                                                quoteClose.Attributes["quoteid"] = new EntityReference(a.LogicalName,a.Id);
                                                quoteClose.Attributes["subject"] = string.Format("Canceled Quote-{0}_{1}", a["name"].ToString() , DateTime.Now.ToString());
                                                closeQuoteRequest.QuoteClose = quoteClose;
                                                closeQuoteRequest.Status = new OptionSetValue(6);
                                               
                                                service.Execute(closeQuoteRequest);
                                                tracing.Trace("9:" + DateTime.Now.ToString());
                                            }

                                        }

                                        tracing.Trace("quoteUpdated");

                                        Entity OpporClose = new Entity("opportunityclose");

                                        OpporClose["actualend"] = DateTime.Now;
                                        OpporClose["opportunityid"] = new EntityReference(retOppo.LogicalName, retOppo.Id);
                                        OpporClose["opportunitystatecode"] = new OptionSetValue(1);
                                        OpporClose["opportunitystatuscode"] = new OptionSetValue(3);
                                        service.Create(OpporClose);
                                        tracing.Trace("Oppor close created");

                                        tracing.Trace("10:" + DateTime.Now.ToString());

                                        //Update Opportunity and Update BPF
                                        Entity UpdateOpportunity = new Entity(retOppo.LogicalName, retOppo.Id);
                                        UpdateOpportunity["niq_closeprobability"] = new OptionSetValue(100000006);
                                        UpdateOpportunity["niq_stage"] = "Closed Won - Approved";
                                        service.Update(UpdateOpportunity);
                                        tracing.Trace("Oppor Updated");
                                        tracing.Trace("11:" + DateTime.Now.ToString());

                                        ConditionExpression condition2 = new ConditionExpression();
                                        condition2.AttributeName = "bpf_opportunityid";
                                        condition2.Operator = ConditionOperator.Equal;
                                        condition2.Values.Add(retOppo.Id);

                                        FilterExpression filter2 = new FilterExpression();
                                        filter2.Conditions.Add(condition2);

                                        QueryExpression query2 = new QueryExpression("niq_bpf_opportunity");
                                        query2.ColumnSet.AddColumns("activestageid", "statecode", "statuscode");
                                        query2.Criteria.AddFilter(filter2);

                                        EntityCollection oppoBpf = service.RetrieveMultiple(query2);
                                        tracing.Trace("12:" + DateTime.Now.ToString());
                                        tracing.Trace("bpf retrieved successfully");
                                        foreach (var bpf in oppoBpf.Entities)
                                        {
                                            var retBpf = service.Retrieve(bpf.LogicalName, bpf.Id, new ColumnSet("statecode", "statuscode"));
                                            if (retBpf.GetAttributeValue<OptionSetValue>("statecode").Value == 1)
                                            {
                                                service.Execute(new SetStateRequest
                                                {
                                                    EntityMoniker = new EntityReference(retBpf.LogicalName, retBpf.Id),
                                                    State = new OptionSetValue(0), //"Active"
                                                    Status = new OptionSetValue(1) //"Active"
                                                });
                                                tracing.Trace("bpf 1 updated");
                                            }

                                        }
                                        tracing.Trace("13:" + DateTime.Now.ToString());
                                        Entity activeProcessInstance = GetActiveBPFDetails(OpporObj, service);
                                        if (activeProcessInstance != null)
                                        {
                                            Guid activeBPFId = activeProcessInstance.Id;
                                            Guid activeStageId = new Guid(activeProcessInstance.Attributes["processstageid"].ToString());
                                            int currentStagePosition = -1;
                                            RetrieveActivePathResponse pathResp = GetAllStagesOfSelectedBPF(activeBPFId, activeStageId, ref currentStagePosition, service);
                                            if (currentStagePosition > -1 && pathResp.ProcessStages != null && pathResp.ProcessStages.Entities != null && currentStagePosition + 1 < pathResp.ProcessStages.Entities.Count)
                                            {
                                                Guid nextStageId = (Guid)pathResp.ProcessStages.Entities[currentStagePosition + 1].Attributes["processstageid"];
                                                Entity entBPF = new Entity(logicalNameOfBPF)
                                                {
                                                    Id = activeBPFId
                                                };
                                                entBPF["activestageid"] = new EntityReference("processstage", nextStageId);
                                                service.Update(entBPF);
                                                tracing.Trace("14:" + DateTime.Now.ToString());
                                                service.Execute(new SetStateRequest
                                                {
                                                    EntityMoniker = new EntityReference(logicalNameOfBPF, activeBPFId),
                                                    State = new OptionSetValue(1), //Status
                                                    Status = new OptionSetValue(2) //Status reason
                                                });
                                                tracing.Trace("bpf 2 updated");
                                                tracing.Trace("15:" + DateTime.Now.ToString());
                                            }
                                        }

                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        public Entity GetActiveBPFDetails(Entity entity, IOrganizationService service)
        {
            Entity activeProcessInstance = null;
            RetrieveProcessInstancesRequest entityBPFsRequest = new RetrieveProcessInstancesRequest
            {
                EntityId = entity.Id,
                EntityLogicalName = entity.LogicalName
            };
            RetrieveProcessInstancesResponse entityBPFsResponse = (RetrieveProcessInstancesResponse)service.Execute(entityBPFsRequest);
            if (entityBPFsResponse.Processes != null && entityBPFsResponse.Processes.Entities != null)
            {
                activeProcessInstance = entityBPFsResponse.Processes.Entities[0];
            }
            return activeProcessInstance;
        }
        public RetrieveActivePathResponse GetAllStagesOfSelectedBPF(Guid activeBPFId, Guid activeStageId, ref int currentStagePosition, IOrganizationService service)
        {
            // Retrieve the process stages in the active path of the current process instance
            RetrieveActivePathRequest pathReq = new RetrieveActivePathRequest
            {
                ProcessInstanceId = activeBPFId
            };
            RetrieveActivePathResponse pathResp = (RetrieveActivePathResponse)service.Execute(pathReq);
            for (int i = 0; i < pathResp.ProcessStages.Entities.Count; i++)
            {
                // Retrieve the active stage name and active stage position based on the activeStageId for the process instance
                if (pathResp.ProcessStages.Entities[i].Attributes["processstageid"].ToString() == activeStageId.ToString())
                {
                    currentStagePosition = i;
                }
            }
            return pathResp;
        }
    }

}
