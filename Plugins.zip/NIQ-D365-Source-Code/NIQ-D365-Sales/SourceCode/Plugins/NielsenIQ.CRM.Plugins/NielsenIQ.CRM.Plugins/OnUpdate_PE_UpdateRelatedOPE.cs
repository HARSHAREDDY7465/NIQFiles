﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_PE_UpdateRelatedOPE : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(null);

                if (context.Depth > 1)
                {
                    tracing.Trace("OnUpdate_PE_UpdateRelatedOPE: Context Depth > 1");
                    return;
                }


                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_PE_UpdateRelatedOPE: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity peObj = (Entity)context.InputParameters["Target"];
                    if (peObj != null && peObj.Id != Guid.Empty && peObj.Attributes.Contains("statecode"))
                    {
                        tracing.Trace("OnUpdate_PE_UpdateRelatedOPE: PE OBJ " + peObj.Id);
                        tracing.Trace("OnUpdate_PE_UpdateRelatedOPE:State Code" + peObj.GetAttributeValue<OptionSetValue>("statecode"));
                        string fetchXmlOPE = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='niq_opportunityproductenhancement'>
                                                    <attribute name='statecode' />
                                                    <order attribute='createdon' descending='true' />
                                                    <filter type='and'>
                                                      <condition attribute='niq_productenhancementnameid' operator='eq' uitype='niq_productenhancement' value='{0}' />
                                                    </filter>
                                                    <link-entity name='niq_productenhancement' from='niq_productenhancementid' to='niq_productenhancementnameid' visible='false' link-type='outer' alias='a_4de05c6b1c83ec118d210022480b2fe5'>
                                                      <attribute name='niq_productenhancementname' />
                                                    </link-entity>
                                                  </entity>
                                                </fetch>";
                        fetchXmlOPE = string.Format(fetchXmlOPE, peObj.Id);
                        var result = service.RetrieveMultiple(new FetchExpression(fetchXmlOPE));
                        if (result != null && result.Entities != null && result.Entities.Count > 0)
                        {
                            tracing.Trace("OnUpdate_PE_UpdateRelatedOPE: result count " + result.Entities.Count);
                            foreach (Entity ope in result.Entities)
                            {
                                Entity updOPE = new Entity(ope.LogicalName, ope.Id);
                                UpdateRequest updateRequest = new UpdateRequest { Target = ope };
                                tracing.Trace("OnUpdate_PE_UpdateRelatedOPE: OPE ID " + ope.Id);
                                updOPE["statecode"] = peObj.GetAttributeValue<OptionSetValue>("statecode");
                                service.Update(updOPE);
                            }

                        }
                    }

                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
