﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;


namespace NielsenIQ.CRM.Plugins
{
    public class OnPreCreate_Opportunity_LinkAccountFromLeadContact : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnPreCreate_Opportunity: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity oppoObj = (Entity)context.InputParameters["Target"];
                    tracing.Trace("OnPreCreate_Opportunity: Checking if Opportunity is Originated from Lead");
                    if (oppoObj != null && oppoObj.Id != Guid.Empty && oppoObj.Attributes.Contains("originatingleadid") && oppoObj.GetAttributeValue<EntityReference>("originatingleadid").Id != Guid.Empty)
                    {
                        tracing.Trace("OnPreCreate_Opportunity: Retrieving Contact From Lead");
                        Entity leadResult = service.Retrieve(oppoObj.GetAttributeValue<EntityReference>("originatingleadid").LogicalName, oppoObj.GetAttributeValue<EntityReference>("originatingleadid").Id, new ColumnSet(new string[] { "parentcontactid", "transactioncurrencyid", "niq_salesorgid", "niq_salesgroupsalesorgid", "estimatedclosedate", "subject", "campaignid" }));
                        tracing.Trace("OnPreCreate_Opportunity: Retrieving Account from Contact");
                        if (leadResult != null && leadResult.Id != Guid.Empty && leadResult.Attributes.Contains("parentcontactid") && leadResult.GetAttributeValue<EntityReference>("parentcontactid").Id != Guid.Empty)
                        {

                            if (leadResult.Attributes.Contains("transactioncurrencyid"))
                            {
                                tracing.Trace("OnPreCreate_Opportunity:currency" + leadResult.GetAttributeValue<EntityReference>("transactioncurrencyid").Name);
                                oppoObj["transactioncurrencyid"] = leadResult.GetAttributeValue<EntityReference>("transactioncurrencyid");
                            }
                            if (leadResult.Attributes.Contains("estimatedclosedate"))
                            {
                                tracing.Trace("OnPreCreate_Opportunity: Est close date" + leadResult.GetAttributeValue<DateTime>("estimatedclosedate"));
                                oppoObj["estimatedclosedate"] = leadResult.GetAttributeValue<DateTime>("estimatedclosedate");
                            }
                            if (leadResult.Attributes.Contains("subject"))
                            {
                                tracing.Trace("OnPreCreate_Opportunity:Subject" + leadResult.GetAttributeValue<string>("subject"));
                                oppoObj["name"] = leadResult.GetAttributeValue<string>("subject");
                            }
                            if (leadResult.Attributes.Contains("niq_salesgroupsalesorgid"))
                            {
                                tracing.Trace("OnPreCreate_Opportunity: salesgrpsalesorg" + leadResult.GetAttributeValue<EntityReference>("niq_salesgroupsalesorgid").Id);
                                oppoObj["niq_salesgroupsalesorgid"] = leadResult.GetAttributeValue<EntityReference>("niq_salesgroupsalesorgid");
                            }
                            if (leadResult.Attributes.Contains("niq_salesorgid"))
                            {
                                tracing.Trace("OnPreCreate_Opportunity: salesorg" + leadResult.GetAttributeValue<EntityReference>("niq_salesorgid").Id);
                                oppoObj["niq_salesorgid"] = leadResult.GetAttributeValue<EntityReference>("niq_salesorgid");
                            }
                            if (leadResult.Attributes.Contains("campaignid"))
                            {
                                tracing.Trace("OnPreCreate_Opportunity: campaign" + leadResult.GetAttributeValue<EntityReference>("campaignid").Id);
                                oppoObj["campaignid"] = leadResult.GetAttributeValue<EntityReference>("campaignid");
                            }
                            Entity contactResult = service.Retrieve("contact", leadResult.GetAttributeValue<EntityReference>("parentcontactid").Id, new ColumnSet("parentcustomerid"));
                            tracing.Trace("OnPreCreate_Opportunity: Updating Oppo");
                            if (contactResult != null && contactResult.Id != Guid.Empty && contactResult.Attributes.Contains("parentcustomerid") && contactResult.GetAttributeValue<EntityReference>("parentcustomerid").Id != Guid.Empty)
                            {
                                oppoObj["niq_opportunitytype"] = new OptionSetValue(1);
                                tracing.Trace("OnPreCreate_Opportunity: contact" + contactResult.GetAttributeValue<EntityReference>("parentcustomerid").Id);
                                oppoObj["parentaccountid"] = contactResult.GetAttributeValue<EntityReference>("parentcustomerid");

                            }

                        }

                    }
                    if (oppoObj != null && oppoObj.Id != Guid.Empty && !oppoObj.Attributes.Contains("niq_valueofproductenhancements"))
                    {
                        oppoObj["niq_valueofproductenhancements"] = new Money((decimal)0);
                    }
                    //Pre-Proposal
                    if (oppoObj != null && oppoObj.Id != Guid.Empty && !oppoObj.Attributes.Contains("niq_stage"))
                    {
                        oppoObj["niq_stage"] = "Pre-Proposal";
                    }
                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }

        }
    }
}
