﻿using System;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Collections.Generic;
using Microsoft.Crm.Sdk.Messages;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdateDDAR_UpdateQuote : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdateDDAR_UpdateQuote: Getting the target entity from Input Parameters.");

                    // Obtain the target entity from the input parameters.
                    Entity ddarObj = (Entity)context.InputParameters["Target"];
                    if (ddarObj != null && ddarObj.Id != Guid.Empty)
                    {
                        tracing.Trace("OnUpdateDDAR_UpdateQuote: ddar id" + ddarObj.Id);
                        Entity retDDAR = service.Retrieve(ddarObj.LogicalName, ddarObj.Id, new ColumnSet("niq_approvalstatus", "niq_name", "niq_pricingapproval", "niq_fundusageapproval", "niq_quoteheaderdetailsapproval", "niq_approvalrejectioncomments", "niq_quoteid", "niq_customertype", "niq_termtype", "niq_annualapicola", "niq_annualincreasetype", "niq_apicolastructure", "niq_evergreenautorenewalannualapi", "niq_terminationnotificationmonths", "niq_incentivetype", "niq_incentivevalueniqannualimpact", "niq_numberofftes", "niq_interestrateonlatepayment", "niq_agreementpaymenttermsid", "niq_paymenttermdescription", "statecode", "niq_contractstartdate", "niq_contractenddate", "niq_totalamount", "niq_ratecardprice", "niq_discountamount", "niq_discount"));
                        if (retDDAR.Attributes.Contains("statecode") && retDDAR.GetAttributeValue<OptionSetValue>("statecode") != null && retDDAR.GetAttributeValue<OptionSetValue>("statecode").Value == 1 && (retDDAR.Attributes.Contains("niq_approvalstatus") && retDDAR.GetAttributeValue<OptionSetValue>("niq_approvalstatus") != null && (retDDAR.GetAttributeValue<OptionSetValue>("niq_approvalstatus").Value == 3 || retDDAR.GetAttributeValue<OptionSetValue>("niq_approvalstatus").Value == 4)))
                        {
                            if (retDDAR != null && retDDAR.Id != Guid.Empty && retDDAR.Attributes.Contains("niq_quoteid") && retDDAR.GetAttributeValue<EntityReference>("niq_quoteid").Id != Guid.Empty)
                            {
                                Entity retQuote = service.Retrieve(retDDAR.GetAttributeValue<EntityReference>("niq_quoteid").LogicalName, retDDAR.GetAttributeValue<EntityReference>("niq_quoteid").Id, new ColumnSet("ownerid", "customerid", "opportunityid", "name", "niq_customertype", "niq_termtype", "niq_annualincreasetype", "niq_annualapicola", "niq_apistructure", "niq_evergreenautorenewalannualapi", "niq_terminationnotificationmonths", "niq_numberofftes", "niq_incentivetype", "niq_incentivevalueniqannualimpact", "niq_interestrateonlatepayment", "niq_paymenttermsid", "niq_paymenttermdescription", "niq_incentivetype", "niq_incentivevalueniqannualimpact", "niq_contractstartdate", "niq_contractenddate", "totalamount", "niq_ratecardprice", "niq_discountamount", "niq_discount"));

                                tracing.Trace("OnUpdateDDAR_UpdateQuote: ret ddar" + retDDAR.Id);
                                bool update = false;
                                Entity updQuote = new Entity(retDDAR.GetAttributeValue<EntityReference>("niq_quoteid").LogicalName, retDDAR.GetAttributeValue<EntityReference>("niq_quoteid").Id);
                                tracing.Trace("OnUpdateDDAR_UpdateQuote: quote id" + updQuote.Id);

                                if (retDDAR.Attributes.Contains("niq_customertype") && retDDAR.GetAttributeValue<OptionSetValue>("niq_customertype") != null)
                                {
                                    updQuote["niq_customertype"] = new OptionSetValue(retDDAR.GetAttributeValue<OptionSetValue>("niq_customertype").Value);
                                    update = true;
                                }
                                if (retDDAR.Attributes.Contains("niq_termtype") && retDDAR.GetAttributeValue<OptionSetValue>("niq_termtype") != null)
                                {
                                    updQuote["niq_termtype"] = new OptionSetValue(retDDAR.GetAttributeValue<OptionSetValue>("niq_termtype").Value);
                                    update = true;
                                }
                                if (retDDAR.Attributes.Contains("niq_annualapicola") && retDDAR.GetAttributeValue<decimal>("niq_annualapicola") != 0.0M)
                                {
                                    updQuote["niq_annualapicola"] = (decimal)retDDAR.GetAttributeValue<decimal>("niq_annualapicola");
                                    update = true;
                                }
                                //DYNCRM-22351 - Field hidden on the form
                                //if (retDDAR.Attributes.Contains("niq_annualincreasetype") && retDDAR.GetAttributeValue<OptionSetValue>("niq_annualincreasetype") != null)
                                //{
                                //    updQuote["niq_annualincreasetype"] = new OptionSetValue(retDDAR.GetAttributeValue<OptionSetValue>("niq_annualincreasetype").Value);
                                //    update = true;
                                //}
                                if (retDDAR.Attributes.Contains("niq_apicolastructure") && retDDAR.GetAttributeValue<OptionSetValue>("niq_apicolastructure") != null)
                                {
                                    updQuote["niq_apistructure"] = new OptionSetValue(retDDAR.GetAttributeValue<OptionSetValue>("niq_apicolastructure").Value);

                                    update = true;
                                }
                                if (retDDAR.Attributes.Contains("niq_evergreenautorenewalannualapi") && retDDAR.GetAttributeValue<decimal>("niq_evergreenautorenewalannualapi") != 0.0M)
                                {
                                    updQuote["niq_evergreenautorenewalannualapi"] = (decimal)retDDAR.GetAttributeValue<decimal>("niq_evergreenautorenewalannualapi");
                                    update = true;
                                }
                                if (retDDAR.Attributes.Contains("niq_terminationnotificationmonths") && retDDAR.GetAttributeValue<int>("niq_terminationnotificationmonths") >= 0)
                                {
                                    updQuote["niq_terminationnotificationmonths"] = (int)retDDAR.GetAttributeValue<int>("niq_terminationnotificationmonths");

                                    update = true;
                                }
                                if (retDDAR.Attributes.Contains("niq_numberofftes") && retDDAR.GetAttributeValue<decimal>("niq_numberofftes") >= 0)
                                {
                                    updQuote["niq_numberofftes"] = (decimal)retDDAR.GetAttributeValue<decimal>("niq_numberofftes");
                                    update = true;
                                }
                                //DYNCRM-21869 - Field hidden on the form
                                // if (retDDAR.Attributes.Contains("niq_incentivetype") && retDDAR.GetAttributeValue<OptionSetValue>("niq_incentivetype") != null)
                                // {
                                //     updQuote["niq_incentivetype"] = new OptionSetValue(retDDAR.GetAttributeValue<OptionSetValue>("niq_incentivetype").Value);

                                //     update = true;
                                // }
                                // if (retDDAR.Attributes.Contains("niq_incentivevalueniqannualimpact") && retDDAR.GetAttributeValue<int>("niq_incentivevalueniqannualimpact") >= 0)
                                // {
                                //     updQuote["niq_incentivevalueniqannualimpact"] = (int)retDDAR.GetAttributeValue<int>("niq_incentivevalueniqannualimpact");
                                //     update = true;
                                // }
                                if (retDDAR.Attributes.Contains("niq_interestrateonlatepayment") && retDDAR.GetAttributeValue<decimal>("niq_interestrateonlatepayment") != 0.0M)
                                {
                                    updQuote["niq_interestrateonlatepayment"] = (decimal)retDDAR.GetAttributeValue<decimal>("niq_interestrateonlatepayment");
                                    update = true;
                                }
                                if (retDDAR.Attributes.Contains("niq_agreementpaymenttermsid") && retDDAR.GetAttributeValue<EntityReference>("niq_agreementpaymenttermsid").Id != Guid.Empty)
                                {
                                    updQuote["niq_paymenttermsid"] = new EntityReference(retDDAR.GetAttributeValue<EntityReference>("niq_agreementpaymenttermsid").LogicalName, retDDAR.GetAttributeValue<EntityReference>("niq_agreementpaymenttermsid").Id);
                                    update = true;
                                }
                                if (retDDAR.Attributes.Contains("niq_paymenttermdescription") && retDDAR["niq_paymenttermdescription"].ToString() != null)
                                {
                                    updQuote["niq_paymenttermdescription"] = retDDAR["niq_paymenttermdescription"].ToString();
                                    update = true;
                                }
                                updQuote["niq_fieldsrequiringapproval"] = null;
                                if (update)
                                {
                                    service.Update(updQuote);
                                }

                                Entity updDDAR = new Entity(ddarObj.LogicalName, ddarObj.Id);
                                if (retQuote.Contains("niq_contractstartdate") && retQuote.GetAttributeValue<DateTime>("niq_contractstartdate") != null)
                                {
                                    updDDAR["niq_contractstartdate"] = retQuote["niq_contractstartdate"];
                                }
                                if (retQuote.Contains("niq_contractenddate") && retQuote.GetAttributeValue<DateTime>("niq_contractenddate") != null)
                                {
                                    updDDAR["niq_contractenddate"] = retQuote["niq_contractenddate"];
                                }
                                if (retQuote.Contains("totalamount") && retQuote.GetAttributeValue<Money>("totalamount") != null)
                                {
                                    updDDAR["niq_totalamount"] = retQuote["totalamount"];
                                }
                                if (retQuote.Contains("niq_ratecardprice") && retQuote.GetAttributeValue<Money>("niq_ratecardprice") != null)
                                {
                                    updDDAR["niq_ratecardprice"] = retQuote["niq_ratecardprice"];
                                }
                                if (retQuote.Contains("niq_discountamount") && retQuote.GetAttributeValue<Money>("niq_discountamount") != null)
                                {
                                    updDDAR["niq_discountamount"] = retQuote["niq_discountamount"];
                                }
                                if (retQuote.Contains("niq_discount"))
                                {
                                    updDDAR["niq_approveddiscount"] = (decimal)retQuote.GetAttributeValue<decimal>("niq_discount");
                                }
                                updDDAR["niq_retriggerddar"] = true;
                                tracing.Trace("OnUpdateDDAR_UpdateQuote: Updating DDAR from Quote.");
                                service.Update(updDDAR);


                                string fetchQueueXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='queue'>
                                                            <attribute name='name' />
                                                            <attribute name='emailaddress' />
                                                            <attribute name='queueid' />
                                                            <order attribute='name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='name' operator='eq' value='Sales Marketing Notifications' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                var resultQueue = service.RetrieveMultiple(new FetchExpression(fetchQueueXml));
                                if (resultQueue != null && resultQueue.Entities != null && resultQueue.Entities.Count == 1)
                                {
                                    tracing.Trace("OnUpdateDDAR_UpdateQuote: resultqueue" + resultQueue.Entities.Count);
                                    string customerTypeQ = retQuote.Attributes.Contains("niq_customertype") ? retQuote.FormattedValues["niq_customertype"].ToString() : "";
                                    string termTypeQ = retQuote.Attributes.Contains("niq_termtype") ? retQuote.FormattedValues["niq_termtype"].ToString() : "";
                                    string annualIncreaseTypeQ = retQuote.Attributes.Contains("niq_annualincreasetype") ? retQuote.FormattedValues["niq_annualincreasetype"].ToString() : "";
                                    string apiColaQ = retQuote.Attributes.Contains("niq_annualapicola") ? retQuote.FormattedValues["niq_annualapicola"].ToString() : "";
                                    string apiStructureQ = retQuote.Attributes.Contains("niq_apistructure") ? retQuote.FormattedValues["niq_apistructure"].ToString() : "";
                                    string evergreenQ = retQuote.Attributes.Contains("niq_evergreenautorenewalannualapi") ? retQuote.FormattedValues["niq_evergreenautorenewalannualapi"].ToString() : "";
                                    string termNotiQ = retQuote.Attributes.Contains("niq_terminationnotificationmonths") ? retQuote.FormattedValues["niq_terminationnotificationmonths"].ToString() : "";
                                    string noOfFteQ = retQuote.Attributes.Contains("niq_numberofftes") ? retQuote.FormattedValues["niq_numberofftes"].ToString() : "";
                                    string interestRateQ = retQuote.Attributes.Contains("niq_interestrateonlatepayment") ? retQuote.FormattedValues["niq_interestrateonlatepayment"].ToString() : "";
                                    string paymenttermQ = retQuote.Attributes.Contains("niq_paymenttermsid") ? retQuote.GetAttributeValue<EntityReference>("niq_paymenttermsid").Name : "";
                                    string paymentterdescmQ = retQuote.Attributes.Contains("niq_paymenttermdescription") ? retQuote["niq_paymenttermdescription"].ToString() : "";
                                    string name = retQuote.Attributes.Contains("name") ? retQuote.GetAttributeValue<string>("name") : "";
                                    string oppoName = retQuote.Attributes.Contains("opportunityid") ? retQuote.FormattedValues["opportunityid"].ToString() : "";
                                    //Added as it shows the key is not present in the dictionary
                                    string customerName = "";
                                    if (retQuote.Attributes.Contains("customerid") && retQuote.FormattedValues.ContainsKey("customerid"))
                                    {
                                        customerName = retQuote.FormattedValues["customerid"]?.ToString() ?? "";
                                    }

                                    string customerTypeD = retDDAR.Attributes.Contains("niq_customertype") ? retDDAR.FormattedValues["niq_customertype"].ToString() : "";
                                    string termTypeD = retDDAR.Attributes.Contains("niq_termtype") ? retDDAR.FormattedValues["niq_termtype"].ToString() : "";
                                    string annualIncreaseTypeD = retDDAR.Attributes.Contains("niq_annualincreasetype") ? retDDAR.FormattedValues["niq_annualincreasetype"].ToString() : "";
                                    string apiColaD = retDDAR.Attributes.Contains("niq_annualapicola") ? retDDAR.FormattedValues["niq_annualapicola"].ToString() : "";
                                    string apiStructureD = retDDAR.Attributes.Contains("niq_apicolastructure") ? retDDAR.FormattedValues["niq_apicolastructure"].ToString() : "";
                                    string evergreenD = retDDAR.Attributes.Contains("niq_evergreenautorenewalannualapi") ? retDDAR.FormattedValues["niq_evergreenautorenewalannualapi"].ToString() : "";
                                    string termNotiD = retDDAR.Attributes.Contains("niq_terminationnotificationmonths") ? retDDAR.FormattedValues["niq_terminationnotificationmonths"].ToString() : "";
                                    string noOfFteD = retDDAR.Attributes.Contains("niq_numberofftes") ? retDDAR.FormattedValues["niq_numberofftes"].ToString() : "";
                                    string interestRateD = retDDAR.Attributes.Contains("niq_interestrateonlatepayment") ? retDDAR.FormattedValues["niq_interestrateonlatepayment"].ToString() : "";
                                    string paymenttermD = retDDAR.Attributes.Contains("niq_agreementpaymenttermsid") ? retDDAR.GetAttributeValue<EntityReference>("niq_agreementpaymenttermsid").Name : "";
                                    string paymenttermdescD = retDDAR.Attributes.Contains("niq_paymenttermdescription") ? retDDAR["niq_paymenttermdescription"].ToString() : "";
                                    string pricingApproval = retDDAR.Attributes.Contains("niq_pricingapproval") ? retDDAR.FormattedValues["niq_pricingapproval"].ToString() : "";
                                    string fundUsageApp = retDDAR.Attributes.Contains("niq_fundusageapproval") ? retDDAR.FormattedValues["niq_fundusageapproval"].ToString() : "";
                                    string quoteHeaderApp = retDDAR.Attributes.Contains("niq_quoteheaderdetailsapproval") ? retDDAR.FormattedValues["niq_quoteheaderdetailsapproval"].ToString() : "";
                                    string comment = retDDAR.Attributes.Contains("niq_approvalrejectioncomments") ? retDDAR.GetAttributeValue<string>("niq_approvalrejectioncomments") : "";
                                    string ddarName = retDDAR.Attributes.Contains("niq_name") ? retDDAR.GetAttributeValue<string>("niq_name") : "";
                                    string approvalStatus = retDDAR.Attributes.Contains("niq_approvalstatus") ? retDDAR.FormattedValues["niq_approvalstatus"].ToString() : null;
                                    tracing.Trace("OnUpdateDDAR_UpdateQuote:approvalstatus " + approvalStatus);
                                    string oppoUrl = "";
                                    string quoteUrl = "";
                                    string ddarUrl = "";
                                    string fetchUrlXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='niq_configurationsetting'>
                                                                <attribute name='niq_configurationsettingid' />
                                                                <attribute name='niq_name' />
                                                                <attribute name='createdon' />
                                                                <attribute name='niq_to' />
                                                                <order attribute='niq_name' descending='false' />
                                                                <filter type='and'>
                                                                  <condition attribute='niq_name' operator='eq' value='CRMURL' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";
                                    var resultUrl = service.RetrieveMultiple(new FetchExpression(fetchUrlXml));
                                    if (resultUrl != null && resultUrl.Entities != null && resultUrl.Entities.Count == 1)
                                    {
                                        tracing.Trace("OnUpdateDDAR_UpdateQuote: url received");
                                        Entity csUrl = resultUrl.Entities.FirstOrDefault();
                                        if (csUrl != null && csUrl.Id != Guid.Empty && csUrl.Attributes.Contains("niq_to"))
                                        {

                                            string url = csUrl.GetAttributeValue<string>("niq_to");
                                            tracing.Trace("OnUpdateDDAR_UpdateQuote:url " + url);
                                            quoteUrl = "<a href='" + string.Format(url, retQuote.LogicalName, retQuote.Id) + "'>" + name + "</a>";
                                            tracing.Trace("OnUpdateDDAR_UpdateQuote: quote url" + quoteUrl);
                                            oppoUrl = "<a href='" + string.Format(url, retQuote.GetAttributeValue<EntityReference>("opportunityid").LogicalName, retQuote.GetAttributeValue<EntityReference>("opportunityid").Id) + "'>" + oppoName + "</a>";
                                            tracing.Trace("OnUpdateDDAR_UpdateQuote: oppo url " + oppoUrl);
                                            ddarUrl = "<a href='" + string.Format(url, retDDAR.LogicalName, retDDAR.Id) + "'>" + ddarName + "</a>";

                                        }
                                    }



                                    Entity retOppo = service.Retrieve(retQuote.GetAttributeValue<EntityReference>("opportunityid").LogicalName, retQuote.GetAttributeValue<EntityReference>("opportunityid").Id, new ColumnSet("ownerid"));


                                    Entity queue = resultQueue.Entities.FirstOrDefault();


                                    Entity fromActivityParty = new Entity("activityparty");
                                    Entity toActivityParty1 = new Entity("activityparty");
                                    Entity toActivityParty2 = new Entity("activityparty");


                                    fromActivityParty["partyid"] = new EntityReference("queue", queue.Id);
                                    toActivityParty1["partyid"] = new EntityReference(retQuote.GetAttributeValue<EntityReference>("ownerid").LogicalName, retQuote.GetAttributeValue<EntityReference>("ownerid").Id);
                                    toActivityParty2["partyid"] = new EntityReference(retOppo.GetAttributeValue<EntityReference>("ownerid").LogicalName, retOppo.GetAttributeValue<EntityReference>("ownerid").Id);

                                    Entity email = new Entity("email");
                                    email["from"] = new Entity[] { fromActivityParty };
                                    if (retQuote.GetAttributeValue<EntityReference>("ownerid").Id != retQuote.GetAttributeValue<EntityReference>("ownerid").Id)
                                    {
                                        email["to"] = new Entity[] { toActivityParty1, toActivityParty2 };
                                    }
                                    else
                                    {
                                        email["to"] = new Entity[] { toActivityParty1 };
                                    }
                                    email["regardingobjectid"] = new EntityReference(retQuote.LogicalName, retQuote.Id);
                                    email["subject"] = "Your Quote is " + approvalStatus;
                                    email["description"] = "<p>Hi,</p><br>"
    + "<p>Deal Desk request " + ddarUrl + "  for Quote " + quoteUrl + ", Opportunity " + oppoUrl + " for Account \" " + customerName + " \" has been " + approvalStatus + ".</p>"
    + "<p><strong>Comments:</strong> " + comment + "</p>"
    + "<p> Pricing Approval: " + pricingApproval + "</p>"
    + "<p>Fund Usage Approval:" + fundUsageApp + "</p>"
    + "<p>Quote Header Details Approval:" + quoteHeaderApp + "</p>"
    + "<table>"
    + "  <tr>"
    + "   <th>Quote Header Value                </th>  "
    + "   <th>Submitted value                      </th>"
    + "    <th>Value approved by Deal Desk </th>"
    + "  </tr>"
    + "  <tr>"
    + "    <td>Customer Type   </td>"
    + "    <td>" + customerTypeQ + " </td>"
    + "    <td>" + customerTypeD + " </td>"
    + "  </tr>"
    + "  <tr>"
    + "    <td>Term Type</td>"
    + "    <td>" + termTypeQ + "</td>"
    + "    <td>" + termTypeD + "</td>"
    + "  </tr>"
    + " <tr>"
    + "    <td>Annual Increase Type</td>"
    + "    <td>" + annualIncreaseTypeQ + "</td>"
    + "    <td>" + annualIncreaseTypeD + "</td>"
    + "  </tr>"
    + " <tr>"
    + "    <td>Annual API/COLA %</td>"
    + "    <td>" + apiColaQ + "</td>"
    + "    <td>" + apiColaD + "</td>"
    + "  </tr>"
    + " <tr>"
    + "    <td>API Structure</td>"
    + "    <td>" + apiStructureQ + "</td>"
    + "    <td>" + apiStructureD + "</td>"
    + "  </tr>"
    + " <tr>"
    + "    <td>Termination Notification (Months)</td>"
    + "    <td>" + termNotiQ + "</td>"
    + "    <td>" + termNotiD + "</td>"
    + "  </tr>"
    + "<tr>"
    + "    <td>Number of FTEs</td>"
    + "    <td>" + noOfFteQ + "</td>"
    + "    <td>" + noOfFteD + "</td>"
    + "  </tr>"
    + "<tr>"
    + "    <td>Interest Rate on Late Payment</td>"
    + "    <td>" + interestRateQ + "</td>"
    + "    <td>" + interestRateD + "</td>"
    + "  </tr>"
    + "<tr>"
    + "    <td>Payment Terms</td>"
    + "    <td>" + paymenttermQ + "</td>"
    + "    <td>" + paymenttermD + "</td>"
    + "  </tr>"
    + "<tr>"
    + "    <td>Payment Terms Description</td>"
    + "    <td>" + paymentterdescmQ + "</td>"
    + "    <td>" + paymenttermdescD + "</td>"
    + "  </tr>"
    + "<tr>"
    + "</table>"
    + "<p>Thank you.</p><br>"
    + "<p><strong>Disclaimer:</strong> " + "\"Do not reply to this email group as it is not monitored. \"" + "</p>";
                                    email["directioncode"] = true;
                                    Guid emailId = service.Create(email);

                                    // Use the SendEmail message to send an e-mail message.
                                    SendEmailRequest sendEmailRequest = new SendEmailRequest
                                    {
                                        EmailId = emailId,
                                        TrackingToken = "",
                                        IssueSend = true
                                    };

                                    SendEmailResponse sendEmailresp = (SendEmailResponse)service.Execute(sendEmailRequest);
                                }

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
