﻿using System;
using System.Runtime.Remoting.Services;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace NielsenIQ.CRM.Plugins
{
    public class OnPreCreateQuoteProduct_Validation : IPlugin
    {
        OptionSetValue InCompleteManualInput = new OptionSetValue(610570001);
        ITracingService tracing;
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    if (context.MessageName == "Create")
                    {
                        tracing.Trace("OnPreCreate_QuoteProduct_Validation: Getting the target entity from Input Parameters..");
                        Entity quoteProductobj = (Entity)context.InputParameters["Target"];

                        if (quoteProductobj.Attributes.Contains("isproductoverridden") && quoteProductobj["isproductoverridden"] != null && (bool)quoteProductobj["isproductoverridden"]
                            && quoteProductobj.Attributes.Contains("productdescription") && quoteProductobj["productdescription"] != null && (string)quoteProductobj["productdescription"] == "Dummy Product For Total Amount Set")
                        {
                            quoteProductobj["priceperunit"] = new Money(0);
                            quoteProductobj["baseamount"] = new Money(0);
                        }
                        if (quoteProductobj.Attributes.Contains("transactioncurrencyid") && quoteProductobj.GetAttributeValue<EntityReference>("transactioncurrencyid").Id != Guid.Empty)
                        {
                            Entity currency = service.Retrieve(quoteProductobj.GetAttributeValue<EntityReference>("transactioncurrencyid").LogicalName, quoteProductobj.GetAttributeValue<EntityReference>("transactioncurrencyid").Id, new ColumnSet("isocurrencycode"));
                            if (currency != null && currency.Attributes.Contains("isocurrencycode"))
                            {
                                quoteProductobj["niq_isocurrencycodeqp"] = currency.GetAttributeValue<string>("isocurrencycode");
                            }
                        }
                        //Before the start,end dates and frequency values are populated. the revenue, billingstatus values are set here.
                        //Default value of revenue and billing schedule status == "Incomplete data(Auto)"
                        bool asbRateCardNull = false;
                        if (quoteProductobj.Attributes.Contains("niq_type") && quoteProductobj["niq_type"] != null && quoteProductobj.Attributes.Contains("niq_istimebased") && quoteProductobj["niq_istimebased"] != null)
                        {
                            OptionSetValue productType = quoteProductobj.GetAttributeValue<OptionSetValue>("niq_type");
                            tracing.Trace("product type :" + productType.Value);
                            tracing.Trace("istimebased :" + quoteProductobj.GetAttributeValue<bool>("niq_istimebased"));
                            if (productType.Value == 1 && !quoteProductobj.GetAttributeValue<bool>("niq_istimebased"))
                            {
                                string rateCardUpdateFrequency = quoteProductobj.Contains("niq_ratecardupdatefrequency") && quoteProductobj.GetAttributeValue<string>("niq_ratecardupdatefrequency") != null ? quoteProductobj.GetAttributeValue<string>("niq_ratecardupdatefrequency") : string.Empty;
                                tracing.Trace("Adhoc serice based: niq_ratecardupdatefrequency :" + rateCardUpdateFrequency);
                                if (string.IsNullOrEmpty(rateCardUpdateFrequency))
                                {
                                    tracing.Trace("ASB - ratecard is empty, set revenue and billing status as Incomplete Manual Input.");
                                    //quoteProductobj["niq_revenueschedulestatus"] = new OptionSetValue(InCompleteManualInput.Value);
                                    //quoteProductobj["niq_billingschedulestatus"] = new OptionSetValue(InCompleteManualInput.Value);//logic change DYNCRM-23655
                                    asbRateCardNull = true;
                                }
                            }
                        }
                        tracing.Trace("setting calculated term length.");
                        if (quoteProductobj.Contains("niq_termlength") && quoteProductobj["niq_termlength"] != null)
                        {
                            //while cloning, manageexisting and creating child. the calculated termlenght will populated from original quote product.
                            tracing.Trace("niq_calculatedtermlength contains ?:-" + quoteProductobj.Contains("niq_calculatedtermlength"));
                            if (!quoteProductobj.Contains("niq_calculatedtermlength") || 
                                (quoteProductobj.Contains("niq_calculatedtermlength") && quoteProductobj["niq_calculatedtermlength"]==null))
                            {
                                tracing.Trace("if niq_calculatedtermlength is not present then populate the value during creation");
                                if (asbRateCardNull)
                                    quoteProductobj["niq_calculatedtermlength"] = (double)1;
                                else
                                    quoteProductobj["niq_calculatedtermlength"] = quoteProductobj["niq_termlength"];

                            }
                        }
                    }

                    if (context.MessageName == "Update")
                    {
                        tracing.Trace("OnPreCreate_QuoteProduct_Validation: Update Case based on niq_expvalidation, Getting the target entity from Input Parameters.");
                        Entity quote = (Entity)context.InputParameters["Target"];
                        if (quote != null && quote.Id != Guid.Empty)
                        {
                            tracing.Trace("OnPreCreate_QuoteProduct_Validation: Quote ID: " + quote.Id.ToString());
                            Entity retQuote = service.Retrieve(quote.LogicalName, quote.Id, new ColumnSet("niq_expvalidation"));
                            bool expValidation = retQuote.GetAttributeValue<bool>("niq_expvalidation");
                            tracing.Trace("OnPreCreate_QuoteProduct_Validation: Quote ID: expValidation " + expValidation.ToString());
                            if (expValidation == false)
                            {
                                string fetchXmlQuoteProducts = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                    <entity name='quotedetail'>
                                                                    <attribute name='priceperunit'/>
                                                                    <attribute name='quotedetailname'/>
                                                                    <attribute name='quotedetailid'/>
                                                                    <attribute name='transactioncurrencyid'/>
                                                                    <attribute name='productdescription'/>
                                                                    <attribute name='isproductoverridden'/>
                                                                    <attribute name='baseamount'/>
                                                                    <attribute name='niq_quoteproductvalidated'/>
                                                                    <order attribute='quotedetailname' descending='false'/>
                                                                    <filter type='and'>
                                                                    <condition attribute='quoteid' operator='eq' value='{0}'/>
                                                                    <filter type='or'>
                                                                        <condition attribute='niq_quoteproductvalidated' operator='null'/>
                                                                        <condition attribute='niq_quoteproductvalidated' operator='eq' value='0'/>
                                                                    </filter>
                                                                    </filter>
                                                                    </entity>
                                                                    </fetch>";

                                tracing.Trace("OnPreCreate_QuoteProduct_Validation: Getting the quote products.");
                                fetchXmlQuoteProducts = string.Format(fetchXmlQuoteProducts, quote.Id);
                                EntityCollection quoteProducts = service.RetrieveMultiple(new FetchExpression(fetchXmlQuoteProducts));

                                if (quoteProducts != null && quoteProducts.Entities.Count > 0)
                                {
                                    foreach (Entity quoteP in quoteProducts.Entities)
                                    {
                                        tracing.Trace("OnPreCreate_QuoteProduct_Validation: bool" + (bool)quoteP["niq_quoteproductvalidated"]);
                                        tracing.Trace("OnPreCreate_QuoteProduct_Validation: QuoteProductName: " + quoteP["quotedetailname"]);
                                        if (quoteP.Contains("niq_quoteproductvalidated") && (bool)quoteP["niq_quoteproductvalidated"] == false)
                                        {
                                            if (quoteP.Contains("isproductoverridden") && (bool)quoteP["isproductoverridden"] && quoteP.Contains("productdescription") &&
                            (string)quoteP["productdescription"] == "Dummy Product For Total Amount Set")
                                            {
                                                quoteP["priceperunit"] = new Money(0);
                                                quoteP["baseamount"] = new Money(0);
                                            }
                                            if (quoteP.Attributes.Contains("transactioncurrencyid") && quoteP.GetAttributeValue<EntityReference>("transactioncurrencyid").Id != Guid.Empty)
                                            {
                                                Entity currency = service.Retrieve(quoteP.GetAttributeValue<EntityReference>("transactioncurrencyid").LogicalName, quoteP.GetAttributeValue<EntityReference>("transactioncurrencyid").Id, new ColumnSet("isocurrencycode"));
                                                if (currency != null && currency.Attributes.Contains("isocurrencycode"))
                                                {
                                                    quoteP["niq_isocurrencycodeqp"] = currency.GetAttributeValue<string>("isocurrencycode");
                                                }
                                            }
                                            quoteP["niq_quoteproductvalidated"] = true;
                                            service.Update(quoteP);
                                        }

                                    }
                                }


                            }

                        }

                    }


                }
            }
            catch (Exception ex)
            {
                tracing.Trace("exception: " + ex.Message);
            }
        }
    }

}
