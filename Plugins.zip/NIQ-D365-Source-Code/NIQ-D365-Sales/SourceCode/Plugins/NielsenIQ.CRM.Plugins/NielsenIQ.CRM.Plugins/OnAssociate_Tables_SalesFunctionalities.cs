﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace NielsenIQ.CRM.Plugins
{

    public class OnAssociate_Tables_SalesFunctionalities : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the execution context from the service provider
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            tracingService.Trace("Plugin execution started.");

            if (context.MessageName == "Associate")
            {
                tracingService.Trace("Message is 'Associate'.");

                if (context.InputParameters.Contains("Relationship"))
                {
                    Relationship relationship = (Relationship)context.InputParameters["Relationship"];
                    tracingService.Trace("Relationship schema name: {0}", relationship.SchemaName);

                    if (relationship.SchemaName == "systemuserroles_association")
                    {
                        try
                        {
                            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference target &&
                                context.InputParameters.Contains("RelatedEntities") && context.InputParameters["RelatedEntities"] is EntityReferenceCollection relatedEntities)
                            {
                                CreateSalesUserDefaultSetting(target, relatedEntities, service, tracingService);
                            }
                        }
                        catch (Exception ex)
                        {
                            tracingService.Trace("Exception: {0}", ex.ToString());
                            throw new InvalidPluginExecutionException("An error occurred in CreateSalesUserDefaultSetting: " + ex.Message);
                        }
                    }
                    else
                    {
                        tracingService.Trace("Exiting because the relationship is not 'systemuserroles_association'.");
                    }
                }
            }

            tracingService.Trace("Plugin execution completed.");
        }

        private void CreateSalesUserDefaultSetting(EntityReference target, EntityReferenceCollection relatedEntities, IOrganizationService service, ITracingService tracingService)
        {
            tracingService.Trace("Target entity ID: {0}", target.Id);
            tracingService.Trace("Related entities count: {0}", relatedEntities.Count);

            // Retrieve configuration settings to get the list of role GUIDs
            Entity configurationSettings = service.Retrieve("niq_configurationsetting", new Guid("9d0db5e8-4917-ef11-9f89-6045bd9d8626"), new ColumnSet("niq_to"));
            string niqToValue = configurationSettings.GetAttributeValue<string>("niq_to");
            string[] guidStrings = niqToValue.Split(',');

            List<Guid> guidList = new List<Guid>();
            foreach (string guidString in guidStrings)
            {
                if (Guid.TryParse(guidString, out Guid guid))
                {
                    guidList.Add(guid);
                }
            }

            foreach (EntityReference relatedEntity in relatedEntities)
            {
                if (relatedEntity.LogicalName == "role" && guidList.Contains(relatedEntity.Id))
                {
                    tracingService.Trace("Checking for existing Sales User Default Setting for user ID: {0}", target.Id);

                    // Query to check if the Sales User Default Setting already exists
                    QueryExpression query = new QueryExpression("niq_salesuserdefaultsettings")
                    {
                        ColumnSet = new ColumnSet("niq_user"),
                        Criteria = new FilterExpression
                        {
                            Conditions =
                            {
                                new ConditionExpression("niq_user", ConditionOperator.Equal, target.Id)
                            }
                        }
                    };

                    EntityCollection results = service.RetrieveMultiple(query);
                    if (results.Entities.Count == 0)
                    {
                        tracingService.Trace("No existing Sales User Default Setting found. Creating new record.");

                        Entity salesUserDefaultSetting = new Entity("niq_salesuserdefaultsettings");
                        salesUserDefaultSetting["niq_user"] = new EntityReference("systemuser", target.Id);
                        salesUserDefaultSetting["ownerid"] = new EntityReference("systemuser", target.Id);
                        service.Create(salesUserDefaultSetting);

                        tracingService.Trace("Sales User Default Setting created for user ID: {0}", target.Id);
                    }
                    else
                    {
                        tracingService.Trace("Sales User Default Setting already exists for user ID: {0}. No action taken.", target.Id);
                    }
                }
            }
        }
    }

}
