﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using NielsenIQ.CRM.Plugins.Helper;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Account_ComplianceFinancialStatus : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                if (context.MessageName.ToLower() == "update")
                {
                    tracing.Trace($@"context.Depth: {context.Depth}");
                    Entity TargetEntity = (Entity)context.InputParameters["Target"];
                    Entity AccountEntity = service.Retrieve(TargetEntity.LogicalName, TargetEntity.Id, new ColumnSet("niq_accounttype", "niq_compliancefinancialstatus", "niq_ultimateparentid"));
                    int accountType = AccountEntity.GetAttributeValue<OptionSetValue>("niq_accounttype").Value;
                    tracing.Trace($@"Account type: {accountType}");

                    if (accountType == 2) //AccountType = SAP Account
                    {
                        if (AccountEntity.Attributes.Contains("niq_ultimateparentid") && AccountEntity.Attributes.Contains("niq_compliancefinancialstatus"))
                        {

                            int complianceFinancialStatus = AccountEntity.GetAttributeValue<OptionSetValue>("niq_compliancefinancialstatus").Value;
                            EntityReference UltimateParentAccountRef = AccountEntity.GetAttributeValue<EntityReference>("niq_ultimateparentid"); //CustomerAccount

                            string fetchXml = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='account'>
                                            <attribute name='name' />
                                            <attribute name='niq_compliancefinancialstatus' />
                                            <attribute name='accountid' />
                                            <order attribute='name' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='niq_ultimateparentid' operator='eq' value='{UltimateParentAccountRef.Id}' />
                                              <condition attribute='niq_accounttype' operator='eq' value='2' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                            List<Entity> SAPAccountList = service.RetrieveMultiple(new FetchExpression(fetchXml)).Entities.ToList();
                            tracing.Trace("Count SAP Account: " + SAPAccountList.Count);
                            if (SAPAccountList.Count > 0)
                            {
                                //1. If there is  any SAP Account related to Customer Account which has status = Compliance Restrict / Active , Customer Account will be Active
                                bool isActiveOrRestricted = IsAccountInActiveOrRestricted(SAPAccountList);
                                tracing.Trace($@"isActiveOrRestricted: {isActiveOrRestricted}");
                                if (isActiveOrRestricted)
                                {
                                    UpdateComplianceFinancialStatus(UltimateParentAccountRef, (int)ComplianceFinancialStatus.Active, service);
                                    return;
                                }

                                //2. If there is  any SAP Account related to Customer Account which has status = Compliance Blocked / Compliance Blocked in MSD and no SAP Account with Compliance Restrict / Active , Customer Account will be Compliance Blocked in MSD
                                bool isComplianceBlockedOrComplianceBlockedInMSD = IsAllAccountInComplianceBlockedStatus(SAPAccountList);
                                tracing.Trace($@"isComplianceBlockedOrComplianceBlockedInMSD: {isComplianceBlockedOrComplianceBlockedInMSD}");
                                if (isComplianceBlockedOrComplianceBlockedInMSD)
                                {
                                    UpdateComplianceFinancialStatus(UltimateParentAccountRef, (int)ComplianceFinancialStatus.ComplianceBlockedInMSD, service);
                                    return;
                                }

                                //3. If there is  all   SAP Account related to Customer Account which has status = Financial Blocked / Financial Blocked in MSD and no SAP Account with Compliance Restrict / Active , Customer Account will be Financial Blocked in MSD
                                bool isFinancialBlockedOrInMSD = IsAllAccountInFinancialBlockedStatus(SAPAccountList);
                                tracing.Trace($@"isFinancialBlockedOrInMSD: {isFinancialBlockedOrInMSD}");
                                if (isFinancialBlockedOrInMSD)
                                {
                                    UpdateComplianceFinancialStatus(UltimateParentAccountRef, (int)ComplianceFinancialStatus.FinancialBlockedInMSD, service);
                                    return;
                                }

                            }
                        }
                        else
                        {
                            tracing.Trace("niq_ultimateparentid or niq_compliancefinancialstatus null");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public void UpdateComplianceFinancialStatus(EntityReference UltimateParentAccountRef, int complianceFinancialStatus, IOrganizationService service)
        {
            Entity updateAccount = new Entity(UltimateParentAccountRef.LogicalName, UltimateParentAccountRef.Id);
            updateAccount["niq_compliancefinancialstatus"] = new OptionSetValue(complianceFinancialStatus);
            service.Update(updateAccount);
        }

        public bool IsAccountInActiveOrRestricted(List<Entity> SAPAccountList)
        {
            int countRecord = SAPAccountList.Where(e => e.Attributes.Contains("niq_compliancefinancialstatus") &&
            (
            e.GetAttributeValue<OptionSetValue>("niq_compliancefinancialstatus").Value == (int)ComplianceFinancialStatus.Active ||
            e.GetAttributeValue<OptionSetValue>("niq_compliancefinancialstatus").Value == (int)ComplianceFinancialStatus.ComplianceRestricted
            )).Count();

            return countRecord > 0;
        }

        public bool IsAllAccountInComplianceBlockedStatus(List<Entity> SAPAccountList)
        {
            int countRecord = SAPAccountList.Where(e => e.Attributes.Contains("niq_compliancefinancialstatus") &&
            (
            e.GetAttributeValue<OptionSetValue>("niq_compliancefinancialstatus").Value == (int)ComplianceFinancialStatus.ComplianceBlocked ||
            e.GetAttributeValue<OptionSetValue>("niq_compliancefinancialstatus").Value == (int)ComplianceFinancialStatus.ComplianceBlockedInMSD
            )).Count();

            return countRecord > 0;
        }

        public bool IsAllAccountInFinancialBlockedStatus(List<Entity> SAPAccountList)
        {
            int countRecord = SAPAccountList.Where(e => e.Attributes.Contains("niq_compliancefinancialstatus") &&
            (
            e.GetAttributeValue<OptionSetValue>("niq_compliancefinancialstatus").Value == (int)ComplianceFinancialStatus.FinancialBlocked ||
            e.GetAttributeValue<OptionSetValue>("niq_compliancefinancialstatus").Value == (int)ComplianceFinancialStatus.FinancialBlockedInMSD
            )).Count();

            return countRecord == SAPAccountList.Count;
        }

        public bool IsAllAccountInSameStatus(List<Entity> SAPAccountList, int statusValue)
        {
            int countRecord = SAPAccountList.Where(e => e.Attributes.Contains("niq_compliancefinancialstatus") &&
            e.GetAttributeValue<OptionSetValue>("niq_compliancefinancialstatus").Value == statusValue).Count();

            return countRecord == SAPAccountList.Count;
        }
    }


    enum ComplianceFinancialStatus
    {
        ComplianceBlocked = 610570000,
        ComplianceBlockedInMSD = 610570001,
        ComplianceRestricted = 610570002,
        FinancialBlocked = 610570003,
        FinancialBlockedInMSD = 610570004,
        Active = 610570005
    }

}
