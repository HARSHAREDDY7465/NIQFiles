﻿// This library is for update start date from the quote product
// This library cover US-19945,19947,20018
// Here we use Post Image for startdate,enddate and term length
using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using NielsenIQ.CRM.Plugins.Helper;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System.Text.RegularExpressions;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;


namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_QuoteProduct_CalculateEndDate : IPlugin
    {
        Entity targetEntity = new Entity();
        Entity postImage = new Entity();
        Entity preImage = new Entity();
        DateTime nextMonthStartDate = DateTime.MinValue;
        DateTime endDateTermLength = DateTime.MinValue;
        DateTime lastDayOfTermLength = DateTime.MinValue;
        DateTime startDate = DateTime.MinValue;
        DateTime quoteProductStartDate = DateTime.MinValue;
        DateTime firstDayOfMonth = DateTime.MinValue;
        DateTime endDate = DateTime.MinValue;
        DateTime preStartDate = DateTime.MinValue;
        Entity updateQuoteProduct = new Entity();
        Entity updateQuote = new Entity();
        EntityReference quoteId = null;
        OptionSetValue productType = new OptionSetValue();
        double termLength = 0.0f;
        double pretermLength = 0.0f;
        UpdateRequest request = new UpdateRequest();
        OptionSetValue preBillingFrequency = new OptionSetValue();
        OptionSetValue postBillingFrequency = new OptionSetValue();
        OptionSetValue preRevenueFrequency = new OptionSetValue();
        OptionSetValue postRevenueFrequency = new OptionSetValue();
        IOrganizationService service;
        ITracingService tracingService;
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                service = serviceFactory.CreateOrganizationService(context.UserId);
                tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                tracingService.Trace("Execution Begins..");
                tracingService.Trace("Depth:" + context.Depth);
                targetEntity = (Entity)context.InputParameters["Target"];

                postImage = context.PostEntityImages.Contains("Image") ? (Entity)context.PostEntityImages["Image"] : null;
                preImage = context.PreEntityImages.Contains("PreImage") ? (Entity)context.PreEntityImages["PreImage"] : null;

                if (context.Depth == 1 && context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    targetEntity = (Entity)context.InputParameters["Target"];
                    updateQuoteProduct = new Entity("quotedetail", targetEntity.Id);
                    tracingService.Trace("Id:" + targetEntity.Id);

                    bool isTimemBased = false;
                    tracingService.Trace("niq_isrevenuemodified" + targetEntity.Contains("niq_isrevenuemodified"));
                    tracingService.Trace("niq_isbillingmodified" + targetEntity.Contains("niq_isbillingmodified"));

                    if (targetEntity.LogicalName == "quotedetail" && targetEntity.Id != Guid.Empty)
                    {
                        bool isAutomated = CommonHelper.IsAutomatedOpportunity(service, targetEntity.Id);
                        if (isAutomated)
                        {
                            // Handle the automated opportunity case
                            return;
                        }
                    }

                    if (targetEntity != null && targetEntity.LogicalName == "quotedetail" && !targetEntity.Contains("niq_isrevenuemodified") && !targetEntity.Contains("niq_isbillingmodified"))
                    {
                        if (context.MessageName.ToLower() == "update")
                        {
                            endDate = postImage.Contains("niq_lineitemenddate") && postImage.GetAttributeValue<DateTime>("niq_lineitemenddate") != null ? postImage.GetAttributeValue<DateTime>("niq_lineitemenddate") : DateTime.MinValue;
                            tracingService.Trace("End Date : " + endDate);
                            startDate = postImage.Contains("niq_lineitemstartdate") && postImage.GetAttributeValue<DateTime>("niq_lineitemstartdate") != null ? postImage.GetAttributeValue<DateTime>("niq_lineitemstartdate") : DateTime.MinValue;
                            tracingService.Trace("Start Date : " + startDate);
                            preStartDate = postImage.GetAttributeValue<DateTime>("createdon") != null ? postImage.GetAttributeValue<DateTime>("createdon") : DateTime.MinValue;
                            tracingService.Trace("Previous Start Date : " + preStartDate);

                            termLength = postImage.Contains("niq_termlength") ? postImage.GetAttributeValue<double>("niq_termlength") : -1.0f;
                            tracingService.Trace("term length : " + termLength);

                            pretermLength = preImage.Contains("niq_termlength") ? preImage.GetAttributeValue<double>("niq_termlength") : -1.0f;
                            tracingService.Trace("Pre term length : " + pretermLength);

                            if (termLength != pretermLength)
                            {
                                tracingService.Trace("\tniq_termlenght got changed.");
                                targetEntity["niq_calculatedtermlength"] = termLength; //experlogix change
                                updateQuoteProduct["niq_calculatedtermlength"] = termLength;
                            }
                            if (targetEntity.Contains("niq_calculatedtermlength"))//js change
                            {
                                tracingService.Trace("\tniq_calculatedtermlength got changed.");
                                termLength = targetEntity.Contains("niq_calculatedtermlength") ? targetEntity.GetAttributeValue<double>("niq_calculatedtermlength") : -1.0f;
                            }
                            productType = postImage.Contains("niq_type") && postImage.GetAttributeValue<OptionSetValue>("niq_type") != null ? postImage.GetAttributeValue<OptionSetValue>("niq_type") : null;
                            quoteId = postImage.Contains("quoteid") && postImage.GetAttributeValue<EntityReference>("quoteid") != null ? postImage.GetAttributeValue<EntityReference>("quoteid") : null;
                            isTimemBased = postImage.Contains("niq_istimebased") ? postImage.GetAttributeValue<bool>("niq_istimebased") : false;

                            if (preImage != null)
                            {
                                preBillingFrequency = preImage.Contains("niq_billingfrequency") && preImage.GetAttributeValue<OptionSetValue>("niq_billingfrequency") != null ? preImage.GetAttributeValue<OptionSetValue>("niq_billingfrequency") : null;
                                preRevenueFrequency = preImage.Contains("niq_deliveryfrequency") && preImage.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency") != null ? preImage.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency") : null;
                            }
                            if (postImage != null)
                            {
                                postBillingFrequency = postImage.Contains("niq_billingfrequency") && postImage.GetAttributeValue<OptionSetValue>("niq_billingfrequency") != null ? postImage.GetAttributeValue<OptionSetValue>("niq_billingfrequency") : null;
                                postRevenueFrequency = postImage.Contains("niq_deliveryfrequency") && postImage.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency") != null ? postImage.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency") : null;
                            }

                            // On Change of Start Date, End date and term Length below code will execute
                            if (productType != null && (targetEntity.Contains("niq_lineitemenddate") || targetEntity.Contains("niq_lineitemstartdate") || targetEntity.Contains("niq_calculatedtermlength"))) //targetEntity.Contains("niq_termlength")))
                            {
                                tracingService.Trace("Product Type : " + productType.Value);
                                if (startDate < preStartDate && preStartDate != DateTime.MinValue && startDate != DateTime.MinValue)
                                {
                                    throw new InvalidPluginExecutionException("Please select an appropriate Start/End Date.");
                                }
                                if ((startDate != DateTime.MinValue && endDate != DateTime.MinValue) && productType != null)
                                {
                                    CalculateStarEndDate(preImage, postImage, service, targetEntity, startDate, termLength, isTimemBased, productType, endDate, tracingService, postBillingFrequency, postRevenueFrequency, ref updateQuoteProduct);
                                }
                                else if (productType != null && targetEntity.Contains("niq_calculatedtermlength")) //targetEntity.Contains("niq_termlength") && pretermLength != termLength)
                                {
                                    CalculateStarEndDate(preImage, postImage, service, targetEntity, startDate, termLength, isTimemBased, productType, endDate, tracingService, postBillingFrequency, postRevenueFrequency, ref updateQuoteProduct);
                                }
                            }
                            // Check if billing start date is changes and billing frequency is "One Time","0/100",80/20,50/50 then regenerate the schedules
                            OnBillingDatesChangeTriggerBillingSchduleGenration(postImage, service, targetEntity, productType, tracingService, ref updateQuoteProduct);

                            // update Quote Product if fields are updated
                            OnChangeOfQuoteProductFields(productType, isTimemBased, targetEntity, preImage, postImage, tracingService, service, context, ref updateQuoteProduct);

                            UpdateQuoteDetailModifiedFields(preImage, postImage, service, tracingService, targetEntity, context, ref updateQuoteProduct);

                            UpdateRemainingAmount(postImage, service, tracingService, targetEntity, ref updateQuoteProduct, postRevenueFrequency, postBillingFrequency);

                            OnchangeTermlenghtCheckCompatibility(preImage, postImage, targetEntity, ref updateQuoteProduct, productType, isTimemBased);

                            request.Target = updateQuoteProduct;

                            //Adhoc service based - DYNCRM-22467. Instead of 'totalamount', need to dependent on priceperunit.
                            if ((targetEntity.Attributes.Contains("niq_lineitemstartdate") || targetEntity.Attributes.Contains("niq_lineitemenddate") || targetEntity.Attributes.Contains("priceperunit") || targetEntity.Attributes.Contains("niq_calculatedtermlength")) &&
                                productType.Value == 1)
                            {
                                if (postRevenueFrequency != null && ((preRevenueFrequency == null && postRevenueFrequency.Value == 100000009) ||
                                (!targetEntity.Attributes.Contains("niq_deliveryfrequency") && postRevenueFrequency.Value == 100000009)))//custom
                                {
                                    tracingService.Trace("remove - revenue flow trigger");
                                    updateQuoteProduct.Attributes.Remove("niq_isrevenuemodified");

                                }
                                if (postBillingFrequency != null && ((preBillingFrequency == null && postBillingFrequency.Value == 100000009) ||
                                    (!targetEntity.Attributes.Contains("niq_billingfrequency") && postBillingFrequency.Value == 100000009)))//adhoc
                                {
                                    tracingService.Trace("remove - billing flow trigger");
                                    updateQuoteProduct.Attributes.Remove("niq_isbillingmodified");
                                }
                            }

                            service.Execute(request);

                            tracingService.Trace("Update Successful..");

                            if (targetEntity.Contains("niq_billingfrequency") || targetEntity.Contains("niq_calculatedtermlength"))
                            {
                                UpdateNonstandardBillingterm(quoteId, targetEntity, preImage, postImage, tracingService, service, context);
                            }
                        }
                    }
                }

            }
            catch (InvalidPluginExecutionException ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        private void UpdateQuoteDetailModifiedFields(Entity preImageQuoteProduct, Entity postImageQuoteProduct, IOrganizationService service, ITracingService tracingService, Entity quoteProduct, IPluginExecutionContext context, ref Entity quotedetailEnt)
        {
            try
            {
                string functionName = "UpdateQuoteDetailModifiedFields";
                tracingService.Trace("Inside" + functionName);

                if (quoteProduct.Contains("niq_billingfrequency"))
                {
                    quotedetailEnt["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                }
                if (quoteProduct.Contains("niq_deliveryfrequency") ||
                         quoteProduct.Contains("niq_lagrevenuerecognition"))
                {
                    quotedetailEnt["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                }

                decimal? prePricePerUnit = preImageQuoteProduct.GetAttributeValue<Money>("priceperunit")?.Value;
                decimal? postPricePerUnit = postImageQuoteProduct.GetAttributeValue<Money>("priceperunit")?.Value;
                tracingService.Trace("PrePost_postExtAmountValue:" + !prePricePerUnit.Equals(postPricePerUnit));

                tracingService.Trace("Pre:prePricePerUnit" + prePricePerUnit);
                tracingService.Trace("Post:postPricePerUnit" + postPricePerUnit);

                decimal? preDisAmountValue = preImageQuoteProduct.Contains("manualdiscountamount") && preImageQuoteProduct.GetAttributeValue<Money>("manualdiscountamount") != null ? preImageQuoteProduct.GetAttributeValue<Money>("manualdiscountamount")?.Value : 0;
                decimal? postDisAmountValue = postImageQuoteProduct.Contains("manualdiscountamount") && postImageQuoteProduct.GetAttributeValue<Money>("manualdiscountamount") != null ? postImageQuoteProduct.GetAttributeValue<Money>("manualdiscountamount")?.Value : 0;
                tracingService.Trace("PrePost_manualdiscountamount" + !preDisAmountValue.Equals(postDisAmountValue));

                tracingService.Trace("Pre:" + preImageQuoteProduct.GetAttributeValue<Money>("priceperunit")?.Value);
                tracingService.Trace("Post:" + postImageQuoteProduct.GetAttributeValue<Money>("priceperunit")?.Value);
                //tracingService.Trace("Pre_niq_termlength:" + preImageQuoteProduct.GetAttributeValue<Double>("niq_termlength"));
                //tracingService.Trace("Post_niq_termlength:" + postImageQuoteProduct.GetAttributeValue<Double>("niq_termlength"));

                if (prePricePerUnit != postPricePerUnit)
                {
                    quotedetailEnt["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                    quotedetailEnt["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                }
                else if (preDisAmountValue != postDisAmountValue)
                {
                    quotedetailEnt["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                    quotedetailEnt["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                }

            }
            catch (InvalidPluginExecutionException ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private void UpdateNonstandardBillingterm(EntityReference quoteId, Entity targetEntity, Entity preImage, Entity postImage, ITracingService tracingService, IOrganizationService service, IPluginExecutionContext context)
        {

            try
            {
                tracingService.Trace("UpdateNonstandardBillingterm");
                updateQuote = new Entity("quote", quoteId.Id);
                // On Change of Billing frequency below code will run
                // For Periodic Products, when Billing is Monthly with Lag, Bimonthly with Lag or Quarterly with Lag" then update "Non Standard Billing Term" field on the Quote to "TRUE" 
                if (targetEntity.Contains("niq_billingfrequency") && targetEntity.Attributes["niq_billingfrequency"] != null && productType != null && productType.Value == 2) // Periodic Type 
                {
                    //Get Billing Frequency value
                    int billingFrequency = targetEntity.Contains("niq_billingfrequency") && targetEntity.Attributes["niq_billingfrequency"] != null ? targetEntity.GetAttributeValue<OptionSetValue>("niq_billingfrequency").Value : -1;
                    tracingService.Trace("billingFrequency:" + billingFrequency);
                    if (billingFrequency != -1 && (billingFrequency == 100000006 || billingFrequency == 100000007 || billingFrequency == 100000008) && quoteId != null)
                    {
                        updateQuote["niq_nonstandardbillingterm"] = true;
                    }
                    else
                    {
                        updateQuote["niq_nonstandardbillingterm"] = false;
                    }

                }
                if (targetEntity.Contains("niq_calculatedtermlength"))//targetEntity.Contains("niq_termlength") && targetEntity.Attributes["niq_termlength"] != null)
                {
                    double termLength = postImage.Contains("niq_termlength") ? postImage.GetAttributeValue<double>("niq_termlength") : -1.0f;
                    tracingService.Trace("term length : " + termLength);

                    double pretermLength = preImage.Contains("niq_termlength") ? preImage.GetAttributeValue<double>("niq_termlength") : -1.0f;
                    tracingService.Trace("Pre term length : " + pretermLength);

                    //if (termLength != -1.0f && pretermLength != -1.0f && termLength != pretermLength)
                    {

                        // Define FetchXML query
                        string fetchXml = @"
                                <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                    <entity name='niq_schedule'>
                                        <order attribute='niq_name' descending='false' />
                                        <filter type='and'>
                                            <condition attribute='niq_iscustomschedule' operator='eq' value='1' />
                                            <condition attribute='niq_lineitemid' operator='eq' value='" + targetEntity.Id + @"' />
                                        </filter>
                                    </entity>
                                </fetch>";

                        EntityCollection results = service.RetrieveMultiple(new FetchExpression(fetchXml));
                        tracingService.Trace("Count:" + results.Entities.Count);

                        if (results.Entities.Count > 0)
                        {
                            updateQuote["niq_notifydatechangeforcustomschedule"] = true;
                        }
                    }
                }
                service.Update(updateQuote);

            }
            catch (InvalidPluginExecutionException ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="postImage"></param>
        /// <param name="tracingService"></param>
        /// <param name="service"></param>
        /// <param name="context"></param>
        private void OnChangeOfQuoteProductFields(OptionSetValue productType, bool isTimemBased, Entity targetEntity, Entity preImage, Entity postImage, ITracingService tracingService, IOrganizationService service, IPluginExecutionContext context, ref Entity updateQuoteProduct)
        {
            tracingService.Trace("inside: OnChangeOfQuoteProductFields");
            try
            {
                double? preTermLength = preImage.Contains("niq_termlength") ? preImage.GetAttributeValue<double?>("niq_termlength") : null;
                tracingService.Trace("preTermLength:" + preTermLength);

                double? postTermLength = postImage.Contains("niq_termlength") ? postImage.GetAttributeValue<double?>("niq_termlength") : null;
                tracingService.Trace("postTermLength:" + postTermLength);

                // If Term Length is Updated from experlogix
                if (targetEntity.Contains("niq_termlength") && targetEntity.Attributes["niq_termlength"] != null && preTermLength != null && postTermLength != null && preTermLength != postTermLength)
                {
                    tracingService.Trace("Update Term Length");
                    //Get Delivery Frequency
                    int revenueFrequency = postImage.Contains("niq_deliveryfrequency") && postImage.Attributes["niq_deliveryfrequency"] != null ? postImage.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency").Value : -1;
                    tracingService.Trace("revenueFrequency:" + revenueFrequency);
                    //Get Term Length from experlogix
                    termLength = postImage.Contains("niq_termlength") && postImage.Attributes["niq_termlength"] != null ? postImage.GetAttributeValue<double>("niq_termlength") : -1;
                    tracingService.Trace("termLength:" + termLength);
                    if (revenueFrequency != -1 && termLength != -1 && revenueFrequency != 100000000 && revenueFrequency != 100000008 && revenueFrequency != 100000009)
                    {
                        int value = CommonHelper.GetRevenueFrequencyValue(revenueFrequency, termLength, tracingService);
                        tracingService.Trace("value:" + value);
                        if (value != -1)
                        {
                            updateQuoteProduct["niq_deliveryfrequency"] = new OptionSetValue(value);
                            updateQuoteProduct["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                        }
                    }
                }
                tracingService.Trace("Pre Image rate card" + preImage.GetAttributeValue<String>("niq_ratecardupdatefrequency"));
                tracingService.Trace("Post Image rate card" + postImage.GetAttributeValue<String>("niq_ratecardupdatefrequency"));
                if (targetEntity.Contains("niq_ratecardupdatefrequency") && targetEntity.Attributes["niq_ratecardupdatefrequency"] != null && !string.Equals(preImage.GetAttributeValue<String>("niq_ratecardupdatefrequency"), postImage.GetAttributeValue<String>("niq_ratecardupdatefrequency")))
                {
                    tracingService.Trace("On Change of Rate care update Frequency");
                    string updateFrequencyString = targetEntity.GetAttributeValue<string>("niq_ratecardupdatefrequency");
                    tracingService.Trace("updateFrequencyString:" + updateFrequencyString);
                    int updateFrequencyValue = CommonHelper.RetrieveOptionSetValue(service, updateFrequencyString);
                    tracingService.Trace("updateFrequencyValue:" + updateFrequencyValue);

                    tracingService.Trace("start date contains data ?:" + postImage.Contains("niq_lineitemstartdate"));
                    tracingService.Trace("end date contains data ?:" + postImage.Contains("niq_lineitemenddate"));
                    if (updateFrequencyValue != 0 && (postImage.Contains("niq_lineitemenddate") && postImage.GetAttributeValue<DateTime>("niq_lineitemenddate") != null) && (postImage.Contains("niq_lineitemstartdate") && postImage.GetAttributeValue<DateTime>("niq_lineitemstartdate") != null))
                    {
                        tracingService.Trace("start data and end data contains data");
                        CommonHelper.SetFrequencyforRateCateProduct(tracingService, service, targetEntity, productType, isTimemBased, ref updateQuoteProduct);

                        OptionSetValue newRevenueFrequency = updateQuoteProduct.GetAttributeValue<OptionSetValue>("niq_deliveryfrequency");
                        if (newRevenueFrequency != null && newRevenueFrequency.Value == 100000009)//custom{
                        {
                            tracingService.Trace("Revenue frequency changed custom, so lag revenue recognition is changed to - no lag");
                            updateQuoteProduct["niq_lagrevenuerecognition"] = new OptionSetValue(100000000);//no lag
                        }
                        updateQuoteProduct["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");


                    }
                }
            }
            catch (InvalidPluginExecutionException ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        //This function will update quote product start date and End date = start date + Term Length
        private void CalculateStarEndDate(Entity preImageQuoteProduct, Entity postImageQuoteProduct, IOrganizationService service, Entity quote, DateTime startDate, double termLength, bool isTimemBased, OptionSetValue productType, DateTime endDate, ITracingService tracingService, OptionSetValue postBillingFrequency, OptionSetValue postRevenueFrequency, ref Entity updateQuoteProduct)
        {
            try
            {
                tracingService.Trace("In the updateStartDateQuoteProduct Function..");
                string ratecard = postImageQuoteProduct.GetAttributeValue<string>("niq_ratecardupdatefrequency");
                //Product Type eq "Ad-hoc"
                if (productType.Value == 1)
                {
                    tracingService.Trace("In the Ad-hoc Product..");
                    firstDayOfMonth = startDate;
                    if (endDate >= startDate)
                    {
                        endDateTermLength = endDate;
                        tracingService.Trace("End Date in Ad-hoc = " + endDateTermLength);
                    }
                    else
                    {
                        throw new InvalidPluginExecutionException("Please select an appropriate Start/End Date.");
                    }
                }
                //Product type eq "Periodic" and ASB with rate card not equal to Adhoc
                if (productType.Value == 2 || (productType.Value == 1 && !isTimemBased && !string.IsNullOrEmpty(ratecard) && !string.Equals(ratecard, "Adhoc")))
                {
                    tracingService.Trace("In the Periodic Product..");
                    //if start date is greater than 1st day of month than set start date 1st day of that month. 
                    if (startDate.Day > 1)
                    {
                        firstDayOfMonth = new DateTime(startDate.Year, startDate.Month, 1);
                        // Set the end date firstDayOfMonth + Term length
                        if (termLength == 0.0f)
                        {
                            endDateTermLength = firstDayOfMonth;
                        }
                        else
                        {
                            endDateTermLength = firstDayOfMonth.AddMonths((int)termLength);
                            endDateTermLength = endDateTermLength.AddDays(-1);
                        }

                        tracingService.Trace("End Date with Term Length = " + endDateTermLength);
                    }
                    if (startDate.Day == 1)
                    {
                        firstDayOfMonth = startDate;
                        // Set the end date firstDayOfMonth + Term length
                        if (termLength == 0.0f)
                        {
                            endDateTermLength = firstDayOfMonth;
                        }
                        else
                        {
                            endDateTermLength = firstDayOfMonth.AddMonths((int)termLength);
                            endDateTermLength = endDateTermLength.AddDays(-1);
                        }

                        tracingService.Trace("End Date with Term Length = " + endDateTermLength);
                    }
                }
                updateQuoteProduct["niq_lineitemstartdate"] = firstDayOfMonth;
                updateQuoteProduct["niq_lineitemenddate"] = endDateTermLength;

                // Update billing start/end date for Adhoc Product Type and if Billing frequency is 50/50,80/20,0/100,One Time
                if (productType != null && productType.Value == 1 && postBillingFrequency != null && (postBillingFrequency.Value == 100000010 || postBillingFrequency.Value == 100000011 || postBillingFrequency.Value == 100000012 || postBillingFrequency.Value == 100000013))
                {
                    tracingService.Trace("Billing start and end date is changed");
                    updateQuoteProduct["niq_billingstartdate"] = firstDayOfMonth;
                    updateQuoteProduct["niq_billingenddate"] = endDateTermLength;
                }

                tracingService.Trace("niq_lineitemenddate:" + quote.Contains("niq_lineitemenddate"));
                tracingService.Trace("niq_lineitemstartdate:" + quote.Contains("niq_lineitemstartdate"));
                tracingService.Trace("niq_termlength:" + quote.Contains("niq_termlength"));

                double? preTermLength = preImageQuoteProduct.Contains("niq_termlength") ? preImageQuoteProduct.GetAttributeValue<double?>("niq_termlength") : null;
                tracingService.Trace("preTermLength:" + preTermLength);

                double? postTermLength = postImageQuoteProduct.Contains("niq_termlength") ? postImageQuoteProduct.GetAttributeValue<double?>("niq_termlength") : null;
                tracingService.Trace("postTermLength:" + postTermLength);


                double? preCalTermLength = preImageQuoteProduct.Contains("niq_calculatedtermlength") ? preImageQuoteProduct.GetAttributeValue<double?>("niq_calculatedtermlength") : null;
                tracingService.Trace("preCalTermLength:" + preCalTermLength);

                double? postCalTermLength = postImageQuoteProduct.Contains("niq_calculatedtermlength") ? postImageQuoteProduct.GetAttributeValue<double?>("niq_calculatedtermlength") : null;
                tracingService.Trace("postCalTermLength:" + postCalTermLength);

                tracingService.Trace("TLChnages:" + (preTermLength != null && postTermLength != null && preTermLength != postTermLength));
                if (quote.Contains("niq_calculatedtermlength")) //quote.Contains("niq_termlength"))
                {
                    tracingService.Trace("on change of termlength");
                    if (productType.Value == 1 && !isTimemBased)
                    {
                        if (targetEntity.GetAttributeValue<double?>("niq_calculatedtermlength") != 0)
                        {
                            tracingService.Trace("preCalTermLength:" + preCalTermLength);
                            tracingService.Trace("postCalTermLength:" + postCalTermLength);
                            if (postCalTermLength != null && preCalTermLength != null && preCalTermLength != postCalTermLength)
                            {
                                tracingService.Trace("trigger both schedule");
                                if (postImageQuoteProduct.Contains("niq_isrevshareline") && !((bool)postImageQuoteProduct.Attributes["niq_isrevshareline"]))
                                {
                                    updateQuoteProduct["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                                    updateQuoteProduct["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                                }

                            }
                        }
                    }
                    /*else
                    {
                      if (preTermLength != null && postTermLength != null && preTermLength != postTermLength)
                    {

                       updateQuoteProduct["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                       updateQuoteProduct["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                    }
                    }*/
                    else
                    {
                        tracingService.Trace("Other than Adhoc service based products");
                        if ((preTermLength != null && postTermLength != null && preTermLength != postTermLength) || (postCalTermLength != null && preCalTermLength != null && preCalTermLength != postCalTermLength))
                        {
                            tracingService.Trace("term lenght or calculated term length got changed.");
                            updateQuoteProduct["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                            updateQuoteProduct["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                        }
                    }
                }
                else if (quote.Contains("niq_lineitemenddate") || quote.Contains("niq_lineitemstartdate"))
                {
                    tracingService.Trace("on change of start,end date");
                    // IsValidBillingFrequency will check billing frequnect have 50/50,0/100,80/20,one time option.
                    // Billing schedule generation will be not allowed for  50/50,0/100,80/20,one time
                    bool isValidBF = IsValidBillingFrequency(postImage, tracingService, service);
                    tracingService.Trace("isValidBF: " + isValidBF);
                    if (productType.Value == 2 || (productType.Value == 1 && !isValidBF))
                    {
                        tracingService.Trace("billing trigger");
                        updateQuoteProduct["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                    }
                    updateQuoteProduct["niq_isrevenuemodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                }
            }
            catch (InvalidPluginExecutionException ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private void OnchangeTermlenghtCheckCompatibility(Entity preImageQuoteProduct, Entity postImageQuoteProduct, Entity targetQuoteProduct, ref Entity updateQuoteProduct, OptionSetValue productType, bool isTimeBased)
        {
            tracingService.Trace("func: OnchangeTermlenghtCheckCompatibility.");
            //this case is specially for Manual entry products, we will do the compatibility check, rate card products, check is done on experlogix itself.
            if (targetEntity.Contains("niq_termlength"))
            {
                double? preTermLength = preImageQuoteProduct.Contains("niq_termlength") ? preImageQuoteProduct.GetAttributeValue<double?>("niq_termlength") : null;
                tracingService.Trace("preTermLength:" + preTermLength);

                double? postTermLength = postImageQuoteProduct.Contains("niq_termlength") ? postImageQuoteProduct.GetAttributeValue<double?>("niq_termlength") : null;
                tracingService.Trace("postTermLength:" + postTermLength);

                if (preTermLength != null && postTermLength != null && preTermLength != postTermLength && productType != null)
                {
                    tracingService.Trace("Change in termlength");
                    tracingService.Trace("rate card update frequency contains data ?: " + postImage.GetAttributeValue<string>("niq_ratecardupdatefrequency"));
                    if (string.IsNullOrEmpty(postImage.GetAttributeValue<string>("niq_ratecardupdatefrequency")))
                    {
                        tracingService.Trace("only for Manual entry products, we will do the compatibility check");
                        CompatibilityCheck compatibilityCheck = new CompatibilityCheck(tracingService, service);
                        compatibilityCheck.Checker(productType, postRevenueFrequency, postBillingFrequency, isTimeBased, termLength, postImage, ref updateQuoteProduct);
                    }
                }
            }
        }
        private void UpdateRemainingAmount(Entity postImageQuoteProduct, IOrganizationService service, ITracingService tracingService, Entity targetQuoteProduct, ref Entity quotedetailEnt, OptionSetValue postRevenueFrequency, OptionSetValue postBillingFrequency)
        {
            tracingService.Trace("func: updateRemainingAmount");
            tracingService.Trace("change in amount? :" + targetQuoteProduct.Contains("priceperunit"));
            if (targetQuoteProduct.Contains("priceperunit") || targetQuoteProduct.Contains("manualdiscountamount"))
            {
                if (postRevenueFrequency != null && postRevenueFrequency.Value == 100000009)//custom
                {
                    tracingService.Trace("Revenue frequency is custom");
                    Money remainingRevenueAmount = postImageQuoteProduct.GetAttributeValue<Money>("niq_remainingrevenueamount");
                    Money pricePerUnit = postImageQuoteProduct.GetAttributeValue<Money>("priceperunit");
                    Money manualDiscount = postImageQuoteProduct.GetAttributeValue<Money>("manualdiscountamount");
                    if (remainingRevenueAmount != null)
                    {
                        var query = new QueryExpression("niq_schedule")
                        {
                            ColumnSet = new ColumnSet("niq_amount"),
                            Criteria =
                            {
                                Conditions =
                                {
                                    new ConditionExpression("niq_lineitemid", ConditionOperator.Equal, targetQuoteProduct.Id)
                                },
                                Filters =
                                {
                                    new FilterExpression
                                    {
                                        FilterOperator = LogicalOperator.Or,
                                        Conditions =
                                        {
                                            new ConditionExpression("niq_scheduletype", ConditionOperator.Equal, 100000001),
                                            new ConditionExpression("niq_scheduletype", ConditionOperator.Equal, 100000002)
                                        }
                                    }
                                }
                            }
                        };
                        EntityCollection schdles = service.RetrieveMultiple(query);
                        decimal amt = schdles.Entities.Where(e => e.Contains("niq_amount") && e.GetAttributeValue<Money>("niq_amount") != null)
                                         .Sum(e => e.GetAttributeValue<Money>("niq_amount").Value);

                        if (remainingRevenueAmount.Value == 0 && schdles.Entities.Count == 1)
                        {
                            tracingService.Trace("only one custom billing schedule, so update the amount in schedule");
                            Entity updateSchedule = new Entity("niq_schedule", schdles.Entities[0].Id);
                            updateSchedule["niq_amount"] = new Money(pricePerUnit.Value - manualDiscount.Value);
                            service.Update(updateSchedule);
                            quotedetailEnt["niq_revenueschedulestatus"] = new OptionSetValue(610570004);//complete schedules (manual)	
                        }
                        else
                        {
                            if ((pricePerUnit.Value - manualDiscount.Value) != amt)
                            {
                                quotedetailEnt["niq_revenueschedulestatus"] = new OptionSetValue(610570001);//Incomplete schedules (manual)	
                            }
                            else
                            {
                                quotedetailEnt["niq_revenueschedulestatus"] = new OptionSetValue(610570004);//complete schedules (manual)	
                            }
                            quotedetailEnt["niq_remainingrevenueamount"] = new Money((pricePerUnit.Value - manualDiscount.Value) - amt);

                        }

                    }
                }
                if (postBillingFrequency != null && postBillingFrequency.Value == 100000009)//custom
                {
                    tracingService.Trace("Billing frequency is custom");
                    Money remainingRevenueAmount = postImageQuoteProduct.GetAttributeValue<Money>("niq_remainingbillingamount");
                    Money pricePerUnit = postImageQuoteProduct.GetAttributeValue<Money>("priceperunit");
                    Money manualDiscount = postImageQuoteProduct.GetAttributeValue<Money>("manualdiscountamount");
                    if (remainingRevenueAmount != null)
                    {
                        var query = new QueryExpression("niq_schedule")
                        {
                            ColumnSet = new ColumnSet("niq_amount"),
                            Criteria =
                            {
                                Conditions =
                                {
                                    new ConditionExpression("niq_lineitemid", ConditionOperator.Equal, targetQuoteProduct.Id)
                                },
                                Filters =
                                {
                                    new FilterExpression
                                    {
                                        FilterOperator = LogicalOperator.Or,
                                        Conditions =
                                        {
                                            new ConditionExpression("niq_scheduletype", ConditionOperator.Equal, 100000000)//billing schedule.
                                        }
                                    }
                                }
                            }
                        };
                        EntityCollection schdles = service.RetrieveMultiple(query);
                        decimal amt = schdles.Entities.Where(e => e.Contains("niq_amount") && e.GetAttributeValue<Money>("niq_amount") != null)
                                         .Sum(e => e.GetAttributeValue<Money>("niq_amount").Value);

                        if (remainingRevenueAmount.Value == 0 && schdles.Entities.Count == 1)
                        {
                            tracingService.Trace("only one billing custom schedule, so update the amount in schedule");
                            Entity updateSchedule = new Entity("niq_schedule", schdles.Entities[0].Id);
                            updateSchedule["niq_amount"] = new Money((pricePerUnit.Value - manualDiscount.Value));
                            service.Update(updateSchedule);
                            quotedetailEnt["niq_billingschedulestatus"] = new OptionSetValue(610570004);//complete schedules (manual)	
                        }
                        else
                        {
                            if ((pricePerUnit.Value - manualDiscount.Value) != amt)
                            {
                                quotedetailEnt["niq_billingschedulestatus"] = new OptionSetValue(610570001);//Incomplete schedules (manual)	
                            }
                            else
                            {
                                quotedetailEnt["niq_billingschedulestatus"] = new OptionSetValue(610570004);//complete schedules (manual)	
                            }
                            quotedetailEnt["niq_remainingbillingamount"] = new Money((pricePerUnit.Value - manualDiscount.Value) - amt);

                        }

                    }
                }
            }
        }


        ///  Check if billing start date is changes and billing frequency is "One Time","0/100",80/20,50/50 then regenerate the schedules
        /// </summary>
        /// <param name="postImage"></param>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="productType"></param>
        /// <param name="tracingService"></param>
        /// <param name="updateQuoteProduct"></param>
        private void OnBillingDatesChangeTriggerBillingSchduleGenration(Entity postImage, IOrganizationService service, Entity targetEntity, OptionSetValue productType, ITracingService tracingService, ref Entity updateQuoteProduct)
        {
            tracingService.Trace("inside: OnBillingDatesChangeTriggerBillingSchduleGenration");
            if (targetEntity.Contains("niq_billingstartdate") || targetEntity.Contains("niq_billingenddate"))
            {
                bool isValidBF = IsValidBillingFrequency(postImage, tracingService, service);
                if (isValidBF && productType.Value == 1)
                {
                    updateQuoteProduct["niq_isbillingmodified"] = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");
                }

            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="postImage"></param>
        /// <param name="tracingService"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        private bool IsValidBillingFrequency(Entity postImage, ITracingService tracingService, IOrganizationService service)
        {
            bool isValid = false;
            try
            {
                if (postImage.Contains("niq_billingfrequency") && postImage.Attributes["niq_billingfrequency"] != null)
                {
                    OptionSetValue billingFreqValue = postImage.GetAttributeValue<OptionSetValue>("niq_billingfrequency");
                    if (billingFreqValue != null && (billingFreqValue.Value == 100000010 || billingFreqValue.Value == 100000011 || billingFreqValue.Value == 100000012 || billingFreqValue.Value == 100000013))
                    {
                        isValid = true;
                    }
                }
                return isValid;
            }
            catch (InvalidPluginExecutionException ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }

    public class CompatibilityCheck
    {
        ITracingService tracingService;
        IOrganizationService service;
        public static Dictionary<int, List<string>> updatefrequency = new Dictionary<int, List<string>>
        {
            { 100000000, new List<string>{"Monthly", "Monthly" } },
            { 100000008, new List<string>{"MonthlyTimeBased", "Monthly (Time Based)" } },
            { 100000001,  new List<string>{"Bimonthly", "Bimonthly" } },
            { 100000002,  new List<string>{"Quarterly", "Quarterly" } },
            { 100000004,  new List<string>{"TwoxYear", "2x / Year" } },
            { 100000003,  new List<string>{"ThreexAnnually", "3x / Year" } },
            { 100000005,  new List<string>{"Annual", "Annual" } },
            { 100000009,  new List<string>{"Custom", "Custom" } }
        };
        public static Dictionary<int, List<string>> billingfrequency = new Dictionary<int, List<string>>
        {
            { 100000000, new List<string>{"Monthly", "Monthly" } },
            { 100000001, new List<string>{"Bimonthly", "Bimonthly" } },
            { 100000002, new List<string>{"Quarterly", "Quarterly" } },
            { 100000003, new List<string>{"TwoxYear_Billing", "2x / Year" } },
            { 100000004, new List<string>{"ThreexAnnually_Billing", "3x / Year" } },
            { 100000005, new List<string>{ "Annual", "Annual" } },
            { 100000006, new List<string>{"MonthlyWithLag", "Monthly with Lag" } },
            { 100000007, new List<string>{"BiMonthlyWithLag", "Bimonthly with Lag" } },
            { 100000008, new List<string>{"QuarterlyWithLag", "Quarterly with Lag" } },
            { 100000009, new List<string>{"Custom", "Ad-Hoc" } },
            { 100000010, new List<string>{"FiftyFifty", "50/50" } },
            { 100000014, new List<string>{"SixtyForty", "60/40" } },
            { 100000011, new List<string>{"EightyTwenty", "80/20" } },
            { 100000012, new List<string>{"ZeroHundred", "0/100 (Bill on Delivery)" } },
            { 100000013, new List<string>{"OneTime", "One Time" } }
        };
        public CompatibilityCheck(ITracingService tracingService, IOrganizationService service)
        {
            this.tracingService = tracingService;
            this.service = service;
        }

        public void Checker(OptionSetValue productType, OptionSetValue postRevenueFrequency, OptionSetValue postBillingFrequency, bool isTimemBased, double termLength, Entity PostImage, ref Entity updateQuoteProduct)
        {
            tracingService.Trace("\nfunc: Checker");
            string productCategory = "";
            bool resetUpdateFrequency = false;
            bool resetBillingFrequency = false;
            if (productType != null && productType.Value == 2)
            {
                if (isTimemBased)
                    productCategory = "PeriodicTimeBased";
                else
                    productCategory = "PeriodicServiceBased";
            }
            tracingService.Trace(productCategory);
            Entity config = service.Retrieve("niq_configurationsetting", new Guid("adfca5dc-bc28-ef11-840a-000d3a2f0c5a"), new ColumnSet("niq_json", "niq_cc"));
            //config["niq_json"] = "{\"UpdateFrequency\":{\"AdhocTimeBased\":{\"MonthlyTimeBased\":\"Yes\",\"Monthly\":\"No\",\"Bimonthly\":\"No\",\"Quarterly\":\"No\",\"Annual\":\"No\",\"TwoxYear\":\"No\",\"ThreexAnnually\":\"No\",\"Custom\":\"No\"},\"PeriodicTimeBased\":{\"MonthlyTimeBased\":\"Yes\",\"Monthly\":\"No\",\"Bimonthly\":\"No\",\"Quarterly\":\"No\",\"Annual\":\"No\",\"TwoxYear\":\"No\",\"ThreexAnnually\":\"No\",\"Custom\":\"No\"},\"AdhocServiceBased\":{\"MonthlyTimeBased\":\"No\",\"Monthly\":\"Yes\",\"Bimonthly\":\"Yes\",\"Quarterly\":\"Yes\",\"Annual\":\"Yes\",\"TwoxYear\":\"Yes\",\"ThreexAnnually\":\"Yes\",\"Custom\":\"Yes\"},\"PeriodicServiceBased\":{\"MonthlyTimeBased\":\"No\",\"Monthly\":\"Yes\",\"Bimonthly\":\"Yes\",\"Quarterly\":\"Yes\",\"Annual\":\"Yes\",\"TwoxYear\":\"Yes\",\"ThreexAnnually\":\"Yes\",\"Custom\":\"No\"},\"PlaceholderProducts\":{\"MonthlyTimeBased\":\"No\",\"Monthly\":\"Yes\",\"Bimonthly\":\"Yes\",\"Quarterly\":\"Yes\",\"Annual\":\"Yes\",\"TwoxYear\":\"Yes\",\"ThreexAnnually\":\"Yes\",\"Custom\":\"No\"},\"SAPDeferredLine\":{\"MonthlyTimeBased\":\"No\",\"Monthly\":\"Yes\",\"Bimonthly\":\"Yes\",\"Quarterly\":\"Yes\",\"Annual\":\"Yes\",\"TwoxYear\":\"Yes\",\"ThreexAnnually\":\"Yes\",\"Custom\":\"No\"}},\"RevenueFrequency\":{\"OnPlatformDelivery\":{\"Yes\":{\"PeriodicTimeBased\":{\"MonthlyTimeBased\":\"Yes\",\"Monthly\":\"No\",\"Bimonthly\":\"No\",\"Quarterly\":\"No\",\"Annual\":\"No\",\"TwoxYear\":\"No\",\"ThreexAnnually\":\"No\",\"Custom\":\"No\",\"BiMonthlyMonthlyRevRec\":\"No\",\"QuarterlyMonthlyRevRec\":\"No\"},\"PeriodicServiceBased\":{\"MonthlyTimeBased\":\"No\",\"Monthly\":\"Yes\",\"Bimonthly\":\"No\",\"Quarterly\":\"No\",\"Annual\":\"No\",\"TwoxYear\":\"No\",\"ThreexAnnually\":\"No\",\"Custom\":\"No\",\"BiMonthlyMonthlyRevRec\":\"No\",\"QuarterlyMonthlyRevRec\":\"No\"},\"AdhocTimeBased\":{\"MonthlyTimeBased\":\"Yes\",\"Monthly\":\"No\",\"Bimonthly\":\"No\",\"Quarterly\":\"No\",\"Annual\":\"No\",\"TwoxYear\":\"No\",\"ThreexAnnually\":\"No\",\"Custom\":\"No\",\"BiMonthlyMonthlyRevRec\":\"No\",\"QuarterlyMonthlyRevRec\":\"No\"},\"AdhocServiceBased\":{\"MonthlyTimeBased\":\"No\",\"Monthly\":\"Yes\",\"Bimonthly\":\"No\",\"Quarterly\":\"No\",\"Annual\":\"No\",\"TwoxYear\":\"No\",\"ThreexAnnually\":\"No\",\"Custom\":\"Yes\",\"BiMonthlyMonthlyRevRec\":\"No\",\"QuarterlyMonthlyRevRec\":\"No\"}},\"No\":{\"PeriodicTimeBased\":{\"MonthlyTimeBased\":\"Yes\",\"Monthly\":\"No\",\"Bimonthly\":\"No\",\"Quarterly\":\"No\",\"Annual\":\"No\",\"TwoxYear\":\"No\",\"ThreexAnnually\":\"No\",\"Custom\":\"No\",\"BiMonthlyMonthlyRevRec\":\"No\",\"QuarterlyMonthlyRevRec\":\"No\"},\"PeriodicServiceBased\":{\"MonthlyTimeBased\":\"No\",\"Monthly\":\"Yes\",\"Bimonthly\":\"No\",\"Quarterly\":\"No\",\"Annual\":\"No\",\"TwoxYear\":\"No\",\"ThreexAnnually\":\"No\",\"Custom\":\"No\",\"BiMonthlyMonthlyRevRec\":\"No\",\"QuarterlyMonthlyRevRec\":\"No\"},\"AdhocTimeBased\":{\"MonthlyTimeBased\":\"Yes\",\"Monthly\":\"No\",\"Bimonthly\":\"No\",\"Quarterly\":\"No\",\"Annual\":\"No\",\"TwoxYear\":\"No\",\"ThreexAnnually\":\"No\",\"Custom\":\"No\",\"BiMonthlyMonthlyRevRec\":\"No\",\"QuarterlyMonthlyRevRec\":\"No\"},\"AdhocServiceBased\":{\"MonthlyTimeBased\":\"No\",\"Monthly\":\"Yes\",\"Bimonthly\":\"No\",\"Quarterly\":\"No\",\"Annual\":\"No\",\"TwoxYear\":\"No\",\"ThreexAnnually\":\"No\",\"Custom\":\"Yes\",\"BiMonthlyMonthlyRevRec\":\"No\",\"QuarterlyMonthlyRevRec\":\"No\"},\"PlaceholderProducts\":{\"MonthlyTimeBased\":\"No\",\"Monthly\":\"Yes\",\"Bimonthly\":\"Yes\",\"Quarterly\":\"Yes\",\"Annual\":\"Yes\",\"TwoxYear\":\"Yes\",\"ThreexAnnually\":\"Yes\",\"Custom\":\"No\",\"BiMonthlyMonthlyRevRec\":\"No\",\"QuarterlyMonthlyRevRec\":\"No\"},\"SAPDeferredLine\":{\"MonthlyTimeBased\":\"No\",\"Monthly\":\"Yes\",\"Bimonthly\":\"Yes\",\"Quarterly\":\"Yes\",\"Annual\":\"Yes\",\"TwoxYear\":\"Yes\",\"ThreexAnnually\":\"Yes\",\"Custom\":\"No\",\"BiMonthlyMonthlyRevRec\":\"No\",\"QuarterlyMonthlyRevRec\":\"No\"}}}},\"LagRevenueRecognition\":{\"OnPlatformDelivery\":{\"Yes\":{\"PeriodicTimeBased\":{\"NoLag\":\"Yes\",\"1MonthLag\":\"No\",\"2MonthsLag\":\"No\",\"CustomDelivery\":\"No\"},\"PeriodicServiceBased\":{\"NoLag\":\"Yes\",\"1MonthLag\":\"No\",\"2MonthsLag\":\"No\",\"CustomDelivery\":\"No\"},\"AdhocTimeBased\":{\"NoLag\":\"Yes\",\"1MonthLag\":\"No\",\"2MonthsLag\":\"No\",\"CustomDelivery\":\"No\"},\"AdhocServiceBased\":{\"NoLag\":\"Yes\",\"1MonthLag\":\"No\",\"2MonthsLag\":\"No\",\"CustomDelivery\":\"No\"}},\"No\":{\"PeriodicTimeBased\":{\"NoLag\":\"Yes\",\"1MonthLag\":\"Yes\",\"2MonthsLag\":\"Yes\",\"CustomDelivery\":\"No\"},\"PeriodicServiceBased\":{\"NoLag\":\"Yes\",\"1MonthLag\":\"Yes\",\"2MonthsLag\":\"Yes\",\"CustomDelivery\":\"No\"},\"AdhocTimeBased\":{\"NoLag\":\"Yes\",\"1MonthLag\":\"No\",\"2MonthsLag\":\"No\",\"CustomDelivery\":\"No\"},\"AdhocServiceBased\":{\"NoLag\":\"Yes\",\"1MonthLag\":\"No\",\"2MonthsLag\":\"No\",\"CustomDelivery\":\"No\"},\"PlaceholderProducts\":{\"NoLag\":\"Yes\",\"1MonthLag\":\"Yes\",\"2MonthsLag\":\"Yes\",\"CustomDelivery\":\"No\"},\"SAPDeferredLine\":{\"NoLag\":\"Yes\",\"1MonthLag\":\"Yes\",\"2MonthsLag\":\"Yes\",\"CustomDelivery\":\"No\"}}}},\"BillingFrequency\":{\"PeriodicServiceBased\":{\"Monthly\":\"Yes\",\"Bimonthly\":\"Yes\",\"Quarterly\":\"Yes\",\"Annual\":\"Yes\",\"TwoxYear_Billing\":\"Yes\",\"ThreexAnnually_Billing\":\"Yes\",\"MonthlyWithLag\":\"Yes\",\"BiMonthlyWithLag\":\"Yes\",\"QuarterlyWithLag\":\"Yes\",\"Custom\":\"No\",\"OneTime\":\"No\",\"FiftyFifty\":\"No\",\"EightyTwenty\":\"No\",\"SixtyForty\":\"No\",\"ZeroHundred\":\"No\"},\"PeriodicTimeBased\":{\"Monthly\":\"Yes\",\"Bimonthly\":\"Yes\",\"Quarterly\":\"Yes\",\"Annual\":\"Yes\",\"TwoxYear_Billing\":\"Yes\",\"ThreexAnnually_Billing\":\"Yes\",\"MonthlyWithLag\":\"Yes\",\"BiMonthlyWithLag\":\"Yes\",\"QuarterlyWithLag\":\"Yes\",\"Custom\":\"No\",\"OneTime\":\"No\",\"FiftyFifty\":\"No\",\"EightyTwenty\":\"No\",\"SixtyForty\":\"No\",\"ZeroHundred\":\"No\"},\"AdhocTimeBased\":{\"Monthly\":\"No\",\"Bimonthly\":\"No\",\"Quarterly\":\"No\",\"Annual\":\"No\",\"TwoxYear_Billing\":\"No\",\"ThreexAnnually_Billing\":\"No\",\"MonthlyWithLag\":\"No\",\"BiMonthlyWithLag\":\"No\",\"QuarterlyWithLag\":\"No\",\"Custom\":\"Yes\",\"OneTime\":\"Yes\",\"FiftyFifty\":\"Yes\",\"EightyTwenty\":\"Yes\",\"SixtyForty\":\"Yes\",\"ZeroHundred\":\"Yes\"},\"AdhocServiceBased\":{\"Monthly\":\"Yes\",\"Bimonthly\":\"Yes\",\"Quarterly\":\"Yes\",\"Annual\":\"Yes\",\"TwoxYear_Billing\":\"Yes\",\"ThreexAnnually_Billing\":\"Yes\",\"MonthlyWithLag\":\"No\",\"BiMonthlyWithLag\":\"No\",\"QuarterlyWithLag\":\"No\",\"Custom\":\"Yes\",\"OneTime\":\"Yes\",\"FiftyFifty\":\"Yes\",\"EightyTwenty\":\"Yes\",\"SixtyForty\":\"Yes\",\"ZeroHundred\":\"Yes\"},\"PlaceholderProducts\":{\"Monthly\":\"Yes\",\"Bimonthly\":\"No\",\"Quarterly\":\"No\",\"Annual\":\"No\",\"TwoxYear_Billing\":\"No\",\"ThreexAnnually_Billing\":\"No\",\"MonthlyWithLag\":\"No\",\"BiMonthlyWithLag\":\"No\",\"QuarterlyWithLag\":\"No\",\"Custom\":\"No\",\"OneTime\":\"No\",\"FiftyFifty\":\"No\",\"EightyTwenty\":\"No\",\"SixtyForty\":\"No\",\"ZeroHundred\":\"No\"},\"SAPDeferredLine\":{\"Monthly\":\"Yes\",\"Bimonthly\":\"No\",\"Quarterly\":\"No\",\"Annual\":\"No\",\"TwoxYear_Billing\":\"No\",\"ThreexAnnually_Billing\":\"No\",\"MonthlyWithLag\":\"No\",\"BiMonthlyWithLag\":\"No\",\"QuarterlyWithLag\":\"No\",\"Custom\":\"No\",\"OneTime\":\"No\",\"FiftyFifty\":\"No\",\"EightyTwenty\":\"No\",\"SixtyForty\":\"No\",\"ZeroHundred\":\"No\"}}}";

            if (!string.IsNullOrEmpty(config.GetAttributeValue<string>("niq_json")))
            {
                JObject frequencyJson = JObject.Parse(config.GetAttributeValue<string>("niq_json"));
                if (frequencyJson != null)
                {
                    string currentUpdatefrequency = updatefrequency[postRevenueFrequency.Value][0];
                    tracingService.Trace("\tcurrentUpdatefrequency :" + currentUpdatefrequency);
                    string UpdatefreqConfig = frequencyJson["UpdateFrequency"]?[productCategory]?[currentUpdatefrequency].ToString();
                    tracingService.Trace("\tUpdatefreqConfig :" + UpdatefreqConfig);

                    //check update frequency
                    if (!string.IsNullOrEmpty(UpdatefreqConfig))
                    {
                        if (string.Equals(UpdatefreqConfig.ToString().ToLower(), "yes"))
                        {
                            if (!CheckWithTermLenght(termLength, updatefrequency[postRevenueFrequency.Value][1]))
                            {
                                resetUpdateFrequency = true;
                            }
                        }
                        else
                        {
                            resetUpdateFrequency = true;
                        }
                    }
                    //check the billing frequency
                    string currentBillingfrequency = billingfrequency[postBillingFrequency.Value][0];
                    string BillingfreqConfig = frequencyJson["BillingFrequency"]?[productCategory]?[currentBillingfrequency].ToString();
                    if (!string.IsNullOrEmpty(BillingfreqConfig))
                    {
                        if (string.Equals(BillingfreqConfig.ToString().ToLower(), "yes"))
                        {
                            if (!CheckWithTermLenght(termLength, billingfrequency[postBillingFrequency.Value][1]))
                            {
                                resetBillingFrequency = true;
                            }
                        }
                        else
                        {
                            resetBillingFrequency = true;
                        }
                    }
                }

            }

            if (resetUpdateFrequency || resetBillingFrequency)
            {
                string pricelistItem = PostImage.GetAttributeValue<string>("niq_pricelistitem");

                if (!string.IsNullOrEmpty(pricelistItem))
                {
                    Entity priceListItemEnt = service.Retrieve("productpricelevel", new Guid(pricelistItem),
                        new ColumnSet("productpricelevelid", "niq_billingfrequency", "niq_lagrevenuerecognition", "niq_revenuefrequency", "niq_updatefrequency", "productid", "niq_istimebased"));

                    if (resetUpdateFrequency)
                    {
                        tracingService.Trace("\nResetting the update, revenue, lag revenue frequency options");
                        int updateFrequnencyOSV = CommonHelper.GetUpdateFrequency(priceListItemEnt, tracingService);
                        tracingService.Trace("Update frequency:" + updateFrequnencyOSV);
                        if (updateFrequnencyOSV != -1) updateQuoteProduct["niq_updatefrequency"] = new OptionSetValue(updateFrequnencyOSV);

                        int deliveryfrequencyOSV = CommonHelper.GetDeliveryFrequency(priceListItemEnt, tracingService);
                        tracingService.Trace("Revenue frequency :" + deliveryfrequencyOSV);
                        if (deliveryfrequencyOSV != -1)
                        {
                            updateQuoteProduct["niq_deliveryfrequency"] = new OptionSetValue(deliveryfrequencyOSV);
                            tracingService.Trace("niq_deliveryfrequency" + deliveryfrequencyOSV);
                        }

                        int lagRevenueRecognitionOSV = CommonHelper.SetLagRevenueRecognition(priceListItemEnt, tracingService);
                        tracingService.Trace("Lag revenue recognition: " + lagRevenueRecognitionOSV);
                        if (lagRevenueRecognitionOSV != -1)
                        {
                            updateQuoteProduct["niq_lagrevenuerecognition"] = new OptionSetValue(lagRevenueRecognitionOSV);
                            tracingService.Trace("niq_lagrevenuerecognition" + lagRevenueRecognitionOSV);
                        }
                    }

                    if (resetBillingFrequency)
                    {
                        tracingService.Trace("Resetting the Billing frequency.");
                        int billingFrequencyOSV = CommonHelper.SetBillingFrequency(priceListItemEnt, updateQuoteProduct, tracingService);
                        tracingService.Trace("Billing frequency: " + billingFrequencyOSV);
                        if (billingFrequencyOSV != -1) updateQuoteProduct["niq_billingfrequency"] = new OptionSetValue(billingFrequencyOSV);
                    }
                }
            }

        }

        public bool CheckWithTermLenght(double termLength, string frequency)
        {
            tracingService.Trace("\nfunc: CheckWithTermLenght");
            tracingService.Trace("termlenght :" + termLength);
            tracingService.Trace("frequency name :" + frequency);
            switch (frequency)
            {
                case "BI-Monthly":
                case "Bimonthly":
                case "Bimonthly with Lag":
                case "Bi-Monthly with Lag":
                    if (termLength % 2 == 0) { break; }
                    else { return false; }
                case "Quarterly":
                case "Quarterly with Lag":
                    if (termLength % 3 == 0) { break; }
                    else { return false; }
                case "3 * Annually":
                case "3 X Annually":
                case "3x Annually":
                case "3x / Year":
                    if (termLength % 4 == 0) { break; }
                    else { return false; }
                case "Half-Yearly":
                case "2x / year":
                case "2x / Year":
                    if (termLength % 6 == 0) { break; }
                    else { return false; }
                case "Annually":
                case "Annual":
                    if (termLength % 12 == 0) { break; }
                    else { return false; }
            }
            tracingService.Trace("frequency is compatible with termlength");
            return true;
        }
    }
}