﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;


namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Opportunity_Account_UpdatePartyFields : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_Opportunity_Account_UpdatePartyFields: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity opportunityObj = (Entity)context.InputParameters["Target"];
                    Entity PostImageObj = context.PostEntityImages["Image"] as Entity;
                    Entity PreImageObj = context.PreEntityImages["Image"] as Entity;

                    if ((PostImageObj.Contains("parentaccountid") && PostImageObj["parentaccountid"] != null) || (PostImageObj.Contains("niq_stage") && PostImageObj["niq_stage"] != null))
                    {
                        tracing.Trace("parentaccountid: " + PostImageObj["parentaccountid"].ToString());


                        EntityReference prevAccountReference = PreImageObj.Contains("parentaccountid") ? (EntityReference)context.PreEntityImages["Image"].GetAttributeValue<EntityReference>("parentaccountid") : null;
                        EntityReference newAccountReference = PostImageObj.Contains("parentaccountid") ? PostImageObj.GetAttributeValue<EntityReference>("parentaccountid") : null;
                        tracing.Trace("PreAccount : " + prevAccountReference);
                        tracing.Trace("PostAccount : " + newAccountReference);

                        if (prevAccountReference.Id != newAccountReference.Id)
                        {

                            tracing.Trace("On change of Account value in Opportunity");
                            //if (!PostImageObj.Contains("niq_soldtoparty") && !PostImageObj.Contains("niq_billtoparty") && !PostImageObj.Contains("niq_deliverytoparty"))
                            //{
                            tracing.Trace("Update fields : (On Account change)");
                            UpdatePartyFields(tracing, context, service, PostImageObj);
                            //}

                        }
                        tracing.Trace("Checking stage to update fields");

                        String preActiveStage = PreImageObj.Contains("niq_stage") ? PreImageObj.GetAttributeValue<String>("niq_stage").ToLower() : string.Empty;
                        String postActiveStage = PostImageObj.Contains("niq_stage") ? PostImageObj.GetAttributeValue<String>("niq_stage").ToLower() : string.Empty;

                        tracing.Trace("preActiveStage :" + preActiveStage);


                        if ((preActiveStage == "pre-proposal" && postActiveStage == "proposal") ||
                            (preActiveStage == "proposal" && postActiveStage == "negotiation") ||
                            (preActiveStage == "negotiation" && postActiveStage == "closed won - in review"))
                        {
                            tracing.Trace("On BPF change from proposal to negotiation");

                            tracing.Trace("On change of stage value in Opportunity");
                            if (!PostImageObj.Contains("niq_soldtoparty") || !PostImageObj.Contains("niq_billtoparty") || !PostImageObj.Contains("niq_deliverytoparty"))
                            {
                                bool BillToParty = PreImageObj.Contains("niq_billtoparty") && PreImageObj["niq_billtoparty"] != null;
                                bool DeliveryToParty = PreImageObj.Contains("niq_deliverytoparty") && PreImageObj["niq_deliverytoparty"] != null;
                                
                                if (!BillToParty || !DeliveryToParty)
                                {
                                    tracing.Trace("Update fields : (On stage change)");
                                    UpdatePartyFields(tracing, context, service, PostImageObj);
                                }
                                //tracing.Trace("Update fields : (On stage change)");
                                //UpdatePartyFields(tracing, context, service, PostImageObj);
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private static void UpdatePartyFields(ITracingService tracing, IPluginExecutionContext context, IOrganizationService service, Entity opportunityObj)
        {
            Guid accountId = opportunityObj.GetAttributeValue<EntityReference>("parentaccountid").Id;
            tracing.Trace(opportunityObj.GetAttributeValue<EntityReference>("parentaccountid").Name);
            Entity account = service.Retrieve("account", accountId, new ColumnSet("niq_ultimateparentid"));
            //tracing.Trace("account (UPA) : " + account.GetAttributeValue<EntityReference>("niq_ultimateparentid").Name);

            Guid ultimateParentId = account.Contains("niq_ultimateparentid") ? account.GetAttributeValue<EntityReference>("niq_ultimateparentid").Id : Guid.Empty;
            //Guid ultimateParentId = account.GetAttributeValue<EntityReference>("niq_ultimateparentid").Id;
            tracing.Trace("Ultimate Parent Id : " + ultimateParentId);

            QueryExpression querySAPAccounts = new QueryExpression("account");
            querySAPAccounts.ColumnSet = new ColumnSet("niq_accounttype", "statecode", "niq_ultimateparentid", "niq_compliancefinancialstatus");

            FilterExpression filter = new FilterExpression(LogicalOperator.And);
            filter.AddCondition("niq_accounttype", ConditionOperator.Equal, 2);
            filter.AddCondition("statecode", ConditionOperator.Equal, 0);

            //filter.AddFilter(LogicalOperator.Or);

            if (ultimateParentId == Guid.Empty)
            {
                tracing.Trace("Ultimate Parent Id is null");
                ConditionExpression subCondition1 = new ConditionExpression("niq_ultimateparentid", ConditionOperator.Equal, accountId);
                filter.AddCondition(subCondition1);
            }
            else
            {
                tracing.Trace("Ultimate Parent Id is not null");
                ConditionExpression subCondition2 = new ConditionExpression("niq_ultimateparentid", ConditionOperator.Equal, ultimateParentId);
                filter.AddCondition(subCondition2);
            }

            querySAPAccounts.Criteria = filter;

            EntityCollection results = service.RetrieveMultiple(querySAPAccounts);
            tracing.Trace("Results : " + results);
            tracing.Trace(results.Entities.Count.ToString());

            Entity entity = service.Retrieve("niq_configurationsetting", new Guid("982a3707-594b-f011-877a-6045bda1abcd"), new ColumnSet("niq_to"));
            string isAugReleaseEnabled = entity.GetAttributeValue<string>("niq_to");

            bool isUpdateOpportunity = false;
            if(isAugReleaseEnabled == "true") {
                if (results.Entities.Count == 1 && results.Entities[0].Contains("niq_compliancefinancialstatus") && !new[] { 610570000, 610570001, 610570003, 610570004 }.Contains(results.Entities[0].GetAttributeValue<OptionSetValue>("niq_compliancefinancialstatus").Value))
                {
                    isUpdateOpportunity = true;
                }
            } 
            else 
            {
                if (results.Entities.Count == 1)
                {
                    isUpdateOpportunity = true;
                }
            }

            if (isUpdateOpportunity)
            {
                tracing.Trace("SAP account retrived");
                Entity sapAccount = results.Entities[0];
                Entity oppSapDetails = new Entity("opportunity");
                oppSapDetails.Id = opportunityObj.Id;
                tracing.Trace("Sap Account : " + sapAccount.Id);
                // if (!opportunityObj.Contains("niq_soldtoparty"))
                oppSapDetails["niq_soldtoparty"] = new EntityReference("account", sapAccount.Id);
                //if (!opportunityObj.Contains("niq_billtoparty"))
                oppSapDetails["niq_billtoparty"] = new EntityReference("account", sapAccount.Id);
                //if (!opportunityObj.Contains("niq_deliverytoparty"))
                oppSapDetails["niq_deliverytoparty"] = new EntityReference("account", sapAccount.Id);

                tracing.Trace("before updating sap");
                service.Update(oppSapDetails);
                tracing.Trace("after updating sap");
            }
        }
    }
}