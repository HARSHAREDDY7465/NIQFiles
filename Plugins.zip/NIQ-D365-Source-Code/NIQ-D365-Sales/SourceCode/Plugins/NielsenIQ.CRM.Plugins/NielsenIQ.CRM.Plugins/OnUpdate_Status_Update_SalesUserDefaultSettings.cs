﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xrm.Sdk.Query;
using System.Text;
using System.Threading.Tasks;
using NielsenIQ.CRM.Plugins.Helper;
using Microsoft.Crm.Sdk.Messages;
using static NielsenIQ.CRM.Plugins.Helper.CommonConstant;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Status_Update_SalesUserDefaultSettings : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(null);


                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains(CommonConstant.TARGET) && context.InputParameters[CommonConstant.TARGET] is Entity)
                {

                    Entity targetEntity = (Entity)context.InputParameters[CommonConstant.TARGET];
                    string logicalName = targetEntity.LogicalName;
                    tracing.Trace("target entity");
                   //// bool isActive = true;

                     //  0 means active
                    tracing.Trace("isactive" + targetEntity.GetAttributeValue<OptionSetValue>("statecode").Value.ToString());
                    int status = targetEntity.GetAttributeValue<OptionSetValue>("statecode").Value;
                    if (status != 0 )

                    {

                        Guid UpdatedEntityId = targetEntity.Id;

                        tracing.Trace("Query result inside");


                        QueryExpression salesUserDefaultSetting = new QueryExpression("niq_salesuserdefaultsettings");
                        if (logicalName == "niq_salesgroupsalesorg")
                            salesUserDefaultSetting.Criteria.AddCondition("niq_defaultsalesgroupsalesorg", ConditionOperator.Equal, UpdatedEntityId);
                        if (logicalName == "niq_salesorg")
                            salesUserDefaultSetting.Criteria.AddCondition("niq_defaultsalesorg", ConditionOperator.Equal, UpdatedEntityId);
                        if (logicalName == "transactioncurrency")
                            salesUserDefaultSetting.Criteria.AddCondition("niq_defaultcurrency", ConditionOperator.Equal, UpdatedEntityId);
                        EntityCollection salesUserDefaultSettingRecords = service.RetrieveMultiple(salesUserDefaultSetting);
                        tracing.Trace("Query result" + salesUserDefaultSettingRecords.Entities.Count);



                        // Update Setting records

                        foreach (Entity settingRecord in salesUserDefaultSettingRecords.Entities)

                        {
                            if (logicalName == "niq_salesgroupsalesorg")
                            {

                                settingRecord["niq_defaultsalesgroupsalesorg"] = null; // Erase the default value

                            }
                            if (logicalName == "niq_salesorg")
                            {
                                settingRecord["niq_defaultsalesorg"] = null;   // Erase the default  value

                                settingRecord["niq_defaultsalesgroupsalesorg"] = null;// Erase the default  value

                            }
                            if (logicalName == "transactioncurrency")
                            {
                                settingRecord["niq_defaultcurrency"] = null;   // Erase the default value

                            }


                            service.Update(settingRecord);


                        }



                    }

                }


            }
            catch (Exception e)
            {
                throw new InvalidPluginExecutionException(e.Message);
            }
        }
    }
}


