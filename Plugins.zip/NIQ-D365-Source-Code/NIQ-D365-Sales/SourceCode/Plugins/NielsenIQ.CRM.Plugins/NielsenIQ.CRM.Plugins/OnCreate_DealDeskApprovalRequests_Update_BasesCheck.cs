﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.Plugins
{
    public class OnCreate_DealDeskApprovalRequests_Update_BasesCheck : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                int count = 0;

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("NielsenIQ.CRM.Plugins.OnCreate_DealDeskApprovalRequests_Update_BasesCheck: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity ddobj = (Entity)context.InputParameters["Target"];
                    Entity quote = service.Retrieve(ddobj.LogicalName, ddobj.Id, new ColumnSet("niq_quoteid"));
                    QueryExpression query = new QueryExpression("quotedetail");
                    query.ColumnSet = new ColumnSet("niq_brandid");
                    query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, quote.GetAttributeValue<EntityReference>("niq_quoteid").Id);
                    EntityCollection quoteProducts = service.RetrieveMultiple(query);
                    foreach (Entity QuoteProduct in quoteProducts.Entities)
                    {
                        tracing.Trace(quote.GetAttributeValue<EntityReference>("niq_quoteid").Id.ToString());
                        if (QuoteProduct.Attributes.Contains("niq_brandid") && QuoteProduct.GetAttributeValue<EntityReference>("niq_brandid").Id != Guid.Empty)
                        {
                            Entity brand = service.Retrieve(QuoteProduct.GetAttributeValue<EntityReference>("niq_brandid").LogicalName, QuoteProduct.GetAttributeValue<EntityReference>("niq_brandid").Id, new ColumnSet("name"));
                            if (brand.GetAttributeValue<string>("name") == "BASES")
                            {
                                count++;
                            }
                        }
                    }
                    if(count> 0) 
                    {
                        Entity ddUpdate = new Entity(quote.LogicalName, quote.Id);
                        ddUpdate["niq_basescheck"] = true;
                        service.Update(ddUpdate);
                    }
                }

            }
            catch(Exception ex) 
            { 
            }

        }
    }
}

