﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_QuoteProduct_Date_Update_RelatedQuoteDate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                //Extract the tracing service for use in debugging sandboxed plug-ins.
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                // The InputParameters collection contains all the data  
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_QuoteProduct_Date_Update_RelatedQuoteDate: Getting the target entity from Input Parameters.");
                    // Obtain the target entity from the input parameters.
                    Entity upQuoteProduct = (Entity)context.InputParameters["Target"];
                    if (upQuoteProduct != null && upQuoteProduct.Id != Guid.Empty)
                    {
                        Entity retQuoteProduct = service.Retrieve(upQuoteProduct.LogicalName, upQuoteProduct.Id, new ColumnSet("quoteid"));
                        if (retQuoteProduct != null && retQuoteProduct.Id != Guid.Empty && retQuoteProduct.Attributes.Contains("quoteid"))
                        {
                            tracing.Trace("OnUpdate_QuoteProduct_Date_Update_RelatedQuoteDate: retQuoteProduct" + retQuoteProduct.Id);
                            Entity retQuote = service.Retrieve(retQuoteProduct.GetAttributeValue<EntityReference>("quoteid").LogicalName, retQuoteProduct.GetAttributeValue<EntityReference>("quoteid").Id, new ColumnSet("niq_mainquote", "opportunityid"));
                            if (retQuote != null && retQuote.Id != Guid.Empty && retQuote.Attributes.Contains("niq_mainquote") && retQuote.Attributes.Contains("opportunityid"))
                            {
                                string fetchDateQP = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' aggregate='true' >
                                                        <entity name='quotedetail' >
                                                            <attribute name='niq_lineitemstartdate' alias='minDate' aggregate='min' />
                                                            <attribute name='niq_lineitemenddate' alias='maxDate' aggregate='max' />
                                                            <filter type='and' >
                                                                <condition attribute='quoteid' operator='eq' uiname='testchanges' uitype='quote' value='{0}' />
                                                                <condition attribute='quotedetailname' operator='ne' value='SAP Deferred Revenue reconciliation placeholder' />
                                                            </filter>
                                                        </entity>
                                                    </fetch>";
                                fetchDateQP = string.Format(fetchDateQP, retQuote.Id);
                                var resDateQP = service.RetrieveMultiple(new FetchExpression(fetchDateQP));
                                Entity updQuote = new Entity(retQuote.LogicalName, retQuote.Id);
                                Entity updOppo = new Entity(retQuote.GetAttributeValue<EntityReference>("opportunityid").LogicalName, retQuote.GetAttributeValue<EntityReference>("opportunityid").Id);
                                bool updateQuote = false;
                                if (resDateQP != null && resDateQP.Entities != null && resDateQP.Entities.Count > 0)
                                {

                                    Entity dateQP = resDateQP.Entities.FirstOrDefault();
                                    if (dateQP.Contains("minDate"))
                                    {
                                        updQuote["niq_contractstartdate"] = dateQP.GetAttributeValue<AliasedValue>("minDate").Value;
                                        updOppo["niq_contractstartdate"] = dateQP.GetAttributeValue<AliasedValue>("minDate").Value;
                                        updateQuote = true;
                                    }
                                    if (dateQP.Contains("maxDate"))
                                    {
                                        updQuote["niq_contractenddate"] = dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                        updOppo["niq_contractenddate"] = dateQP.GetAttributeValue<AliasedValue>("maxDate").Value;
                                        updateQuote = true;
                                    }


                                }
                                else
                                {
                                    updateQuote = true;
                                    updQuote["niq_contractstartdate"] = null;
                                    updOppo["niq_contractstartdate"] = null;

                                    updQuote["niq_contractenddate"] = null;
                                    updOppo["niq_contractenddate"] = null;



                                }

                                if (updateQuote)
                                {
                                    service.Update(updQuote);
                                    tracing.Trace("OnCreate_QuoteProduct_AutoPopulateData: sucesfull update quote");
                                    if (retQuote.Attributes.Contains("niq_mainquote") && retQuote.GetAttributeValue<bool>("niq_mainquote"))
                                    {
                                        service.Update(updOppo);
                                        tracing.Trace("OnCreate_QuoteProduct_AutoPopulateData: sucesfull updated Oppo");

                                    }
                                }

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }

        }
    }
}
