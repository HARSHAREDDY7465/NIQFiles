﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_OppSharepointUrlFields_CreatePOCR : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);
                ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                tracing.Trace("started and flow userid:" + context.UserId.ToString());

                //Input Parameters
                var OppId = (string)context.InputParameters["OpportunityId"];
                var fileType = (string)context.InputParameters["TypeofFile"];
                var email = (string)context.InputParameters["UserEmail"];
                var filePath = (string)context.InputParameters["FileFullpath"];
                int oppStatus;

                //retrieve Sharepoint User Value                               
                QueryExpression qe = new QueryExpression("systemuser");
                qe.Criteria.AddCondition("internalemailaddress", ConditionOperator.Equal, email);
                qe.Criteria.AddCondition("isdisabled", ConditionOperator.Equal, false);
                EntityCollection userCol = service.RetrieveMultiple(qe);

                //check the user exists in crm or not
                if (userCol != null || userCol.Entities.Count > 0)
                {
                    tracing.Trace("inside user" + userCol.Entities[0].Id.ToString());
                    Guid UserGuid = userCol.Entities[0].Id;
                    IOrganizationService service1 = factory.CreateOrganizationService(UserGuid);

                    //retrieve the opportunity status and quote
                    Entity opp = service.Retrieve("opportunity", new Guid(OppId.ToString()), new ColumnSet("niq_mainquoteid", "statecode", "niq_billtoparty", "niq_deliverytoparty"));

                    if (opp.Contains("statecode"))
                    {
                        oppStatus = opp.GetAttributeValue<OptionSetValue>("statecode").Value;
                        tracing.Trace("Opportunity status:" + oppStatus.ToString());
                        //check if status is not won
                        if (oppStatus != 1)
                            return;
                    }
                    EntityReference oppBillToParty = new EntityReference();
                    EntityReference oppDeliverToParty = new EntityReference();
                    if (opp.Attributes.Contains("niq_billtoparty") && opp.GetAttributeValue<EntityReference>("niq_billtoparty") != null && opp.GetAttributeValue<EntityReference>("niq_billtoparty").Id != Guid.Empty)
                    {
                        oppBillToParty = opp.GetAttributeValue<EntityReference>("niq_billtoparty");
                        tracing.Trace("Opp-niq_billtoparty: " + oppBillToParty.ToString());
                    }
                    if (opp.Attributes.Contains("niq_deliverytoparty") && opp.GetAttributeValue<EntityReference>("niq_deliverytoparty") != null && opp.GetAttributeValue<EntityReference>("niq_deliverytoparty").Id != Guid.Empty)
                    {
                        oppDeliverToParty = opp.GetAttributeValue<EntityReference>("niq_deliverytoparty");
                        tracing.Trace("Opp-niq_billtoparty: " + oppDeliverToParty.ToString());
                    }

                    //Checks the Filetype and create the POCR

                    Entity POCR = new Entity("niq_postopportunity");
                    POCR["niq_opportunity"] = new EntityReference(opp.LogicalName, new Guid(OppId.ToString()));

                    if (fileType == "Purchase order")
                    {
                        tracing.Trace("inside:PO POCR");
                        POCR["niq_podocumentationurl"] = filePath;
                        POCR["niq_descriptionofchange"] = "PO file submission";
                        POCR["niq_typeofchange"] = new OptionSetValue(100000001);//Po details submission
                        POCR["niq_customerpo"] = "See Opportunity Files";

                        //Fields included for story DYNCRM-2223
                        POCR["niq_currentbilltoparty"] = oppBillToParty;
                        POCR["niq_newbilltopartyid"] = oppBillToParty;
                        POCR["niq_currentdelivertoparty"] = oppDeliverToParty;
                        POCR["niq_newdeliverytoparty"] = oppDeliverToParty;

                        service1.Create(POCR);
                        tracing.Trace("PO submission: POCR created");
                    }
                    else if (fileType == "Final EOA")
                    {
                        tracing.Trace("inside:Final EOA POCR");
                        POCR["niq_finallyexecutedagreementurl"] = filePath;
                        POCR["niq_descriptionofchange"] = "Finally Executed EOA file submission";
                        POCR["niq_typeofchange"] = new OptionSetValue(100000000);// "Finally executed agreement and payment terms submission"

                        Guid quoteGuid = opp.Contains("niq_mainquoteid") ? opp.GetAttributeValue<EntityReference>("niq_mainquoteid").Id : Guid.Empty;
                        if (quoteGuid != Guid.Empty)
                        {
                            Entity Quote = service.Retrieve("quote", quoteGuid, new ColumnSet("niq_paymenttermsid"));
                            POCR["niq_paymenttermsid"] = Quote.Attributes.Contains("niq_paymenttermsid") ? Quote.GetAttributeValue<EntityReference>("niq_paymenttermsid") : null; //display Payment Terms from the main quote of the opportunity
                            POCR["niq_currentpaymentterms"] = Quote.Attributes.Contains("niq_paymenttermsid") ? Quote.GetAttributeValue<EntityReference>("niq_paymenttermsid") : null;
                        }

                        service1.Create(POCR);
                        tracing.Trace("Final: POCR created");
                    }
                }
                context.OutputParameters["Message"] = "success";
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

    }
}