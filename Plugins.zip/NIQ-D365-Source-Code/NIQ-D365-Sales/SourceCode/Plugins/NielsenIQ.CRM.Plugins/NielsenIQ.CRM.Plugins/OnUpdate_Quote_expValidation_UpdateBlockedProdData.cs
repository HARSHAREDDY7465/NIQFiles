﻿using System;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Collections.Generic;
using System.Text;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_Quote_expValidation_UpdateBlockedProdData : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    tracing.Trace("OnUpdate_Quote_expValidation_UpdateBlockedProdData: Getting the target entity from Input Parameters.");
                    Entity quote = (Entity)context.InputParameters["Target"];
                    if (quote != null && quote.Id != Guid.Empty)
                    {
                        tracing.Trace("OnUpdate_Quote_expValidation_UpdateBlockedProdData: Quote ID: " + quote.Id.ToString());
                        Entity retQuote = service.Retrieve(quote.LogicalName, quote.Id, new ColumnSet("niq_blockedproductdesc", "niq_blockedproductnumber", "niq_salesorgid"));
                        if (retQuote != null)
                        {
                            tracing.Trace("OnUpdate_Quote_expValidation_UpdateBlockedProdData: retQuote not null");
                            string BlockedProdNum = retQuote.GetAttributeValue<String>("niq_blockedproductnumber");
                            string BlockedProdDesc = retQuote.GetAttributeValue<String>("niq_blockedproductdesc");
                            Guid salesOrgId = retQuote.GetAttributeValue<EntityReference>("niq_salesorgid").Id;
                            string SalesOrgName = GetSalesOrgName(service, tracing, salesOrgId.ToString());
                            tracing.Trace("SalesOrgName: " + SalesOrgName.ToString());

                            if (BlockedProdNum != null && SalesOrgName != null)
                            {
                                tracing.Trace("BlockedProdNum and SalesOrgName not null");
                                string PriceListId = string.Empty;
                                string[] splitVal = SalesOrgName.Split(' ');
                                string val = "%" + splitVal[0].ToString() + "%";
                                tracing.Trace("splitVal: " + val);
                                string fetchXmlGetPriceListId = @"<fetch version='1.0' distinct='false'>
                                                      <entity name='pricelevel'>
                                                        <attribute name='pricelevelid' />
                                                        <filter type='and'>
      							                            <condition attribute='name' operator='like' value='" + val + @"'/>
                                                        </filter></entity></fetch>";
                                tracing.Trace("OnUpdate_Quote_expValidation_UpdateBlockedProdData: fetchXmlGetPriceListId:" + fetchXmlGetPriceListId);
                                Entity resultPriceListId = service.RetrieveMultiple(new FetchExpression(fetchXmlGetPriceListId)).Entities.FirstOrDefault();
                                if (resultPriceListId != null)
                                {
                                    PriceListId = Convert.ToString(resultPriceListId.GetAttributeValue<Guid>("pricelevelid"));
                                    tracing.Trace("PriceListId: " + PriceListId);
                                }

                                if (!string.IsNullOrEmpty(PriceListId) && !string.IsNullOrEmpty(BlockedProdNum))
                                {
                                    string[] splitValProdNum = BlockedProdNum.Split(',');
                                    StringBuilder sbProdNum = new StringBuilder();
                                    foreach (string item in splitValProdNum)
                                    {
                                        string cc = @"<value>" + item.Trim() + @"</value>";
                                        sbProdNum.Append(cc);
                                    }

                                    string fetchXmlBlockedProduct = @"<fetch version='1.0' distinct='false'>
                                                                    <entity name='product'>
                                                                        <attribute name='productnumber' />
                                                                        <attribute name='niq_active' />
                                                                        <attribute name='productid' />
                                                                        <attribute name='description' />
                                                                        <link-entity name='productpricelevel' to='productid' from='productid' alias='productpricelevel' link-type='outer'>
                                                                          <attribute name='niq_blocked' />
                                                                          <attribute name='pricelevelid' />
                                                                          <attribute name='productpricelevelid' />
                                                                          <order attribute='productpricelevelid' />
                                                                        </link-entity>
                                                                        <filter>
                                                                          <condition attribute='productnumber' operator='in'>" + sbProdNum +
                                                                          @"</condition>
                                                                          <condition attribute='pricelevelid' entityname='productpricelevel' operator='eq' value='" + PriceListId + @"' />
                                                                          <filter type='or'>
                                                                            <condition attribute='niq_active' operator='eq' value='0' />
                                                                            <condition attribute='niq_blocked' entityname='productpricelevel' operator='eq' value='1' />
                                                                          </filter>
                                                                        </filter>
                                                                        <order attribute='productid' />
                                                                  </entity>
                                                                </fetch>";
                                    tracing.Trace("OnUpdate_Quote_expValidation_UpdateBlockedProdData: fetchXmlBlockedProduct:" + fetchXmlBlockedProduct);
                                    EntityCollection resultBlockedProduct = service.RetrieveMultiple(new FetchExpression(fetchXmlBlockedProduct));
                                    if (resultBlockedProduct != null && resultBlockedProduct.Entities.Count > 0)
                                    {
                                        tracing.Trace("resultBlockedProduct count: " + resultBlockedProduct.Entities.Count.ToString());
                                        StringBuilder sbProdNumb = new StringBuilder();
                                        StringBuilder sbProdDesc = new StringBuilder();

                                        if (sbProdNumb != null && sbProdDesc != null)
                                        {
                                            string fetchXmlGetQuoteProd = @"<fetch version='1.0' distinct='false'>
                                                      <entity name='quotedetail'>
                                                        <attribute name='productnumber' />
                                                        <attribute name='productname' />
                                                            <link-entity name='quote' to='quoteid' from='quoteid' link-type='inner'>
                                                                <filter type='and'>
      							                                    <condition attribute='quoteid' operator='like' value='" + quote.Id + @"'/>
                                                                </filter>             
                                                            </link-entity>
                                                        </entity></fetch>";
                                            tracing.Trace("OnUpdate_Quote_expValidation_UpdateBlockedProdData: fetchXmlGetQuoteProd:" + fetchXmlGetQuoteProd);
                                            EntityCollection resultQuoteProduct = service.RetrieveMultiple(new FetchExpression(fetchXmlGetQuoteProd));
                                            if (resultQuoteProduct != null && resultQuoteProduct.Entities.Count > 0)
                                            {
                                                tracing.Trace("resultQuoteProduct count: " + resultQuoteProduct.Entities.Count.ToString());
                                                foreach (Entity quoteprod in resultQuoteProduct.Entities)
                                                {
                                                    if (quoteprod != null)
                                                    {
                                                        string quoteProdnum = quoteprod.GetAttributeValue<String>("productnumber") + ", ";
                                                        //tracing.Trace("Entering First for: " + quoteProdnum.ToString());
                                                        if (quoteProdnum != null)
                                                        {
                                                            foreach (Entity blockedProduct in resultBlockedProduct.Entities)
                                                            {                                                                
                                                                if (blockedProduct != null)
                                                                {
                                                                    string blockedpn = blockedProduct.GetAttributeValue<String>("productnumber") + ", ";
                                                                    string blockedpd = blockedProduct.GetAttributeValue<String>("description") + "; ";
                                                                    //tracing.Trace("Entering Second for: " + blockedpn.ToString());
                                                                    if (blockedpn == quoteProdnum)
                                                                    {
                                                                        tracing.Trace("blockedpn == quoteProdnum");
                                                                        sbProdNumb.Append(blockedpn);
                                                                        sbProdDesc.Append(blockedpd);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            tracing.Trace("OnUpdate_Quote_expValidation_UpdateBlockedProdData: sbProdNumb: " + sbProdNumb.ToString());
                                            tracing.Trace("OnUpdate_Quote_expValidation_UpdateBlockedProdData: sbProdDesc:" + sbProdDesc.ToString());
                                            tracing.Trace("OnUpdate_Quote_expValidation_UpdateBlockedProdData: Entering for Update");
                                            Entity updQuote = new Entity("quote", quote.Id);
                                            updQuote["niq_blockedproductnumber"] = Convert.ToString(sbProdNumb).TrimEnd(',');//sbProdNumb.ToString().TrimEnd(',');
                                            updQuote["niq_blockedproductdesc"] = sbProdDesc.ToString().TrimEnd(';');
                                            service.Update(updQuote);
                                            tracing.Trace("OnUpdate_Quote_expValidation_UpdateBlockedProdData: Blocked Product data updated successfully");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //throw new InvalidPluginExecutionException(ex.Message);
                tracing.Trace("Exception in OnUpdate_Quote_expValidation_UpdateBlockedProdData: " + ex.Message);
            }
        }

        public string GetSalesOrgName(IOrganizationService service, ITracingService tracer, string salesOrgId)
        {
            string salesOrgName = string.Empty;
            try
            {
                if (salesOrgId != null)
                {
                    var query1 = new QueryExpression("niq_salesorg")
                    {
                        ColumnSet = new ColumnSet(true),
                        Criteria =
                            {
                                Conditions =
                                {
                                    new ConditionExpression("niq_salesorgid", ConditionOperator.Equal, salesOrgId)
                                }
                            }
                    };
                    var entitylist = service.RetrieveMultiple(query1);
                    if (entitylist.Entities[0] != null)
                    {
                        salesOrgName = entitylist.Entities[0].Attributes["niq_name"].ToString();
                    }
                }

            }
            catch (Exception ex)
            {
                tracer.Trace("Exception in OnUpdate_Quote_expValidation_UpdateBlockedProdData-GetSalesOrgName: " + ex.Message);
                salesOrgName = "";
            }
            return salesOrgName;
        }
    }
}
