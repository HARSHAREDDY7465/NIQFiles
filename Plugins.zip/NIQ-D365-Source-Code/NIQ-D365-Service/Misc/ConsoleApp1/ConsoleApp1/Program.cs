﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Configuration;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using System.Runtime.InteropServices;

namespace ConsoleApp1
{
    class Program
    {
        private static CrmServiceClient _client;
        ////public static string filePath = @"C:\Users\dora2002\OneDrive - Nielsen IQ\Desktop\QueueData1.xlsx";
        public static string filePath = @"C:\PawanNielsenDevelopment\RemappingQueues.xlsx";


        public static void Main(string[] args)
        {
            try
            {

                using (_client = new CrmServiceClient(ConfigurationManager.ConnectionStrings["CRMConnectionString"].ConnectionString))
                {
                    //Do stuff

                    if (_client.IsReady)
                    {
                        var request = new WhoAmIRequest();
                        var response = _client.Execute(request);
                        Excel.Application xlApp = new Excel.Application();

                        if (xlApp == null)
                        {
                            Console.WriteLine("Excel is not installed in the system...");
                            return;
                        }

                        object misValue = System.Reflection.Missing.Value;

                        //  Excel.Application xlApp = new Excel.Application();
                        Excel.Workbook xlWorkBook = xlApp.Workbooks.Open(filePath);
                        Excel.Worksheet xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                        Excel.Range xlRange = xlWorkSheet.UsedRange;
                        int totalRows = xlRange.Rows.Count;
                        int totalColumns = xlRange.Columns.Count;

                        string sourcequeue, destinationqueue;

                        for (int rowCount = 2; rowCount <= totalRows; rowCount++)
                        {

                            sourcequeue = Convert.ToString((xlRange.Cells[rowCount, 1] as Excel.Range).Text);

                            //destinationqueue = sourcequeue.Substring(1, sourcequeue.Length - 2);
                            destinationqueue = Convert.ToString((xlRange.Cells[rowCount, 2] as Excel.Range).Text);

                            EntityCollection destinationQueue = DestinationQueue(_client, destinationqueue);
                            //rapa1003
                            EntityCollection sourceTeam = GetTeamDetails(_client, sourcequeue);
                            EntityCollection destinationTeam = GetTeamDetails(_client, destinationqueue);

                            RemappQueueTeamMembers(sourcequeue, destinationqueue, destinationQueue, sourceTeam, destinationTeam);

                            ////Delete Queues
                            //DeleteQueuesByName(_client, sourcequeue);

                            ////Delete Teams
                            //DeleteTeamsByName(_client, sourcequeue);
                        }

                        xlWorkBook.Close();
                        xlApp.Quit();

                        Marshal.ReleaseComObject(xlWorkSheet);
                        Marshal.ReleaseComObject(xlWorkBook);
                        Marshal.ReleaseComObject(xlApp);

                        Console.WriteLine("End of the file...");
                        // EntityCollection sharepointcollection = IndienttobeupdatedforSharepoint(_client);
                        //UpdateParentReference(_client, sharepointcollection);
                        // EntityCollection contactcollection = GetContactswhichdoeshaveCALS(_client);
                        //GetCALSCombinationforEachContact(_client, contactcollection);

                        Console.WriteLine("Validation was successful.");
                        Console.WriteLine();


                    }
                    else
                    {
                        Console.WriteLine("Validation was Failed.");
                        Console.WriteLine();

                    }
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                string message = ex.Message;
                throw;
            }



        }

        private static void RemappQueueTeamMembers(string sourcequeue, string destinationqueue, EntityCollection destinationQueue, EntityCollection sourceTeam, EntityCollection destinationTeam)
        {
            if (destinationQueue.Entities.Count > 0)
            {
                EntityCollection queueitemneedtobeTranfered = QueueItem(_client, sourcequeue);
                Chunk ch = new Chunk();
                var chunked = ch.BuildChunksWithLinq(queueitemneedtobeTranfered.Entities.ToList(), 50).ToList();
                foreach (List<Entity> batch in chunked)
                {
                    Console.WriteLine(sourcequeue);
                    Console.WriteLine(destinationqueue);
                    Console.WriteLine("Batch Count " + batch.Count + "Chunk count" + chunked.Count);

                    List<AddToQueueRequest> AdduserTeamrequest = new List<AddToQueueRequest>();

                    foreach (Entity entity in batch)
                    {

                        EntityReference sourequeue = entity.GetAttributeValue<EntityReference>("queueid");

                        AddToQueueRequest routeRequest = new AddToQueueRequest
                        {
                            SourceQueueId = sourequeue.Id,
                            Target = new EntityReference(entity.GetAttributeValue<EntityReference>("objectid").LogicalName, entity.GetAttributeValue<EntityReference>("objectid").Id),
                            DestinationQueueId = destinationQueue.Entities[0].Id
                        };
                        AdduserTeamrequest.Add(routeRequest);
                    }

                    // create the request collection
                    OrganizationRequestCollection requestCollection = new OrganizationRequestCollection();
                    requestCollection.AddRange(AdduserTeamrequest);

                    // create the execute multiple and set the requestCollection
                    ExecuteMultipleRequest execRequest = new ExecuteMultipleRequest()
                    {
                        Settings = new ExecuteMultipleSettings()
                        {
                            ContinueOnError = true,
                            ReturnResponses = true
                        },
                        Requests = requestCollection
                    };
                    ExecuteMultipleResponse responseWithResults = (ExecuteMultipleResponse)_client.Execute(execRequest);

                    foreach (var responseItem in responseWithResults.Responses)
                    {
                        // A valid response.
                        if (responseItem.Response != null) { }
                        //  Console.WriteLine(responseItem.Response);

                        // An error has occurred.
                        else if (responseItem.Fault != null)
                            Console.WriteLine(responseItem.Fault.Message);
                    }

                    //rapa1003 date: 09/05/2022
                    //To change owner of request
                    if (destinationTeam != null && destinationTeam.Entities.Count > 0)
                        UpdateRequestOwner(destinationTeam, batch);
                }

                //Add old team members to new team
                UpdateTeamMembers(sourceTeam, destinationTeam);

            }
        }

        private static void UpdateTeamMembers(EntityCollection sourceTeam, EntityCollection destinationTeam)
        {
            if (sourceTeam != null && sourceTeam.Entities.Count > 0)
            {
                EntityCollection teamMembership = GetTeamMembershipDetails(_client, sourceTeam.Entities[0].Id);

                if (teamMembership != null && teamMembership.Entities.Count > 0)
                {
                    //Guid[] userIds = teamMembership.Entities.Select(s => new Guid(s.Attributes["systemuserid"].ToString())).ToArray();
                    Guid[] userIds = GetEnableUsers(teamMembership, _client);

                    if (destinationTeam != null && destinationTeam.Entities.Count > 0)
                    {
                        AddMembersToTeam(destinationTeam.Entities[0].Id, userIds, _client);
                        RemoveMembersFromTeam(sourceTeam.Entities[0].Id, userIds, _client);
                    }


                }
            }
        }

        public static Guid[] GetEnableUsers(EntityCollection teamMembership, IOrganizationService service)
        {
            Guid[] userIds = null;
            List<Guid> lstUserIds = new List<Guid>();

            foreach (var item in teamMembership.Entities)
            {
                EntityCollection users = null;
                string fetchXmlUser = string.Format(@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='systemuser'>
    <attribute name='fullname' />
    <attribute name='systemuserid' />
    <attribute name='isdisabled' />
    <order attribute='fullname' descending='false' />
    <filter type='and'>
      <condition attribute='systemuserid' operator='eq' uitype='systemuser' value='{0}' />
    </filter>
  </entity>
</fetch>", item["systemuserid"]);

                users = service.RetrieveMultiple(new FetchExpression(fetchXmlUser));

                if (users != null && users.Entities.Count > 0)
                {
                    if (users.Entities[0].Attributes.Contains("isdisabled") && users.Entities[0].Attributes["isdisabled"] != null)
                    {
                        bool isdisabled = Convert.ToBoolean(users.Entities[0].Attributes["isdisabled"].ToString());
                        if (!isdisabled)
                        {
                            lstUserIds.Add(new Guid(users.Entities[0].Attributes["systemuserid"].ToString()));
                        }
                    }
                }
            }

            userIds = lstUserIds.ToArray();
            return userIds;
        }
        public static void AddMembersToTeam(Guid teamId, Guid[] membersId, IOrganizationService service)
        {
            // Create the AddMembersTeamRequest object.
            AddMembersTeamRequest addRequest = new AddMembersTeamRequest();

            // Set the AddMembersTeamRequest TeamID property to the object ID of 
            // an existing team.
            addRequest.TeamId = teamId;

            // Set the AddMembersTeamRequest MemberIds property to an 
            // array of GUIDs that contains the object IDs of one or more system users.
            addRequest.MemberIds = membersId;

            // Execute the request.
            service.Execute(addRequest);
        }

        public static void RemoveMembersFromTeam(Guid teamId, Guid[] membersId, IOrganizationService service)
        {
            // Create the AddMembersTeamRequest object.
            RemoveMembersTeamRequest addRequest = new RemoveMembersTeamRequest();

            // Set the AddMembersTeamRequest TeamID property to the object ID of 
            // an existing team.
            addRequest.TeamId = teamId;

            // Set the AddMembersTeamRequest MemberIds property to an 
            // array of GUIDs that contains the object IDs of one or more system users.
            addRequest.MemberIds = membersId;

            // Execute the request.
            service.Execute(addRequest);
        }
        private static void UpdateRequestOwner(EntityCollection destinationTeam, List<Entity> batch)
        {
            foreach (Entity entity in batch)
            {
                EntityReference objectid = entity.GetAttributeValue<EntityReference>("objectid");
                OptionSetValue objecttypecode = entity.GetAttributeValue<OptionSetValue>("objecttypecode");

                if (objectid != null && objecttypecode.Value == 112)
                {
                    AssignRequest assignowner = new AssignRequest
                    {
                        Assignee = new EntityReference("team", destinationTeam.Entities[0].Id),
                        Target = new EntityReference("incident", objectid.Id)
                    };
                    _client.Execute(assignowner);
                }
            }
        }

        public static EntityCollection GetTeamDetails(IOrganizationService service, string teamName)
        {
            EntityCollection teams = null;
            string fetchXmlTeam = string.Format(@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='team'>
    <attribute name='name' />
    <attribute name='businessunitid' />
    <attribute name='teamid' />
    <attribute name='teamtype' />
    <order attribute='name' descending='false' />
    <filter type='and'>
      <condition attribute='name' operator='eq' value='{0}' />
    </filter>
  </entity>
</fetch>", teamName.Trim());

            teams = service.RetrieveMultiple(new FetchExpression(fetchXmlTeam));
            return teams;
        }

        public static EntityCollection GetTeamMembershipDetails(IOrganizationService service, Guid teamId)
        {
            EntityCollection teamsMembership = null;
            string fetchXmlTeam = string.Format(@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='teammembership'>
    <attribute name='systemuserid' />
    <attribute name='teamid' />
    <filter type='and'>
      <condition attribute='teamid' operator='eq' value='{0}' />
    </filter>
  </entity>
</fetch>", teamId);

            teamsMembership = service.RetrieveMultiple(new FetchExpression(fetchXmlTeam));
            return teamsMembership;
        }

        public static EntityCollection QueueItem(CrmServiceClient service, String aa_name)
        {

            EntityCollection collection = new EntityCollection();
            // Define Condition Values
            //      aa_name = "<AF-EWA-RL(Queue)>";

            // Instantiate QueryExpression query
            var query = new QueryExpression("queueitem");

            // Add columns to query.ColumnSet
            query.ColumnSet.AddColumns("objecttypecode", "objectid", "title", "enteredon", "queueitemid", "queueid");
            query.AddOrder("enteredon", OrderType.Descending);

            // Add link-entity aa
            var aa = query.AddLink("queue", "queueid", "queueid");
            aa.EntityAlias = "aa";

            // Define filter aa.LinkCriteria
            aa.LinkCriteria.AddCondition("name", ConditionOperator.Equal, aa_name);

            collection = service.RetrieveMultiple(query);




            return collection;


        }

        public static EntityCollection DestinationQueue(CrmServiceClient service, String query_name)
        {
            EntityCollection collection = new EntityCollection();
            // Define Condition Values
            //   var query_name = "";

            // Instantiate QueryExpression query
            var query = new QueryExpression("queue");

            // Add columns to query.ColumnSet
            query.ColumnSet.AddColumns("name", "queueid");
            query.AddOrder("name", OrderType.Ascending);

            // Define filter query.Criteria
            query.Criteria.AddCondition("name", ConditionOperator.Equal, query_name);


            collection = service.RetrieveMultiple(query);




            return collection;



        }


        public static void UpdateParentReference(CrmServiceClient service, EntityCollection listneedtobeupdated)
        {



            foreach (Entity updatesharepoint in listneedtobeupdated.Entities)
            {
                // Entity ParentRecord = GetSharepointlocationBasedRelativeURL(service, updatesharepoint.GetAttributeValue<EntityReference>("parentsiteorlocation").Name);
                //Console.WriteLine(ParentRecord.Id + " " + updatesharepoint.GetAttributeValue<EntityReference>("parentsiteorlocation").Name);

                //Entity recordneedtoupdated = new Entity(updatesharepoint.LogicalName, updatesharepoint.Id);

                //recordneedtoupdated["parentsiteorlocation"] = new EntityReference(ParentRecord.LogicalName, ParentRecord.Id);
                //                service.Update(recordneedtoupdated);

                RetrieveAbsoluteAndSiteCollectionUrlRequest retrieveRequest = new RetrieveAbsoluteAndSiteCollectionUrlRequest
                {
                    Target = new EntityReference(updatesharepoint.LogicalName, updatesharepoint.Id)
                };
                RetrieveAbsoluteAndSiteCollectionUrlResponse retriveResponse = (RetrieveAbsoluteAndSiteCollectionUrlResponse)service.Execute(retrieveRequest);
                Console.WriteLine("Absolute URL of document location record is '{0}'.", retriveResponse.AbsoluteUrl.ToString());
                Console.WriteLine("Site Collection URL of document location record is '{0}'.", retriveResponse.SiteCollectionUrl.ToString());
            }

        }

        public static Entity GetSharepointlocationBasedRelativeURL(CrmServiceClient service, String RelativeURL)
        {


            EntityCollection collection = new EntityCollection();

            // Define Condition Values
            var query_relativeurl = RelativeURL;

            // Instantiate QueryExpression query
            var query = new QueryExpression("sharepointdocumentlocation");
            query.TopCount = 1;
            query.AddOrder("createdon", OrderType.Ascending);

            // Add columns to query.ColumnSet
            query.ColumnSet.AddColumns("sharepointdocumentlocationid");
            query.ColumnSet.AddColumns("relativeurl");
            // Define filter query.Criteria
            query.Criteria.AddCondition("relativeurl", ConditionOperator.Equal, query_relativeurl);

            collection = service.RetrieveMultiple(query);

            return collection.Entities[0];
        }


        public static EntityCollection IndienttobeupdatedforSharepoint(CrmServiceClient service)
        {
            EntityCollection collection = new EntityCollection();
            // Instantiate QueryExpression query
            // Define Condition Values
            var query_relativeurl = "incident";

            // Instantiate QueryExpression query
            var query = new QueryExpression("sharepointdocumentlocation");
            //            query.TopCount = 1;

            // Add columns to query.ColumnSet
            query.ColumnSet.AddColumns("sharepointdocumentlocationid", "parentsiteorlocation", "relativeurl", "regardingobjectid");

            // Define filter query.Criteria
            query.Criteria.AddCondition("relativeurl", ConditionOperator.Equal, query_relativeurl);
            var query_Criteria_0 = new FilterExpression();
            query.Criteria.AddFilter(query_Criteria_0);

            // Define filter query_Criteria_0
            query_Criteria_0.AddCondition("b", "parentsiteorlocation", ConditionOperator.Null);
            query_Criteria_0.AddCondition("parentsiteorlocation", ConditionOperator.NotNull);

            // Add link-entity b
            var b = query.AddLink("sharepointdocumentlocation", "parentsiteorlocation", "sharepointdocumentlocationid", JoinOperator.LeftOuter);
            b.EntityAlias = "b";

            // Add columns to b.Columns
            b.Columns.AddColumns("sharepointdocumentlocationid", "parentsiteorlocation");

            collection = service.RetrieveMultiple(query);


            return collection;

        }

        public static EntityCollection GetContactswhichdoeshaveCALS(CrmServiceClient service)
        {
            EntityCollection collection = new EntityCollection();
            // Instantiate QueryExpression query
            var query = new QueryExpression("contact");
            //query.TopCount = 1;


            // Add columns to query.ColumnSet
            query.ColumnSet.AddColumns("contactid", "niq_customertype", "niq_geography", "niq_servicecategory", "fullname");

            // Define filter query.Criteria
            query.Criteria.AddCondition("niq_calids", ConditionOperator.Null);
            query.Criteria.AddCondition("niq_customertype", ConditionOperator.NotNull);
            query.Criteria.AddCondition("niq_geography", ConditionOperator.NotNull);
            query.Criteria.AddCondition("niq_servicecategory", ConditionOperator.NotNull);

            collection = service.RetrieveMultiple(query);


            return collection;

        }

        public static void GetCALSCombinationforEachContact(CrmServiceClient service, EntityCollection contatcollection)
        {

            foreach (Entity contactrecordentity in contatcollection.Entities)
            {
                Console.WriteLine("FullNanem and Guid" + (contactrecordentity.Attributes.Contains("fullname") ? contactrecordentity["fullname"].ToString() : "NO Fullname" + " " + contactrecordentity.Id));



                EntityCollection adxrecordcoltotal = new EntityCollection();
                string[] niq_servicecategoryarray = contactrecordentity.FormattedValues["niq_servicecategory"].Split(';');
                string[] niq_geographyarray = contactrecordentity.FormattedValues["niq_geography"].Split(';');
                string[] niq_customertypearray = contactrecordentity.FormattedValues["niq_customertype"].Split(';');




                List<String> list = new List<string>();

                foreach (string niq_servicecategory in niq_servicecategoryarray)
                {
                    foreach (string niq_geography in niq_geographyarray)
                    {
                        foreach (string niq_customertype in niq_customertypearray)
                        {
                            //sb.AppendLine("<condition attribute='adx_name' operator='eq' value='" + niq_servicecategory.Trim() + "-" + niq_geography.Trim() + "-" + niq_customertype.Trim() + "' />");
                            list.Add("<condition attribute='adx_name' operator='eq' value='" + niq_servicecategory.Trim() + "-" + niq_geography.Trim() + "-" + niq_customertype.Trim() + "' />");
                        }

                    }
                }


                Chunk ch = new Chunk();
                var chunked = ch.BuildChunksWithLinq(list, 200).ToList();



                foreach (List<string> S in chunked)
                {
                    StringBuilder sb = new StringBuilder();

                    foreach (string st in S)
                    {

                        sb.AppendLine(st);

                    }

                    string adxfetchxml = string.Format(@"<fetch>
  <entity name='adx_contentaccesslevel'>
    <attribute name='adx_contentaccesslevelid' />
    <attribute name='adx_name' />
    <filter type='or'>
      {0}
    </filter>
  </entity>
</fetch>", sb.ToString());

                    FetchExpression adxrecord = new FetchExpression(adxfetchxml);

                    EntityCollection adxrecordcol = service.RetrieveMultiple(adxrecord);
                    adxrecordcoltotal.Entities.AddRange(adxrecordcol.Entities);


                    DissociateMultipleRequest(service, adxrecordcol, contactrecordentity);
                    AssociateMultipleRequest(service, adxrecordcol, contactrecordentity);

                }

                UpdateCalforContact(service, contactrecordentity, adxrecordcoltotal);


            }



        }

        public static void DissociateMultipleRequest(CrmServiceClient service, EntityCollection adxrecordcol, Entity contactrecordentity)
        {
            // Create an ExecuteMultipleRequest object.
            ExecuteMultipleRequest requestWithResults = new ExecuteMultipleRequest()
            {
                // Assign settings that define execution behavior: continue on error, return responses. 
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = false,
                    ReturnResponses = true
                },
                // Create an empty organization request collection.
                Requests = new OrganizationRequestCollection()
            };

            // Create several (local, in memory) entities in a collection. 
            EntityCollection input = adxrecordcol;
            string relationshipName = "adx_ContactContentAccessLevel";
            Relationship relationship = new Relationship(relationshipName);

            // Add a CreateRequest for each entity to the request collection.
            foreach (var entity in input.Entities)
            {
                var relatedEntities = new EntityReferenceCollection();
                relatedEntities.Add(entity.ToEntityReference());


                DisassociateRequest dissocaiteRequest = new DisassociateRequest { Target = contactrecordentity.ToEntityReference(), Relationship = relationship, RelatedEntities = relatedEntities };
                requestWithResults.Requests.Add(dissocaiteRequest);
            }

            // Execute all the requests in the request collection using a single web method call.
            ExecuteMultipleResponse responseWithResults =
                (ExecuteMultipleResponse)service.Execute(requestWithResults);

            // Display the results returned in the responses.
            foreach (var responseItem in responseWithResults.Responses)
            {
                // A valid response.
                if (responseItem.Response != null)
                    DisplayResponse(requestWithResults.Requests[responseItem.RequestIndex], responseItem.Response);

                // An error has occurred.
                else if (responseItem.Fault != null)
                    DisplayFault(requestWithResults.Requests[responseItem.RequestIndex],
                        responseItem.RequestIndex, responseItem.Fault);
            }
        }


        private static void AssociateMultipleRequest(CrmServiceClient service, EntityCollection adxrecordcol, Entity contactrecordentity)
        {
            Entity Contact = new Entity("contact", contactrecordentity.Id);

            // Create an ExecuteMultipleRequest object.
            ExecuteMultipleRequest requestWithResults = new ExecuteMultipleRequest()
            {
                // Assign settings that define execution behavior: continue on error, return responses. 
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = false,
                    ReturnResponses = true
                },
                // Create an empty organization request collection.
                Requests = new OrganizationRequestCollection()
            };

            // Create several (local, in memory) entities in a collection. 
            EntityCollection input = adxrecordcol;
            string relationshipName = "adx_ContactContentAccessLevel";
            Relationship relationship = new Relationship(relationshipName);

            // Add a CreateRequest for each entity to the request collection.
            foreach (var entity in input.Entities)
            {
                var relatedEntities = new EntityReferenceCollection();
                relatedEntities.Add(entity.ToEntityReference());


                AssociateRequest assocaiteRequest = new AssociateRequest { Target = Contact.ToEntityReference(), Relationship = relationship, RelatedEntities = relatedEntities };
                requestWithResults.Requests.Add(assocaiteRequest);
            }

            // Execute all the requests in the request collection using a single web method call.
            ExecuteMultipleResponse responseWithResults =
                (ExecuteMultipleResponse)service.Execute(requestWithResults);

            // Display the results returned in the responses.
            foreach (var responseItem in responseWithResults.Responses)
            {
                // A valid response.
                if (responseItem.Response != null)
                    DisplayResponse(requestWithResults.Requests[responseItem.RequestIndex], responseItem.Response);

                // An error has occurred.
                else if (responseItem.Fault != null)
                    DisplayFault(requestWithResults.Requests[responseItem.RequestIndex],
                        responseItem.RequestIndex, responseItem.Fault);
            }



        }

        private static void DisplayFault(OrganizationRequest organizationRequest, int count,
           OrganizationServiceFault organizationServiceFault)
        {
            Console.WriteLine("A fault occurred when processing {1} request, at index {0} in the request collection with a fault message: {2}", count + 1,
                organizationRequest.RequestName,
                organizationServiceFault.Message);
        }
        private static void DisplayResponse(OrganizationRequest organizationRequest, OrganizationResponse organizationResponse)
        {
            Console.WriteLine("Created " + (organizationRequest.Parameters["Target"]));
        }

        public static void UpdateCalforContact(CrmServiceClient service, Entity contact, EntityCollection contectacceslevel)
        {

            Entity Contact = new Entity("contact", contact.Id);
            StringBuilder cals = new StringBuilder();


            foreach (Entity adxr in contectacceslevel.Entities)
            {
                cals.Append(adxr.GetAttributeValue<Guid>("adx_contentaccesslevelid").ToString() + ",");
            }
            Contact["niq_calids"] = cals.ToString();
            service.Update(Contact);

        }

        public static void DeleteQueuesByName(CrmServiceClient service, string queueName)
        {

            EntityCollection queueCollections = DestinationQueue(service, queueName);
            if (queueCollections != null)
                foreach (var item in queueCollections.Entities)
                    service.Delete("queue", new Guid(item["queueid"].ToString()));

        }

        public static void DeleteTeamsByName(CrmServiceClient service, string teamName)
        {

            EntityCollection teamCollections = GetTeamDetails(service, teamName);
            if (teamCollections != null)
                foreach (var item in teamCollections.Entities)
                    service.Delete("team", new Guid(item["teamid"].ToString()));
        }

        public class Chunk
        {
            public IEnumerable<IEnumerable<T>> BuildChunks<T>(List<T> fullList, int batchSize)
            {
                return BuildChunksWithIteration(fullList, batchSize);
            }



            private IEnumerable<IEnumerable<T>> BuildChunksWithLinqAndYield<T>(List<T> fullList, int batchSize)
            {
                return null;
            }

            private IEnumerable<IEnumerable<T>> BuildChunksWithIteration<T>(List<T> fullList, int batchSize)
            {
                return null;
            }

            private IEnumerable<IEnumerable<T>> BuildChunksWithRange<T>(List<T> fullList, int batchSize)
            {
                return null;
            }

            public IEnumerable<IEnumerable<T>> BuildChunksWithLinq<T>(List<T> fullList, int batchSize)
            {
                int total = 0;
                var chunkedList = new List<List<T>>();
                while (total < fullList.Count)
                {
                    var chunk = fullList.Skip(total).Take(batchSize);
                    chunkedList.Add(chunk.ToList());
                    total += batchSize;
                }

                return chunkedList;
            }

            public List<List<T>> ChunkBy<T>(List<T> fullList, int batchSize)
            {
                int total = 0;
                var chunkedList = new List<List<T>>();
                while (total < fullList.Count)
                {
                    var chunk = fullList.Skip(total).Take(batchSize);
                    chunkedList.Add(chunk.ToList());
                    total += batchSize;
                }

                return chunkedList;
            }


        }





    }
}
