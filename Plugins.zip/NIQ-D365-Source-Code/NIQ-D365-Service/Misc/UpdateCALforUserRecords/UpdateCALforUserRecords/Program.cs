﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace UpdateCALforUserRecords
{
    class Program
    {
        private static CrmServiceClient _client;

        public static void Main(string[] args)
        {
            try
            {
                using (_client = new CrmServiceClient(ConfigurationManager.ConnectionStrings["CRMConnectionString"].ConnectionString))
                {
                    //Do stuff

                    if (_client.IsReady)
                    {
                        var request = new WhoAmIRequest();
                        var response = _client.Execute(request);
                        Console.WriteLine("Validation was successful.");
                        Console.WriteLine();


                        
                        string UserID = @"
884305ab-c8ca-ec11-a7b5-000d3a4b4656,
8d4305ab-c8ca-ec11-a7b5-000d3a4b4656,
924305ab-c8ca-ec11-a7b5-000d3a4b4656,
a24305ab-c8ca-ec11-a7b5-000d3a4b4656,
b24305ab-c8ca-ec11-a7b5-000d3a4b4656,
d14305ab-c8ca-ec11-a7b5-000d3a4b4656,
de4305ab-c8ca-ec11-a7b5-000d3a4b4656,
ec4305ab-c8ca-ec11-a7b5-000d3a4b4656,
fa4305ab-c8ca-ec11-a7b5-000d3a4b4656,
084405ab-c8ca-ec11-a7b5-000d3a4b4656,
0b4405ab-c8ca-ec11-a7b5-000d3a4b4656,
2a4405ab-c8ca-ec11-a7b5-000d3a4b4656,
484405ab-c8ca-ec11-a7b5-000d3a4b4656,
4e4405ab-c8ca-ec11-a7b5-000d3a4b4656,
534405ab-c8ca-ec11-a7b5-000d3a4b4656,
834405ab-c8ca-ec11-a7b5-000d3a4b4656,
924405ab-c8ca-ec11-a7b5-000d3a4b4656,
974405ab-c8ca-ec11-a7b5-000d3a4b4656,
d44405ab-c8ca-ec11-a7b5-000d3a4b4656,
d94405ab-c8ca-ec11-a7b5-000d3a4b4656,
eb4405ab-c8ca-ec11-a7b5-000d3a4b4656,
0a4505ab-c8ca-ec11-a7b5-000d3a4b4656,
134505ab-c8ca-ec11-a7b5-000d3a4b4656,
264505ab-c8ca-ec11-a7b5-000d3a4b4656,
3e4505ab-c8ca-ec11-a7b5-000d3a4b4656,
b9b404b1-c8ca-ec11-a7b5-000d3a4b4656,
bdb404b1-c8ca-ec11-a7b5-000d3a4b4656,
c3b404b1-c8ca-ec11-a7b5-000d3a4b4656,
e0b404b1-c8ca-ec11-a7b5-000d3a4b4656,
fdb404b1-c8ca-ec11-a7b5-000d3a4b4656,
05b504b1-c8ca-ec11-a7b5-000d3a4b4656,
18b504b1-c8ca-ec11-a7b5-000d3a4b4656,
2bb504b1-c8ca-ec11-a7b5-000d3a4b4656,
31b504b1-c8ca-ec11-a7b5-000d3a4b4656,
34b504b1-c8ca-ec11-a7b5-000d3a4b4656,
51b504b1-c8ca-ec11-a7b5-000d3a4b4656,
57b504b1-c8ca-ec11-a7b5-000d3a4b4656,
73b504b1-c8ca-ec11-a7b5-000d3a4b4656,
82b504b1-c8ca-ec11-a7b5-000d3a4b4656,
88b504b1-c8ca-ec11-a7b5-000d3a4b4656,
8db504b1-c8ca-ec11-a7b5-000d3a4b4656,
a4b504b1-c8ca-ec11-a7b5-000d3a4b4656,
afb504b1-c8ca-ec11-a7b5-000d3a4b4656,
cbb504b1-c8ca-ec11-a7b5-000d3a4b4656,
d2b504b1-c8ca-ec11-a7b5-000d3a4b4656,
deb504b1-c8ca-ec11-a7b5-000d3a4b4656,
e9b504b1-c8ca-ec11-a7b5-000d3a4b4656,
eeb504b1-c8ca-ec11-a7b5-000d3a4b4656,
12b604b1-c8ca-ec11-a7b5-000d3a4b4656,
29b604b1-c8ca-ec11-a7b5-000d3a4b4656,
2cb604b1-c8ca-ec11-a7b5-000d3a4b4656,
4ab604b1-c8ca-ec11-a7b5-000d3a4b4656,
53b604b1-c8ca-ec11-a7b5-000d3a4b4656,
75b604b1-c8ca-ec11-a7b5-000d3a4b4656,
84b604b1-c8ca-ec11-a7b5-000d3a4b4656,
87b604b1-c8ca-ec11-a7b5-000d3a4b4656,
8db604b1-c8ca-ec11-a7b5-000d3a4b4656,
9fb604b1-c8ca-ec11-a7b5-000d3a4b4656,
b5b604b1-c8ca-ec11-a7b5-000d3a4b4656,
d1b604b1-c8ca-ec11-a7b5-000d3a4b4656,
d9b604b1-c8ca-ec11-a7b5-000d3a4b4656,
dcb604b1-c8ca-ec11-a7b5-000d3a4b4656,
fab604b1-c8ca-ec11-a7b5-000d3a4b4656,
1eb704b1-c8ca-ec11-a7b5-000d3a4b4656,
3fb704b1-c8ca-ec11-a7b5-000d3a4b4656,
49b704b1-c8ca-ec11-a7b5-000d3a4b4656,
68b704b1-c8ca-ec11-a7b5-000d3a4b4656,
75b704b1-c8ca-ec11-a7b5-000d3a4b4656,
2a00fdb6-c8ca-ec11-a7b5-000d3a4b4656,
396d1803-d0ca-ec11-a7b5-000d3a4b4656,
406d1803-d0ca-ec11-a7b5-000d3a4b4656,
af6d1803-d0ca-ec11-a7b5-000d3a4b4656,
6c6e1803-d0ca-ec11-a7b5-000d3a4b4656,
beff2f3e-7eca-ec11-a7b5-000d3a4b476b,
f7e68337-8cca-ec11-a7b5-000d3a4b476b,
b1c14876-98ca-ec11-a7b5-000d3a4b476b,
6b68437c-98ca-ec11-a7b5-000d3a4b476b,
c00953b7-98ca-ec11-a7b5-000d3a4b476b,
fc8e9051-99ca-ec11-a7b5-000d3a4b476b,
c78f9051-99ca-ec11-a7b5-000d3a4b476b,
e03b8b57-99ca-ec11-a7b5-000d3a4b476b,
5e3c8b57-99ca-ec11-a7b5-000d3a4b476b,
f635c5c6-9aca-ec11-a7b5-000d3a4b476b,
1dae0c88-a2ca-ec11-a7b5-000d3a4b476b,
e888215d-a3ca-ec11-a7b5-000d3a4b476b,
91d01963-a3ca-ec11-a7b5-000d3a4b476b,
30e9a50f-a6ca-ec11-a7b5-000d3a4b476b,
5ae9a50f-a6ca-ec11-a7b5-000d3a4b476b,
5a2b9e15-a6ca-ec11-a7b5-000d3a4b476b,
992cbd9e-a6ca-ec11-a7b5-000d3a4b476b,
c5561be1-a6ca-ec11-a7b5-000d3a4b476b,
0163bfa3-a8ca-ec11-a7b5-000d3a4b476b,
d563bfa3-a8ca-ec11-a7b5-000d3a4b476b,
90a8b7a9-a8ca-ec11-a7b5-000d3a4b476b,
491af5c5-abca-ec11-a7b5-000d3a4b476b,
96d300e1-b7ca-ec11-a7b5-000d3a4b476b,
5712bc28-b8ca-ec11-a7b5-000d3a4b476b,
5efd00d2-b9ca-ec11-a7b5-000d3a4b476b,
744fc1d5-bbca-ec11-a7b5-000d3a4b476b,
35cd9eb3-c1ca-ec11-a7b5-000d3a4b476b,
8d7899b9-c1ca-ec11-a7b5-000d3a4b476b,
a97899b9-c1ca-ec11-a7b5-000d3a4b476b,
39814306-c2ca-ec11-a7b5-000d3a4b476b,
3b814306-c2ca-ec11-a7b5-000d3a4b476b,
3f814306-c2ca-ec11-a7b5-000d3a4b476b,
41814306-c2ca-ec11-a7b5-000d3a4b476b,
72814306-c2ca-ec11-a7b5-000d3a4b476b,
76814306-c2ca-ec11-a7b5-000d3a4b476b,
92814306-c2ca-ec11-a7b5-000d3a4b476b,
ba814306-c2ca-ec11-a7b5-000d3a4b476b,
ca814306-c2ca-ec11-a7b5-000d3a4b476b,
e9814306-c2ca-ec11-a7b5-000d3a4b476b,
fb814306-c2ca-ec11-a7b5-000d3a4b476b,
5f824306-c2ca-ec11-a7b5-000d3a4b476b,
82824306-c2ca-ec11-a7b5-000d3a4b476b,
84824306-c2ca-ec11-a7b5-000d3a4b476b,
94824306-c2ca-ec11-a7b5-000d3a4b476b,
aa824306-c2ca-ec11-a7b5-000d3a4b476b,
39834306-c2ca-ec11-a7b5-000d3a4b476b,
3c834306-c2ca-ec11-a7b5-000d3a4b476b,
50834306-c2ca-ec11-a7b5-000d3a4b476b,
cd834306-c2ca-ec11-a7b5-000d3a4b476b,
d0834306-c2ca-ec11-a7b5-000d3a4b476b,
da834306-c2ca-ec11-a7b5-000d3a4b476b,
0d844306-c2ca-ec11-a7b5-000d3a4b476b,
6e844306-c2ca-ec11-a7b5-000d3a4b476b,
95844306-c2ca-ec11-a7b5-000d3a4b476b,
e0844306-c2ca-ec11-a7b5-000d3a4b476b,
a92c3e0c-c2ca-ec11-a7b5-000d3a4b476b,
bd2c3e0c-c2ca-ec11-a7b5-000d3a4b476b,
d72c3e0c-c2ca-ec11-a7b5-000d3a4b476b,
352d3e0c-c2ca-ec11-a7b5-000d3a4b476b,
472d3e0c-c2ca-ec11-a7b5-000d3a4b476b,
622d3e0c-c2ca-ec11-a7b5-000d3a4b476b,
8a2d3e0c-c2ca-ec11-a7b5-000d3a4b476b,
ce2d3e0c-c2ca-ec11-a7b5-000d3a4b476b,
d92d3e0c-c2ca-ec11-a7b5-000d3a4b476b,
1f2e3e0c-c2ca-ec11-a7b5-000d3a4b476b,
262e3e0c-c2ca-ec11-a7b5-000d3a4b476b,
7e2e3e0c-c2ca-ec11-a7b5-000d3a4b476b,
8b2e3e0c-c2ca-ec11-a7b5-000d3a4b476b,
9f2e3e0c-c2ca-ec11-a7b5-000d3a4b476b,
c22e3e0c-c2ca-ec11-a7b5-000d3a4b476b,
0c2f3e0c-c2ca-ec11-a7b5-000d3a4b476b,
1d2f3e0c-c2ca-ec11-a7b5-000d3a4b476b,
3a2f3e0c-c2ca-ec11-a7b5-000d3a4b476b,
8c2f3e0c-c2ca-ec11-a7b5-000d3a4b476b,
912f3e0c-c2ca-ec11-a7b5-000d3a4b476b,
c12f3e0c-c2ca-ec11-a7b5-000d3a4b476b,
19303e0c-c2ca-ec11-a7b5-000d3a4b476b,
3c303e0c-c2ca-ec11-a7b5-000d3a4b476b,
57303e0c-c2ca-ec11-a7b5-000d3a4b476b,
85303e0c-c2ca-ec11-a7b5-000d3a4b476b,
8f303e0c-c2ca-ec11-a7b5-000d3a4b476b,
bf303e0c-c2ca-ec11-a7b5-000d3a4b476b,
d2303e0c-c2ca-ec11-a7b5-000d3a4b476b,
de303e0c-c2ca-ec11-a7b5-000d3a4b476b,
32313e0c-c2ca-ec11-a7b5-000d3a4b476b,
37313e0c-c2ca-ec11-a7b5-000d3a4b476b,
39313e0c-c2ca-ec11-a7b5-000d3a4b476b,
65313e0c-c2ca-ec11-a7b5-000d3a4b476b,
bb753612-c2ca-ec11-a7b5-000d3a4b476b,
c4753612-c2ca-ec11-a7b5-000d3a4b476b,
d2753612-c2ca-ec11-a7b5-000d3a4b476b,
02763612-c2ca-ec11-a7b5-000d3a4b476b,
06763612-c2ca-ec11-a7b5-000d3a4b476b,
08763612-c2ca-ec11-a7b5-000d3a4b476b,
0c763612-c2ca-ec11-a7b5-000d3a4b476b,
2d763612-c2ca-ec11-a7b5-000d3a4b476b,
55763612-c2ca-ec11-a7b5-000d3a4b476b,
5b763612-c2ca-ec11-a7b5-000d3a4b476b,
6a763612-c2ca-ec11-a7b5-000d3a4b476b,
6c763612-c2ca-ec11-a7b5-000d3a4b476b,
76763612-c2ca-ec11-a7b5-000d3a4b476b,
a1763612-c2ca-ec11-a7b5-000d3a4b476b,
a8763612-c2ca-ec11-a7b5-000d3a4b476b,
ab763612-c2ca-ec11-a7b5-000d3a4b476b,
eb763612-c2ca-ec11-a7b5-000d3a4b476b,
f3763612-c2ca-ec11-a7b5-000d3a4b476b,
04773612-c2ca-ec11-a7b5-000d3a4b476b,
14773612-c2ca-ec11-a7b5-000d3a4b476b,
3d773612-c2ca-ec11-a7b5-000d3a4b476b,
42773612-c2ca-ec11-a7b5-000d3a4b476b,
4c773612-c2ca-ec11-a7b5-000d3a4b476b,
5d773612-c2ca-ec11-a7b5-000d3a4b476b,
62773612-c2ca-ec11-a7b5-000d3a4b476b,
90773612-c2ca-ec11-a7b5-000d3a4b476b,
98773612-c2ca-ec11-a7b5-000d3a4b476b,
9c773612-c2ca-ec11-a7b5-000d3a4b476b,
b8773612-c2ca-ec11-a7b5-000d3a4b476b,
e2773612-c2ca-ec11-a7b5-000d3a4b476b,
e5773612-c2ca-ec11-a7b5-000d3a4b476b,
ee773612-c2ca-ec11-a7b5-000d3a4b476b,
fa773612-c2ca-ec11-a7b5-000d3a4b476b,
34783612-c2ca-ec11-a7b5-000d3a4b476b,
37783612-c2ca-ec11-a7b5-000d3a4b476b,
3a783612-c2ca-ec11-a7b5-000d3a4b476b,
43783612-c2ca-ec11-a7b5-000d3a4b476b,
5d783612-c2ca-ec11-a7b5-000d3a4b476b,
a6be2e18-c2ca-ec11-a7b5-000d3a4b476b,
aabe2e18-c2ca-ec11-a7b5-000d3a4b476b,
bebe2e18-c2ca-ec11-a7b5-000d3a4b476b,
c5be2e18-c2ca-ec11-a7b5-000d3a4b476b,
f5be2e18-c2ca-ec11-a7b5-000d3a4b476b,
05bf2e18-c2ca-ec11-a7b5-000d3a4b476b,
0bbf2e18-c2ca-ec11-a7b5-000d3a4b476b,
0ebf2e18-c2ca-ec11-a7b5-000d3a4b476b,
28bf2e18-c2ca-ec11-a7b5-000d3a4b476b,
3cbf2e18-c2ca-ec11-a7b5-000d3a4b476b,
58bf2e18-c2ca-ec11-a7b5-000d3a4b476b,
86bf2e18-c2ca-ec11-a7b5-000d3a4b476b,
9bbf2e18-c2ca-ec11-a7b5-000d3a4b476b,
9fbf2e18-c2ca-ec11-a7b5-000d3a4b476b,
b5bf2e18-c2ca-ec11-a7b5-000d3a4b476b,
bfbf2e18-c2ca-ec11-a7b5-000d3a4b476b,
d8bf2e18-c2ca-ec11-a7b5-000d3a4b476b,
f3bf2e18-c2ca-ec11-a7b5-000d3a4b476b,
09c02e18-c2ca-ec11-a7b5-000d3a4b476b,
12c02e18-c2ca-ec11-a7b5-000d3a4b476b,
2ac02e18-c2ca-ec11-a7b5-000d3a4b476b,
41c02e18-c2ca-ec11-a7b5-000d3a4b476b,
49c02e18-c2ca-ec11-a7b5-000d3a4b476b,
57c02e18-c2ca-ec11-a7b5-000d3a4b476b,
7ec02e18-c2ca-ec11-a7b5-000d3a4b476b,
93c02e18-c2ca-ec11-a7b5-000d3a4b476b,
96c02e18-c2ca-ec11-a7b5-000d3a4b476b,
afc02e18-c2ca-ec11-a7b5-000d3a4b476b,
b2c02e18-c2ca-ec11-a7b5-000d3a4b476b,
d1c02e18-c2ca-ec11-a7b5-000d3a4b476b,
e9c02e18-c2ca-ec11-a7b5-000d3a4b476b,
efc02e18-c2ca-ec11-a7b5-000d3a4b476b,
f7c02e18-c2ca-ec11-a7b5-000d3a4b476b,
08c12e18-c2ca-ec11-a7b5-000d3a4b476b,
24c12e18-c2ca-ec11-a7b5-000d3a4b476b,
3ec12e18-c2ca-ec11-a7b5-000d3a4b476b,
40c12e18-c2ca-ec11-a7b5-000d3a4b476b,
44c12e18-c2ca-ec11-a7b5-000d3a4b476b,
5dc12e18-c2ca-ec11-a7b5-000d3a4b476b,
70c12e18-c2ca-ec11-a7b5-000d3a4b476b,
a707271e-c2ca-ec11-a7b5-000d3a4b476b,
b407271e-c2ca-ec11-a7b5-000d3a4b476b,
ba07271e-c2ca-ec11-a7b5-000d3a4b476b,
c407271e-c2ca-ec11-a7b5-000d3a4b476b,
d707271e-c2ca-ec11-a7b5-000d3a4b476b,
f807271e-c2ca-ec11-a7b5-000d3a4b476b,
0a08271e-c2ca-ec11-a7b5-000d3a4b476b,
1208271e-c2ca-ec11-a7b5-000d3a4b476b,
2008271e-c2ca-ec11-a7b5-000d3a4b476b,
2908271e-c2ca-ec11-a7b5-000d3a4b476b,
4e08271e-c2ca-ec11-a7b5-000d3a4b476b,
5708271e-c2ca-ec11-a7b5-000d3a4b476b,
5f08271e-c2ca-ec11-a7b5-000d3a4b476b,
6208271e-c2ca-ec11-a7b5-000d3a4b476b,
7908271e-c2ca-ec11-a7b5-000d3a4b476b,
9908271e-c2ca-ec11-a7b5-000d3a4b476b,
9e08271e-c2ca-ec11-a7b5-000d3a4b476b,
c608271e-c2ca-ec11-a7b5-000d3a4b476b,
e208271e-c2ca-ec11-a7b5-000d3a4b476b,
e608271e-c2ca-ec11-a7b5-000d3a4b476b,
f708271e-c2ca-ec11-a7b5-000d3a4b476b,
fb08271e-c2ca-ec11-a7b5-000d3a4b476b,
2c09271e-c2ca-ec11-a7b5-000d3a4b476b,
2f09271e-c2ca-ec11-a7b5-000d3a4b476b,
3a09271e-c2ca-ec11-a7b5-000d3a4b476b,
5009271e-c2ca-ec11-a7b5-000d3a4b476b,
8509271e-c2ca-ec11-a7b5-000d3a4b476b,
9209271e-c2ca-ec11-a7b5-000d3a4b476b,
9b09271e-c2ca-ec11-a7b5-000d3a4b476b,
c709271e-c2ca-ec11-a7b5-000d3a4b476b,
ce09271e-c2ca-ec11-a7b5-000d3a4b476b,
df09271e-c2ca-ec11-a7b5-000d3a4b476b,
080a271e-c2ca-ec11-a7b5-000d3a4b476b,
0f0a271e-c2ca-ec11-a7b5-000d3a4b476b,
190a271e-c2ca-ec11-a7b5-000d3a4b476b,
3c0a271e-c2ca-ec11-a7b5-000d3a4b476b,
480a271e-c2ca-ec11-a7b5-000d3a4b476b,
c9501f24-c2ca-ec11-a7b5-000d3a4b476b,
dd501f24-c2ca-ec11-a7b5-000d3a4b476b,
e9501f24-c2ca-ec11-a7b5-000d3a4b476b,
c4d6345f-c2ca-ec11-a7b5-000d3a4b476b,
c6d6345f-c2ca-ec11-a7b5-000d3a4b476b,
c8d6345f-c2ca-ec11-a7b5-000d3a4b476b,
cad6345f-c2ca-ec11-a7b5-000d3a4b476b,
fad6345f-c2ca-ec11-a7b5-000d3a4b476b,
0a2a2d65-c2ca-ec11-a7b5-000d3a4b476b,
2f2a2d65-c2ca-ec11-a7b5-000d3a4b476b,
5c2a2d65-c2ca-ec11-a7b5-000d3a4b476b,
8a2a2d65-c2ca-ec11-a7b5-000d3a4b476b,
c82a2d65-c2ca-ec11-a7b5-000d3a4b476b,
da2a2d65-c2ca-ec11-a7b5-000d3a4b476b,
072b2d65-c2ca-ec11-a7b5-000d3a4b476b,
0e2b2d65-c2ca-ec11-a7b5-000d3a4b476b,
242b2d65-c2ca-ec11-a7b5-000d3a4b476b,
562b2d65-c2ca-ec11-a7b5-000d3a4b476b,
7a2b2d65-c2ca-ec11-a7b5-000d3a4b476b,
9b2b2d65-c2ca-ec11-a7b5-000d3a4b476b,
d22b2d65-c2ca-ec11-a7b5-000d3a4b476b,
fc2b2d65-c2ca-ec11-a7b5-000d3a4b476b,
282c2d65-c2ca-ec11-a7b5-000d3a4b476b,
362c2d65-c2ca-ec11-a7b5-000d3a4b476b,
542c2d65-c2ca-ec11-a7b5-000d3a4b476b,
622c2d65-c2ca-ec11-a7b5-000d3a4b476b,
6f2c2d65-c2ca-ec11-a7b5-000d3a4b476b,
732c2d65-c2ca-ec11-a7b5-000d3a4b476b,
812c2d65-c2ca-ec11-a7b5-000d3a4b476b,
a92c2d65-c2ca-ec11-a7b5-000d3a4b476b,
bc2c2d65-c2ca-ec11-a7b5-000d3a4b476b,
d12c2d65-c2ca-ec11-a7b5-000d3a4b476b,
d42c2d65-c2ca-ec11-a7b5-000d3a4b476b,
e62c2d65-c2ca-ec11-a7b5-000d3a4b476b,
f62c2d65-c2ca-ec11-a7b5-000d3a4b476b,
0d2d2d65-c2ca-ec11-a7b5-000d3a4b476b,
1f2d2d65-c2ca-ec11-a7b5-000d3a4b476b,
45a82c6b-c2ca-ec11-a7b5-000d3a4b476b,
5da82c6b-c2ca-ec11-a7b5-000d3a4b476b,
6fa82c6b-c2ca-ec11-a7b5-000d3a4b476b,
8ca82c6b-c2ca-ec11-a7b5-000d3a4b476b,
b5a82c6b-c2ca-ec11-a7b5-000d3a4b476b,
d9a82c6b-c2ca-ec11-a7b5-000d3a4b476b,
e3a82c6b-c2ca-ec11-a7b5-000d3a4b476b,
18a92c6b-c2ca-ec11-a7b5-000d3a4b476b,
39a92c6b-c2ca-ec11-a7b5-000d3a4b476b,
56a92c6b-c2ca-ec11-a7b5-000d3a4b476b,
8ba92c6b-c2ca-ec11-a7b5-000d3a4b476b,
c8a92c6b-c2ca-ec11-a7b5-000d3a4b476b,
dfa92c6b-c2ca-ec11-a7b5-000d3a4b476b,
faa92c6b-c2ca-ec11-a7b5-000d3a4b476b,
4caa2c6b-c2ca-ec11-a7b5-000d3a4b476b,
81aa2c6b-c2ca-ec11-a7b5-000d3a4b476b,
afaa2c6b-c2ca-ec11-a7b5-000d3a4b476b,
eaaa2c6b-c2ca-ec11-a7b5-000d3a4b476b,
02ab2c6b-c2ca-ec11-a7b5-000d3a4b476b,
1bab2c6b-c2ca-ec11-a7b5-000d3a4b476b,
abf82471-c2ca-ec11-a7b5-000d3a4b476b,
e7f82471-c2ca-ec11-a7b5-000d3a4b476b,
eef82471-c2ca-ec11-a7b5-000d3a4b476b,
05f92471-c2ca-ec11-a7b5-000d3a4b476b,
21f92471-c2ca-ec11-a7b5-000d3a4b476b,
32f92471-c2ca-ec11-a7b5-000d3a4b476b,
38f92471-c2ca-ec11-a7b5-000d3a4b476b,
57f92471-c2ca-ec11-a7b5-000d3a4b476b,
a7f92471-c2ca-ec11-a7b5-000d3a4b476b,
b1f92471-c2ca-ec11-a7b5-000d3a4b476b,
eef92471-c2ca-ec11-a7b5-000d3a4b476b,
0efa2471-c2ca-ec11-a7b5-000d3a4b476b,
29fa2471-c2ca-ec11-a7b5-000d3a4b476b,
3bfa2471-c2ca-ec11-a7b5-000d3a4b476b,
89fa2471-c2ca-ec11-a7b5-000d3a4b476b,
9efa2471-c2ca-ec11-a7b5-000d3a4b476b,
10fb2471-c2ca-ec11-a7b5-000d3a4b476b,
34fb2471-c2ca-ec11-a7b5-000d3a4b476b,
87fb2471-c2ca-ec11-a7b5-000d3a4b476b,
91fb2471-c2ca-ec11-a7b5-000d3a4b476b,
b9fb2471-c2ca-ec11-a7b5-000d3a4b476b,
c8fb2471-c2ca-ec11-a7b5-000d3a4b476b,
eafb2471-c2ca-ec11-a7b5-000d3a4b476b,
26fc2471-c2ca-ec11-a7b5-000d3a4b476b,
49fc2471-c2ca-ec11-a7b5-000d3a4b476b,
3fb01f77-c2ca-ec11-a7b5-000d3a4b476b,
41b01f77-c2ca-ec11-a7b5-000d3a4b476b,
62b01f77-c2ca-ec11-a7b5-000d3a4b476b,
74b01f77-c2ca-ec11-a7b5-000d3a4b476b,
83b01f77-c2ca-ec11-a7b5-000d3a4b476b,
99b01f77-c2ca-ec11-a7b5-000d3a4b476b,
abb01f77-c2ca-ec11-a7b5-000d3a4b476b,
bcb01f77-c2ca-ec11-a7b5-000d3a4b476b,
ccb01f77-c2ca-ec11-a7b5-000d3a4b476b,
d5b01f77-c2ca-ec11-a7b5-000d3a4b476b,
ffb01f77-c2ca-ec11-a7b5-000d3a4b476b,
0eb11f77-c2ca-ec11-a7b5-000d3a4b476b,
15b11f77-c2ca-ec11-a7b5-000d3a4b476b,
2bb11f77-c2ca-ec11-a7b5-000d3a4b476b,
41b11f77-c2ca-ec11-a7b5-000d3a4b476b,
49b11f77-c2ca-ec11-a7b5-000d3a4b476b,
57b11f77-c2ca-ec11-a7b5-000d3a4b476b,
60b11f77-c2ca-ec11-a7b5-000d3a4b476b,
7ab11f77-c2ca-ec11-a7b5-000d3a4b476b,
95b11f77-c2ca-ec11-a7b5-000d3a4b476b,
bfb11f77-c2ca-ec11-a7b5-000d3a4b476b,
ddb11f77-c2ca-ec11-a7b5-000d3a4b476b,
0eb21f77-c2ca-ec11-a7b5-000d3a4b476b,
33b21f77-c2ca-ec11-a7b5-000d3a4b476b,
50b21f77-c2ca-ec11-a7b5-000d3a4b476b,
79b21f77-c2ca-ec11-a7b5-000d3a4b476b,
8bb21f77-c2ca-ec11-a7b5-000d3a4b476b,
7b621a7d-c2ca-ec11-a7b5-000d3a4b476b,
ac621a7d-c2ca-ec11-a7b5-000d3a4b476b,
c8621a7d-c2ca-ec11-a7b5-000d3a4b476b,
e3621a7d-c2ca-ec11-a7b5-000d3a4b476b,
ef621a7d-c2ca-ec11-a7b5-000d3a4b476b,
27631a7d-c2ca-ec11-a7b5-000d3a4b476b,
54631a7d-c2ca-ec11-a7b5-000d3a4b476b,
65631a7d-c2ca-ec11-a7b5-000d3a4b476b,
9d631a7d-c2ca-ec11-a7b5-000d3a4b476b,
ea631a7d-c2ca-ec11-a7b5-000d3a4b476b,
f0631a7d-c2ca-ec11-a7b5-000d3a4b476b,
03641a7d-c2ca-ec11-a7b5-000d3a4b476b,
11641a7d-c2ca-ec11-a7b5-000d3a4b476b,
21641a7d-c2ca-ec11-a7b5-000d3a4b476b,
65641a7d-c2ca-ec11-a7b5-000d3a4b476b,
70641a7d-c2ca-ec11-a7b5-000d3a4b476b,
80641a7d-c2ca-ec11-a7b5-000d3a4b476b,
b3641a7d-c2ca-ec11-a7b5-000d3a4b476b,
e4641a7d-c2ca-ec11-a7b5-000d3a4b476b,
02651a7d-c2ca-ec11-a7b5-000d3a4b476b,
05651a7d-c2ca-ec11-a7b5-000d3a4b476b,
20651a7d-c2ca-ec11-a7b5-000d3a4b476b,
2a651a7d-c2ca-ec11-a7b5-000d3a4b476b,
6a651a7d-c2ca-ec11-a7b5-000d3a4b476b,
79651a7d-c2ca-ec11-a7b5-000d3a4b476b,
80651a7d-c2ca-ec11-a7b5-000d3a4b476b,
96651a7d-c2ca-ec11-a7b5-000d3a4b476b,
b3651a7d-c2ca-ec11-a7b5-000d3a4b476b,
f8651a7d-c2ca-ec11-a7b5-000d3a4b476b,
ff651a7d-c2ca-ec11-a7b5-000d3a4b476b,
06661a7d-c2ca-ec11-a7b5-000d3a4b476b,
29661a7d-c2ca-ec11-a7b5-000d3a4b476b,
49661a7d-c2ca-ec11-a7b5-000d3a4b476b,
94661a7d-c2ca-ec11-a7b5-000d3a4b476b,
60b11283-c2ca-ec11-a7b5-000d3a4b476b,
6ab11283-c2ca-ec11-a7b5-000d3a4b476b,
e1b11283-c2ca-ec11-a7b5-000d3a4b476b,
ecb11283-c2ca-ec11-a7b5-000d3a4b476b,
06b21283-c2ca-ec11-a7b5-000d3a4b476b,
1ab21283-c2ca-ec11-a7b5-000d3a4b476b,
6bb21283-c2ca-ec11-a7b5-000d3a4b476b,
77b21283-c2ca-ec11-a7b5-000d3a4b476b,
92b21283-c2ca-ec11-a7b5-000d3a4b476b,
a7b21283-c2ca-ec11-a7b5-000d3a4b476b,
fbb21283-c2ca-ec11-a7b5-000d3a4b476b,
12b31283-c2ca-ec11-a7b5-000d3a4b476b,
16b31283-c2ca-ec11-a7b5-000d3a4b476b,
18b31283-c2ca-ec11-a7b5-000d3a4b476b,
43b31283-c2ca-ec11-a7b5-000d3a4b476b,
5cb31283-c2ca-ec11-a7b5-000d3a4b476b,
6eb31283-c2ca-ec11-a7b5-000d3a4b476b,
9ab31283-c2ca-ec11-a7b5-000d3a4b476b,
adb31283-c2ca-ec11-a7b5-000d3a4b476b,
edb31283-c2ca-ec11-a7b5-000d3a4b476b,
14b41283-c2ca-ec11-a7b5-000d3a4b476b,
33b41283-c2ca-ec11-a7b5-000d3a4b476b,
3fb41283-c2ca-ec11-a7b5-000d3a4b476b,
54b41283-c2ca-ec11-a7b5-000d3a4b476b,
63b41283-c2ca-ec11-a7b5-000d3a4b476b,
57600d89-c2ca-ec11-a7b5-000d3a4b476b,
cc600d89-c2ca-ec11-a7b5-000d3a4b476b,
73eb04ca-c2ca-ec11-a7b5-000d3a4b476b,
5650fdcf-c2ca-ec11-a7b5-000d3a4b476b,
7d53fdcf-c2ca-ec11-a7b5-000d3a4b476b,
5b98f5d5-c2ca-ec11-a7b5-000d3a4b476b,
e599f5d5-c2ca-ec11-a7b5-000d3a4b476b,
d99af5d5-c2ca-ec11-a7b5-000d3a4b476b,
c6528222-c5ca-ec11-a7b5-000d3a4b476b,
37538222-c5ca-ec11-a7b5-000d3a4b476b,
6f538222-c5ca-ec11-a7b5-000d3a4b476b,
7c538222-c5ca-ec11-a7b5-000d3a4b476b,
94538222-c5ca-ec11-a7b5-000d3a4b476b,
f1538222-c5ca-ec11-a7b5-000d3a4b476b,
2f548222-c5ca-ec11-a7b5-000d3a4b476b,
d19a7a28-c5ca-ec11-a7b5-000d3a4b476b,
ea9a7a28-c5ca-ec11-a7b5-000d3a4b476b,
f99b7a28-c5ca-ec11-a7b5-000d3a4b476b,
fd9b7a28-c5ca-ec11-a7b5-000d3a4b476b,
2c9c7a28-c5ca-ec11-a7b5-000d3a4b476b,
089e7a28-c5ca-ec11-a7b5-000d3a4b476b,
c69e7a28-c5ca-ec11-a7b5-000d3a4b476b,
afe3722e-c5ca-ec11-a7b5-000d3a4b476b,
dee3722e-c5ca-ec11-a7b5-000d3a4b476b,
4fe4722e-c5ca-ec11-a7b5-000d3a4b476b,
7fe4722e-c5ca-ec11-a7b5-000d3a4b476b,
9ee4722e-c5ca-ec11-a7b5-000d3a4b476b,
62e5722e-c5ca-ec11-a7b5-000d3a4b476b,
83e5722e-c5ca-ec11-a7b5-000d3a4b476b,
05e6722e-c5ca-ec11-a7b5-000d3a4b476b,
a3e6722e-c5ca-ec11-a7b5-000d3a4b476b,
fee6722e-c5ca-ec11-a7b5-000d3a4b476b,
46e7722e-c5ca-ec11-a7b5-000d3a4b476b,
53e7722e-c5ca-ec11-a7b5-000d3a4b476b,
62e7722e-c5ca-ec11-a7b5-000d3a4b476b,
08916d34-c5ca-ec11-a7b5-000d3a4b476b,
36916d34-c5ca-ec11-a7b5-000d3a4b476b,
39916d34-c5ca-ec11-a7b5-000d3a4b476b,
5b916d34-c5ca-ec11-a7b5-000d3a4b476b,
8a916d34-c5ca-ec11-a7b5-000d3a4b476b,
a1916d34-c5ca-ec11-a7b5-000d3a4b476b,
c7916d34-c5ca-ec11-a7b5-000d3a4b476b,
d4916d34-c5ca-ec11-a7b5-000d3a4b476b,
e8916d34-c5ca-ec11-a7b5-000d3a4b476b,
ea916d34-c5ca-ec11-a7b5-000d3a4b476b,
f3916d34-c5ca-ec11-a7b5-000d3a4b476b,
35926d34-c5ca-ec11-a7b5-000d3a4b476b,
44926d34-c5ca-ec11-a7b5-000d3a4b476b,
50926d34-c5ca-ec11-a7b5-000d3a4b476b,
98926d34-c5ca-ec11-a7b5-000d3a4b476b,
ab926d34-c5ca-ec11-a7b5-000d3a4b476b,
d1926d34-c5ca-ec11-a7b5-000d3a4b476b,
00936d34-c5ca-ec11-a7b5-000d3a4b476b,
1f936d34-c5ca-ec11-a7b5-000d3a4b476b,
49936d34-c5ca-ec11-a7b5-000d3a4b476b,
60936d34-c5ca-ec11-a7b5-000d3a4b476b,
78936d34-c5ca-ec11-a7b5-000d3a4b476b,
91936d34-c5ca-ec11-a7b5-000d3a4b476b,
d3936d34-c5ca-ec11-a7b5-000d3a4b476b,
e7936d34-c5ca-ec11-a7b5-000d3a4b476b,
f3936d34-c5ca-ec11-a7b5-000d3a4b476b,
14946d34-c5ca-ec11-a7b5-000d3a4b476b,
27946d34-c5ca-ec11-a7b5-000d3a4b476b,
52946d34-c5ca-ec11-a7b5-000d3a4b476b,
68946d34-c5ca-ec11-a7b5-000d3a4b476b,
84946d34-c5ca-ec11-a7b5-000d3a4b476b,
a0946d34-c5ca-ec11-a7b5-000d3a4b476b,
88d7653a-c5ca-ec11-a7b5-000d3a4b476b,
c3d7653a-c5ca-ec11-a7b5-000d3a4b476b,
d4d7653a-c5ca-ec11-a7b5-000d3a4b476b,
efd7653a-c5ca-ec11-a7b5-000d3a4b476b,
1cd8653a-c5ca-ec11-a7b5-000d3a4b476b,
4dd8653a-c5ca-ec11-a7b5-000d3a4b476b,
8dd8653a-c5ca-ec11-a7b5-000d3a4b476b,
fcd8653a-c5ca-ec11-a7b5-000d3a4b476b,
07d9653a-c5ca-ec11-a7b5-000d3a4b476b,
81d9653a-c5ca-ec11-a7b5-000d3a4b476b,
9cd9653a-c5ca-ec11-a7b5-000d3a4b476b,
d3d9653a-c5ca-ec11-a7b5-000d3a4b476b,
ded9653a-c5ca-ec11-a7b5-000d3a4b476b,
c5da653a-c5ca-ec11-a7b5-000d3a4b476b,
64db653a-c5ca-ec11-a7b5-000d3a4b476b,
1d215e40-c5ca-ec11-a7b5-000d3a4b476b,
43215e40-c5ca-ec11-a7b5-000d3a4b476b,
06225e40-c5ca-ec11-a7b5-000d3a4b476b,
49225e40-c5ca-ec11-a7b5-000d3a4b476b,
13235e40-c5ca-ec11-a7b5-000d3a4b476b,
dc5f7914-ccca-ec11-a7b5-000d3a4b476b,
e0b56259-ccca-ec11-a7b5-000d3a4b476b,
9c54cca9-ccca-ec11-a7b5-000d3a4b476b,
f493c4af-ccca-ec11-a7b5-000d3a4b476b,
647569b2-cfca-ec11-a7b5-000d3a4b476b,
967569b2-cfca-ec11-a7b5-000d3a4b476b,
80bc61b8-cfca-ec11-a7b5-000d3a4b476b,
89be61b8-cfca-ec11-a7b5-000d3a4b476b,
d0be61b8-cfca-ec11-a7b5-000d3a4b476b,
90bf61b8-cfca-ec11-a7b5-000d3a4b476b,
a11b5abe-cfca-ec11-a7b5-000d3a4b476b,
151c5abe-cfca-ec11-a7b5-000d3a4b476b,
d91c5abe-cfca-ec11-a7b5-000d3a4b476b,
371d5abe-cfca-ec11-a7b5-000d3a4b476b,
901d5abe-cfca-ec11-a7b5-000d3a4b476b,
621e5abe-cfca-ec11-a7b5-000d3a4b476b,
6f1e5abe-cfca-ec11-a7b5-000d3a4b476b,
9a4e52c4-cfca-ec11-a7b5-000d3a4b476b,
054f52c4-cfca-ec11-a7b5-000d3a4b476b,
094f52c4-cfca-ec11-a7b5-000d3a4b476b,
4d4f52c4-cfca-ec11-a7b5-000d3a4b476b,
bf4f52c4-cfca-ec11-a7b5-000d3a4b476b,
2e5052c4-cfca-ec11-a7b5-000d3a4b476b,
8a5052c4-cfca-ec11-a7b5-000d3a4b476b,
cb5052c4-cfca-ec11-a7b5-000d3a4b476b,
88f16a3f-dbcb-ec11-a7b5-000d3a4b476b,
2a430684-8eca-ec11-a7b5-000d3a4b4cee,
0f8afe89-8eca-ec11-a7b5-000d3a4b4cee,
c9548853-91ca-ec11-a7b5-000d3a4b4cee,
1a486b6e-98ca-ec11-a7b5-000d3a4b4cee,
42392905-99ca-ec11-a7b5-000d3a4b4cee,
003a2905-99ca-ec11-a7b5-000d3a4b4cee,
80271c11-99ca-ec11-a7b5-000d3a4b4cee,
9654b122-9cca-ec11-a7b5-000d3a4b4cee,
bf19f30f-9eca-ec11-a7b5-000d3a4b4cee,
b1ff61e3-9eca-ec11-a7b5-000d3a4b4cee,
a989d0ca-a0ca-ec11-a7b5-000d3a4b4cee,
39022a6d-a4ca-ec11-a7b5-000d3a4b4cee,
fca02473-a4ca-ec11-a7b5-000d3a4b4cee,
bcfefc57-a8ca-ec11-a7b5-000d3a4b4cee,
5bafe908-b9ca-ec11-a7b5-000d3a4b4cee,
8e1bc3a7-baca-ec11-a7b5-000d3a4b4cee,
391a1f32-bbca-ec11-a7b5-000d3a4b4cee,
2843f16a-bcca-ec11-a7b5-000d3a4b4cee,
3744f16a-bcca-ec11-a7b5-000d3a4b4cee,
5644f16a-bcca-ec11-a7b5-000d3a4b4cee,
c9a8e970-bcca-ec11-a7b5-000d3a4b4cee,
73a9e970-bcca-ec11-a7b5-000d3a4b4cee,
a5a9e970-bcca-ec11-a7b5-000d3a4b4cee,
aaa9e970-bcca-ec11-a7b5-000d3a4b4cee,
43aae970-bcca-ec11-a7b5-000d3a4b4cee,
efaae970-bcca-ec11-a7b5-000d3a4b4cee,
97abe970-bcca-ec11-a7b5-000d3a4b4cee,
eaabe970-bcca-ec11-a7b5-000d3a4b4cee,
4fb6e676-bcca-ec11-a7b5-000d3a4b4cee,
54b6e676-bcca-ec11-a7b5-000d3a4b4cee,
c7b6e676-bcca-ec11-a7b5-000d3a4b4cee,
53b7e676-bcca-ec11-a7b5-000d3a4b4cee,
c4b7e676-bcca-ec11-a7b5-000d3a4b4cee,
feb7e676-bcca-ec11-a7b5-000d3a4b4cee,
a35ee17c-bcca-ec11-a7b5-000d3a4b4cee,
fa5ee17c-bcca-ec11-a7b5-000d3a4b4cee,
5e5fe17c-bcca-ec11-a7b5-000d3a4b4cee,
8e5fe17c-bcca-ec11-a7b5-000d3a4b4cee,
ab5fe17c-bcca-ec11-a7b5-000d3a4b4cee,
bf5fe17c-bcca-ec11-a7b5-000d3a4b4cee,
db5fe17c-bcca-ec11-a7b5-000d3a4b4cee,
5860e17c-bcca-ec11-a7b5-000d3a4b4cee,
e460e17c-bcca-ec11-a7b5-000d3a4b4cee,
3561e17c-bcca-ec11-a7b5-000d3a4b4cee,
4762e17c-bcca-ec11-a7b5-000d3a4b4cee,
29a6d982-bcca-ec11-a7b5-000d3a4b4cee,
39a7d982-bcca-ec11-a7b5-000d3a4b4cee,
52a7d982-bcca-ec11-a7b5-000d3a4b4cee,
f1a8d982-bcca-ec11-a7b5-000d3a4b4cee,
3ba9d982-bcca-ec11-a7b5-000d3a4b4cee,
5ea9d982-bcca-ec11-a7b5-000d3a4b4cee,
9e44f41e-bdca-ec11-a7b5-000d3a4b4cee,
a044f41e-bdca-ec11-a7b5-000d3a4b4cee,
b344f41e-bdca-ec11-a7b5-000d3a4b4cee,
d144f41e-bdca-ec11-a7b5-000d3a4b4cee,
1245f41e-bdca-ec11-a7b5-000d3a4b4cee,
1445f41e-bdca-ec11-a7b5-000d3a4b4cee,
1745f41e-bdca-ec11-a7b5-000d3a4b4cee,
2b45f41e-bdca-ec11-a7b5-000d3a4b4cee,
3c45f41e-bdca-ec11-a7b5-000d3a4b4cee,
8745f41e-bdca-ec11-a7b5-000d3a4b4cee,
8945f41e-bdca-ec11-a7b5-000d3a4b4cee,
9045f41e-bdca-ec11-a7b5-000d3a4b4cee,
9a45f41e-bdca-ec11-a7b5-000d3a4b4cee,
be45f41e-bdca-ec11-a7b5-000d3a4b4cee,
f845f41e-bdca-ec11-a7b5-000d3a4b4cee,
0046f41e-bdca-ec11-a7b5-000d3a4b4cee,
2a46f41e-bdca-ec11-a7b5-000d3a4b4cee,
6e46f41e-bdca-ec11-a7b5-000d3a4b4cee,
7346f41e-bdca-ec11-a7b5-000d3a4b4cee,
8246f41e-bdca-ec11-a7b5-000d3a4b4cee,
8746f41e-bdca-ec11-a7b5-000d3a4b4cee,
a846f41e-bdca-ec11-a7b5-000d3a4b4cee,
e846f41e-bdca-ec11-a7b5-000d3a4b4cee,
ea46f41e-bdca-ec11-a7b5-000d3a4b4cee,
ef46f41e-bdca-ec11-a7b5-000d3a4b4cee,
f646f41e-bdca-ec11-a7b5-000d3a4b4cee,
2147f41e-bdca-ec11-a7b5-000d3a4b4cee,
5b47f41e-bdca-ec11-a7b5-000d3a4b4cee,
6747f41e-bdca-ec11-a7b5-000d3a4b4cee,
6c47f41e-bdca-ec11-a7b5-000d3a4b4cee,
8247f41e-bdca-ec11-a7b5-000d3a4b4cee,
d247f41e-bdca-ec11-a7b5-000d3a4b4cee,
d647f41e-bdca-ec11-a7b5-000d3a4b4cee,
fa47f41e-bdca-ec11-a7b5-000d3a4b4cee,
4148f41e-bdca-ec11-a7b5-000d3a4b4cee,
4e48f41e-bdca-ec11-a7b5-000d3a4b4cee,
5948f41e-bdca-ec11-a7b5-000d3a4b4cee,
6a48f41e-bdca-ec11-a7b5-000d3a4b4cee,
9848f41e-bdca-ec11-a7b5-000d3a4b4cee,
9b48f41e-bdca-ec11-a7b5-000d3a4b4cee,
5bedee24-bdca-ec11-a7b5-000d3a4b4cee,
80edee24-bdca-ec11-a7b5-000d3a4b4cee,
97edee24-bdca-ec11-a7b5-000d3a4b4cee,
9aedee24-bdca-ec11-a7b5-000d3a4b4cee,
aaedee24-bdca-ec11-a7b5-000d3a4b4cee,
05eeee24-bdca-ec11-a7b5-000d3a4b4cee,
11eeee24-bdca-ec11-a7b5-000d3a4b4cee,
23eeee24-bdca-ec11-a7b5-000d3a4b4cee,
32eeee24-bdca-ec11-a7b5-000d3a4b4cee,
5deeee24-bdca-ec11-a7b5-000d3a4b4cee,
75eeee24-bdca-ec11-a7b5-000d3a4b4cee,
7ceeee24-bdca-ec11-a7b5-000d3a4b4cee,
9aeeee24-bdca-ec11-a7b5-000d3a4b4cee,
b9eeee24-bdca-ec11-a7b5-000d3a4b4cee,
d8eeee24-bdca-ec11-a7b5-000d3a4b4cee,
f7eeee24-bdca-ec11-a7b5-000d3a4b4cee,
1eefee24-bdca-ec11-a7b5-000d3a4b4cee,
2defee24-bdca-ec11-a7b5-000d3a4b4cee,
06f0ee24-bdca-ec11-a7b5-000d3a4b4cee,
1ef0ee24-bdca-ec11-a7b5-000d3a4b4cee,
2cf0ee24-bdca-ec11-a7b5-000d3a4b4cee,
3ff0ee24-bdca-ec11-a7b5-000d3a4b4cee,
fb33e72a-bdca-ec11-a7b5-000d3a4b4cee,
0d34e72a-bdca-ec11-a7b5-000d3a4b4cee,
2f34e72a-bdca-ec11-a7b5-000d3a4b4cee,
6734e72a-bdca-ec11-a7b5-000d3a4b4cee,
a134e72a-bdca-ec11-a7b5-000d3a4b4cee,
ae34e72a-bdca-ec11-a7b5-000d3a4b4cee,
c534e72a-bdca-ec11-a7b5-000d3a4b4cee,
d134e72a-bdca-ec11-a7b5-000d3a4b4cee,
e534e72a-bdca-ec11-a7b5-000d3a4b4cee,
1a35e72a-bdca-ec11-a7b5-000d3a4b4cee,
2f35e72a-bdca-ec11-a7b5-000d3a4b4cee,
3335e72a-bdca-ec11-a7b5-000d3a4b4cee,
5435e72a-bdca-ec11-a7b5-000d3a4b4cee,
6835e72a-bdca-ec11-a7b5-000d3a4b4cee,
8735e72a-bdca-ec11-a7b5-000d3a4b4cee,
9735e72a-bdca-ec11-a7b5-000d3a4b4cee,
af35e72a-bdca-ec11-a7b5-000d3a4b4cee,
b835e72a-bdca-ec11-a7b5-000d3a4b4cee,
e335e72a-bdca-ec11-a7b5-000d3a4b4cee,
fe35e72a-bdca-ec11-a7b5-000d3a4b4cee,
0136e72a-bdca-ec11-a7b5-000d3a4b4cee,
2a36e72a-bdca-ec11-a7b5-000d3a4b4cee,
5036e72a-bdca-ec11-a7b5-000d3a4b4cee,
6836e72a-bdca-ec11-a7b5-000d3a4b4cee,
6b36e72a-bdca-ec11-a7b5-000d3a4b4cee,
7936e72a-bdca-ec11-a7b5-000d3a4b4cee,
9236e72a-bdca-ec11-a7b5-000d3a4b4cee,
ac36e72a-bdca-ec11-a7b5-000d3a4b4cee,
c936e72a-bdca-ec11-a7b5-000d3a4b4cee,
cc36e72a-bdca-ec11-a7b5-000d3a4b4cee,
d236e72a-bdca-ec11-a7b5-000d3a4b4cee,
0f37e72a-bdca-ec11-a7b5-000d3a4b4cee,
2537e72a-bdca-ec11-a7b5-000d3a4b4cee,
2737e72a-bdca-ec11-a7b5-000d3a4b4cee,
3b37e72a-bdca-ec11-a7b5-000d3a4b4cee,
6d37e72a-bdca-ec11-a7b5-000d3a4b4cee,
8337e72a-bdca-ec11-a7b5-000d3a4b4cee,
8937e72a-bdca-ec11-a7b5-000d3a4b4cee,
cc37e72a-bdca-ec11-a7b5-000d3a4b4cee,
83dde130-bdca-ec11-a7b5-000d3a4b4cee,
86dde130-bdca-ec11-a7b5-000d3a4b4cee,
96dde130-bdca-ec11-a7b5-000d3a4b4cee,
aadde130-bdca-ec11-a7b5-000d3a4b4cee,
b7dde130-bdca-ec11-a7b5-000d3a4b4cee,
e0dde130-bdca-ec11-a7b5-000d3a4b4cee,
efdde130-bdca-ec11-a7b5-000d3a4b4cee,
f1dde130-bdca-ec11-a7b5-000d3a4b4cee,
fddde130-bdca-ec11-a7b5-000d3a4b4cee,
04dee130-bdca-ec11-a7b5-000d3a4b4cee,
5cdee130-bdca-ec11-a7b5-000d3a4b4cee,
64dee130-bdca-ec11-a7b5-000d3a4b4cee,
6ddee130-bdca-ec11-a7b5-000d3a4b4cee,
c5dee130-bdca-ec11-a7b5-000d3a4b4cee,
c8dee130-bdca-ec11-a7b5-000d3a4b4cee,
dbdee130-bdca-ec11-a7b5-000d3a4b4cee,
3adfe130-bdca-ec11-a7b5-000d3a4b4cee,
73dfe130-bdca-ec11-a7b5-000d3a4b4cee,
76dfe130-bdca-ec11-a7b5-000d3a4b4cee,
88dfe130-bdca-ec11-a7b5-000d3a4b4cee,
ccdfe130-bdca-ec11-a7b5-000d3a4b4cee,
d0dfe130-bdca-ec11-a7b5-000d3a4b4cee,
f6dfe130-bdca-ec11-a7b5-000d3a4b4cee,
2ce0e130-bdca-ec11-a7b5-000d3a4b4cee,
32e0e130-bdca-ec11-a7b5-000d3a4b4cee,
39e0e130-bdca-ec11-a7b5-000d3a4b4cee,
51e0e130-bdca-ec11-a7b5-000d3a4b4cee,
90e0e130-bdca-ec11-a7b5-000d3a4b4cee,
5d24da36-bdca-ec11-a7b5-000d3a4b4cee,
7c24da36-bdca-ec11-a7b5-000d3a4b4cee,
9124da36-bdca-ec11-a7b5-000d3a4b4cee,
b224da36-bdca-ec11-a7b5-000d3a4b4cee,
c524da36-bdca-ec11-a7b5-000d3a4b4cee,
d624da36-bdca-ec11-a7b5-000d3a4b4cee,
e124da36-bdca-ec11-a7b5-000d3a4b4cee,
fb24da36-bdca-ec11-a7b5-000d3a4b4cee,
1925da36-bdca-ec11-a7b5-000d3a4b4cee,
3425da36-bdca-ec11-a7b5-000d3a4b4cee,
4625da36-bdca-ec11-a7b5-000d3a4b4cee,
5a25da36-bdca-ec11-a7b5-000d3a4b4cee,
7f25da36-bdca-ec11-a7b5-000d3a4b4cee,
9e25da36-bdca-ec11-a7b5-000d3a4b4cee,
b025da36-bdca-ec11-a7b5-000d3a4b4cee,
bb25da36-bdca-ec11-a7b5-000d3a4b4cee,
c125da36-bdca-ec11-a7b5-000d3a4b4cee,
ef25da36-bdca-ec11-a7b5-000d3a4b4cee,
fc25da36-bdca-ec11-a7b5-000d3a4b4cee,
fe25da36-bdca-ec11-a7b5-000d3a4b4cee,
1026da36-bdca-ec11-a7b5-000d3a4b4cee,
4126da36-bdca-ec11-a7b5-000d3a4b4cee,
5526da36-bdca-ec11-a7b5-000d3a4b4cee,
5826da36-bdca-ec11-a7b5-000d3a4b4cee,
6726da36-bdca-ec11-a7b5-000d3a4b4cee,
9e26da36-bdca-ec11-a7b5-000d3a4b4cee,
a126da36-bdca-ec11-a7b5-000d3a4b4cee,
e926da36-bdca-ec11-a7b5-000d3a4b4cee,
f026da36-bdca-ec11-a7b5-000d3a4b4cee,
f726da36-bdca-ec11-a7b5-000d3a4b4cee,
3027da36-bdca-ec11-a7b5-000d3a4b4cee,
4227da36-bdca-ec11-a7b5-000d3a4b4cee,
4327da36-bdca-ec11-a7b5-000d3a4b4cee,
7627da36-bdca-ec11-a7b5-000d3a4b4cee,
7c27da36-bdca-ec11-a7b5-000d3a4b4cee,
8727da36-bdca-ec11-a7b5-000d3a4b4cee,
b727da36-bdca-ec11-a7b5-000d3a4b4cee,
c827da36-bdca-ec11-a7b5-000d3a4b4cee,
d027da36-bdca-ec11-a7b5-000d3a4b4cee,
136bd23c-bdca-ec11-a7b5-000d3a4b4cee,
446bd23c-bdca-ec11-a7b5-000d3a4b4cee,
4f6bd23c-bdca-ec11-a7b5-000d3a4b4cee,
7b6bd23c-bdca-ec11-a7b5-000d3a4b4cee,
a6908386-beca-ec11-a7b5-000d3a4b4cee,
a8908386-beca-ec11-a7b5-000d3a4b4cee,
aa908386-beca-ec11-a7b5-000d3a4b4cee,
d0908386-beca-ec11-a7b5-000d3a4b4cee,
f2908386-beca-ec11-a7b5-000d3a4b4cee,
f8908386-beca-ec11-a7b5-000d3a4b4cee,
04918386-beca-ec11-a7b5-000d3a4b4cee,
1d918386-beca-ec11-a7b5-000d3a4b4cee,
30918386-beca-ec11-a7b5-000d3a4b4cee,
35918386-beca-ec11-a7b5-000d3a4b4cee,
55918386-beca-ec11-a7b5-000d3a4b4cee,
6d918386-beca-ec11-a7b5-000d3a4b4cee,
80918386-beca-ec11-a7b5-000d3a4b4cee,
84918386-beca-ec11-a7b5-000d3a4b4cee,
93918386-beca-ec11-a7b5-000d3a4b4cee,
a9918386-beca-ec11-a7b5-000d3a4b4cee,
c0918386-beca-ec11-a7b5-000d3a4b4cee,
c8918386-beca-ec11-a7b5-000d3a4b4cee,
d7918386-beca-ec11-a7b5-000d3a4b4cee,
ffd77b8c-beca-ec11-a7b5-000d3a4b4cee,
04d87b8c-beca-ec11-a7b5-000d3a4b4cee,
1cd87b8c-beca-ec11-a7b5-000d3a4b4cee,
35d87b8c-beca-ec11-a7b5-000d3a4b4cee,
4ed87b8c-beca-ec11-a7b5-000d3a4b4cee,
51d87b8c-beca-ec11-a7b5-000d3a4b4cee,
64d87b8c-beca-ec11-a7b5-000d3a4b4cee,
9ed87b8c-beca-ec11-a7b5-000d3a4b4cee,
a1d87b8c-beca-ec11-a7b5-000d3a4b4cee,
b1d87b8c-beca-ec11-a7b5-000d3a4b4cee,
b6d87b8c-beca-ec11-a7b5-000d3a4b4cee,
d5d87b8c-beca-ec11-a7b5-000d3a4b4cee,
f1d87b8c-beca-ec11-a7b5-000d3a4b4cee,
03d97b8c-beca-ec11-a7b5-000d3a4b4cee,
1bd97b8c-beca-ec11-a7b5-000d3a4b4cee,
45d97b8c-beca-ec11-a7b5-000d3a4b4cee,
50d97b8c-beca-ec11-a7b5-000d3a4b4cee,
61d97b8c-beca-ec11-a7b5-000d3a4b4cee,
68d97b8c-beca-ec11-a7b5-000d3a4b4cee,
8ed97b8c-beca-ec11-a7b5-000d3a4b4cee,
dbd97b8c-beca-ec11-a7b5-000d3a4b4cee,
29da7b8c-beca-ec11-a7b5-000d3a4b4cee,
a8e47892-beca-ec11-a7b5-000d3a4b4cee,
ebac43de-c3ca-ec11-a7b5-000d3a4b4cee,
0dfe38ea-c3ca-ec11-a7b5-000d3a4b4cee,
87059c34-c4ca-ec11-a7b5-000d3a4b4cee,
44494999-c5ca-ec11-a7b5-000d3a4b4cee,
75494999-c5ca-ec11-a7b5-000d3a4b4cee,
8c494999-c5ca-ec11-a7b5-000d3a4b4cee,
8f494999-c5ca-ec11-a7b5-000d3a4b4cee,
9c494999-c5ca-ec11-a7b5-000d3a4b4cee,
c2494999-c5ca-ec11-a7b5-000d3a4b4cee,
e0494999-c5ca-ec11-a7b5-000d3a4b4cee,
e2494999-c5ca-ec11-a7b5-000d3a4b4cee,
fb494999-c5ca-ec11-a7b5-000d3a4b4cee,
384a4999-c5ca-ec11-a7b5-000d3a4b4cee,
444a4999-c5ca-ec11-a7b5-000d3a4b4cee,
584a4999-c5ca-ec11-a7b5-000d3a4b4cee,
6c4a4999-c5ca-ec11-a7b5-000d3a4b4cee,
a54a4999-c5ca-ec11-a7b5-000d3a4b4cee,
a84a4999-c5ca-ec11-a7b5-000d3a4b4cee,
c94a4999-c5ca-ec11-a7b5-000d3a4b4cee,
cc4a4999-c5ca-ec11-a7b5-000d3a4b4cee,
fe4a4999-c5ca-ec11-a7b5-000d3a4b4cee,
234b4999-c5ca-ec11-a7b5-000d3a4b4cee,
3a4b4999-c5ca-ec11-a7b5-000d3a4b4cee,
ecab6d54-c7ca-ec11-a7b5-000d3a4b4cee,
c0a8c43d-c9ca-ec11-a7b5-000d3a4b4cee,
c2a8c43d-c9ca-ec11-a7b5-000d3a4b4cee,
caa8c43d-c9ca-ec11-a7b5-000d3a4b4cee,
d5a8c43d-c9ca-ec11-a7b5-000d3a4b4cee,
e2a8c43d-c9ca-ec11-a7b5-000d3a4b4cee,
3463c443-c9ca-ec11-a7b5-000d3a4b4cee,
4663c443-c9ca-ec11-a7b5-000d3a4b4cee,
7463c443-c9ca-ec11-a7b5-000d3a4b4cee,
8063c443-c9ca-ec11-a7b5-000d3a4b4cee,
ad63c443-c9ca-ec11-a7b5-000d3a4b4cee,
b563c443-c9ca-ec11-a7b5-000d3a4b4cee,
d463c443-c9ca-ec11-a7b5-000d3a4b4cee,
f063c443-c9ca-ec11-a7b5-000d3a4b4cee,
f363c443-c9ca-ec11-a7b5-000d3a4b4cee,
0b64c443-c9ca-ec11-a7b5-000d3a4b4cee,
2264c443-c9ca-ec11-a7b5-000d3a4b4cee,
3364c443-c9ca-ec11-a7b5-000d3a4b4cee,
3a64c443-c9ca-ec11-a7b5-000d3a4b4cee,
4864c443-c9ca-ec11-a7b5-000d3a4b4cee,
7364c443-c9ca-ec11-a7b5-000d3a4b4cee,
7764c443-c9ca-ec11-a7b5-000d3a4b4cee,
c464c443-c9ca-ec11-a7b5-000d3a4b4cee,
d864c443-c9ca-ec11-a7b5-000d3a4b4cee,
0965c443-c9ca-ec11-a7b5-000d3a4b4cee,
0c65c443-c9ca-ec11-a7b5-000d3a4b4cee,
3d65c443-c9ca-ec11-a7b5-000d3a4b4cee,
5365c443-c9ca-ec11-a7b5-000d3a4b4cee,
7d65c443-c9ca-ec11-a7b5-000d3a4b4cee,
9665c443-c9ca-ec11-a7b5-000d3a4b4cee,
c365c443-c9ca-ec11-a7b5-000d3a4b4cee,
e865c443-c9ca-ec11-a7b5-000d3a4b4cee,
0c66c443-c9ca-ec11-a7b5-000d3a4b4cee,
2d66c443-c9ca-ec11-a7b5-000d3a4b4cee,
54aabc49-c9ca-ec11-a7b5-000d3a4b4cee,
82aabc49-c9ca-ec11-a7b5-000d3a4b4cee,
b7aabc49-c9ca-ec11-a7b5-000d3a4b4cee,
ceaabc49-c9ca-ec11-a7b5-000d3a4b4cee,
d8aabc49-c9ca-ec11-a7b5-000d3a4b4cee,
efaabc49-c9ca-ec11-a7b5-000d3a4b4cee,
0aabbc49-c9ca-ec11-a7b5-000d3a4b4cee,
44abbc49-c9ca-ec11-a7b5-000d3a4b4cee,
55abbc49-c9ca-ec11-a7b5-000d3a4b4cee,
e873568b-cbca-ec11-a7b5-000d3a4b4cee,
d1b64e91-cbca-ec11-a7b5-000d3a4b4cee,
cd0f843b-cdca-ec11-a7b5-000d3a4b4cee,
2d10843b-cdca-ec11-a7b5-000d3a4b4cee,
08ba7e41-cdca-ec11-a7b5-000d3a4b4cee,
27ba7e41-cdca-ec11-a7b5-000d3a4b4cee,
91ba7e41-cdca-ec11-a7b5-000d3a4b4cee,
abba7e41-cdca-ec11-a7b5-000d3a4b4cee,
faba7e41-cdca-ec11-a7b5-000d3a4b4cee,
24bb7e41-cdca-ec11-a7b5-000d3a4b4cee,
5ebb7e41-cdca-ec11-a7b5-000d3a4b4cee,
e9fe7647-cdca-ec11-a7b5-000d3a4b4cee,
a4ff7647-cdca-ec11-a7b5-000d3a4b4cee,
40007747-cdca-ec11-a7b5-000d3a4b4cee,
61007747-cdca-ec11-a7b5-000d3a4b4cee,
056c8342-d0ca-ec11-a7b5-000d3a4b4cee,
136d8342-d0ca-ec11-a7b5-000d3a4b4cee,
4f6d8342-d0ca-ec11-a7b5-000d3a4b4cee,
a36d8342-d0ca-ec11-a7b5-000d3a4b4cee,
ee6d8342-d0ca-ec11-a7b5-000d3a4b4cee,
116e8342-d0ca-ec11-a7b5-000d3a4b4cee,
24788048-d0ca-ec11-a7b5-000d3a4b4cee,
a8887f84-d0ca-ec11-a7b5-000d3a4b4cee,
af887f84-d0ca-ec11-a7b5-000d3a4b4cee,
32897f84-d0ca-ec11-a7b5-000d3a4b4cee,
77897f84-d0ca-ec11-a7b5-000d3a4b4cee,
ac897f84-d0ca-ec11-a7b5-000d3a4b4cee,
c38a7f84-d0ca-ec11-a7b5-000d3a4b4cee,
d28a7f84-d0ca-ec11-a7b5-000d3a4b4cee,
228b7f84-d0ca-ec11-a7b5-000d3a4b4cee,
44cf778a-d0ca-ec11-a7b5-000d3a4b4cee,
59cf778a-d0ca-ec11-a7b5-000d3a4b4cee,
75cf778a-d0ca-ec11-a7b5-000d3a4b4cee,
cccf778a-d0ca-ec11-a7b5-000d3a4b4cee,
e5d0778a-d0ca-ec11-a7b5-000d3a4b4cee,
46d1778a-d0ca-ec11-a7b5-000d3a4b4cee,
65d1778a-d0ca-ec11-a7b5-000d3a4b4cee,
0cd2778a-d0ca-ec11-a7b5-000d3a4b4cee,
504895cc-d0ca-ec11-a7b5-000d3a4b4cee,
994895cc-d0ca-ec11-a7b5-000d3a4b4cee,
d64895cc-d0ca-ec11-a7b5-000d3a4b4cee,
3a4995cc-d0ca-ec11-a7b5-000d3a4b4cee,
e10b90d2-d0ca-ec11-a7b5-000d3a4b4cee,
040d90d2-d0ca-ec11-a7b5-000d3a4b4cee,
8f0d90d2-d0ca-ec11-a7b5-000d3a4b4cee,
800e90d2-d0ca-ec11-a7b5-000d3a4b4cee,
820e90d2-d0ca-ec11-a7b5-000d3a4b4cee,
d80e90d2-d0ca-ec11-a7b5-000d3a4b4cee,
efaf7fd7-efca-ec11-a7b5-000d3a4b4cee,
9c9ff2b5-81ca-ec11-a7b5-000d3a4b4de9,
cfe1d17b-8cca-ec11-a7b5-000d3a4b4de9,
c8f05b65-8dca-ec11-a7b5-000d3a4b4de9,
10501947-97ca-ec11-a7b5-000d3a4b4de9,
7e5d164d-97ca-ec11-a7b5-000d3a4b4de9,
105f164d-97ca-ec11-a7b5-000d3a4b4de9,
9226f2e3-97ca-ec11-a7b5-000d3a4b4de9,
e4fcb9c3-98ca-ec11-a7b5-000d3a4b4de9,
c1feb9c3-98ca-ec11-a7b5-000d3a4b4de9,
27b3bc2c-9fca-ec11-a7b5-000d3a4b4de9,
28a3af38-9fca-ec11-a7b5-000d3a4b4de9,
4cc3cd44-a2ca-ec11-a7b5-000d3a4b4de9,
735fdfe5-a3ca-ec11-a7b5-000d3a4b4de9,
f107daeb-a3ca-ec11-a7b5-000d3a4b4de9,
a6b25eb9-a4ca-ec11-a7b5-000d3a4b4de9,
6b793897-a7ca-ec11-a7b5-000d3a4b4de9,
a9fec2c0-b5ca-ec11-a7b5-000d3a4b4de9,
cc3c3d72-b8ca-ec11-a7b5-000d3a4b4de9,
e15081c3-bcca-ec11-a7b5-000d3a4b4de9,
895181c3-bcca-ec11-a7b5-000d3a4b4de9,
8b5181c3-bcca-ec11-a7b5-000d3a4b4de9,
f05181c3-bcca-ec11-a7b5-000d3a4b4de9";

                        //   Dissociate(_client);
                        //  GetCALSBasedUser(_client, "57302052-90d0-ec11-a7b5-6045bd8e385c");


                        foreach (string usergid in UserID.Split(','))
                        {


                            var query_isdisabled = usergid;
                            var query_fullname = "%Eszter Melisek%";
                            // Instantiate QueryExpression query
                            var query = new QueryExpression("systemuser");
                            query.TopCount = 1;

                            // Add columns to query.ColumnSet
                            query.ColumnSet.AddColumns("isdisabled", "niq_calids", "systemuserid", "fullname");
                            //  query.Criteria.AddCondition("fullname", ConditionOperator.Like, query_fullname);
                            // Define filter query.Criteria
                            query.Criteria.AddCondition("systemuserid", ConditionOperator.Equal, query_isdisabled);
                            //    query.Criteria.AddCondition("niq_calids", ConditionOperator.NotNull);
                            EntityCollection userrcords = _client.RetrieveMultiple(query);
                            Guid Accestemplateid = GetTeamTemplate(_client);

                            foreach (Entity userrecord in userrcords.Entities)
                            {

                                // Dissociate(_client, userrecord.Id.ToString());
                                // EntityCollection adxrecordcol = GetCALSBasedUserandAssociate(_client, userrecord.Id.ToString());
                                Entity User = new Entity("systemuser", userrecord.Id);
                                // StringBuilder cals = new StringBuilder();

                                // foreach (Entity adxr in adxrecordcol.Entities)
                                // {
                                //     cals.Append(adxr.GetAttributeValue<Guid>("adx_contentaccesslevelid").ToString() + ",");
                                // }
                                // User["niq_calids"] = cals.ToString();
                                // _client.Update(User);
                                string cals = userrecord["niq_calids"].ToString();

                                Console.WriteLine("Transactions  " + userrecord["fullname"].ToString()  +"GUiD "+ userrecord.Id);
                                DissoicateAccessteams(_client, User, Accestemplateid);
                                List<String> KBAccessListNeedtobeAdded = cals.ToString().Split(',').ToList();
                                EntityCollection UserListKBAccessneedtoAdded = GetMatchingUserCALCollection(_client, KBAccessListNeedtobeAdded);
                                AddAccees(UserListKBAccessneedtoAdded, _client, User, Accestemplateid);


                            }


                        }
                      
                    }
                    else
                    {
                        Console.WriteLine("Validation was Failed.");
                        Console.WriteLine();

                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                string message = ex.Message;
                throw;
            }
        }

        public static void removeacces(EntityCollection removeaccesrecords, CrmServiceClient service, Guid userid, Guid templateid)
        {

            List<RemoveUserFromRecordTeamRequest> RemoveuserTeamrequest = new List<RemoveUserFromRecordTeamRequest>();
            foreach (Entity entity in removeaccesrecords.Entities)
            {

                var request = new RemoveUserFromRecordTeamRequest
                {
                    Record = entity.ToEntityReference(),
                    SystemUserId = userid,
                    TeamTemplateId = templateid
                };

                RemoveuserTeamrequest.Add(request);

            }


            OrganizationRequestCollection requestCollection = new OrganizationRequestCollection();
            requestCollection.AddRange(RemoveuserTeamrequest);

            ExecuteMultipleRequest execRequest = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },
                Requests = requestCollection
            };
            ExecuteMultipleResponse responseWithResults = (ExecuteMultipleResponse)service.Execute(execRequest);


            foreach (var responseItem in responseWithResults.Responses)
            {
                // A valid response.
                if (responseItem.Response != null) { }
                   // Console.WriteLine(responseItem.Response);

                // An error has occurred.
                else if (responseItem.Fault != null)
                    Console.WriteLine(responseItem.Fault.Message);
            }



        }



        private static void AddAccees(EntityCollection userListKBAccessneedtoAdded, CrmServiceClient service, Entity User, Guid Accestemplateid)
        {

            // List<List<Entity>> splittedLists = entities.ChunkBy<Entity>(1000);

            Chunk ch = new Chunk();
            var chunked = ch.BuildChunksWithLinq(userListKBAccessneedtoAdded.Entities.ToList(), 50).ToList();

            foreach (List<Entity> batch in chunked)
            {
                 
                Console.WriteLine("Add Accesss Team " + User.Id + "Batch Count " + batch.Count + "Chunk count"+ chunked.Count);


                List<AddUserToRecordTeamRequest> AdduserTeamrequest = new List<AddUserToRecordTeamRequest>();
                foreach (Entity entity in batch)
                {


                    var request = new AddUserToRecordTeamRequest
                    {
                        Record = entity.ToEntityReference(),
                        SystemUserId = User.Id,
                        TeamTemplateId = Accestemplateid
                    };

                    AdduserTeamrequest.Add(request);
                }

                // create the request collection
                OrganizationRequestCollection requestCollection = new OrganizationRequestCollection();
                requestCollection.AddRange(AdduserTeamrequest);

                // create the execute multiple and set the requestCollection
                ExecuteMultipleRequest execRequest = new ExecuteMultipleRequest()
                {
                    Settings = new ExecuteMultipleSettings()
                    {
                        ContinueOnError = true,
                        ReturnResponses = true
                    },
                    Requests = requestCollection
                };
                ExecuteMultipleResponse responseWithResults = (ExecuteMultipleResponse)service.Execute(execRequest);


                foreach (var responseItem in responseWithResults.Responses)
                {
                    // A valid response.
                    if (responseItem.Response != null) { }
                      //  Console.WriteLine(responseItem.Response);

                    // An error has occurred.
                    else if (responseItem.Fault != null)
                        Console.WriteLine(responseItem.Fault.Message);
                }
            }

        }

        public static Guid GetTeamTemplate(CrmServiceClient service)
        {
            var query_teamtemplatename = "%Knowledge Article Permission Set%";
            var query = new QueryExpression("teamtemplate");
            query.TopCount = 1;
            query.ColumnSet.AddColumns("teamtemplateid");
            query.Criteria.AddCondition("teamtemplatename", ConditionOperator.Like, query_teamtemplatename);
            EntityCollection enitites = service.RetrieveMultiple(query);
            return enitites.Entities[0].Id;

        }


        public static EntityCollection GetMatchingUserCALCollection(IOrganizationService service, List<String> KBAccessCals)
        {
            EntityCollection KBUserList = new EntityCollection();

            foreach (string Calids in KBAccessCals)
            {
                if (Calids.Length == 36)
                {
                    var query_niq_calids = "%" + Calids + "%";
                    var query = new QueryExpression("knowledgearticle");
                    query.ColumnSet.AddColumns("knowledgearticleid");
                    query.Criteria.AddCondition("niq_calids", ConditionOperator.Like, query_niq_calids);
                    EntityCollection enitites = service.RetrieveMultiple(query);

                    KBUserList.Entities.AddRange(enitites.Entities);
                }

            }

            return KBUserList;

        }


        public static EntityCollection GetCALSBasedUserandAssociate(CrmServiceClient service, string userid)
        {

            EntityCollection adxrecordcoltotal = new EntityCollection();
            EntityCollection adxrecordcol = new EntityCollection();
            string fetchxml = string.Format(@"<fetch>
  <entity name='systemuser'>
    <attribute name='systemuserid' />
    <attribute name='niq_calids' />
    <attribute name='niq_customertype' />
    <attribute name='niq_geography' />
    <attribute name='niq_servicecategory' />
    <filter>
       <condition attribute='systemuserid' operator='eq' value ='{0}' />
        <condition attribute='niq_customertype' operator='not-null' />
        <condition attribute='niq_geography' operator='not-null' />
      <condition attribute='niq_servicecategory' operator='not-null' />
    </filter>
  </entity>
</fetch>", userid);


            FetchExpression userrecord = new FetchExpression(fetchxml);

            EntityCollection userrecordcol = service.RetrieveMultiple(userrecord);

            // userrecordcol.Entities[0].Attributes<


            foreach (Entity userrecordentity in userrecordcol.Entities)
            {

                string[] niq_servicecategoryarray = userrecordentity.FormattedValues["niq_servicecategory"].Split(';');
                string[] niq_geographyarray = userrecordentity.FormattedValues["niq_geography"].Split(';');
                string[] niq_customertypearray = userrecordentity.FormattedValues["niq_customertype"].Split(';');




                List<String> list = new List<string>();

                foreach (string niq_servicecategory in niq_servicecategoryarray)
                {
                    foreach (string niq_geography in niq_geographyarray)
                    {
                        foreach (string niq_customertype in niq_customertypearray)
                        {
                            //sb.AppendLine("<condition attribute='adx_name' operator='eq' value='" + niq_servicecategory.Trim() + "-" + niq_geography.Trim() + "-" + niq_customertype.Trim() + "' />");
                            list.Add("<condition attribute='adx_name' operator='eq' value='" + niq_servicecategory.Trim() + "-" + niq_geography.Trim() + "-" + niq_customertype.Trim() + "' />");
                        }

                    }
                }

                Chunk ch = new Chunk();
                var chunked = ch.BuildChunksWithLinq(list, 200).ToList();


                foreach (List<string> S in chunked)
                {
                    StringBuilder sb = new StringBuilder();

                    foreach (string st in S)
                    {

                        sb.AppendLine(st);

                    }

                    string adxfetchxml = string.Format(@"<fetch>
  <entity name='adx_contentaccesslevel'>
    <attribute name='adx_contentaccesslevelid' />
    <attribute name='adx_name' />
    <filter type='or'>
      {0}
    </filter>
  </entity>
</fetch>", sb.ToString());

                    FetchExpression adxrecord = new FetchExpression(adxfetchxml);

                    adxrecordcol = service.RetrieveMultiple(adxrecord);
                    adxrecordcoltotal.Entities.AddRange(adxrecordcol.Entities);
                 

                    AssociateMultipleRequest(service, adxrecordcol, userid);
                }
                

            }
            return adxrecordcoltotal;
        }


        public static void DissociateMultipleRequest(CrmServiceClient service, EntityCollection CollectionRequest, Entity User)
        {
            // Create an ExecuteMultipleRequest object.
            ExecuteMultipleRequest requestWithResults = new ExecuteMultipleRequest()
            {
                // Assign settings that define execution behavior: continue on error, return responses. 
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = false,
                    ReturnResponses = true
                },
                // Create an empty organization request collection.
                Requests = new OrganizationRequestCollection()
            };

            // Create several (local, in memory) entities in a collection. 
            EntityCollection input = CollectionRequest;
            string relationshipName = "niq_SystemUser_adx_contentaccesslevel";
            Relationship relationship = new Relationship(relationshipName);

            // Add a CreateRequest for each entity to the request collection.
            foreach (var entity in input.Entities)
            {
                var relatedEntities = new EntityReferenceCollection();
                relatedEntities.Add(entity.ToEntityReference());


                DisassociateRequest dissocaiteRequest = new DisassociateRequest { Target = User.ToEntityReference(), Relationship = relationship, RelatedEntities = relatedEntities };
                requestWithResults.Requests.Add(dissocaiteRequest);
            }

            // Execute all the requests in the request collection using a single web method call.
            ExecuteMultipleResponse responseWithResults =
                (ExecuteMultipleResponse)service.Execute(requestWithResults);

            // Display the results returned in the responses.
            foreach (var responseItem in responseWithResults.Responses)
            {
                // A valid response.
                if (responseItem.Response != null) { }
                    //DisplayResponse(requestWithResults.Requests[responseItem.RequestIndex], responseItem.Response);

                // An error has occurred.
                else if (responseItem.Fault != null)
                    DisplayFault(requestWithResults.Requests[responseItem.RequestIndex],
                        responseItem.RequestIndex, responseItem.Fault);
            }
        }

        public class Chunk
        {
            public IEnumerable<IEnumerable<T>> BuildChunks<T>(List<T> fullList, int batchSize)
            {
                return BuildChunksWithIteration(fullList, batchSize);
            }



            private IEnumerable<IEnumerable<T>> BuildChunksWithLinqAndYield<T>(List<T> fullList, int batchSize)
            {
                return null;
            }

            private IEnumerable<IEnumerable<T>> BuildChunksWithIteration<T>(List<T> fullList, int batchSize)
            {
                return null;
            }

            private IEnumerable<IEnumerable<T>> BuildChunksWithRange<T>(List<T> fullList, int batchSize)
            {
                return null;
            }

            public IEnumerable<IEnumerable<T>> BuildChunksWithLinq<T>(List<T> fullList, int batchSize)
            {
                int total = 0;
                var chunkedList = new List<List<T>>();
                while (total < fullList.Count)
                {
                    var chunk = fullList.Skip(total).Take(batchSize);
                    chunkedList.Add(chunk.ToList());
                    total += batchSize;
                }

                return chunkedList;
            }

            public List<List<T>> ChunkBy<T>(List<T> fullList, int batchSize)
            {
                int total = 0;
                var chunkedList = new List<List<T>>();
                while (total < fullList.Count)
                {
                    var chunk = fullList.Skip(total).Take(batchSize);
                    chunkedList.Add(chunk.ToList());
                    total += batchSize;
                }

                return chunkedList;
            }


        }

        public static void AssociateMultipleRequest(CrmServiceClient service, EntityCollection CollectionRequest, String userid)
        {

            Entity User = new Entity("systemuser", new Guid(userid));

            // Create an ExecuteMultipleRequest object.
            ExecuteMultipleRequest requestWithResults = new ExecuteMultipleRequest()
            {
                // Assign settings that define execution behavior: continue on error, return responses. 
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = false,
                    ReturnResponses = true
                },
                // Create an empty organization request collection.
                Requests = new OrganizationRequestCollection()
            };

            // Create several (local, in memory) entities in a collection. 
            EntityCollection input = CollectionRequest;
            string relationshipName = "niq_SystemUser_adx_contentaccesslevel";
            Relationship relationship = new Relationship(relationshipName);

            // Add a CreateRequest for each entity to the request collection.
            foreach (var entity in input.Entities)
            {
                var relatedEntities = new EntityReferenceCollection();
                relatedEntities.Add(entity.ToEntityReference());


                AssociateRequest assocaiteRequest = new AssociateRequest { Target = User.ToEntityReference(), Relationship = relationship, RelatedEntities = relatedEntities };
                requestWithResults.Requests.Add(assocaiteRequest);
            }

            // Execute all the requests in the request collection using a single web method call.
            ExecuteMultipleResponse responseWithResults =
                (ExecuteMultipleResponse)service.Execute(requestWithResults);

            // Display the results returned in the responses.
            foreach (var responseItem in responseWithResults.Responses)
            {
                // A valid response.
                if (responseItem.Response != null)
                    DisplayResponse(requestWithResults.Requests[responseItem.RequestIndex], responseItem.Response);

                // An error has occurred.
                else if (responseItem.Fault != null)
                    DisplayFault(requestWithResults.Requests[responseItem.RequestIndex],
                        responseItem.RequestIndex, responseItem.Fault);
            }
        }


        private static void DisplayFault(OrganizationRequest organizationRequest, int count,
            OrganizationServiceFault organizationServiceFault)
        {
            Console.WriteLine("A fault occurred when processing {1} request, at index {0} in the request collection with a fault message: {2}", count + 1,
                organizationRequest.RequestName,
                organizationServiceFault.Message);
        }
        private static void DisplayResponse(OrganizationRequest organizationRequest, OrganizationResponse organizationResponse)
        {
            Console.WriteLine("Created " + (organizationRequest.Parameters["Target"]));
        }

        private static EntityCollection GetCollectionOfEntitiesToCreate()
        {
            return new EntityCollection()
            {

            };
        }



        //public void Associate(CrmServiceClient service)
        //{
        //    string relationshipName = "niq_systemuser_adx_contentaccesslevel";
        //    Relationship relationship = new Relationship(relationshipName);
        //    EntityReferenceCollection relatedEntities = new EntityReferenceCollection();
        //    EntityReference secondaryEntity = new EntityReference("SecondEntitySchemaName", GUIDOfSecondEntityRecord);
        //    relatedEntities.Add(secondaryEntity);
        //    service.Associate("FirstEntitySchemaName", GUIDOfFirstEntityRecord, relationship, relatedEntities);


        //}

        public static void DissoicateAccessteams(CrmServiceClient service, Entity User,Guid Accestemplateid)
        {
            int pageNumber = 1;
            var af_systemuserid = User.Id;
            var query_isrootarticle = false;
            var ae_teamtype = 1;

           // Entity User = new Entity("systemuser", new Guid(userid));
            // var af_fullname = "Rachana Pattanaik";


            // Instantiate QueryExpression query
            var query = new QueryExpression("knowledgearticle");
            query.Distinct = true;

            // Add columns to query.ColumnSet
            query.ColumnSet.AddColumns("articlepublicnumber", "knowledgearticleid");
            query.AddOrder("articlepublicnumber", OrderType.Ascending);

            query.PageInfo.Count = 50;
            query.PageInfo.PageNumber = 1;
            query.PageInfo.PagingCookie = null;

            // Define filter query.Criteria
            query.Criteria.AddCondition("isrootarticle", ConditionOperator.Equal, query_isrootarticle);

            // Add link-entity ae
            var ae = query.AddLink("team", "knowledgearticleid", "regardingobjectid");
            ae.EntityAlias = "ae";

            // Define filter ae.LinkCriteria
            ae.LinkCriteria.AddCondition("teamtype", ConditionOperator.Equal, ae_teamtype);

            // Add link-entity ae_teammembership
            var ae_teammembership = ae.AddLink("teammembership", "teamid", "teamid");

            // Add link-entity af
            var af = ae_teammembership.AddLink("systemuser", "systemuserid", "systemuserid");
            af.EntityAlias = "af";

            // Define filter af.LinkCriteria
            //af.LinkCriteria.AddCondition("fullname", ConditionOperator.Equal, af_fullname);
            af.LinkCriteria.AddCondition("systemuserid", ConditionOperator.Equal, af_systemuserid);

            EntityCollection accesteamrecords = service.RetrieveMultiple(query);
            removeacces(accesteamrecords, service, User.Id, Accestemplateid);
            Console.WriteLine("Remove Accesss Team " + User.Id + "Batah Count " + accesteamrecords);
            while (accesteamrecords.MoreRecords)
            {
                pageNumber++;
                query.PageInfo.PageNumber = pageNumber;
                query.PageInfo.PagingCookie = accesteamrecords.PagingCookie;
                EntityCollection tempResponse = service.RetrieveMultiple(query);
                removeacces(tempResponse, service, User.Id, Accestemplateid);
                accesteamrecords.Entities.AddRange(tempResponse.Entities);
                accesteamrecords.MoreRecords = tempResponse.MoreRecords;
                Console.WriteLine("Remove Accesss Team " + User.Id + "Batah Count " + accesteamrecords);


                Console.WriteLine("Record Count" + accesteamrecords.Entities.Count);
            }



        }




        public static void Dissociate(CrmServiceClient service, string userid)
        {
            int pageNumber = 1;
            // Define Condition Values
            var query_adx_name = "%-%-%";
            var query_niq_systemuser_adx_contentaccesslevel_systemuserid = userid;

            // Instantiate QueryExpression query
            var query = new QueryExpression("adx_contentaccesslevel");

            // Add columns to query.ColumnSet
            query.ColumnSet.AddColumns("adx_name");

            // Define filter query.Criteria
            query.Criteria.AddCondition("adx_name", ConditionOperator.Like, query_adx_name);


            query.PageInfo.Count = 200;
            query.PageInfo.PageNumber = 1;
            query.PageInfo.PagingCookie = null;

            Entity User = new Entity("systemuser", new Guid(userid));


            // Add link-entity query_niq_systemuser_adx_contentaccesslevel
            var query_niq_systemuser_adx_contentaccesslevel = query.AddLink("niq_systemuser_adx_contentaccesslevel", "adx_contentaccesslevelid", "adx_contentaccesslevelid");

            // Add columns to query_niq_systemuser_adx_contentaccesslevel.Columns
            query_niq_systemuser_adx_contentaccesslevel.Columns.AddColumns("systemuserid");

            // Define filter query_niq_systemuser_adx_contentaccesslevel.LinkCriteria
            query_niq_systemuser_adx_contentaccesslevel.LinkCriteria.AddCondition("systemuserid", ConditionOperator.Equal, query_niq_systemuser_adx_contentaccesslevel_systemuserid);


            ConditionExpression cond1 = new ConditionExpression("adx_name", ConditionOperator.Contains, "-*-");
            EntityCollection adx_contentaccesslevel = service.RetrieveMultiple(query);
            DissociateMultipleRequest(service, adx_contentaccesslevel, User);
            while (adx_contentaccesslevel.MoreRecords)
            {
                pageNumber++;
                query.PageInfo.PageNumber = pageNumber;
                query.PageInfo.PagingCookie = adx_contentaccesslevel.PagingCookie;
                EntityCollection tempResponse = service.RetrieveMultiple(query);
                DissociateMultipleRequest(service, tempResponse, User);
                adx_contentaccesslevel.Entities.AddRange(tempResponse.Entities);
                adx_contentaccesslevel.MoreRecords = tempResponse.MoreRecords;

                Console.WriteLine("Record Count" + adx_contentaccesslevel.Entities.Count);
            }




        }



    }
}