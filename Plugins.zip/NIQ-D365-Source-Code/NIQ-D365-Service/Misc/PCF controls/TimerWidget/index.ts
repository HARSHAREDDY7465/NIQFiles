import {IInputs, IOutputs} from "./generated/ManifestTypes";
import * as React from "react";
import * as ReactDOM from "react-dom";
import TimerWidgetControl, { ITimerWidgetControlProps } from "./timerwidgetcontrol";

const PERSISTED_CURRENTCOUNTER_KEY_NAME = "currentcounter";

export class Timerwidget implements ComponentFramework.StandardControl<IInputs, IOutputs> {

	 private _notifyOutputChanged:()=> void;
	 private _container:HTMLDivElement;
	 private _counter: number | undefined;
     private _controlViewRendered: boolean;
	 private _persistedcounter:  number |null ;


	// Used to store necessary data for a single lookup entity selected during runtime
	private _selectedaccount: ComponentFramework.LookupValue;
	private _selectedactivitytype: ComponentFramework.LookupValue;
	private _selectedactivitysubtype: ComponentFramework.LookupValue;
	private _incidentid: string;
	private _totaltimer: string;
	private _pauseandplay:boolean;



	 // Data type used to store the various information as part of the state object.
	 private _stateDictionary: ComponentFramework.Dictionary = {};

	 private _context: ComponentFramework.Context<IInputs>;

	 private _props : ITimerWidgetControlProps={

		counter: undefined,
		pause:  true,
		currentcount:0,
		totaltimer:"",

		onChangeTimer:this.notifyChange.bind(this),
		onPause:this.notifyPauseChange.bind(this),
	 }

	/**
	 * Empty constructor.
	 */
	constructor()
	{

	}

	/**
	 * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.
	 * Data-set values are not initialized here, use updateView.
	 * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.
	 * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.
	 * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.
	 * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.
	 */
	public init(context: ComponentFramework.Context<IInputs>, notifyOutputChanged: () => void, state: ComponentFramework.Dictionary, container:HTMLDivElement): void
	{

         console.log("index - init");

		this._controlViewRendered = false;
		this._context = context;
		

		// if (state) {
          
		// 	this._stateDictionary = state;
		// 	this._persistedcounter=state[(<any>this._context).page.entityId];
		// 	this._props.currentcount=state[(<any>this._context).page.entityId];
		// 	//this._props.pause=state[(<any>this._context).page.entityId+"PauseStatus"];
		// }


	  this._notifyOutputChanged = notifyOutputChanged;
      this._container = document.createElement("div");
      container.appendChild(this._container);
	}


	/**
	 * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.
	 * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions
	 */
	public updateView(context: ComponentFramework.Context<IInputs>): void
	{

		this._selectedaccount = context.parameters.account.raw[0];
		this._selectedactivitytype= context.parameters.activitytype.raw[0];
		this._selectedactivitysubtype= context.parameters.activitysubtype.raw[0];
		this._incidentid= context.parameters.sampleProperty.raw==null?"":context.parameters.sampleProperty.raw;
	    this._totaltimer= context.parameters.totaltime.raw==null?"":context.parameters.totaltime.raw;
		this._props.totaltimer= context.parameters.totaltime.raw==null?"":context.parameters.totaltime.raw;
		this._context = context;

	
		// Add code to update control view
        //console.log("index - updateView-> Render props.counter = " + this._props.currentcount);
		if (!this._controlViewRendered) {
       
			
		  ReactDOM.render(
			React.createElement(TimerWidgetControl, this._props), 
			this._container
		 );
			this._controlViewRendered = true;
		//console.log("index - updateView-> Render props.counter = " + this._props.counter);
		
		}
	}


	private notifyChange(newCounter: number | undefined) {
		this._counter = newCounter;
		this._props.counter=newCounter;
		this._stateDictionary[(<any>this._context).page.entityId] = newCounter;
		//console.log("Props Counter"+this._props.counter);
		this._context.mode.setControlState(this._stateDictionary);
		//console.log(this._counter);
		this._notifyOutputChanged();
	 }

	 private notifyPauseChange(newPause: boolean,timer:number) {
		//console.log("Pause Status : " +newPause);
		this._props.pause=newPause;
		//this._stateDictionary[(<any>this._context).page.entityId+"PauseStatus"]=newPause;
		this._notifyOutputChanged();

	 }
	/**
	 * It is called by the framework prior to a control receiving new data.
	 * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”
	 */
	public getOutputs(): IOutputs
	{

		return {

		}
	}


	public destroy(): void
	{

	
	/*	console.log(`incidentid :${this._incidentid}`);
		if (this._selectedaccount!= undefined)
		console.log(`accountname: ${this._selectedaccount.name} entityType: ${this._selectedaccount.entityType} id: ${this._selectedaccount.id}`);
		if (this._selectedactivitytype!= undefined)
		console.log(`activitytypename: ${this._selectedactivitytype.name} entityType: ${this._selectedactivitytype.entityType} id: ${this._selectedactivitytype.id}`);
        if (this._selectedactivitysubtype!= undefined)
		console.log(`activitysubtypename: ${this._selectedactivitysubtype.name} entityType: ${this._selectedactivitysubtype.entityType} id: ${this._selectedactivitysubtype.id}`);
*/
      if (this._counter!=undefined && this._counter>60 && this._incidentid !=undefined){
		const min=Math.floor(this._counter/60);
		const getminutes=("0"+min%60).slice(-2);
		const hours=("0"+Math.floor(this._counter/3600)).slice(-2);
		// Add code to cleanup control if necessary
		const data: ComponentFramework.WebApi.Entity = {};
			data["niq_activitycreationflag"]= true;
			let parsedDate = new Date();
			let StartDate = new Date(parsedDate.getSeconds() - this._counter);			
			//data["overriddencreatedon"]=StartDate.toISOString();
			data["niq_atdate"]= parsedDate.toISOString();
			data["niq_atdurationtotalseconds"]=this._counter;
			data["niq_atdurationinhours"]= hours+":"+getminutes;
			if (this._selectedaccount!= undefined)
			data["niq_ataccount@odata.bind"] ="/accounts("+this._selectedaccount.id+")";
			if (this._selectedactivitytype!= undefined)
			data["niq_atactivitytype@odata.bind"] ="/niq_requestactivitytypeses("+this._selectedactivitytype.id+")";
			if (this._selectedactivitysubtype!= undefined)
			data["niq_atactivitysubtype@odata.bind"] ="/niq_requestactivitytypeses("+this._selectedactivitysubtype.id+")";
			data["niq_atrequest@odata.bind"] ="/incidents("+(<any>this._context).page.entityId+")";
			
			this._context.webAPI.createRecord("niq_activitytracker",data).then(function success(result) {
					console.log("record created with ID: " + result.id);
					// perform operations on record creation
				},
				function (error) {
					console.log(error.message);
					// handle error conditions
				});

				
	  }
      if (this._props.pause ==true){
	  this._stateDictionary[(<any>this._context).page.entityId] = 0;
	  this._context.mode.setControlState(this._stateDictionary);
	  }


	  console.log((<any>this._context).page.entityId);
	  ReactDOM.unmountComponentAtNode(this._container);

	}
}
