import * as React from "react";
import{Stack} from  "@fluentui/react/lib/Stack";
import{Label} from  "@fluentui/react/lib/Label";
import{CommandButton} from  "@fluentui/react/lib/components/Button/CommandButton/CommandButton";
import{mergeStyles} from  "@fluentui/merge-styles";
import { initializeIcons } from "@fluentui/react/lib/Icons";
import  { IIconProps } from "@fluentui/react/lib/Icon";
import { useBoolean,useConst } from "@fluentui/react-hooks";


const playIcon: IIconProps = { iconName: 'BoxPlaySolid' ,style: { fontSize: 30,color:'#00BCF2' } };
const pauseIcon: IIconProps = { iconName: 'CirclePauseSolid', style: { fontSize: 30,color:'#00BCF2' }};
//const playIcon: IIconProps = { iconName: 'PlaySolid' };

export interface ITimerWidgetControlProps {
    //properties : PCF =>
    counter: number | undefined;
    pause: boolean ;
    currentcount: number;
    totaltimer:string;
    //Callback function : => PCF
    onChangeTimer: (counter: number | undefined) => void;
    onPause: (pause: boolean,currentcount:number) => void;
 }

 const TimerWidgetControl =(props :ITimerWidgetControlProps) : JSX.Element =>{

// useState , useBoolean are used for state varibales
const [time, setTime] = React.useState<number>(props.currentcount);
const [timerOn, setTimerOn] = React.useState(props.pause);
const [muted, { toggle: setMuted }] = useBoolean(false);


// initializeIcons
useConst(() => {
  //console.log("useConst : initilize icons");
  initializeIcons();
});

// Styles Class
const maskedclass = mergeStyles({
  fontSize: 20,
  Size:30
});

const smallclass = mergeStyles({
  fontSize: 10,
  
});

// Will method will be called on Change of timerOn value
React.useEffect(() => {
        let interval : any = null ;
       
        if (timerOn) {
          
          interval = setInterval(() => {
           // console.log(time);
            setTime((prevTime) => prevTime + 1);        
          }, 1000);
        } else if (!timerOn) {     
          clearInterval(interval);

        }      
        return () => clearInterval(interval);
      }, [timerOn]);

// Will method will be called on Change of time value
React.useEffect(() => {   
        props.onChangeTimer(time);       
      },[time]);


// Format the values HH:MM:SS format    
const formatTime=() =>{

     const sec=("0" + (time%60)).slice(-2);
     const min=Math.floor(time/60);
     const getminutes=("0"+min%60).slice(-2);
     const hours=("0"+Math.floor(time/3600)).slice(-2);

      return (hours+":"+getminutes+":"+sec);
     };

 // Method will be triggered on Pause/Play Command Button Click    
const PuaseandPlay=() =>{
      setMuted();
      muted==true?setTimerOn(true):setTimerOn(false);
      props.onPause(timerOn,time);

     };

    return(
        <div>
          <Stack tokens={{ childrenGap: 8 }} horizontal>
         
        <CommandButton 
        toggle
        checked={muted}
        iconProps={timerOn ? pauseIcon : playIcon}
        onClick={PuaseandPlay}  
        allowDisabledFocus
      
      />
       <Label className={maskedclass}>{formatTime()}</Label>
       <Label className={smallclass}>Total Time : {props.totaltimer}</Label> 
      </Stack>

        </div>
    );
 }; 

 export default TimerWidgetControl;