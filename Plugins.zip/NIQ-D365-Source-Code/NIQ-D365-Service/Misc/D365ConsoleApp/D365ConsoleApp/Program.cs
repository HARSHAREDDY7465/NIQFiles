﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace D365ConsoleApp
{
    class Program
    {
        private static CrmServiceClient _client;
       
        public static void Main(string[] args)
        {
            try
            {
                MakeCRMConnection();

            }
            catch (Exception ex)
            {
                string message = ex.Message;
                throw;
            }
        }

        private static void MakeCRMConnection()
        {
            using (_client = new CrmServiceClient(ConfigurationManager.ConnectionStrings["CRMConnectionString"].ConnectionString))
            {
                //Do stuff

                if (_client.IsReady)
                {
                    var request = new WhoAmIRequest();
                    var response = _client.Execute(request);
                    Console.WriteLine("Validation was successful.");
                    Console.WriteLine();

                    Helper helper = new Helper();

                    ////Uncheck this method when to to upade owner of queue to team
                    //helper.UpdateQueueOwner(_client);

                    helper.UpdateRoutingRuleItem(_client);
                    
                }
                else
                {
                    Console.WriteLine("Validation was Failed.");
                    Console.WriteLine();

                }
            }
        }

        //        public static void UpdateQueueOwner(CrmServiceClient service)
        //        {
        //            try
        //            {
        //                string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
        //  <entity name='queue'>
        //    <attribute name='name' />
        //    <attribute name='queueid' />
        //    <attribute name='queueviewtype' />
        //    <attribute name='emailrouteraccessapproval' />
        //    <attribute name='owningbusinessunit' />
        //    <attribute name='createdon' />
        //    <attribute name='ownerid' />
        //    <order attribute='name' descending='false' />
        //    <filter type='and'>
        //      <condition attribute='queueviewtype' operator='eq' value='0' />
        //      <condition attribute='createdon' operator='on' value='2022-07-08' />
        //<condition attribute='name' operator='not-like' value='%&lt;%' />
        //        </filter>
        //  </entity>
        //</fetch>";


        //                EntityCollection queues = service.RetrieveMultiple(new FetchExpression(fetchXml));
        //                foreach (var q in queues.Entities)
        //                {
        //                    Console.WriteLine("Name: {0}", q.Attributes["name"]);
        //                    if (q.Attributes["name"] != null)
        //                    {
        //                        string fetchXmlTeam = string.Format(@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
        //  <entity name='team'>
        //    <attribute name='name' />
        //    <attribute name='businessunitid' />
        //    <attribute name='teamid' />
        //    <attribute name='teamtype' />
        //    <order attribute='name' descending='false' />
        //    <filter type='and'>
        //      <condition attribute='name' operator='eq' value='{0}' />
        //    </filter>
        //  </entity>
        //</fetch>", q.Attributes["name"].ToString().Trim());

        //                        EntityCollection teams = service.RetrieveMultiple(new FetchExpression(fetchXmlTeam));

        //                        if (teams != null)
        //                        {
        //                            string teamGuid = teams.Entities[0].Attributes["teamid"].ToString();
        //                            //update owner as team in existing queue
        //                            AssignRequest assignowner = new AssignRequest
        //                            {
        //                                Assignee = new EntityReference("team", new Guid(teams.Entities[0].Attributes["teamid"].ToString())),
        //                                Target = new EntityReference("queue", new Guid(q.Attributes["queueid"].ToString()))
        //                            };
        //                            //service.Execute(assignowner);
        //                            Console.WriteLine("Owner of queue " + q.Attributes["name"].ToString().Trim() + " " + "upadated as team " + teams.Entities[0].Attributes["name"].ToString().Trim() + " successfully.");
        //                        }
        //                    }



        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                string message = ex.Message;
        //                Console.WriteLine(ex.Message);
        //            }
        //        }
    }
}

