﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace D365ConsoleApp
{
    public class Helper
    {
        public bool AssociateRoleToTeam(string _roleName, CrmServiceClient _client)
        {
            bool isAssociated = true;

            try
            {
                if (!string.IsNullOrWhiteSpace(_roleName))
                {
                    // Retrieve a role from CRM.
                    QueryExpression query = new QueryExpression
                    {
                        EntityName = "role",
                        ColumnSet = new ColumnSet("roleid"),
                        Criteria = new FilterExpression
                        {
                            Conditions ={
                                            // You would replace the condition below with an actual role
                                            // name, or skip this query if you had a role id.
                                                new ConditionExpression
                                                {
                                                    AttributeName = "name",
                                                    Operator = ConditionOperator.Equal,
                                                    Values = {_roleName.ToLower().Trim()}
                                                }
                                    }
                        }
                    };


                    Entity role = _client.RetrieveMultiple(query).Entities.FirstOrDefault();
                    if (role != null)
                    {
                        //Get Team details
                        EntityCollection teams = GetTeamDetails(_client);
                        if (teams != null)
                        {
                            foreach (var item in teams.Entities)
                            {
                                // Add the role to the team.
                                _client.Associate("team", new Guid(item["teamid"].ToString()), new Relationship("teamroles_association"),
                                       new EntityReferenceCollection() { new EntityReference("role", new Guid(role["roleid"].ToString())) });

                                Console.WriteLine("Assigned role " + _roleName + " to team " + item["name"].ToString());
                            }

                        }

                    }

                }
                return isAssociated;
            }
            catch (Exception ex)
            {
                isAssociated = false;
                Console.WriteLine(string.Concat("Method ", "AssociateRoleToTeam", " Error Message ", ex.Message.ToString()));
                return isAssociated;
            }

        }

        public void UpdateRoutingRuleItem(CrmServiceClient _client)
        {
            string filePath = @"C:\PawanNielsenDevelopment\ReportingSolution.xlsx";
            Excel.Application xlApp = new Excel.Application();

            if (xlApp == null)
            {
                Console.WriteLine("Excel is not installed in the system...");
                return;
            }

            object misValue = System.Reflection.Missing.Value;

            Excel.Workbook xlWorkBook = xlApp.Workbooks.Open(filePath);
            Excel.Worksheet xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            Excel.Range xlRange = xlWorkSheet.UsedRange;
            int totalRows = xlRange.Rows.Count;
            int totalColumns = xlRange.Columns.Count;
            for (int rowCount = 2; rowCount <= totalRows; rowCount++)
            {

                string routingRuleItemID = Convert.ToString((xlRange.Cells[rowCount, 3] as Excel.Range).Text);
                string sequence = Convert.ToString((xlRange.Cells[rowCount, 2] as Excel.Range).Text);

                if (!string.IsNullOrEmpty(routingRuleItemID) && !string.IsNullOrEmpty(sequence))
                {
                    Entity routingruleitem = new Entity("routingruleitem");
                    routingruleitem.Id = new Guid(routingRuleItemID);
                    routingruleitem["sequencenumber"] = Convert.ToInt32(sequence);
                    _client.Update(routingruleitem);
                }

            }
        }
        public EntityCollection GetTeamDetails(CrmServiceClient _client)
        {
            EntityCollection teams = null;
            try
            {
                string fetchXmlTeam = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='team'>
    <attribute name='name' />
    <attribute name='businessunitid' />
    <attribute name='teamid' />
    <attribute name='teamtype' />
    <attribute name='teamtype' />
    <attribute name='isdefault' />
    <attribute name='queueid' />
    <attribute name='createdon' />
    <attribute name='createdby' />
    <order attribute='name' descending='false' />
    <filter type='and'>
      <condition attribute='createdon' operator='on' value='2022-07-11' />
    </filter>
  </entity>
</fetch>";

                teams = _client.RetrieveMultiple(new FetchExpression(fetchXmlTeam));
                return teams;
            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Concat("Method ", "GetTeamDetails", " Error Message ", ex.Message.ToString()));
                return teams;
            }

        }

        public void UpdateQueueOwner(CrmServiceClient service)
        {
            try
            {
                string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='queue'>
    <attribute name='name' />
    <attribute name='queueid' />
    <attribute name='queueviewtype' />
    <attribute name='emailrouteraccessapproval' />
    <attribute name='owningbusinessunit' />
    <attribute name='createdon' />
    <attribute name='ownerid' />
    <order attribute='name' descending='false' />
    <filter type='and'>
      <condition attribute='queueviewtype' operator='eq' value='0' />
      <condition attribute='createdon' operator='on' value='2022-07-11' />
<condition attribute='name' operator='not-like' value='%&lt;%' />
        </filter>
  </entity>
</fetch>";


                EntityCollection queues = service.RetrieveMultiple(new FetchExpression(fetchXml));
                foreach (var q in queues.Entities)
                {
                    Console.WriteLine("Name: {0}", q.Attributes["name"]);
                    if (q.Attributes["name"] != null)
                    {
                        string fetchXmlTeam = string.Format(@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='team'>
    <attribute name='name' />
    <attribute name='businessunitid' />
    <attribute name='teamid' />
    <attribute name='teamtype' />
    <order attribute='name' descending='false' />
    <filter type='and'>
      <condition attribute='name' operator='eq' value='{0}' />
    </filter>
  </entity>
</fetch>", q.Attributes["name"].ToString().Trim());

                        EntityCollection teams = service.RetrieveMultiple(new FetchExpression(fetchXmlTeam));

                        if (teams != null)
                        {
                            string teamGuid = teams.Entities[0].Attributes["teamid"].ToString();
                            //update owner as team in existing queue
                            AssignRequest assignowner = new AssignRequest
                            {
                                Assignee = new EntityReference("team", new Guid(teams.Entities[0].Attributes["teamid"].ToString())),
                                Target = new EntityReference("queue", new Guid(q.Attributes["queueid"].ToString()))
                            };
                            service.Execute(assignowner);
                            Console.WriteLine("Owner of queue " + q.Attributes["name"].ToString().Trim() + " " + "upadated as team " + teams.Entities[0].Attributes["name"].ToString().Trim() + " successfully.");
                        }
                    }



                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
