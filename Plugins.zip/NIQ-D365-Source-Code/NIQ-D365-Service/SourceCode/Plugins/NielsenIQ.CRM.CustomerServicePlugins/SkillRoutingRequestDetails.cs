﻿
#region [ Includes]
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.CustomerServicePlugins.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static NielsenIQ.CRM.CustomerServicePlugins.Helpers.CommonConstants;
#endregion

namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class SkillRoutingRequestDetails : IPlugin
    {
        ITracingService tracer = null;

        /// <summary>
        /// Method to execute first method of the plugin 
        /// </summary>
        /// <param name="serviceProvider"></param>
        public void Execute(IServiceProvider serviceProvider)
        {
            // create service object 
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            try
            {
                // update ownerid route incident - when the owner changes for the record types  - GCD, NGH recordtypes 
                // only when recordtype = CR, Analytics, NGH
                int recordtype = 0;
                tracer.Trace("start assignment plugin");
                // get the target
                Entity targetentity = (Entity)context.InputParameters[TARGET];
                // check if  owning user changed 
                if (targetentity.Attributes.Contains("owninguser") && targetentity["owninguser"] != null && ((EntityReference)targetentity["owninguser"]) != null)
                {
                    tracer.Trace("owning user:" + ((EntityReference)targetentity["owninguser"]).Id.ToString());
                    // get the preimage for update operation
                    Entity postimage = (Entity)context.PostEntityImages[POSTIMAGE];
                    if (postimage.Attributes.Contains("niq_recordtype") && postimage["niq_recordtype"] != null)
                        recordtype = ((OptionSetValue)postimage["niq_recordtype"]).Value;
                    // check if the record type is CR/Analytics/NGH
                    if (recordtype == (int)REQUESTRECORDTYPE.Analytics || recordtype == (int)REQUESTRECORDTYPE.ClientResponse || recordtype == (int)REQUESTRECORDTYPE.NGH)
                    {
                        tracer.Trace("owning user updated for the GCD,NGH data");
                        ProcessAssignedDetails(service, targetentity, postimage);
                    }
                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ERRORMESSAGEFAILURE + ex);
            }
        }

        /// <summary>
        /// Get the assigned owner details 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetentity"></param>
        /// <param name="preimage"></param>
        private void ProcessAssignedDetails(IOrganizationService service, Entity targetentity, Entity preimage)
        {
            try
            {
                Guid ownerid = ((EntityReference)targetentity["owninguser"]).Id;
                tracer.Trace("Owner:" + ownerid.ToString());

                // move the BPF status to Assigned stage 
                Guid processid = Guid.Empty;
                Guid instanceid = GetactiveBPFInstanceId(service, targetentity, out processid);
                tracer.Trace("instanceid: " + instanceid.ToString() + " , processid: " + processid.ToString());
                if (processid != Guid.Empty)
                {
                    Guid assignedStage = GetAssignedStageOfBPF(processid, "Assigned", service);
                    tracer.Trace("assigned stageid " + assignedStage.ToString());
                    // Retrieve the stage ID of the next stage that you want to set as active
                    if (assignedStage != Guid.Empty)
                    {
                        // Set the next stage as the active stage
                        UpdateBpfStage(service, instanceid, assignedStage);
                    }

                }
            }
            catch { throw; }
        }

        /// <summary>
        /// MEthod to update the business process flow stage in bpf record 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="instanceid"></param>
        /// <param name="stageid"></param>
        private void UpdateBpfStage(IOrganizationService service, Guid instanceid, Guid stageid)
        {
            try
            {
                Entity updentitybpf = new Entity("phonetocaseprocess", instanceid);
                updentitybpf["activestageid"] = new EntityReference("processstage", stageid);
                service.Update(updentitybpf);
            }
            catch { throw; }
        }

        /// <summary>
        /// GEt the stageid for the Assigned stage from BPF 
        /// </summary>
        /// <param name="processid"></param>
        /// <param name="stagename"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        private Guid GetAssignedStageOfBPF(Guid processid, string stagename, IOrganizationService service)
        {
            Guid assignedstage = Guid.Empty;
            try
            {
                QueryByAttribute query = new QueryByAttribute("processstage");
                query.AddAttributeValue("processid", processid);
                query.AddAttributeValue("stagename", stagename);
                query.ColumnSet = new ColumnSet(new string[] { "stagename" });
                //get the process stage from process
                EntityCollection collection = service.RetrieveMultiple(query);
                if (collection != null && collection.Entities.Count > 0)
                {
                    assignedstage = collection.Entities[0].Id;
                }
            }
            catch { throw; }
            return assignedstage;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetentity"></param>
        /// <returns></returns>
        private Guid GetactiveBPFInstanceId(IOrganizationService service, Entity targetentity, out Guid processid)
        {
            Guid bpfinstanceid = Guid.Empty;
            Guid incidentid = targetentity.Id; processid = Guid.Empty;
            try
            {
                QueryByAttribute query = new QueryByAttribute("phonetocaseprocess");
                query.AddAttributeValue("incidentid", (incidentid));
                query.AddAttributeValue("statecode", 0);
                tracer.Trace("incidentid: " + incidentid.ToString());

                query.ColumnSet = new ColumnSet(new string[] { "processid", "businessprocessflowinstanceid" });
                //
                EntityCollection collection = service.RetrieveMultiple(query);
                if (collection != null && collection.Entities.Count > 0)
                {
                    bpfinstanceid = (Guid)collection.Entities[0]["businessprocessflowinstanceid"];
                    processid = ((EntityReference)collection.Entities[0]["processid"]).Id;
                }
            }
            catch { throw; }
            return bpfinstanceid;
        }


        // 

    }
}
