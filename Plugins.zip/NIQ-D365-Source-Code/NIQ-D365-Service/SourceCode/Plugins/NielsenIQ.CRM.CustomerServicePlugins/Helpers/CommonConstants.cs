﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.CustomerServicePlugins.Helpers
{
    public static class CommonConstants
    {
        // common plugin related constants 
        internal static string POSTIMAGE => "Postimage";
        internal static string PREIMAGE => "Preimage";

        internal static string CREATEOPERATION => "create";
        internal static string TARGET => "Target";
        //request related text values 
        internal static string REQUESTENTITY => "incident";
        internal static string ACCOUNTENTITY => "account";
        internal static string CONTACTENTITY => "contact";

        internal static string NGHTIERENTITY => "niq_nghtier";

        internal static string REQUESTID => "incidentid";

        internal static string NGH => "NGH";
        internal static string NONNGH => "NON NGH";

        // Messages/exception throws from plugins
        internal static string PREVENTFINISHSTAGE => "Request process flow cannot be updated";
        internal static string ERRORMESSAGEFAILURE => "Error occurred while processing the request. ";

        //enum values 
        internal enum PLUGINSTAGE
        {
            PreValidation = 10, PreStage = 20, PostStage = 40
        }
        internal enum REQUESTSTATUSCODE
        {

            New = 100000000,
            Assigned = 100000001,
            InProgress = 1,
            Responded = 5,
            AwaitingDevelopment = 100000004,
            AwaitingHandovertoDevelopment = 100000005,
            AwaitingRequestor = 100000006,
            AwaitingSignOff = 100000007,
            Closed = 100000008,
            AssignmentAccepted = 100000009,
            Cancelled = 100000010,
            Escalated = 100000027,
            LongTermEscalation = 100000028,
            FollowupQuestion = 100000011,
            On = 100000012,
            Open = 100000013,
            PendingAssignment = 100000014,
            PendingClientFeedback = 100000029,
            PendingSubmitterFeedback = 100000030,
            RequestClosed = 100000017,
            RequestReOpened = 100000016,
            WorkinProgress = 100000018,
            PendingCorrectionExecution = 100000019,
            AssessmentEffortEstimation = 100000020,
            ClientSignoff = 100000021,
            ClientSignoffProposalScope = 100000022,
            DevelopmentSolutionDelivery = 100000023,
            QCAgainstSpecsFTD = 100000024,
            SpecificationSignOff = 100000025,
            TimingDefinition = 100000026,
            OnHold = 2,
            WaitingforDetails = 3,
            Researching = 4,
            ClosedOOTB = 6,
            Reopened = 100000003
        }
        internal enum REQUESTSUBSTATUSCODE
        {

            HoldInternal = 100000001,
            HoldExternal = 100000003,
            Working = 100000000,
            HoldInternalLongTermEscalation = 100000010,
            QualityControl = 100000011,
            ReadyforDelivery = 100000012,
            AwaitingDelivery = 100000002,
            SolutionProvided = 100000004,
            NoSolution = 100000005,
            Cancelled = 100000006,
            OutofScope = 100000007,
            ResponseReceived = 100000008,
            NoResponse = 100000009,
            PortalProvisioning = 100000013,
            ProductProvisioning = 100000014,
            PendedPortal = 100000015,
            ErrorPortal = 100000016,
            PendedProduct = 100000017,
            ErrorProduct = 100000018,
            Fulfilled = 100000019,
            ReadyforAgentAction = 100000020,
            AutoProcessed = 100000023,
            Duplicate = 100000021,
            Misdirected = 100000022,
            WorkingOnTime = 100000024,
            WorkingDelayed = 100000025,
            OnHoldSoftwareIssue = 100000026,
            Rejected = 100000027

        }
        internal enum REQUESTSUBSTATUS
        {
            Cancelled = 100000006
        }
        internal enum ROUTINGSTATUS
        {
            NotRouted = 100000000,
            RoutingInProgress = 100000001,
            Routed = 100000002
        }
        internal enum REQUESTRECORDTYPE
        {
            Analytics = 100000000,
            ClientResponse = 100000001,
            NGH = 100000003,
            NGHAM = 100000004
        }
        internal enum REQUESTSTATECODE
        {
            Active = 0,
            Responded = 1,
            Closed = 2
        }
        internal enum BPFStatusValues
        {
            Active = 1,
            Finish = 2
        }

        internal enum PRIORITYCODE
        {

            P1Critical = 100000009,
            P2High = 100000010,
            P3Medium = 100000011,
            P4Low = 100000012,
            P5None = 100000013,
            Critical = 100000008,
            High = 100000005,
            Medium = 100000006,
            Low = 100000007

        }
    }
}
