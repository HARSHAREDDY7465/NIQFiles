﻿/**
 * 
 * 
 *
 * **/


#region [ Includes]
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.CustomerServicePlugins.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static NielsenIQ.CRM.CustomerServicePlugins.Helpers.CommonConstants;
#endregion

namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class BPFStageChangeUpdateCaseStatus : IPlugin
    {
        ITracingService tracer = null;

        /// <summary>
        /// Method to be invoked from plugin method 
        /// </summary>
        /// <param name="serviceProvider"></param>
        public void Execute(IServiceProvider serviceProvider)
        {
            // create service object 
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            //Check the operation is pre or post operation
            switch (context.Stage)
            {
                case (int)PLUGINSTAGE.PreStage:
                    PreventBpfFinishStatus(context);
                    break;
                case (int)PLUGINSTAGE.PostStage:
                    Entity postimage = (Entity)context.PostEntityImages[POSTIMAGE];
                    if (postimage != null && postimage.Attributes.Contains(CommonConstants.REQUESTID) && postimage.Attributes.Contains("activestageid"))
                    {
                        //get incident id and active stage name from BPF 
                        ProcessActiveStage(service, ((EntityReference)postimage[CommonConstants.REQUESTID]).Id, ((EntityReference)postimage["activestageid"]).Name);
                    }
                    break;
            }
        }

        #region [ Private Methods ]

        /// <summary>
        /// Method to prevent the users from  clicking the finish button in the BPF 
        /// </summary>
        /// <param name="context"></param>
        private void PreventBpfFinishStatus(IPluginExecutionContext context)
        {
            Entity target = (Entity)context.InputParameters[TARGET];
            // finished 
            if (target.Attributes.Contains("statuscode") && ((OptionSetValue)target["statuscode"]).Value == (int)BPFStatusValues.Finish)
            {
                //throw new InvalidPluginExecutionException(PREVENTFINISHSTAGE);
            }
        }

        /// <summary>
        /// Method to change the status of the case on changing the sctive stage of the BPF in the request 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="caseid"></param>
        /// <param name="activestagename"></param>
        private void ProcessActiveStage(IOrganizationService service, Guid caseid, string activestagename)
        {
            try
            {
                Entity updcase = new Entity(CommonConstants.REQUESTENTITY, caseid);
                int statecode = 0, substatus = 0, statuscode = 0;
                DateTime currentdt = DateTime.UtcNow;
                int inprogressSubstatus = 0;
                tracer.Trace(" caseid:" + caseid.ToString());
                //Get the active stage name 
                switch (activestagename.ToLower())
                {
                    case "new":
                        statuscode = (int)REQUESTSTATUSCODE.New;
                        UpdateCaseStatus(service, updcase, statecode, statuscode, substatus, 0, 0, currentdt);
                        break;
                    case "assigned":
                        statuscode = (int)REQUESTSTATUSCODE.Assigned;
                        //int routingstatus = GetCaseAssignedStatusValues(service, caseid, out inprogressSubstatus);
                        //if (routingstatus == (int)ROUTINGSTATUS.RoutingInProgress)
                        //{
                        //    updcase["niq_routingstatusvalue"] = new OptionSetValue((int)ROUTINGSTATUS.Routed);
                        //}
                        UpdateCaseStatus(service, updcase, statecode, statuscode, substatus, 0, 0, currentdt);
                        break;
                    case "in progress":
                        statuscode = (int)REQUESTSTATUSCODE.InProgress;
                        GetCaseAssignedStatusValues(service, caseid, out inprogressSubstatus);
                        if (inprogressSubstatus > 0)
                        {
                            substatus = inprogressSubstatus;
                        }
                        UpdateCaseStatus(service, updcase, statecode, statuscode, substatus, 0, 0, currentdt);
                        break;
                    case "responded":
                        DateTime? createdDate = null; int cycledays = 0;
                        // get the responded  substatus from the request  
                        substatus = GetCaseRespondedSubstatus(service, caseid, out createdDate);
                        // when responded substatus is not available , then it indicates the record is cancelled
                        if (substatus == 0)
                            substatus = (int)REQUESTSUBSTATUS.Cancelled;
                        // calculate the cycle time  
                        double cycletime = CalculateCycleTime(service, createdDate, currentdt, out cycledays);
                        // update case status
                        UpdateCaseStatus(service, updcase, 0, 0, substatus, cycledays, cycletime, currentdt);
                        //Update case with substatus value -     statecode = 1; statuscode = 5;
                        //ResolveIncidentRequest(service, caseid, (int)REQUESTSTATECODE.Responded, (int)REQUESTSTATUSCODE.Responded);

                        if (substatus == (int)REQUESTSUBSTATUS.Cancelled)
                        {
                            // Set statuscode = Closed (100000017), statecode = Closed
                            ResolveIncidentRequest(service, caseid, (int)REQUESTSTATECODE.Closed, 1000);
                        }
                        else
                        {
                            // Default logic for responded
                            ResolveIncidentRequest(service, caseid, (int)REQUESTSTATECODE.Responded, (int)REQUESTSTATUSCODE.Responded);
                        }

                        break;
                }
                tracer.Trace("activestgname :" + activestagename);

                tracer.Trace("Status code to be set: " + statuscode);
                tracer.Trace("Substatus to be set: " + substatus);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ERRORMESSAGEFAILURE + ex);
            }
        }


        /// <summary>
        /// Get routing status for the case record 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="caseid"></param>
        /// <returns></returns>
        private int GetCaseAssignedStatusValues(IOrganizationService service, Guid caseid, out int inprogressSubstatus)
        {
            int routingstatus = 0; inprogressSubstatus = 0;
            try
            {
                Entity reqentity = service.Retrieve(CommonConstants.REQUESTENTITY, caseid, new ColumnSet("niq_inprogresssubstatus", "niq_routingstatusvalue"));
                //  check and get the routing status 
                //if (reqentity != null && reqentity.Attributes.Contains("niq_routingstatusvalue"))
                //    routingstatus = ((OptionSetValue)reqentity["niq_routingstatusvalue"]).Value;
                //  check and get the inprogress sub status 
                if (reqentity != null && reqentity.Attributes.Contains("niq_inprogresssubstatus"))
                    inprogressSubstatus = ((OptionSetValue)reqentity["niq_inprogresssubstatus"]).Value;
            }
            catch { throw; }
            return routingstatus;
        }

        /// <summary>
        /// Method to calcualte the cycle time - ie. time diff between responded and created  time  
        /// </summary>
        /// <param name="service"></param>
        /// <param name="createdDate"></param>
        /// <returns></returns>
        private double CalculateCycleTime(IOrganizationService service, DateTime? createdDate, DateTime respondedtime, out int cycledays)
        {
            cycledays = 0;
            double tothours = 0;
            DateTime startDateTime = createdDate.Value; // 8/23 // UTC value 
            DateTime endDateTime = respondedtime; // UTC value  
            DateTime secondDateTime = endDateTime;
            tracer.Trace("Createdon: " + startDateTime.ToString());
            tracer.Trace("endDateTime: " + endDateTime.ToString());

            // if  start date  == end date  then  calculate the hours  
            if (startDateTime.Date == endDateTime.Date)
            {
                TimeSpan tsSameDay = endDateTime.Subtract(startDateTime);
                tothours = tsSameDay.TotalHours;
            }
            else
            {
                // 1.find the remaining hours  today  
                DateTime nextday = startDateTime.AddDays(1);
                DateTime dtstartnextday = new DateTime(nextday.Year, nextday.Month, nextday.Day, 0, 0, 0);
                tothours = dtstartnextday.Subtract(startDateTime).TotalHours;

                nextday = dtstartnextday;
                // while loop that starts with tomorrow and tomorrow is less than end day 
                while (nextday.Date < endDateTime.Date)
                {
                    if (nextday.DayOfWeek != DayOfWeek.Sunday && nextday.DayOfWeek != DayOfWeek.Saturday)
                    {
                        if (nextday.Date != endDateTime.Date)
                        {
                            //tracer.Trace(" start date " + nextday.ToString());
                            //tracer.Trace(" end date " + nextday.AddDays(1).ToString());
                            TimeSpan tsother = (nextday.AddDays(1)) - nextday;
                            tothours = tothours + tsother.TotalHours;
                            // add the number of days
                            cycledays++;
                        }
                    }
                    nextday = nextday.AddDays(1);
                }
                // if we have on the same day 
                if (nextday.Date == endDateTime.Date)
                {
                    cycledays++; // add days  and  calculate  remaining  hours on last day . 
                    DateTime startofday = new DateTime(endDateTime.Year, endDateTime.Month, endDateTime.Day, 0, 0, 0);
                    tothours += endDateTime.Subtract(startofday).TotalHours;
                }
            }
            tracer.Trace("tothours: " + tothours.ToString());
            return tothours;
        }

        /// <summary>
        /// Method to change the status  as Responded/resolved with selected substatus 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="caseid"></param>
        /// <param name="statecode"></param>
        /// <param name="statuscode"></param>
        private void ResolveIncidentRequest(IOrganizationService service, Guid caseid, int statecode, int statuscode)
        {
            try
            {
                tracer.Trace("=== Entered ResolveIncidentRequest ===");
                tracer.Trace("Case ID: " + caseid.ToString());
                tracer.Trace("State Code to be set: " + statecode);
                tracer.Trace("Status Code to be set: " + statuscode);



                Entity incidentresolution = new Entity("incidentresolution");
                incidentresolution["subject"] = "Incident was responded";
                incidentresolution[CommonConstants.REQUESTID] = new EntityReference(CommonConstants.REQUESTENTITY, caseid);
                OrganizationRequest request = new OrganizationRequest()
                {
                    RequestName = "CloseIncident"
                };
                request["IncidentResolution"] = incidentresolution;
                request["Status"] = new OptionSetValue(statuscode);

                tracer.Trace("Executing CloseIncident request...");

                service.Execute(request);

                tracer.Trace("CloseIncident executed successfully.");
            }
            catch { throw; }


        }

        /// <summary>
        ///  Method to update the request with status, statecode and substatus values 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="updcase"></param>
        /// <param name="statuscode"></param>
        /// <param name="statecode"></param>
        private void UpdateCaseStatus(IOrganizationService service, Entity updcase, int statecode, int statuscode, int substatus, int cycledays, double cycletime, DateTime respondedtime)
        {
            try
            {
                if (statuscode != 0)
                {
                    updcase["statecode"] = new OptionSetValue(statecode);
                    updcase["statuscode"] = new OptionSetValue(statuscode);
                }
                //else responded status change 
                else
                {
                    updcase["niq_respondeddatetime"] = respondedtime;// UTC time  
                }
                if (cycletime > 0)
                {
                    updcase["niq_cycletimehours"] = (decimal)cycletime;
                    updcase["niq_cycletimeindays"] = cycledays;
                }
                if (substatus == 0)
                    updcase["niq_substatus"] = null;// clear sub status value 
                else
                    updcase["niq_substatus"] = new OptionSetValue(substatus);
                service.Update(updcase);
            }
            catch { throw; }
        }

        /// <summary>
        /// Get the responded substatus 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="caseid"></param>
        private int GetCaseRespondedSubstatus(IOrganizationService service, Guid caseid, out DateTime? createdDate)
        {
            int substatus = 0; createdDate = null;
            try
            {
                Entity reqentity = service.Retrieve(CommonConstants.REQUESTENTITY, caseid, new ColumnSet("niq_respondedsubstatus", "createdon", "niq_isrejected"));
                createdDate = ((DateTime)reqentity["createdon"]);

                if (reqentity.Attributes.Contains("niq_isrejected") && (bool)reqentity["niq_isrejected"])
                {
                    //substatus = ((OptionSetValue)reqentity["niq_respondedsubstatus"]).Value;
                    substatus = 100000027;
                }
                else if (reqentity != null && reqentity.Attributes.Contains("niq_respondedsubstatus"))
                {
                    substatus = ((OptionSetValue)reqentity["niq_respondedsubstatus"]).Value;
                }
            }
            catch { throw; }
            return substatus;
        }

        #endregion
    }

}
