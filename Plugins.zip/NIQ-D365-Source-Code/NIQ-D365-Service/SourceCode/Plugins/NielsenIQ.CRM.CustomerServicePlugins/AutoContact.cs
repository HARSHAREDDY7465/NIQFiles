﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using Microsoft.Xrm.Sdk.Query;


namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class AutoContact : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {

            ITracingService tracingService =
    (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory factory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

            Guid newGuid = Guid.Parse((string)context.InputParameters["userid"]);
            //  context.UserId;
            //Guid.Parse("C57CAC41-9A56-EC11-8F8F-000D3A128147");
            IOrganizationService service =
                factory.CreateOrganizationService(newGuid);



            try
            {

                QueryExpression query = new QueryExpression("niq_serviceroutinglanguages");
                string[] cols = { "niq_serviceroutinglanguagesid", "niq_name" };
                query.Criteria = new FilterExpression();
                query.Criteria.AddCondition("niq_name", ConditionOperator.Equal, "English");
                query.ColumnSet = new ColumnSet(cols);
                var languages = service.RetrieveMultiple(query);
                //Casting the reference to GUID
                Guid businessLanguage = (Guid)languages[0].Attributes["niq_serviceroutinglanguagesid"];
                // var firstname = c(string)context.InputParameters["firstname"];
                //newGuid = newuserid;
                // Guid newGuid = context.UserId;
                //Guid.Parse("C57CAC41-9A56-EC11-8F8F-000D3A128147");
                // IOrganizationService service =
                //   factory.CreateOrganizationService(newGuid);



                var firstname = (string)context.InputParameters["firstname"];
                var lastname = (string)context.InputParameters["lastname"];
                var email = (string)context.InputParameters["email"];

                Entity contact = new Entity("contact");
                contact["lastname"] = lastname;
                contact["firstname"] = firstname;
                contact["emailaddress1"] = email;
                string regardingobjectidType = "niq_serviceroutinglanguages";
                contact["niq_businesslanguageserviceid"] = new EntityReference(regardingobjectidType, businessLanguage);
                contact["niq_contactrecordtype"] = true;
                contact["niq_preferredlanguage"] = new OptionSetValue(Convert.ToInt32(1022));

                Guid crm = service.Create(contact);
                context.OutputParameters["output"] = crm.ToString();
            }


            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw new InvalidPluginExecutionException("An error occurred in FollowUpPlugin." + ex.ToString(), ex);
            }
            catch (Exception ex)
            {
                tracingService.Trace("FollowUpPlugin: {0}", ex.ToString());
                throw;
            }



        }
    }
}
