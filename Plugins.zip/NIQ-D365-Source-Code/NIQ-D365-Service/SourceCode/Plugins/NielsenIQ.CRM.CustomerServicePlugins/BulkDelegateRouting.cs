﻿#region [ Includes]
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.CustomerServicePlugins.Helpers;
using static NielsenIQ.CRM.CustomerServicePlugins.Helpers.CommonConstants;
using System;
using System.Collections.Generic;

#endregion

namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class BulkDelegateRouting : IPlugin
    {
        ITracingService tracer = null;

        /// <summary>
        /// Method to be invoked from plugin method 
        /// </summary>
        /// <param name="serviceProvider"></param>
        public void Execute(IServiceProvider serviceProvider)
        {
            // create service object 
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            try
            {
                
                Entity BRR = (Entity)context.InputParameters[TARGET];

                Guid brrid = BRR.Id;

                Entity delegaterouting = service.Retrieve("niq_bulkrequestrouting", brrid, new ColumnSet("niq_requestid", "niq_primarycontactid"));

               


                if (delegaterouting!=null)
                {
                   string requestids = delegaterouting.Attributes["niq_requestid"].ToString();
                    string[] stringSeparators = new string[] { "," };
                    string[] requestidresult = requestids.Split(stringSeparators, StringSplitOptions.None);

                    ////update loggedin contact to cloning request
                    Guid contactid = Guid.Empty;
                    if (delegaterouting.Attributes.Contains("niq_primarycontactid") && delegaterouting["niq_primarycontactid"] != null && (EntityReference)delegaterouting["niq_primarycontactid"] != null) // check ngh tier  
                    {
                        contactid = ((EntityReference)delegaterouting.Attributes["niq_primarycontactid"]).Id;
                        tracer.Trace("contactid" + contactid);
                    }

                  
                    

                    foreach (string reqid in requestidresult)
                    {
                        tracer.Trace("request: " + reqid);
                        Entity parentrequest = new Entity("incident");
                        Guid reqGuid= Guid.Empty;
                        reqGuid = Guid.Parse(reqid);
                        parentrequest = service.Retrieve("incident", reqGuid, new ColumnSet("incidentid", 
                            "customerid", "primarycontactid", "niq_topicid", "title", "caseorigincode", "niq_businessquestion", "niq_yourhypothesis", "niq_expecteddecisions"
                            , "niq_activitytypeid", "niq_activitysubtypeid", "niq_plannedstartdate", "niq_plannedenddate", "niq_totalplannedefforts", "niq_frequency",
                            "niq_multiclient", "niq_numberofclients", "niq_targetaudience", "niq_deliverymode", "niq_numberofcountries", "niq_numberofcategories",
                            "niq_numberofbusinessissueanalysis", "niq_serviceproducts", "niq_guidedanalyticsused",
                            "niq_clientoutcomeorclientbusinessopportunity", "niq_numberofdatabases", "niq_numberofperformanceoverview", "niq_numberofslidespagestabs", "niq_businesstopicsincluded", "niq_guidedanalyticscontent", "niq_analyticscomments"));

                        tracer.Trace("test2: " + reqid);
                        parentrequest.Attributes.Remove("incidentid");
                        parentrequest.Attributes.Remove("primarycontactid");
                        parentrequest.Id = Guid.NewGuid();
                        parentrequest.Attributes.Remove("niq_recordtype");
                        OptionSetValue option = new OptionSetValue(100000002);
                        parentrequest.Attributes["niq_recordtype"] = option;
                        parentrequest.Attributes["parentcaseid"] = new EntityReference("incident", reqGuid);
                       parentrequest.Attributes["primarycontactid"] = new EntityReference("contact", contactid);
                        parentrequest.Attributes["niq_bulkdelegateroutingid"] = new EntityReference("niq_bulkrequestrouting", brrid);
                        //parentrequest.Attributes["customerid"] = new EntityReference("account", reqGuid);
                        //parentrequest.Attributes["customerid"] = new EntityReference("account", reqGuid);
                        //parentrequest.Attributes["niq_periods"] = "0";
                        tracer.Trace("test3: " + reqid);

                        service.Create(parentrequest);









                    }

                }


            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ERRORMESSAGEFAILURE + ex);
            }

        }
    }
}
    
