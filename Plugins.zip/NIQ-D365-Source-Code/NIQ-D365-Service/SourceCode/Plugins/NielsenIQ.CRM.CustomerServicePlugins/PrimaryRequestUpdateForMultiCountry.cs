﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class PrimaryRequestUpdateForMultiCountry : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {

            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {

                try
                {
                    Entity Requestobj = (Entity)context.InputParameters["Target"];
                    tracingService.Trace("caseorigin" + Requestobj.GetAttributeValue<OptionSetValue>("caseorigincode").Value);

                    if (Requestobj.Contains("caseorigincode") && Requestobj.GetAttributeValue<OptionSetValue>("caseorigincode").Value == 100000087 && Requestobj.GetAttributeValue<bool>("niq_createrequestforsecondaryaccounts") == false)
                    {
                        Entity UpdateRequest = new Entity("incident", context.PrimaryEntityId);
                        tracingService.Trace("contextid" + context.PrimaryEntityId);
                        UpdateRequest["niq_primaryrequestformulticountryrequest"] = new EntityReference("incident", context.PrimaryEntityId);
                        tracingService.Trace("Case Create update");
                        service.Update(UpdateRequest);

                    }

                }
                catch (Exception ex)
                {
                    throw new InvalidPluginExecutionException(ex.Message);
                }
            }
        }
    }
}
