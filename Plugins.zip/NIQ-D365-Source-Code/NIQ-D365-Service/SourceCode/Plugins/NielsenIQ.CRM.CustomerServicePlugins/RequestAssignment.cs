﻿#region [ Includes]
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.CustomerServicePlugins.Helpers;
using static NielsenIQ.CRM.CustomerServicePlugins.Helpers.CommonConstants;
using System;
using System.Collections.Generic;

#endregion

namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class RequestAssignment : IPlugin
    {
        ITracingService tracer = null;

        /// <summary>
        /// Method to be invoked from plugin method 
        /// </summary>
        /// <param name="serviceProvider"></param>
        public void Execute(IServiceProvider serviceProvider)
        {
            // create service object 
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            try {
                // To check depth   
                if (context.Depth > 2) return;

               

                    if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
                    {
                        // Business logic goes here  
                        new RequestAssignment().BusinessLogic(service, context);
                    }
                
            }


            catch (Exception ex)
            {
                 
                throw new InvalidPluginExecutionException("You cannot use a test user and contact");
                //throw new InvalidPluginExecutionException(ERRORMESSAGEFAILURE + ex);
            


        }

        }


        private void BusinessLogic(IOrganizationService service, IExecutionContext context)
        {
            try
            {
                // We are hitting Assign button on a request record 
                var requestreference = (EntityReference)context.InputParameters["Target"];

                // Assignee could be a User or Team    
                var userEntityReference = (EntityReference)context.InputParameters["Assignee"];

                // In our requirement it should be a User, otherwise return    
                if (userEntityReference.LogicalName != "systemuser") return;



                var fetchXmluserr = @"  
              <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>  
                <entity name='systemuser'>  
                  <attribute name='systemuserid' />               
                      <filter type='and'>  
                        <condition attribute='systemuserid' operator='eq' uitype='systemuser' value='{0}' />      
                      </filter>  
    <link-entity name='systemuserroles' from='systemuserid' to='systemuserid' visible='false' intersect='true'>
          <link-entity name='role' from='roleid' to='roleid' alias='aw'>
            <filter type='and'>
              <condition attribute='name' operator='eq' value='System Administrator' />
            </filter>
          </link-entity>
        </link-entity>
                </entity>  
              </fetch>";
                Guid userId = context.UserId;

                var loggedinusersisadmin = service.RetrieveMultiple(new FetchExpression(string.Format(
                                   fetchXmluserr,
                                   userId))).Entities;
                if (loggedinusersisadmin.Count == 0)
                {

                    // fetchXml to retrieve all the users with Department Test and non admin
                    var fetchXmltestuser = @"  
          <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>  
            <entity name='systemuser'>  
              <attribute name='systemuserid' />               
                  <filter type='and'>  
                    <condition attribute='systemuserid' operator='eq' uitype='systemuser' value='{0}' /> 
      <condition attribute='niq_department' operator='like' value='%Test User%' />
                  </filter>  
            </entity>  
          </fetch>";

                    // Passing current Team is fetchXml and retrieving Team's user  
                    var testusers = service.RetrieveMultiple(new FetchExpression(string.Format(
                        fetchXmltestuser,
                        userEntityReference.Id))).Entities;

                    // If user count is zero case should be assigned to Team's default Queue  
                    if (testusers.Count != 0)
                    {
                        Entity preimagerequest = null;
                        preimagerequest = (Entity)context.PreEntityImages[PREIMAGE];
                        Guid preownerid = ((Microsoft.Xrm.Sdk.EntityReference)preimagerequest.Attributes["ownerid"]).Id;


                        //var status = ((Microsoft.Xrm.Sdk.OptionSetValue)preimagerequest.Attributes["statecode"]).Value;
                        //tracer.Trace("status" + status);
                        //throw new InvalidPluginExecutionException("test");
                        // fetchXml to retrieve all the users in a given Team  
                        var fetchXmlcheckifitsteam = @"  
          <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>  
            <entity name='systemuser'>  
              <attribute name='systemuserid' />               
                  <filter type='and'>  
                    <condition attribute='systemuserid' operator='eq' uitype='systemuser' value='{0}' />      
                  </filter>                  
            </entity>  
          </fetch>";

                        var ispreowneruser = service.RetrieveMultiple(new FetchExpression(string.Format(
                        fetchXmlcheckifitsteam,
                        preownerid))).Entities;

                        if (ispreowneruser.Count == 1)
                        {

                            preimagerequest.Attributes["ownerid"] = new EntityReference("systemuser", preownerid);
                        }
                        else { preimagerequest.Attributes["ownerid"] = new EntityReference("team", preownerid); }

                        Entity notification = new Entity("appnotification");

                        notification["title"] = "You cannot use a test user and contact";
                        notification["ttlinseconds"] = 1200;

                        service.Update(preimagerequest);
                        // service.Create(notification);
                        throw new InvalidPluginExecutionException("You cannot use a test user and contact");


                    }
                }
            }

            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("You cannot use a test user and contact");
                //throw new InvalidPluginExecutionException(ERRORMESSAGEFAILURE + ex);
            }



        }

            
    }
}

