﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.CustomerServicePlugins.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static NielsenIQ.CRM.CustomerServicePlugins.Helpers.CommonConstants;

namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class CreateUpdateFieldHistory : IPlugin
    {
        ITracingService tracer = null; public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService)); try
            {
                Entity targetentity = (Entity)context.InputParameters[TARGET];
                Guid requestIdGuid = targetentity.Id;
                tracer.Trace("Guid id of Current request: " + requestIdGuid.ToString());

                if (context.MessageName.ToLower() == "create")
                {
                    Entity contextEntity = null;
                    contextEntity = (Entity)context.InputParameters["Target"];
                    if (contextEntity.LogicalName != "incident" || requestIdGuid == null)
                    {
                        return;
                    }

                    tracer.Trace("Entering Create Mode");

                    string reqNumber = (contextEntity.Contains("ticketnumber") && contextEntity.GetAttributeValue<String>("ticketnumber") != null) ? contextEntity.GetAttributeValue<String>("ticketnumber") : null;

                    int reqStatus = (contextEntity.Attributes.Contains("statuscode") && contextEntity.GetAttributeValue<OptionSetValue>("statuscode") != null) ? contextEntity.GetAttributeValue<OptionSetValue>("statuscode").Value : 0;
                    int reqSubStatus = (contextEntity.Attributes.Contains("niq_substatus") && contextEntity.GetAttributeValue<OptionSetValue>("niq_substatus") != null) ? contextEntity.GetAttributeValue<OptionSetValue>("niq_substatus").Value : 0;

                    Guid reqOwnerid = contextEntity.GetAttributeValue<EntityReference>("ownerid").Id;
                    string reqOwner = (reqOwnerid.ToString() != Guid.Empty.ToString()) ? GetUserFullName(service, tracer, reqOwnerid.ToString()) : null;

                    Guid reqModifiedbyid = (contextEntity.Attributes.Contains("modifiedby") && contextEntity.GetAttributeValue<EntityReference>("modifiedby").Id != null) ?
                       contextEntity.GetAttributeValue<EntityReference>("modifiedby").Id : Guid.Empty;
                    string reqModifiedBy = reqModifiedbyid.ToString();

                    DateTime reqModifiedOn = contextEntity.GetAttributeValue<DateTime>("modifiedon");
                    DateTime reqCreatedOn = contextEntity.GetAttributeValue<DateTime>("createdon");
                    Guid reqParentCaseId = (contextEntity.Attributes.Contains("parentcaseid") && contextEntity.GetAttributeValue<EntityReference>("parentcaseid").Id != null) ? contextEntity.GetAttributeValue<EntityReference>("parentcaseid").Id : Guid.Empty;
                    string parentreqNumber = (reqParentCaseId.ToString() != Guid.Empty.ToString()) ? GetParentCaseNumber(service, tracer, reqParentCaseId.ToString()) : null;

                    if (parentreqNumber != null)
                    {
                        tracer.Trace("reqParentCaseId: " + reqParentCaseId.ToString());
                        string response1 = CreateFieldHistory(service, tracer, requestIdGuid, reqModifiedBy, parentreqNumber, "", reqModifiedOn, "Parent Request", "parentcaseid", reqOwnerid.ToString());
                        tracer.Trace("Field History for Parent Request created successfully in Create Mode");
                    }
                    else
                    {
                        tracer.Trace("reqParentCaseId: " + reqParentCaseId.ToString());
                        string response1 = CreateFieldHistory(service, tracer, requestIdGuid, reqModifiedBy, "", "", reqModifiedOn, "Parent Request", "parentcaseid", reqOwnerid.ToString());
                        tracer.Trace("Field History for Parent Request created successfully in Create Mode");
                    }

                    if (reqModifiedOn == reqCreatedOn && reqParentCaseId != Guid.Empty)
                    {
                        tracer.Trace("reqParentCaseId: " + reqParentCaseId.ToString());
                        string response2 = CreateFieldHistory(service, tracer, requestIdGuid, reqModifiedBy, reqNumber, "", reqModifiedOn, "Child Request", "childrequest", reqOwnerid.ToString());
                        tracer.Trace("Field History for Child Request created successfully in Create Mode");
                    }
                    if (!string.IsNullOrEmpty(reqOwner))
                    {
                        tracer.Trace("reqOwner: " + reqOwner);
                        string response3 = CreateFieldHistory(service, tracer, requestIdGuid, reqModifiedBy, reqOwner, "", reqModifiedOn, "Request Owner", "ownerid", reqOwnerid.ToString());
                        tracer.Trace("Field History for Request Owner created successfully in Create Mode");
                    }
                    if (reqStatus != 0)
                    {
                        tracer.Trace("reqStatus: " + reqStatus);
                        string requestStatusName = contextEntity.FormattedValues["statuscode"];
                        string response4 = CreateFieldHistory(service, tracer, requestIdGuid, reqModifiedBy, requestStatusName, "", reqModifiedOn, "Status", "statuscode", reqOwnerid.ToString());
                        tracer.Trace("Field History for Status created successfully in Create Mode");
                    }
                    if (reqSubStatus != 0)
                    {
                        string requestSubStatusName = contextEntity.FormattedValues["niq_substatus"];
                        if (requestSubStatusName != null)
                        {
                            string response5 = CreateFieldHistory(service, tracer, requestIdGuid, reqModifiedBy, requestSubStatusName, "", reqModifiedOn, "Sub-Status", "niq_substatus", reqOwnerid.ToString());
                            tracer.Trace("Field History for Sub-Status created successfully in Create Mode");
                        }
                    }
                    else
                    {
                        string response5 = CreateFieldHistory(service, tracer, requestIdGuid, reqModifiedBy, "", "", reqModifiedOn, "Sub-Status", "niq_substatus", reqOwnerid.ToString());
                        tracer.Trace("Field History for Sub-Status created successfully in Create Mode");
                    }
                    tracer.Trace("reqSubStatus: " + reqSubStatus);

                    int reqPriority = (contextEntity.Attributes.Contains("prioritycode") && contextEntity.GetAttributeValue<OptionSetValue>("prioritycode") != null) ?
                        contextEntity.GetAttributeValue<OptionSetValue>("prioritycode").Value : 0;
                    tracer.Trace("reqPriority: " + reqPriority.ToString());

                    int reqRectype = (contextEntity.Attributes.Contains("niq_recordtype") && contextEntity.GetAttributeValue<OptionSetValue>("niq_recordtype") != null) ?
                       contextEntity.GetAttributeValue<OptionSetValue>("niq_recordtype").Value : 0;
                    tracer.Trace("reqRectype: " + reqRectype.ToString());

                    if (reqPriority != 0)
                    {
                        tracer.Trace("Entering Priority");
                        string reqPriorityName = GetPriorityCodeName(reqPriority);

                        if (!string.IsNullOrEmpty(reqPriorityName))
                        {
                            if (reqRectype == 100000001 || reqRectype == 100000008 || reqRectype == 100000006 || reqRectype == 100000005)
                            {
                                string response = CreateFieldHistory(service, tracer, requestIdGuid, reqModifiedBy, reqPriorityName, "", reqModifiedOn, "Priority", "prioritycode", reqOwnerid.ToString());
                                tracer.Trace("Field History for Status created successfully in Update Mode");
                            }

                        }
                    }

                    tracer.Trace("Exiting Create Mode");
                }

                if (context.MessageName.ToLower() == "update")
                {
                    Entity contextEntity = null;
                    contextEntity = (Entity)context.InputParameters["Target"];
                    if (contextEntity.LogicalName != "incident" || requestIdGuid == null)
                    {
                        return;
                    }

                    tracer.Trace("Entering Update Mode");
                    tracer.Trace("Getting Context values");

                    Guid reqOwnerid = (contextEntity.Attributes.Contains("ownerid") && contextEntity.GetAttributeValue<EntityReference>("ownerid").Id != null) ?
                        contextEntity.GetAttributeValue<EntityReference>("ownerid").Id : Guid.Empty;
                    tracer.Trace("reqOwnerid: " + reqOwnerid.ToString());
                    string contextreqOwner = (reqOwnerid.ToString() != Guid.Empty.ToString()) ? GetUserFullName(service, tracer, reqOwnerid.ToString()) : null;
                    tracer.Trace("contextreqOwner: " + contextreqOwner);

                    Guid reqModifiedbyid = (contextEntity.Attributes.Contains("modifiedby") && contextEntity.GetAttributeValue<EntityReference>("modifiedby").Id != null) ?
                        contextEntity.GetAttributeValue<EntityReference>("modifiedby").Id : Guid.Empty;
                    string contextreqModifiedBy = reqModifiedbyid.ToString();
                    tracer.Trace("contextreqModifiedBy: " + contextreqModifiedBy);

                    DateTime reqModifiedOn = (contextEntity.Attributes.Contains("modifiedon") && contextEntity.GetAttributeValue<DateTime>("modifiedon") != null) ?
                        contextEntity.GetAttributeValue<DateTime>("modifiedon") : DateTime.Now;
                    tracer.Trace("reqModifiedOn: " + reqModifiedOn);


                    int contextreqStatus = (contextEntity.Attributes.Contains("statuscode") && contextEntity.GetAttributeValue<OptionSetValue>("statuscode") != null) ?
                        contextEntity.GetAttributeValue<OptionSetValue>("statuscode").Value : 0;
                    tracer.Trace("contextreqStatus: " + contextreqStatus.ToString());

                    int contextreqSubStatus = (contextEntity.Attributes.Contains("niq_substatus") && contextEntity.GetAttributeValue<OptionSetValue>("niq_substatus") != null) ?
                        contextEntity.GetAttributeValue<OptionSetValue>("niq_substatus").Value : 0;

                    int contextreqPriority = (contextEntity.Attributes.Contains("prioritycode") && contextEntity.GetAttributeValue<OptionSetValue>("prioritycode") != null) ?
                       contextEntity.GetAttributeValue<OptionSetValue>("prioritycode").Value : 0;
                    tracer.Trace("contextreqPriority: " + contextreqPriority.ToString());

                    tracer.Trace("Getting PreImage Values");
                    Entity preimage = new Entity();
                    if (context.PreEntityImages.Contains("PreImage"))
                    {
                        preimage = (Entity)context.PreEntityImages["PreImage"];
                    }

                    Guid preimagereqOwnerid = (preimage.Attributes.Contains("ownerid") && preimage.GetAttributeValue<EntityReference>("ownerid").Id != null) ?
                        preimage.GetAttributeValue<EntityReference>("ownerid").Id : Guid.Empty;
                    string preimagereqOwner = GetUserFullName(service, tracer, preimagereqOwnerid.ToString());
                    tracer.Trace("preimagereqOwner: " + preimagereqOwner);

                    int preimagereqStatus = (preimage.Attributes.Contains("statuscode") && preimage.GetAttributeValue<OptionSetValue>("statuscode") != null) ?
                        preimage.GetAttributeValue<OptionSetValue>("statuscode").Value : 0;
                    tracer.Trace("preimagereqStatus: " + preimagereqStatus.ToString());

                    int preimagereqSubStatus = (preimage.Attributes.Contains("niq_substatus") && preimage.GetAttributeValue<OptionSetValue>("niq_substatus") != null) ?
                        preimage.GetAttributeValue<OptionSetValue>("niq_substatus").Value : 0;

                    int preimagereqPrioritycode = (preimage.Attributes.Contains("prioritycode") && preimage.GetAttributeValue<OptionSetValue>("prioritycode") != null) ?
                       preimage.GetAttributeValue<OptionSetValue>("prioritycode").Value : 0;

                    int preimagereqRectype = (preimage.Attributes.Contains("niq_recordtype") && preimage.GetAttributeValue<OptionSetValue>("niq_recordtype") != null) ?
                        preimage.GetAttributeValue<OptionSetValue>("niq_recordtype").Value : 0;
                    tracer.Trace("preimagereqRectype: " + preimagereqRectype.ToString());

                    tracer.Trace("Entering Comparison and creation");

                        // Ensure 'parentcaseid' is in the current update
                        if (contextEntity.Attributes.Contains("parentcaseid"))
                        {
                            // Get the current and previous values of 'parentcaseid'
                            EntityReference contextParentRef = contextEntity.GetAttributeValue<EntityReference>("parentcaseid");
                            Guid contextreqParentCaseId = contextParentRef != null ? contextParentRef.Id : Guid.Empty;

                            // Check pre-image: Handle the case when parentcaseid is cleared (set to Guid.Empty)
                            EntityReference preimageParentRef = preimage.Contains("parentcaseid") ? preimage.GetAttributeValue<EntityReference>("parentcaseid") : null;
                            Guid preimagereqParentCaseId = preimageParentRef != null ? preimageParentRef.Id : Guid.Empty;

                            // If parentcaseid has been updated (whether to a new value or cleared)
                            if (contextreqParentCaseId != preimagereqParentCaseId)
                            {
                                // Track change when 'parentcaseid' is updated, including when it's cleared (set to Guid.Empty)
                                tracer.Trace("ParentCaseId has been updated or cleared, creating field history.");

                                string newParentRequest = contextreqParentCaseId != Guid.Empty ? GetParentCaseNumber(service, tracer, contextreqParentCaseId.ToString()) : null;
                                string oldParentRequest = preimagereqParentCaseId != Guid.Empty ? GetParentCaseNumber(service, tracer, preimagereqParentCaseId.ToString()) : null;

                                string response = CreateFieldHistory(service,tracer,requestIdGuid,contextreqModifiedBy,newParentRequest,oldParentRequest,reqModifiedOn,"Parent Request","parentcaseid",reqOwnerid.ToString());

                                tracer.Trace("Field History for Parent Request created successfully.");
                            }
                            else
                            {
                                // If no change (parentcaseid remains the same), no field history creation
                                tracer.Trace("ParentCaseId has not changed, skipping field history.");
                            }
                        }
                    if (contextreqOwner != null && contextreqOwner != preimagereqOwner)
                    {
                        tracer.Trace("Entering reqOwner");
                        string response = CreateFieldHistory(service, tracer, requestIdGuid, contextreqModifiedBy, contextreqOwner, preimagereqOwner, reqModifiedOn, "Request Owner", "ownerid", reqOwnerid.ToString());
                        tracer.Trace("Field History for Request Owner created successfully in Update Mode");
                    }
                    if (contextreqStatus != 0 && contextreqStatus != preimagereqStatus)
                    {
                        tracer.Trace("Entering status");
                        string contextreqStatusName = GetStatusCodeName(contextreqStatus);
                        string preimagereqStatusName = GetStatusCodeName(preimagereqStatus);
                        if (!string.IsNullOrEmpty(contextreqStatusName) && !string.IsNullOrEmpty(preimagereqStatusName))
                        {
                            string response = CreateFieldHistory(service, tracer, requestIdGuid, contextreqModifiedBy, contextreqStatusName, preimagereqStatusName, reqModifiedOn, "Status", "statuscode", reqOwnerid.ToString());
                            tracer.Trace("Field History for Status created successfully in Update Mode");
                        }
                    }
                    if (contextreqSubStatus != 0 && contextreqSubStatus != preimagereqSubStatus)
                    {
                        tracer.Trace("Entering sub-status");
                        tracer.Trace("contextreqSubStatus: " + contextreqSubStatus.ToString());
                        tracer.Trace("preimagereqSubStatus: " + preimagereqSubStatus.ToString());

                        string contextreqSubStatusName = GetSubStatusCodeName(contextreqSubStatus);
                        string preimagereqSubStatusName = GetSubStatusCodeName(preimagereqSubStatus);

                        tracer.Trace("contextreqSubStatusName: " + contextreqSubStatusName.ToString());
                        tracer.Trace("preimagereqSubStatusName: " + preimagereqSubStatusName.ToString());

                        if (!string.IsNullOrEmpty(contextreqSubStatusName))
                        {
                            string response = CreateFieldHistory(service, tracer, requestIdGuid, contextreqModifiedBy, contextreqSubStatusName, preimagereqSubStatusName, reqModifiedOn, "Sub-Status", "niq_substatus", reqOwnerid.ToString());
                            tracer.Trace("Field History for Sub-Status created successfully in Update Mode");
                        }
                    }

                    if (contextreqPriority != 0 && contextreqPriority != preimagereqPrioritycode)
                    {
                        tracer.Trace("Entering Priority");
                        string contextreqPriorityName = GetPriorityCodeName(contextreqPriority);
                        string preimagereqPrioritycodeName = GetPriorityCodeName(preimagereqPrioritycode);
                        if (!string.IsNullOrEmpty(contextreqPriorityName) && !string.IsNullOrEmpty(preimagereqPrioritycodeName))
                        {
                            if (preimagereqRectype == 100000001 || preimagereqRectype == 100000008 || preimagereqRectype == 100000006 || preimagereqRectype == 100000005)
                            {
                                string response = CreateFieldHistory(service, tracer, requestIdGuid, contextreqModifiedBy, contextreqPriorityName, preimagereqPrioritycodeName, reqModifiedOn, "Priority", "prioritycode", reqOwnerid.ToString());
                                tracer.Trace("Field History for Status created successfully in Update Mode");
                            }

                        }
                    }


                    tracer.Trace("Exiting Update Mode");
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ERRORMESSAGEFAILURE + ex);
            }
        }

        public string CreateFieldHistory(IOrganizationService service, ITracingService tracer, Guid targetId, string updatedUser, string newvalue, string oldvalue, DateTime updatedDatetime, string subject, string fieldapiname, string regReqOwner)
        {
            try
            {
                //tracer.Trace("CreateFieldHistory newvalue: " + Convert.ToString(newvalue));
                //tracer.Trace("CreateFieldHistory oldvalue: " + Convert.ToString(oldvalue));
                tracer.Trace("CreateFieldHistory fieldapiname: " + fieldapiname.ToString());

                Entity fieldHistory = new Entity("niq_fieldhistory");
                fieldHistory["niq_userwhoupdated"] = new EntityReference("systemuser", Guid.Parse(updatedUser));
                fieldHistory["niq_newvalue"] = newvalue;
                fieldHistory["niq_oldvalue"] = oldvalue;
                fieldHistory["niq_datetimechanged"] = updatedDatetime;
                fieldHistory["subject"] = subject;
                fieldHistory["niq_fieldapiname"] = fieldapiname;
                fieldHistory["niq_tabletype"] = "Request";
                if (regReqOwner != null && !string.IsNullOrEmpty(regReqOwner) && regReqOwner != "00000000-0000-0000-0000-000000000000")
                {
                    tracer.Trace("CreateFieldHistory - FetchXML");
                    Guid regreqOwnerId = Guid.Parse(regReqOwner);
                    var fetchXml = @"  
                                  <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>  
                                    <entity name='systemuser'>  
                                      <attribute name='systemuserid' />               
                                          <filter type='and'>  
                                            <condition attribute='systemuserid' operator='eq' uitype='systemuser' value='{0}' />      
                                          </filter>                  
                                    </entity>  
                                  </fetch>";

                    var user = service.RetrieveMultiple(new FetchExpression(string.Format(
                    fetchXml,
                    regreqOwnerId))).Entities;
                    if (user.Count == 1)
                    {
                        tracer.Trace("CreateFieldHistory - Entering systemuser");
                        fieldHistory["niq_regardingrequestowner"] = new EntityReference("systemuser", regreqOwnerId);
                    }

                }
                else if (regReqOwner == "00000000-0000-0000-0000-000000000000")
                {
                    fieldHistory["niq_regardingrequestowner"] = new EntityReference("systemuser", Guid.Parse(updatedUser));
                }

                if (targetId != null)
                {
                    string regardingobjectidType = "incident";
                    fieldHistory["regardingobjectid"] = new EntityReference(regardingobjectidType, targetId);
                }
                //var crm = service.Create(fieldHistory);
                //tracer.Trace("CreateFieldHistory - fieldHistory :  " + fieldHistory.ToString());
                Guid fieldHistoryGuid = service.Create(fieldHistory);
                tracer.Trace("Field History created successfully with Guid Id: " + fieldHistoryGuid.ToString());
            }
            catch (Exception ex)
            {
                //throw ex;
                tracer.Trace("Exception in CreateFieldHistory: " + ex.Message);
            }
            return "";
        }

        public string GetUserFullName(IOrganizationService service, ITracingService tracer, string userGuid)
        {
            string userFullName = string.Empty;
            tracer.Trace("GetUserFullName - userguid: " + userGuid);
            try
            {
                if (userGuid != null)
                {
                    var query1 = new QueryExpression("systemuser")
                    {
                        ColumnSet = new ColumnSet(true),
                        Criteria =
                            {
                                Conditions =
                                {
                                    new ConditionExpression("systemuserid", ConditionOperator.Equal, userGuid)
                                }
                            }
                    };
                    var entitylistUser = service.RetrieveMultiple(query1);
                    if (entitylistUser != null && entitylistUser.Entities.Count > 0)
                    {
                        tracer.Trace("GetUserFullName - Entering systemuser");
                        if (entitylistUser.Entities[0] != null)
                        {
                            userFullName = entitylistUser.Entities[0].Attributes["fullname"].ToString();
                        }
                    }
                    else
                    {
                        tracer.Trace("GetUserFullName - Entering team");
                        var query2 = new QueryExpression("team")
                        {
                            ColumnSet = new ColumnSet(true),
                            Criteria =
                            {
                                Conditions =
                                {
                                    new ConditionExpression("teamid", ConditionOperator.Equal, userGuid)
                                }
                            }
                        };
                        var entitylistTeam = service.RetrieveMultiple(query2);
                        if (entitylistTeam != null)
                        {
                            if (entitylistTeam.Entities[0] != null)
                            {
                                userFullName = entitylistTeam.Entities[0].Attributes["name"].ToString();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                tracer.Trace("Exception in GetUserFullName: " + ex.Message);
                throw;
            }
            return userFullName;
        }

        public string GetParentCaseNumber(IOrganizationService service, ITracingService tracer, string parentCaseGuid)
        {
            string CaseNumber = string.Empty;
            try
            {
                if (parentCaseGuid != null)
                {
                    var query1 = new QueryExpression("incident")
                    {
                        ColumnSet = new ColumnSet(true),
                        Criteria =
                            {
                                Conditions =
                                {
                                    new ConditionExpression("incidentid", ConditionOperator.Equal, parentCaseGuid)
                                }
                            }
                    };
                    var entitylist = service.RetrieveMultiple(query1);
                    if (entitylist.Entities[0] != null)
                    {
                        CaseNumber = entitylist.Entities[0].Attributes["ticketnumber"].ToString();
                    }
                }

            }
            catch (Exception ex)
            {
                tracer.Trace("Exception in GetUserFullName: " + ex.Message);
                throw;
            }
            return CaseNumber;
        }


        public string GetStatusCodeName(int statuscodeValue)
        {
            string name = string.Empty;
            try
            {
                if (statuscodeValue == (int)REQUESTSTATUSCODE.New)
                {
                    name = "New";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.Assigned)
                {
                    name = "Assigned";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.InProgress)
                {
                    name = "InProgress";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.Responded)
                {
                    name = "Responded";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.AwaitingDevelopment)
                {
                    name = "Awaiting Development";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.AwaitingHandovertoDevelopment)
                {
                    name = "Awaiting Handover to Development";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.AwaitingRequestor)
                {
                    name = "Awaiting Requestor";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.AwaitingSignOff)
                {
                    name = "Awaiting Sign Off";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.Closed || statuscodeValue == (int)REQUESTSTATUSCODE.ClosedOOTB)
                {
                    name = "Closed";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.AssignmentAccepted)
                {
                    name = "Assignment Accepted";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.Cancelled)
                {
                    name = "Cancelled";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.Escalated)
                {
                    name = "Escalated";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.LongTermEscalation)
                {
                    name = "Long-Term Escalation";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.FollowupQuestion)
                {
                    name = "Follow-up Question";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.On)
                {
                    name = "On Hold";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.Open)
                {
                    name = "Open";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.PendingAssignment)
                {
                    name = "Pending Assignment";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.PendingClientFeedback)
                {
                    name = "Pending Client Feedback";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.PendingSubmitterFeedback)
                {
                    name = "Pending Submitter Feedback";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.RequestClosed)
                {
                    name = "Request Closed";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.RequestReOpened)
                {
                    name = "Request Re-Opened";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.WorkinProgress)
                {
                    name = "Work in Progress";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.PendingCorrectionExecution)
                {
                    name = "Pending Correction Execution";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.AssessmentEffortEstimation)
                {
                    name = "Assessment & Effort Estimation";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.ClientSignoff)
                {
                    name = "Client Sign off";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.ClientSignoffProposalScope)
                {
                    name = "Client Sign off Proposal & Scope";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.DevelopmentSolutionDelivery)
                {
                    name = "Development / Solution Delivery";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.QCAgainstSpecsFTD)
                {
                    name = "QC Against Specs + FTD";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.SpecificationSignOff)
                {
                    name = "Specification Sign Off";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.TimingDefinition)
                {
                    name = "Timing Definition";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.OnHold)
                {
                    name = "On Hold";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.WaitingforDetails)
                {
                    name = "Waiting for Details";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.Researching)
                {
                    name = "Researching";
                }
                if (statuscodeValue == (int)REQUESTSTATUSCODE.Reopened)
                {
                    name = "Reopened";
                }
                tracer.Trace("StatuscodeName: " + name);
            }
            catch (Exception ex)
            {
                tracer.Trace("Exception in GetStatusCodeName: " + ex.Message);
            }
            return name;
        }

        public string GetSubStatusCodeName(int statuscodeValue)
        {
            string name = string.Empty;
            try
            {
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.HoldInternal)
                {
                    name = "Hold - Internal";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.HoldExternal)
                {
                    name = "Hold - External";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.Working)
                {
                    name = "Working";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.HoldInternalLongTermEscalation)
                {
                    name = "Hold - Internal Long Term Escalation";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.QualityControl)
                {
                    name = "Quality Control";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.ReadyforDelivery)
                {
                    name = "Ready for Delivery";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.AwaitingDelivery)
                {
                    name = "Awaiting Delivery";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.SolutionProvided)
                {
                    name = "Solution Provided";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.NoSolution)
                {
                    name = "No Solution";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.Cancelled)
                {
                    name = "Cancelled";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.OutofScope)
                {
                    name = "Out of Scope";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.ResponseReceived)
                {
                    name = "Response Received";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.NoResponse)
                {
                    name = "No Response";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.PortalProvisioning)
                {
                    name = "Portal Provisioning";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.ProductProvisioning)
                {
                    name = "Product Provisioning";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.PendedPortal)
                {
                    name = "Pended, Portal";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.ErrorPortal)
                {
                    name = "Error, Portal";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.PendedProduct)
                {
                    name = "Pended, Product";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.ErrorProduct)
                {
                    name = "Error, Product";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.Fulfilled)
                {
                    name = "Fulfilled";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.ReadyforAgentAction)
                {
                    name = "Ready for Agent Action";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.AutoProcessed)
                {
                    name = "Auto Processed";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.Duplicate)
                {
                    name = "Duplicate";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.Misdirected)
                {
                    name = "Misdirected";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.WorkingOnTime)
                {
                    name = "Working - On Time";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.WorkingDelayed)
                {
                    name = "Working - Delayed";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.OnHoldSoftwareIssue)
                {
                    name = "On Hold - Software Issue";
                }
                if (statuscodeValue == (int)REQUESTSUBSTATUSCODE.Rejected)
                {
                    name = "Rejected";
                }

                tracer.Trace("SubStatuscodeName: " + name);
            }
            catch (Exception ex)
            {
                tracer.Trace("Exception in GetSubStatusCodeName: " + ex.Message);
            }
            return name;
        }

        public string GetPriorityCodeName(int PrioritycodeValue)
        {
            string name = string.Empty;
            try
            {
                if (PrioritycodeValue == (int)PRIORITYCODE.P1Critical)
                {
                    name = "P1 - Critical";
                }
                if (PrioritycodeValue == (int)PRIORITYCODE.P2High)
                {
                    name = "P2 - High";
                }
                if (PrioritycodeValue == (int)PRIORITYCODE.P3Medium)
                {
                    name = "P3 - Medium";
                }
                if (PrioritycodeValue == (int)PRIORITYCODE.P4Low)
                {
                    name = "P4 - Low";
                }
                if (PrioritycodeValue == (int)PRIORITYCODE.P5None)
                {
                    name = "P5 - None";
                }
                if (PrioritycodeValue == (int)PRIORITYCODE.Critical)
                {
                    name = "Critical";
                }
                if (PrioritycodeValue == (int)PRIORITYCODE.High)
                {
                    name = "High";
                }
                if (PrioritycodeValue == (int)PRIORITYCODE.Medium)
                {
                    name = "Medium";
                }
                if (PrioritycodeValue == (int)PRIORITYCODE.Low)
                {
                    name = "Low";
                }

                tracer.Trace("PrioritycodeValue: " + name);
            }
            catch (Exception ex)
            {
                tracer.Trace("Exception in PrioritycodeValue: " + ex.Message);
            }
            return name;
        }

    }
}

