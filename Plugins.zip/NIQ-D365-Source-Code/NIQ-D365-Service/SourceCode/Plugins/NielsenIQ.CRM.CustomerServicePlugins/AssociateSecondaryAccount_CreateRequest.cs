﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class AssociateSecondaryAccount_CreateRequest : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            if (context.MessageName == "Associate")
            {
                if (context.InputParameters.Contains("Relationship"))
                {
                    Relationship rel = (Relationship)context.InputParameters["Relationship"];
                    if (rel.SchemaName != "niq_incident_account")
                    {
                        return;
                    }
                    try
                    {
                        if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
                        {
                            EntityReference targetentity = (EntityReference)context.InputParameters["Target"];
                            if (context.InputParameters.Contains("RelatedEntities") && context.InputParameters["RelatedEntities"] is EntityReferenceCollection)
                            {
                                EntityReferenceCollection relatedEntities = context.InputParameters["RelatedEntities"] as EntityReferenceCollection;
                                if (relatedEntities.Count > 1)
                                {
                                    foreach (EntityReference relatedentity in relatedEntities)
                                    {
                                        CreateRequestForSecondaryAccount(targetentity.Id, relatedentity.Id, service);
                                    }
                                }
                                else
                                {
                                    CreateRequestForSecondaryAccount(targetentity.Id, relatedEntities[0].Id, service);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new InvalidPluginExecutionException(ex.Message);
                    }
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="_primaryRequestId"></param>
        /// <param name="_accountId"></param>
        /// <param name="service"></param>
        private void CreateRequestForSecondaryAccount(Guid _primaryRequestId, Guid _accountId, IOrganizationService service)
        {
            try
            {
                Entity existingrequest = service.Retrieve("incident", _primaryRequestId, new ColumnSet("niq_recordtype", "niq_topicid", "title", "description", "caseorigincode", "customerid", "primarycontactid"));
                Guid AccId = _accountId;
                //Guid AccId = relatedEntity.Id;
                //Guid[] accounts = AccId;
                Entity request = new Entity("incident");
                request.Attributes["niq_recordtype"] = new OptionSetValue(existingrequest.GetAttributeValue<OptionSetValue>("niq_recordtype").Value);
                request["niq_topicid"] = existingrequest.GetAttributeValue<EntityReference>("niq_topicid");
                request["title"] = existingrequest.GetAttributeValue<string>("title");
                request["description"] = existingrequest.GetAttributeValue<string>("description");
                request.Attributes["caseorigincode"] = new OptionSetValue(existingrequest.GetAttributeValue<OptionSetValue>("caseorigincode").Value);
                request["caseorigincode"] = new OptionSetValue(existingrequest.GetAttributeValue<OptionSetValue>("caseorigincode").Value);
                request.Attributes["customerid"] = new EntityReference("account", _accountId);
                request["primarycontactid"] = existingrequest.GetAttributeValue<EntityReference>("primarycontactid");
                request["niq_primaryrequestformulticountryrequest"] = new EntityReference("incident", _primaryRequestId);
                request["niq_createrequestforsecondaryaccounts"] = true;
                Guid requestGuid = service.Create(request);
                Entity updatePrimaryMultiRequest = new Entity("incident", _primaryRequestId);
                updatePrimaryMultiRequest["niq_primaryrequestformulticountryrequest"] = new EntityReference("incident", _primaryRequestId);

                service.Update(updatePrimaryMultiRequest);

            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);

            }
        }
    }
}