﻿using Microsoft.Xrm.Sdk;
using System;
using System.ServiceModel;

namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class RequestAssociateandDisassoicate : IPlugin
    {


        /// <summary>
        /// Execute method that is required by the IPlugin interface.
        /// </summary>
        /// <param name="serviceProvider">The service provider from which you can obtain the
        /// tracing service, plug-in execution context, organization service, and more.</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            //Extract the tracing service for use in debugging sandboxed plug-ins.
            ITracingService tracingService =
                (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Obtain the execution context from the service provider.
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));

            if (context.MessageName == "Associate" || context.MessageName == "Disassociate")
            {

                if (context.InputParameters.Contains("Relationship"))
                {

                    Relationship rel = (Relationship)context.InputParameters["Relationship"];

                    if (rel.SchemaName != "niq_incident_incident")
                    {
                        return;
                    }


                    try
                    {
                        // The InputParameters collection contains all the data passed in the message request.
                        if (context.InputParameters.Contains("Target") &&
                    context.InputParameters["Target"] is EntityReference)
                        {
                            // Obtain the target entity from the input parameters.
                            EntityReference targetentity = (EntityReference)context.InputParameters["Target"];

                            if (context.InputParameters.Contains("RelatedEntities") && context.InputParameters["RelatedEntities"] is EntityReferenceCollection)
                            {

                                EntityReferenceCollection relatedEntities = context.InputParameters["RelatedEntities"] as EntityReferenceCollection;
                                EntityReference relatedEntity = relatedEntities[0];

                                tracingService.Trace("target entity  Entity LogicalName Name {0} -  Entity Id {1} - Record name {2} :", targetentity.LogicalName, targetentity.Id, targetentity.Name);
                                tracingService.Trace("target entity  Entity LogicalName Name {0} -  Entity Id {1} - Record name {2} :", relatedEntity.LogicalName, relatedEntity.Id, relatedEntity.Name);

                                // Obtain the organization service reference.
                                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                                Entity incident = new Entity(relatedEntity.LogicalName, relatedEntity.Id);

                                if (context.MessageName == "Associate")
                                    incident["parentcaseid"] = new EntityReference(targetentity.LogicalName, targetentity.Id);
                                else
                                    incident["parentcaseid"] = null;

                                service.Update(incident);


                            }




                        }
                    }
                    catch (FaultException<OrganizationServiceFault> ex)
                    {
                        throw new InvalidPluginExecutionException("An error occurred in the FollowupPlugin plug-in.", ex);
                    }

                    catch (Exception ex)
                    {
                        tracingService.Trace("FollowupPlugin: {0}", ex.ToString());
                        throw;
                    }
                }

            }
        }
    }
}
