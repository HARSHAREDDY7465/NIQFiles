﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class PostUpdateKnowledgeArticlePermissionSet : IPlugin
    {
        ITracingService tracer = null;
        public void Execute(IServiceProvider serviceProvider)
        {

            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            if (context.Depth > 2) return;
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));


            try
            {

                // Removed the Update Login from Plugin and added to powerautoamte

                //if (context.MessageName.ToLower() == "update")
                //{

                //    Entity KB = (Entity)context.InputParameters["Target"];

                //    Entity preImages = (context.PreEntityImages != null && context.PreEntityImages.Contains("PreImage")) ? (Entity)context.PreEntityImages["PreImage"] : null;
                //    if (preImages == null)
                //    {
                //        return;
                //    }

                //    Entity postImages = (context.PostEntityImages != null && context.PostEntityImages.Contains("PostImage")) ? (Entity)context.PostEntityImages["PostImage"] : null;
                //    if (postImages == null)
                //    {
                //        return;

                //    }

                //    string preimageCalids = preImages.Attributes.Contains("niq_calids") == true ? preImages.Attributes["niq_calids"].ToString().TrimEnd(',') : string.Empty;
                //    string postimageCalids = postImages.Attributes["niq_calids"].ToString().TrimEnd(',');
                //    string[] preimageCalGuilds = null;
                //    string[] postimageCalGuilds = postimageCalids.Split(',');

                //    if (!String.IsNullOrEmpty(preimageCalids))
                //    {
                //        preimageCalGuilds = preimageCalids.Split(',');
                //        List<string> KBAccessListNeedtobeRemoved = ListCalsNeedtoRemoveFromAccessTeams(preimageCalGuilds, postimageCalGuilds);
                //        List<string> KBAccessListNeedtobeAdded = ListCalsNeedtoAddFromAccessTeams(postimageCalGuilds, preimageCalGuilds);
                //        EntityCollection UserListKBAccessneedtoRevoked = GetMatchingUserCALCollection(service, KBAccessListNeedtobeRemoved);
                //        EntityCollection UserListKBAccessneedtoAdded = GetMatchingUserCALCollection(service, KBAccessListNeedtobeAdded);
                //        RevokeAccess(UserListKBAccessneedtoRevoked, service, KB);
                //        AddAccees(UserListKBAccessneedtoAdded, service, KB);

                //    }
                //    else
                //    {

                //        List<string> KBAccessListNeedtobeAdded = postimageCalGuilds.ToList();
                //        EntityCollection UserListKBAccessneedtoAdded = GetMatchingUserCALCollection(service, KBAccessListNeedtobeAdded);
                //        AddAccees(UserListKBAccessneedtoAdded, service, KB);


                //    }





                //}
                if (context.MessageName.ToLower() == "create")
                {
                    Entity KB = (Entity)context.InputParameters["Target"];


                    tracer.Trace("IS RootArticle: " + !KB.GetAttributeValue<bool>("isrootarticle"));
                    if (!KB.GetAttributeValue<bool>("isrootarticle"))
                    {
                        tracer.Trace("IS RootArticle: " + !KB.GetAttributeValue<bool>("isrootarticle"));
                        AddUsersToAccesTeam(service, new EntityReference(KB.LogicalName, KB.Id), KB.GetAttributeValue<EntityReference>("createdby").Id, GetTeamTemplate(service));
                    }


                }
            }
            catch (Exception ex)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), ex.Message);
            }



        }

        private void AddAccees(EntityCollection userListKBAccessneedtoAdded, IOrganizationService service,Entity KB)
        {
            foreach (Entity userrecord in userListKBAccessneedtoAdded.Entities)
            {
                AddUsersToAccesTeam(service, new EntityReference(KB.LogicalName, KB.Id), userrecord.Id, GetTeamTemplate(service));
            }

        }

        private void RevokeAccess(EntityCollection userListKBAccessneedtoRevoked, IOrganizationService service, Entity KB)
        {

            foreach(Entity userrecord in userListKBAccessneedtoRevoked.Entities)
            {
                RemoveUsersToAccesTeam(service, new EntityReference(KB.LogicalName,KB.Id), userrecord.Id, GetTeamTemplate(service));
            }

        }

        public void AddUsersToAccesTeam(IOrganizationService service, EntityReference targetentity, Guid systemuserId, Guid teamTemplateId)
        {

            var request = new AddUserToRecordTeamRequest
            {
                Record = targetentity,
                SystemUserId = systemuserId,
                TeamTemplateId = teamTemplateId
            };

            AddUserToRecordTeamRequest addReq = (AddUserToRecordTeamRequest)request;

            EntityReference target = addReq.Record;

            if (request == null)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Can not add to team without target");
            }

            if (request.SystemUserId == Guid.Empty)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Can not add to team without user");
            }

            if (request.TeamTemplateId == Guid.Empty)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Can not add to team without team");
            }

            service.Execute(request);

        }

        public void RemoveUsersToAccesTeam(IOrganizationService service, EntityReference targetentity, Guid systemuserId, Guid teamTemplateId)
        {

            var request = new RemoveUserFromRecordTeamRequest
            {
                Record = targetentity,
                SystemUserId = systemuserId,
                TeamTemplateId = teamTemplateId
            };

            RemoveUserFromRecordTeamRequest addReq = (RemoveUserFromRecordTeamRequest)request;

            EntityReference target = addReq.Record;

            if (request == null)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Can not add to team without target");
            }

            if (request.SystemUserId == Guid.Empty)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Can not add to team without user");
            }

            if (request.TeamTemplateId == Guid.Empty)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Can not add to team without team");
            }

            service.Execute(request);

        }

        public Guid GetTeamTemplate(IOrganizationService service)
        {
            var query_teamtemplatename = "%Knowledge Article Permission Set%";
            var query = new QueryExpression("teamtemplate");
            query.TopCount = 1;
            query.ColumnSet.AddColumns("teamtemplateid");
            query.Criteria.AddCondition("teamtemplatename", ConditionOperator.Like, query_teamtemplatename);
            EntityCollection enitites = service.RetrieveMultiple(query);
            return enitites.Entities[0].Id;

        }

        public EntityCollection GetMatchingUserCALCollection(IOrganizationService service, List<String> KBAccessCals)
        {
            EntityCollection KBUserList = new EntityCollection();

            foreach (string Calids in KBAccessCals)
            {
                var query_niq_calids = "%" + Calids + "%";
                var query = new QueryExpression("systemuser");
                query.ColumnSet.AddColumns("systemuserid");
                query.Criteria.AddCondition("niq_calids", ConditionOperator.Like, query_niq_calids);
                EntityCollection enitites = service.RetrieveMultiple(query);

                KBUserList.Entities.AddRange(enitites.Entities);

            }

            return KBUserList;

        }



        public List<String> ListCalsNeedtoRemoveFromAccessTeams(string[] PreimageCals, string[] PostimageCals)
        {
            bool hasDuplicate = false;
            List<String> liststring = new List<String>();
            foreach (var StringA in PreimageCals)
            {
                foreach (var StringB in PostimageCals)
                {
                    if (StringA == StringB)
                    {
                        hasDuplicate = true;
                    }
                }
                if (!hasDuplicate)
                {
                    liststring.Add(StringA);
                }
                else
                {
                    hasDuplicate = false;
                }
            }
            return liststring;
        }

        public List<String> ListCalsNeedtoAddFromAccessTeams(string[] PostimageCals, string[] PreimageCals)
        {
            bool hasDuplicate = false;
            List<String> liststring = new List<String>();
            foreach (var StringA in PostimageCals)
            {
                foreach (var StringB in PreimageCals)
                {
                    if (StringA == StringB)
                    {
                        hasDuplicate = true;
                    }

                }
                if (!hasDuplicate)
                {
                    liststring.Add(StringA);
                }
                else
                {
                    hasDuplicate = false;
                }

            }

            return liststring;
        }
    }

}
