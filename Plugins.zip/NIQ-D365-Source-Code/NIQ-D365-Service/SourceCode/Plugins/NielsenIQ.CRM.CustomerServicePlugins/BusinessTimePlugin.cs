﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;

namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class BusinessTimePlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);
           
                DateTime startTime = (DateTime)context.InputParameters["StartTime"];
                DateTime endTime = (DateTime)context.InputParameters["EndTime"];
            
                float businessDays = 0;
                float businessHours = 0;
                DateTime day = startTime.Date;
                TimeSpan span = endTime - startTime;
        
                //if longer than 1 day
                if (span.TotalDays > 1)
                {
                    for (day = startTime.Date.AddDays(1); day.Date < endTime.Date; day = day.AddDays(1))
                    {
                        if (!String.Equals(day.DayOfWeek.ToString(), "Sunday") && !String.Equals(day.DayOfWeek.ToString(), "Saturday")) //if it is a weekday
                        {
                            businessDays += 1;
                            businessHours += 24;
                        }
                    }
                    //finish up hours during a week if we used the for loop and it isn't a weekend
                    if (day != startTime.Date && !String.Equals(day.DayOfWeek.ToString(), "Sunday") && !String.Equals(day.DayOfWeek.ToString(), "Saturday"))
                    {
                        businessHours += (float)(endTime - day).TotalHours;
                        businessDays += ((float)(endTime - day).TotalHours / 24);
                    }

                }
                else //if 1 day or less
                {
                    if ((int)startTime.DayOfWeek < 6 && (int)endTime.DayOfWeek >= 6) //if it starts friday and ends on Weekend
                    {
                        //businessHours = (float)(startTime - startTime.AddDays(1).Date).TotalHours;
                        businessHours = (float)(startTime.AddDays(1).Date - startTime).TotalHours;
                        businessDays = businessHours / 24;
                    }
                    else if ((int)endTime.DayOfWeek < 6 && (int)startTime.DayOfWeek >= 6) //if it starts on weekend and ends on Monday
                    {
                        businessHours = (float)(endTime - endTime.Date).TotalHours;
                        businessDays = businessHours / 24;
                    }
                    else //both are same weekday
                    {
                        businessHours = (float)span.TotalHours;
                        businessDays = (float)span.TotalDays;
                    }
                }
                context.OutputParameters["Days"] = businessDays;
                context.OutputParameters["Hours"] = businessHours;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
