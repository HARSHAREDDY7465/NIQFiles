﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;

namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class OnUpdate_PriorityOnParentRequest_UpdateChildRequest : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity targetEntity)
            {
                Entity preImage = (context.PreEntityImages.Contains("PreImage")) ? context.PreEntityImages["PreImage"] : null;

                if (preImage == null || !preImage.Contains("prioritycode")) return;

                int previousPriority = preImage.GetAttributeValue<OptionSetValue>("prioritycode").Value;
                int newPriority = targetEntity.Contains("prioritycode") ? targetEntity.GetAttributeValue<OptionSetValue>("prioritycode").Value : previousPriority;

                // Proceed only if priority has actually changed
                if (previousPriority == newPriority) return;

                int parentRecordType = preImage.Contains("niq_recordtype") ? preImage.GetAttributeValue<OptionSetValue>("niq_recordtype").Value : 0;

                // Check if parent request is Client Response (100000001) or NGH (100000003)
                if (parentRecordType == 100000001 || parentRecordType == 100000003)
                {
                    Guid parentId = targetEntity.Id;

                    // Retrieve all child requests linked to the parent
                    QueryExpression query = new QueryExpression("incident")
                    {
                        ColumnSet = new ColumnSet("incidentid", "niq_recordtype", "prioritycode"),
                        Criteria = new FilterExpression()
                    };
                    query.Criteria.AddCondition("parentcaseid", ConditionOperator.Equal, parentId);

                    EntityCollection childRequests = service.RetrieveMultiple(query);

                    foreach (Entity child in childRequests.Entities)
                    {
                        int childRecordType = child.GetAttributeValue<OptionSetValue>("niq_recordtype").Value;

                        int updatedPriority;

                        // If child request has the same record type as parent, copy priority directly
                        if (childRecordType == parentRecordType)
                        {
                            updatedPriority = newPriority;
                        }
                        // (For Data Validity or Global Client Order or Global Client Inquiry or RDDS or Go Enabling or Analytics support or Reporting solution)
                        else if (childRecordType == 100000005 || childRecordType == 100000007 || childRecordType == 100000009 || childRecordType == 100000010 || childRecordType == 100000011 || childRecordType == 100000013 || childRecordType == 100000014 || childRecordType == 100000006 || childRecordType == 100000008) 
                        {
                            updatedPriority = MapPriorityDataValidity(newPriority);
                        }
                       
                        else
                        {
                            return; // No mapping required, exit without updating priority
                        }

                        // Update child request priority only if different from the existing one
                        if (child.GetAttributeValue<OptionSetValue>("prioritycode").Value != updatedPriority)
                        {
                            Entity updateChild = new Entity("incident", child.Id)
                            {
                                ["prioritycode"] = new OptionSetValue(updatedPriority)
                            };
                            service.Update(updateChild);
                        }
                    }
                }
            }
        }

        // Mapping priority logic for Data Validity form
        private int MapPriorityDataValidity(int parentPriority)
        {
            if (parentPriority == 100000009) return 100000009; // Critical → Critical
            if (parentPriority == 100000010) return 100000010; // High → High
            if (parentPriority == 100000011) return 100000011; // Medium → Medium
            if (parentPriority == 100000012 || parentPriority == 100000013) return 100000012; // Low → Low
            return parentPriority;
        }

        
    }
}
