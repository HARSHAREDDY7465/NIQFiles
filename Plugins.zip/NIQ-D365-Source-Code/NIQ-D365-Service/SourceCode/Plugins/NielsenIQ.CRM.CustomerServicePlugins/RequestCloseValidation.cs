﻿using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Remoting.Services;
using System.Diagnostics;
using System.IdentityModel.Metadata;

namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class RequestCloseValidation : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            #region PluginConfig
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            #endregion


            try
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    var targetEntity = (Entity)context.InputParameters["Target"];
                    tracingService.Trace("targetEntity id" + targetEntity.Id);
                    var request = service.Retrieve(targetEntity.LogicalName, targetEntity.Id, new ColumnSet("niq_recordtype", "niq_closeddatetimehided"));
                    int recordType = request.GetAttributeValue<OptionSetValue>("niq_recordtype") != null ? request.GetAttributeValue<OptionSetValue>("niq_recordtype").Value : -1;
                    tracingService.Trace($"record type is {recordType}");
                    // Where record types are Ops and statuscode is Request Closed
                    if (recordType == 100000005 || recordType == 100000006 || recordType == 100000007 || recordType == 100000008 || recordType == 100000009 || recordType == 100000010 || recordType == 100000011 || recordType == 100000013 || recordType == 100000014)
                    {

                        if (targetEntity.Contains("statuscode"))
                        {
                            tracingService.Trace("targetEntity contains statuscode");
                            int status = targetEntity.GetAttributeValue<OptionSetValue>("statuscode").Value;
                            tracingService.Trace($"request status is {status}");
                            if (status == 100000017)
                            {
                                //tracingService.Trace("request status closed");
                                QueryExpression query = new QueryExpression("task");
                                query.ColumnSet = new ColumnSet(false);
                                query.Criteria = new FilterExpression(LogicalOperator.And);
                                query.Criteria.AddCondition(new ConditionExpression("regardingobjectid", ConditionOperator.Equal, targetEntity.Id));
                                query.Criteria.AddCondition(new ConditionExpression("statecode", ConditionOperator.Equal, 0));
                                EntityCollection entCol = service.RetrieveMultiple(query);

                                tracingService.Trace($"Open activities for {targetEntity.Id} are {entCol.Entities.Count}");

                                if (entCol.Entities.Count > 0) 
                                {
                                    
                                    throw new InvalidPluginExecutionException("All Request Tasks must be complete prior to closing the request.");
                                }
                                else
                                {
                                    request["niq_closeddatetimehided"] = DateTime.Now;
                                    service.Update(request);

                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("Error :- " + ex.Message);
            }
        }
    }
}
