﻿#region [ Includes]
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.CustomerServicePlugins.Helpers;
using static NielsenIQ.CRM.CustomerServicePlugins.Helpers.CommonConstants;
using System;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;

#endregion

namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class RequestOwnerChange_ChangeDept : IPlugin
    {
        ITracingService tracer = null;

        /// <summary>
        /// Method to be invoked from plugin method 
        /// </summary>
        /// <param name="serviceProvider"></param>
        public void Execute(IServiceProvider serviceProvider)
        {
            // create service object 
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            try
            {
                // To check depth   
                if (context.Depth > 2) return;



                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    // Business logic goes here  
                    Entity request = (Entity)context.InputParameters["Target"];
                    int recordType = 0;
                    if (request.Contains("niq_recordtype") && request["niq_recordtype"] != null)
                    {
                        OptionSetValue recordTypeOptionSet = (OptionSetValue)request["niq_recordtype"];
                         recordType = recordTypeOptionSet.Value;
                    }
                    if (recordType != 100000000 || recordType != 100000001 || recordType != 100000002 || recordType!= 100000012 || recordType != 100000003 || recordType!= 100000004)
                    {
                        EntityReference UserReference = (EntityReference)request.Attributes["ownerid"];
                        if (UserReference != null && UserReference.LogicalName == "systemuser")
                        {
                            Entity userEntity = service.Retrieve(UserReference.LogicalName, UserReference.Id, new ColumnSet("niq_responsibledepartmentoptionset"));                            
                            if(userEntity.Attributes.Contains("niq_responsibledepartmentoptionset") && userEntity.Attributes["niq_responsibledepartmentoptionset"]!=null)
                            {
                                var userResponsibleDeptLabel = userEntity.FormattedValues["niq_responsibledepartmentoptionset"];
                                tracer.Trace("The responsible department of the user is"+ userResponsibleDeptLabel);
                                int requestResponsibleDeptValueToSet = GetOptionsSetValueForLabel(service, request.LogicalName, "niq_responsibledepartment", userResponsibleDeptLabel);
                                request["niq_responsibledepartment"] = new OptionSetValue(requestResponsibleDeptValueToSet); ;
                                tracer.Trace("The responsible department is set for the request");
                            }
                            else
                            {
                                tracer.Trace("The responsible department of user doesn't contain data");
                                request["niq_responsibledepartment"] = null;
                            }

                        }
                        else if(UserReference.LogicalName == "team")
                        {
                            tracer.Trace("The owner of record is a team");
                            request["niq_responsibledepartment"] = null;
                        }
                    }



                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
                //throw new InvalidPluginExecutionException(ERRORMESSAGEFAILURE + ex);
            }

        }


        private int GetOptionsSetValueForLabel(IOrganizationService service, string entityName, string attributeName, string selectedLabel)
        {

            RetrieveAttributeRequest retrieveAttributeRequest = new
            RetrieveAttributeRequest
            {
                EntityLogicalName = entityName,
                LogicalName = attributeName,
                RetrieveAsIfPublished = true
            };
            // Execute the request.
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            // Access the retrieved attribute.
            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)
            retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
            OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();
            int selectedOptionValue = 0;
            foreach (OptionMetadata oMD in optionList)
            {
                if (oMD.Label.LocalizedLabels[0].Label.ToString().ToLower() == selectedLabel.ToLower())
                {
                    selectedOptionValue = oMD.Value.Value;
                    break;
                }
            }
            return selectedOptionValue;
        }


    }
}

