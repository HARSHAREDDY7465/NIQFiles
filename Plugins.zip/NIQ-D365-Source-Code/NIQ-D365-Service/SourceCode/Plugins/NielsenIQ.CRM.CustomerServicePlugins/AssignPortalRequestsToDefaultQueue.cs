﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class AssignPortalRequestsToDefaultQueue : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            #region PluginConfig
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            #endregion
            Guid standardQueue = new Guid("f0be3d03-cf4a-ed11-bba1-000d3a2227e5");
            Guid chinaRetailerQueue = new Guid("9acf033f-cf4a-ed11-bba1-000d3a2227e5");
            Guid NGHConnectTechENQueue = new Guid("519C4479-971B-EC11-B6E6-00224803E17E");
            Guid NGHConnectTechNonENQueue = new Guid("1AFCD052-971B-EC11-B6E6-0022480B3F30");
            int recordType = 0;

            try
            {
                if (context.MessageName == "Create")
                {
                    Entity contextEntity = (Entity)context.InputParameters["Target"];
                    if (contextEntity.LogicalName != "incident")
                    {
                        return;
                    }
                    if (contextEntity.Attributes.Contains("niq_recordtype"))
                    {
                        recordType = contextEntity.GetAttributeValue<OptionSetValue>("niq_recordtype").Value;
                    }
                    if ((contextEntity.Attributes.Contains("caseorigincode") && contextEntity.GetAttributeValue<OptionSetValue>("caseorigincode") != null)
                        && (contextEntity.Attributes.Contains("primarycontactid") && contextEntity.GetAttributeValue<EntityReference>("primarycontactid") != null) && (recordType == 100000000 || recordType == 100000003 || recordType == 100000001))
                    {
                        //Assign request to Contact's BU only when request created with Topic from CSO portal
                        if (contextEntity.Contains("niq_topicid") && contextEntity.GetAttributeValue<EntityReference>("niq_topicid") != null)
                        //if (recordType == 100000000 || recordType == 100000001 || recordType == 100000003)
                        {
                            EntityReference topicref = contextEntity.GetAttributeValue<EntityReference>("niq_topicid");
                            Entity topic = service.Retrieve(topicref.LogicalName, topicref.Id, new ColumnSet("niq_name"));
                            string topicname = topic.GetAttributeValue<string>("niq_name");
                            string[] metertopics = { "Data Plans Sales (Data Point Limits/ Tier Changes)", "Data Plans Support (Questions & Issues)" };
                            if (contextEntity.GetAttributeValue<OptionSetValue>("caseorigincode").Value == 100000087
                                && topicname != null && topicname != "" && !metertopics.Contains(topicname))
                            {
                                tracingService.Trace("Case Create from Portal");
                                AssignToQueueBU(contextEntity, chinaRetailerQueue, standardQueue, service, tracingService);
                            }
                        }
                        //Assign request to Contact's BU only when request created with NSSTopic from NSS portal
                        if (contextEntity.Contains("niq_nsstopic") && contextEntity.GetAttributeValue<EntityReference>("niq_nsstopic") != null)
                        {
                            EntityReference NSStopicref = contextEntity.GetAttributeValue<EntityReference>("niq_nsstopic");
                            Entity NSStopic = service.Retrieve(NSStopicref.LogicalName, NSStopicref.Id, new ColumnSet("niq_name"));
                            string NSStopicname = NSStopic.GetAttributeValue<string>("niq_name");
                            string NSSSubtopicname = "";

                            //get NSS sub-topic
                            if (contextEntity.Contains("niq_nsssubtopic") && contextEntity.GetAttributeValue<EntityReference>("niq_nsssubtopic") != null)
                            {
                                EntityReference NSSSubtopicref = contextEntity.GetAttributeValue<EntityReference>("niq_nsssubtopic");
                                Entity NSSSubtopic = service.Retrieve(NSSSubtopicref.LogicalName, NSSSubtopicref.Id, new ColumnSet("niq_name"));
                                NSSSubtopicname = NSSSubtopic.GetAttributeValue<string>("niq_name");
                            }
                            if (contextEntity.GetAttributeValue<OptionSetValue>("caseorigincode").Value == 100000172 && (NSStopicname != null && NSStopicname != "" && !(NSStopicname == "Access" || NSStopicname == "Reporting" || NSStopicname == "System Issues" || NSStopicname == "Data & methodology" || NSStopicname == "Data Quality Issues" || NSStopicname == "Data Extraction" || NSStopicname == "Data Inquiry" || NSStopicname == "Dataset Changes" || NSStopicname == "New dataset set-up")))
                            {
                                AssignToQueueBU(contextEntity, chinaRetailerQueue, standardQueue, service, tracingService);
                                tracingService.Trace("Case Create from Portal");
                            }
                        }
                        if (recordType == 100000003)
                        {
                            if (contextEntity.GetAttributeValue<OptionSetValue>("caseorigincode").Value == 100000087)
                            {
                                tracingService.Trace("ngh case created from portal");
                                tracingService.Trace("ngh case created from portal" + contextEntity.GetAttributeValue<EntityReference>("niq_topicid").Id);
                                if (contextEntity.Contains("niq_topicid") && contextEntity.GetAttributeValue<EntityReference>("niq_topicid") != null)
                                {
                                    tracingService.Trace("insideif");
                                    EntityReference topicref = contextEntity.GetAttributeValue<EntityReference>("niq_topicid");
                                    Entity topic = service.Retrieve(topicref.LogicalName, topicref.Id, new ColumnSet("niq_name"));
                                    string topicname = topic.GetAttributeValue<string>("niq_name");
                                    tracingService.Trace("Topic value:" + topicname);
                                    if (topicname != null && (topicname == "Data Plans Support (Questions & Issues)" || topicname == "Data Plans Sales (Data Point Limits/ Tier Changes)"))
                                    {
                                        EntityReference contactRef = contextEntity.GetAttributeValue<EntityReference>("primarycontactid");
                                        Entity requestContact = service.Retrieve(contactRef.LogicalName, contactRef.Id, new ColumnSet("niq_preferredlanguage", "niq_businesslanguageserviceid", "adx_preferredlanguageid"));
                                        string adxpreferredlanguage = requestContact.Contains("adx_preferredlanguageid") ? requestContact.GetAttributeValue<EntityReference>("adx_preferredlanguageid").Name : null;
                                        int preferredlanguage = requestContact.Contains("niq_preferredlanguage") ? requestContact.GetAttributeValue<OptionSetValue>("niq_preferredlanguage").Value : 0;
                                        Entity updateRequest = new Entity(contextEntity.LogicalName, contextEntity.Id);
                                        if (adxpreferredlanguage == null || adxpreferredlanguage == "English")
                                        {
                                            updateRequest["ownerid"] = new EntityReference("team", NGHConnectTechENQueue);

                                        }
                                        else if (preferredlanguage != 0)
                                        {
                                            tracingService.Trace("Non English" + preferredlanguage);
                                            updateRequest["ownerid"] = new EntityReference("team", NGHConnectTechNonENQueue);
                                        }
                                        service.Update(updateRequest);
                                    }
                                }

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("Request From Portal plugin Failed :  {0}", ex.ToString());
                throw;
            }
        }
        public void AssignToQueueBU(Entity contextEntity, Guid chinaRetailerQueue, Guid standardQueue, IOrganizationService service, ITracingService tracingService)
        {
            try
            {
                EntityReference contactRef = contextEntity.GetAttributeValue<EntityReference>("primarycontactid");
                Entity requestContact = service.Retrieve(contactRef.LogicalName, contactRef.Id, new ColumnSet("owningbusinessunit"));
                EntityReference contactOwnerbusinessUnit = requestContact.GetAttributeValue<EntityReference>("owningbusinessunit");
                String BusinessUnitName = service.Retrieve(contactOwnerbusinessUnit.LogicalName, contactOwnerbusinessUnit.Id, new ColumnSet("name")).GetAttributeValue<string>("name");
                Entity updateRequest = new Entity(contextEntity.LogicalName, contextEntity.Id);
                if (BusinessUnitName == "China Retailers")
                {
                    updateRequest["ownerid"] = new EntityReference("team", chinaRetailerQueue);
                    tracingService.Trace("BusinessUnitName" + BusinessUnitName);
                }
                else if (BusinessUnitName == "Standard")
                {
                    updateRequest["ownerid"] = new EntityReference("team", standardQueue);
                    tracingService.Trace("BusinessUnitName" + BusinessUnitName);
                }
                if (contextEntity.Contains("niq_requestaccount") && contextEntity.GetAttributeValue<EntityReference>("niq_requestaccount") != null)
                {
                    updateRequest["customerid"] = contextEntity.GetAttributeValue<EntityReference>("niq_requestaccount");
                }

                service.Update(updateRequest);
            }
            catch (Exception ex)
            {
                tracingService.Trace("Request From Portal plugin Failed :  {0}", ex.ToString());
                throw;
            }
        }

    }
}