﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class PullGUIDs : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);

                string text = (string)context.InputParameters["Text"];
                string guidRegex = @"\w{8}-\w{4}-\w{4}-\w{4}-\w{12}";

                MatchCollection matches = Regex.Matches(text, guidRegex);
                string toreturn = "";
                foreach (Match match in matches)
                {
                    toreturn += match.Value + ",";
                }
                if (matches.Count > 0)
                {
                    toreturn = toreturn.Remove(toreturn.Length - 1);
                }

                context.OutputParameters["Result"] = toreturn;

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
