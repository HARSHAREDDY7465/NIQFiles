﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class BPFChangeOnRequestAssignment : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            #region PluginConfig
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            #endregion
            try
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
                {
                    var requestreference = (EntityReference)context.InputParameters["Target"];
                    //Entity entity = (Entity)context.InputParameters["Target"];
                    Entity entity = service.Retrieve(requestreference.LogicalName, requestreference.Id, new ColumnSet(true));
                    if (entity.GetAttributeValue<OptionSetValue>("niq_recordtype").Value == 100000012)
                    {
                        return;
                    }
                    if (entity.GetAttributeValue<OptionSetValue>("niq_recordtype").Value == 100000000 ||
                        entity.GetAttributeValue<OptionSetValue>("niq_recordtype").Value == 100000001 ||
                        entity.GetAttributeValue<OptionSetValue>("niq_recordtype").Value == 100000002 ||
                        entity.GetAttributeValue<OptionSetValue>("niq_recordtype").Value == 100000003 ||
                        entity.GetAttributeValue<OptionSetValue>("niq_recordtype").Value == 100000004)
                    {
                        EntityReference ownerValue = entity.GetAttributeValue<EntityReference>("ownerid");
                        if (ownerValue.LogicalName == "team")
                        {
                            if (entity.GetAttributeValue<OptionSetValue>("statuscode").Value == 100000001 ||
                               entity.GetAttributeValue<OptionSetValue>("statuscode").Value == 1)
                            {
                                Entity UpdateStatusEntity = new Entity(entity.LogicalName, entity.Id);
                                UpdateStatusEntity["statuscode"] = new OptionSetValue(100000000);
                                UpdateStatusEntity["niq_substatus"] = null;
                                service.Update(UpdateStatusEntity);
                                Process(service, tracingService, entity, "New");
                            }
                            else
                            { 
                                return;
                            }
                            
                        }
                        else if (entity.Contains("ownerid"))
                        {
                            Process(service, tracingService, entity, "Assigned");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("Error :- " + ex.Message);
            }
        }
        private void Process(IOrganizationService sdk, ITracingService tracer, Entity target , string newStageName)
        {
            RetrieveProcessInstancesRequest req = new RetrieveProcessInstancesRequest() { EntityId = target.Id, EntityLogicalName = target.LogicalName };
            RetrieveProcessInstancesResponse response = (RetrieveProcessInstancesResponse)sdk.Execute(req);

            if (response?.Processes != null && response.Processes?.Entities != null && response.Processes.Entities.Count > 0)
            {
                //Retrieve the active stage id
                Guid stageId = response.Processes.Entities[0].GetAttributeValue<Guid>("processstageid");
                string activeStageName = GetActiveStageName(sdk, stageId);
                //find the stage name based off the status code value
                //string newStageName = "Assigned";
                tracer.Trace($"stageId={stageId}, activeStageName={activeStageName}, newStageName={newStageName}");

                if (!newStageName.Equals(activeStageName, StringComparison.InvariantCultureIgnoreCase))
                {
                    Guid processId = response.Processes.Entities[0].Id;
                    tracer.Trace($"processId={processId}");
                    //get all stages for the BPF
                    RetrieveActivePathResponse pathResp = GetPathResponse(sdk, processId);

                    if (pathResp?.ProcessStages != null && pathResp.ProcessStages?.Entities != null && pathResp.ProcessStages.Entities.Count > 0)
                    {
                        // iterate the stages to find the new EntityReference of the stage you want to set as the active one
                        Entity newStage = pathResp.ProcessStages.Entities.ToList().Where(stage => newStageName.Equals(stage.GetAttributeValue<string>("stagename"), StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
                        tracer.Trace($"newStageId={newStage.Id}");

                        if (newStage != null)
                        {
                            Entity update = new Entity("phonetocaseprocess", processId);
                            //the business process flow entity
                            update["activestageid"] = newStage.ToEntityReference();
                            sdk.Update(update);
                            tracer.Trace($"Updated bpf with id={processId} with activestageid={newStage.Id}");
                        }
                    }
                }
            }
        }
        private static RetrieveActivePathResponse GetPathResponse(IOrganizationService sdk, Guid processId)
        {
            RetrieveActivePathRequest pathReq = new RetrieveActivePathRequest
            {
                ProcessInstanceId = processId
            };
            RetrieveActivePathResponse pathResp = (RetrieveActivePathResponse)sdk.Execute(pathReq);
            return pathResp;
        }

        private string GetActiveStageName(IOrganizationService sdk, Guid stageId)
        {
            Entity stageEnt = sdk.Retrieve("processstage", stageId, new ColumnSet("stagename"));
            string activeStageName = stageEnt.GetAttributeValue<string>("stagename");
            return activeStageName;
        }
    }
}
