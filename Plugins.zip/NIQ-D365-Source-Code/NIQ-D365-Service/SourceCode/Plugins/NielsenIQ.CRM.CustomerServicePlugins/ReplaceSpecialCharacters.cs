﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;

namespace NielsenIQ.CRM.CustomerServicePlugins
{
    public class ReplaceSpecialCharacters : IPlugin
    {

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);

                string specialCharactersString = (string)context.InputParameters["SpecialCharacters"];
                string inputString = (string)context.InputParameters["inputString"];
                string outputString = inputString;
                char deliminator = ',';
                List<string> specialCharacters = new List<string>(specialCharactersString.Split(deliminator));

                foreach (string character in specialCharacters)
                {
                    outputString = outputString.Replace(character, '-'.ToString());
                }

                context.OutputParameters["OutputString"] = outputString;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
