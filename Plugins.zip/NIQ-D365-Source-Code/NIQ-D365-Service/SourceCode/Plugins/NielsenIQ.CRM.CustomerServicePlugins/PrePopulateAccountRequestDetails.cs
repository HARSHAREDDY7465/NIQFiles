﻿

#region [ Includes]
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using NielsenIQ.CRM.CustomerServicePlugins.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static NielsenIQ.CRM.CustomerServicePlugins.Helpers.CommonConstants;
#endregion

namespace NielsenIQ.CRM.CustomerServicePlugins
{

    /// <summary>
    /// Method to be invoked from plugin method 
    /// </summary>
    /// <param name="serviceProvider"></param>
    public class PrePopulateAccountRequestDetails : IPlugin
    {
        ITracingService tracer = null;

        /// <summary>
        /// Method to execute first method of the plugin 
        /// </summary>
        /// <param name="serviceProvider"></param>
        public void Execute(IServiceProvider serviceProvider)
        {
            // create service object 
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            try
            {
                // When a record is updated from ui, then fetch the details from related record 
                Entity targetentity = (Entity)context.InputParameters[TARGET];
                Entity preimage = null;
                if (context.MessageName.ToLower() != CREATEOPERATION) //  only for update get the preimage 
                    preimage = (Entity)context.PreEntityImages[PREIMAGE];
                else
                {//  only for  Create operation when required fields are not available 
                    OnCreatePrePopulateRequiredData(service, targetentity);
                }

                // check only if  record type is gcd or ngh 
                int recordtype = 0;
                if (targetentity.Attributes.Contains("niq_recordtype") && targetentity["niq_recordtype"] != null) // contact 
                    recordtype = ((OptionSetValue)targetentity["niq_recordtype"]).Value;
                else if (preimage != null && preimage.Attributes.Contains("niq_recordtype") && preimage["niq_recordtype"] != null)
                    recordtype = ((OptionSetValue)preimage["niq_recordtype"]).Value;

                tracer.Trace("recordtype :" + recordtype.ToString());
                //only if record type = GCD- CR,Analytics, NGH
                if (recordtype == (int)REQUESTRECORDTYPE.Analytics || recordtype == (int)REQUESTRECORDTYPE.ClientResponse || recordtype == (int)REQUESTRECORDTYPE.NGH)
                {
                    ConstructSkillData(service, targetentity, preimage, recordtype, context.MessageName.ToLowerInvariant());
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ERRORMESSAGEFAILURE + ex);
            }
        }




        #region [ Private Methods ] 


        /// <summary>
        ///  When a request is created from portal or chatbot , the record types are not given , only topic will be selected
        ///  Also other required attributes need to be prepopulated
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetentity"></param>
        private void OnCreatePrePopulateRequiredData(IOrganizationService service, Entity targetentity)
        {
            try
            {
                int rectype = 0;
                // check if recordtype does not contain data 
                if (!targetentity.Attributes.Contains("niq_recordtype"))
                {
                    //check if topic exists 
                    if (targetentity.Attributes.Contains("niq_topicid") && targetentity["niq_topicid"] != null && (EntityReference)targetentity["niq_topicid"] != null) // topic
                    {
                        Guid topicid = ((EntityReference)targetentity.Attributes["niq_topicid"]).Id;
                        if (topicid != Guid.Empty)
                        {
                            Entity entity = service.Retrieve("niq_topic", topicid, new ColumnSet(new string[] { "niq_recordtype" }));
                            if (entity != null && entity.Attributes.Contains("niq_recordtype"))
                            {
                                string rectypeval = entity["niq_recordtype"].ToString();
                                if (rectypeval.Contains(","))
                                {
                                    string[] rectypes = rectypeval.Split(',');
                                    rectypeval = rectypes[0];
                                }
                                rectype = Convert.ToInt32(rectypeval);
                                targetentity["niq_recordtype"] = new OptionSetValue(rectype);
                            }
                        }
                    }
                }
                if (targetentity.Attributes.Contains("niq_recordtype") && targetentity["niq_recordtype"] != null) // contact 
                    rectype = ((OptionSetValue)targetentity["niq_recordtype"]).Value;
                // based on the recordtype check the required fields 
                if (rectype == (int)REQUESTRECORDTYPE.ClientResponse || rectype == (int)REQUESTRECORDTYPE.Analytics || rectype == (int)REQUESTRECORDTYPE.NGH)
                {
                    OnCreatePopulateRecTypeBasedData(service, targetentity, rectype);
                }
            }
            catch { throw; }

        }

        /// <summary>
        /// Populate few fields for the Analytics,CR, NGH record type
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetentity"></param>
        private void OnCreatePopulateRecTypeBasedData(IOrganizationService service, Entity targetentity, int rectype)
        {
            try
            {
                switch (rectype)
                {
                    case (int)REQUESTRECORDTYPE.Analytics:
                    case (int)REQUESTRECORDTYPE.ClientResponse:
                        if (!targetentity.Attributes.Contains("niq_numberofdatabases"))
                            targetentity.Attributes.Add("niq_numberofdatabases", 1);
                        if (!targetentity.Attributes.Contains("niq_numberofcountries"))
                            targetentity.Attributes.Add("niq_numberofcountries", 1);
                        if (!targetentity.Attributes.Contains("niq_numberofcategories"))
                            targetentity.Attributes.Add("niq_numberofcategories", 1);
                        // performance overview , Business Issue Analysis, Guided analysis
                        if (!targetentity.Attributes.Contains("niq_numberofperformanceoverview"))
                            targetentity.Attributes.Add("niq_numberofperformanceoverview", 0);
                        if (!targetentity.Attributes.Contains("niq_numberofbusinessissueanalysis"))
                            targetentity.Attributes.Add("niq_numberofbusinessissueanalysis", 0);
                        if (!targetentity.Attributes.Contains("niq_guidedanalyticscontent"))
                            targetentity.Attributes.Add("niq_guidedanalyticscontent", 0.00);
                        break;
                }
            }
            catch { throw; }
        }

        /// <summary>
        ///  construct the skill data for the GCD, NGH record types 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetentity"></param>
        /// <param name="preimage"></param>
        private void ConstructSkillData(IOrganizationService service, Entity targetentity, Entity preimage, int recordtype, string message)
        {
            try
            {
                string topic = string.Empty; StringBuilder skillsdata = new StringBuilder();
                // get the topic selected in the request form
                topic = GetTopicName(service, targetentity, preimage);
                if (!string.IsNullOrEmpty(topic))
                    skillsdata.Append(topic + ";");



                //check if account or contact information is modified
                tracer.Trace("Entered the condition for getting the values.");
                Guid operatedctryid = Guid.Empty;
                // then fetch the related helplineproduct and prepopulate
                string custinfo = MapAccountContactAttributes(service, targetentity, preimage, out operatedctryid);
                if (!string.IsNullOrEmpty(custinfo))
                    skillsdata.Append(custinfo);



                // append NGH or Non NGH
                if (recordtype == (int)REQUESTRECORDTYPE.NGH)
                {
                    // if create operation and agent tier is empty, then populate default value as L1
                    bool isnghtier = true;
                    string agenttier = "L1";
                    if (message == CREATEOPERATION)
                    { // if agent tier is not supplied then populate the default value as L1
                        if (!targetentity.Attributes.Contains("niq_nghagenttierid"))
                        {
                            PopulateDefaultNGHTierValue(service, agenttier, targetentity);
                            isnghtier = false;
                        }
                    }
                    //Get NGH product and businessline from request and get the nghproductmapping
                    string nghType = NGH; Guid nghprodmappingid = Guid.Empty;
                    // variable to hold the default mapping products
                    string[] defaultNGHProducts = { "Connect Express", "Spaceman", "Connect Enterprise" };
                    // pass the ngh product from request - to ngh product mapping
                    string nghProductMapping = GetNghProductMapping(service, targetentity, preimage, message, out nghprodmappingid);
                    tracer.Trace("Substring of product mapping - " + nghProductMapping.Substring(nghProductMapping.IndexOf("-") + 1).Trim());
                    // check if operated country and nghproductmapping are available
                    if (operatedctryid != Guid.Empty && nghprodmappingid != Guid.Empty)
                    {
                        tracer.Trace("Operated country and product mapping exists");
                        GetNGHSkillsForProductCountry(service, nghprodmappingid, operatedctryid, out nghType);
                    }
                    else if (operatedctryid == Guid.Empty && nghprodmappingid != Guid.Empty && defaultNGHProducts.Contains(nghProductMapping.Substring(nghProductMapping.IndexOf("-") + 1).Trim()))
                    {
                        tracer.Trace("Operated country is null, however product mapping is either of Connect Express/Spaceman/Connect Enterprise");
                        nghType = NGH;
                    }
                    else
                    {
                        tracer.Trace("Operated country and product mapping is NULL");
                        nghType = NONNGH;
                    }
                    tracer.Trace("Operatedcountry:" + operatedctryid.ToString() + " ;prodmappingid:" + nghprodmappingid.ToString());
                    if (nghType == NGH)
                    {
                        if (!string.IsNullOrEmpty(nghProductMapping) && nghprodmappingid != Guid.Empty)
                        {
                            skillsdata.Append(nghProductMapping + ";");
                        }



                        if (isnghtier) // if Agent tier is present in the form, then call this method
                        {
                            // Get the data for the NGH agent tier details
                            agenttier = GetNGHAgentTierDetails(service, targetentity, preimage);
                        }
                        if (!string.IsNullOrEmpty(agenttier))
                            skillsdata.Append(agenttier + ";");
                        // Topic, market, client group,Language,NGH , NGH tier, NGH Helpline product
                        if (!string.IsNullOrEmpty(nghType))
                            skillsdata.Append(nghType + ";");

                        MapNGHSelectionLookupValue(service, nghType, targetentity);
                    }
                    else
                    {// map the nonNGH routing type

                        if (!string.IsNullOrEmpty(nghType))
                            skillsdata.Append(nghType+";");

                        MapNGHSelectionLookupValue(service, nghType, targetentity);
                    }
                }
                else
                {
                    // map NON NGH type for CR & Analytics record types

                    if (!string.IsNullOrEmpty(NONNGH))
                        skillsdata.Append(NONNGH);
                    MapNGHSelectionLookupValue(service, NONNGH, targetentity);
                }
                // determine if ngh or non ngh
                if (targetentity.Attributes.Contains("niq_skills"))
                {
                    targetentity["niq_skills"] = skillsdata.ToString().TrimEnd(';');
                }
                else
                {
                    targetentity.Attributes.Add("niq_skills", skillsdata.ToString().TrimEnd(';'));
                }
            }
            catch { throw; }
        }
        /// <summary>
        ///  Check the type of routing  based on the product  and  operated  market 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="nghprodmappingid"></param>
        /// <param name="operatedctryid"></param>
        /// <param name="nghType"></param>
        private void GetNGHSkillsForProductCountry(IOrganizationService service, Guid nghprodmappingid, Guid operatedctryid, out string nghType)
        {
            nghType = NGH; // by default , set as NGH
            try
            {
                QueryByAttribute query = new QueryByAttribute("niq_nghskills");
                query.AddAttributeValue("niq_nghproductmappingid", nghprodmappingid);
                query.ColumnSet = new ColumnSet("niq_operatedmarketid");
                EntityCollection collection = (EntityCollection)service.RetrieveMultiple(query);
                var ismatchingfound = false;
                if (collection != null && collection.Entities != null && collection.Entities.Count > 0)
                {
                    for (int j = 0; j < collection.Entities.Count; j++)
                    {
                        Entity entity = collection.Entities[j];
                        // if country is empty, then it means All countries , so exit as NGH
                        if (entity.Attributes.Contains("niq_operatedmarketid"))
                        {
                            if (((EntityReference)entity["niq_operatedmarketid"]).Id == operatedctryid)
                            {
                                ismatchingfound = true; break; // matching found
                            }
                        }
                        else
                        {
                            ismatchingfound = true; break; // matching is found
                        }
                    }
                }
                // check otherwise and make it NON NGH routing
                if (!ismatchingfound)
                    nghType = NONNGH;
            }
            catch { throw; }
        }
        /// <summary>
        /// Function to get NGH product mapping 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetentity"></param>
        /// <param name="preimage"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        private string GetNghProductMapping(IOrganizationService service, Entity targetentity,
                                    Entity preimage, string message, out Guid nghprodmappingid)
        {
            string nghproductmapping = string.Empty; nghprodmappingid = Guid.Empty; Guid nghproductid = Guid.Empty;
            try
            {
                // nghproduct 
                if (targetentity.Attributes.Contains("niq_nghproductid") && targetentity["niq_nghproductid"] != null && (EntityReference)targetentity["niq_nghproductid"] != null) // niq_nghproductid
                    nghproductid = ((EntityReference)targetentity.Attributes["niq_nghproductid"]).Id;
                else if (preimage != null && preimage.Attributes.Contains("niq_nghproductid") && preimage["niq_nghproductid"] != null && (EntityReference)preimage["niq_nghproductid"] != null) // before image 
                    nghproductid = ((EntityReference)preimage.Attributes["niq_nghproductid"]).Id;

                tracer.Trace("nghproduct: " + nghproductid + "; ");

                // check if it nghproduct is present in the form
                if (nghproductid != Guid.Empty)
                {
                    Entity entity = service.Retrieve("niq_nghproduct", nghproductid, new ColumnSet("niq_nghproductmappingid", "niq_businessline"));
                    // get nghproductmapping
                    if (entity != null && entity.Attributes.Contains("niq_nghproductmappingid"))
                    {
                        nghprodmappingid = ((EntityReference)entity["niq_nghproductmappingid"]).Id;
                        nghproductmapping = ((EntityReference)entity["niq_nghproductmappingid"]).Name;
                        // check if nghproductmapping lookup value exists 
                        if (targetentity.Attributes.Contains("niq_nghproductmappingid"))
                            targetentity["niq_nghproductmappingid"] = ((EntityReference)entity["niq_nghproductmappingid"]);
                        else
                            targetentity.Attributes.Add("niq_nghproductmappingid", ((EntityReference)entity["niq_nghproductmappingid"]));
                    }
                    if (message == CREATEOPERATION && !targetentity.Attributes.Contains("niq_businessline"))
                    {
                        targetentity.Attributes.Add("niq_businessline", (OptionSetValue)entity["niq_businessline"]);
                    }
                }
                tracer.Trace("nghproductmapping: " + nghproductmapping + ", nghprodmappingid: " + nghprodmappingid.ToString());
            }
            catch { throw; }
            return nghproductmapping;
        }


        /// <summary>
        /// MapNGHSelectionLookupValue
        /// </summary>
        /// <param name="service"></param>
        /// <param name="nghselection"></param>
        /// <param name="targetentity"></param>
        private void MapNGHSelectionLookupValue(IOrganizationService service, string nghselection, Entity targetentity)
        {
            try
            {
                QueryByAttribute query = new QueryByAttribute("niq_nghornonngh");
                query.AddAttributeValue("niq_name", nghselection);
                query.ColumnSet = new ColumnSet(false);
                EntityCollection collection = (EntityCollection)service.RetrieveMultiple(query);
                if (collection != null && collection.Entities.Count > 0)
                {
                    EntityReference nghselect = new EntityReference(collection.Entities[0].LogicalName, collection.Entities[0].Id);
                    if (targetentity.Attributes.Contains("niq_nghornonnghid"))
                    {
                        targetentity["niq_nghornonnghid"] = nghselect;
                    }
                    else
                    {
                        targetentity.Attributes.Add("niq_nghornonnghid", nghselect);
                    }
                }
            }
            catch { throw; }
        }

        /// <summary>
        /// Get the topic name from the Topic entity
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetentity"></param>
        /// <param name="preimage"></param>
        /// <returns></returns>
        private string GetTopicName(IOrganizationService service, Entity targetentity, Entity preimage)
        {
            string topic = string.Empty;
            try
            {
                Guid topicid = Guid.Empty;
                // topic 
                if (targetentity.Attributes.Contains("niq_topicid") && targetentity["niq_topicid"] != null && (EntityReference)targetentity["niq_topicid"] != null) // topic
                    topicid = ((EntityReference)targetentity.Attributes["niq_topicid"]).Id;
                else if (preimage != null && preimage.Attributes.Contains("niq_topicid") && preimage["niq_topicid"] != null && (EntityReference)preimage["niq_topicid"] != null) // topic
                    topicid = ((EntityReference)preimage.Attributes["niq_topicid"]).Id;
                if (topicid != Guid.Empty)
                {
                    Entity entity = service.Retrieve("niq_topic", topicid, new ColumnSet(new string[] { "niq_name" }));
                    if (entity != null && entity.Attributes.Contains("niq_name"))
                        topic = entity["niq_name"].ToString();
                }
            }
            catch { throw; }
            return topic;
        }

        /// <summary>
        /// Map customerid and contactid  and get the language, client group, operated market to request record 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetentity"></param>
        private string MapAccountContactAttributes(IOrganizationService service, Entity targetentity, Entity preimage, out Guid operatedctryid)
        {
            Guid contactid = Guid.Empty, accountid = Guid.Empty; string custinfo = string.Empty; operatedctryid = Guid.Empty;
            try
            {
                string polymorphiclookuplogicalname = "";
                if (targetentity.Attributes.Contains("customerid") && targetentity["customerid"] != null && (EntityReference)targetentity["customerid"] != null)
                {// contact 
                    accountid = ((EntityReference)targetentity["customerid"]).Id;
                    polymorphiclookuplogicalname = ((EntityReference)targetentity["customerid"]).LogicalName;
                }
                else if (preimage != null && preimage.Attributes.Contains("customerid") && preimage["customerid"] != null && (EntityReference)preimage["customerid"] != null) {
                    accountid = ((EntityReference)preimage["customerid"]).Id;
                    polymorphiclookuplogicalname = ((EntityReference)preimage["customerid"]).LogicalName;
                }
                //check whether as type is account
                if (accountid != Guid.Empty && polymorphiclookuplogicalname == "account") // account  
                {
                    string accdetails = GetAccountGroupMarketDetails(service, accountid, out operatedctryid);
                    if (accdetails != string.Empty)
                        custinfo = accdetails;
                }
                tracer.Trace("Account operated market, group retrieved : " + custinfo);
                // get the contact from the form 
                if (targetentity.Attributes.Contains("primarycontactid") && targetentity["primarycontactid"] != null && (EntityReference)targetentity["primarycontactid"] != null) // contact 
                    contactid = ((EntityReference)targetentity["primarycontactid"]).Id;
                else if (preimage != null && preimage.Attributes.Contains("primarycontactid") && preimage["primarycontactid"] != null && (EntityReference)preimage["primarycontactid"] != null)
                    contactid = ((EntityReference)preimage["primarycontactid"]).Id;
                if (contactid != Guid.Empty) // contact  
                {
                    string contdetails = GetContactLanguageDetails(service, contactid);
                    if (!string.IsNullOrEmpty(contdetails))
                        custinfo += contdetails;
                }
                tracer.Trace("Contact language retrieved : " + custinfo);
            }
            catch { throw; }
            return custinfo;
        }

        /// <summary>
        /// Method to get Operated market & clientrouting group and update the request object 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetentity"></param>
        /// <param name="accountid"></param>
        private string GetAccountGroupMarketDetails(IOrganizationService service, Guid accountid, out Guid operatedctryid)
        {
            string accinfo = string.Empty; operatedctryid = Guid.Empty;
            try
            {
                // get client group and service market from account and populate the request object 
                Entity accentity = service.Retrieve(CommonConstants.ACCOUNTENTITY, accountid, new ColumnSet(new string[] { "niq_serviceroutingclientgroupid", "niq_serviceroutingmarketid" }));
                // populate the input parameter object - routing client groupid 
                if (accentity != null && accentity.Attributes.Contains("niq_serviceroutingclientgroupid"))
                {
                    accinfo = ((EntityReference)accentity["niq_serviceroutingclientgroupid"]).Name + "; ";
                }
                //niq_serviceroutingmarketid
                if (accentity != null && accentity.Attributes.Contains("niq_serviceroutingmarketid"))
                {
                    accinfo += ((EntityReference)accentity["niq_serviceroutingmarketid"]).Name + "; ";
                    operatedctryid = ((EntityReference)accentity["niq_serviceroutingmarketid"]).Id;
                }
            }
            catch { throw; }
            return accinfo;
        }

        /// <summary>
        /// Get the business language from Contact record and populate the request object - input parameter 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="contactid"></param>
        private string GetContactLanguageDetails(IOrganizationService service, Guid contactid)
        {
            string continfo = string.Empty;
            try
            {
                Entity contactentity = service.Retrieve(CommonConstants.CONTACTENTITY, contactid, new ColumnSet("niq_businesslanguageserviceid"));
                if (contactentity != null && contactentity.Attributes.Contains("niq_businesslanguageserviceid"))
                {
                    // contact entity - get the language 
                    continfo = ((EntityReference)contactentity["niq_businesslanguageserviceid"]).Name + ";";
                }
            }
            catch { throw; }
            return continfo;
        }


        /// <summary>
        /// Function to get the name of the NGH agent tier selected in the request record 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetentity"></param>
        /// <param name="preimage"></param>
        /// <returns></returns>
        private string GetNGHAgentTierDetails(IOrganizationService service, Entity targetentity, Entity preimage)
        {
            string tierinfo = string.Empty;
            Guid tierid = Guid.Empty;
            try
            {
                if (targetentity.Attributes.Contains("niq_nghagenttierid") && targetentity["niq_nghagenttierid"] != null && (EntityReference)targetentity["niq_nghagenttierid"] != null) // check ngh tier  
                    tierid = ((EntityReference)targetentity["niq_nghagenttierid"]).Id;
                else if (preimage != null && preimage.Attributes.Contains("niq_nghagenttierid") && preimage["niq_nghagenttierid"] != null && (EntityReference)preimage["niq_nghagenttierid"] != null) // preimage chk  
                    tierid = ((EntityReference)preimage["niq_nghagenttierid"]).Id;
                if (tierid != Guid.Empty)
                {
                    // get the tier name from NGH tier entity
                    Entity tierentity = service.Retrieve(CommonConstants.NGHTIERENTITY, tierid, new ColumnSet("niq_name"));
                    if (tierentity != null && tierentity.Attributes.Contains("niq_name"))
                        tierinfo = tierentity["niq_name"].ToString();
                }
            }
            catch { throw; }
            return tierinfo;
        }

        /// <summary>
        ///  Populate Agent Tier as L1 if no value supplied in UI 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetentity"></param>
        private void PopulateDefaultNGHTierValue(IOrganizationService service, string defaultTier, Entity targetentity)
        {
            try
            {
                QueryByAttribute query = new QueryByAttribute(NGHTIERENTITY);
                query.AddAttributeValue("niq_name", defaultTier);
                query.ColumnSet = new ColumnSet(false);
                EntityCollection collection = (EntityCollection)service.RetrieveMultiple(query);
                if (collection != null && collection.Entities.Count > 0)
                {
                    EntityReference nghtier = new EntityReference(collection.Entities[0].LogicalName, collection.Entities[0].Id);
                    if (targetentity.Attributes.Contains("niq_nghagenttierid"))
                    {
                        targetentity["niq_nghagenttierid"] = nghtier;
                    }
                    else
                    {
                        targetentity.Attributes.Add("niq_nghagenttierid", nghtier);
                    }

                }
            }
            catch { throw; }
        }

        #endregion
    }
}
