if (typeof (ScheduleRibbon) === "undefined") {
    ScheduleRibbon = {
        __namespace: true
    };
}
ScheduleRibbon.Event = {
    createCloneRecord: async function (scheduleAmount, formContext, scheduleName, lineItemId, transactionCurrencyId, scheduleDate, scheduleType, cloneCount) {
        try {
            for (var i = 0; i < cloneCount; i++) {
                Xrm.Utility.showProgressIndicator("Cloning records..");
                var record = {};
                record.niq_amount = Number(parseFloat(scheduleAmount).toFixed(4)); // Currency
                record.niq_iscustomschedule = true; // Boolean
                record.niq_name = scheduleName; // Text
                record["niq_lineitemid@odata.bind"] = "/quotedetails(" + lineItemId + ")"; // Lookup
                record["transactioncurrencyid@odata.bind"] = "/transactioncurrencies(" + transactionCurrencyId + ")"; // Lookup
                record.niq_scheduledate = scheduleDate; // Date Time
                record.niq_scheduletype = scheduleType; // Choice

                await Xrm.WebApi.createRecord("niq_schedule", record).then(
                    function success(result) {
                        var newId = result.id;
                        //console.log(newId);
                    },
                    function (error) {
                        console.log(error.message);
                    }
                );
            }
            var billingScheduleSubgrid = formContext.getControl("Subgrid_Billing_Schedule");
            var revenueScheduleSubgrid = formContext.getControl("Subgrid_Revenue_Schedule");
            var billingScheduleSection = formContext.ui.tabs.get("general").sections.get("billing_schedule_section_8");
            var revenueScheduleSection = formContext.ui.tabs.get("general").sections.get("revenue_schedule_section_9");

            if (billingScheduleSubgrid.getVisible() == true) {
                billingScheduleSubgrid.refresh();
                //we will uncomment if we go with d365 field
                formContext.getAttribute("niq_billingschedulecopies").setValue(null);
            }
            if (revenueScheduleSubgrid.getVisible() == true) {
                revenueScheduleSubgrid.refresh();
                //we will uncomment if we go with d365 field
                formContext.getAttribute("niq_revenueschedulecopies").setValue(null);
            }
            Xrm.Utility.closeProgressIndicator();
        } catch (err) {
            Xrm.Utility.closeProgressIndicator();
        }
    },
    //Below code is for Number of copy fields in form
    numberOfScheduleCopy: function (selectedControl, primaryControl) {
        var selectedRows = selectedControl.getGrid().getSelectedRows();
        var formContext = primaryControl;
        var subgridName = selectedControl._controlName;
        var numberOfCopy = 0;
        if (selectedRows.getLength() === 0) {
            Xrm.Navigation.openAlertDialog({ text: "Please select at least one record to clone." });
            return;
        }
        if (subgridName == "Subgrid_Revenue_Schedule") {
            numberOfCopy = formContext.getAttribute("niq_revenueschedulecopies").getValue();
        }
        if (subgridName == "Subgrid_Billing_Schedule") {
            numberOfCopy = formContext.getAttribute("niq_billingschedulecopies").getValue();
        }
        if (subgridName != '' && numberOfCopy > 0) {
            selectedRows.forEach(async function (row) {
                debugger;
                var entityName = row.getData().getEntity().getEntityName();
                var entityId = row.getData().getEntity().getId().replace('{', '').replace('}', '');
                //Retrieve Schedule Values from the selected schedule in subgrid
                var result = await Xrm.WebApi.retrieveRecord(entityName, entityId, "?$select=niq_scheduleid,niq_name,niq_amount,_transactioncurrencyid_value,niq_iscustomschedule,_niq_lineitemid_value,niq_scheduledate,niq_scheduletype&$expand=niq_lineitemid($select=quotedetailid,niq_billingfrequency,niq_remainingbillingamount,niq_remainingrevenueamount,niq_deliveryfrequency)");
                if (result != null) {
                    var quoteDetailId = "";
                    var billingFrequency = null;
                    var remainingBillingAmount = 0;
                    var remainingRevenueAmount = 0;
                    var revenueFrequency = null;
                    //console.log(result);
                    // Columns
                    var scheduleAmount = result["niq_amount"]; // Currency
                    var cloneCountAmount = Number(numberOfCopy) * Number(scheduleAmount);
                    var scheduleName = result["niq_name"]; // Text
                    var transactionCurrencyId = result["_transactioncurrencyid_value"]; // Lookup
                    var isCustomSchedule = result["niq_iscustomschedule"]; // Boolean
                    var lineItemId = result["_niq_lineitemid_value"]; // Lookup
                    var scheduleDate = result["niq_scheduledate"]; // Date Time
                    var scheduleType = result["niq_scheduletype"]; // Choice

                    if (result.hasOwnProperty("niq_lineitemid") && result["niq_lineitemid"] !== null) {
                        quoteDetailId = result["niq_lineitemid"]["quotedetailid"]; // Guid
                        billingFrequency = result["niq_lineitemid"]["niq_billingfrequency"]; // Choice
                        remainingBillingAmount = result["niq_lineitemid"]["niq_remainingbillingamount"]; // Currency
                        remainingRevenueAmount = result["niq_lineitemid"]["niq_remainingrevenueamount"]; // Currency
                        revenueFrequency = result["niq_lineitemid"]["niq_deliveryfrequency"]; // Choice

                        //This is for Copy Billing schedule 
                        //If billing Frequency is Adhoc and scheduleType is billing and cloneCountAmount is less than equals remaininngBillingAmount
                        if (billingFrequency == 100000009 && scheduleType == 100000000) {
                            if (cloneCountAmount <= remainingBillingAmount) {
                                ScheduleRibbon.Event.createCloneRecord(scheduleAmount, formContext, scheduleName, lineItemId, transactionCurrencyId, scheduleDate, scheduleType, numberOfCopy);
                            } else {
                                Xrm.Navigation.openErrorDialog({ message: "Cloning Schedule Amount is Greater than Remaining Billing Amount.!" });
                                formContext.getAttribute("niq_billingschedulecopies").setValue(null);
                            }
                        }
                        //This is for Copy Revenue schedule
                        //If revenue Frequency is Adhoc and scheduleType is revenue and cloneCountAmount is less than equals remaininngRevenueAmount
                        if (revenueFrequency == 100000009 && (scheduleType == 100000001 || scheduleType == 100000002)) {
                            if (cloneCountAmount <= remainingRevenueAmount) {
                                ScheduleRibbon.Event.createCloneRecord(scheduleAmount, formContext, scheduleName, lineItemId, transactionCurrencyId, scheduleDate, scheduleType, numberOfCopy);
                            } else {
                                Xrm.Navigation.openErrorDialog({ message: "Cloning Schedule Amount is Greater than Remaining Revenue Amount.!" });
                                formContext.getAttribute("niq_revenueschedulecopies").setValue(null);
                            }
                        }
                    }
                }
            });
        } else {
            Xrm.Navigation.openErrorDialog({ message: "Please add greater than 0 number to copy the schedule..!" });
        }
    },
    //Show subgrid new button in custom revenue and billing schedule subgrid
    hideSubgridNewButton: function (selectedControl) {
        var formContext = selectedControl;
        if (formContext.getGrid().controlName === "Subgrid_Revenue_Schedule" || formContext.getGrid().controlName === "Subgrid_Billing_Schedule") {
            return true;
        } else {
            return false;
        }
    },
    //Get the subgrid name on click of subgrid new button(Use this session Item in scheduleformevent)
    getSubgridName : function(selectedControl){
        var formContext = selectedControl;
        var subgridName = formContext.getGrid().controlName;
        sessionStorage.setItem("subgridName", subgridName);
    }
}