if (typeof (AccountForm) === "undefined") {
    AccountForm = {
        __namespace: true
    };
}

AccountForm.Events = {
    ParentAccountOnChange: function (executionContext) { // On Change of Parent Account auto Populate Ultimate Parent Account on the record
        'use strict';
        //added comments
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "parentaccountid") && CommonForm.Events.CheckValueExists(formContext, "parentaccountid")) {
            var parentAccountId = formContext.getAttribute("parentaccountid").getValue()[0].id;
            var globalContext = Xrm.Utility.getGlobalContext();
            var serverUrl = globalContext.getClientUrl();
            var fetchUltimateParent = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                "<entity name='account'>" +
                "<attribute name='accountid' />" +
                "<attribute name='niq_ultimateparentid' />" +
                "<order attribute='niq_ultimateparentid' descending='false' />" +
                "<filter type='and'>" +
                "<condition attribute='accountid' operator='eq' uitype='account' value='" + parentAccountId + "'/>" +
                "</filter>" +
                "</entity>" +
                "</fetch>";

            var fetchUltimateParentResults = GetCRMWebAPI.Methods.GetFetchRecords(serverUrl, fetchUltimateParent, "accounts");

            if (fetchUltimateParentResults !== null && fetchUltimateParentResults.value.length > 0 && fetchUltimateParentResults.value[0] !== null) {
                var retrivedvalue = fetchUltimateParentResults.value[0]._niq_ultimateparentid_value; //get the id of the field
                var retrivedformatedvalue = fetchUltimateParentResults.value[0]["_niq_ultimateparentid_value@OData.Community.Display.V1.FormattedValue"]; //get the formatted name of the field
                if (retrivedvalue !== null && retrivedvalue !== "undefined") {
                    var ultimateParentObj = new Array();
                    ultimateParentObj[0] = new Object();
                    ultimateParentObj[0].id = retrivedvalue;
                    ultimateParentObj[0].name = retrivedformatedvalue;
                    ultimateParentObj[0].entityType = "account";
                    formContext.getAttribute("niq_ultimateparentid").setValue(ultimateParentObj);
                }
                else {
                    var parentAccObj = new Array();
                    parentAccObj[0] = formContext.getAttribute("parentaccountid").getValue()[0];
                    formContext.getAttribute("niq_ultimateparentid").setValue(parentAccObj);
                }

            }
            else {
                var parentAccObj = new Array();
                parentAccObj[0] = formContext.getAttribute("parentaccountid").getValue()[0];
                formContext.getAttribute("niq_ultimateparentid").setValue(parentAccObj);
            }
        }
    },
    toggleSectionsBasedOnAccountSource: function (executionContext) {
        'use strict';
        var formContext = executionContext.getFormContext();
        var accountSource = formContext.getAttribute("niq_accountsource").getValue();


        var zoomInfoSection = formContext.ui.tabs.get("tab_ZoomLusha").sections.get("tab_3_section_8");
        var lushaSection = formContext.ui.tabs.get("tab_ZoomLusha").sections.get("tab_3_section_90");
        if (accountSource === 610570000)//Show lusha
        {
            zoomInfoSection.setVisible(false);
            lushaSection.setVisible(true);
        }
        else if (accountSource === 100000034) {//Show Zoom info
            zoomInfoSection.setVisible(true);
            lushaSection.setVisible(false);
        }
        else {
            zoomInfoSection.setVisible(false);
            lushaSection.setVisible(false);
        }

    },

    formOnLoadDisableSapFields: function (executionContext) { // Disable fields of a Sap Account Tab for non-admin users on load of form if acc type is SAP Account
        'use strict';
        this.accTypeOnChange(executionContext);// On Change of Acc type/Form Load SHow or Hide the Account Tabs based on Acc Type
        this.onCreateDisableReadOnly(executionContext);//  Enable the Account Type Field For Admin Role while account create
        this.servicefieldisableforNGH(executionContext); //Enable service field only for NGH
        this.setUltimateParentFilter(executionContext);  //Set Filer to show only customer accounts on Ultimate Parent
        this.CustomerTypefieldisableforRoles(executionContext);
        this.SAPAccountRequestsTab(executionContext);
        this.HandleAccSalesLoftFields(executionContext);
        
        var formContext = executionContext.getFormContext();
        this.disableWelcomePackageEmailsFieldForRoles(executionContext);
        var tab = formContext.ui.tabs.get("tab_4");
        var accType = formContext.getAttribute("niq_accounttype").getValue()
        if (accType !== null && accType === 2 && tab !== null && tab !== "undefined") {
            formContext.ui.navigation.items.forEach(function(item) {
                if(item._id === "nav_msa_partner_opportunity" || item._id === "navOppsParent")
                    item.setVisible(false);
            });

            if (!CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer")) {
                var tabsections = tab.sections.get();
                for (var i in tabsections) {
                    var sectionName = tabsections[i].getName();
                    CommonForm.Events.EnableOrDisableSection(formContext, "tab_4", sectionName, true);
                }
            }
        }
        this.toggleSectionsBasedOnAccountSource(executionContext);
  this.updateSalesloftOwnerEmail(executionContext);
    },
     updateSalesloftOwnerEmail: function (executionContext) {
     var formContext = executionContext.getFormContext();
     var ownerLookup = formContext.getAttribute("niq_basessalesloftowner").getValue();

     if (ownerLookup && ownerLookup.length > 0) {
         var ownerId = ownerLookup[0].id.replace("{", "").replace("}", "");

         Xrm.WebApi.retrieveRecord("systemuser", ownerId, "?$select=internalemailaddress").then(
             function (result) {
                 if (result && result.internalemailaddress) {
                     formContext.getAttribute("niq_accsaisalesloftowneremail").setValue(result.internalemailaddress);
                 } else {
                     formContext.getAttribute("niq_accsaisalesloftowneremail").setValue(null);
                 }
             }
         );
     } else {
         formContext.getAttribute("niq_accsaisalesloftowneremail").setValue(null);
     }
   },

CustomerTypefieldisableforRoles: function (executionContext) {
        'use strict';
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer,NIQ Add-on Deal Desk Approver")) {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_customertype")) {
               
                formContext.getControl("niq_customertype").setDisabled(false);
            }
        }
        else {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_customertype")) {
                formContext.getControl("niq_customertype").setDisabled(true);
            }

        }

    },

disableWelcomePackageEmailsFieldForRoles: function (executionContext) {
    "use strict";

    var formContext = executionContext.getFormContext();
    if(CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Global Helpline Agent,NIQ Global Helpline Manager,System Administrator"))
    {  
        formContext.getControl("niq_ngh_discoveraccess_isemailon").setDisabled(false);
    }
    else 
    {
        formContext.getControl("niq_ngh_discoveraccess_isemailon").setDisabled(true);
    }
},

    onCreateDisableReadOnly: function (executionContext) { //  Enable the Account Type Field For Admin Role while account create
        'use strict';
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        if (formType === 1) { //To check the form type is in create mode 

            if (CommonForm.Events.CheckIfLoggedInUserRoles("Business Admin,System Administrator,System Customizer")) // To check non-admin roles
            {
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_accounttype")) {
                    formContext.getControl("niq_accounttype1").setDisabled(false); // To make account type field editable
                    formContext.getControl("niq_accounttype2").setDisabled(false); //To make account type field editable
                }
            }
            else {
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_accounttype")) {
                    formContext.getControl("niq_accounttype1").setDisabled(true);// To make account type field readonly
                    formContext.getControl("niq_accounttype2").setDisabled(true);// To make account type field readonly
                }
            }

        }
        else {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_accounttype")) {
                formContext.getControl("niq_accounttype1").setDisabled(true);// To make account type field readonly
                formContext.getControl("niq_accounttype2").setDisabled(true);// To make account type field readonly
            }
        }
    },
    servicefieldisableforNGH: function (executionContext) {
        'use strict';
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("System Administrator,NIQ Global Helpline Manager")) {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_nghspecialclient")) {
               
                formContext.getControl("niq_nghspecialclient").setDisabled(false);
            }
        }
        else {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_nghspecialclient")) {
                formContext.getControl("niq_nghspecialclient").setDisabled(true);
            }

        }

    },
    accTypeOnChange: async function (executionContext) { // On Change of Acc type/Form Load SHow or Hide the Account Tabs based on Acc Type
        'use strict';
        var formContext = executionContext.getFormContext();

        if (CommonForm.Events.CheckFieldExists(formContext, "niq_accounttype")) {  // To Check Either Account Type Field Exists Or Not
            var accountType = formContext.getAttribute("niq_accounttype").getValue();
            if (accountType !== "undefined" && accountType === 2) {   //To ensure Account type field and SAP Account summary tab are having valid information
                this.setUltimateParentFilter(executionContext);
                CommonForm.Events.ShowHideTabs(formContext, "tab_3", false);
                CommonForm.Events.ShowHideTabs(formContext, "tab_4", true);//To Make SAP account summary tab visible
                CommonForm.Events.ShowHideTabs(formContext, "Finance_Approval_Requests", true);
                CommonForm.Events.SetFocusTabs(formContext, "tab_4");//To focus on SAP account tab
                //DYNCRM-23818 - Hide SAP Account Requests tab for SAP Account
                CommonForm.Events.ShowHideTabs(formContext, "tab_SAP_Account_Requests", false);
            }
            else if (accountType !== "undefined" && accountType === 1) {
                CommonForm.Events.ShowHideTabs(formContext, "tab_4", false);
                CommonForm.Events.ShowHideTabs(formContext, "Finance_Approval_Requests", false);
                CommonForm.Events.ShowHideTabs(formContext, "tab_3", true);
                CommonForm.Events.SetFocusTabs(formContext, "tab_3"); //To focus on Customer account tab
                //DYNCRM-23818 - Show SAP Account Requests tab for Customer Account
                CommonForm.Events.ShowHideTabs(formContext, "tab_SAP_Account_Requests", true);
            }
            else if(accountType === null)
            {
                //DYNCRM-23818 - Hide SAP Account Requests tab
                CommonForm.Events.ShowHideTabs(formContext, "tab_SAP_Account_Requests", false);
            }
        }
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_accounttype")){
            var accountTypeSAP = formContext.getAttribute("niq_accounttype").getValue();
            //var navItem = formContext.ui.navigation.items;
            var navigationItem = "";
            var trueFlag = await this.ShowNIQGFKAugRelease();
            if(accountTypeSAP == 2 && trueFlag.toLowerCase() == "true"){
                CommonForm.Events.ShowHideTabs(formContext, "tab_9", false); //Opportunity tab
                CommonForm.Events.ShowHideTabs(formContext, "tab_10", false); //Contact tab
                CommonForm.Events.ShowHideTabs(formContext, "tab_11", false); //Lead tab
                CommonForm.Events.ShowHideTabs(formContext, "tab_18", true); //SAP Account Finance details
                CommonForm.Events.ShowHideTabs(formContext, "assets", false); //Asset tab
                CommonForm.Events.ShowHideTabs(formContext, "Asset_Documents", false); //Asset Documents tab
                CommonForm.Events.ShowHideTabs(formContext, "Finance_Approval_Requests", false); //FAR tab

                var arrNavItems = ["nav_niq_account_niq_accountrole","nav_niq_account_niq_activitytracker_ataccount","nav_msdyn_account_bookableresource_Vendor","nav_niq_msfp_alert_niq_RelatedAccount_account",
                "nav_niq_account_niq_clientobjective_AccountName","nav_niq_account_niq_qbo","nav_niq_account_niq_niqaccountgoal_accountameid","nav_niq_account_niq_accountplanstakeholder_AccountName",
                "nav_msa_contact_managingpartner","nav_niq_postopportunity_AccountName_account","nav_niq_postopportunity_CurrentBillToParty_accoun","nav_niq_postopportunity_CurrentDeliverToParty_acc",
                "nav_niq_postopportunity_NewDeliveryToParty_accoun","nav_niq_account_niq_bulkrequestcreation_Account","nav_msdyn_account_msdyn_ocliveworkitem_Customer"    
                ];
                for(var i = 0;i<arrNavItems.length;i++){
                    navigationItem = formContext.ui.navigation.items.getAll().find(function(item) {
                        return item._id === arrNavItems[i];
                    });
                     if (navigationItem) {
                        // Hide the navigation item
                        navigationItem.setVisible(false);
                    }
                }
            }else{
                CommonForm.Events.ShowHideTabs(formContext, "tab_9", true); //Opportunity tab
                CommonForm.Events.ShowHideTabs(formContext, "tab_10", true); //Contact tab
                CommonForm.Events.ShowHideTabs(formContext, "tab_11", true); //Lead tab
                CommonForm.Events.ShowHideTabs(formContext, "tab_18", false); //SAP Account Finance details
                CommonForm.Events.ShowHideTabs(formContext, "assets", true); //Asset tab
                CommonForm.Events.ShowHideTabs(formContext, "Asset_Documents", true); //Asset Documents tab
                CommonForm.Events.ShowHideTabs(formContext, "Finance_Approval_Requests", true); //FAR tab
            }
        }
    },
    //retrieve the flag for aug release
    ShowNIQGFKAugRelease: async function(){
        var result = await Xrm.WebApi.retrieveRecord("niq_configurationsetting", "982a3707-594b-f011-877a-6045bda1abcd", "?$select=niq_name,niq_to");
        var niq_to = result["niq_to"];
        return niq_to;
    },
    setUltimateParentFilter: function (executionContext) {
        // get the form context
        formContext = executionContext.getFormContext();
        if (formContext.getControl("niq_ultimateparentid")) {
            var account = formContext.getControl('niq_ultimateparentid');

            if (account.getEntityTypes().length > 1) {
                account.setEntityTypes(['account']);
            }
            formContext.getControl("niq_ultimateparentid").addPreSearch(this.filterCustomerAccounts);
        }
    },

    //hide show SAP Account Requests Tab if Account Type is SAP Account
    SAPAccountRequestsTab: function(executionContext){
        var formContext = executionContext.getFormContext();
        var accountType = formContext.getAttribute("niq_accounttype")?.getValue();
        if(accountType === 2) // account type is SAP Account
        {
            formContext.ui.tabs.get("SAP Account Requests").setVisible(true);
        }
        else
        {
            formContext.ui.tabs.get("SAP Account Requests").setVisible(false);
        }
    },

    filterCustomerAccounts: function () {
        // Only show accounts with the type 'Customer Account'
        var customeraccount = 1;
        //formContext = executionContext.getFormContext();
        var customerAccountFilter = "<filter type='and'>  <condition attribute='statecode' operator='eq' value='0' /> <condition attribute='niq_accounttype' operator='eq' value='" + customeraccount + "' /> </filter>";
        formContext.getControl("niq_ultimateparentid").addCustomFilter(customerAccountFilter, "account");
    },

    Servicetabeditefunction (executionContext) 
    {
      var formContext = executionContext.getFormContext();
      if (!CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer,NIQ Project Manager,NIQ Sales User,NIQ Marketing User,NIQ Marketing Manager - Business,NIQ Marketing Professional - Business,Sales Manager") && formContext.ui.getFormType()!=1)
      {
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Client Response Manager,NIQ Client Response Agent,NIQ Analytics Agent,NIQ Analytics Manager,NIQ Global Helpline Agent,NIQ Global Helpline Manager"))
        {
              if (CommonForm.Events.CheckFieldExists(formContext, "niq_accounttype"))
          {
              formContext.ui.controls.forEach(function (control, index) {
       
                      control.setDisabled(true);
       
       
              });
        
              formContext.getControl("niq_serviceroutingmarketid").setDisabled(false); 
              formContext.getControl("niq_serviceroutingclientgroupid").setDisabled(false); 
              formContext.getControl("niq_servicedomains").setDisabled(false); 
              formContext.getControl("niq_serviceaccountadvisory").setDisabled(false); 
              formContext.getControl("niq_knowledgepermissionsets").setDisabled(false); 
              formContext.getControl("niq_nghspecialclient").setDisabled(false); 
			  formContext.getControl("niq_hypercare2").setDisabled(false);
              formContext.getControl("niq_platformaccountadvisory").setDisabled(false);
			  formContext.getControl("niq_ncporganizationname").setDisabled(false);
			  formContext.getControl("niq_ncporganizationid").setDisabled(false);
			  formContext.getControl("niq_accountdeveloper").setDisabled(false);
			  formContext.getControl("niq_discovercompanyname").setDisabled(false);
			  formContext.getControl("niq_discovercompanyid").setDisabled(false);
              if (formContext.getAttribute("niq_dataplan").getValue()) {
                formContext.getControl("niq_dataplan").setDisabled(true);
              } else {
                formContext.getControl("niq_dataplan").setDisabled(false);
              }
                   
              }
              else {
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_accounttype")) 
                {
                    formContext.getControl("niq_serviceroutingmarketid").setDisabled(true);
                  formContext.getControl("niq_serviceroutingclientgroupid").setDisabled(true); 
                  formContext.getControl("niq_servicedomains").setDisabled(true);
                  formContext.getControl("niq_serviceaccountadvisory").setDisabled(true);
                  formContext.getControl("niq_knowledgepermissionsets").setDisabled(true);
                  formContext.getControl("niq_nghspecialclient").setDisabled(true);
                  formContext.getControl("niq_hypercare2").setDisabled(true);
                 formContext.getControl("niq_platformaccountadvisory").setDisabled(true);
				 formContext.getControl("niq_ncporganizationname").setDisabled(true);
				formContext.getControl("niq_ncporganizationid").setDisabled(true);
			  formContext.getControl("niq_accountdeveloper").setDisabled(true);
			  formContext.getControl("niq_discovercompanyname").setDisabled(true);
			  formContext.getControl("niq_discovercompanyid").setDisabled(true);
              if (formContext.getAttribute("niq_dataplan").getValue()) {
                formContext.getControl("niq_dataplan").setDisabled(true);
              } else {
                formContext.getControl("niq_dataplan").setDisabled(false);
              }                }
          }

        }

      }

    },
    FilterPrimarySAPAccountLookup: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var currentAccountGUID = formContext.data.entity.getId();
        currentAccountGUID = currentAccountGUID.replace(/[{}]/g, "");
        if (formContext.getControl("niq_primarysapaccount")) {
            formContext.getControl("niq_primarysapaccount").addPreSearch(function () {
                var filter = `<filter type="and">
      <condition attribute="niq_ultimateparentid" operator="eq" value="${currentAccountGUID}" />
      <condition attribute="niq_accounttype" operator="eq" value="2" />
    </filter>`;
                formContext.getControl("niq_primarysapaccount").addCustomFilter(filter);
            });
        }
    },

    // DYNCRM-25363
    populateFinanceIndustryMapping: async function(executionContext)
    {
        "use strict";
        var formContext = executionContext.getFormContext();
        if(CommonForm.Events.CheckFieldExists(formContext, "niq_industry") && CommonForm.Events.CheckValueExists(formContext, "niq_industry"))
        {
            var industry = formContext.getAttribute("niq_industry").getValue();
            var ultimateParentAccount="";
            if(CommonForm.Events.CheckFieldExists(formContext, "niq_ultimateparentid") && CommonForm.Events.CheckValueExists(formContext, "niq_ultimateparentid")){
                ultimateParentAccount = formContext.getAttribute("niq_ultimateparentid").getValue()[0].id.replace("{", "").replace("}", "");
                try
                {
                    var result = await Xrm.WebApi.retrieveMultipleRecords("niq_hfmcode", "?$select=niq_financeindustryl1mapping,niq_financeindustryl2mapping&$filter=niq_industry eq " + industry +" and niq_isfinancialindustrymapping eq true and _niq_ultimateparentaccount_value eq "+ultimateParentAccount);
                    if (result.entities.length > 0)
                    {
                        var Record = result.entities[0];
                        var hfmCodeL1Mapping = Record.niq_financeindustryl1mapping;
                        var hfmCodeL2Mapping = Record.niq_financeindustryl2mapping;
                        if((hfmCodeL1Mapping != null && hfmCodeL1Mapping != undefined && hfmCodeL1Mapping != "") || (hfmCodeL2Mapping != null && hfmCodeL2Mapping != undefined && hfmCodeL2Mapping != "")){
                            formContext.getAttribute("niq_financeindustryl1mapping").setValue(hfmCodeL1Mapping);
                            formContext.getAttribute("niq_financeindustryl2mapping").setValue(hfmCodeL2Mapping);
                        }
                        else{
                            AccountForm.Events.populateFinanceIndustryMappingifUltimateParentAccountIsEmpty(executionContext);
                        }
                    }
                    else
                    {
                        AccountForm.Events.populateFinanceIndustryMappingifUltimateParentAccountIsEmpty(executionContext);
                    }
                }
                catch (error) 
                {
                    console.error("Error retrieving finance industry mappings: " + error.message);
                }
            }
            else{
                AccountForm.Events.populateFinanceIndustryMappingifUltimateParentAccountIsEmpty(executionContext);
            }
        }  
    },
    /**
    * Controls visibility and lock state of SalesLoft fields based on account type and user role.
    * Shows 'niq_accsaisalesloftowneremail' only for SAP Account (2)
    * Shows 'niq_accsaipracticearea' only for Customer Account (1)
    * Locks 'niq_accsaisalesloftowneremail' for all except System Administrator
    * @param {object} executionContext - The execution context from the form event.
    */
    HandleAccSalesLoftFields: function(executionContext) {
        var formContext = executionContext?.getFormContext();
        if (!formContext) return;
    
        var accountType = formContext.getAttribute("niq_accounttype")?.getValue();
        var isAdmin = CommonForm?.Events?.CheckIfLoggedInUserRoles?.("System Administrator") || false;
    
        var salesLoftEmail = formContext.getControl("niq_accsaisalesloftowneremail");
        var practiceArea = formContext.getControl("niq_accsaipracticearea");
    
        salesLoftEmail?.setVisible(accountType === 1);
        salesLoftEmail?.setDisabled(!isAdmin);
        practiceArea?.setVisible(accountType === 1);
    },
    populateFinanceIndustryMappingifUltimateParentAccountIsEmpty: async function(executionContext){
        "use strict";
        var formContext = executionContext.getFormContext();
        var industry = formContext.getAttribute("niq_industry").getValue();
        try
        {
            var result = await Xrm.WebApi.retrieveMultipleRecords("niq_hfmcode", "?$select=niq_financeindustryl1mapping,niq_financeindustryl2mapping&$filter=niq_industry eq " + industry+" and niq_isfinancialindustrymapping eq true");
            if (result.entities.length > 0)
            {
                var Record = result.entities[0];
                var hfmCodeL1Mapping = Record.niq_financeindustryl1mapping;
                formContext.getAttribute("niq_financeindustryl1mapping").setValue(hfmCodeL1Mapping);
                var hfmCodeL2Mapping = Record.niq_financeindustryl2mapping;
                formContext.getAttribute("niq_financeindustryl2mapping").setValue(hfmCodeL2Mapping);
            }
            else
            {
                formContext.getAttribute("niq_financeindustryl1mapping").setValue(null);
                formContext.getAttribute("niq_financeindustryl2mapping").setValue(null);
            }
        }
        catch (error) 
        {
            console.error("Error retrieving finance industry mappings: " + error.message);
        }
    },
    ExcludefromDBOptimizerfielenableforRoles: function (executionContext) {
        'use strict';
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("D&B Optimizer Administrator")) {
            if (CommonForm.Events.CheckFieldExists(formContext, "dnb_excludefromoptimizer")) {
               
                formContext.getControl("dnb_excludefromoptimizer").setDisabled(false);
                formContext.getControl("dnb_excludefromoptimizer").setVisible(true);
            }
        }
        else {
            if (CommonForm.Events.CheckFieldExists(formContext, "dnb_excludefromoptimizer")) {
                formContext.getControl("dnb_excludefromoptimizer").setDisabled(true);
                formContext.getControl("dnb_excludefromoptimizer").setVisible(false);
            }
        }
    }
}

function filterLookup(executionContext) {
    var formContext = executionContext.getFormContext();
    var Industry = formContext.getAttribute("niq_industry").getValue();
    if (Industry != null) {
        formContext.getControl("niq_subindustry").addPreSearch(function () {
            addLookupFilter(formContext);
        });
    }
}
function addLookupFilter(formContext) {
    var Industry = formContext.getAttribute("niq_industry").getValue();
    if (Industry != null && Industry != undefined) {
        var fetchxmL = "<filter type='and'><condition attribute = 'niq_industry' operator = 'eq' value = '" + Industry + "' /></filter >"
        formContext.getControl("niq_subindustry").addCustomFilter(fetchxmL, "niq_subindustry");
    }
}

function clearSubIndustryValue (executionContext){
    var formContext = executionContext.getFormContext();
 
    var industry = formContext.getAttribute("niq_industry");
    var subIndustry = formContext.getAttribute("niq_subindustry");
 
    if(industry && subIndustry){
 
        var subIndustryValue = subIndustry.getValue();
 
        if(subIndustryValue != null){
            subIndustry.setValue(null);
        }
    }
}

//DYNCRM-23920 - SAP Accounts Related tab on Customer Accounts
function toggleTabRelatedSAPAccounts(executionContext) {
	var formContext = executionContext.getFormContext();
    var AccountId = formContext.data.entity.getId();
	

var fetchXml = `?fetchXml=
    <fetch mapping='logical'>
  <entity name="account">
    <attribute name="name" />
    <filter type="and">
      <condition attribute="niq_accounttype" operator="eq" value="2" />
      <condition attribute="niq_ultimateparentid" operator="eq" uitype="account" value="${AccountId}" />
    </filter>
  </entity>
</fetch>`;



Xrm.WebApi.retrieveMultipleRecords("account", fetchXml).then(
    function success(result) {
		
		if(result.entities.length>=1) {  
		Xrm.Page.ui.tabs.get("tab_related_sap_accounts").setVisible(true);
        } else{
             Xrm.Page.ui.tabs.get("tab_related_sap_accounts").setVisible(false);
        }
        // perform additional operations on retrieved records
    },
    function (error) {
        console.log(error.message);
        // handle error conditions
    }
);

}

//DYNCRM-23752 - Customer Account - Page Layout
AccountForm.Events.LockManagementReportingInformationFields = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();
    if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer")) {
        //Make fields editable for admins
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_customertype")) formContext.getControl("niq_customertype").setDisabled(false);
        if (CommonForm.Events.CheckFieldExists(formContext, "ParentAccountId")) formContext.getControl("ParentAccountId").setDisabled(false);
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_ultimateparentid")) formContext.getControl("niq_ultimateparentid").setDisabled(false);
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_FinanceindustryL1mapping")) formContext.getControl("niq_FinanceindustryL1mapping").setDisabled(false);
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_FinanceindustryL2mapping")) formContext.getControl("niq_FinanceindustryL2mapping").setDisabled(false);
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_SegmentationL1")) formContext.getControl("niq_SegmentationL1").setDisabled(false);
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_SegmentationL2")) formContext.getControl("niq_SegmentationL2").setDisabled(false);
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_ClientShortName")) formContext.getControl("niq_ClientShortName").setDisabled(false);
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_SalesGroup")) formContext.getControl("niq_SalesGroup").setDisabled(false);
    }
    else {
        //Make fields readonly for non-admins
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_customertype")) formContext.getControl("niq_customertype").setDisabled(true);
        if (CommonForm.Events.CheckFieldExists(formContext, "ParentAccountId")) formContext.getControl("ParentAccountId").setDisabled(true);
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_ultimateparentid")) formContext.getControl("niq_ultimateparentid").setDisabled(true);
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_FinanceindustryL1mapping")) formContext.getControl("niq_FinanceindustryL1mapping").setDisabled(true);
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_FinanceindustryL2mapping")) formContext.getControl("niq_FinanceindustryL2mapping").setDisabled(true);
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_SegmentationL1")) formContext.getControl("niq_SegmentationL1").setDisabled(true);
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_SegmentationL2")) formContext.getControl("niq_SegmentationL2").setDisabled(true);
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_ClientShortName")) formContext.getControl("niq_ClientShortName").setDisabled(true);
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_SalesGroup")) formContext.getControl("niq_SalesGroup").setDisabled(true);
    }
}

//DYNCRM-23752 - Customer Account - Page Layout
AccountForm.Events.ShowHideZoomInfoLushaTab = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();
    var accountSource = formContext.getAttribute("niq_accountsource").getValue();

    if (accountSource === null && accountSource === "") {
        formContext.ui.tabs.get("tab_ZoomLusha").setVisible(false);
    }
    else if (accountSource === 100000034 || accountSource === 610570000) { //ZoomInfo : 100000034, Lusha : 610570000
        formContext.ui.tabs.get("tab_ZoomLusha").setVisible(true);
    }
    else {
        formContext.ui.tabs.get("tab_ZoomLusha").setVisible(false);
    }
}