if (typeof (QuoteProductForm) === "undefined") {
    QuoteProductForm = {
        __namespace: true
    };
}
QuoteProductForm.Events = {
    opportunityType: null,
    opportunityApprovalStatus: null,
    intialOppCheckflag: false,
    isFinanceorAdminUserflag: false,
    isFinanceorAdminUserCheckflag: false,
    OriginalStartdate: null,
    OriginalEnddate: null,
    revenueScheduleStatus: {
        IncompleteManualInput: 610570001,
        CompleteManualInput: 610570004
    },
    billingScheduleStatus: {
        IncompleteManualInput: 610570001,
        CompleteManualInput: 610570004
    },
    OnFormLoad: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        this.LockBasesSolutionFormerName(executionContext);
        this.LockEndDate(executionContext);
        this.isFinanceorAdminUserflag = CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User,NIQ Business Admin,System Administrator,System Customizer");
        this.isFinanceorAdminUserCheckflag = true;
        if (formContext.getAttribute('quoteid').getValue() !== undefined && formContext.getAttribute('quoteid').getValue() !== null &&
            formContext.getAttribute('quoteid').getValue().length > 0 && formContext.getAttribute('quoteid').getValue()[0].id !== undefined &&
            formContext.getAttribute('quoteid').getValue()[0].id !== null)
            this.checkOpportunityInfo(executionContext, formContext.getAttribute('quoteid').getValue()[0].id);
        this.LockBasesStudyNumber(executionContext);
        /*this.LockUnlockInvoicetext(executionContext);*/
        var formType = formContext.ui.getFormType();
        if (formType != 0 && formType != 1) {
            this.ShowHideForAdmins(executionContext);
        }

        //21236 - don't change the order of function call.
        this.FilteredFrequenciesForSalesUser(executionContext);
        this.SetTermLength(executionContext);

        this.LockUnlockProjectReferenceID(executionContext);
        this.WbsFieldEditableForSales(executionContext);
        this.hideShowBillingStartEndDate(executionContext);
        //this.AppendUserSelectedOption(executionContext);
        //this.hideShowRevShareLine(executionContext);
        //this.ShowIndicator(executionContext);
    },
    /*
        OnPaneFormLoad: function (executionContext) {
            this.FilteredFrequenciesForSalesUser(executionContext);
            this.RegisterSendMessage(executionContext);
            this.showCustomScheduleInPaneForm(executionContext);
            this.SetTermLength(executionContext);
            this.hideShowBillingStartEndDate(executionContext);
            //this.hideShowRevShareLine(executionContext);
            //this.ShowIndicator(executionContext);
            this.LoadSidePane4REVSHAR(executionContext);
    */
    OnPaneFormLoad: async function run(executionContext) {
        this.LockEndDate(executionContext);
        await this.FilteredFrequenciesForSalesUser(executionContext);
        this.RegisterSendMessage(executionContext);
        await this.showCustomScheduleInPaneForm(executionContext);
        await this.SetTermLength(executionContext);
        this.hideShowBillingStartEndDate(executionContext);
        this.LoadSidePane4REVSHAR(executionContext);


    },

    refreshParentForm: function (executionContext) {
        var formContext = executionContext.getFormContext();
        // Refresh the parent form
        if (formContext.ui) {
            formContext.data.refresh();
        }
    },
    /*ShowIndicator: function (executionContext) {
        var formContext = executionContext.getFormContext();

        // Show progress indicator immediately when the form loads
        Xrm.Utility.showProgressIndicator("Validating required fields...");

        // List of required fields on Quote Product
        var requiredFields = [
            "niq_updatefrequency",
            "niq_deliveryfrequency",
            "niq_lagrevenuerecognition",
            "niq_billingfrequency",
            "niq_lineitemstartdate",
            "niq_lineitemenddate"
        ];

        // Flag to track if progress indicator has been closed
        var progressClosed = false;

        // Function to validate fields
        function validateFields() {
            var allFieldsPopulated = requiredFields.every(function (fieldName) {
                var fieldValue = formContext.getAttribute(fieldName).getValue();
                return fieldValue !== null && fieldValue !== "";
            });

            if (allFieldsPopulated) {
                // All fields are populated
                if (!progressClosed) {
                    Xrm.Utility.closeProgressIndicator();
                    progressClosed = true;
                }
                formContext.ui.setFormNotification(
                    "All required fields are populated. You can now edit the form.",
                    "INFO",
                    "validation_complete"
                );
            } else {
                // Some fields are missing
                if (!progressClosed) {
                    Xrm.Utility.showProgressIndicator("Some required fields are missing. Refreshing form in 20 seconds...");

                    // Schedule a full page refresh after 20 seconds
                    setTimeout(function () {
                        formContext.data.refresh(false).then(function(){
                            validateFields();
                        }); // Reload the entire page
                    }, 20000); // 20 seconds
                }
            }
        }

        

        // Close the progress indicator after 90 seconds regardless of field status
        setTimeout(function () {
            if (!progressClosed) {
                Xrm.Utility.closeProgressIndicator();
                progressClosed = true;
                formContext.ui.setFormNotification(
                    "Validation timed out after 60 seconds. Please recheck the form manually.",
                    "WARNING",
                    "validation_timeout"
                );
            }
        }, 60000); // 60 seconds

        // Initial validation
        validateFields();
    },*/
    LockBasesSolutionFormerName: function (executionContext) {
        var formContext = executionContext.getFormContext();
        if (!CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator")) {
            formContext.getControl("niq_basessolutionformername").setDisabled(true);
        }
    },
    LockUnlockProjectReferenaceID: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (!this.intialOppCheckflag) {
            this.checkOpportunityInfo(executionContext, (Xrm.Utility.getPageContext() !== undefined && Xrm.Utility.getPageContext() !== null &&
                Xrm.Utility.getPageContext().input !== undefined && Xrm.Utility.getPageContext().input !== null &&
                Xrm.Utility.getPageContext().input.entityName != undefined && Xrm.Utility.getPageContext().input.entityName != null &&
                Xrm.Utility.getPageContext().input.entityName === 'quote') ?
                Xrm.Utility.getPageContext().input.entityId : formContext.getAttribute('quoteid').getValue()[0].id);
        }
        if (!this.isFinanceorAdminUserCheckflag) {
            this.isFinanceorAdminUserflag = CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User,NIQ Business Admin,System Administrator,System Customizer");
            this.isFinanceorAdminUserCheckflag = true;
        }

        if (this.opportunityType !== null && this.opportunityType === 1) {
            this.SetDisableGridColumn(formContext.getAttribute("niq_projectid"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_databasename"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_contractproductname"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_fundusagetype"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_dealguidance"), true);
        }
        else {
            this.SetDisableGridColumn(formContext.getAttribute("niq_projectid"), false);
            this.SetDisableGridColumn(formContext.getAttribute("niq_databasename"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_contractproductname"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_fundusagetype"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_dealguidance"), true);
        }
        if (this.opportunityType !== null && this.opportunityType === 1)
            if (this.opportunityApprovalStatus !== null && this.opportunityApprovalStatus === 100000001) {
                this.SetDisableGridColumn(formContext.getAttribute("niq_invoicetext"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_databasename"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_contractproductname"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_fundusagetype"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_dealguidance"), true);

                if (!this.isFinanceorAdminUserflag)
                    this.SetDisableGridColumn(formContext.getAttribute("niq_wbs"), true);
                //this.SetDisableGridColumn(formContext.getAttribute("niq_remark"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_databasename"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_contractproductname"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_fundusagetype"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_basesstudynumber"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_dealguidance"), true);
            }
            else {
                this.SetDisableGridColumn(formContext.getAttribute("niq_invoicetext"), false);
                this.SetDisableGridColumn(formContext.getAttribute("niq_wbs"), false);
                //this.SetDisableGridColumn(formContext.getAttribute("niq_remark"), false);
                this.SetDisableGridColumn(formContext.getAttribute("niq_databasename"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_contractproductname"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_fundusagetype"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_dealguidance"), true);
            }

    },
    SetDisableGridColumn: function (attrCtrl, isDisable) {
        "use strict";
        try {
            attrCtrl.controls.forEach(function (control) {
                control.setDisabled(isDisable);
            });
        }
        catch (ex) {
            Xrm.Navigation.openErrorDialog({ message: "Error occurd in QuoteProductForm.Events.SetDisableGridColumn method.", details: ex });
        }
    },

    LockUnlockInvoicetext: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_invoicetext") && CommonForm.Events.CheckValueExists(formContext, "quoteid")) {
            var quote = formContext.getAttribute("quoteid").getValue();
            var quote_id = quote[0].id.replace('{', '').replace('}', '');
            Xrm.WebApi.online.retrieveRecord("quote", quote_id, "?$select=_opportunityid_value&$expand=opportunityid($select=niq_approvalstatus)").then(
                function success(result) {
                    var oppoValue = result["_opportunityid_value"];
                    if (oppoValue !== null) {
                        if (result.hasOwnProperty("opportunityid")) {
                            var approvalstatus = result["opportunityid"]["niq_approvalstatus"];

                            if (approvalstatus === 100000001) {
                                formContext.getControl("niq_invoicetext").setDisabled(true);
                            }
                        }
                    }
                },
                function (error) {

                }
            );
        }
    },
    WbsFieldEditableForSales: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User")) {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_wbs") && CommonForm.Events.CheckValueExists(formContext, "quoteid")) {
                var quote = formContext.getAttribute("quoteid").getValue();
                var quote_id = quote[0].id.replace('{', '').replace('}', '');
                Xrm.WebApi.online.retrieveRecord("quote", quote_id, "?$select=_opportunityid_value&$expand=opportunityid($select=niq_approvalstatus,statecode)").then(
                    function success(result) {
                        var _opportunityid_value = result["_opportunityid_value"];
                        if (result.hasOwnProperty("opportunityid")) {
                            var opportunityApprovalStatus = result["opportunityid"]["niq_approvalstatus"];
                            var opportunityStatus = result["opportunityid"]["statecode"];
                            //1- won, 2- lost, 100000001- pending
                            if ((opportunityStatus === 1 || opportunityStatus === 2) || opportunityApprovalStatus === 100000001) {
                                formContext.getControl("niq_wbs").setDisabled(true);
                            }
                            if (opportunityStatus === 1) {
                                CommonForm.Events.disableFormFields(true, formContext);
                            }
                        }
                    },
                    function (error) { }
                );
            }
        }
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User") || (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User"))) {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_wbs") && CommonForm.Events.CheckValueExists(formContext, "quoteid")) {
                var quote = formContext.getAttribute("quoteid").getValue();
                var quote_id = quote[0].id.replace('{', '').replace('}', '');
                Xrm.WebApi.online.retrieveRecord("quote", quote_id, "?$select=_opportunityid_value&$expand=opportunityid($select=niq_approvalstatus,statecode)").then(
                    function success(result) {
                        var _opportunityid_value = result["_opportunityid_value"];
                        if (result.hasOwnProperty("opportunityid")) {
                            var opportunityApprovalStatus = result["opportunityid"]["niq_approvalstatus"];
                            var opportunityStatus = result["opportunityid"]["statecode"];
                            //100000002 - approved
                            if (opportunityApprovalStatus != 100000002) {
                                formContext.getControl("niq_wbs").setDisabled(false);
                            }
                            else {
                                formContext.getControl("niq_wbs").setDisabled(true);
                            }
                            if (opportunityStatus === 1) {
                                CommonForm.Events.disableFormFields(true, formContext);
                            }
                        }
                    },
                    function (error) { }
                );
            }
        }
    },
    checkOpportunityInfo: function (executionContext, quoteId) {
        "use strict";
        try {
            var formContext = executionContext.getFormContext();
            var fetch = "<fetch top='1' distinct='true' no-lock='true'>" +
                "<entity name='opportunity'>" +
                "<attribute name='opportunityid' />" +
                "<attribute name='niq_approvalstatus' />" +
                "<attribute name='niq_opportunitytype' />" +
                "<link-entity name='quote' to='opportunityid' from='opportunityid' link-type='inner' alias='aa'>" +
                "<filter type='and'><condition attribute='quoteid' operator='eq' value='" + quoteId + "' /></filter>" +
                "</link-entity>" +
                "</entity>" +
                "</fetch>";
            var fetchResults = GetCRMWebAPI.Methods.GetFetchRecords(Xrm.Utility.getGlobalContext().getClientUrl(), fetch, "opportunities");
            if (fetchResults !== null && fetchResults.value.length > 0) {
                QuoteProductForm.Events.intialOppCheckflag = true;
                if (fetchResults.value[0]['niq_opportunitytype'] !== undefined && fetchResults.value[0]['niq_opportunitytype'] !== null)
                    QuoteProductForm.Events.opportunityType = fetchResults.value[0]['niq_opportunitytype'];
                if (fetchResults.value[0]['niq_approvalstatus'] !== undefined && fetchResults.value[0]['niq_approvalstatus'] !== null)
                    QuoteProductForm.Events.opportunityApprovalStatus = fetchResults.value[0]['niq_approvalstatus'];
            }
        }
        catch (e) {
            Xrm.Navigation.openErrorDialog({
                message: "Error occurd in QuoteForm.Events.checkQPCLocking method.",
                details: e
            });
        }
    },
    ShowHideForAdmins: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer")) {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_iscreatedrun")) {
                formContext.getControl("niq_iscreatedrun").setVisible(true);
            }
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_ismodified")) {
                formContext.getControl("niq_ismodified").setVisible(true);

            }
        }
    },

    OnSelectQuoteProduct: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var listofColumns = [];
        try {
            QuoteProductForm.Events.OpenTheRecordSidePane(executionContext);
            listofColumns = ["niq_istimebased", "niq_type", "quotedetailname", "isproductoverridden", "producttypecode", "niq_lineitemstartdate", "niq_lineitemenddate", "niq_lagrevenuerecognition", "niq_dealguidance",
                "niq_deliveryfrequency", "niq_remark", "niq_billingfrequency", "niq_fundamount", "extendedamount", "niq_subbrandid", "niq_brandid", "productname", "productdescription",
                "productid", "manualdiscountamount", "baseamount", "niq_reconciliationamount", "niq_discountqp", "niq_lineitemnumberforsap", "niq_updatefrequency", "niq_termlength", "niq_isbillingmodified", "niq_isrevenuemodified", "niq_billingstartdate", "niq_billingenddate", "niq_billingschedulestatus", "niq_revenueschedulestatus", "niq_calculatedtermlength"];

            for (var i = 0; i < listofColumns.length; i++) {
                if (listofColumns[i] !== undefined && listofColumns[i] !== null && formContext.getAttribute(listofColumns[i]) !== null)
                    this.SetDisableGridColumn(formContext.getAttribute(listofColumns[i]), true);
            }
        }
        catch (ex) {
            Xrm.Navigation.openErrorDialog({ message: "Error occurd in QuoteProductForm.Events.OnSelectQuoteProduct method.", details: ex });
        }
    },
    LockBasesStudyNumber: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator")) {
            formContext.getControl("niq_basesstudynumber").setDisabled(false);
            this.SetDisableGridColumn(formContext.getAttribute("niq_basesstudynumber"), false);
        }
        else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User")) {
            {
                formContext.getControl("niq_basesstudynumber").setDisabled(true);
            }
        }
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User") && this.opportunityType === 1) {
            this.SetDisableGridColumn(formContext.getAttribute("niq_basesstudynumber"), true);
            formContext.getControl("niq_basesstudynumber").setDisabled(true);
        }
        else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User") && this.opportunityType === 2) {
            this.SetDisableGridColumn(formContext.getAttribute("niq_basesstudynumber"), false);
            formContext.getControl("niq_basesstudynumber").setDisabled(false);
        }
    },
    LockEndDate: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var type = formContext.getAttribute("niq_type").getValue();
        var istimeBased = formContext.getAttribute("niq_istimebased").getValue();
        var rateCardUpdateFrequency = formContext.getAttribute("niq_ratecardupdatefrequency")?.getValue();
        var updateFrequencyValue = formContext.getAttribute("niq_updatefrequency")?.getValue();
        formContext.getControl("niq_lineitemenddate").setDisabled(false);
        if ((type === 2 && rateCardUpdateFrequency === null) || (type === 2 && rateCardUpdateFrequency !== null && rateCardUpdateFrequency !== "Adhoc") || (type === 1 && istimeBased === false && rateCardUpdateFrequency !== null && rateCardUpdateFrequency !== "Adhoc")) {
            formContext.getControl("niq_lineitemenddate").setDisabled(true);
        }
    },
    // IC/POC Enhancements ------------
    // DYNCRM-20015 - Display Available Frequency Values for Sales Users on quote product form
    // DYNCRM-20070 - Lock Revenue Frequency Field on quote product form for Periodic Service Based Products with On-Platform Delivery (Yes)
    // DYNCRM-20071 - Lock Revenue Frequency Field on quote product form for Periodic Service Based Products with On-Platform Delivery (No)
    // DYNCRM-20066 - Lock lag revenue recognition for "On Platform delivery" checked (yes)
    // DYNCRM-20016 - Enable End Date if Ad-hoc Product
    // DYNCRM-20067- The Sales user to update the field - Lag Revenue Recognition  quote product form with valid options ( same as 20015)
    // 1. for Adhoc product lock lag revenue 2. for Periodic product lock lag reveneue only if onplatfrom delivery is true ( similar to 20066 )
    // DYNCRM-20044 - The Sales user should be able to update the field Update frequency
    // DYNCRM-20045 - for Periodic Service-based on update of "Update Frequency" - corresponding revenue frequency to update accordingly
    // DYNCRM-20071 - Lock Revenue Frequency Field on quote product form for Adhoc Service Based Products & set its freq be equal to "Update freq"

    FilteredFrequenciesForSalesUser: async function (executionContext) {
        let FilterOnlyforSalesUser = true
        var removeValues = [];
        var FreqFieldsToModify = ["niq_updatefrequency", "niq_billingfrequency", "niq_lagrevenuerecognition", "niq_deliveryfrequency"];
        var onPlatformDelivery = "No"
        var context = Xrm.Utility.getGlobalContext();
        var formContext = executionContext.getFormContext();
        var productName = formContext.getAttribute("quotedetailname")?.getValue();
        var productType = null;
        var type = null;
        var termLength = null;
        var istimeBased = null;

        let startDate = formContext.getAttribute("niq_lineitemstartdate")?.getValue();
        let endDate = formContext.getAttribute("niq_lineitemenddate")?.getValue();
        let rateCardUpdateFrequency = formContext.getAttribute("niq_ratecardupdatefrequency")?.getValue();

        // var isAdhocproductshouldbehaveasperiodic = null;
        if (QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_type")) && QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_type").getValue())) {
            type = formContext.getAttribute("niq_type").getValue();
        }
        if (QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_istimebased")) && QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_istimebased").getValue())) {
            istimeBased = formContext.getAttribute("niq_istimebased").getValue();
        }

        // Get the TermLength for the Current record
        //if (QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_termlength")) && QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_termlength").getValue())) {
        if (QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_calculatedtermlength")) && QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_calculatedtermlength").getValue())) {
            //termLength = formContext.getAttribute("niq_termlength").getValue();
            //DYNCRM- 21595
            termLength = formContext.getAttribute("niq_calculatedtermlength").getValue();
        }
        // if (QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_adhocproductshouldbehaveasperiodic")) && QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_adhocproductshouldbehaveasperiodic").getValue())) {
        //     isAdhocproductshouldbehaveasperiodic = formContext.getAttribute("niq_adhocproductshouldbehaveasperiodic").getValue();
        // }

        if (QuoteProductForm.Events.IsValid(productName) && (productName === "Place Holder Product" || productName === "SAP Deferred Revenue reconciliation placeholder")) {
            switch (productName) {
                case "Place Holder Product":
                    var productType = "PlaceholderProducts";

                    var onPlatformDelivery = "No";
                    break;

                case "SAP Deferred Revenue reconciliation placeholder":
                    var productType = "SAPDeferredLine";

                    var onPlatformDelivery = "No";
                    break;
            }
        }
        else {
            if (type != null && type === 1) {

                if (istimeBased != null && istimeBased) {
                    productType = "AdhocTimeBased";
                } else {
                    productType = "AdhocServiceBased";
                }
            } else {
                if (istimeBased != null && istimeBased) {
                    productType = "PeriodicTimeBased";
                } else {
                    productType = "PeriodicServiceBased";
                }
            }
            if (QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_onplatformdelivery")) && QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_onplatformdelivery").getValue())) {
                onPlatformDelivery = formContext.getAttribute("niq_onplatformdelivery").getValue();
            }

        }
        // Admin users should see all freq values ( un-filtered)
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer")) { FilterOnlyforSalesUser = false; }
        //testing
        FilterOnlyforSalesUser = true;
        if (FilterOnlyforSalesUser) {
            // Fetch Available Frequency values as JSON from Dataverse..
            var constValues;
            var result = await Xrm.WebApi.retrieveRecord("niq_configurationsetting", "adfca5dc-bc28-ef11-840a-000d3a2f0c5a", "?$select=niq_json,niq_cc")

            constValues = JSON.parse(result.niq_cc);
            var availableFreqJson = JSON.parse(result.niq_json);
            // For all the 4 different Frequencies

            for (var i = 0; i < FreqFieldsToModify.length; i++) {
                switch (FreqFieldsToModify[i]) {
                    case "niq_deliveryfrequency":
                        var values = availableFreqJson.RevenueFrequency.OnPlatformDelivery[onPlatformDelivery][productType];
                        break;
                    case "niq_lagrevenuerecognition":
                        var values = availableFreqJson.LagRevenueRecognition.OnPlatformDelivery[onPlatformDelivery][productType];
                        break;
                    case "niq_updatefrequency":
                        var values = availableFreqJson.UpdateFrequency[productType];
                        break;
                    case "niq_billingfrequency":
                        var values = availableFreqJson.BillingFrequency[productType];
                        break;
                }

                // Filter out "No" keys from "values" and get their corresponding entry from "constValues"
                removeValues = Object.keys(values).filter(function (key) {
                    return values[key] === "No";
                }).map(function (key) {
                    return constValues[key];
                });
                //console.log("removeValues :"+removeValues)
                // Removal of choice values from Control
                for (var j = 0; j < removeValues.length; j++) {
                    if (QuoteProductForm.Events.IsValid(removeValues[j]) && QuoteProductForm.Events.IsValid(removeValues[j].value)) {
                        formContext.getControl(FreqFieldsToModify[i]).removeOption(removeValues[j].value);
                    }
                }
            }

            // addtional filetrin for Adhoc service based
            let shouldBehaveAsAdhoc = false;
            if (QuoteProductForm.Events.IsValid(startDate) && QuoteProductForm.Events.IsValid(endDate) &&
                QuoteProductForm.Events.IsFirstDayOfMonth(startDate) &&
                QuoteProductForm.Events.IsLastDayOfMonth(endDate)
                && termLength !== 0 && type == 1 && !istimeBased &&
                rateCardUpdateFrequency == null) {
                //formContext.getControl("niq_lineitemenddate").setDisabled(true);
                //formContext.getControl("niq_lineitemstartdate").setDisabled(true);
                QuoteProductForm.Events.filterUpdateFrequencyOptionSet(executionContext, shouldBehaveAsAdhoc);
                QuoteProductForm.Events.filterBillingFrequencyOptionSet(executionContext, shouldBehaveAsAdhoc);
            }
            if (QuoteProductForm.Events.IsValid(startDate) && QuoteProductForm.Events.IsValid(endDate) &&
                (termLength === null || termLength === 0) && type == 1 && !istimeBased &&
                rateCardUpdateFrequency == null) {
                let startIsFirstDay = QuoteProductForm.Events.IsFirstDayOfMonth(startDate);
                let endIsLastDay = QuoteProductForm.Events.IsLastDayOfMonth(endDate);
                if ((startIsFirstDay && !endIsLastDay) || (!startIsFirstDay && endIsLastDay) || (!startIsFirstDay && !endIsLastDay)) {
                    shouldBehaveAsAdhoc = true;
                    QuoteProductForm.Events.filterUpdateFrequencyOptionSet(executionContext, shouldBehaveAsAdhoc);
                    QuoteProductForm.Events.filterBillingFrequencyOptionSet(executionContext, shouldBehaveAsAdhoc);
                }
            }
            if (QuoteProductForm.Events.IsValid(startDate) && QuoteProductForm.Events.IsValid(endDate) &&
                (termLength === null || termLength === 0) && type == 1 && istimeBased) {
                shouldBehaveAsAdhoc = true;
                QuoteProductForm.Events.filterBillingFrequencyOptionSet(executionContext, shouldBehaveAsAdhoc);
            }

            // filter the frequencies based on termlength

            // console.log("termLength :" + termLength)
            if (termLength > 0) {
                for (var i = 0; i < (FreqFieldsToModify.length) - 1; i++) // no filtering for "niq_lagrevenuerecognition"
                {
                    var freqOptions = formContext.getControl(FreqFieldsToModify[i]).getOptions()
                    for (var j = 0; j < freqOptions.length; j++) {
                        switch (freqOptions[j].text) {

                            case "BI-Monthly":
                            case "Bimonthly":
                            case "Bimonthly with Lag":
                            case "Bi-Monthly with Lag":
                                if (termLength % 2 == 0) { break; }
                                else { formContext.getControl(FreqFieldsToModify[i]).removeOption(freqOptions[j].value); break; }
                            case "Quarterly":
                            case "Quarterly with Lag":
                                if (termLength % 3 == 0) { break; }
                                else { formContext.getControl(FreqFieldsToModify[i]).removeOption(freqOptions[j].value); break; }
                            case "3 * Annually":
                            case "3 X Annually":
                            case "3x Annually":
                                if (termLength % 4 == 0) { break; }
                                else { formContext.getControl(FreqFieldsToModify[i]).removeOption(freqOptions[j].value); break; }
                            case "Half-Yearly":
                            case "2x / year":
                            case "2x / Year":
                                if (termLength % 6 == 0) { break; }
                                else { formContext.getControl(FreqFieldsToModify[i]).removeOption(freqOptions[j].value); break; }
                            case "Annually":
                            case "Annual":
                                if (termLength % 12 == 0) { break; }
                                else { formContext.getControl(FreqFieldsToModify[i]).removeOption(freqOptions[j].value); break; }
                        }

                    }

                }
            }
            QuoteProductForm.Events.AppendUserSelectedOption(executionContext);

        }
        // Diaable UpdateFreq dropdown if RateCardUpdateFreq has any value
        if (QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_ratecardupdatefrequency")) && QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_ratecardupdatefrequency").getValue())) {
            formContext.getControl("niq_updatefrequency").setDisabled(true);
        }

        // Disable "Lag revenue recognition field" if "On Platfrom Delivery" is "yes"
        if (onPlatformDelivery == "Yes" && (productType == "PeriodicServiceBased" || productType == "PeriodicTimeBased")) {
            formContext.getControl("niq_lagrevenuerecognition").setDisabled(true);
        }

        if (onPlatformDelivery === "No") {


            var revenueFrequencyValue = formContext.getAttribute("niq_deliveryfrequency")?.getValue();
            var alllagoptions = availableFreqJson.LagRevenueRecognition.OnPlatformDelivery["No"][productType];
            var contvalues = constValues;

            var allowedKeys = [];
            var allowedKeysWhenCustomOrMonthlyTimeBased = ["NoLag"];
            var allowedKeysOtherwise = ["NoLag", "1MonthLag", "2MonthsLag"];

            if (
                (contvalues["Custom"] && revenueFrequencyValue === contvalues["Custom"].value) ||
                (contvalues["MonthlyTimeBased"] && revenueFrequencyValue === contvalues["MonthlyTimeBased"].value)
            ) {
                allowedKeys = allowedKeysWhenCustomOrMonthlyTimeBased;
            } else {
                allowedKeys = allowedKeysOtherwise;
            }

            var control = formContext.getControl("niq_lagrevenuerecognition");

            // Clear all existing options before adding new ones
            control.clearOptions();

            // Add only allowed options
            allowedKeys.forEach(function (key) {
                var optionConfig = contvalues[key];
                console.log("Adding option:", optionConfig.text, optionConfig.value);
                if (optionConfig) {
                    control.addOption({
                        text: optionConfig.Label,
                        value: optionConfig.value
                    });
                }
            });

            // Reset value if the current one is not allowed
            var currentValue = formContext.getAttribute("niq_lagrevenuerecognition")?.getValue();
            var allowedValues = allowedKeys.map(function (key) {
                return contvalues[key]?.value;
            });
            //reset the default value
            if ((allowedValues.indexOf(currentValue) === -1) && (startDate !== null) && (endDate !== null)) {
                formContext.getAttribute("niq_lagrevenuerecognition").setValue(contvalues["NoLag"]?.value);
            }
        }


        /// Disable "Revenue Freq field" if product is "PeriodicServiceBased"
        if (productType == "PeriodicServiceBased") {
            //formContext.getControl("niq_deliveryfrequency").setDisabled(true);
        }

        /// Disable "Revenue Freq field" if product is "AdhocServiceBased"
        if (productType == "AdhocServiceBased") {
            //formContext.getControl("niq_deliveryfrequency").setDisabled(true);
        }

        // For Ad-hoc products Enable END date
        // For Ad-hoc products Disable "Lag revenue"
        if (productType == "AdhocTimeBased" || productType == "AdhocServiceBased") {
            //formContext.getControl("niq_lineitemenddate").setDisabled(false);
            if (formContext.getAttribute("niq_lagrevenuerecognition") && formContext.getAttribute("niq_lagrevenuerecognition").getValue() != null) {
                //formContext.getControl("niq_lagrevenuerecognition").setDisabled(true);
            }


            // DYNCRM-20464  - Adhoc Service based product with term length not 0 and Update Frequency value is other than "Adhoc / Custom"
            if (termLength > 0 && formContext.getAttribute("niq_updatefrequency").getValue() !== 100000009) {
                //formContext.getControl("niq_lineitemenddate").setDisabled(false);
            }
        }
        // Lock Billing frequency if products are "Place Holder Product" and "SAP Deferred Revenue reconciliation placeholder"
        if (QuoteProductForm.Events.IsValid(productName) && (productName === "Place Holder Product" || productName === "SAP Deferred Revenue reconciliation placeholder")) {
            formContext.getControl("niq_billingfrequency").setDisabled(true);
        }
        //if (QuoteProductForm.Events.IsValid(startDate) && QuoteProductForm.Events.IsValid(endDate) &&
        //    QuoteProductForm.Events.IsFirstDayOfMonth(startDate) &&
        //    QuoteProductForm.Events.IsLastDayOfMonth(endDate)
        //    && termLength !== 0 && type == 1 && !istimeBased &&
        //    rateCardUpdateFrequency == null) {
        //    formContext.getControl("niq_lineitemenddate").setDisabled(true);
        //    formContext.getControl("niq_lineitemstartdate").setDisabled(true);
        //}
        this.IsFormReadOnly(executionContext);
    },
    FrequencyCompatibilityCheck: async function (executionContext) {
        await this.FilteredFrequenciesForSalesUser(executionContext);
        var formContext = executionContext.getFormContext();
        var updatefrequency = formContext.getAttribute("niq_updatefrequency").getValue();
        var billingfrequency = formContext.getAttribute("niq_billingfrequency").getValue();
        var error = false;
        var validBillingFreq = formContext.getControl("niq_billingfrequency").getOptions();
        var validUpdateFreq = formContext.getControl("niq_updatefrequency").getOptions();

        let startDate = formContext.getAttribute("niq_lineitemstartdate")?.getValue();
        let endDate = formContext.getAttribute("niq_lineitemenddate")?.getValue();

        if (startDate != null && endDate != null) {
            if (validUpdateFreq.filter((freq) => freq.value == updatefrequency).length == 0) {

                formContext.getAttribute("niq_updatefrequency").setValue(null);
                error = true;
            }
            if (validBillingFreq.filter((freq) => freq.value == billingfrequency).length == 0) {
                formContext.getAttribute("niq_billingfrequency").setValue(null);
                error = true;
            }
            if (error) {
                Xrm.Navigation.openErrorDialog({ message: "Saving is not possible due to start and end date being not compatible with Update or Billing frequency. Correct the values and try again." });
            }
        }
    },
    IsValid: function (attr) {
        "use strict";
        let isValidAttribute = false;
        if (attr !== null && attr !== "null" && attr !== "undefind" && attr !== undefined) {
            isValidAttribute = true;
        }
        return isValidAttribute;
    },
    // Disable "Revenue Freq field" if product is "PeriodicServiceBased" & set its value to be same as "Update Freq"
    // Disable "Revenue Freq field" if product is "Ad-hocServiceBased" & set its value to be same as "Update Freq"
    AssignRevenueFeq4PeriodicAndAdhocServiceBased: async function (executionContext) {
        var onPlatformDelivery = null;
        var productType = null;
        var type = null;

        var formContext = executionContext.getFormContext();
        if (QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_onplatformdelivery")) && QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_onplatformdelivery").getValue())) {
            onPlatformDelivery = formContext.getAttribute("niq_onplatformdelivery").getValue();
        }

        if (QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_type")) && QuoteProductForm.Events.IsValid(formContext.getAttribute("niq_type").getValue())) {
            type = formContext.getAttribute("niq_type").getValue();
        }

        var istimeBased = formContext.getAttribute("niq_istimebased")?.getValue();
        if (type === 1) {
            if (istimeBased) {
                productType = "AdhocTimeBased";
            } else {
                productType = "AdhocServiceBased";
            }
        } else {
            if (istimeBased) {
                productType = "PeriodicTimeBased";
            } else {
                productType = "PeriodicServiceBased";
            }
        }
        QuoteProductForm.Events.AppendUserSelectedOption(executionContext);

        var updateFreq = formContext.getAttribute("niq_updatefrequency")?.getValue();
        var productName = formContext.getAttribute("quotedetailname")?.getValue();

        if ((productType == "PeriodicServiceBased" || productType == "AdhocServiceBased") && (productName !== "Place Holder Product" && productName !== "SAP Deferred Revenue reconciliation placeholder")) {

            if (onPlatformDelivery != null && onPlatformDelivery == "No") {
                if (productType == "PeriodicServiceBased") {
                    switch (updateFreq) {
                        case 100000010://weekly
                        case 100000011://biweekly
                            formContext.getAttribute("niq_deliveryfrequency").setValue(100000000); break;//montly
                        case 100000001:
                        case 100000002:
                            formContext.getAttribute("niq_deliveryfrequency").setValue(updateFreq); break;
                        default:
                            formContext.getAttribute("niq_deliveryfrequency").setValue(updateFreq);
                        //formContext.getControl("niq_deliveryfrequency").setDisabled(true);

                    }
                }
                else // productType == "AdhocServiceBased"
                {
                    if (updateFreq != null && (updateFreq == 100000010 || updateFreq == 100000011))
                        formContext.getAttribute("niq_deliveryfrequency").setValue(100000000);
                    else
                        formContext.getAttribute("niq_deliveryfrequency").setValue(updateFreq);

                    //formContext.getControl("niq_deliveryfrequency").setDisabled(true);
                }
            }
            else { //  onPlatformDelivery == "Yes")
                formContext.getAttribute("niq_deliveryfrequency").setValue(100000000);
                //formContext.getControl("niq_deliveryfrequency").setDisabled(true);
            }
        }
        if (productType == "PeriodicServiceBased" && onPlatformDelivery == "Yes") {
            formContext.getAttribute("niq_deliveryfrequency").setValue(100000000);
        }

    },

    AppendUserSelectedOption: async function (executionContext) {
        console.log("hello");
        var formContext = executionContext.getFormContext();
        //remove unwanted options
        var existingOptions = formContext.getControl("niq_deliveryfrequency").getOptions();
        for (var j = 0; j < existingOptions.length; j++) {
            if (existingOptions[j].text != "Monthly") {
                formContext.getControl("niq_deliveryfrequency").removeOption(existingOptions[j].value);
            }
        }

        var updateFrequencyValue = formContext.getAttribute("niq_updatefrequency").getValue();
        var updateFrequencyText = formContext.getAttribute("niq_updatefrequency").getText();
        let rateCardUpdateFrequency = formContext.getAttribute("niq_ratecardupdatefrequency")?.getValue();
        let istimeBased = formContext.getAttribute("niq_istimebased").getValue();
        let type = formContext.getAttribute("niq_type")?.getValue();
        let formType = formContext.ui.getFormType();
        var startdate = formContext.getAttribute("niq_lineitemstartdate")?.getValue();
        var enddate = formContext.getAttribute("niq_lineitemenddate")?.getValue();

        //special case - Adhoc service based
        if (type == 1 && !istimeBased && !QuoteProductForm.Events.IsValid(rateCardUpdateFrequency) && !QuoteProductForm.Events.IsValid(startdate) && !QuoteProductForm.Events.IsValid(enddate)) {
            //add - custom option
            formContext.getControl("niq_deliveryfrequency").addOption({ value: 100000009, text: "Custom" });

        }


        //special case - Adhoc service based, rateCardUpdateFrequency == null
        var updateFrequency = formContext.getControl("niq_updatefrequency").getOptions();
        if (type == 1 && !istimeBased && !QuoteProductForm.Events.IsValid(rateCardUpdateFrequency) && updateFrequency.length == 2 && updateFrequency.filter(item => item.text === "Custom").length == 1) {
            //remove- monthly 
            formContext.getControl("niq_deliveryfrequency").removeOption(100000000);
        }


        //Experlogix rate card
        //special case - periodic service based, Experlogix rate card = adhoc
        if (type == 2 && !istimeBased && QuoteProductForm.Events.IsValid(rateCardUpdateFrequency) && rateCardUpdateFrequency == "Adhoc") {
            //add - custom option
            formContext.getControl("niq_updatefrequency").addOption({ value: 100000009, text: "Custom" });

        }

        //special case - adhoc service based, Experlogix rate card = adhoc
        if (type == 1 && !istimeBased && QuoteProductForm.Events.IsValid(rateCardUpdateFrequency) && rateCardUpdateFrequency == "Adhoc") {
            //remove- monthly 
            formContext.getControl("niq_deliveryfrequency").removeOption(100000000);
        }

        //new options
        existingOptions = formContext.getControl("niq_deliveryfrequency").getOptions();
        //just append, whatever added in updatefrequency
        if (QuoteProductForm.Events.IsValid(updateFrequencyValue) && QuoteProductForm.Events.IsValid(updateFrequencyText) && existingOptions.filter(item => item.text === updateFrequencyText).length == 0) {
            if (updateFrequencyValue != 100000010 && updateFrequencyValue != 100000011) {  //weekly or biweekly
                formContext.getControl("niq_deliveryfrequency").addOption({ value: updateFrequencyValue, text: updateFrequencyText });
            }
        }

        //Experlogix rate card
        //special case - periodic service based, Experlogix rate card = adhoc
        if (type == 2 && !istimeBased && QuoteProductForm.Events.IsValid(rateCardUpdateFrequency) && rateCardUpdateFrequency == "Adhoc") {
            //remove- custom 
            formContext.getControl("niq_deliveryfrequency").removeOption(100000009);
        }

        // Special case for RevShare Line
        var childOpportunityID = formContext.getAttribute("niq_correspondingchildopportunity")?.getValue();
        if (childOpportunityID !== null && childOpportunityID !== "") {
            let startIsFirstDay = QuoteProductForm.Events.IsFirstDayOfMonth(startdate);
            let endIsLastDay = QuoteProductForm.Events.IsLastDayOfMonth(enddate);
            if ((startIsFirstDay && !endIsLastDay) || (!startIsFirstDay && endIsLastDay) || (!startIsFirstDay && !endIsLastDay)) {

                formContext.getControl("niq_deliveryfrequency").addOption({ value: 100000008, text: "Monthly (Time Based)" });
                //formContext.getControl("niq_updatefrequency").addOption({ value: 100000009, text: "Custom" });
                formContext.getControl("niq_billingfrequency").addOption({ value: 100000009, text: "Ad-Hoc" });
            }
        }

    },

    //Funtion to call Side Pane
    OpenTheRecordSidePane: async function (executionContext) {
        const paneId = "QuoteProductSidePane";
        const formContext = executionContext.getFormContext();
        const entityName = formContext.data.entity.getEntityName();
        const recordId = formContext.data.entity.getId();
        if (recordId == null) {
            return;
        }
        const pane = Xrm.App.sidePanes.getPane(paneId) ?? await Xrm.App.sidePanes.createPane({
            paneId: paneId,
            canClose: true
        });
        pane.width = 600;  //you can decide what's the width of the side pane.
        //you could change the width for each record, in case you want to
        pane.navigate({
            pageType: "entityrecord",
            entityName: entityName,
            entityId: recordId,
            formId: "6ca9a69c-913b-ef11-8409-000d3aaa24ff"
        });

    },

    // Function to check if a value exists in the JSON structure
    CheckValueExists: function (json, value) {
        for (let key in json) {
            if (json[key].value === value) {
                return true;
            }
        }
        return false;
    },
    // Show & Hide Revenue/Billing Section and set remaining amount fields in quote product main form
    showBillingAndRevenueSection: async function (executionContext) {
        var allScheduleAmount = 0;
        var lastRemainingAmount = 0;
        var query = "";
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        var currentQuoteProductId = formContext.data.entity.getId();
        var totalAmount = formContext.getAttribute("extendedamount")?.getValue();
        var billingScheduleSubgrid = formContext.getControl("Subgrid_Billing_Schedule");
        var revenueScheduleSubgrid = formContext.getControl("Subgrid_Revenue_Schedule");
        var quoteId = formContext.getAttribute("quoteid")?.getValue();

        var billingScheduleSection = formContext.ui.tabs.get("general").sections.get("billing_schedule_section_8");
        var revenueScheduleSection = formContext.ui.tabs.get("general").sections.get("revenue_schedule_section_9");

        var currentQuoteProductId = formContext.data.entity.getId();
        var resultCurrency = await Xrm.WebApi.retrieveRecord("quotedetail", currentQuoteProductId.replace("{", "").replace("}", ""), "?$select=_transactioncurrencyid_value");
        var currencyId = resultCurrency["_transactioncurrencyid_value"];

        QuoteProductForm.Events.refreshForm(executionContext);
        if (currentQuoteProductId != "" || currentQuoteProductId != null) {
            //Below onLoad is for Billing Schedule Subgrid
            billingScheduleSubgrid.addOnLoad(async function () {
                var billingSubgrid = billingScheduleSubgrid.getGrid().getTotalRecordCount();
                //Get Quote product start date
                var startDate = formContext.getAttribute("niq_lineitemstartdate").getValue();
                lastRemainingAmount = 0;
                query = "?$select=niq_scheduleid,niq_amount,niq_scheduletype&$filter=(_niq_lineitemid_value eq '" + currentQuoteProductId.replace("{", "").replace("}", "") + "' and niq_scheduletype eq 100000000)";
                allScheduleAmount = await QuoteProductForm.Events.retrieveScheduleAmount(query);
                lastRemainingAmount = totalAmount - allScheduleAmount;
                var record = {};
                record.niq_remainingbillingamount = Number(parseFloat(lastRemainingAmount).toFixed(4)); // Currency
                if (formType == 2) {
                    var billingfrequency = formContext.getAttribute("niq_billingfrequency")?.getValue() ?? null;

                    if (billingfrequency === 100000009) {
                        record.niq_billingschedulestatus = record.niq_remainingrevenueamount === 0
                            ? QuoteProductForm.Events.revenueScheduleStatus.CompleteManualInput
                            : QuoteProductForm.Events.revenueScheduleStatus.IncompleteManualInput;
                    } else {
                        record.niq_billingschedulestatus = record.niq_remainingrevenueamount === 0
                            ? 610570003 // Complete Schedules (Auto)
                            : 610570002; // Incomplete Schedules (Auto)
                    }
                    //record.niq_billingschedulestatus = record.niq_remainingbillingamount === 0 ? QuoteProductForm.Events.billingScheduleStatus.CompleteManualInput : QuoteProductForm.Events.billingScheduleStatus.IncompleteManualInput;
                    await Xrm.WebApi.updateRecord("quotedetail", currentQuoteProductId.replace("{", "").replace("}", ""), record);
                    let remainingBillingAmount = formContext.getAttribute("niq_remainingbillingamount");
                    if (remainingBillingAmount) {
                        remainingBillingAmount.setValue(record.niq_remainingbillingamount);
                        remainingBillingAmount.setSubmitMode("never"); // Manually trigger the OnChange event if necessary
                    }
                }
                var scheduleType = 100000000; // Schedule Type = billing
                var resultBillingCustomSchedule = await Xrm.WebApi.retrieveMultipleRecords("niq_schedule", "?$select=niq_iscustomschedule&$filter=(_niq_lineitemid_value eq " + currentQuoteProductId.replace("{", "").replace("}", "") + " and niq_iscustomschedule eq true and niq_scheduletype eq 100000000 and statuscode eq 1)&$top=1");
                if (resultBillingCustomSchedule.entities.length == 0 && startDate) {
                    //await QuoteProductForm.Events.autoCreateScheduleSchedule(currentQuoteProductId.replace("{", "").replace("}", ""), scheduleType, startDate, currencyId, billingScheduleSubgrid);
                }
            });
            //Below onLoad is for Revenue Schedule Subgrid
            revenueScheduleSubgrid.addOnLoad(async function () {
                var revenueSubgrid = revenueScheduleSubgrid.getGrid().getTotalRecordCount();
                //Get Quote product start date
                var startDate = formContext.getAttribute("niq_lineitemstartdate").getValue();
                lastRemainingAmount = 0;
                query = "?$select=niq_scheduleid,niq_amount,niq_scheduletype&$filter=(_niq_lineitemid_value eq '" + currentQuoteProductId.replace("{", "").replace("}", "") + "' and (niq_scheduletype eq 100000001 or niq_scheduletype eq 100000002))";
                allScheduleAmount = await QuoteProductForm.Events.retrieveScheduleAmount(query);
                lastRemainingAmount = totalAmount - allScheduleAmount;
                var record = {};
                record.niq_remainingrevenueamount = Number(parseFloat(lastRemainingAmount).toFixed(4)); // Currency
                if (formType == 2) {
                    var deliveryFrequencyValue = formContext.getAttribute("niq_deliveryfrequency")?.getValue() ?? null;

                    if (deliveryFrequencyValue === 100000009) {
                        record.niq_revenueschedulestatus = record.niq_remainingrevenueamount === 0
                            ? QuoteProductForm.Events.revenueScheduleStatus.CompleteManualInput
                            : QuoteProductForm.Events.revenueScheduleStatus.IncompleteManualInput;
                    } else {
                        record.niq_revenueschedulestatus = record.niq_remainingrevenueamount === 0
                            ? 610570003 // Complete Schedules (Auto)
                            : 610570002; // Incomplete Schedules (Auto)
                    }
                    // record.niq_revenueschedulestatus = record.niq_remainingrevenueamount === 0 ? QuoteProductForm.Events.revenueScheduleStatus.CompleteManualInput : QuoteProductForm.Events.revenueScheduleStatus.IncompleteManualInput;
                    await Xrm.WebApi.updateRecord("quotedetail", currentQuoteProductId.replace("{", "").replace("}", ""), record);
                    let remainingRevenueAmount = formContext.getAttribute("niq_remainingrevenueamount");
                    if (remainingRevenueAmount) {
                        remainingRevenueAmount.setValue(record.niq_remainingrevenueamount);
                        remainingRevenueAmount.setSubmitMode("never"); // Manually trigger the OnChange event if necessary
                    }
                }
                var oppExistingContractAction = await QuoteProductForm.Events.retriveExistingContractAction(currentQuoteProductId.replace("{", "").replace("}", ""));
                if ((oppExistingContractAction === 2 || oppExistingContractAction === 4) && oppExistingContractAction !== null) {
                    var scheduleType = 100000002; // Schedule Type = revenue forecast
                    var resultRevenueCustomSchedule = await Xrm.WebApi.retrieveMultipleRecords("niq_schedule", "?$select=niq_iscustomschedule&$filter=(_niq_lineitemid_value eq " + currentQuoteProductId.replace("{", "").replace("}", "") + " and niq_iscustomschedule eq true and niq_scheduletype eq 100000002 and statuscode eq 1)&$top=1");
                    if (resultRevenueCustomSchedule.entities.length == 0 && startDate) {
                        //await QuoteProductForm.Events.autoCreateScheduleSchedule(currentQuoteProductId.replace("{", "").replace("}", ""), scheduleType, startDate, currencyId, revenueScheduleSubgrid);
                    }
                } else {
                    var scheduleType = 100000001; // Schedule Type = revenue
                    var resultRevenueCustomSchedule = await Xrm.WebApi.retrieveMultipleRecords("niq_schedule", "?$select=niq_iscustomschedule&$filter=(_niq_lineitemid_value eq " + currentQuoteProductId.replace("{", "").replace("}", "") + " and niq_iscustomschedule eq true and niq_scheduletype eq 100000001 and statuscode eq 1)&$top=1");
                    if (resultRevenueCustomSchedule.entities.length == 0 && startDate) {
                        //await QuoteProductForm.Events.autoCreateScheduleSchedule(currentQuoteProductId.replace("{", "").replace("}", ""), scheduleType, startDate, currencyId, revenueScheduleSubgrid);
                    }
                }
            });
        }
    },
    //Retrieve Existing Contract Action field value from the opportunity
    retriveExistingContractAction: async function (quoteProductGuid) {
        // Create FetchXML query
        var fetchXml = `
    <fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
      <entity name="quotedetail">
        <attribute name="quotedetailid" />
        <order attribute="niq_brandid" descending="false" />
        <filter type="and">
          <condition attribute="quotedetailid" operator="eq" value="` + quoteProductGuid + `" />
        </filter>
        <link-entity name="quote" from="quoteid" to="quoteid" link-type="inner" alias="ae">
          <link-entity name="opportunity" from="opportunityid" to="opportunityid" link-type="inner" alias="af">
            <attribute name="niq_existingcontractaction" />
          </link-entity>
        </link-entity>
      </entity>
    </fetch>`;

        // Convert FetchXML to Web API query
        var encodedFetchXml = encodeURIComponent(fetchXml);
        var existingContractAction = null;
        // Execute the query using Xrm.WebApi
        await Xrm.WebApi.retrieveMultipleRecords("quotedetail", "?fetchXml=" + encodedFetchXml).then(
            function success(result) {
                if (result.entities.length > 0) {
                    // Retrieve niq_existingcontractaction from the result
                    existingContractAction = result.entities[0]["af.niq_existingcontractaction"];
                    //console.log("Existing Contract Action:", niqExistingContractAction);
                    // Use the value as needed
                } else {
                    console.log("No records found.");
                }
            },
            function (error) {
                console.log("Error retrieving data:", error.message);
            }
        );
        return existingContractAction;
    },
    retrieveScheduleAmount: async function (query) {
        var totalScheduleAmount = 0;
        var amount;
        await Xrm.WebApi.retrieveMultipleRecords("niq_schedule", query).then(
            function success(results) {
                //console.log(results);
                for (var i = 0; i < results.entities.length; i++) {
                    var result = results.entities[i];
                    amount = result["niq_amount"]; // Currency
                    totalScheduleAmount += amount;
                }
            },
            function (error) {
                console.log(error.message);
            }
        );
        return totalScheduleAmount;
    },
    LockUnlockProjectReferenceID: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        if (!this.intialOppCheckflag) {
            this.checkOpportunityInfo(executionContext, (Xrm.Utility.getPageContext() !== undefined && Xrm.Utility.getPageContext() !== null &&
                Xrm.Utility.getPageContext().input !== undefined && Xrm.Utility.getPageContext().input !== null &&
                Xrm.Utility.getPageContext().input.entityName != undefined && Xrm.Utility.getPageContext().input.entityName != null &&
                Xrm.Utility.getPageContext().input.entityName === 'quote') ?
                Xrm.Utility.getPageContext().input.entityId : formContext.getAttribute('quoteid').getValue()[0].id);
        }
        if (!this.isFinanceorAdminUserCheckflag) {
            this.isFinanceorAdminUserflag = CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User,NIQ Business Admin,System Administrator,System Customizer");
            this.isFinanceorAdminUserCheckflag = true;
        }

        if (this.opportunityType !== null && this.opportunityType === 1) {
            this.SetDisableGridColumn(formContext.getAttribute("niq_projectid"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_databasename"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_contractproductname"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_fundusagetype"), true);
        }
        else {
            this.SetDisableGridColumn(formContext.getAttribute("niq_projectid"), false);
            this.SetDisableGridColumn(formContext.getAttribute("niq_databasename"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_contractproductname"), true);
            this.SetDisableGridColumn(formContext.getAttribute("niq_fundusagetype"), true);
        }
        //opportunity type Completely New Sale [ 1 ], opportunityApprovalStatus == 100000001 [ pending]
        if (this.opportunityType !== null && this.opportunityType === 1)
            if (this.opportunityApprovalStatus !== null && this.opportunityApprovalStatus === 100000001) {
                this.SetDisableGridColumn(formContext.getAttribute("niq_invoicetext"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_databasename"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_contractproductname"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_fundusagetype"), true);


                if (!this.isFinanceorAdminUserflag)
                    this.SetDisableGridColumn(formContext.getAttribute("niq_wbs"), true);
                //this.SetDisableGridColumn(formContext.getAttribute("niq_remark"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_databasename"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_contractproductname"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_fundusagetype"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_basesstudynumber"), true);

            }
            else {
                this.SetDisableGridColumn(formContext.getAttribute("niq_invoicetext"), false);
                this.SetDisableGridColumn(formContext.getAttribute("niq_wbs"), false);
                //this.SetDisableGridColumn(formContext.getAttribute("niq_remark"), false);
                this.SetDisableGridColumn(formContext.getAttribute("niq_databasename"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_contractproductname"), true);
                this.SetDisableGridColumn(formContext.getAttribute("niq_fundusagetype"), true);
            }

    },
    //Hide and show the custom Billing/Revenue schedule sections in quote product form
    refreshForm: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
        if (roles === null) return false;
        var hasRole = false;
        roles.forEach(function (item) {
            //here we can also use item.id to compare role id
            if (item.name == "NIQ Sales User" || item.name == "System Administrator") {
                hasRole = true;
            }
        });
        if (hasRole == true) {
            var billingFrequencyValue = formContext.getAttribute("niq_billingfrequency")?.getValue();
            var revenueFrequencyValue = formContext.getAttribute("niq_deliveryfrequency")?.getValue();
            var priceListItem = formContext.getAttribute("niq_pricelistitem")?.getValue();
            var existingProduct = formContext.getAttribute("productid")?.getValue();
            var quoteLookup = formContext.getAttribute("quoteid").getValue();
            if (priceListItem != null && existingProduct != null && quoteLookup != null) {
                var priceListItemResult = await Xrm.WebApi.retrieveRecord("productpricelevel", priceListItem, "?$select=niq_istimebased,niq_producttype");
                var isTimeServiceBase = priceListItemResult["niq_istimebased"];
                var productType = priceListItemResult["niq_producttype"];
                var proposlStageOrNot = await this.stageName(quoteLookup[0].id.replace("{", "").replace("}", ""));

                if (billingFrequencyValue == 100000009) {
                    //(productTyep eq adhoc and isTimeBase) or (productType eq adhoc and isServiceBase)
                    if (((productType == 100000001 && isTimeServiceBase == false) || (productType == 100000001 && isTimeServiceBase == true)) && proposlStageOrNot) {
                        //If billingFrequency eq Ad-hoc(Custom) show Billing Schedule Section
                        formContext.ui.tabs.get("general").sections.get("billing_schedule_section_8").setVisible(true);
                        //formContext.getControl("Subgrid_Billing_Schedule").refresh();
                    } else {
                        formContext.ui.tabs.get("general").sections.get("billing_schedule_section_8").setVisible(false);
                    }
                } else {
                    formContext.ui.tabs.get("general").sections.get("billing_schedule_section_8").setVisible(false);
                }
                //If revenueFrequency(delivery) eq Ad-hoc(Custom) show Revenue Schedule Section
                if (revenueFrequencyValue == 100000009) {
                    // priceListItemResult = await Xrm.WebApi.retrieveRecord("productpricelevel", priceListItem, "?$select=niq_istimebased,niq_producttype");
                    // productType = priceListItemResult["niq_producttype"];
                    var productResult = await Xrm.WebApi.retrieveRecord("product", existingProduct[0].id.replace("{", "").replace("}", ""), "?$select=niq_onplatformdelivery");
                    var onPlatFormDelivery = productResult["niq_onplatformdelivery"];
                    if (onPlatFormDelivery != null) {
                        //OnPlateformDelivery is No and productType is ad-hoc and product isServiceBase
                        if (onPlatFormDelivery == false && productType == 100000001 && isTimeServiceBase == false) {
                            formContext.ui.tabs.get("general").sections.get("revenue_schedule_section_9").setVisible(true);
                            //formContext.getControl("Subgrid_Revenue_Schedule").refresh();
                            // if (currentQuoteProductId != "") {
                            //     var revenueScheduleGrid = formContext.getControl("Subgrid_Billing_Schedule");
                            //     var scheduleType = 100000001; // Schedule Type = revenue
                            //     var resultRevenueCustomSchedule = await Xrm.WebApi.retrieveMultipleRecords("niq_schedule", "?$select=niq_iscustomschedule&$filter=(_niq_lineitemid_value eq " + currentQuoteProductId.replace("{", "").replace("}", "") + " and niq_iscustomschedule eq true and niq_scheduletype eq 100000001)&$top=1");
                            //     revenueScheduleGrid.addOnLoad(async function () {
                            //         if (resultRevenueCustomSchedule.entities.length == 0 && startDate) {
                            //             this.autoCreateScheduleSchedule(revenueScheduleGrid, currentQuoteProductId.replace("{", "").replace("}", ""), scheduleType, currencyId);
                            //         }
                            //     });
                            // }
                        } else {
                            formContext.ui.tabs.get("general").sections.get("revenue_schedule_section_9").setVisible(false);
                        }
                    } else {
                        var record = {};
                        record.niq_onplatformdelivery = false; // Boolean
                        await Xrm.WebApi.updateRecord("product", existingProduct[0].id.replace("{", "").replace("}", ""), record);
                    }
                } else {
                    formContext.ui.tabs.get("general").sections.get("revenue_schedule_section_9").setVisible(false);
                }
            }
        }
        this.IsFormReadOnly(executionContext);
    },
    SendMessageFromSidePane: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const entityName = formContext.data.entity.getEntityName();
        const recordId = formContext.data.entity.getId();
        Array.from(parent.frames).forEach((frame) => {
            frame.postMessage({
                messageName: "QuoteProduct.SidePaneChanged",
                data: {
                    entityName: entityName,
                    recordId: recordId
                }
            }, "*");
        });
    },
    RegisterSendMessage: function (executionContext) {
        const formContext = executionContext.getFormContext();
        formContext.data.entity.addOnPostSave(QuoteProductForm.Events.SendMessageFromSidePane);

    },
    //update Non-Standard Billing in quote if billing frequency is Custom OR 0/100 and extended amount(Base) less then 20,000USD and term length <= 1 month
    UpdateNonStandardInquote: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var billingFrequency = null;
        let currentQuoteProductId = formContext.data.entity.getId().replace("{", "").replace("}", "");
        let quoteId = formContext.getAttribute("quoteid")?.getValue()[0].id.replace("{", "").replace("}", "");
        let type = formContext.getAttribute("niq_type")?.getValue();
        //let termLength = formContext.getAttribute("niq_termlength")?.getValue();
        //DYNCRM- 21595
        let termLength = formContext.getAttribute("niq_calculatedtermlength")?.getValue();
        let extendedamount_base = formContext.getAttribute("extendedamount_base")?.getValue();
        billingFrequency = formContext.getAttribute("niq_billingfrequency")?.getValue();

        var result = await Xrm.WebApi.retrieveRecord("niq_configurationsetting", "9223fcba-ec3c-ef11-8409-6045bd9afcc1", "?$select=niq_to")
        var thresholdValue = result["niq_to"];
        if (billingFrequency === null && quoteId === null) { return; }
        var resultBases = await Xrm.WebApi.retrieveRecord("quotedetail", currentQuoteProductId, "?$select=_niq_brandid_value");
        var brand = resultBases["_niq_brandid_value@OData.Community.Display.V1.FormattedValue"];

        if (type === 2 && billingFrequency == 100000006 || billingFrequency == 100000007 || billingFrequency == 10000008) {
            var record = {};
            record.niq_nonstandardbillingterm = true; // Boolean
            await Xrm.WebApi.updateRecord("quote", quoteId, record);
            //return;
        } else if (type === 1 && billingFrequency === 100000009 || (brand !== "BASES" && billingFrequency === 100000012 && (termLength >= 1 || extendedamount_base > Number(thresholdValue)))) {
            var record = {};
            record.niq_nonstandardbillingterm = true; // Boolean
            await Xrm.WebApi.updateRecord("quote", quoteId, record);
            //return;
        }

        else if (quoteId !== null && thresholdValue !== null && currentQuoteProductId !== null) {

            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                "  <entity name='quotedetail'>" +
                "    <attribute name='createdon' />" +
                "    <order attribute='niq_brandid' descending='false' />" +
                "    <filter type='and'>" +
                "      <filter type='or'>" +
                "        <filter type='and'>" +
                "          <condition attribute='niq_type' operator='eq' value='2' />" +
                "          <filter type='or'>" +
                "            <condition attribute='niq_billingfrequency' operator='eq' value='100000007' />" +
                "            <condition attribute='niq_billingfrequency' operator='eq' value='100000006' />" +
                "            <condition attribute='niq_billingfrequency' operator='eq' value='100000008' />" +
                "          </filter>" +
                "        </filter>" +
                "        <filter type='and'>" +
                "          <condition attribute='niq_type' operator='eq' value='1' />" +
                "          <filter type='or'>" +
                "            <condition attribute='niq_billingfrequency' operator='eq' value='100000009' />" +
                "            <filter type='and'>" +
                "              <condition attribute='niq_billingfrequency' operator='eq' value='100000012' />" +
                "              <condition attribute='niq_brandidname' operator='ne' value='BASES' />" +
                "              <filter type='or'>" +
                "                <condition attribute='extendedamount_base' operator='gt' value='" + Number(thresholdValue) + "' />" +
                "                <condition attribute='niq_tenureindays' operator='gt' value='28' />" +
                "              </filter>" +
                "            </filter>" +
                "          </filter>" +
                "        </filter>" +
                "      </filter>" +
                "      <condition attribute='quotedetailid' operator='ne' value='" + currentQuoteProductId + "' />" +
                "    </filter>" +
                "    <link-entity name='quote' from='quoteid' to='quoteid' link-type='inner' alias='af'>" +
                "      <filter type='and'>" +
                "        <condition attribute='quoteid' operator='eq' value='{" + quoteId + "}' />" +
                "      </filter>" +
                "    </link-entity>" +
                "  </entity>" +
                "</fetch>"
            var results = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", "?fetchXml=" + encodeURIComponent(fetchXml));

            if (results.entities.length > 0) {
                var record = {};
                record.niq_nonstandardbillingterm = true; // Boolean
                await Xrm.WebApi.updateRecord("quote", quoteId, record);
                return;
            }
            else {
                var record = {};
                record.niq_nonstandardbillingterm = false; // Boolean
                await Xrm.WebApi.updateRecord("quote", quoteId, record);
                return;
            }
        }
        else {
            var record = {};
            record.niq_nonstandardbillingterm = false; // Boolean
            await Xrm.WebApi.updateRecord("quote", quoteId, record);
            return;
        }

    },
    //Show & Hide Revenue/Billing subgrid and set remaining amount fields in quote product pane form
    showCustomScheduleInPaneForm: async function (executionContext) {
        var allScheduleAmount = 0;
        var lastRemainingAmount = 0;
        var query = "";
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        var currentQuoteProductId = formContext.data.entity.getId();
        var totalAmount = formContext.getAttribute("extendedamount")?.getValue();
        var billingScheduleSubgrid = formContext.getControl("Subgrid_Billing_Schedule");
        var revenueScheduleSubgrid = formContext.getControl("Subgrid_Revenue_Schedule");
        var quoteId = formContext.getAttribute("quoteid")?.getValue();

        billingScheduleSubgrid.setVisible(false);
        revenueScheduleSubgrid.setVisible(false);
        //Get Quote product start date
        var currentQuoteProductId = formContext.data.entity.getId();
        var resultCurrency = await Xrm.WebApi.retrieveRecord("quotedetail", currentQuoteProductId.replace("{", "").replace("}", ""), "?$select=_transactioncurrencyid_value");
        var currencyId = resultCurrency["_transactioncurrencyid_value"];

        QuoteProductForm.Events.quoteProductPaneForm(executionContext);
        if (currentQuoteProductId != "" || currentQuoteProductId != null) {
            //Below onLoad is for Billing Schedule Subgrid
            billingScheduleSubgrid.addOnLoad(async function () {
                var billingSubgrid = billingScheduleSubgrid.getGrid().getTotalRecordCount();
                var startDate = formContext.getAttribute("niq_lineitemstartdate").getValue();
                lastRemainingAmount = 0;
                query = "?$select=niq_scheduleid,niq_amount,niq_scheduletype&$filter=(_niq_lineitemid_value eq '" + currentQuoteProductId.replace("{", "").replace("}", "") + "' and niq_scheduletype eq 100000000)";
                allScheduleAmount = await QuoteProductForm.Events.retrieveScheduleAmount(query);
                lastRemainingAmount = totalAmount - allScheduleAmount;
                var record = {};
                record.niq_remainingbillingamount = Number(parseFloat(lastRemainingAmount).toFixed(4)); // Currency
                if (formType == 2) {
                    record.niq_billingschedulestatus = record.niq_remainingbillingamount === 0 ? QuoteProductForm.Events.billingScheduleStatus.CompleteManualInput : QuoteProductForm.Events.billingScheduleStatus.IncompleteManualInput;
                    await Xrm.WebApi.updateRecord("quotedetail", currentQuoteProductId.replace("{", "").replace("}", ""), record);
                    let remainingBillingAmount = formContext.getAttribute("niq_remainingbillingamount");
                    if (remainingBillingAmount) {
                        remainingBillingAmount.setValue(record.niq_remainingbillingamount);
                        remainingBillingAmount.setSubmitMode("never"); // Manually trigger the OnChange event if necessary
                    }
                }
                var scheduleType = 100000000; // Schedule Type = billing
                var resultBillingCustomSchedule = await Xrm.WebApi.retrieveMultipleRecords("niq_schedule", "?$select=niq_iscustomschedule&$filter=(_niq_lineitemid_value eq " + currentQuoteProductId.replace("{", "").replace("}", "") + " and niq_iscustomschedule eq true and niq_scheduletype eq 100000000 and statuscode eq 1)&$top=1");
                if (resultBillingCustomSchedule.entities.length == 0 && startDate) {
                    //await QuoteProductForm.Events.autoCreateScheduleSchedule(currentQuoteProductId.replace("{", "").replace("}", ""), scheduleType, startDate, currencyId, billingScheduleSubgrid);
                }
            });
            //Below onLoad is for Revenue Schedule Subgrid
            revenueScheduleSubgrid.addOnLoad(async function () {
                var revenueSubgrid = revenueScheduleSubgrid.getGrid().getTotalRecordCount();
                var startDate = formContext.getAttribute("niq_lineitemstartdate").getValue();
                lastRemainingAmount = 0;
                query = "?$select=niq_scheduleid,niq_amount,niq_scheduletype&$filter=(_niq_lineitemid_value eq '" + currentQuoteProductId.replace("{", "").replace("}", "") + "' and (niq_scheduletype eq 100000001 or niq_scheduletype eq 100000002))";
                allScheduleAmount = await QuoteProductForm.Events.retrieveScheduleAmount(query);
                lastRemainingAmount = totalAmount - allScheduleAmount;
                var record = {};
                record.niq_remainingrevenueamount = Number(parseFloat(lastRemainingAmount).toFixed(4)); // Currency
                if (formType == 2) {
                    var deliveryFrequencyValue = formContext.getAttribute("niq_deliveryfrequency")?.getValue() ?? null;

                    if (deliveryFrequencyValue === 100000009) {
                        record.niq_revenueschedulestatus = record.niq_remainingrevenueamount === 0
                            ? QuoteProductForm.Events.revenueScheduleStatus.CompleteManualInput
                            : QuoteProductForm.Events.revenueScheduleStatus.IncompleteManualInput;
                    } else {
                        record.niq_revenueschedulestatus = record.niq_remainingrevenueamount === 0
                            ? 610570003 // Complete Schedules (Auto)
                            : 610570002; // Incomplete Schedules (Auto)
                    }
                    //record.niq_revenueschedulestatus = record.niq_remainingrevenueamount === 0 ? QuoteProductForm.Events.revenueScheduleStatus.CompleteManualInput : QuoteProductForm.Events.revenueScheduleStatus.IncompleteManualInput;
                    await Xrm.WebApi.updateRecord("quotedetail", currentQuoteProductId.replace("{", "").replace("}", ""), record);
                    let remainingRevenueAmount = formContext.getAttribute("niq_remainingrevenueamount");
                    if (remainingRevenueAmount) {
                        remainingRevenueAmount.setValue(record.niq_remainingrevenueamount);
                        remainingRevenueAmount.setSubmitMode("never"); // Manually trigger the OnChange event if necessary
                    }
                }
                var oppExistingContractAction = await QuoteProductForm.Events.retriveExistingContractAction(currentQuoteProductId.replace("{", "").replace("}", ""));
                if ((oppExistingContractAction === 2 || oppExistingContractAction === 4) && oppExistingContractAction !== null) {
                    var scheduleType = 100000002; // Schedule Type = revenue forecast
                    var resultRevenueCustomSchedule = await Xrm.WebApi.retrieveMultipleRecords("niq_schedule", "?$select=niq_iscustomschedule&$filter=(_niq_lineitemid_value eq " + currentQuoteProductId.replace("{", "").replace("}", "") + " and niq_iscustomschedule eq true and niq_scheduletype eq 100000002 and statuscode eq 1)&$top=1");
                    if (resultRevenueCustomSchedule.entities.length == 0 && startDate) {
                        //await QuoteProductForm.Events.autoCreateScheduleSchedule(currentQuoteProductId.replace("{", "").replace("}", ""), scheduleType, startDate, currencyId, revenueScheduleSubgrid);
                    }
                } else {
                    var scheduleType = 100000001; // Schedule Type = revenue
                    var resultRevenueCustomSchedule = await Xrm.WebApi.retrieveMultipleRecords("niq_schedule", "?$select=niq_iscustomschedule&$filter=(_niq_lineitemid_value eq " + currentQuoteProductId.replace("{", "").replace("}", "") + " and niq_iscustomschedule eq true and niq_scheduletype eq 100000001 and statuscode eq 1)&$top=1");
                    if (resultRevenueCustomSchedule.entities.length == 0 && startDate) {
                        //await QuoteProductForm.Events.autoCreateScheduleSchedule(currentQuoteProductId.replace("{", "").replace("}", ""), scheduleType, startDate, currencyId, revenueScheduleSubgrid);
                    }
                }
            });
        }
    },
    //Hide/Show custom billing/revenue subgrid and remaining amount fields in quote product pane form
    quoteProductPaneForm: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
        if (roles === null) return false;
        var hasRole = false;
        roles.forEach(function (item) {
            //here we can also use item.id to compare role id
            if (item.name == "NIQ Sales User" || item.name == "System Administrator") {
                hasRole = true;
            }
        });
        if (hasRole == true) {
            var billingFrequencyValue = formContext.getAttribute("niq_billingfrequency")?.getValue();
            var revenueFrequencyValue = formContext.getAttribute("niq_deliveryfrequency")?.getValue();
            var priceListItem = formContext.getAttribute("niq_pricelistitem")?.getValue();
            var existingProduct = formContext.getAttribute("productid")?.getValue();
            var quoteLookup = formContext.getAttribute("quoteid").getValue();
            //Get Quote product start date
            var startDate = formContext.getAttribute("niq_lineitemstartdate").getValue();
            var currentQuoteProductId = formContext.data.entity.getId();
            if (priceListItem != null && existingProduct != null && quoteLookup != null) {
                var priceListItemResult = await Xrm.WebApi.retrieveRecord("productpricelevel", priceListItem, "?$select=niq_istimebased,niq_producttype");
                var isTimeServiceBase = priceListItemResult["niq_istimebased"];
                var productType = priceListItemResult["niq_producttype"];
                var proposlStageOrNot = await this.stageName(quoteLookup[0].id.replace("{", "").replace("}", ""));
                var resultCurrency = await Xrm.WebApi.retrieveRecord("quotedetail", currentQuoteProductId.replace("{", "").replace("}", ""), "?$select=_transactioncurrencyid_value");
                var currencyId = resultCurrency["_transactioncurrencyid_value"];
                if (billingFrequencyValue == 100000009) {
                    //(productTyep eq adhoc and isTimeBase) or (productType eq adhoc and isServiceBase)
                    if (((productType == 100000001 && isTimeServiceBase == false) || (productType == 100000001 && isTimeServiceBase == true)) && proposlStageOrNot) {
                        //If billingFrequency eq Ad-hoc(Custom) show Billing Schedule Section
                        formContext.getControl("Subgrid_Billing_Schedule").setVisible(true);
                        //formContext.getControl("Subgrid_Billing_Schedule").refresh();
                        formContext.getControl("niq_remainingbillingamount").setVisible(true);
                        formContext.getControl("niq_billingschedulecopies").setVisible(true);

                    } else {
                        formContext.getControl("Subgrid_Billing_Schedule").setVisible(false);
                        formContext.getControl("niq_remainingbillingamount").setVisible(false);
                        formContext.getControl("niq_billingschedulecopies").setVisible(false);
                    }
                } else {
                    formContext.getControl("Subgrid_Billing_Schedule").setVisible(false);
                    formContext.getControl("niq_remainingbillingamount").setVisible(false);
                    formContext.getControl("niq_billingschedulecopies").setVisible(false);
                }
                //If revenueFrequency(delivery) eq Ad-hoc(Custom) show Revenue Schedule Section
                if (revenueFrequencyValue == 100000009) {
                    // priceListItemResult = await Xrm.WebApi.retrieveRecord("productpricelevel", priceListItem, "?$select=niq_istimebased,niq_producttype");
                    // productType = priceListItemResult["niq_producttype"];
                    var productResult = await Xrm.WebApi.retrieveRecord("product", existingProduct[0].id.replace("{", "").replace("}", ""), "?$select=niq_onplatformdelivery");
                    var onPlatFormDelivery = productResult["niq_onplatformdelivery"];
                    if (onPlatFormDelivery != null) {
                        //OnPlateformDelivery is No and productType is ad-hoc and product isServiceBase
                        if (onPlatFormDelivery == false && productType == 100000001 && isTimeServiceBase == false) {
                            formContext.getControl("Subgrid_Revenue_Schedule").setVisible(true);
                            //formContext.getControl("Subgrid_Revenue_Schedule").refresh();
                            formContext.getControl("niq_remainingrevenueamount").setVisible(true);
                            formContext.getControl("niq_revenueschedulecopies").setVisible(true);
                        } else {
                            formContext.getControl("Subgrid_Revenue_Schedule").setVisible(false);
                            formContext.getControl("niq_remainingrevenueamount").setVisible(false);
                            formContext.getControl("niq_revenueschedulecopies").setVisible(false);
                        }
                    } else {
                        var record = {};
                        record.niq_onplatformdelivery = false; // Boolean
                        await Xrm.WebApi.updateRecord("product", existingProduct[0].id.replace("{", "").replace("}", ""), record);
                    }
                } else {
                    formContext.getControl("Subgrid_Revenue_Schedule")?.setVisible(false);
                    formContext.getControl("niq_remainingrevenueamount").setVisible(false);
                    formContext.getControl("niq_revenueschedulecopies").setVisible(false);
                }
            }
        }
        this.IsFormReadOnly(executionContext);
    },
    setEndDt4Adhoc: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var type = formContext.getAttribute("niq_type")?.getValue();
        var istimeBased = formContext.getAttribute("niq_istimebased").getValue();
        //var termLength = formContext.getAttribute("niq_termlength")?.getValue();
        //DYNCRM-21595
        var termLength = formContext.getAttribute("niq_calculatedtermlength")?.getValue();
        let dateField, selectedDate, startdateField;

        if (((type === 1 && istimeBased === false && formContext.getAttribute("niq_updatefrequency")?.getValue() !== 100000009) || (type === 2)) && termLength > 0) {
            dateField = formContext.getAttribute("niq_lineitemstartdate");
            //formContext.getControl("niq_lineitemenddate").setDisabled(true);
            // Start date can only be 1st of any month
            if (dateField != null && dateField.getValue() != null) {
                selectedDate = dateField.getValue();
                var day = selectedDate.getDate();
                if (day !== 1) {
                    selectedDate.setDate(1);
                    //dateField.setValue(selectedDate);
                    formContext.getAttribute("niq_lineitemstartdate")?.setValue(selectedDate);
                    formContext.ui.setFormNotification("Only the first of the month is allowed. Date has been adjusted to the 1st.", "INFO", "firstOfMonthNotification");
                    // formContext.getAttribute("niq_lineitemstartdate").fireOnChange();
                    formContext.getAttribute("niq_lineitemstartdate")?.setIsValid(false, "Only the first of the month is allowed");

                } else {
                    formContext.getAttribute("niq_lineitemstartdate")?.setIsValid(true, "");
                    formContext.ui.clearFormNotification("firstOfMonthNotification");
                }
                // End date has to be last date of start date + termlength
                startdateField = formContext.getAttribute("niq_lineitemstartdate")?.getValue();
                startdateField.setMonth(startdateField.getMonth() + termLength, 0);
                formContext.getAttribute("niq_lineitemenddate")?.setValue(startdateField);
                formContext.getAttribute("niq_lineitemstartdate")?.setIsValid(true, "");
                this.CalculateTermLength(executionContext);

            }
        }
    },
    //End Date is not less than start date
    onChangeEndDate: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var eventArgs = executionContext.getEventArgs();
        var startDate = formContext.getAttribute("niq_lineitemstartdate").getValue();
        var endDate = formContext.getAttribute("niq_lineitemenddate").getValue();
        var productType = formContext.getAttribute("niq_type")?.getValue();
        var istimeBased = formContext.getAttribute("niq_istimebased").getValue();
        var rateCardUpdateFrequency = formContext.getAttribute("niq_ratecardupdatefrequency")?.getValue();
        var updateFrequencyValue = formContext.getAttribute("niq_updatefrequency")?.getValue();


        if (startDate != null && endDate != null && productType != null && productType === 1 && new Date(endDate) < new Date(startDate)) {
            Xrm.Navigation.openErrorDialog({ message: "End date cannot be before start date." });
            //formContext.getAttribute("niq_lineitemenddate").setValue(null);
            //executionContext.getEventArgs().preventDefault();
        }
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_billingstartdate") && CommonForm.Events.CheckFieldExists(formContext, "niq_billingenddate")) {
            let BillingEndDate = formContext.getAttribute("niq_billingenddate")?.getValue();
            if (new Date(QuoteProductForm.Events.OriginalEnddate).getTime() == new Date(BillingEndDate).getTime()) {
                formContext.getAttribute("niq_billingenddate").setValue(endDate);
            }

        }
        if ((productType === 2 && rateCardUpdateFrequency === "Adhoc") || (productType === 1 && rateCardUpdateFrequency === null && istimeBased === false && updateFrequencyValue !== 100000009)) {
            let endIsLastDay = QuoteProductForm.Events.IsLastDayOfMonth(endDate);
            if (!endIsLastDay) {
                const date = formContext.getAttribute("niq_lineitemenddate").getValue();
                const lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0); // Get last day of month

                // Set the value on the form (must be a Date object)
                formContext.getAttribute("niq_lineitemenddate").setValue(lastDay);
                formContext.ui.setFormNotification("Only the last of the month is allowed. Date has been adjusted to the last.", "INFO", "lastOfMonthNotification");
                this.CalculateTermLength(executionContext);
                //formContext.getAttribute("niq_lineitemenddate")?.setIsValid(false);
            }
            else {
                //formContext.getAttribute("niq_lineitemenddate")?.setIsValid(true);
                formContext.ui.clearFormNotification("lastOfMonthNotification");
            }

        }
    },
    //start Date is not greater than end date
    onChangeStartDate: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var startDate = formContext.getAttribute("niq_lineitemstartdate").getValue();
        var endDate = formContext.getAttribute("niq_lineitemenddate").getValue();
        var productType = formContext.getAttribute("niq_type")?.getValue();
        if (startDate != null && endDate != null && productType != null && productType === 1 && new Date(startDate) > new Date(endDate)) {
            Xrm.Navigation.openErrorDialog({ message: "Start date cannot be after End date." });
            //formContext.getAttribute("niq_lineitemstartdate").setValue(null);
            //executionContext.getEventArgs().preventDefault();
        }
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_billingstartdate") && CommonForm.Events.CheckFieldExists(formContext, "niq_billingenddate")) {
            let BillingstartDate = formContext.getAttribute("niq_billingstartdate")?.getValue();
            if (new Date(QuoteProductForm.Events.OriginalStartdate).getTime() == new Date(BillingstartDate).getTime()) {
                formContext.getAttribute("niq_billingstartdate").setValue(startDate);
            }

        }

    },
    //on save of quote product End Date is not less than start date OR start Date is not greater than end date
    onSaveOfQuoteProduct: function (executionContext) {

        var formContext = executionContext.getFormContext();
        var eventArgs = executionContext.getEventArgs();
        var startDate = formContext.getAttribute("niq_lineitemstartdate").getValue();
        var endDate = formContext.getAttribute("niq_lineitemenddate").getValue();
        var productType = formContext.getAttribute("niq_type")?.getValue();
        var updateFrequency = formContext.getAttribute("niq_updatefrequency")?.getValue();
        var revenueFrequency = formContext.getAttribute("niq_deliveryfrequency")?.getValue();
        var billingFrequency = formContext.getAttribute("niq_billingfrequency")?.getValue();
        var lagRevenueRecognition = formContext.getAttribute("niq_lagrevenuerecognition")?.getValue();
        if (/*productType === 1 &&*/ productType !== null) {
            if ((startDate == null || endDate == null) || (new Date(startDate) > new Date(endDate) || new Date(endDate) < new Date(startDate)) || billingFrequency == null || lagRevenueRecognition == null || revenueFrequency == null || updateFrequency == null) {

                if (eventArgs.getSaveMode() == 2 || eventArgs.getSaveMode() == 70 || eventArgs.getSaveMode() == 1 || eventArgs.getSaveMode() == 59) {
                    if (billingFrequency == null || lagRevenueRecognition == null || revenueFrequency == null || updateFrequency == null) {
                        Xrm.Navigation.openErrorDialog({ message: "Please check the Update Frequency, Revenue Frequency, Billing Frequency and Lag Revenue Recognition." });
                    }
                    if ((startDate == null || endDate == null) || (new Date(startDate) > new Date(endDate) || new Date(endDate) < new Date(startDate))) {
                        Xrm.Navigation.openErrorDialog({ message: "Please check the Start Date Or End date." });
                    }
                    executionContext.getEventArgs().preventDefault();
                }

            }
            else {
                this.FrequencyCompatibilityCheck(executionContext);
            }
        }
    },
    CalculateTermLength: async function (executionContext) {
        let formContext = executionContext.getFormContext();
        let startDate = formContext.getAttribute("niq_lineitemstartdate")?.getValue();
        let endDate = formContext.getAttribute("niq_lineitemenddate")?.getValue();
        var id = formContext.data.entity.getId();
        //Xrm.Utility.showProgressIndicator("Calculating term length..");
        //let quoteDetailsData = await Xrm.WebApi.retrieveRecord("quotedetail", id.replace("{", "").replace("}", ""), "?$select=niq_termlength");
        //Xrm.Utility.closeProgressIndicator();
        //let termLength = quoteDetailsData.niq_termlength;
        let rateCardUpdateFrequency = formContext.getAttribute("niq_ratecardupdatefrequency")?.getValue();
        let type = formContext.getAttribute("niq_type")?.getValue();
        let isTimeBased = formContext.getAttribute("niq_istimebased")?.getValue();
        let billingFrequency = formContext.getAttribute("niq_billingfrequency")?.getValue();
        let revenueFrequency = formContext.getAttribute("niq_deliveryfrequency")?.getValue();
        let lagRevenueRecognition = formContext.getAttribute("niq_lagrevenuerecognition")?.getValue();
        let updateFrequency = formContext.getAttribute("niq_updatefrequency")?.getValue();
        let shouldRecalculate = false;

        if (type === 1) { // Ad-hoc
            if (!isTimeBased) {
                if (rateCardUpdateFrequency === null || rateCardUpdateFrequency === "Adhoc") {
                    shouldRecalculate = true;
                }

            }
            else {
                shouldRecalculate = true;
            }

        } else {
            // Periodic 
            if (rateCardUpdateFrequency === "Adhoc") {
                shouldRecalculate = true;
            }
        }

        if (!shouldRecalculate) {
            return;
        }
        // Check if startDate and endDate are valid
        if (QuoteProductForm.Events.IsValid(startDate) && QuoteProductForm.Events.IsValid(endDate)) {

            let startIsFirstDay = QuoteProductForm.Events.IsFirstDayOfMonth(startDate);
            let endIsLastDay = QuoteProductForm.Events.IsLastDayOfMonth(endDate);

            if (startIsFirstDay && endIsLastDay) {
                // Scenario 1: Start date is the 1st day and End date is the last day of the month
                if (QuoteProductForm.Events.AreDatesInSameMonth(startDate, endDate)) {
                    // Same month
                    //formContext.getAttribute("niq_termlength")?.setValue(1);
                    //DYNCRM-21595
                    formContext.getAttribute("niq_calculatedtermlength")?.setValue(1);
                    //record.niq_termlength = 1;
                    if (updateFrequency == null) {
                        formContext.getAttribute("niq_updatefrequency").setValue(100000009);
                    }
                    if (revenueFrequency == null) {
                        formContext.getAttribute("niq_deliveryfrequency").setValue(100000009);
                    }
                    if (lagRevenueRecognition == null) {
                        formContext.getAttribute("niq_lagrevenuerecognition").setValue(100000000);
                    }
                    if (billingFrequency == null) {
                        formContext.getAttribute("niq_billingfrequency").setValue(100000010);
                    }

                    // set Billing Start date
                    if (CommonForm.Events.CheckFieldExists(formContext, "niq_billingstartdate") && CommonForm.Events.CheckFieldExists(formContext, "niq_billingenddate")) {
                        let BillingstartDate = formContext.getAttribute("niq_billingstartdate")?.getValue();
                        if (new Date(QuoteProductForm.Events.OriginalStartdate).getTime() == new Date(BillingstartDate).getTime()) {
                            formContext.getAttribute("niq_billingstartdate").setValue(startDate);
                        }

                    }
                    if (CommonForm.Events.CheckFieldExists(formContext, "niq_billingstartdate") && CommonForm.Events.CheckFieldExists(formContext, "niq_billingenddate")) {
                        let BillingEndDate = formContext.getAttribute("niq_billingenddate")?.getValue();
                        if (new Date(QuoteProductForm.Events.OriginalEnddate).getTime() == new Date(BillingEndDate).getTime()) {
                            formContext.getAttribute("niq_billingenddate").setValue(endDate);
                        }

                    }

                } else {
                    // Different months
                    let diffInMonths = QuoteProductForm.Events.MonthsDifference(startDate, endDate);
                    //formContext.getAttribute("niq_termlength")?.setValue(1 + diffInMonths);
                    //DYNCRM-21595
                    formContext.getAttribute("niq_calculatedtermlength")?.setValue(1 + diffInMonths);
                    //record.niq_termlength = 1 + diffInMonths;
                    if (updateFrequency == null) {
                        formContext.getAttribute("niq_updatefrequency").setValue(100000009);
                    }
                    if (revenueFrequency == null) {
                        formContext.getAttribute("niq_deliveryfrequency").setValue(100000009);
                    }
                    if (lagRevenueRecognition == null) {
                        formContext.getAttribute("niq_lagrevenuerecognition").setValue(100000000);
                    }
                    if (billingFrequency == null) {
                        formContext.getAttribute("niq_billingfrequency").setValue(100000010);
                    }

                    // set Billing Start date
                    if (CommonForm.Events.CheckFieldExists(formContext, "niq_billingstartdate") && CommonForm.Events.CheckFieldExists(formContext, "niq_billingenddate")) {
                        let BillingstartDate = formContext.getAttribute("niq_billingstartdate")?.getValue();
                        if (new Date(QuoteProductForm.Events.OriginalStartdate).getTime() == new Date(BillingstartDate).getTime()) {
                            formContext.getAttribute("niq_billingstartdate").setValue(startDate);
                        }

                    }
                    if (CommonForm.Events.CheckFieldExists(formContext, "niq_billingstartdate") && CommonForm.Events.CheckFieldExists(formContext, "niq_billingenddate")) {
                        let BillingEndDate = formContext.getAttribute("niq_billingenddate")?.getValue();
                        if (new Date(QuoteProductForm.Events.OriginalEnddate).getTime() == new Date(BillingEndDate).getTime()) {
                            formContext.getAttribute("niq_billingenddate").setValue(endDate);
                        }

                    }
                }
            } else if (startIsFirstDay && !endIsLastDay) {
                // Scenario 2: Start date is the 1st day and End date is not the last day of the month
                //formContext.getAttribute("niq_termlength")?.setValue(0);
                //DYNCRM-21595
                formContext.getAttribute("niq_calculatedtermlength")?.setValue(0);
                //record.niq_termlength = 0;
                // Set common attribute values
                if (updateFrequency == null) {
                    formContext.getAttribute("niq_updatefrequency").setValue(100000009);
                }
                if (revenueFrequency == null) {
                    formContext.getAttribute("niq_deliveryfrequency").setValue(100000009);
                }
                if (lagRevenueRecognition == null) {
                    formContext.getAttribute("niq_lagrevenuerecognition").setValue(100000000);
                }
                if (billingFrequency == null) {
                    formContext.getAttribute("niq_billingfrequency").setValue(100000010);
                }

                // set Billing Start date
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_billingstartdate") && CommonForm.Events.CheckFieldExists(formContext, "niq_billingenddate")) {
                    let BillingstartDate = formContext.getAttribute("niq_billingstartdate")?.getValue();
                    if (new Date(QuoteProductForm.Events.OriginalStartdate).getTime() == new Date(BillingstartDate).getTime()) {
                        formContext.getAttribute("niq_billingstartdate").setValue(startDate);
                    }

                }
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_billingstartdate") && CommonForm.Events.CheckFieldExists(formContext, "niq_billingenddate")) {
                    let BillingEndDate = formContext.getAttribute("niq_billingenddate")?.getValue();
                    if (new Date(QuoteProductForm.Events.OriginalEnddate).getTime() == new Date(BillingEndDate).getTime()) {
                        formContext.getAttribute("niq_billingenddate").setValue(endDate);
                    }

                }

            } else if (!startIsFirstDay && endIsLastDay) {
                // Scenario 3: Start date is not the 1st day and End date is the last day of the month
                //formContext.getAttribute("niq_termlength")?.setValue(0);
                //DYNCRM-21595
                formContext.getAttribute("niq_calculatedtermlength")?.setValue(0);
                //record.niq_termlength = 0;
                // Set common attribute values
                if (updateFrequency == null) {
                    formContext.getAttribute("niq_updatefrequency").setValue(100000009);
                }
                if (revenueFrequency == null) {
                    formContext.getAttribute("niq_deliveryfrequency").setValue(100000009);
                }
                if (lagRevenueRecognition == null) {
                    formContext.getAttribute("niq_lagrevenuerecognition").setValue(100000000);
                }
                if (billingFrequency == null) {
                    formContext.getAttribute("niq_billingfrequency").setValue(100000010);
                }

                // set Billing Start date
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_billingstartdate") && CommonForm.Events.CheckFieldExists(formContext, "niq_billingenddate")) {
                    let BillingstartDate = formContext.getAttribute("niq_billingstartdate")?.getValue();
                    if (new Date(QuoteProductForm.Events.OriginalStartdate).getTime() == new Date(BillingstartDate).getTime()) {
                        formContext.getAttribute("niq_billingstartdate").setValue(startDate);
                    }

                }
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_billingstartdate") && CommonForm.Events.CheckFieldExists(formContext, "niq_billingenddate")) {
                    let BillingEndDate = formContext.getAttribute("niq_billingenddate")?.getValue();
                    if (new Date(QuoteProductForm.Events.OriginalEnddate).getTime() == new Date(BillingEndDate).getTime()) {
                        formContext.getAttribute("niq_billingenddate").setValue(endDate);
                    }

                }
            } else if (!startIsFirstDay && !endIsLastDay) {
                //formContext.getAttribute("niq_termlength")?.setValue(0);
                //DYNCRM-21595
                formContext.getAttribute("niq_calculatedtermlength")?.setValue(0);
                //record.niq_termlength = 0;
                // Set common attribute values
                if (updateFrequency == null) {
                    formContext.getAttribute("niq_updatefrequency").setValue(100000009);
                }
                if (revenueFrequency == null) {
                    formContext.getAttribute("niq_deliveryfrequency").setValue(100000009);
                }
                if (lagRevenueRecognition == null) {
                    formContext.getAttribute("niq_lagrevenuerecognition").setValue(100000000);
                }
                if (billingFrequency == null) {
                    formContext.getAttribute("niq_billingfrequency").setValue(100000010);
                }

                // set Billing Start date
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_billingstartdate") && CommonForm.Events.CheckFieldExists(formContext, "niq_billingenddate")) {
                    let BillingstartDate = formContext.getAttribute("niq_billingstartdate")?.getValue();
                    if (new Date(QuoteProductForm.Events.OriginalStartdate).getTime() == new Date(BillingstartDate).getTime()) {
                        formContext.getAttribute("niq_billingstartdate").setValue(startDate);
                    }

                }
                if (CommonForm.Events.CheckFieldExists(formContext, "niq_billingstartdate") && CommonForm.Events.CheckFieldExists(formContext, "niq_billingenddate")) {
                    let BillingEndDate = formContext.getAttribute("niq_billingenddate")?.getValue();
                    if (new Date(QuoteProductForm.Events.OriginalEnddate).getTime() == new Date(BillingEndDate).getTime()) {
                        formContext.getAttribute("niq_billingenddate").setValue(endDate);
                    }

                }
            }
        }
        formContext.getAttribute("niq_billingfrequency").fireOnChange();
    },

    //Find out term lenght from Startdate and EndDate if start date and end date is 1st day and last day of resepectively
    MonthsDifference: function (startDate, endDate) {
        // Create Date objects from the start and end dates
        const start = new Date(startDate);
        const end = new Date(endDate);

        // Calculate the difference in years and months
        const yearDiff = end.getFullYear() - start.getFullYear();
        const monthDiff = end.getMonth() - start.getMonth();

        // Total months difference
        const totalMonths = yearDiff * 12 + monthDiff;

        // Return the total difference in months
        return totalMonths;
    },
    //Return true if day is 1st day of a month
    IsFirstDayOfMonth: function (date) {
        const day = date.getDate();
        if (day === 1) {
            return true
        } else { return false }
    },
    //Return true if day is  last day of a month
    IsLastDayOfMonth: function (date) {
        const lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
        if (date.getDate() === lastDay) { return true; } else { return false; }
    },
    AreDatesInSameMonth: function (startDate, endDate) {
        // Parse the input dates as Date objects
        const start = new Date(startDate);
        const end = new Date(endDate);

        // Check if the year and month of both dates are the same
        if (start.getFullYear() === end.getFullYear() && start.getMonth() === end.getMonth()) {
            return true
        } else { return false; }
    },
    filterBillingFrequencyOptionSet: function (executionContext, shouldBehaveAsAdhoc) {
        let formContext = executionContext.getFormContext();
        let valuesToKeep = [];
        // Get the Option Set field
        let optionSetField = formContext.getControl("niq_billingfrequency");
        if (shouldBehaveAsAdhoc) {
            // Define the values to keep
            valuesToKeep = [
                100000009, // Ad-Hoc
                100000010, // 50/50
                100000011, // 80/20
                100000012, // 0/100
                100000013, // One Time
                100000014  // 60/40

            ];
        } else {
            valuesToKeep = [
                100000000, // Monthly
                100000001, // BiMonthly
                100000002, // Quarterly
                100000003, // 3 X Annually
                100000004,  // Half-Yearly
                100000005, //Annually
                100000006, //Bi-Monthly- Monthly Rev Rec
                100000007, // Quarterly- Monthly Rev Rec
                100000008, //Monthly (Time Based)
                100000009, // Ad-Hoc
                100000010, // 50/50
                100000011, // 80/20
                100000012, // 0/100
                100000013,  // One Time
                100000014  // 60/40
            ];
        }


        // Get all options
        let options = optionSetField.getOptions();

        // Iterate through the options and remove those that do not match the valuesToKeep
        options.forEach(function (option) {
            if (valuesToKeep.indexOf(option.value) === -1) {
                optionSetField.removeOption(option.value);
            }
        });
    },
    filterUpdateFrequencyOptionSet: function (executionContext, shouldBehaveAsAdhoc) {
        let formContext = executionContext.getFormContext();

        // Get the Option Set field
        let optionSetField = formContext.getControl("niq_updatefrequency");
        let valuesToKeep = [];
        // Define the value to keep
        if (shouldBehaveAsAdhoc) {
            valuesToKeep = [100000009];
        } else {
            valuesToKeep = [
                100000000, // Monthly
                100000001, // BiMonthly
                100000002, // Quarterly
                100000003, // 3 X Annually
                100000004, // Half-Yearly
                100000005, //Annually
                100000008, //Monthly (Time Based)
                100000009, // custom
                100000010, // weekly
                100000011 // biweekly
            ];
        }


        // Get all options
        let options = optionSetField.getOptions();

        options.forEach(function (option) {
            if (valuesToKeep.indexOf(option.value) === -1) {
                optionSetField.removeOption(option.value);
            }
        });
    },
    //Get opportunity stage
    stageName: async function (quoteGuid) {
        var stageResult = await Xrm.WebApi.retrieveMultipleRecords("opportunity", "?$select=_niq_mainquoteid_value,niq_stage&$filter=(_niq_mainquoteid_value eq " + quoteGuid + " and niq_stage ne 'Pre-Proposal')");
        if (stageResult.entities.length > 0) {
            return true;
        } else {
            return false;
        }
    },
    IsFormReadOnly: async function (executionContext) {
        let formContext = executionContext.getFormContext();
        let quoteId = formContext.getAttribute("quoteid")?.getValue()[0].id.replace("{", "").replace("}", "");
        if (!QuoteProductForm.Events.IsValid(quoteId)) { return; }
        let fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
            "<entity name='opportunity'>" +
            "<attribute name='niq_approvalstatus' />" +
            "<attribute name='niq_stage' />" +
            "<filter type='and'>" +
            "<filter type='or'>" +
            "<condition attribute='niq_stage' operator='eq' value='Closed Won - In Review' />" +
            "<condition attribute='niq_stage' operator='eq' value='Closed Lost' />" +
            "<condition attribute='niq_stage' operator='eq' value='Closed Won - Approved' />" +
            "</filter>" +
            "</filter>" +
            "<link-entity name='quote' from='opportunityid' to='opportunityid' link-type='inner' alias='ab'>" +
            "<filter type='and'>" +
            "<condition attribute='quoteid' operator='eq' value='{" + quoteId + "}' />" +
            "</filter>" +
            "</link-entity>" +
            "</entity>" +
            "</fetch>";

        var results = await Xrm.WebApi.retrieveMultipleRecords("opportunity", "?fetchXml=" + encodeURIComponent(fetchXml));

        if (results.entities.length > 0) {
            if (QuoteProductForm.Events.IsValid(results) && QuoteProductForm.Events.IsValid(results.entities) && QuoteProductForm.Events.IsValid(results.entities[0]) && QuoteProductForm.Events.IsValid(results.entities[0].niq_stage)) {
                switch (results.entities[0].niq_stage) {
                    case "Closed Won - In Review":
                        switch (results.entities[0].niq_approvalstatus) {
                            case 100000001: //Pending
                            case 100000000: //In Progress
                            case 100000002: //Approved
                                this.MakeFormReadOnly(executionContext);
                                break;

                            case 100000005: //OM correction in progress
                                if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add On Sales Ops Approver") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User") && CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User")) {
                                    this.MakeFormReadOnly(executionContext);
                                }
                                else if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User") && !CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Add-On Finance Gatekeeper")) {
                                    this.MakeFormReadOnly(executionContext);
                                }
                                break;
                            case 100000006: //Sales Ops Correction in Progress 
                                if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User") && !CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Finance User")) {
                                    this.MakeFormReadOnly(executionContext);
                                }
                                break;
                        }
                        break;
                    case "Closed Lost":
                        this.MakeFormReadOnly(executionContext);
                        break;
                    case "Closed Won - Approved":
                        if (QuoteProductForm.Events.IsValid(results.entities[0].niq_approvalstatus) && (results.entities[0].niq_approvalstatus === 100000002)) // 100000002==approved
                        {
                            this.MakeFormReadOnly(executionContext);
                        }
                        break;
                }
            }
        }
    },
    MakeFormReadOnly: function (executionContext) {
        var formContext = executionContext.getFormContext();

        var subgridrRevenue = formContext.getControl("Subgrid_Revenue_Schedule"); // replace with your subgrid name
        if (subgridrRevenue) {
            subgridrRevenue.setVisible(false);
        }
        // var subgridrbilling = formContext.getControl("Subgrid_Billing_Schedule"); // replace with your subgrid name

        // if (subgridrbilling) {
        //     subgridrbilling.setVisible(false);
        // }

        // Get all attributes and make them read-only
        var attributes = formContext.data.entity.attributes.get();
        for (var i in attributes) {
            var attribute = attributes[i];
            if (attribute['_attributeName'] != null && attribute['_attributeName'] !== "niq_wbs") {
                attribute.controls.forEach(function (control) {
                    control.setDisabled(true); // Disable the control
                });
            }

        }

        // Optionally, you can also make the form's tabs and sections read-only
        var tabs = formContext.ui.tabs.get();
        tabs.forEach(function (tab) {
            tab.sections.forEach(function (section) {
                section.controls.forEach(function (control) {
                    //control.setDisabled(true); // Disable the control within the section
                });
            });
        });
    },
    //Automatically create custom schedule when billing and revenue subgrid load
    autoCreateScheduleSchedule: async function (currenRecordGuid, scheduleType, scheduleDate, currencyId, subgridControl) {
        var scheduleName = await this.formatDate(new Date(scheduleDate));
        var record = {};
        record.niq_amount = Number(parseFloat(1).toFixed(4)); // Currency
        record["transactioncurrencyid@odata.bind"] = "/transactioncurrencies(" + currencyId + ")"; // Lookup
        record.niq_iscustomschedule = true; // Boolean
        record["niq_lineitemid@odata.bind"] = "/quotedetails(" + currenRecordGuid + ")"; // Lookup
        record.niq_scheduledate = await this.formatDateYYYYMMDD(scheduleDate); // Date Time
        record.niq_scheduletype = scheduleType; // Choice
        record.niq_name = scheduleName; // Text

        await Xrm.WebApi.createRecord("niq_schedule", record);
        subgridControl.refresh();
    },
    formatDate: async function (date) {
        // Customize the date format as needed
        var day = date.getDate().toString().padStart(2, '0');
        var month = (date.getMonth() + 1).toString().padStart(2, '0'); // Months are zero-based
        var year = date.getFullYear();

        // Example format: MM/dd/yyyy
        return `${month}/${day}/${year}`;
    },
    formatDateYYYYMMDD: async function (date) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    },
    SetTermLength: async function (executionContext) {
        let formContext = executionContext.getFormContext();
        let startDate = formContext.getAttribute("niq_lineitemstartdate")?.getValue();
        let endDate = formContext.getAttribute("niq_lineitemenddate")?.getValue();
        var id = formContext.data.entity.getId();
        //let quoteDetailsData = await Xrm.WebApi.retrieveRecord("quotedetail", id.replace("{", "").replace("}", ""), "?$select=niq_termlength");
        //let termLength = quoteDetailsData.niq_termlength;
        let rateCardUpdateFrequency = formContext.getAttribute("niq_ratecardupdatefrequency")?.getValue();
        let type = formContext.getAttribute("niq_type")?.getValue();
        let isTimeBased = formContext.getAttribute("niq_istimebased")?.getValue();
        let entityLogicalName = formContext.data.entity.getEntityName();
        let shouldRecalculate = false;

        if (type === 1) { // Ad-hoc
            if (!isTimeBased) {
                if (rateCardUpdateFrequency === null || rateCardUpdateFrequency === "Adhoc") {

                    shouldRecalculate = true;
                }

            }
            else {
                shouldRecalculate = true;
            }

        } else {
            // Periodic 
            if (rateCardUpdateFrequency === "Adhoc") {
                //formContext.getControl("niq_lineitemenddate").setDisabled(false);
                shouldRecalculate = true;
            }
        }

        if (!shouldRecalculate) {
            return;
        }

        // Check if startDate and endDate are valid
        if (QuoteProductForm.Events.IsValid(startDate) && QuoteProductForm.Events.IsValid(endDate)) {

            let startIsFirstDay = QuoteProductForm.Events.IsFirstDayOfMonth(startDate);
            let endIsLastDay = QuoteProductForm.Events.IsLastDayOfMonth(endDate);

            if (startIsFirstDay && endIsLastDay) {
                // Scenario 1: Start date is the 1st day and End date is the last day of the month
                if (QuoteProductForm.Events.AreDatesInSameMonth(startDate, endDate)) {
                    //formContext.getAttribute("niq_termlength")?.setValue(1);
                    //DYNCRM-21595
                    formContext.getAttribute("niq_calculatedtermlength")?.setValue(1);
                    formContext.data.save();
                    formContext.data.refresh(true);
                    //formContext.getControl("niq_lineitemenddate").setDisabled(true);
                    //formContext.getControl("niq_lineitemstartdate").setDisabled(true);
                } else {
                    // Different months
                    let diffInMonths = QuoteProductForm.Events.MonthsDifference(startDate, endDate);
                    //formContext.getAttribute("niq_termlength")?.setValue(1 + diffInMonths);
                    //DYNCRM-21595
                    formContext.getAttribute("niq_calculatedtermlength")?.setValue(1 + diffInMonths);
                    formContext.data.save();
                    //formContext.getControl("niq_lineitemenddate").setDisabled(true);
                    //formContext.getControl("niq_lineitemstartdate").setDisabled(true);
                    // var data = {
                    //     "niq_termlength": 1 + diffInMonths,
                    //     "niq_calculatedtermlength": 1 + diffInMonths
                    // }
                    // Xrm.WebApi.updateRecord(entityLogicalName, id, data).then(
                    //     function success(result) {
                    //         console.log("Account updated");
                    //         formContext.data.refresh(true);
                    //     },
                    //     function (error) {
                    //         console.log(error.message);
                    //         // handle error conditions
                    //     }
                    // );
                }
            }
        }
    },
    // DYNCRM-21736 and DYNCRM-21639
    // Hiding and showing Billing start date and End date based on Quote product type
    hideShowBillingStartEndDate: function (executionContext) {
        var formContext = executionContext.getFormContext();
        let quoteProductType = formContext.getAttribute("niq_type")?.getValue();
        let billingStartDate = formContext.getControl("niq_billingstartdate");
        let billingEndDate = formContext.getControl("niq_billingenddate");
        let billingFrequencyVal = formContext.getAttribute("niq_billingfrequency")?.getValue();
        //fields billing start date and billing end date are present
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_billingstartdate") && CommonForm.Events.CheckFieldExists(formContext, "niq_billingenddate")) {
            // if quote product type is not null and billing frequency is not null
            if (quoteProductType !== null || billingFrequencyVal !== null) {
                //if quote product type = "ad hoc" and billing frequency = 80/20,50/50,0/100, One Time Billing start and end date is visible
                if (quoteProductType == 1 && (billingFrequencyVal === 100000011 || billingFrequencyVal === 100000010 || billingFrequencyVal === 100000012 || billingFrequencyVal === 100000013 || billingFrequencyVal === 100000014)) {
                    billingStartDate.setVisible(true);
                    billingEndDate.setVisible(true);
                    QuoteProductForm.Events.OriginalStartdate = formContext.getAttribute("niq_lineitemstartdate")?.getValue();
                    QuoteProductForm.Events.OriginalEnddate = formContext.getAttribute("niq_lineitemenddate")?.getValue();
                    if (formContext.getAttribute("niq_billingstartdate")?.getValue() === null && formContext.getAttribute("niq_billingenddate")?.getValue() === null) {
                        formContext.getAttribute("niq_billingstartdate").setValue(QuoteProductForm.Events.OriginalStartdate);
                        formContext.getAttribute("niq_billingenddate").setValue(QuoteProductForm.Events.OriginalEnddate);
                    }

                }
                //if quote product type is "periodic" billing start and end date is not visible
                else {
                    billingStartDate.setVisible(false);
                    billingEndDate.setVisible(false);
                    // formContext.getAttribute("niq_billingstartdate").setValue(null);
                    // formContext.getAttribute("niq_billingenddate").setValue(null);
                }
            } else {
                billingStartDate.setVisible(false);
                billingEndDate.setVisible(false);
                // formContext.getAttribute("niq_billingstartdate").setValue(null);
                // formContext.getAttribute("niq_billingenddate").setValue(null);
            }
        }

    },
    //DYNCRM-21640
    //Billing End Date is not less than Billing start date if quote product type = "ad hoc" and billing frequency = 80/20,50/50,0/100, One Time Billing start and end date is visible

    onChangeBillingDates: function (executionContext) {
        let formContext = executionContext.getFormContext();
        let startDate = formContext.getAttribute("niq_billingstartdate")?.getValue();
        let endDate = formContext.getAttribute("niq_billingenddate")?.getValue();
        let productType = formContext.getAttribute("niq_type")?.getValue();
        if (startDate != null && endDate != null && productType != null && productType === 1 && new Date(startDate) > new Date(endDate)) {
            Xrm.Navigation.openErrorDialog({ message: "Please check the Billing - Start Date & End date. Start date cannot be after End date." });
        }
    },
    //on save of quote product Billing End Date is not less than Billing start date 
    onSaveValidateBillingDates: function (executionContext) {
        let formContext = executionContext.getFormContext();
        let eventArgs = executionContext.getEventArgs();
        let startDate = formContext.getAttribute("niq_billingstartdate")?.getValue();
        let endDate = formContext.getAttribute("niq_billingenddate")?.getValue();
        let quoteProductType = formContext.getAttribute("niq_type")?.getValue();
        let billingFrequencyVal = formContext.getAttribute("niq_billingfrequency")?.getValue();
        //if quote product type = "ad hoc" and billing frequency = 80/20,50/50,0/100, One Time Billing start and end date is visible
        if (quoteProductType == 1 && (billingFrequencyVal === 100000011 || billingFrequencyVal === 100000010 || billingFrequencyVal === 100000012 || billingFrequencyVal === 100000013 || billingFrequencyVal === 100000014)) {
            // if ((startDate == null || endDate == null) || new Date(startDate) > new Date(endDate)) {
            if (startDate != null && endDate != null && new Date(startDate) > new Date(endDate)) {
                Xrm.Navigation.openErrorDialog({ message: "Please check the Billing - Start Date & End date." });
                executionContext.getEventArgs().preventDefault();

            }
            if (startDate == null || endDate == null) {
                Xrm.Navigation.openErrorDialog({ message: "Please enter Billing - Start Date & End date." });
                executionContext.getEventArgs().preventDefault();
            }
        } else {
            formContext.getAttribute("niq_billingstartdate").setValue(null);
            formContext.getAttribute("niq_billingenddate").setValue(null);

        }
    },
    /* validateRevenueAmount: async function (executionContext) {
         var formContext = executionContext.getFormContext();
 
         try {
             var fetchXml = `<fetch>
                             <entity name="quotedetail">
                                 <attribute name="quotedetailid" />
                                 <attribute name="quotedetailname" />
                                 <attribute name="quoteid" />
                                 <attribute name="niq_billingfrequency" />
                                 <attribute name="niq_deliveryfrequency" />
                                 <attribute name="niq_remainingrevenueamount" />
                                 <attribute name="niq_remainingbillingamount" />
                                 <filter>
                                     <condition attribute="quotedetailid" operator="eq" value="${formContext.data.entity.getId().replace("{", "").replace("}", "")}" />
                                 </filter>
                                 <link-entity name="quote" from="quoteid" to="quoteid" alias="parentquote">
                                     <attribute name="name" />
                                     <attribute name="quoteid" />
                                     <attribute name="quotenumber" />
                                     <link-entity name="opportunity" from="opportunityid" to="opportunityid" alias="opportunity">
                                         <attribute name="name" />
                                         <attribute name="niq_stage" />
                                         <attribute name="opportunityid" />
                                         <attribute name="statecode" />
                                     </link-entity>
                                 </link-entity>
                             </entity>
                         </fetch>`;
 
             // Use Xrm.WebApi.retrieveMultipleRecords to retrieve quotedetail
             var results = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", "?fetchXml=" + encodeURIComponent(fetchXml));
 
             if (results.entities.length === 0) {
                 return;
             }
 
             // Get the current stage of the opportunity process (e.g., Pre-Proposal)
             var activeStage = results.entities[0]?.['opportunity.niq_stage'] ?? null;
 
             // Retrieve the opportunity's statecode
             var opportunityStateCode = results.entities[0]?.['opportunity.statecode'];
 
             // Check if the opportunity is Lost (statecode = 2) and exit if true
             if (opportunityStateCode === 2) {
                 return;
             }
 
             // If the stage is Pre-Proposal, check only for remaining revenue amount
             if (activeStage === "Pre-Proposal") {
                 var response = await Xrm.WebApi.retrieveMultipleRecords(
                     "quotedetail",
                     `?$select=niq_remainingrevenueamount,niq_remainingbillingamount,niq_deliveryfrequency&$filter=_quoteid_value eq ${results.entities[0]?.['parentquote.quoteid']}`
                 );
 
                 if (response.entities.length > 0) {
                     var hasError = false;
 
                     response.entities.forEach((product) => {
                         var remainingAmount = product?.niq_remainingrevenueamount;
                         var deliveryFrequency = product?.niq_deliveryfrequency;
 
                         // Handle null or undefined values by treating them as 0 for comparison
                         remainingAmount = remainingAmount ?? 0;
 
                         // Only check if remainingAmount !== 0 and deliveryFrequency is 100000009
                         if (remainingAmount !== 0 && deliveryFrequency === 100000009) {
                             hasError = true;
                         }
                     });
 
                     // If there's an error, show the error message
                     if (hasError) {
                         Xrm.Navigation.openErrorDialog({
                             message: "The remaining amount to schedule is not zero. Please create/delete the schedules for the remaining amount."
                         });
                     }
                 }
                 return; // Exit after checking for Pre-Proposal stage
             }
 
             // Otherwise, check for remainingAmount and remainingBillingAmount in all other stages
             var response = await Xrm.WebApi.retrieveMultipleRecords(
                 "quotedetail",
                 `?$select=niq_remainingrevenueamount,niq_remainingbillingamount,niq_deliveryfrequency,niq_billingfrequency&$filter=_quoteid_value eq ${results.entities[0]?.['parentquote.quoteid']}`
             );
 
             if (response.entities.length > 0) {
                 var hasError = false;
 
                 response.entities.forEach((product) => {
                     var remainingAmount = product?.niq_remainingrevenueamount;
                     var remainingBillingAmount = product?.niq_remainingbillingamount;
                     var deliveryFrequency = product?.niq_deliveryfrequency;
                     var billingFrequency = product?.niq_billingfrequency;
 
                     // Handle null or undefined values by treating them as 0 for comparison
                     remainingAmount = remainingAmount ?? 0;
                     remainingBillingAmount = remainingBillingAmount ?? 0;
 
                     // Check if remainingAmount or remainingBillingAmount is either > 0 or < 0 (i.e., not equal to 0)
                     if ((remainingAmount !== 0 || remainingBillingAmount !== 0) &&
                         (deliveryFrequency === 100000009 || billingFrequency === 100000009)) {
                         hasError = true;
                     }
                 });
 
                 // If there's an error, show the error message
                 if (hasError) {
                     Xrm.Navigation.openErrorDialog({
                         message: "The remaining amount to schedule is not zero. Please create/delete the schedules for the remaining amount."
                     });
                 }
             }
 
         } catch (error) {
             console.error(error);
         }
     },*/


    //DYNCRM 22086
    // on load of quote product Hiding and showing Rev share line lookup field
    hideShowRevShareLine: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        //getting current entity GUID
        var currentQuoteProductId = formContext.data.entity.getId().replace("{", "").replace("}", "");
        //create fetch xml
        var fetch =
            "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' no-lock='false'>" +
            "<entity name='quotedetail'>" +
            "<attribute name='quotedetailname'/>" +
            "<filter type='and'>" +
            "<condition attribute='quoteid' operator='not-null'/>" +
            "<condition attribute='niq_revshareline' operator='not-null'/>" +
            "<condition attribute='quotedetailid' operator='eq' value='" + currentQuoteProductId + "'/>" +
            "</filter>" +
            "<link-entity name='quote' from='quoteid' to='quoteid' link-type='inner' alias='a_fd34491736d4474ea64d840a1458c50d'>" +
            "<attribute name='opportunityid'/>" +
            "<link-entity name='opportunity' alias='af' link-type='inner' from='opportunityid' to='opportunityid'>" +
            "<filter type='and'>" +
            "<condition attribute='niq_hostopportunity' operator='not-null'/>" +
            "</filter>" +
            "<link-entity name='opportunity' alias='ag' link-type='inner' from='opportunityid' to='niq_hostopportunity'>" +
            "<filter type='and'>" +
            "<condition attribute='niq_revenuesharedeal' operator='eq' value='1'/>" +
            "</filter>" +
            "</link-entity>" +
            "</link-entity>" +
            "</link-entity>" +
            "</entity>" +
            "</fetch>"
        var results = await Xrm.WebApi.retrieveMultipleRecords("quotedetail", "?fetchXml=" + encodeURIComponent(fetch));
        if (results.entities.length > 0) {
            //Showing the field when conditions met
            var revShareLine = formContext.getControl("niq_revshareline");
            revShareLine.setVisible(true);
        }
        else {
            //hiding the field as conditions are not met
            var revShareLine = formContext.getControl("niq_revshareline");
            revShareLine.setVisible(false);
        }
    },

    LoadSidePane4REVSHAR: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var isAdminUserflag = CommonForm.Events.CheckIfLoggedInUserRoles("System Administrator, NIQ Business Admin");
        var childOpportunityID = formContext.getAttribute("niq_correspondingchildopportunity").getValue();

        if (childOpportunityID !== null && childOpportunityID !== "") {

            if (!isAdminUserflag) // for users other than Admins
            {
                // Get all attributes and make them read-only except Billing Freq
                var attributes = formContext.data.entity.attributes.get();
                for (var i in attributes) {
                    var attribute = attributes[i];
                    //if (attribute['_attributeName'] != null && (attribute['_attributeName'] !== "niq_billingfrequency" || attribute['_attributeName'] !== "niq_billingschedulecopies")) {

                    //IC-POC #24193_B

                    // start date and end date added ....

                    if (attribute['_attributeName'] != null) {
                        attribute.controls.forEach(function (control) {
                            if (attribute['_attributeName'] === "niq_billingfrequency" || attribute['_attributeName'] === "niq_billingschedulecopies" || attribute['_attributeName'] === "niq_billingstartdate" || attribute['_attributeName'] === "niq_billingenddate") {
                                control.setDisabled(false); // Enable these fields
                            } else {
                                control.setDisabled(true); // Disable other fields
                            }
                        });
                    }

                    //IC-POC #24193_E
                }
            }
            else // for admins
            {
                // Get all attributes and make them editable ( billing Freq, Start & End Date )
                var attributes = formContext.data.entity.attributes.get();
                for (var i in attributes) {
                    var attribute = attributes[i];

                    //IC-POC #24193_B

                    // start date and end date added ....
                    if (attribute['_attributeName'] != null && (attribute['_attributeName'] === "niq_billingfrequency" || attribute['_attributeName'] === "niq_lineitemstartdate" || attribute['_attributeName'] === "niq_lineitemenddate" || attribute['_attributeName'] === "niq_billingschedulecopies" || attribute['_attributeName'] === "niq_billingstartdate" || attribute['_attributeName'] === "niq_billingenddate")) {
                        attribute.controls.forEach(function (control) {
                            control.setDisabled(false); // Enable the control
                        });
                    }
                    else {
                        attribute.controls.forEach(function (control) {
                            control.setDisabled(true); // Disable the control
                        });
                    }

                    //IC-POC #24193_E

                }

            }
        }
    },
}