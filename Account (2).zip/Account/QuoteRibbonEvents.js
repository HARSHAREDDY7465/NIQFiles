if (typeof (QuoteProductRibbon) === "undefined") {
    QuoteProductRibbon = {
        __namespace: true
    };
}
var paneRecordId = null;
QuoteProductRibbon.Events = {
    DeleteButtonVisibilityOnQuoteProduct: function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Business Admin,System Administrator,System Customizer")) {
            return true;
        } else {
            return false;
        }
    },
    //This function update bulk start date in quote product subgrid in quote entity
    numberOfSatrtDateUpdate: async function (selectedControl, primaryControl) {
        var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
        if (roles === null) return false;
        var hasRole = false;
        roles.forEach(function (item) {
            //here we can also use item.id to compare role id
            if (item.name == "NIQ Sales User" || item.name == "System Administrator") {
                hasRole = true;
            }
        });
        if (hasRole == true) {
            try {
                Xrm.Utility.showProgressIndicator("Processing..");
                // await delay(1000);
                setTimeout(function () {
                    //debugger;
                    var selectedRows = selectedControl.getGrid().getSelectedRows();
                    var formContext = primaryControl;
                    //var subgridName = selectedControl._controlName;
                    if (selectedRows.getLength() === 0) {
                        Xrm.Navigation.openAlertDialog({ text: "Please select at least one record to Update Start Date." });
                        Xrm.Utility.closeProgressIndicator();
                        return;
                    }
                    try {
                        var firstDayOfMonth = null;
                        var lastDayOfMonth = null;
                        var numberOfMonth = formContext.getAttribute("niq_movestartdate").getValue();
                        numberOfMonth = Number(numberOfMonth);
                        if (numberOfMonth != null && numberOfMonth >= -12 && numberOfMonth <= 36 && numberOfMonth != 0 && Number.isInteger(numberOfMonth)) {
                            selectedRows.forEach(function (row) {
                                //debugger;
                                var entity = row.getData().getEntity();
                                var entityName = row.getData().getEntity().getEntityName();
                                var entityId = row.getData().getEntity().getId().replace('{', '').replace('}', '');
                                console.log(row.data.entity.attributes._collection);
                                var attributes = row.data.entity.attributes._collection;
                                var currentDateTime = new Date();
                                currentDateTime = currentDateTime.getDate() + "/" + (currentDateTime.getMonth() + 1) + "/" + currentDateTime.getFullYear() + " " + currentDateTime.getHours() + ":" + currentDateTime.getMinutes() + ":" + currentDateTime.getSeconds();
                                var startDate = attributes.niq_lineitemstartdate.getValue();
                                var endDate = attributes.niq_lineitemenddate.getValue();
                                var reveneueFrequency = attributes.niq_deliveryfrequency.getValue();
                                var billingFrequency = attributes.niq_billingfrequency.getValue();
                                var type = attributes.niq_type.getValue();
                                startDate = new Date(startDate);
                                endDate = new Date(endDate);
                                //Get termlength
                                var termLength = attributes.niq_termlength.getValue();
                                startDate.setMonth(startDate.getMonth() + numberOfMonth);

                                if (type === 2) // Periodic
                                {
                                    if (attributes.niq_lineitemstartdate) {
                                        attributes.niq_lineitemstartdate.setValue(new Date(startDate));
                                        if (termLength == null || termLength == 0) {
                                            attributes.niq_lineitemenddate.setValue(new Date(startDate));
                                            attributes.niq_isbillingmodified.setValue(currentDateTime);
                                            attributes.niq_isrevenuemodified.setValue(currentDateTime);
                                        } else {
                                            var endDateNew = new Date(startDate.setMonth(startDate.getMonth() + termLength));
                                            endDateNew = endDateNew.setDate(endDateNew.getDate() - 1);
                                            attributes.niq_lineitemenddate.setValue(new Date(endDateNew));
                                            attributes.niq_isbillingmodified.setValue(currentDateTime);
                                            attributes.niq_isrevenuemodified.setValue(currentDateTime);
                                        }
                                    }

                                } else {
                                    // Calculate end date, it should be
                                    if (attributes.niq_lineitemstartdate) {

                                        let startDatediff = new Date(attributes.niq_lineitemstartdate.getValue());
                                        const startDateddiffCompare = new Date(attributes.niq_lineitemstartdate.getValue());
                                        let endDatediff = new Date(attributes.niq_lineitemenddate.getValue());

                                        // Calculate the difference in days
                                        let dateDiff = (endDatediff - startDatediff) / (1000 * 60 * 60 * 24);

                                        // Add one month to the start date
                                        startDatediff.setMonth(startDatediff.getMonth() + numberOfMonth);

                                        // Set the new end date by adding the same day difference
                                        let newEndDate = new Date(startDatediff.getTime() + dateDiff * (1000 * 60 * 60 * 24));

                                        attributes.niq_lineitemstartdate.setValue(new Date(startDatediff));
                                        attributes.niq_lineitemenddate.setValue(new Date(newEndDate));
                                        //Start date is 1st day of month or not
                                        firstDayOfMonth = QuoteProductRibbon.Events.IsFirstDayOfMonth(startDatediff);
                                        //End date is last day of month or not
                                        lastDayOfMonth = QuoteProductRibbon.Events.IsLastDayOfMonth(newEndDate);
                                        //If Start date is 1st day of month or end date is last day of month set term length
                                        if (firstDayOfMonth && lastDayOfMonth) {
                                            let diffInMonths = QuoteProductForm.Events.MonthsDifference(startDatediff, newEndDate);
                                            attributes.niq_termlength.setValue(diffInMonths + 1);
                                        } else {
                                            attributes.niq_termlength.setValue(0);
                                        }
                                        //US DYNCRM-21743 4th AC
                                        //Billing Frequency eq 50/50,80/20,0/100/one time then bulk update date on Billing Start/End Date
                                        if (billingFrequency != null && (billingFrequency === 100000011 || billingFrequency === 100000010 || billingFrequency === 100000012 || billingFrequency === 100000013)) {
                                            if (attributes.niq_billingstartdate) {
                                                let billingStartDate = new Date(attributes.niq_billingstartdate.getValue());
                                                if (billingStartDate.getTime() === startDateddiffCompare.getTime()) {
                                                    attributes.niq_billingstartdate.setValue(new Date(startDatediff));
                                                    attributes.niq_billingenddate.setValue(new Date(newEndDate));
                                                }

                                            }
                                        }

                                        if (reveneueFrequency != 100000009 && reveneueFrequency != null) {
                                            attributes.niq_isrevenuemodified.setValue(currentDateTime);
                                        }
                                        if (billingFrequency != 100000009 && billingFrequency != null) {
                                            attributes.niq_isbillingmodified.setValue(currentDateTime);

                                        }
                                    }
                                }
                                entity.save();
                                if (reveneueFrequency = 100000009) {
                                    QuoteProductRibbon.Events.updateRevenueScheduleDates(numberOfMonth, entityId);
                                }
                                if (billingFrequency = 100000009) {
                                    QuoteProductRibbon.Events.updateBillingScheduleDates(numberOfMonth, entityId);
                                }
                                //entity.refresh();
                            });
                            formContext.getAttribute("niq_movestartdate").setValue(null);
                            formContext.data.save();
                            Xrm.Utility.closeProgressIndicator();
                            var quoteProductSubGrid = formContext.getControl("QuoteProduct");
                            quoteProductSubGrid.refresh();
                        } else {
                            Xrm.Navigation.openAlertDialog({ text: "Please add number of month between -12 to 36" });
                            Xrm.Utility.closeProgressIndicator();
                        }
                    } catch (err) {
                        Xrm.Utility.closeProgressIndicator();
                    }
                }, 1000);
            } catch (err) {
                Xrm.Utility.closeProgressIndicator();
            }
        }
    },
    //Above function for main grid to open popup
    openPopupAndUpdateRecords: async function (selectedControl, primaryControl) {
        var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
        if (roles === null) return false;
        var hasRole = false;
        roles.forEach(function (item) {
            //here we can also use item.id to compare role id
            if (item.name == "NIQ Sales User" || item.name == "System Administrator") {
                hasRole = true;
            }
        });
        if (hasRole == true) {
            //debugger;
            var selectedRows = selectedControl.getGrid().getSelectedRows();
            var formContext = primaryControl;
            if (selectedRows.getLength() === 0) {
                Xrm.Navigation.openAlertDialog({ text: "Please select at least one record to Update Start Date." });
                Xrm.Utility.closeProgressIndicator();
                return;
            }
            var dialogParameters = {
                pageType: "webresource",
                webresourceName: "niq_BulkUpdateStartDateHtml", // the name of your HTML web resource
                data: null
            };
            var navigationOptions = {
                target: 2,
                width: 400,
                height: 300,
                position: 1,
                title: "Bulk Records Update"
            };
            Xrm.Navigation.navigateTo(dialogParameters, navigationOptions).then(
                function success(returnValue) {
                    console.log(returnValue);
                    if (returnValue && returnValue.returnValue.addMonths) {
                        QuoteProductRibbon.Events.updateBulkStartdate(selectedControl, selectedRows, parseInt(returnValue.returnValue.addMonths));
                    }
                },
                function error(error) {
                    console.error(error.message);
                }
            );
        }
    },
    //Update record from the main grid
    updateBulkStartdate: async function (selectedControl, selectedRows, addMonthCount) {
        //debugger;
        try {
            Xrm.Utility.showProgressIndicator("Processing..");
            //await delay(1000);
            setTimeout(function () {
                //debugger;
                //var selectedRows = selectedControl.getGrid().getSelectedRows();
                //var subgridName = selectedControl._controlName;
                if (selectedRows.getLength() === 0) {
                    Xrm.Navigation.openAlertDialog({ text: "Please select at least one record to Update Start Date." });
                    Xrm.Utility.closeProgressIndicator();
                    return;
                }
                try {
                    var firstDayOfMonth = null;
                    var lastDayOfMonth = null;
                    var numberOfMonth = addMonthCount;
                    if (numberOfMonth != null && numberOfMonth >= -12 && numberOfMonth <= 36 && numberOfMonth != 0) {
                        selectedRows.forEach(function (row) {
                            //debugger;
                            var entity = row.getData().getEntity();
                            var entityName = row.getData().getEntity().getEntityName();
                            var entityId = row.getData().getEntity().getId().replace('{', '').replace('}', '');
                            //console.log(row.data.entity.attributes._collection);
                            var attributes = row.data.entity.attributes._collection;
                            var currentDateTime = new Date();
                            currentDateTime = currentDateTime.getDate() + "/" + (currentDateTime.getMonth() + 1) + "/" + currentDateTime.getFullYear() + " " + currentDateTime.getHours() + ":" + currentDateTime.getMinutes() + ":" + currentDateTime.getSeconds();
                            var startDate = attributes.niq_lineitemstartdate.getValue();
                            var endDate = attributes.niq_lineitemenddate.getValue();
                            var type = attributes.niq_type.getValue();
                            var reveneueFrequency = attributes.niq_deliveryfrequency.getValue();
                            var billingFrequency = attributes.niq_billingfrequency.getValue();
                            startDate = new Date(startDate);
                            endDate = new Date(endDate);
                            //Get termlength
                            var termLength = attributes.niq_termlength.getValue();
                            startDate.setMonth(startDate.getMonth() + numberOfMonth);

                            if (type === 2) // Periodic
                            {
                                if (attributes.niq_lineitemstartdate) {
                                    attributes.niq_lineitemstartdate.setValue(new Date(startDate));
                                    if (termLength == null || termLength == 0) {
                                        attributes.niq_lineitemenddate.setValue(new Date(startDate));
                                        attributes.niq_isbillingmodified.setValue(currentDateTime);
                                        attributes.niq_isrevenuemodified.setValue(currentDateTime);
                                    } else {
                                        var endDateNew = new Date(startDate.setMonth(startDate.getMonth() + termLength));
                                        endDateNew = endDateNew.setDate(endDateNew.getDate() - 1);
                                        attributes.niq_lineitemenddate.setValue(new Date(endDateNew));
                                        attributes.niq_isbillingmodified.setValue(currentDateTime);
                                        attributes.niq_isrevenuemodified.setValue(currentDateTime);
                                    }
                                }
                            } else {
                                // Calculate end date, it should be
                                if (attributes.niq_lineitemstartdate) {

                                    let startDatediff = new Date(attributes.niq_lineitemstartdate.getValue());
                                    const startDateddiffCompare = new Date(attributes.niq_lineitemstartdate.getValue());
                                    let endDatediff = new Date(attributes.niq_lineitemenddate.getValue());

                                    // Calculate the difference in days
                                    let dateDiff = (endDatediff - startDatediff) / (1000 * 60 * 60 * 24);

                                    // Add one month to the start date
                                    startDatediff.setMonth(startDatediff.getMonth() + numberOfMonth);

                                    // Set the new end date by adding the same day difference
                                    let newEndDate = new Date(startDatediff.getTime() + dateDiff * (1000 * 60 * 60 * 24));

                                    attributes.niq_lineitemstartdate.setValue(new Date(startDatediff));
                                    attributes.niq_lineitemenddate.setValue(new Date(newEndDate));
                                    //Start date is 1st day of month or not
                                    firstDayOfMonth = QuoteProductRibbon.Events.IsFirstDayOfMonth(startDatediff);
                                    //End date is last day of month or not
                                    lastDayOfMonth = QuoteProductRibbon.Events.IsLastDayOfMonth(newEndDate);
                                    //If Start date is 1st day of month or end date is last day of month set term length
                                    if (firstDayOfMonth && lastDayOfMonth) {
                                        let diffInMonths = QuoteProductForm.Events.MonthsDifference(startDatediff, newEndDate);
                                        attributes.niq_termlength.setValue(diffInMonths + 1);
                                    } else {
                                        attributes.niq_termlength.setValue(0);
                                    }

                                    //US DYNCRM-21743 4th AC
                                    //Billing Frequency eq 50/50,80/20,0/100/one time then bulk update date on Billing Start/End Date
                                    if (billingFrequency != null && (billingFrequency === 100000011 || billingFrequency === 100000010 || billingFrequency === 100000012 || billingFrequency === 100000013)) {
                                        if (attributes.niq_billingstartdate) {
                                            let billingStartDate = new Date(attributes.niq_billingstartdate.getValue());
                                            if (billingStartDate.getTime() === startDateddiffCompare.getTime()) {
                                                attributes.niq_billingstartdate.setValue(new Date(startDatediff));
                                                attributes.niq_billingenddate.setValue(new Date(newEndDate));
                                            }
                                        }
                                    }

                                    if (reveneueFrequency != 100000009 && reveneueFrequency != null) {
                                        attributes.niq_isrevenuemodified.setValue(currentDateTime);
                                    }
                                    if (billingFrequency != 100000009 && billingFrequency != null) {
                                        attributes.niq_isbillingmodified.setValue(currentDateTime);
                                    }
                                }
                                //  }
                            }
                            entity.save();
                            if (reveneueFrequency = 100000009) {
                                QuoteProductRibbon.Events.updateRevenueScheduleDates(numberOfMonth, entityId);
                            }
                            if (billingFrequency = 100000009) {
                                QuoteProductRibbon.Events.updateBillingScheduleDates(numberOfMonth, entityId);
                            }
                        });
                        selectedControl.refresh();
                        Xrm.Utility.closeProgressIndicator();
                    } else {
                        Xrm.Navigation.openAlertDialog({ text: "Please add number of month between -12 to 36." });
                        Xrm.Utility.closeProgressIndicator();
                    }
                } catch (err) {
                    Xrm.Utility.closeProgressIndicator();
                }
            }, 1000);
        } catch (err) {
            Xrm.Utility.closeProgressIndicator();
        }
    },
    //Hide Bulk Update in View(Bulk update Show only on My Main Quotes Product Lines)
    hideBulkUpdateButton: async function (selectedControl, primaryControl) {
        var formContext = primaryControl;
        var arrProductType = [];
        var currentViewId = formContext._getCurrentView()["id"].replace("{", "").replace("}", "");
        var currentViewName = selectedControl._viewSelector.getCurrentView()["name"];
        var selectedRows = selectedControl.getGrid().getSelectedRows();
        selectedRows.forEach(function (row) {
            var attributes = row.data.entity.attributes._collection;
            var type = attributes.niq_type.getValue();
            arrProductType.push(type);
        });
        //In the arrProductType all values are same or not
        const allEqual = arrProductType => arrProductType.every(v => v === arrProductType[0]);
        var productSameTrueFalse = allEqual(arrProductType);
        //change condition on view name currentViewName == "My Main Quotes Product lines"
        if (currentViewName == "My Main Quotes Product Lines" && productSameTrueFalse == true) {
            return true;
        } else {
            return false;
        }
    },
    //Hide show update bulk frequency button 
    hideBulkFrequencyButton: function (primaryControl) {
        //debugger;
        var formContext = primaryControl;
        var formId = formContext.ui.formSelector.getCurrentItem().getId();
        var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
        if (roles === null) return false;
        var hasRole = false;
        roles.forEach(function (item) {
            //here we can also use item.id to compare role id
            if (item.name == "NIQ Sales User" || item.name == "NIQ Finance User" || item.name == "System Administrator") {
                hasRole = true;
            }
        });
        //Show Bulk Update frequency in Quote Product Side Pane form
        if (formId == "6ca9a69c-913b-ef11-8409-000d3aaa24ff" && hasRole == true) {
            return true;
        } else {
            return false;
        }
    },
    //Array values are same or not
    arrValuesSame: async function (arrValues) {
        var arrValueEqual = arrValues => arrValues.every(v => v === arrValues[0]);
        return arrValueEqual(arrValues);
    },
    delay: function (ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    },
    // bulk update frequency button in quote product subrid in quote
    bulkUpdateFrequency: async function (primaryControl) {
        try {
            //debugger;
            var arrType = [];
            var arrIsTimeBased = [];
            var arrTermLength = [];
            var arrOnPlatFormDelivery = [];
            var arrProductName = [];
            var formContext = primaryControl;
            var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
            if (roles === null) return false;
            var hasRole = false;
            roles.forEach(function (item) {
                //here we can also use item.id to compare role id
                if (item.name == "NIQ Sales User" || item.name == "NIQ Finance User" || item.name == "System Administrator") {
                    hasRole = true;
                }
            });
            if (hasRole == true) {
                var parentContext = window.parent.getCurrentXrm()._page._data._formContext;
                if (parentContext.getControl("QuoteProduct") != null) {
                    Xrm.Utility.showProgressIndicator("Processing..");
                    await delay(1000);
                    //setTimeout(async function () {
                    var selectedRows = parentContext.getControl("QuoteProduct").getGrid().getSelectedRows();
                    var quoteProductSubgrid = parentContext.getControl("QuoteProduct");
                    var currentGuid = formContext.data.entity.getId();
                    if (selectedRows.getLength() <= 1) {
                        Xrm.Navigation.openAlertDialog({ text: "Please select more than one record to Update Frequencies." });
                        Xrm.Utility.closeProgressIndicator();
                        return;
                    }
                    if (selectedRows.getLength() >= 51) {
                        Xrm.Navigation.openAlertDialog({ text: "Please select less than 50 records to Update Frequencies." });
                        Xrm.Utility.closeProgressIndicator();
                        return;
                    }
                    //if (selectedRows.getLength() > 1) {
                    selectedRows.forEach(function (selectedRow) {
                        var attributes = selectedRow.data.entity.attributes._collection;
                        var type = attributes.niq_type.getValue();
                        arrType.push(type);
                        var isTimeBase = attributes.niq_istimebased.getValue();
                        arrIsTimeBased.push(isTimeBase);
                        var onDelivery = attributes.niq_onplatformdelivery.getValue();
                        arrOnPlatFormDelivery.push(onDelivery);
                        //Get termLength and push into arrTermLength
                        var termLength = attributes.niq_termlength.getValue();
                        arrTermLength.push(termLength);
                        var productName = attributes.productname.getValue();
                        arrProductName.push(productName);
                        //console.log("Type: " + type);
                    });
                    //In the arrProductType all values are same or not
                    var productSameTrueFalse = await this.arrValuesSame(arrType);
                    //arrIsTimeBased all values are same or not
                    var isTimeBasedSame = await this.arrValuesSame(arrIsTimeBased);
                    //arrTermLength all values are same or not
                    var termLengthSame = await this.arrValuesSame(arrTermLength);
                    //arrOnPlatFormDelivery all values are same or not
                    var OnPlatFormDeliverySame = await this.arrValuesSame(arrOnPlatFormDelivery);

                    //If selected all products are "SAP Deferred Revenue reconciliation placeholder" OR "Place Holder Product" then give error message
                    var SAPOrPlaceHolderProduct = arrProductName.every(value =>
                        value === "SAP Deferred Revenue reconciliation placeholder" ||
                        value === "Place Holder Product"
                    );
                    if (SAPOrPlaceHolderProduct === true) {
                        Xrm.Navigation.openAlertDialog({ text: "You have selected all the same SAP Deffered OR Place holder product." });
                        Xrm.Utility.closeProgressIndicator();
                        return;
                    }
                    if (selectedRows.getLength() > 1 && productSameTrueFalse == true && isTimeBasedSame == true && termLengthSame == true && OnPlatFormDeliverySame == true) {
                        var updateFrequency = formContext.getAttribute("niq_updatefrequency").getValue();
                        var revenueFrequency = formContext.getAttribute("niq_deliveryfrequency").getValue();
                        var billingFrequency = formContext.getAttribute("niq_billingfrequency").getValue();
                        var lagRevenueRecognize = formContext.getAttribute("niq_lagrevenuerecognition").getValue();
                        //var rateCardUpdateFrequency = formContext.getAttribute("niq_ratecardupdatefrequency").getValue();
                        selectedRows.forEach(async function (selectedRow) {
                            var rowId = selectedRow.getData().getEntity().getId();
                            if (rowId != currentGuid) {
                                var parentEntity = selectedRow.getData().getEntity();
                                var attributes = selectedRow.data.entity.attributes._collection;
                                var termLength = attributes.niq_termlength.getValue();
                                var rateCardUpdateFrequency = attributes.niq_ratecardupdatefrequency.getValue();
                                var productName = attributes.productname.getValue();
                                if (rateCardUpdateFrequency == null && updateFrequency != null && (productName !== "Place Holder Product" && productName !== "SAP Deferred Revenue reconciliation placeholder" && !productName.includes('Intra POC Rev Share') && !productName.includes('Intercompany Revenue Share'))) {
                                    attributes.niq_updatefrequency.setValue(updateFrequency);
                                }
                                if (rateCardUpdateFrequency == null && revenueFrequency != null && (productName !== "Place Holder Product" && productName !== "SAP Deferred Revenue reconciliation placeholder" && !productName.includes('Intra POC Rev Share') && !productName.includes('Intercompany Revenue Share'))) {
                                    attributes.niq_deliveryfrequency.setValue(revenueFrequency);
                                }
                                if (billingFrequency != null && (productName !== "Place Holder Product" && productName !== "SAP Deferred Revenue reconciliation placeholder")) {
                                    attributes.niq_billingfrequency.setValue(billingFrequency);
                                }
                                if (lagRevenueRecognize != null && (productName !== "Place Holder Product" && productName !== "SAP Deferred Revenue reconciliation placeholder" && !productName.includes('Intra POC Rev Share') && !productName.includes('Intercompany Revenue Share'))) {
                                    attributes.niq_lagrevenuerecognition.setValue(lagRevenueRecognize);
                                }
                                parentEntity.save();
                            }
                        });
                        quoteProductSubgrid.refresh();
                        Xrm.Utility.closeProgressIndicator();
                    } else {
                        Xrm.Navigation.openAlertDialog({ text: "This action cannot be performed because you have selected products that do not have the same options available. Please, change your selection and try again." });
                        Xrm.Utility.closeProgressIndicator();
                    }
                    Xrm.Utility.closeProgressIndicator();
                    //}, 1000);
                    //}
                } else {
                    //console.error("Subgrid control is not found.");
                    Xrm.Utility.closeProgressIndicator();
                }
            }
        } catch (err) {
            Xrm.Utility.closeProgressIndicator();
            alert("This functionality is not working on main grid.");
        }
    },
    //Open Side Pane form when record select on main grid("My Main Quotes Product Lines")
    openSidePaneForm: async function (executionContext) {
        const paneId = "QuoteProductSidePane";
        const formContext = executionContext.getFormContext();

        const entityName = formContext.data.entity.getEntityName();

        //Now below field are lock - Defect 22152 
        const fieldsToDisable = ['niq_billingfrequency', 'producttypecode', 'niq_istimebased', 'niq_termlength',
            'niq_lineitemstartdate', 'niq_lineitemenddate', 'niq_updatefrequency',
            'niq_lagrevenuerecognition', 'niq_basesstudynumber', 'manualdiscountamount', 'niq_ratecardupdatefrequency',
            'niq_projectid', 'niq_deliveryfrequency', 'niq_glaccountid', 'niq_type', 'extendedamount', 'productname', 'niq_billingstartdate', 'niq_billingenddate', 'niq_billingschedulestatus', 'niq_revenueschedulestatus'];

        formContext.getData().getEntity().attributes.forEach(function (attr) {
            if (fieldsToDisable.includes(attr.getName())) {
                attr.controls.forEach(function (myField) {
                    myField.setDisabled(true);
                });
            }
        });

        paneRecordId = formContext.data.entity.getId();
        if (paneRecordId == null) {
            return;
        }
        const pane = Xrm.App.sidePanes.getPane(paneId) ?? await Xrm.App.sidePanes.createPane({
            paneId: paneId,
            canClose: true
        });
        pane.width = 600;  //you can decide what's the width of the side pane.
        //you could change the width for each record, in case you want to
        pane.navigate({
            pageType: "entityrecord",
            entityName: entityName,
            entityId: paneRecordId,
            formId: "6ca9a69c-913b-ef11-8409-000d3aaa24ff"
        });
    },
    //Hide Bulk Update Frequency button in main grid("My Main Quotes Product Lines")
    hideBulkFrequencyButtonMainGrid: async function (selectedControl, primaryControl) {
        var formContext = primaryControl;
        var arrType = [];
        var arrOnPlatFormDelivery = [];
        var arrIsTimeBased = [];
        var arrTermLength = [];
        var currentViewId = formContext._getCurrentView()["id"].replace("{", "").replace("}", "");
        var currentViewName = selectedControl._viewSelector.getCurrentView()["name"];
        var selectedRows = selectedControl.getGrid().getSelectedRows();
        var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
        if (roles === null) return false;
        var hasRole = false;
        roles.forEach(function (item) {
            //here we can also use item.id to compare role id
            if (item.name == "NIQ Sales User" || item.name == "NIQ Finance User" || item.name == "System Administrator") {
                hasRole = true;
            }
        });
        selectedRows.forEach(function (row) {
            var attributes = row.data.entity.attributes._collection;
            var type = attributes.niq_type.getValue();
            arrType.push(type);
            var isTimeBase = attributes.niq_istimebased.getValue();
            arrIsTimeBased.push(isTimeBase);
            var onDelivery = attributes.niq_onplatformdelivery.getValue();
            arrOnPlatFormDelivery.push(onDelivery);
            //Get termLength and push into arrTermLength
            var termLength = attributes.niq_termlength.getValue();
            arrTermLength.push(termLength);
        });
        //In the arrProductType all values are same or not
        var productSameTrueFalse = await this.arrValuesSame(arrType);
        //arrIsTimeBased all values are same or not
        var isTimeBasedSame = await this.arrValuesSame(arrIsTimeBased);
        //arrTermLength all values are same or not
        var termLengthSame = await this.arrValuesSame(arrTermLength);
        //arrOnPlatFormDelivery all values are same or not
        var OnPlatFormDeliverySame = await this.arrValuesSame(arrOnPlatFormDelivery);
        if (hasRole == true && selectedRows.getLength() > 1 && productSameTrueFalse == true && isTimeBasedSame == true && termLengthSame == true && OnPlatFormDeliverySame == true && currentViewName == "My Main Quotes Product Lines") {
            return true;
        } else {
            return false;
        }
    },
    //Bulk update frequencies from the main grid view quote product
    bulkUpdateFrequencyMainGrid: async function (selectedControl, primaryControl) {
        try {
            var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
            if (roles === null) return false;
            var hasRole = false;
            roles.forEach(function (item) {
                //here we can also use item.id to compare role id
                if (item.name == "NIQ Sales User" || item.name == "NIQ Finance User" || item.name == "System Administrator") {
                    hasRole = true;
                }
            });
            if (hasRole == true) {
                var arrType = [];
                var arrOnPlatFormDelivery = [];
                var arrIsTimeBased = [];
                var arrTermLength = [];
                var arrProductName = [];
                if (paneRecordId == null || paneRecordId == "") {
                    Xrm.Utility.closeProgressIndicator();
                    return;
                }
                Xrm.Utility.showProgressIndicator("Processing..");
                await delay(1000);
                var selectedRows = selectedControl.getGrid().getSelectedRows();
                if (selectedRows.getLength() <= 1) {
                    Xrm.Navigation.openAlertDialog({ text: "Please select more than one record to Update Frequencies." });
                    Xrm.Utility.closeProgressIndicator();
                    return;
                }

                selectedRows.forEach(function (row) {
                    var attributes = row.data.entity.attributes._collection;
                    var type = attributes.niq_type.getValue();
                    arrType.push(type);
                    var isTimeBase = attributes.niq_istimebased.getValue();
                    arrIsTimeBased.push(isTimeBase);
                    var onDelivery = attributes.niq_onplatformdelivery.getValue();
                    arrOnPlatFormDelivery.push(onDelivery);
                    //Get termLength and push into arrTermLength
                    var termLength = attributes.niq_termlength.getValue();
                    arrTermLength.push(termLength);
                    var productName = attributes.productname.getValue();
                    arrProductName.push(productName);
                });
                //In the arrProductType all values are same or not
                var productSameTrueFalse = await this.arrValuesSame(arrType)
                //arrIsTimeBased all values are same or not
                var isTimeBasedSame = await this.arrValuesSame(arrIsTimeBased);
                //arrTermLength all values are same or not
                var termLengthSame = await this.arrValuesSame(arrTermLength);
                //arrOnPlatFormDelivery all values are same or not
                var OnPlatFormDeliverySame = await this.arrValuesSame(arrOnPlatFormDelivery);
                //If selected all products are "SAP Deferred Revenue reconciliation placeholder" OR "Place Holder Product" then give error message
                var SAPOrPlaceHolderProduct = arrProductName.every(value =>
                    value === "SAP Deferred Revenue reconciliation placeholder" ||
                    value === "Place Holder Product"
                );
                if (SAPOrPlaceHolderProduct === true) {
                    Xrm.Navigation.openAlertDialog({ text: "You have selected all the same SAP Deffered OR Place holder product." });
                    Xrm.Utility.closeProgressIndicator();
                    return;
                }
                if (selectedRows.getLength() > 1 && productSameTrueFalse == true && isTimeBasedSame == true && termLengthSame == true && OnPlatFormDeliverySame == true) {
                    var result = await Xrm.WebApi.retrieveRecord("quotedetail", paneRecordId.replace("{", "").replace("}", ""), "?$select=niq_billingfrequency,niq_ratecardupdatefrequency,niq_lagrevenuerecognition,niq_deliveryfrequency,niq_updatefrequency");
                    var updateFrequency = result["niq_updatefrequency"];
                    var revenueFrequency = result["niq_deliveryfrequency"];
                    var billingFrequency = result["niq_billingfrequency"];
                    var lagRevenueRecognize = result["niq_lagrevenuerecognition"];
                    //var rateCardUpdateFrequency = result["niq_ratecardupdatefrequency"];
                    selectedRows.forEach(async function (selectedRow) {
                        var rowId = selectedRow.getData().getEntity().getId();
                        if (rowId != paneRecordId.replace("{", "").replace("}", "")) {
                            var parentEntity = selectedRow.getData().getEntity();
                            var attributes = selectedRow.data.entity.attributes._collection;
                            var termLength = attributes.niq_termlength.getValue();
                            var rateCardUpdateFrequency = attributes.niq_ratecardupdatefrequency.getValue();
                            var productName = attributes.productname.getValue();

                            if (updateFrequency != null && rateCardUpdateFrequency == null && (productName !== "Place Holder Product" && productName !== "SAP Deferred Revenue reconciliation placeholder")) {
                                attributes.niq_updatefrequency.setValue(updateFrequency);
                            }

                            if (revenueFrequency != null && rateCardUpdateFrequency == null && (productName !== "Place Holder Product" && productName !== "SAP Deferred Revenue reconciliation placeholder")) {
                                attributes.niq_deliveryfrequency.setValue(revenueFrequency);
                            }

                            if (billingFrequency != null && (productName !== "Place Holder Product" && productName !== "SAP Deferred Revenue reconciliation placeholder")) {
                                attributes.niq_billingfrequency.setValue(billingFrequency);
                            }
                            if (lagRevenueRecognize != null && (productName !== "Place Holder Product" && productName !== "SAP Deferred Revenue reconciliation placeholder")) {
                                attributes.niq_lagrevenuerecognition.setValue(lagRevenueRecognize);
                            }
                            parentEntity.save();
                            parentEntity.refresh();
                        }
                    });
                    //selectedControl.getGrid().refresh();
                    Xrm.Utility.closeProgressIndicator();
                } else {
                    Xrm.Navigation.openAlertDialog({ text: "This action cannot be performed because you have selected products that do not have the same options available. Please, change your selection and try again." });
                    Xrm.Utility.closeProgressIndicator();
                }
            }
        } catch (err) {
            Xrm.Utility.closeProgressIndicator();
        }
    },
    /**
     * updateRevenueScheduleDates() updates the schedule date of the custom billing and revenue schedules.
     * The date is updated by adding the specified number of months.
     *
     * @param {number} addMonthCount - The number of months to add to the niq_scheduledate attribute.
     * @param {string} lineItemId - The GUID of the niq_lineitemid to filter the records.
     */
    updateRevenueScheduleDates: function (addMonthCount, lineItemId) {
        var fetchXml = `
        <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
          <entity name='niq_schedule'>
            <attribute name='niq_scheduleid' />
            <attribute name='niq_scheduletype' />
            <attribute name='niq_scheduledate' />
            <attribute name='niq_lineitemid' />
            <attribute name='niq_iscustomschedule' />
            <attribute name='niq_name' />
            <order attribute='niq_name' descending='false' />
            <filter type='and'>
              <condition attribute="niq_scheduletype" operator="eq" value="100000001" />
              <condition attribute='niq_iscustomschedule' operator='eq' value='1' />
              <condition attribute='niq_lineitemid' operator='eq' value='${lineItemId}' />
            </filter>
          </entity>
        </fetch>`;

        Xrm.WebApi.retrieveMultipleRecords("niq_schedule", "?fetchXml=" + encodeURIComponent(fetchXml)).then(
            function success(result) {
                result.entities.forEach(function (schedule) {
                    if (schedule.niq_scheduledate) {
                        var scheduledDate = new Date(schedule.niq_scheduledate);
                        scheduledDate.setMonth(scheduledDate.getMonth() + addMonthCount);

                        var year = scheduledDate.getFullYear();
                        var month = (scheduledDate.getMonth() + 1).toString().padStart(2, '0');
                        var day = scheduledDate.getDate().toString().padStart(2, '0');
                        var formattedDate = `${month}/${day}/${year}`;

                        var updateSchedule = {
                            niq_scheduledate: `${year}-${month}-${day}`,
                            niq_name: formattedDate
                        };

                        Xrm.WebApi.updateRecord("niq_schedule", schedule.niq_scheduleid, updateSchedule).then(
                            function success(result) {
                            },
                            function error(error) {
                            }
                        );
                    }
                });
            },
            function error(error) {
            }
        );
    },

    /**
     * updateBillingScheduleDates() updates the schedule date of the custom billing and revenue schedules.
     * The date is updated by adding the specified number of months.
     *
     * @param {number} addMonthCount - The number of months to add to the niq_scheduledate attribute.
     * @param {string} lineItemId - The GUID of the niq_lineitemid to filter the records.
     */
    updateBillingScheduleDates: function (addMonthCount, lineItemId) {
        var fetchXml = `
            <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
              <entity name='niq_schedule'>
                <attribute name='niq_scheduleid' />
                <attribute name='niq_scheduletype' />
                <attribute name='niq_scheduledate' />
                <attribute name='niq_lineitemid' />
                <attribute name='niq_iscustomschedule' />
                <attribute name='niq_name' />
                <order attribute='niq_name' descending='false' />
                <filter type='and'>
                  <condition attribute="niq_scheduletype" operator="eq" value="100000000" />
                  <condition attribute='niq_iscustomschedule' operator='eq' value='1' />
                  <condition attribute='niq_lineitemid' operator='eq' value='${lineItemId}' />
                </filter>
              </entity>
            </fetch>`;

        Xrm.WebApi.retrieveMultipleRecords("niq_schedule", "?fetchXml=" + encodeURIComponent(fetchXml)).then(
            function success(result) {
                result.entities.forEach(function (schedule) {
                    if (schedule.niq_scheduledate) {
                        var scheduledDate = new Date(schedule.niq_scheduledate);
                        scheduledDate.setMonth(scheduledDate.getMonth() + addMonthCount);

                        var year = scheduledDate.getFullYear();
                        var month = (scheduledDate.getMonth() + 1).toString().padStart(2, '0');
                        var day = scheduledDate.getDate().toString().padStart(2, '0');
                        var formattedDate = `${month}/${day}/${year}`;

                        var updateSchedule = {
                            niq_scheduledate: `${year}-${month}-${day}`,
                            niq_name: formattedDate
                        };

                        Xrm.WebApi.updateRecord("niq_schedule", schedule.niq_scheduleid, updateSchedule).then(
                            function success(result) {
                            },
                            function error(error) {
                            }
                        );
                    }
                });
            },
            function error(error) {
            }
        );
    },
    //Return true if day is 1st day of a month
    IsFirstDayOfMonth: function (date) {
        const day = date.getDate();
        if (day === 1) {
            return true
        } else { return false }
    },
    //Return true if day is  last day of a month
    IsLastDayOfMonth: function (date) {
        const lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
        if (date.getDate() === lastDay) { return true; } else { return false; }
    },
    //Find out term lenght from Startdate and EndDate if start date and end date is 1st day and last day of resepectively
    MonthsDifference: function (startDate, endDate) {
        // Create Date objects from the start and end dates
        const start = new Date(startDate);
        const end = new Date(endDate);

        // Calculate the difference in years and months
        const yearDiff = end.getFullYear() - start.getFullYear();
        const monthDiff = end.getMonth() - start.getMonth();

        // Total months difference
        const totalMonths = yearDiff * 12 + monthDiff;

        // Return the total difference in months
        return totalMonths;
    },
    //Regeneration of schedules onClick of "Regenerate Button" on quote product tab.
    RegenerateSchedule: async function (selectedControl, primaryControl) {
        //debugger;
        var formContext = primaryControl;
        var FARStage = false;
        var opportunityLookup = formContext.getAttribute("opportunityid")?.getValue();
        if (opportunityLookup != null) {
            //Check stage in FAR stage or not
            FARStage = await QuoteProductRibbon.Events.checkOpportunityStage(opportunityLookup[0].id.replace("{", "").replace("}", ""));
        }
        if (CommonForm.Events.CheckIfLoggedInUserRoles("System Administrator,NIQ Add-On Finance Gatekeeper,NIQ Add On Sales Ops Approver") && FARStage && opportunityLookup != null) {
            Xrm.Utility.showProgressIndicator("Schedules are generating..");
            await delay(1000);
            //debugger;
            var selectedRows = selectedControl.getGrid().getSelectedRows();
            //var subgridName = selectedControl._controlName;
            if (selectedRows.getLength() === 0) {
                Xrm.Navigation.openAlertDialog({ text: "Please select at least one record to Regenerate Schedules." });
                Xrm.Utility.closeProgressIndicator();
                return;
            }
            try {
                selectedRows.forEach(function (row) {
                    //debugger;
                    var entity = row.getData().getEntity();
                    var entityName = row.getData().getEntity().getEntityName();
                    var entityId = row.getData().getEntity().getId().replace('{', '').replace('}', '');
                    //console.log(row.data.entity.attributes._collection);
                    var attributes = row.data.entity.attributes._collection;
                    var currentDateTime = new Date();
                    currentDateTime = currentDateTime.getDate() + "/" + (currentDateTime.getMonth() + 1) + "/" + currentDateTime.getFullYear() + " " + currentDateTime.getHours() + ":" + currentDateTime.getMinutes() + ":" + currentDateTime.getSeconds();
                    var reveneueFrequency = attributes.niq_deliveryfrequency.getValue();
                    var billingFrequency = attributes.niq_billingfrequency.getValue();

                    //Change Last modified for Revenue field
                    if (reveneueFrequency != null && reveneueFrequency != 100000009) {
                        attributes.niq_isrevenuemodified.setValue(currentDateTime);
                    }
                    //Change Last modified for Billing modified field
                    if (billingFrequency != null && billingFrequency != 100000009) {
                        attributes.niq_isbillingmodified.setValue(currentDateTime);
                    }
                    entity.save();
                });
                Xrm.Utility.closeProgressIndicator();
                var quoteProductSubGrid = formContext.getControl("QuoteProduct");
                quoteProductSubGrid.refresh();
            }
            catch (err) {
                Xrm.Utility.closeProgressIndicator();
            }
        }
    },
    //Opportunity on FAR stage or not
    checkOpportunityStage: async function (OpportunityGUID) {
        var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
            "  <entity name='opportunity'>" +
            "    <attribute name='name'/>" +
            "    <attribute name='niq_stage'/>" +
            "    <attribute name='opportunityid'/>" +
            "    <order attribute='estimatedclosedate' descending='false'/>" +
            "    <order attribute='customerid' descending='false'/>" +
            "    <filter type='and'>" +
            "        <filter type='and'>" +
            "          <condition attribute='niq_stage' operator='eq' value='Closed Won - In Review'/>" +
            "          <condition attribute='niq_approvalstatus' operator='in'>" +
            "            <value>100000004</value>" +
            "            <value>100000005</value>" +
            "            <value>100000006</value>" +
            "            <value>100000003</value>" +
            "          </condition>" +
            "        </filter>" +
            "      <condition attribute='opportunityid' operator='eq' value='" + OpportunityGUID + "'/>" +
            "    </filter>" +
            "  </entity>" +
            "</fetch>";
        var results = await Xrm.WebApi.retrieveMultipleRecords("opportunity", "?fetchXml=" + encodeURIComponent(fetchXml));
        if (results.entities.length > 0) {
            return true;
        } else {
            return false;
        }
    },
    //Hide button Regenerate Schedule button on quote product tab
    HideRegenerateSchedules: async function (primaryControl) {
        var formContext = primaryControl;
        var FARStage = false;
        var opportunityLookup = formContext.getAttribute("opportunityid")?.getValue();
        if (opportunityLookup != null) {
            FARStage = await QuoteProductRibbon.Events.checkOpportunityStage(opportunityLookup[0].id.replace("{", "").replace("}", ""));
        }
        if (FARStage && CommonForm.Events.CheckIfLoggedInUserRoles("System Administrator,NIQ Add-On Finance Gatekeeper,NIQ Add On Sales Ops Approver") && opportunityLookup != null) {
            return true;
        } else {
            return false
        }
    }
}


