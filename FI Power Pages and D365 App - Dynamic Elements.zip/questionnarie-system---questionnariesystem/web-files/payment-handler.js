window.PaymentHandler = (function () {
  const CONFIG = {
    flowUrl: ""
  };

  function formatAmount(amount) {
    return Number(amount || 0).toLocaleString("en-US", {
      style: "currency",
      currency: "USD"
    });
  }

  function escapeHtml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function cleanupModal() {
    const backdrop = document.getElementById("ph-backdrop");
    const modal = document.getElementById("ph-modal");

    if (backdrop) backdrop.remove();
    if (modal) modal.remove();
  }

  function showProgressIndicator(message) {
    if (document.getElementById("ph-progress")) {
      return;
    }

    const html = `
      <div id="ph-progress" style="position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:10000;display:flex;align-items:center;justify-content:center;">
        <div style="min-width:280px;max-width:90vw;background:#fff;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.25);padding:24px 20px;font-family:Segoe UI,Arial,sans-serif;text-align:center;">
          <div style="width:36px;height:36px;border:4px solid #dbe7f5;border-top:4px solid #0b5cab;border-radius:50%;margin:0 auto 14px auto;animation:ph-spin 1s linear infinite;"></div>
          <div style="font-size:16px;font-weight:600;color:#111827;margin-bottom:6px;">Please wait</div>
          <div style="font-size:14px;color:#4b5563;">${escapeHtml(message || "Processing...")}</div>
        </div>
      </div>
    `;

    if (!document.getElementById("ph-progress-style")) {
      const style = document.createElement("style");
      style.id = "ph-progress-style";
      style.textContent = `
        @keyframes ph-spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `;
      document.head.appendChild(style);
    }

    document.body.insertAdjacentHTML("beforeend", html);
  }

  function hideProgressIndicator() {
    const progress = document.getElementById("ph-progress");
    if (progress) {
      progress.remove();
    }
  }

  function renderPaymentModal(submissionId, amount) {
    const html = `
      <div id="ph-backdrop" style="position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9998;"></div>
      <div id="ph-modal" style="position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);width:min(92vw,520px);background:#fff;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.25);z-index:9999;font-family:Segoe UI,Arial,sans-serif;overflow:hidden;">
        <div style="padding:16px 20px;border-bottom:1px solid #e9e9e9;font-size:18px;font-weight:600;">Application Payment</div>
        <div style="padding:18px 20px;">
          <div style="margin-bottom:8px;color:#555;">Submission ID:</div>
          <div style="margin-bottom:14px;font-weight:600;word-break:break-all;">${escapeHtml(submissionId)}</div>

          <div style="margin-bottom:8px;color:#555;">Amount to Pay:</div>
          <div style="font-size:24px;font-weight:700;color:#0b5cab;margin-bottom:18px;">${formatAmount(amount)}</div>

          <div style="display:flex;gap:10px;flex-wrap:wrap;">
            <button id="ph-success" style="flex:1;min-width:140px;background:#0b5cab;color:#fff;border:none;padding:10px 12px;border-radius:8px;cursor:pointer;">Pay (Success)</button>
            <button id="ph-failed" style="flex:1;min-width:140px;background:#b42318;color:#fff;border:none;padding:10px 12px;border-radius:8px;cursor:pointer;">Simulate Failed</button>
            <button id="ph-cancel" style="flex:1;min-width:140px;background:#6b7280;color:#fff;border:none;padding:10px 12px;border-radius:8px;cursor:pointer;">Cancel</button>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML("beforeend", html);
  }

  async function getFlowUrlFromConfig() {
    const query = "/_api/lpi_configsettings?$select=lpi_name,lpi_to&$filter=lpi_name eq 'paymentURL'";

    const response = await fetch(query, {
      method: "GET",
      headers: {
        "Accept": "application/json"
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to fetch config setting. Status: ${response.status}. ${errorText}`);
    }

    const data = await response.json();
    const rows = data && data.value ? data.value : [];

    if (!rows.length) {
      throw new Error("No config setting found with name 'paymentURL'.");
    }

    const flowUrl = rows[0].lpi_to;

    if (!flowUrl) {
      throw new Error("The config setting 'paymentURL' does not contain a URL.");
    }

    return flowUrl;
  }

  async function fetchPriceFromFlow(submissionId) {
    if (!submissionId) {
      throw new Error("submissionId is required");
    }

    CONFIG.flowUrl = await getFlowUrlFromConfig();

    const res = await fetch(CONFIG.flowUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        submissionId: submissionId
      })
    });

    if (res.status === 200) {
      const amountHeader = res.headers.get("amount");

      if (amountHeader === null || amountHeader === "") {
        throw new Error("Flow response header does not contain 'amount'.");
      }

      const amount = Number(amountHeader);

      if (!Number.isFinite(amount)) {
        throw new Error("Flow returned an invalid amount header.");
      }

      return amount;
    }

    const errorText = await res.text();
    throw new Error(`Flow call failed. Status: ${res.status}. ${errorText}`);
  }

  async function openPayment(submissionId) {
    cleanupModal();
    showProgressIndicator("Calculating payment amount...");

    let amount;

    try {
      amount = await fetchPriceFromFlow(submissionId);
    } catch (error) {
      hideProgressIndicator();
      cleanupModal();
      alert(error.message || "Failed to calculate payment. Please try again.");
      throw error;
    }

    hideProgressIndicator();

    return new Promise((resolve) => {
      cleanupModal();
      renderPaymentModal(submissionId, amount);

      function done(status) {
        cleanupModal();
        resolve({
          status: status,
          amount: amount
        });
      }

      document.getElementById("ph-success").addEventListener("click", () => done("success"));
      document.getElementById("ph-failed").addEventListener("click", () => done("failed"));
      document.getElementById("ph-cancel").addEventListener("click", () => done("canceled"));
      document.getElementById("ph-backdrop").addEventListener("click", () => done("canceled"));
    });
  }

  return {
    openPayment: openPayment
  };
})();