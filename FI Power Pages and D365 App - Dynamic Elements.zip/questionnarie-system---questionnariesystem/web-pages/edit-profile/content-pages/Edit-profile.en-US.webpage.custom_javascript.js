$(document).ready(function() {
    $("#UpdateButton").val("Update");
});
