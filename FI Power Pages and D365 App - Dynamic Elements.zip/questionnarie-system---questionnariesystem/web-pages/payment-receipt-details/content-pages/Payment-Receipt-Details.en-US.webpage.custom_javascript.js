$(document).ready(function (){
    $("#printReceiptBtn").on("click", function (e) {
        e.preventDefault();
        window.print();
    });

    $("#backToPaymentsBtn").on("click", function (e){
        e.preventDefault();
        window.location.href = "/My-Payments";
    });
})