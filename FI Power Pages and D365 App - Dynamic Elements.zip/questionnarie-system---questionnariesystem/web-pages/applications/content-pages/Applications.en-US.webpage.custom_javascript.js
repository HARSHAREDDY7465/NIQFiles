
function openApplication(applicationid,flowid){
        window.location.href = `/Question?applicationid=${applicationid}&flowid=${flowid}`;
    }

function openAll(status){
        window.location.href = "?page=1&status=" + status;
    }
    function openProgress(status){
        window.location.href = "?page=1&status=" + status;
    }
    function openApproved(status){
        window.location.href = "?page=1&status=" + status;
    }
    function openRejected(status){
        window.location.href = "?page=1&status=" + status;
    }
    function openDraft(status){
        window.location.href = "?page=1&status=" + status;
    }


async function discardApplication(applicationid){
if (!confirm("Discard this application? This will delete it permanently."))
      return;
    try{
    const token = await getRequestVerificationToken();
      // 2) delete the application
      await fetch(`/_api/lpi_applications(${applicationid})`, {
        method: "DELETE",
        headers: {
          __RequestVerificationToken: token,
          "If-Match": "*",
        },
      });
      window.location.href = "/Application";
    }catch (e) {
      console.error(e);
      alert("Failed to discard/delete the application. Please try again.");
    }
}

  // Retrieve Portal token
function getRequestVerificationToken() {
    return new Promise((resolve, reject) => {
      shell.getTokenDeferred().done(resolve).fail(reject);
    });
  }

document.addEventListener("DOMContentLoaded", function () {
    const searchInput = document.getElementById("applicationSearch");
    searchInput.addEventListener("keypress", function (e) {
        if (e.key === "Enter") {
            e.preventDefault();
            const searchValue = this.value.trim();
            window.location.href =
                "?page=1&search=" + encodeURIComponent(searchValue);
        }
    });

    document.getElementById('searchBtn').addEventListener('click', function () {
    window.location.href = "?page=1&search=" + encodeURIComponent(searchValue);
  });

});

document.getElementById('applyBtn').addEventListener('click', function () {
    window.location.href = "/License-Selection" ;
  });

  document.title = "Applications";
