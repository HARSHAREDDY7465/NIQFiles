$(document).ready(function () {

  const listSelector = ".entitylist.entity-grid";
  const renewPageUrl = "/license-selection/";

  function shouldShowRenew(expiryDateText) {
    if (!expiryDateText) return false;

    var expiry = new Date(expiryDateText);

    if (isNaN(expiry)) return false;

    var next7Days = new Date();
    next7Days.setDate(next7Days.getDate() + 7);
    return expiry <= next7Days;
  }

  function injectButtons($list) {

    var $grid = $list.find(".view-grid table");

    if (!$grid.length) return;

    var $headerRow = $grid.find("thead tr");

    if (!$headerRow.find(".custom-action-col").length) {
      $headerRow.append(
        '<th class="custom-action-col">Actions</th>'
      );
    }

    $grid.find("tbody tr").each(function () {

      var $row = $(this);

      if ($row.find(".custom-action-col").length) return;

      var rowId = $row.attr("data-id");

      if (!rowId) return;
      const $cells = $row.children("td");
      const expiryDate = $cells.filter('[data-attribute="dgps_expirationdate"]').text().trim();
      const renewable = $cells.filter('[data-attribute="dgps_licenserenewable"]').text().trim().toLowerCase();
      const canrenew = shouldShowRenew(expiryDate) && renewable === "yes";
      var html =
        '<td class="custom-action-col">' +
        '<div class="license-action-wrap">' +
        '<button type="button" class="btn view-license-btn" data-row-id="' + rowId + '"><i class="fa fa-eye" style="margin-right:5px"></i>View</button>';

      if (canrenew) {
        html +=
          '<button type="button" class="btn renew-license-btn" data-row-id="' + rowId + '"><i class="fa fa-refresh" style="margin-right:3px"></i>Renew</button>';
      }

      html +=
        '</div>' +
        '</td>';

      $row.append(html);

    });

  }

  $(listSelector).on("loaded", function () {
    injectButtons($(this));
  });

  $(document).on("click", ".renew-license-btn", function () {
    window.location.href =
      renewPageUrl;
  });

  $(document).on("click", ".view-license-btn", function () {
    const rowId = $(this).data("row-id");
     window.location.href =`/License-Details?id=${rowId}`;
   
  });

});