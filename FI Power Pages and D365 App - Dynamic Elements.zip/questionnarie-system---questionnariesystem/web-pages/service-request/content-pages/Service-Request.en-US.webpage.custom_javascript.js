// filename: Service.en-US.customjs.js
const state = {
  allRequests: [],
  currentStatus: "all",
  searchTerm: "",
  currentPage: 1,
  pageSize: 3
};

function normalizeStatus(status) {
  return String(status || "").trim().toLowerCase();
}

function getBadgeClass(status) {
  const value = normalizeStatus(status);
  if (value === "open") return "lp-badge-warning";
  if (value === "in progress") return "lp-badge-info";
  if (value === "resolved") return "lp-badge-success";
  if (value === "rejected") return "lp-badge-danger";
  return "lp-badge-muted";
}

function updateTabCounts(requests) {
  const counts = { all: requests.length, open: 0, inprogress: 0, resolved: 0 };

  requests.forEach((request) => {
    const status = normalizeStatus(request.status);
    if (status === "open") counts.open += 1;
    if (status === "in progress") counts.inprogress += 1;
    if (status === "resolved") counts.resolved += 1;
  });

  document.getElementById("count-all").textContent = counts.all;
  document.getElementById("count-open").textContent = counts.open;
  document.getElementById("count-inprogress").textContent = counts.inprogress;
  document.getElementById("count-resolved").textContent = counts.resolved;
}

function getFilteredRequests() {
  const term = state.searchTerm.toLowerCase();
  return state.allRequests.filter((request) => {
    const matchesStatus = state.currentStatus === "all" || normalizeStatus(request.status) === state.currentStatus;
    const matchesSearch =
      !term ||
      request.requestId.toLowerCase().includes(term) ||
      request.category.toLowerCase().includes(term) ||
      request.status.toLowerCase().includes(term) ||
      request.raisedOn.toLowerCase().includes(term);
    return matchesStatus && matchesSearch;
  });
}

function updateSummary(totalFiltered) {
  const summary = document.getElementById("serviceRequestsSummary");

  if (!totalFiltered) {
    summary.textContent = "Showing 0 to 0 of 0 entries";
    return;
  }

  const start = (state.currentPage - 1) * state.pageSize + 1;
  const end = Math.min(start + state.pageSize - 1, totalFiltered);
  summary.textContent = `Showing ${start} to ${end} of ${totalFiltered} entries`;
}

function renderTableRows(rows) {
  const tbody = document.getElementById("serviceRequestsTbody");

  if (!rows.length) {
    tbody.innerHTML = '<tr><td data-label="Results" colspan="5">No service requests found.</td></tr>';
    return;
  }

  tbody.innerHTML = rows.map((request) => `
    <tr>
      <td data-label="Request ID">${request.requestId}</td>
      <td data-label="Category">${request.category}</td>
      <td data-label="Status"><span class="lp-badge ${getBadgeClass(request.status)}">${request.status}</span></td>
      <td data-label="Raised On">${request.raisedOn}</td>
      <td data-label="Action"><a class="btn btn-link p-0" href="#">View</a></td>
    </tr>
  `).join("");
}

function createPageItem(label, page, options = {}) {
  const { active = false, disabled = false } = options;
  const li = document.createElement("li");
  li.className = `page-item${active ? " active" : ""}${disabled ? " disabled" : ""}`;

  const a = document.createElement("a");
  a.className = "page-link";
  a.href = "#";
  a.textContent = label;

  if (!disabled) {
    a.addEventListener("click", (event) => {
      event.preventDefault();
      state.currentPage = page;
      renderServiceRequests();
    });
  }

  li.appendChild(a);
  return li;
}

function renderPagination(totalFiltered) {
  const pagination = document.getElementById("serviceRequestsPagination");
  pagination.innerHTML = "";

  const totalPages = Math.max(1, Math.ceil(totalFiltered / state.pageSize));
  pagination.appendChild(createPageItem("‹", Math.max(1, state.currentPage - 1), { disabled: state.currentPage === 1 }));

  for (let page = 1; page <= totalPages; page += 1) {
    pagination.appendChild(createPageItem(String(page), page, { active: page === state.currentPage }));
  }

  pagination.appendChild(createPageItem("›", Math.min(totalPages, state.currentPage + 1), { disabled: state.currentPage === totalPages || totalFiltered === 0 }));
}

function setActiveTab() {
  document.querySelectorAll(".lp-tabs .nav-link").forEach((link) => {
    link.classList.toggle("active", link.dataset.status === state.currentStatus);
  });
}

function renderServiceRequests() {
  updateTabCounts(state.allRequests);

  const filtered = getFilteredRequests();
  const totalPages = Math.max(1, Math.ceil(filtered.length / state.pageSize));
  if (state.currentPage > totalPages) state.currentPage = totalPages;

  const startIndex = (state.currentPage - 1) * state.pageSize;
  const pageRows = filtered.slice(startIndex, startIndex + state.pageSize);

  setActiveTab();
  renderTableRows(pageRows);
  updateSummary(filtered.length);
  renderPagination(filtered.length);
}

function bindEvents() {
  document.querySelectorAll(".lp-tabs .nav-link").forEach((link) => {
    link.addEventListener("click", (event) => {
      event.preventDefault();
      state.currentStatus = link.dataset.status;
      state.currentPage = 1;
      renderServiceRequests();
    });
  });

  document.getElementById("serviceRequestSearch").addEventListener("input", (event) => {
    state.searchTerm = event.target.value.trim();
    state.currentPage = 1;
    renderServiceRequests();
  });
}

document.addEventListener("DOMContentLoaded", () => {
  bindEvents();
  renderServiceRequests();
});

/*
Later, replace state.allRequests with your fetch result:
fetch("/your-api/service-requests")
  .then((response) => response.json())
  .then((data) => {
    state.allRequests = data;
    state.currentPage = 1;
    renderServiceRequests();
  });
*/
document.addEventListener("DOMContentLoaded", function () {
  const serviceRequestBtn = document.getElementById("serviceRequestBtn");

  if (serviceRequestBtn) {
    serviceRequestBtn.addEventListener("click", function (event) {
      event.preventDefault();
      console.log("Open New Service Request flow");
    });
  }
});
