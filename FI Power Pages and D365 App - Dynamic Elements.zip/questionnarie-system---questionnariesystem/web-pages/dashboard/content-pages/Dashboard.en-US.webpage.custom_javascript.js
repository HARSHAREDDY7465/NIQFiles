function openApplication(applicationid,flowid){
        window.location.href = `/Question?applicationid=${applicationid}&flowid=${flowid}`;
    }
async function discardApplication(applicationid){
if (!confirm("Discard this application? This will delete it permanently."))
      return;
    try{
    const token = await getRequestVerificationToken();
      // 2) delete the application
      await fetch(`/_api/lpi_applications(${applicationid})`, {
        method: "DELETE",
        headers: {
          __RequestVerificationToken: token,
          "If-Match": "*",
        },
      });
      window.location.href = "/Application";
    }catch (e) {
      console.error(e);
      alert("Failed to discard/delete the application. Please try again.");
    }
}

 document.querySelectorAll("[data-lp-chat-form]").forEach((form) => {
    form.addEventListener("submit", function (e) {
      e.preventDefault();

      const input = form.querySelector('input[type="text"]');
      const question = input?.value.trim();
      if (!question) return;
      window.location.href = "/chat?q=" + encodeURIComponent(question);
    });
  });
  document.querySelectorAll(".lp-suggested button").forEach((button) => {
    button.addEventListener("click", function () {
      const question = button.textContent.trim();
      window.location.href = "/chat?q=" + encodeURIComponent(question);
    });
  });

  function getRequestVerificationToken() {
    return new Promise((resolve, reject) => {
      shell.getTokenDeferred().done(resolve).fail(reject);
    });
  }