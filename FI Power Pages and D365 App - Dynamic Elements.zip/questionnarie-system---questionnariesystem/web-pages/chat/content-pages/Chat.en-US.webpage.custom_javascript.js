   document.addEventListener("DOMContentLoaded", function () {
    const frame = document.getElementById("copilotFrame");
    if (!frame) return;

    const params = new URLSearchParams(window.location.search);
    const question = params.get("q");
    const baseSrc = frame.dataset.baseSrc;

    if (!baseSrc) return;

    frame.src = question
      ? baseSrc + "&initialQuestion=" + question
      : baseSrc;
  });