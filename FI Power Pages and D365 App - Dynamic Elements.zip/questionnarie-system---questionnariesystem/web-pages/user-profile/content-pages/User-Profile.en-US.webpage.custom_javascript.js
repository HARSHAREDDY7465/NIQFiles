document.getElementById('btnChangePassword').addEventListener('click', function () {
    window.location.href = "/en-US/Account/Manage/ChangePassword" ;
  });

$(document).ready(function () {
    // 1. Check if the URL contains the success message parameter
    const urlParams = new URLSearchParams(window.location.search);
    const message = urlParams.get('Message');

    if (message === 'ChangePasswordSuccess') {
        // 2. Create the success alert box html
        const alertHtml = `
            <div id="password-success-alert" class="alert alert-success alert-dismissible" role="alert" style="margin-top: 15px;">
                <strong>Success!</strong> Your password has been changed successfully.
                <button type="button" id="closebtnalert" class="close btn-close-modal" data-dismiss="modal" aria-label="Close" style="background: none; border: none; font-size: 1.5rem; line-height: 1; color: #aaa; cursor: pointer;">
                    <span aria-hidden="true">&times;</span>
                  </button>
            </div>
        `;
        const newParams = urlParams.toString();
        const newUrl = window.location.pathname + (newParams ? '?' + newParams : '');
          
        window.history.replaceState({}, document.title, newUrl);

        $(".lp-main").before(alertHtml);
        document.getElementById('closebtnalert').addEventListener('click', function() {
          
            document.getElementById('password-success-alert').style.display = 'none';
        });
        
    }
});
