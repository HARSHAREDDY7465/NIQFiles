function payNow(id, event) {
  if (event) event.preventDefault();

  const invoiceId = id;
  if (!invoiceId) return;

  const btn = event.currentTarget || document.getElementById("payBtn_" + id);
  if (!btn || btn.style.pointerEvents === 'none') return;
  btn.style.pointerEvents = 'none';
  btn.style.opacity = '0.5';

  // Dataverse option-set values used in the payloads below
  const STATE_PAID = 2;
  const STATUS_COMPLETE = 100001;
  const PAYMENT_STATUS_PAID = 855890001;
  const PAYMENT_METHOD_CREDIT_CARD = 855890000;

  shell.getTokenDeferred()
    .done(function (token) {

      //To check if token is acquired or not
      // console.log("Anti-forgery token acquired:", token);

      function apiCall(url, method, body) {
        const headers = { "Accept": "application/json" };

        if (method !== "GET") {
          headers["Content-Type"] = "application/json";
          headers["OData-MaxVersion"] = "4.0";
          headers["OData-Version"] = "4.0";
          headers["__RequestVerificationToken"] = token;
        }

        return fetch(url, {
          method: method,
          headers: headers,
          credentials: "same-origin",
          body: body ? JSON.stringify(body) : undefined
        }).then(function (res) {
          if (!res.ok) {
            return res.text().then(function (text) {
              let msg = "HTTP " + res.status;
              try {
                const err = JSON.parse(text);
                msg = (err && err.error && err.error.message) || msg;
              } catch (e) { /* non-JSON body */ }
              throw new Error(msg);
            });
          }
          if (res.status === 204) return null;
          return res.json();
        });
      }

      const selectFields = "$select=totalamount,_lpi_applicant_value,_lpi_application_value";

      apiCall("/_api/invoices(" + invoiceId + ")?" + selectFields, "GET")
        .then(function (inv) {
          // console.log("Invoice fetched:", inv);

          if (!inv._lpi_applicant_value || !inv._lpi_application_value) {
            throw new Error("Invoice is missing applicant or application link.");
          }
          if (inv.totalamount == null) {
            throw new Error("Invoice total amount is empty — cannot process payment.");
          }


          const receiptPayload = {
            "lpi_paymentamount": inv.totalamount,
            "lpi_paymentstatus": PAYMENT_STATUS_PAID,
            "lpi_paymentmethod": PAYMENT_METHOD_CREDIT_CARD,
            "lpi_Invoice@odata.bind":     "/invoices(" + invoiceId + ")",
            "lpi_Applicant@odata.bind":   "/contacts(" + inv._lpi_applicant_value + ")",
            "lpi_Application@odata.bind": "/lpi_applications(" + inv._lpi_application_value + ")"
          };

          return apiCall("/_api/lpi_paymentreceipts", "POST", receiptPayload);
        })
        .then(function () {

          const statusPayload = {
            "statecode": STATE_PAID,
            "statuscode": STATUS_COMPLETE
          };
          return apiCall("/_api/invoices(" + invoiceId + ")", "PATCH", statusPayload);
        })
        .then(function () {

          window.open(
            "https://www.paypal.com/ncp/payment/MTNQ8Z8KGNYCS",
            "_blank",
            "noopener,noreferrer"
          );
        })
        .catch(function (err) {
          
          if (btn) {
            btn.style.pointerEvents = 'auto';
            btn.style.opacity = '1';
          }
          const msg = (err && err.message) || "Could not initiate payment. Please try again.";
          alert(msg);
          console.error("Pay flow failed:", err);
        });

    })
    .fail(function (err) {
      // Token retrieval itself failed — re-enable the button and warn
      if (btn) {
        btn.style.pointerEvents = 'auto';
        btn.style.opacity = '1';
      }
      console.error("Failed to retrieve anti-forgery token:", err);
      alert("Could not retrieve security token. Please refresh the page and try again.");
    });
}
