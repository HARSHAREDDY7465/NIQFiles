/*-----------------------------------------------------------------------------------------------------
SchemaName: lpi_/webresources/javascript/Question/QuestionForm.js
DisplayName: QuestionForm.js
CreatedBy: Kalyan
CreatedOn: 04/8/2026
------------------------------------------------------------------------------------------------------*/

var LPI = LPI || {}

LPI.QuestionForm = {

    onLoad : function (executionContext) {
    var formContext = executionContext.getFormContext();
        window.top.formContext = formContext;
        LPI.QuestionForm.ShowHideHTMLPreviewButton(executionContext);
    },
    ShowHideHTMLPreviewButton: function (executionContext) {
    var formContext = executionContext.getFormContext();
    var answerTypeAttr = formContext.getAttribute("lpi_answerdatatype");
    var previewBtnCtrl = formContext.getControl("WebResource_QuestionButtonPreview");

    if (!answerTypeAttr || !previewBtnCtrl) {
        return;
    }

    previewBtnCtrl.setVisible(answerTypeAttr.getValue() === 855890017);
    },

    filterHeadingSubSectionLookup: function (executionContext) {
        return LPI.QuestionForm.filterRelatedSubgrid(executionContext, {
            fieldName: "lpi_headingsubsection",
            entityName: "lpi_headingsubsection1",
            idField: "lpi_headingsubsection1id",
            linkEntity: "lpi_flowsubsection1",
            linkFrom: "lpi_subsection",
            linkTo: "lpi_headingsubsection1id",
            flowField: "lpi_flow"
        });
    },

    filterRelatedSubgrid: async function (executionContext, config) {

        var formContext = executionContext.getFormContext();
        var mainFlowId = formContext.getAttribute("lpi_functionflowid")?.getValue();
        if (!mainFlowId) return;
        var LookupControl = formContext.getControl(config.fieldName);

        var fetchXml =
            "<fetch version='1.0' mapping='logical'>" +
            "<entity name='" + config.entityName + "'>" +
            "<attribute name='" + config.idField + "' />" +
            "<filter type='and'>" +
            "<condition attribute='statecode' operator='eq' value='0' />" +
            "</filter>" +
            "<link-entity name='" + config.linkEntity + "' from='" + config.linkFrom + "' to='" + config.linkTo + "'>" +
            "<filter type='and'>" +
            "<condition attribute='" + config.flowField + "' operator='eq' value='" + mainFlowId + "' />" +
            "</filter>" +
            "</link-entity>" +
            "</entity>" +
            "</fetch>";

        var result = await Xrm.WebApi.retrieveMultipleRecords(config.entityName, "?fetchXml=" + encodeURIComponent(fetchXml));

        var ids = result.entities.map(function (row) {
            return row[config.idField];
        });

        var values = "";
        for (var i = 0; i < ids.length; i++) {
            values += "<value>" + ids[i] + "</value>";
        }
        if (ids.length > 0) {
            var filterXml =
                "<filter type='and'>" +
                "<condition attribute='statecode' operator='eq' value='0' />" +
                "<condition attribute='" + config.idField + "' operator='in'>" +
                values +
                "</condition>" +
                "</filter>";
            if (LookupControl) {
                LookupControl.addPreSearch(function () {
                    LookupControl.addCustomFilter(filterXml, config.entityName);
                });
            }

        } else {
            var filterXml =
                "<filter type='and'>" +
                "<condition attribute='statecode' operator='eq' value='0' />" +
                "<condition attribute='" + config.idField + "' operator='null' />" +
                "<condition attribute='" + config.idField + "' operator='not-null' />" +
                "</filter>"

            if (LookupControl) {
                LookupControl.addPreSearch(function () {
                    LookupControl.addCustomFilter(filterXml, config.entityName);
                });
            }

        }
    },


};