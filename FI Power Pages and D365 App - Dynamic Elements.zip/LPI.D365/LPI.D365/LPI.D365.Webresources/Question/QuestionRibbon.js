/*-----------------------------------------------------------------------------------------------------
SchemaName: lpi_/webresources/javascript/QuestionRibbon/QuestionRibbon.js
DisplayName: QuestionRibbon.js
CreatedBy: Kalyan
CreatedOn: 28/7/2026
------------------------------------------------------------------------------------------------------*/

var LPI = LPI || {}

LPI.QuestionRibbon = {
    openFlowQuestionMappingQuickCreate: function (primaryControl) {
        var formContext = primaryControl;

        Xrm.Navigation.openForm(
            {
                entityName: "lpi_flowquestionsmapping1",
                useQuickCreateForm: true
            },
        ).then(function () {
            var subgrid = formContext.getControl("Subgrid_new_6");
            if (subgrid) {
                subgrid.refresh();
            }
        });
    }


};