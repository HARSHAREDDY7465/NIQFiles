// ----------------------------------------------------------------------------------------- //
// SchemaName :- lpi_/webresources/javascript/common/filepreviewmanager.js
// DisplayName :- FilePreviewManager.js
// CreatedBy :- Deepak Kumar
// Date :- 2/7/2026
// ------------------------------------------------------------------------------------------//


var LPI = (typeof LPI === "undefined") ? {} : LPI;
LPI.Common = LPI.Common || {};

LPI.Common.FilePreviewManager = (function () {

    const DEFAULTS = Object.freeze({
        pollIntervalMs: 1000,
        maxPollAttempts: 20,
        hidePreviewWhenEmpty: true
    });

    function normalizeGuid(id) {
        return (id || "").replace(/[{}]/g, "");
    }

    function safeGetControl(formContext, name) {
        try { return formContext.getControl(name); } catch { return null; }
    }

    function safeGetAttribute(formContext, name) {
        try { return formContext.getAttribute(name); } catch { return null; }
    }

    function buildInitData(formContext, fileColumn) {
        return {
            formContext: formContext,
            Xrm: Xrm,
            entity: formContext.data.entity.getEntityName(),
            fileColumn: fileColumn
        };
    }

    async function initializeViewer(formContext, webResourceControlName, fileColumn) {
        const control = safeGetControl(formContext, webResourceControlName);
        if (!control) return;

        const cw = await control.getContentWindow();
        if (cw && typeof cw.initialize === "function") {
            cw.initialize(buildInitData(formContext, fileColumn));
        }
    }

    async function waitForFilePersisted(entity, recordId, fileColumn, pollIntervalMs, maxAttempts) {
        for (let i = 0; i < maxAttempts; i++) {
            const resp = await Xrm.WebApi.retrieveRecord(entity, recordId, `?$select=${fileColumn}`);
            if (resp && resp[fileColumn]) return true;
            await new Promise(r => setTimeout(r, pollIntervalMs));
        }
        return false;
    }

    function resolveConfig(fileControlAttribute) {
        if (!fileControlAttribute) throw new Error("File Control Attribute config is required.");
        const merged = { ...DEFAULTS, fileControlAttribute };
        return merged;
    }

    async function initializePreviewPages(executionContext, fileControlAttribute) {
        const formContext = executionContext.getFormContext();
        if (!fileControlAttribute) throw new Error("File Control Attribute config is required.");
        const mergedCfg = { ...DEFAULTS, fileControlAttribute };

        for (const [control, column] of Object.entries(mergedCfg.fileControlAttribute)) {
            if (mergedCfg.hidePreviewWhenEmpty) {
                const attr = safeGetAttribute(formContext, column);
                const hasFile = !!attr?.getValue?.();
                const ctrl = safeGetControl(formContext, control);
                if (ctrl) ctrl.setVisible(hasFile);
                if (!hasFile) continue;
            }
            await initializeViewer(formContext, control, column);
        }
    }

    function registerFileChangeEvents(executionContext, fileControlAttribute) {
        const formContext = executionContext.getFormContext();

        if (!fileControlAttribute) throw new Error("File Control Attribute config is required.");
        const mergedCfg = { ...DEFAULTS, fileControlAttribute };

        for (const [_, column] of Object.entries(mergedCfg.fileControlAttribute)) {
            const attr = safeGetAttribute(formContext, column);
            if (!attr) continue;
            attr.addOnChange(async function (ctx) {
                await fileOnChange(ctx, mergedCfg);
            });
        }
    }

    async function fileOnChange(executionContext, cfg) {
        const formContext = executionContext.getFormContext();
        const fileColumn = executionContext.getEventSource()?.getName?.();
        if (!fileColumn) return;

        const ctrl = Object.keys(cfg.fileControlAttribute).find(
            k => cfg.fileControlAttribute[k] === fileColumn
        );

        const control = safeGetControl(formContext, ctrl);
        const attr = safeGetAttribute(formContext, fileColumn);
        if (!control || !attr) return;

        const hasFile = !!attr.getValue();
        if (!hasFile) {
            if (cfg.hidePreviewWhenEmpty) control.setVisible(false);
            return;
        }

        control.setVisible(true);

        const entity = formContext.data.entity.getEntityName();
        const recordId = normalizeGuid(formContext.data.entity.getId());
        if (!recordId) return;

        const ok = await waitForFilePersisted(
            entity,
            recordId,
            fileColumn,
            cfg.pollIntervalMs,
            cfg.maxPollAttempts
        );

        if (ok) {
            await initializeViewer(formContext, ctrl, fileColumn);
        }
    }

    return {
        initializePreviewPages,
        registerFileChangeEvents
    };
})();