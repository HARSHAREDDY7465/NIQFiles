/*-----------------------------------------------------------------------------------------------------
SchemaName: lpi_/webresources/javascript/inspection/inspectionform.js
DisplayName: InspectionForm.js
CreatedBy: Deepak Kumar
CreatedOn: 1/7/2026
------------------------------------------------------------------------------------------------------*/


var LPI = LPI || {}
LPI.InspectionForm = {
    "EntityDefination": {
        "Tabs": {

        },
        "Sections": {

        },
        "Subgrid": {

        },
        "Entity": {
            "EntitySchemaName": "lpi_inspection",
            "EntityPluralname": "lpi_inspections",
            "Fields": {
            }
        }
    },
    OnFormLoad: function (executionContext) {
        //Call All On load Form Functions
        LPI.InspectionForm.loadWebResources(executionContext);


    },
    OnFormSave: function (executionContext) {
        //Call All On Form Save Functions
        LPI.InspectionForm.saveChecklistDatatoUserResponse(executionContext);
    },

    //Added by deepak
    loadWebResources: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var webresource_control = formContext.getControl("WebResource_inspectionchecklist");
        if (webresource_control) {
            webresource_control.getContentWindow().then(
                function (contentWindow) {
                    contentWindow.setClientApiContext(Xrm, formContext);
                }
            )
        }
    },
    saveChecklistDatatoUserResponse: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var draftData = formContext.getAttribute("lpi_inspectionchecklistdraftdata");
        if (draftData != null && draftData != undefined && draftData != "") {
            const data = JSON.parse(draftData.getValue()) || {};
            let updatePromises = [];
            for (const [key, value] of Object.entries(data)) {

                const id = key;

                const isChecked = value["checked"] || "";
                const elementValue = value["val"] || "";
                const remarksText = value["remarks"] || "";

                let updatePayload = {};
                updatePayload["lpi_answer"] = isChecked ? true : false;
                updatePayload["lpi_answertext"] = elementValue;
                updatePayload["lpi_remarks"] = String(remarksText);

                let requestPromise = Xrm.WebApi.updateRecord("lpi_d365userresponse", id, updatePayload).catch(
                    err => {
                        console.error(`Fault details on entry submission thread: ${id}`, err.message);
                        return { error: true, id: id };
                    }
                );
                updatePromises.push(requestPromise);
            }
            Promise.all(updatePromises).then(results => {
                const validationError = results.filter(r => r && r.error);
                if (validationError.length === 0) {

                } else {
                    statusText.textContent = `Error: ${validationError.length} rows failed submission`;
                }
            });
        }
    }
}