// ----------------------------------------------------------------------------------------- //
// SchemaName :- lpi_/webresources/javascript/d365userresponse/userresponseform.js
// DisplayName :- D365UserResponseForm.js
// CreatedBy :- Deepak Kumar
// Date :- 16/6/2026
// ------------------------------------------------------------------------------------------//


var LPI = LPI || {}
LPI.D365UserResponseForm = {
    "EntityDefination": {
        "Tabs": {

        },
        "Sections": {

        },
        "Subgrid": {

        },
        "Entity": {
            "EntitySchemaName": "lpi_d365userresponse",
            "EntityPluralname": "lpi_d365userresponses",
            "Fields": {
                "Name": "name",
                "Application": "lpi_application",
                "QuestionLookup": "lpi_question",
                "QuestionText": "lpi_questiontext",
            }
        }
    },
    OnFormLoad: function (executionContext) {
        //Call All On load Form Functions

    },
    OnFormSave: function (executionContext) {
        //Call All On Form Save Functions
    },
    // This function locks fields on editable subgrid present on BLA Form
    onSelectLockUnlockUserResponseSubgridFields: function (executionContext) {
        let formContext = executionContext.getFormContext();
        let gridEntity = formContext.data.entity;

        let fields = [LPI.D365UserResponseForm.EntityDefination.Entity.Fields.Application,
        LPI.D365UserResponseForm.EntityDefination.Entity.Fields.QuestionText,
        LPI.D365UserResponseForm.EntityDefination.Entity.Fields.QuestionLookup];

        gridEntity.attributes.forEach(function (attribute) {
            if (fields.indexOf(attribute.getName()) > -1) {
                attribute.controls.forEach(function (fieldControl) {
                    fieldControl.setDisabled(true);
                });
            }
        });
    },
    onSaveOfChecklistAnswerUpdateBpfStage: function (executionContext) {
        let formContext = executionContext.getFormContext();

        let answerValue = formContext.getAttribute("lpi_answer");
        if (answerValue != null && answerValue != undefined && answerValue != "") {
            answerValue = answerValue.getValue();
        }

        let userResponseID = formContext.data.entity.getId().replace('{', '').replace('}', '');
        let businessLicenseID = Xrm.Utility.getPageContext().input.entityId.replace('{', '').replace('}', '');

        if (businessLicenseID != null && businessLicenseID != undefined && businessLicenseID != "" && userResponseID != null && businessLicenseID != undefined && businessLicenseID != "") {
            let query = "?$select=lpi_d365userresponseid&$filter=((lpi_answer eq false or lpi_answer eq null) and statecode eq 0 and _lpi_businesslicenseapplication_value eq " + businessLicenseID + " and lpi_d365userresponseid ne " + userResponseID + ")";
            Xrm.WebApi.retrieveMultipleRecords("lpi_d365userresponse", query).then(
                function success(result) {
                    if (result != null && result.entities.length == 0 && answerValue == true) {
                        var confirmStrings = {
                            title: "Confirm Your Action",
                            text: "You have completed the checkist. please click Ok to Complete the Application Review",
                            confirmButtonLabel: "Ok",
                            cancelButtonLabel: "Cancel"
                        };
                        var confirmOptions = {
                            height: 200,
                            width: 450
                        };
                        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
                            function (success) {
                                if (success.confirmed) {
                                    Xrm.WebApi.retrieveMultipleRecords("lpi_businesslicenseapplicationbpf", "?$select=businessprocessflowinstanceid,_activestageid_value,activestagestartedon,completedon,_bpf_lpi_businesslicenseapplicationid_value&$filter=_bpf_lpi_businesslicenseapplicationid_value eq " + businessLicenseID).then(
                                        function success(results) {
                                            if (results.entities.length > 0) {
                                                var result = results.entities[0];
                                                var businessprocessflowinstanceid = result["businessprocessflowinstanceid"];
                                                var activestageid = result["_activestageid_value"]
                                                if (activestageid != "e5771600-c789-47d2-8780-a8aa7fe29e5d") {
                                                    LPI.D365UserResponseForm.updateBPFStage(businessprocessflowinstanceid, "e5771600-c789-47d2-8780-a8aa7fe29e5d");
                                                    Xrm.WebApi.updateRecord("lpi_businesslicenseapplication", businessLicenseID, { "lpi_applicationstatus": 365820008 });
                                                    var alertStrings = {
                                                        confirmButtonLabel: "OK",
                                                        text: "Application submitted successfully. Please refresh the page to see latest data",
                                                        title: "Status"
                                                    };
                                                    var alertOptions = {
                                                        height: 200,
                                                        width: 450
                                                    };

                                                    Xrm.Page.data.refresh(true);
                                                    Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                                                }
                                            }
                                        },
                                        function (error) {
                                            console.log(error.message);
                                        }
                                    );

                                } else {

                                }
                            },
                            function (error) {
                                console.error(error.message);
                            }
                        );
                    } else {
                        Xrm.WebApi.retrieveMultipleRecords("lpi_businesslicenseapplicationbpf", "?$select=businessprocessflowinstanceid,_activestageid_value,activestagestartedon,completedon,_bpf_lpi_businesslicenseapplicationid_value&$filter=_bpf_lpi_businesslicenseapplicationid_value eq " + businessLicenseID).then(
                            function success(results) {
                                if (results.entities.length > 0) {
                                    var result = results.entities[0];
                                    var businessprocessflowinstanceid = result["businessprocessflowinstanceid"];
                                    var activestageid = result["_activestageid_value"]
                                    if (activestageid == "e5771600-c789-47d2-8780-a8aa7fe29e5d") {
                                        LPI.D365UserResponseForm.updateBPFStage(businessprocessflowinstanceid, "e2d3917f-b8b8-4776-9ccb-e7bccd8ce278");
                                    }
                                }
                            },
                            function (error) {
                                console.log(error.message);
                            }
                        );
                    }
                },
                function (error) {
                    console.log(error.message);
                }
            );
        }

    },
    updateBPFStage: function (businessprocessflowinstanceid, targetStageId) {
        var initialStageID = "e2d3917f-b8b8-4776-9ccb-e7bccd8ce278"
        let payload = {
            "activestageid@odata.bind": "/processstages(" + targetStageId + ")",
            "traversedpath": initialStageID + "," + targetStageId
        }
        Xrm.WebApi.updateRecord("lpi_businesslicenseapplicationbpf", businessprocessflowinstanceid, payload).then(
            function success(result) {
                Xrm.Page.data.refresh;
            },
            function (error) {
                console.log(error.message);
            }
        );
    }

}