/*-----------------------------------------------------------------------------------------------------
SchemaName: lpi_/webresources/javascript/FunctionFlowRibbon/FunctionFlowRibbon.js
DisplayName: FunctionFlowRibbon.js
CreatedBy: Kalyan
CreatedOn: 23/7/2026
------------------------------------------------------------------------------------------------------*/

var LPI = LPI || {}

LPI.FunctionFlowRibbon = {
    openHeadingSectionQuickCreate: function (primaryControl) {
        var formContext = primaryControl;
        var functionalFlowId = formContext.data.entity.getId().replace(/[{}]/g, "");

        Xrm.Navigation.openForm(
            {
                entityName: "lpi_headingsection1",
                useQuickCreateForm: true
            },
            {
                lpi_functionflowid: functionalFlowId
            }
        ).then(function () {
            var subgrid = formContext.getControl("Subgrid_new_4");
            if (subgrid) {
                subgrid.refresh();
            }
        });
    },
    openHeadingSubSectionQuickCreate: function (primaryControl) {
        var formContext = primaryControl;
        var functionalFlowId = formContext.data.entity.getId().replace(/[{}]/g, "");

        Xrm.Navigation.openForm(
            {
                entityName: "lpi_headingsubsection1",
                useQuickCreateForm: true
            },
            {
                lpi_functionflowid: functionalFlowId
            }
        ).then(function () {
            var subgrid = formContext.getControl("Subgrid_new_5");
            if (subgrid) {
                subgrid.refresh();
            }
        });
    },
    openQuestionInPopup: function (primaryControl) {
        var id = primaryControl.data.entity.getId().replace(/[{}]/g, "");

        Xrm.Navigation.navigateTo({
            pageType: "entityrecord",
            entityName: "lpi_questionframework1",
            data: {
                lpi_functionflowid: id
            }
        }, {
            target: 2,
            position: 1,
            width: { value: 70, unit: "%" },
            height: { value: 80, unit: "%" }
        }).then(function () {
            var grid = primaryControl.getControl("Subgrid_new_6");
            if (grid) grid.refresh();
        });
    },

    filterHeadingSectionLookupInQuickCreate: async function (executionContext) {
        const formContext = executionContext.getFormContext();
        const lookupControl = formContext.getControl("lpi_quickcreatesection");
        const functionalFlowId = (formContext.getAttribute("lpi_functionflowid")?.getValue() || "").replace(/[{}]/g, "");

        if (!lookupControl || !functionalFlowId) {
            return;
        }

        lookupControl.setDisabled(true);

        let ids = [];

        try {
            ids = (await Xrm.WebApi.retrieveMultipleRecords(
                "lpi_headingsection1",
                "?fetchXml=" + encodeURIComponent(
                    "<fetch mapping='logical'>" +
                    "<entity name='lpi_headingsection1'>" +
                    "<attribute name='lpi_headingsection1id' />" +
                    "<filter>" +
                    "<condition attribute='statecode' operator='eq' value='0' />" +
                    "</filter>" +
                    "<link-entity name='lpi_flowsection1' " +
                    "from='lpi_headingsection' " +
                    "to='lpi_headingsection1id'>" +
                    "<filter>" +
                    "<condition attribute='lpi_mainflow' " +
                    "operator='eq' value='" + functionalFlowId + "' />" +
                    "</filter>" +
                    "</link-entity>" +
                    "</entity>" +
                    "</fetch>"
                )
            )).entities.map(function (row) {
                return row.lpi_headingsection1id.replace(/[{}]/g, "");
            });
        } catch (error) {
            ids = [];
        }

        lookupControl.addPreSearch(function () {
            lookupControl.addCustomFilter(
                "<filter type='and'>" +
                "<condition attribute='statecode' operator='eq' value='0' />" +
                (
                    ids.length
                        ? "<condition attribute='lpi_headingsection1id' operator='in'>" +
                        ids.map(function (id) {
                            return "<value>" + id + "</value>";
                        }).join("") +
                        "</condition>"
                        : "<condition attribute='lpi_headingsection1id' operator='null' />"
                ) +
                "</filter>",
                "lpi_headingsection1"
            );
        });

        lookupControl.setDisabled(false);
    }

}