/*-----------------------------------------------------------------------------------------------------
SchemaName: lpi_/webresources/javascript/FunctionFlowMain/FunctionFlowMain.js
DisplayName: FunctionFlowMain.js
CreatedBy: Kalyan
CreatedOn: 23/7/2026
------------------------------------------------------------------------------------------------------*/

var LPI = LPI || {}

LPI.FunctionFlowMain = {
    UserWizardShowTabForActiveStage: function (executionContext) {
        var formContext = executionContext.getFormContext();

        if (!formContext || !formContext.data || !formContext.data.process) {
            return;
        }

        LPI.FunctionFlowMain.ShowHideTabs(executionContext);
        formContext.data.process.addOnStageChange(LPI.FunctionFlowMain.ShowHideTabs);
    },


    ShowHideTabs: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var stage = formContext.data.process.getActiveStage();
        var name = stage ? stage.getName() : "";

        var tabs = {
            "General": ["general_tab"],
            "Sections": ["general_tab", "sections_tab"],
            "Sub Sections": ["general_tab", "sections_tab", "subsections_tab"],
            "Questions": ["general_tab", "sections_tab", "subsections_tab", "questions_tab"],
            "Completed": ["general_tab", "sections_tab", "subsections_tab", "questions_tab", "related_tab"]
        };

        formContext.ui.tabs.get().forEach(function (tab) {
            tab.setVisible(false);
        });

        (tabs[name] || []).forEach(function (tabName) {
            var tab = formContext.ui.tabs.get(tabName);
            if (tab) {
                tab.setVisible(true);
            }
        });

        var currentTabName = (tabs[name] || []).slice(-1)[0];
        var currentTab = currentTabName ? formContext.ui.tabs.get(currentTabName) : null;

        if (currentTab) {
            currentTab.setDisplayState("expanded");
            currentTab.setFocus();
        }
    },

    filterHeadingSectionSubgrid: function (executionContext) {
        return LPI.FunctionFlowMain.filterRelatedSubgrid(executionContext, {
            subgridName: "Subgrid_new_4",
            entityName: "lpi_headingsection1",
            idField: "lpi_headingsection1id",
            linkEntity: "lpi_flowsection1",
            linkFrom: "lpi_headingsection",
            linkTo: "lpi_headingsection1id",
            flowField: "lpi_mainflow"
        });
    },

    filterHeadingSubSectionSubgrid: function (executionContext) {
        return LPI.FunctionFlowMain.filterRelatedSubgrid(executionContext, {
            subgridName: "Subgrid_new_5",
            entityName: "lpi_headingsubsection1",
            idField: "lpi_headingsubsection1id",
            linkEntity: "lpi_flowsubsection1",
            linkFrom: "lpi_subsection",
            linkTo: "lpi_headingsubsection1id",
            flowField: "lpi_flow"
        });
    },

    filterRelatedSubgrid: async function (executionContext, config) {
        var formContext = executionContext.getFormContext();
        var mainFlowId = formContext.data.entity.getId();

        if (!mainFlowId) return;

        mainFlowId = mainFlowId.replace(/[{}]/g, "");

        var subgrid = await LPI.FunctionFlowMain.waitForSubgrid(formContext, config.subgridName);
        if (!subgrid) return;

        var fetchXml =
            "<fetch version='1.0' mapping='logical'>" +
            "<entity name='" + config.entityName + "'>" +
            "<attribute name='" + config.idField + "' />" +
            "<filter type='and'>" +
            "<condition attribute='statecode' operator='eq' value='0' />" +
            "</filter>" +
            "<link-entity name='" + config.linkEntity + "' from='" + config.linkFrom + "' to='" + config.linkTo + "'>" +
            "<filter type='and'>" +
            "<condition attribute='" + config.flowField + "' operator='eq' value='" + mainFlowId + "' />" +
            "</filter>" +
            "</link-entity>" +
            "</entity>" +
            "</fetch>";

        var result = await Xrm.WebApi.retrieveMultipleRecords(
            config.entityName,
            "?fetchXml=" + encodeURIComponent(fetchXml)
        );

        var ids = result.entities.map(function (row) {
            return row[config.idField];
        });

        var values = "";
        for (var i = 0; i < ids.length; i++) {
            values += "<value>" + ids[i] + "</value>";
        }
        if (ids.length > 0) {
            var filterXml =
                "<filter type='and'>" +
                "<condition attribute='statecode' operator='eq' value='0' />" +
                "<condition attribute='" + config.idField + "' operator='in'>" +
                values +
                "</condition>" +
                "</filter>";

            subgrid.setFilterXml(filterXml);
        } else {
            subgrid.setFilterXml(
                "<filter type='and'>" +
                "<condition attribute='statecode' operator='eq' value='0' />" +
                "<condition attribute='" + config.idField + "' operator='null' />" +
                "<condition attribute='" + config.idField + "' operator='not-null' />" +
                "</filter>"
            );
        }

        subgrid.refresh();

    },

    waitForSubgrid: function (formContext, subgridName) {
        return new Promise(function (resolve) {
            var attempts = 0;
            var timer = window.setInterval(function () {
                var subgrid = formContext.getControl(subgridName);

                if (subgrid) {
                    window.clearInterval(timer);
                    resolve(subgrid);
                    return;
                }

                attempts++;
                if (attempts >= 20) {
                    window.clearInterval(timer);
                    resolve(null);
                }
            }, 500);
        });
    },
    toggleSection: function (executionContext) {
        var formContext = executionContext.getFormContext();

        var AddExistingSections = formContext.getAttribute("lpi_addexistingsections")?.getValue() ?? false;
        var AddExistingSubSections = formContext.getAttribute("lpi_addexistingsubsections")?.getValue() ?? false;
        var AddExistingQuestions = formContext.getAttribute("lpi_addexistingquestion")?.getValue() ?? false;


        formContext.ui?.tabs.get("sections_tab")?.sections.get("sections_tab_section_3")?.setVisible(AddExistingSections);
        formContext.ui?.tabs.get("subsections_tab")?.sections.get("subsections_tab_section_3")?.setVisible(AddExistingSubSections);
        formContext.ui?.tabs.get("questions_tab")?.sections.get("questions_tab_section_3")?.setVisible(AddExistingQuestions);
    }


};
