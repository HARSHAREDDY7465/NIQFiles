/*-----------------------------------------------------------------------------------------------------
SchemaName: lpi_/webresources/javascript/feedetails/feedetailsform.js
DisplayName: FeeDetailFrom.js
CreatedBy: Ram Prakash
CreatedOn: 23/7/2026
------------------------------------------------------------------------------------------------------*/

var LPI = LPI || {}
LPI.FeeDetailFrom = {
    "EntityDefination": {
        "Tabs": {

        },
        "Sections": {

        },
        "Subgrid": {

        },
        "Entity": {
            "EntitySchemaName": "",
            "EntityPluralname": "",
            "Fields": {
            }
        }
    },
    OnFormLoad: function (executionContext) {
        //Call All On load Form Functions

    },
    OnFormSave: function (executionContext) {
        //Call All On Form Save Functions

    },
    // Added by Ram Prakash
    onFeeTemplateChange: function (executionContext) {
        // Get the form context
        var formContext = executionContext.getFormContext();

        // Get the lookup attribute value
        var lookupAttribute = formContext.getAttribute("lpi_feetemplate");

        if (lookupAttribute != null && lookupAttribute.getValue() != null) {
            var lookupValue = lookupAttribute.getValue();

            var recordId = lookupValue[0].id; // Extract GUID
            var entityName = lookupValue[0].entityType; // Extract Entity Name

            // Retrieve the currency value from the parent template record
            Xrm.WebApi.retrieveRecord(entityName, recordId, "?$select=lpi_feeamount").then(
                function success(result) {
                    // Check if the currency field has a value on the parent record
                    if (result != null && result.lpi_feeamount != null) {
                        // Set the currency value on the Quick Create form (expects a float/decimal number)
                        formContext.getAttribute("lpi_feeamount").setValue(Number(result.lpi_feeamount));
                    } else {
                        formContext.getAttribute("lpi_feeamount").setValue(null);
                    }
                },
                function error(error) {
                    console.error("Error retrieving fee template data: " + error.message);
                }
            );
        } else {
            // Clear the target currency field if the lookup is cleared
            formContext.getAttribute("lpi_feeamount").setValue(null);
        }
    }

}