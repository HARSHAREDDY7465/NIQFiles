/*-----------------------------------------------------------------------------------------------------
SchemaName: lpi_/webresources/javascript/license/licensesform.js
DisplayName: LicensesForm.js
CreatedBy: Deepak Kumar
CreatedOn: 24/6/2026
------------------------------------------------------------------------------------------------------*/


var LPI = LPI || {}
LPI.LicenseForm = {
    "EntityDefination": {
        "Tabs": {

        },
        "Sections": {

        },
        "Subgrid": {

        },
        "Entity": {
            "EntitySchemaName": "dgps_license",
            "EntityPluralname": "dgps_licenses",
            "Fields": {
            }
        }
    },
    OnFormLoad: function (executionContext) {
        //Call All On load Form Functions
        LPI.LicenseForm.loadWebResources(executionContext);


    },
    OnFormSave: function (executionContext) {
        //Call All On Form Save Functions
        LPI.LicenseForm.saveChecklistDatatoUserResponse(executionContext);


    },

    //Added by deepak
    loadWebResources: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var webresource_control = formContext.getControl("WebResource_allinspectionchecklist");
        if (webresource_control) {
            webresource_control.getContentWindow().then(
                function (contentWindow) {
                    contentWindow.setClientApiContext(Xrm, formContext);
                }
            )
        }

        if (LPI?.Common?.FilePreviewManager) {
            LPI.Common.FilePreviewManager.registerFileChangeEvents(executionContext, { "WebResource_filepreview": "lpi_browsefile" });
            LPI.Common.FilePreviewManager.initializePreviewPages(executionContext, { "WebResource_filepreview": "lpi_browsefile" });
        }
        else {
            console.log("File Preview Manager script file is not loaded");
        }
    },
    saveChecklistDatatoUserResponse: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var draftData = formContext.getAttribute("lpi_inspectionchecklistdraftdata");
        if (draftData != null && draftData != undefined && draftData != "") {
            const data = JSON.parse(draftData.getValue()) || {};
            let updatePromises = [];
            for (const [key, value] of Object.entries(data)) {

                const id = key;

                const isChecked = value["checked"] || "";
                const elementValue = value["val"] || "";
                const remarksText = value["remarks"] || "";

                let updatePayload = {};
                updatePayload["lpi_answer"] = isChecked ? true : false;
                updatePayload["lpi_answertext"] = elementValue;
                updatePayload["lpi_remarks"] = String(remarksText);

                let requestPromise = Xrm.WebApi.updateRecord("lpi_d365userresponse", id, updatePayload).catch(
                    err => {
                        console.error(`Fault details on entry submission thread: ${id}`, err.message);
                        return { error: true, id: id };
                    }
                );
                updatePromises.push(requestPromise);
            }
            Promise.all(updatePromises).then(results => {
                const validationError = results.filter(r => r && r.error);
                if (validationError.length === 0) {

                } else {
                    statusText.textContent = `Error: ${validationError.length} rows failed submission`;
                }
            });
        }
    }
}