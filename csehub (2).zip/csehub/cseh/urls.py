"""cseh URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from csehub import views,retrive
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home,name='home'),
    path('shome/',views.shome,name='shome'),
    path("thome/",views.thome,name='thome'),
    path("hhome/",views.hhome,name='hhome'),
    path('loginreg/',views.tealogin,name='loginreg'),
    path('stuloginreg/',views.stulogin,name='stuloginreg'),
    path('about/',views.about,name='about'),
    path('faqform',views.faqform,name='faqform'),
    path('reg',views.reg,name='reg'),
    path('registration',views.registration,name='registration'),
    path('login1',views.login1,name='login1'),
    path('tlogin',views.tlogin,name='tlogin'),
    path("LogoutForm/",views.logoutform),
    path("assform",views.assignmentform,name='assform'),
    path("postform/",views.postsform,name='postform'),
    path("leaveform/",views.leaveform,name='leaveform'),
    path('examples',views.examples,name='examples'),
    path('taphome/',views.taphome,name='taphome'),
    path('taphome/TAPform',views.TAPform,name='TAPform'),
    path('home',views.logoutform,name='LogoutForm'),
    path('taploginpage',views.taploginpage,name='taploginpage'),
    path('taplogin',views.taplogin,name='taplogin'),
    path('resetpage/',views.resetpage,name='resetpage'),
    path('resetform',views.resetform,name='resetform'),
    path('refbase/',views.refbase,name='refbase'),
    path('ref1/',views.ref1,name='ref1'),
    path('ref2/',views.ref2,name='ref2'),
    path('studetails',views.studetails,name='studetails'),
    path('teacherdetails',retrive.teacherdetails,name='teacherdetails'),
    path("stdet",views.studetails,name='rollno'),
    path("teadet",views.staffdetails,name='teadet'),
    path("stdet/<str:rollno>",retrive.studetails,name='roll'),
    path("CSE", retrive.cse,name='CSE'),
    path('viewdetails',retrive.Viewdetails,name="viewdetails"),
    path('assignments',retrive.assignments,name='assignments'),
    path('assdetails', retrive.assdetails, name='assdetails'),
    path('updateform_assignment/<str:pk>/',retrive.update_assignment,name='updateform_assignment'),
    path('delete_assignment/<str:pk>/', retrive.delete_assignment, name='delete_assignment'),
    path('update_attendance/<str:pk>/',retrive.update_attendance,name='update_attendance'),
    path('update_teacher/<str:pk>/',retrive.update_teacher,name='update_teacher'),
    path('studentform',views.studentform,name='studentform'),
    path('teacherform', views.teacherform, name='teacherform'),
    path('tapdetails',retrive.tapdetails,name='tapdetails'),
    path('update_tapdetails/<str:pk>/',retrive.update_tapdetails,name='update_tapdetails'),
    path('delete_tapdetail/<str:pk>/',retrive.delete_tapdetail,name='delete_tapdetail'),
    path('delete_teadetail/<str:pk>/',retrive.delete_teadetail,name='delete_teadetail'),
    path('taplogout',views.taplogout,name='taplogout'),
    path('student_assignment_views',retrive.student_assignment_views,name='student_assignment_views'),
    path('students_assdetails',retrive.students_assdetails,name='students_assdetails'),
    path('view_assignment/<str:pk>/',retrive.view_assignment,name='view_assignment'),
    path('view_faq/',retrive.view_faq,name='view_faq'),
    path('view_faqs/<str:pk>/',retrive.view_faqs,name='view_faqs'),

]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL,
                          document_root = settings.STATIC_ROOT)