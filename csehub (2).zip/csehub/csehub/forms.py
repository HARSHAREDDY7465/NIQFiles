from django import forms
from .models import TAP,Assignments,FAQ,Teacher,Student

class tapf(forms.ModelForm):
    class Meta:
        model=TAP
        fields='__all__'
class assif(forms.ModelForm):
    class Meta:
        model=Assignments
        fields='__all__'
class faqf(forms.ModelForm):
    class Meta:
        model=FAQ
        fields='__all__'

class stuf(forms.ModelForm):
    class Meta:
        model=Student
        fields='__all__'

class teaf(forms.ModelForm):
    class Meta:
        model=Teacher
        fields='__all__'