from django.contrib import admin
from .models import TAP,Assignments,FAQ,Student,Teacher
# Register your models here.
admin.site.register(TAP)
admin.site.register(Assignments)
admin.site.register(FAQ)
admin.site.register(Student)
admin.site.register(Teacher)