from django.db import models
# from django.contrib.auth.models import User
# Create your models here.


class TAP(models.Model):
    company=models.CharField(max_length=200,blank=False)
    tap_image=models.ImageField(blank=True,upload_to='TAPimages/%y/%m/%d',null=True)
    company_link=models.CharField(max_length=300,blank=True)
    position_offered=models.CharField(max_length=1000,blank=False)
    Eligibility_Criteria=models.TextField(blank=False)
    Compensation=models.CharField(max_length=1000,blank=False)
    Date_of_recruitment=models.CharField(max_length=10,blank=False)
    venue=models.CharField(max_length=200,blank=False)
    selection_Process=models.CharField(max_length=1000,blank=False)
    Documents=models.CharField(max_length=1000,blank=False)
    Dress_Code=models.CharField(max_length=1000,blank=False)
    note=models.TextField(blank=True)

    def __str__(self):
        return self.company


# teacher's models

class Assignments(models.Model):
    Subject=models.CharField(max_length=200,blank=False)
    date_of_submission=models.CharField(max_length=20,blank=False)
    questions=models.TextField(blank=False)

    Y1 = [
        ('I Year', "I"),
        ('II Year', "II"),
        ('III Year', "III"),
        ('IV Year', "IV"),
    ]
    Year = models.CharField(max_length=100, choices=Y1,blank=True)

    se = [('A', 'A'),
          ('B', 'B'),
          ('C', 'C')]
    section = models.CharField(max_length=5, choices=se, blank=True)

    def __str__(self):
        return self.Subject


# student's models
class FAQ(models.Model):
    Emial=models.EmailField(max_length=254,blank=False)
    Topic=models.CharField(max_length=300,blank=False)
    Question=models.TextField(blank=False)
    def __str__(self):
        return self.Topic

from django.db import models

# Create your models here.
class Student(models.Model):

    Roll_No=models.CharField( max_length = 20,unique = True ,blank=False)

    Surname=models.CharField(max_length=50,blank=False)

    Middlename=models.CharField(max_length=50,blank=True)

    Lastname=models.CharField(max_length=50,blank=False)

    Address=models.TextField(blank=False)

    g1 = [
        ('Male', 'M'),
        ('Female', 'F'),
    ]

    Gender=models.CharField(max_length=100,choices=g1)

    Fathername=models.CharField(max_length=50,blank=False)

    Mothername=models.CharField(max_length=50,blank=False)

    Contact_Info=models.IntegerField(blank=False)

    Email=models.CharField(max_length=50,blank=False)

    dept1=[
        ('CSE',"Computer Science and Engineering"),
    ]
    Department=models.CharField(max_length=100,choices=dept1,blank=False)

    Y1=[
        ('I Year',"I"),
        ('II Year', "II"),
        ('III Year', "III"),
        ('IV Year', "IV"),
    ]
    Year=models.CharField(max_length=100,choices=Y1)

    s1=[
        ("I SEM",'I'),
        ("II SEM",'II'),
    ]
    Semester=models.CharField(max_length=100,choices=s1,blank=False)

    Class_Teacher=models.ForeignKey('Teacher',on_delete=models.SET_NULL,blank=True ,null=True)

    se=[('A','A'),
        ('B','B'),
        ('C','C')]
    section=models.CharField(max_length=5,choices=se,blank=False)

    attendance=models.CharField(max_length=10,blank=True)


    class Meta:
        ordering=["Roll_No"]

    def __str__(self):
        return self.Roll_No+ "--" + self.Lastname + "--- " + self.Year + " ---" + self.Department



class Teacher(models.Model):
    c1=[('HOD','HOD'),
        ('None','None')]

    user=models.CharField(choices=c1,max_length=10,blank=True)

    StaffID=models.CharField(max_length=50, blank=False,unique=True)

    Name = models.CharField(max_length=50, blank=False)

    g1 = [
        ('Male','M'),
        ('Female','F'),
    ]

    Gender = models.CharField(max_length=100,choices=g1)

    Address = models.TextField(blank=False)

    Experience=models.IntegerField(blank=False)

    Qualification=models.TextField(blank=False)

    Contact_info=models.IntegerField(blank=False)

    Email=models.CharField(max_length=50,blank=True)



    def __str__(self):
        return self.Name


class Notification(models.Model):
    College_Name=models.CharField(max_length=500,blank=False)

    Title=models.CharField(max_length=500,blank=False)

    Description=models.TextField(blank=False)

    Image=models.ImageField(blank=True)



