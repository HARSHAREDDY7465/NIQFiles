from django.shortcuts import render,redirect,HttpResponseRedirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import login,logout,authenticate
# from django.urls import reverse

from .models import TAP,Student,Teacher,Assignments
from .forms import tapf,assif,faqf,stuf,teaf
# Create your views here.


# Home pages------------------------------------------------------------------------------------------------------------
def home(request):
    return render(request,'homep.html')

def hhome(request):
    return render(request,'hhome.html')

def shome(request):
    return render(request,'shome.html')

def thome(request):
    return render(request,'thome.html')

def taphome(request):
    return render(request,'taphome.html',{'all':TAP.objects.all()[::-1]})

def about(request):
    return render(request,'about.html')

# Logins,Logout,Reset---------------------------------------------------------------------------------------------------
def tealogin(request):
    return render(request,'log_reg.html')

def stulogin(request):
    return render(request,'stu_log_reg.html')

def registration(request):
    return render(request,'registration.html')

def reg(request):
    user1=request.POST['un']
    pass1=request.POST['pass1']
    pass2=request.POST['pass2']
    if request.user.is_authenticated:
        return HttpResponse("<h1>User Already Registered</h1>")
    else:
        if pass1==pass2:
            User.objects.create_user(username=user1,password=pass1)
            return redirect('/loginreg')
        else:
            return HttpResponse("<h2>Registration not sucessfull Both Passwords doesn't match</h2>")

def login1(request):
    un=request.POST['un']
    ps=request.POST['pass1']
    temp=authenticate(username=un,password=ps)
    if temp is None:
        return HttpResponse("Invalid Username or Password Check it or Register")

    else:
        login(request,temp)
        t2=Student.objects.all()
        l2=[]
        for i in t2:
            l2.append(i.Roll_No)
        if request.user.username in l2:
            return redirect('/shome')

def tlogin(request):
    un=request.POST['un']
    ps=request.POST['pass1']
    temp=authenticate(username=un,password=ps)
    if temp is None:
        return HttpResponse("Invalid Username or Password Check it or Register")

    else:
        login(request, temp)
        det=Teacher.objects.get(StaffID=request.user.username)
        if det.user=='HOD':
            if request.method == "POST":
                return redirect('/hhome')
        else:
            t1=Teacher.objects.all()
            l1=[]
            for i in t1:
                l1.append(i.StaffID)
            if request.user.username in l1:
                return redirect('/thome')

def taplogin(request):
    un = request.POST['un']
    ps = request.POST['pass1']
    temp = authenticate(username=un, password=ps)
    if temp is None:
        return HttpResponse("Invalid Username or Password Check it or Register")

    else:
        login(request, temp)
        if request.user.is_superuser:
            if request.method == "POST":
                return render(request, 'tapupdating.html', {'f1': tapf()})
        else:
            return HttpResponse("The user is not an admin")

def taploginpage(request):
    return render(request,'taplogin.html')

def logoutform(request):
    logout(request)
    return HttpResponseRedirect('/')

def taplogout(request):
    logout(request)
    return redirect('/taphome')

def resetpage(request):
    return render(request,'resetpage.html')

def resetform(request):
    un=request.POST['un']
    ps=request.POST['pass1']
    p=User.objects.get(username=un)
    p.set_password(ps)
    p.save()
    return home(request)

# Forms-----------------------------------------------------------------------------------------------------------------

def assignmentform(request):
    if request.method=="POST":
        form1=assif(request.POST)
        form1.save()
        return HttpResponseRedirect("/thome")
    else:
        return render(request,'assignmentform.html',{'f1':assif()})
    #return render(request,'tapupdating.html')

def postsform(request):
    if request.method=="POST":
        form1=postf(request.POST)
        form1.save()
        return HttpResponse("Data saved")
    else:
        return render(request,'postform.html',{'f1':postf()})
    #return render(request,'tapupdating.html')

def leaveform(request):
    if request.method=="POST":
        form1=leavef(request.POST)
        form1.save()
        return redirect('/thome')
    else:
        return render(request,'leaveform.html',{'f1':leavef()})
    #return render(request,'tapupdating.html')

def TAPform(request):
    if request.method=="POST":
        form1=tapf(request.POST,request.FILES)
        form1.save()
        logout(request)
        return redirect('/tapdetails')
    else:
        return render(request,'tapupdating.html',{'f1':tapf()})

def faqform(request):
    if request.method=="POST":
        form1=faqf(request.POST)
        form1.save()
        return redirect('/shome')
    else:
        return render(request,'faqform.html',{'f1':faqf()})

def studentform(request):
    if request.method=="POST":
        form1=stuf(request.POST)
        un=request.POST['Roll_No']
        ps=request.POST['Roll_No']
        form1.save()
        User.objects.create_user(username=un, password=ps)
        return HttpResponseRedirect("/CSE")
    else:
        return render(request,'studentform.html',{'f1':stuf()})

def teacherform(request):
    if request.method=="POST":
        form1=teaf(request.POST)
        un=request.POST['StaffID']
        ps=request.POST['StaffID']
        form1.save()
        User.objects.create_user(username=un, password=ps)
        return HttpResponseRedirect("/teacherdetails")
    else:
        return render(request,'teacherform.html',{'f1':teaf()})

# Extra references------------------------------------------------------------------------------------------------------
def refbase(request):
    return render(request,'refbase.html')

def ref1(request):
    return render(request,'ref1.html')

def ref2(request):
    return render(request,'ref2.html')

def examples(request):
    return render(request,'examples.html')

def studetails(request):
    stud=Student.objects.get(Roll_No=request.user.username)
    return render(request,'studetails.html',{'Details':stud})

def staffdetails(request):
    tead=Teacher.objects.get(StaffID=request.user.username)
    return render(request,'teacherprofile.html',{'Details':tead})



