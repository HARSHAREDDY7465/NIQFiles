from django.apps import AppConfig


class CsehubConfig(AppConfig):
    name = 'csehub'
