from django.shortcuts import render,redirect
from .models import Student,Assignments,TAP,FAQ,Teacher
from .forms import assif,tapf,stuf,teaf
from django.contrib.auth.models import User

# Pages open------------------------------------------------------------------------------------------------------------

def cse(request):
   return render(request, 'CSE.html')

def assignments(request):
   return render(request, 'assignments.html')

# Viewdetails--------------------------------------------------------------------------------------------------------

def Viewdetails(request):
    details = None
    year=None
    Section=None
    if request.method == 'POST':
        if bool(request.POST.get('YEAR')=='II Year') and bool(request.POST.get('SECTION')=='A'):
            year = "II Year"
            Section="A"
        elif bool(request.POST.get('YEAR')=='II Year') and bool(request.POST.get('SECTION')=='B'):
            year = "II Year"
            Section="B"
        elif bool(request.POST.get('YEAR')=='II Year') and bool(request.POST.get('SECTION')=='C'):
            year = "II Year"
            Section="C"

        elif bool(request.POST.get('YEAR')=='III Year') and bool(request.POST.get('SECTION')=='A'):
            year = "III Year"
            Section="A"
        elif bool(request.POST.get('YEAR')=='III Year') and bool(request.POST.get('SECTION')=='B'):
            year = "III Year"
            Section="B"
        elif bool(request.POST.get('YEAR')=='III Year') and bool(request.POST.get('SECTION')=='C'):
            year = "III Year"
            Section="C"

        if bool(request.POST.get('YEAR')=='IV Year') and bool(request.POST.get('SECTION')=='A'):
            year = "IV Year"
            Section="A"
        elif bool(request.POST.get('YEAR')=='IV Year') and bool(request.POST.get('SECTION')=='B'):
            year = "IV Year"
            Section="B"
        elif bool(request.POST.get('YEAR')=='IV Year') and bool(request.POST.get('SECTION')=='C'):
            year = "IV Year"
            Section="C"

        details = Student.objects.filter(Department='CSE', Year=year, section=Section)
        return render(request, 'STUDENTDETAILS.html', {'Details': details})

def assdetails(request):
    details = None
    year=None
    Section=None
    if request.method == 'POST':
        if bool(request.POST.get('YEAR')=='II Year') and bool(request.POST.get('SECTION')=='A'):
            year = "II Year"
            Section="A"
        elif bool(request.POST.get('YEAR')=='II Year') and bool(request.POST.get('SECTION')=='B'):
            year = "II Year"
            Section="B"
        elif bool(request.POST.get('YEAR')=='II Year') and bool(request.POST.get('SECTION')=='C'):
            year = "II Year"
            Section="C"

        elif bool(request.POST.get('YEAR')=='III Year') and bool(request.POST.get('SECTION')=='A'):
            year = "III Year"
            Section="A"
        elif bool(request.POST.get('YEAR')=='III Year') and bool(request.POST.get('SECTION')=='B'):
            year = "III Year"
            Section="B"
        elif bool(request.POST.get('YEAR')=='III Year') and bool(request.POST.get('SECTION')=='C'):
            year = "III Year"
            Section="C"

        if bool(request.POST.get('YEAR')=='IV Year') and bool(request.POST.get('SECTION')=='A'):
            year = "IV Year"
            Section="A"
        elif bool(request.POST.get('YEAR')=='IV Year') and bool(request.POST.get('SECTION')=='B'):
            year = "IV Year"
            Section="B"
        elif bool(request.POST.get('YEAR')=='IV Year') and bool(request.POST.get('SECTION')=='C'):
            year = "IV Year"
            Section="C"

        details = Assignments.objects.filter(Year=year, section=Section)
        return render(request, 'ASSDETAILS.html', {'Details': details})

def studetails(request,rollno):
    stud=Student.objects.get(Roll_No=rollno)
    return render(request,'studetails.html',{'Details':stud })

def tapdetails(request):
    details = TAP.objects.all()
    return render(request, 'tapdetails.html', {'Details': details})

def student_assignment_views(request):
    return render(request, 'student assignment view.html')


# Update and Delete-----------------------------------------------------------------------------------------------------

def update_assignment(request,pk):

    assf=Assignments.objects.get(id=pk)
    form = assif(instance=assf)
    if request.method=='POST':
        form=assif(request.POST,instance=assf)
        if form.is_valid():
            form.save()
            return redirect('/assignments')
    context={'form':form}
    return render(request,'Update_form.html',context)

def delete_assignment(request,pk):
    assf = Assignments.objects.get(id=pk)
    if request.method=='POST':
        assf.delete()
        return redirect('/assignments')
    context={'item': assf}
    return render(request,'delete.html',context)

def update_attendance(request,pk):
    stf=Student.objects.get(id=pk)
    form = stuf(instance=stf)
    if request.method=='POST':
        form=stuf(request.POST,instance=stf)
        if form.is_valid():
            form.save()
            return redirect('/CSE')
    context={'form':form}
    return render(request,'Update_attendance.html',context)

def update_tapdetails(request,pk):
    tapfs=TAP.objects.get(id=pk)
    form = tapf(instance=tapfs)
    if request.method=='POST':
        form=tapf(request.POST,request.FILES,instance=tapfs)
        if form.is_valid():
            form.save()
            return redirect('/tapdetails')
    context = {'form': form}
    return render(request, 'Update_tapdetails.html', context)

def delete_tapdetail(request,pk):
    tapfs = TAP.objects.get(id=pk)
    if request.method == 'POST':
        tapfs.delete()
        return redirect('/tapdetails')
    context = {'item': tapfs}
    return render(request, 'delete_tap.html', context)

def delete_teadetail(request,pk):
    teaf=Teacher.objects.get(id=pk)
    u=User.objects.get(username=teaf.StaffID)
    if request.method=='POST':
        u.delete()
        teaf.delete()
        return redirect('/teacherdetails')
    context={'item':teaf}
    return render(request,'delete_teacher.html',context)
# View assignment details-----------------------------------------------------------------------------------------------
def students_assdetails(request):
    details=Student.objects.get(Roll_No=request.user.username)
    assd=Assignments.objects.filter(Year=details.Year,section=details.section)
    context={'Details':assd}
    return render(request, 'student_assdetails.html', context)


def view_assignment(request,pk):
    assin=Assignments.objects.get(id=pk)
    return render(request,'student_view_assdetails.html',{'i': assin})

def view_faq(request):
    return render(request,'view_faq.html', {'Details': FAQ.objects.all()[::-1]})

def view_faqs(request,pk):
    assin=FAQ.objects.get(id=pk)
    return render(request,'view_faqs.html',{'i': assin})

def update_teacher(request,pk):
    stf=Teacher.objects.get(id=pk)
    form = teaf(instance=stf)
    if request.method=='POST':
        form=teaf(request.POST,instance=stf)
        if form.is_valid():
            form.save()
            return redirect('/teacherdetails')
    context={'form':form}
    return render(request,'update_teacher.html',context)

def teacherdetails(request):
    tea=Teacher.objects.all()
    return render(request,'teacherdetails.html',{'Details': tea})
