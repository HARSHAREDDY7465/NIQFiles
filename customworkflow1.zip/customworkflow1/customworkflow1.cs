﻿using System;
using System.Activities;
using System.Runtime.Remoting.Contexts;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

namespace customworkflow1
{
    public class customworkflow1 : CodeActivity
    {
        [RequiredArgument]
        [Input("String input")]
        public InArgument<string> Timeframe { get; set; }

        [Output("String output")]
        public OutArgument<string> StateOutput { get; set; }

        
        protected override void Execute(CodeActivityContext context)
        {
            ITracingService tracingService = context.GetExtension<ITracingService>();

            string timeframe = Timeframe.Get(context);
            tracingService.Trace("Received timeframe: " + (timeframe ?? "NULL"));

            if (string.IsNullOrWhiteSpace(timeframe))
            {
                tracingService.Trace("Error: CityInput is null or empty.");
                throw new InvalidPluginExecutionException("Timeframe cannot be null or empty.");
            }
            if (timeframe.Equals("Immediate", StringComparison.OrdinalIgnoreCase))
            {

                StateOutput.Set(context, "The time Frame of this opportunity is Immediate");
                tracingService.Trace("Received timeframe: " + StateOutput+"1");
            }
            else if (timeframe.Equals("this quarter", StringComparison.OrdinalIgnoreCase))
            {
                StateOutput.Set(context, "The time Frame of this opportunity is this Quarter");
                tracingService.Trace("Received timeframe: " + StateOutput + "2");
            }
            else if (timeframe.Equals("next quarter", StringComparison.OrdinalIgnoreCase))
            {
                StateOutput.Set(context, "The time Frame of this opportunity is next Quarter");
                tracingService.Trace("Received timeframe: " + StateOutput + "3");
            }
            else if (timeframe.Equals("this year", StringComparison.OrdinalIgnoreCase))
            {
                StateOutput.Set(context, "The time Frame of this opportunity is This Year");
                tracingService.Trace("Received timeframe: " + StateOutput + "123");
            }
            else
            {
                tracingService.Trace("Timeframe did not match with any timeframe. Setting StateOutput to empty.");
                StateOutput.Set(context, string.Empty);
            }
            tracingService.Trace("Execution completed successfully.");
        }

    }
}
