from multiprocessing.sharedctypes import Value
from PyQt6.QtWidgets import QApplication, QWidget , QPushButton, QLabel
from PyQt6.QtGui import QIcon , QFont
import sys
from random import randint



class Window(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Simple question")
        self.setWindowIcon(QIcon("logo.ico"))
        self.setGeometry(900,200,  400,350)
        self.create_widgets()

    def create_widgets(self):
        self.btnYes = QPushButton("Yes", self)
        self.btnYes.setGeometry(40,265,80,40)
        self.btnYes.clicked.connect(self.clickedYes)
        self.btnYes.setStyleSheet("background-color:grey")

        self.btnNo = QPushButton("No", self)
        self.btnNo.setGeometry(270,265,80,40)
        self.btnNo.clicked.connect(self.clickedNo)
        self.btnNo.setStyleSheet("background-color:grey")

        self.label = QLabel("Are You Dumb?", self)
        self.label.setGeometry(40,100,400,100)
        self.label.setFont(QFont("Lato",40))
        self.label.setStyleSheet("font-weight: bold")
        self.label.setStyleSheet("font-weight: bold;color:black")

    
    def clickedNo(self):
        height = randint(200,300)
        width = randint(220,310)
        self.btnNo.setGeometry(width,height,80,40)


    def clickedYes(self):
        self.label.setText("I knew it \U0001F923")
        self.label.setGeometry(60,100,400,100)
        self.btnYes.setGeometry(500,500,0,0)
        self.btnNo.setGeometry(500,500,0,0)
        

app = QApplication(sys.argv)
window = Window()
window.show()
sys.exit(app.exec())