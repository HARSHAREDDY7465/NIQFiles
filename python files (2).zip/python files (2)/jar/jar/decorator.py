def decorator(fun):
   def number():
      print("1")
      fun()
      print("3")
      
   return number
@decorator
def sample():
   print("2")

sample()
