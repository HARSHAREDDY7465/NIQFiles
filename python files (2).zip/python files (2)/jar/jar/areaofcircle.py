import math



r=10

print(math.pi*r*r)
print(math.sqrt(2))