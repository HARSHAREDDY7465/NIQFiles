def num(a):
    if a%2 !=0:
        a=a*3+1
        print(a)
        num(a)
    else:
        a=a/2
        print(a)
        num(a)
n=7
num(n) 