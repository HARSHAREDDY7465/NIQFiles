import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
sns.set()

df=pd.read_csv("C:\\Users\HV7\Desktop\datascience\HistoricalPrices (1).csv")


x = pd.to_datetime(df['Date'])

y = df[' opening price']

ydata = y 

plt.figure(figsize=(8,6))
plt.plot(x, ydata, 'g^')
plt.plot(x,y, 'r') 
plt.title("scatter plot")
plt.ylabel('volume')
plt.xlabel('date')
plt.show()
