
import cv2
from random import randrange

video = cv2.VideoCapture(0)

trained_face_data = cv2.CascadeClassifier('C:\\Users\HV7\Desktop\haarcascade_fullbody.xml')

classifier_file ='C:\\Users\HV7\Desktop\car_detector.xml'

car_tracker = cv2.CascadeClassifier(classifier_file)

while True:
    read_successful, frame =video.read()

    if read_successful:
        grayscaled_img = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    else:
        break

    car_cordins = car_tracker.detectMultiScale(grayscaled_img)
    people = trained_face_data.detectMultiScale(grayscaled_img)

    for (x,y,w,h) in car_cordins:
        cv2.rectangle(frame, (x+1 , y+2),(w+x , h+y) , (255,0,0), 2)
        cv2.rectangle(frame, (x , y),(w+x , h+y) , (0,0,255), 2)
        
    for (x,y,w,h) in people:
            cv2.rectangle(frame, (x , y),(w+x , h+y) , (0,255,255), 2)

    cv2.imshow('video car and people detection',frame)

    key = cv2.waitKey(1)

    if key==81 or key==113:
        break

video.release()
