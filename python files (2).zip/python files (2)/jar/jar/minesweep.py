# l=[
#     [0,1,0,1,0,0],
#     [1,0,0,0,1,0],
#     [0,0,1,1,0,0],
#     [0,1,0,0,1,0],
#     [1,0,1,0,1,1],
#     [0,0,0,1,0,0]
# ]
l=[
    [0,1,0],
    [0,1,0],
    [0,0,0]
]
r=len(l)
k=len(l[0])
for i in range(r):
    for j in  range(k):
        if l[i][j]==1:
            l[i][j]=9
c=0
for i in range(r):
    for j in  range(k):
        if i==0 or j==0 or i==k-1 or j==k-1:
            if i==0 and j==0:
                if l[i][j]!=9:
                    for m in range(0,2):
                        for n in range(0,2):
                            if l[i+m][j+n]==9:
                                c+=1
                    l[i][j]=c
                    c=0
            elif i==k-1 and j==k-1:
                 if l[i][j]!=9:
                    for m in range(-1,1):
                        for n in range(-1,1):
                            if l[i+m][j+n]==9:
                                c+=1
                    l[i][j]=c
                    c=0
            elif i==0 and j==k-1:
                 if l[i][j]!=9:
                    for m in range(0,2):
                        for n in range(-1,0):
                            if l[i+m][j+n]==9:
                                c+=1
                    l[i][j]=c
                    c=0
            elif i==k-1 and j==0:
                 if l[i][j]!=9:
                    for m in range(-1,1):
                        for n in range(0,2):
                            if l[i+m][j+n]==9:
                                c+=1
                    l[i][j]=c
                    c=0
            elif i>0 and j==0:
                 if l[i][j]!=9:
                    for m in range(-1,2):
                        for n in range(0,2):
                            if l[i+m][j+n]==9:
                                c+=1
                    l[i][j]=c
                    c=0
            elif i==0 and j>0:
                 if l[i][j]!=9:
                    for m in range(-1,1):
                        for n in range(-1,2):
                            if l[i+m][j+n]==9:
                                c+=1
                    l[i][j]=c
                    c=0
            elif i>0 and j>0:
                try:
                 if l[i][j]!=9:
                    for m in range(-1,2):
                        for n in range(-1,1):
                            if l[i+m][j+n]==9:
                                c+=1
                    l[i][j]=c
                    c=0
                except:
                    if l[i][j]!=9:
                        for m in range(-1,0):
                            for n in range(-1,1):
                                if l[i+m][j+n]==9:
                                    c+=1
                        l[i][j]=c
                        c=0     
        else:
            
            if l[i][j]!=9:
                for m in range(-1,2):
                    for n in range(-1,2):
                        if l[i+m][j+n]==9:
                            c+=1
                l[i][j]=c
                c=0            
print(l)
