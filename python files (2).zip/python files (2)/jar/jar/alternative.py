def alter(s):
    l=[]
    a=""
    for i in range(len(s)):
        if i==len(s)-1:
            if(int(s[i-1])%2==0 and int(s[i])%2!=0) or (int(s[i-1])%2!=0 and int(s[i])%2==0):
                a+=s[i]
                l.append(a)
            else:
                pass

        elif (int(s[i])%2==0 and int(s[i+1])%2!=0) or (int(s[i])%2!=0 and int(s[i+1])%2==0):
            a+=s[i]
            
        else:
            if(int(s[i-1])%2==0 and int(s[i])%2!=0) or (int(s[i-1])%2!=0 and int(s[i])%2==0):
                a+=s[i]
            l.append(a)
            a="" 
    m=[]
    for i in l:
        m.append(len(m))
    i=m.index(max(m))
    return l[i] 
s=input()
print(alter(s))

