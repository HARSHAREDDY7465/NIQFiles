import os
import random
import smtplib

def auto_email():
    user="harsha"
    email="harshareddy22639@gmail.com"
    message="l;rkjglskdgoirejglksdjg;lakgj"
    s=smtplib.SMTP('smtp.gmail.com',587)
    s.starttls()
    s.login("harshavoruguntla@gmail.com","Harsha226399")
    s.sendmail('jskdgjnlkdiersakd',email,message)
    print("mail sent")

auto_email()