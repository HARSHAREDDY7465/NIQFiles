# permissions to download the datasets from the internet
import ssl
ssl._create_default_hhtps_context = ssl._create_unverified_context

import tensorflow as tf
import numpy as np
from tensorflow import keras

import matplotlib.pyplot as plt

# load a pre-defined dataset 
fashion_mnist = keras.datasets.fashion_mnist

# pull out the data form dataset
(train_images, train_labels), (test_images, test_labels) = fashion_mnist.load_data()

# show the data
# for i in range(10):
plt.imshow(train_images[0], vmin=0, vmax=255)
plt.show()

# define neural network structure
model = keras.Sequential([

    # input is a 28*28 image("flatten" flattens the 28*28 into single 784*1 input layer)
    keras.layers.Flatten(input_shape=(28,28)),

    # hidden layer is 128 deep. relu returns the value or 0(works good enough. much faster)
    keras.layers.Dense(units=128, activation=tf.nn.relu),

    # output is 0-10(depending on what piece of clothing it is). return maximum
    keras.layers.Dense(units=10, activation=tf.nn.softmax)
])

# compile model
model.compile(optimizer=tf.optimizers.Adam(), loss='sparse_categorical_crossentropy')

# train model using the dataset
model.fit(train_images, train_labels, epochs=5)

# test out model using our testing data
test_loss = model.evaluate(test_images, test_labels)

# make predictions
predictions = model.predict(test_images)

print(predictions[0])
# print predictions
# print(list(predictions[1].index(max(predictions[1]))))

# print the correct answer
print(test_labels[1])
