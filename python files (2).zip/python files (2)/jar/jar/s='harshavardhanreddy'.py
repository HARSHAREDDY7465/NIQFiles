import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import PatternFill

df1 = pd.read_excel("C:\\Users\HV7\Desktop\sampleone.xlsx", sheet_name="Sheet1")

df2 = pd.read_excel("C:\\Users\HV7\Desktop\sampleone.xlsx", sheet_name="Sheet2")

# Compare the columns and create a Boolean mask indicating where the substring is present
mask = df1['name'].astype(str).str.contains("substring")

# Update the DataFrame with the Boolean mask
df1.loc[mask, "name"] = "substring"

# Save the changes to the Excel file
writer = pd.ExcelWriter("sampleone.xlsx", engine='openpyxl') 
df1.to_excel(writer, index=False, sheet_name='Sheet1')
df2.to_excel(writer, index=False, sheet_name='Sheet2')

# Get a reference to the workbook and the worksheet
workbook = writer.book
worksheet = writer.sheets['Sheet1']


fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")

for row in worksheet.iter_rows(min_row=2, max_col=1, max_row=worksheet.max_row, values_only=True):
    for cell in row:
        if cell == "substring":
            worksheet.cell(row=row[0], column=1).fill = fill

workbook.save("sampleone.xlsx")
