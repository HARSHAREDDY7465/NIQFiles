import cv2
from random import randrange
import numpy as np

img=cv2.imread("")

trained_face_data = cv2.CascadeClassifier('C:\\Users\HV7\Desktop\haarcascade_frountalface_default.xml')
smile_data = cv2.CascadeClassifier('C:\\Users\HV7\Desktop\haarcascade_smile.xml')

# img = cv2.imread(r'C:\\Users\HV7\Desktop\jdk.jpg')
# webcam= cv2.VideoCapture("videopath.mp4")
webcam= cv2.VideoCapture(0)

while True:

    successful_frame_read, frame = webcam.read()

    if not successful_frame_read:
        break

    grayscaled_img = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    face_cordins = trained_face_data.detectMultiScale(grayscaled_img)


    for (x,y,w,h) in face_cordins:
        cv2.rectangle(frame, (x , y),(w+x , h+y) , (randrange(128,256) , randrange(128,256), randrange(256)), 2)

        the_smile_cordins =frame[y:y+h , x:x+w]
        # the_smile_cordins = (x,y,w,h)
        grayscaled_face = cv2.cvtColor(the_smile_cordins, cv2.COLOR_BGR2GRAY)
        smile_cordins = smile_data.detectMultiScale(grayscaled_face, scaleFactor=1.7, minNeighbors=20)

        eye_data = cv2.CascadeClassifier('C:\\Users\HV7\Desktop\haarcascade_eye.xml')
        eye_cordins = eye_data.detectMultiScale(grayscaled_face)
        
        # for (x,y,w,h) in smile_cordins:
        #         cv2.rectangle(the_smile_cordins, (x , y),(w+x , h+y) , (0 , 255, 0), 2)
        # for (x_,y_,w_,h_) in eye_cordins:
            # cv2.rectangle(the_smile_cordins, (x_ , y_),(w_+x_ , h_+y_) , (255 , 255, 255), 2)        

        if len(smile_cordins)>0:
            cv2.putText(frame,'smiling',(x,y+h+40), fontScale=2, fontFace=cv2.FONT_HERSHEY_COMPLEX_SMALL, color=(255,255,255))

        # if len(eye_cordins)>0:
        #     cv2.putText(frame,'un-asian-ified',(x,y+h+90), fontScale=2, fontFace=cv2.FONT_HERSHEY_COMPLEX_SMALL, color=(255,255,255))

    # for (x,y,w,h) in smile_cordins:
    #     cv2.rectangle(frame, (x , y),(w+x , h+y) , (0 , 255, 0), 2)

    cv2.imshow('smile face detection',frame)

    key = cv2.waitKey(1)

    if key==81 or key==113:
        break

webcam.release()
