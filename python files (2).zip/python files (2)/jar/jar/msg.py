import pywhatkit as kit
number='+919182142821'
kit.sendwhatmsg(
    number,
    'hi',17,35
)
