import cv2

from random import randrange

img_file = 'C:\\Users\HV7\Desktop\images.jpg'

classifier_file ='C:\\Users\HV7\Desktop\car_detector.xml'

img = cv2.imread(img_file)

car_tracker = cv2.CascadeClassifier(classifier_file)

grayscaled_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

car_cordins = car_tracker.detectMultiScale(grayscaled_img)

for (x,y,w,h) in car_cordins:
    cv2.rectangle(img, (x , y),(w+x , h+y) , (randrange(128,256) , randrange(128,256), randrange(256)), 2)

cv2.imshow('car detection',img)

cv2.waitKey()
