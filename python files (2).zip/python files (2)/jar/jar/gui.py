import pyautogui as gui

gui.sleep(5)

for i in range(10):
    gui.write("hi")
    gui.sleep(0.8)
    gui.press("enter")
