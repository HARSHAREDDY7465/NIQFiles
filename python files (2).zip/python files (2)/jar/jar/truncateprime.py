def prime(n):
    if n==1:
        return False
    for i in range(2,n):
        if n%i==0:
            return False
        else:
            pass
    return True

def left(l):
    if '0' in l:
        return False
    while len(l)!=0:
        a=""
        for i in l:
            a+=i
        a=int(a)
        
        if prime(a):
            l.pop(0)
            pass
        else:
            return False
    return True
def right(m):
    if '0' in m:
        return False
    while len(m)!=0:
        a=""
        for i in m:
            a+=i
        a=int(a)
        
        if prime(a):
            m.pop()
            pass
        else:
            return False
    return True
n=11

n=str(n)
l=[]
m=[]
for i in n:
    l.append(i)
    m.append(i)

lef=left(l)
rig=right(m)
if lef==True and rig==True:
    print("both")
elif lef==False and rig==True:
    print("right")
elif lef==True and rig==False:
    print("Left")
else:
    print("False")

    

