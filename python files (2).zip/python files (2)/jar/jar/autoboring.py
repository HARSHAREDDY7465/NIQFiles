import random
import pyautogui
pyautogui.sleep(3)
l=['lk','mg','fof']
for i in range(5):
    pyautogui.write(random.choice(l))

    pyautogui.sleep(0.8)
    pyautogui.press('enter')

