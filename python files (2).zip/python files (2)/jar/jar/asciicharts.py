n={'Q1':300, 'Q2':150, 'Q3':0 }
n=sorted(n.items(), key=lambda item: item[1], reverse=True)
n=dict(n)
l=[]
for i in n:
    l.append(int(n[i]/50))
k=0
for i in n:
    print(i+'|',end="")

    for j in range(l[k]):
        print('#',end="")
    if l[k]!=0:
        print("",end=" ")
        print(n[i])
        k+=1
    else:
        print(n[i])
        k+=1

