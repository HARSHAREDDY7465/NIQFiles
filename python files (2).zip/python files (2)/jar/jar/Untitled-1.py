a=int(input())
l1=[]
l2=[]
for i in range(a):
    n,m=map(int,input().split())
    l1.append(n)
    l2.append(m)
for i in range(a):
    res=l1[i]*l2[i]
    if l1[i]>1000:
        d=res*0.1
        print(float(res-d))
    else:
        print(float(res))
