from collections import deque
def kill(a,n):
    l=[]
    dq= deque(a)
    while(len(dq)>0):
        dq.rotate(-n)
        l.append(dq.pop())
    print(l[-1])
kill([0,1,2,3,4,5,6,7,8],3)
