import pyautogui as p

p.sleep(3)

for i in range(10):
    p.write("f0ff")
    p.sleep(0.8)
    p.press("enter")
