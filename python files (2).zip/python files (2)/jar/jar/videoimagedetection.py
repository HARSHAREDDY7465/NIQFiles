import cv2
from random import randrange

img=cv2.imread("")

trained_face_data = cv2.CascadeClassifier('C:\\Users\HV7\Desktop\haarcascade_frountalface_default.xml')


# img = cv2.imread(r'C:\\Users\HV7\Desktop\jdk.jpg')
# webcam= cv2.VideoCapture("videopath.mp4")
webcam= cv2.VideoCapture(0)

while True:

    successful_frame_read, frame = webcam.read()

    grayscaled_img = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    face_cordins = trained_face_data.detectMultiScale(grayscaled_img)

    for (x,y,w,h) in face_cordins:
        cv2.rectangle(frame, (x , y),(w+x , h+y) , (randrange(128,256) , randrange(128,256), randrange(256)), 2)

    cv2.imshow('video face detection',frame)

    key = cv2.waitKey(1)

    if key==81 or key==113:
        break

webcam.release()

'''
grayscaled_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

face_cordins = trained_face_data.detectMultiScale(grayscaled_img)

# cv2.rectangle(img, (102 , 29),(73+102 , 73+29) , (0, 255, 0), 2)

for (x,y,w,h) in face_cordins:
    cv2.rectangle(img, (x , y),(w+x , h+y) , (randrange(128,256) , randrange(128,256), randrange(256)), 2)


# print(face_cordins)

cv2.imshow('face detection',img)
'''



