import turtle
t=turtle.Turtle()
t.speed(10)

t.rt(90)
t.fd(100)
t.lt(60)
t.fd(60)
t.lt(60)
t.fd(60)
t.lt(60)
t.fd(100)

t.circle(52,extent = 180)

