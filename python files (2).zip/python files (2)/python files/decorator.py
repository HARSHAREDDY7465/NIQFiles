def decorator(fun):
   def wrapper():
      print("1")
      fun()
      print("3")
      
   return wrapper
@decorator
def sample():
   print("2")

sample()
