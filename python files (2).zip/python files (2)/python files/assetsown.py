class grandparent:
    def assetsbygrandparent(self):
        a=5000
        return a

class parent(grandparent):
    def assetsbyparent(self):
        b=10000
        return b
    
class child(parent):
    def assetbychild(self):
        ca=20000
        return ca

obj_parent=parent()
obj_child=child()
obj_grandparent=grandparent()

print("assets own by child")
print(obj_child.assetbychild()+
obj_child.assetsbyparent()+
obj_child.assetsbygrandparent())

print("assets own by parent")

print(obj_parent.assetsbygrandparent()+
obj_parent.assetsbyparent())

print("assets own by grandparent")
print(obj_grandparent.assetsbygrandparent())
