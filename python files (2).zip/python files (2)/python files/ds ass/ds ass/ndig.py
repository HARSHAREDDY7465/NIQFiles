n=int(input())
n=str(n)
print("no of digits in the number is:",len(n))
