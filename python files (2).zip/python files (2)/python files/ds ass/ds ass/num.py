s=input()
n=['1','2','3','4','5','6','7','8','9','0','.']
c=0
for i in s:
    if i in n:
        c=c
    else:
        c=c+1
if(c==0):
    print("it is a number")
else:
    print("not a number")
