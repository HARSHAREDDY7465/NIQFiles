def rec(n):
    if(n<=1):
        return n
    else:
        return n+rec(n-1)
n=int(input())
if n<0:
    print("enter a +ve number")
else:
    print("the sum is:",rec(n))
