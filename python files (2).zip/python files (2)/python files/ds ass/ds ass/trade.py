import pandas as pd
import matplotlib.pyplot as plt

df=pd.read_csv("C:\\Users\Hv7\Downloads\HistoricalPrices (1).csv")

sd=pd.to_datetime('05/13/22')
ed=pd.to_datetime('07/29/22')

df['Date']=pd.to_datetime(df['Date'])
new_df=(df['Date']>=sd) & (df['Date']<=ed)

df1=df.loc[new_df]
df2=df1.set_index('Date')
plt.figure(figsize=(3,5))

plt.suptitle("Trading volume of stock from 1-4-2021 to 1-5-2021", fontsize=16,color='royalblue')
plt.title("stock prices")

plt.ylabel("Trading volume",fontsize=12,color='green')

df2['Volume'].plot(kind='bar')

plt.xlabel("Date",fontsize=12, color='red')

plt.show()
