s1=set()
s2=set()
for i in range(1,6):
    s1.add(i)
for i in range(3,8):
    s2.add(i)
print("set1:",s1)
print()
print("set2:",s2)
print()
s3=s1|s2
print("union:",s3)
print()
s4=s1&s2
print("intersection:",s4)
print()
if(s3>s4):
    print("s3 is superset of s4")
    print()
elif(s3<s4):
    print("s4 is superset of s3")
    print()
else:
    print("both are same")
    print()
s4.clear()
print("after clearing set s4:",s4)
s10=s1-s2
s11=s2-s1
print(s10,s11)
