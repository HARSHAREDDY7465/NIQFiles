class os:
    def function(self):
        print("i provide many features")
    def main(self):
        print("i am an operating system")

        
class windows(os):
    
    def function(self):
        
        print("i provide friendly user inter face")
class macos(os):
    def function(self):
        print("i provide security")


obj_os=os()
obj_win=windows()
obj_mac=macos()

obj_win.function()
obj_win.main()

obj_mac.function()
obj_mac.main()
