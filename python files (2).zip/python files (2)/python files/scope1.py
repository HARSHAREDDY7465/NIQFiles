def any():
    global c
    c=10
    print(c)
    def add():
        
        c=100
        print(c+10)
        def sub():
            global a
            a=10
            print(c-10)
            
        
        sub()
        
    add()
    
    
any() 
print(a)      


