import pyttsx3
import datetime
import speech_recognition as sr
import webbrowser
import os
import wikipedia
import time
from datetime import date
import  pyjokes
import requests
from GoogleNews import GoogleNews
import  subprocess
from pywinauto import Application
import pyautogui



i=0
j=0
i1=0
gender=''
dic = {"hello": "hello sir ,How are you", "hy": "hello sir ,How are you", "hayy": "Im fine sir "}
engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
a  =voices

engine.setProperty('voice', voices[1].id)  

def my():
    with open("ss","r") as e:
     s=e.readlines()

     speak(s)
     e.close()

def speak(audio):
    engine.say(audio)

    engine.runAndWait()

def me():
    s = "hello {gender} Im jenny " \
        "Created by haarshaa reddy "

    speak(s)
    speak("how can i help you !")

def wishme(s):

    hour = int(datetime.datetime.now().hour)

    if (hour >= 0 and hour < 12):
        speak(f"Good Morning {s}!")

    elif hour >= 12 and hour < 18:
        speak(f"Good AfterNoon {s}!")

    else:
        speak(f"Good Evening{s}!")

    speak(f"Hello {s} How can i help you !")


def opendetiles():
    speak("you want to only see the user details or i should speak")

    s=takecommend()

    if(s=="see"):
       with open("data of user.text","r" ) as e:
        e.readlines()
        print(e)
        e.close()
    else:
        with open("data of user.text","r") as e:
            s = e.readlines()
            print(s)
            speak(s)
            e.close()

def username(s1):
    try:
     speak(f"what i should call you{s1}")
     s=takecommend()
     s=s.replace("call me",'')
     speak(f"helle{s1} ")
     speak(s)
     with open("data of user.text","a") as e:
        st = datetime.datetime.now()
        st1=date.today()
        e.write(f"{s} use me on {st1}at{st} \n ")
        e.close()
        speak(f"how can i help you {s1}")
    except Exception as e:
        speak(f"{s1} i dont understand sir what did you say ")

        username(s1)
def takecommend():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening......")
        r.pause_threshold = 1
        audio = r.listen(source)
    try:
        print("processing your command..........")
        query = r.recognize_google(audio, language='en-in')
        print("You said", query)
    except Exception as e:
        print(e)
        print("say it again please")

        # if e=="recognition connection failed: [Errno 11001] getaddrinfo failed":
        #  speak("There are some suggetion please cheak your internet connection or reapet what did you say")
        return None
    return query

def stoplisting():
    speak("for how much time  you want to stop jenny from listening commands")
    try:
        a = int(takecommend())
        speak("going to sleep for")
        speak(a)
        time.sleep(a)
    except Exception as e:
        speak(" I could not understand what did you say could not got to sleep")
        stoplisting()

def walkupme():
    strftime = datetime.datetime.now().strftime("%H:""%M:""%S")
    speak(f"it is{strftime} you have to wakeup")

def news(str):
  global i
  if i == 0:
      speak(f"ofcourse {str} which news  you want to listen")
  else:
      speak(f"which news you want to listen{str}")

  try:
    s = takecommend().lower()
    s=s.replace('about',"")
    speak("which page you want ot listen")

    s2 = int(takecommend())
    googlenews = GoogleNews()
    googlenews = GoogleNews('en', "2")
    googlenews.search(s)
    googlenews.getpage(s2)
    googlenews.result()
    speak(f" {str} here is news about ")
    speak(s)
    print(googlenews.gettext())
    speak(googlenews.gettext())
  except Exception as s:
      speak(f"could not understand {str} what did  you say  say it again")
      i=1
      news(str)

def me1():
    with open("gg", "r") as e:
        s = e.readlines()
        speak(s)
        e.close()

def jenny():
    global  j
    if j==0:
        speak("")
    else:
        speak("jenny in a sleep mode {gender}")
    try:

     s=takecommend().lower()
     print(s)
     if 'sleep' in s:
        speak("ok {gender} from now jenny is in a sleep mode {gender}")
        jenny()
        j+=1
     elif'woke up'in s or 'wake up' in s:
         speak("ok {gender} it will take some time to get connection to the network")
         main()
     else:
         jenny()
    except Exception as e1:
      jenny()

def into():
    global i1
    global gender
    while (1):
        if i1>0:
            speak("may i know who is you")
    
        try:

            s1 = takecommend().lower()
            s1=s1.replace('im','')
            if 'harsha' in s1:
                gender = 'sir'

            else:
                speak("please identify your self Are you a male of female  !")
                speak("or girl or boy")
                s1 = takecommend().lower()
                if 'male' in s1 or 'boy' in s1:
                    gender = 'sir'
                elif 'female' in s1 or 'girl' in s1:
                    gender = 'mam'
                else:
                    into()
                    i1=+1

            if 'harsha' not in s1:
                username(gender)
                print(gender)
                wishme(gender)
                break
            else:
                print(gender)
                wishme(gender)
                break
        except Exception as e:
            i1=+1
            

def main():
     into()
     while (1):
        clear = lambda: os.system('cls')
        clear()
        try:
            query = takecommend().lower()
            

            if 'wikipedia' in query:
                speak("searching {gender}")
                query = query.replace("wikipedia", "")
                result = wikipedia.summary(query, sentences=2)
                speak("According to wikipedia")
                speak(result)
            

            elif 'open youtube' in query:
                speak("about what you want to search on youtube")
                s = takecommend()
                webbrowser.open("www.youtube.com/results?search_query=" + s + "")

                speak(f"opening youtube {gender}!")
            elif 'open google' in query:
                webbrowser.open("google.com")
                speak(f"opening google{gender} !")

            elif 'time' in query:
                strtime = datetime.datetime.now().strftime("%H:""%M:""%S")
                speak(f"{gender} the time is{strtime}")

            elif 'open code' in query:

                codepath = "C:\Users\HV7\Desktop\jar\jar\jenny.py"
                os.startfile(codepath)
                speak(f"opening vs code {gender}!")
                speak(
                    f"you opened vs code {gender} would like to stop me from listing if yes please said stop listening or don't listen")

            elif 'open brackets' in query:
                codepath = "C:\Program Files (x86)\Brackets\Brackets"
                speak(f"opening brackets {gender}!")
                os.startfile(codepath)
                speak(
                    "you opened another program {gender} would like to stop me from listing if yes please said stop listening or dont listen")

            elif 'open facebook' in query:
                webbrowser.open("facebook.com")
                speak(f"opening Facebook {gender}!")
                speak(
                    f"you opened another program {gender}would like to stop me from listing if yes please said stop listening or dont listen")

            elif 'search' in query:
                s = webbrowser.open(query)

                speak(s)
                speak(
                    f"you opened another program {gender} would like to stop me from listing if yes please said stop listening or dont listen")

            elif 'who is' in query:
                webbrowser.open(query)

            elif 'hello' in query:
                me()
                speak(f"hello {gender} ! How are you")

            elif 'good' in query or 'well' in query or 'excellent' in query :
                speak(f'great to that you are well {gender}')

            elif 'who are you' in query or 'what is your name' in query:
                me()
            elif 'what is your age' in query:
                speak("sorry i dont want tell you that. if you want then ask my boss harsha")
            elif "will you be my gf" in query or "will you be my bf" in query or "will you be my boy friend" in query or "will you be my girl friend" in query:
                speak("I'm not sure about, may be you should ask my boss Harsha")

            elif "how are you" in query:
                speak("I'm fine, glad you me that")

            elif "i love you" in query:
                speak("It's hard to understand")

            elif 'today' in query:
                speak("It is")
                speak(date.today())
                speak("today")

            elif "don't listen" in query or "stop listening" in query:
                speak("ok {gender}")
                jenny()

            elif 'change my name' in query or 'change name' in query:
                s = takecommend()
                speak("Now your name is ")
                speak(s)

            elif 'user detailes' in query:
                opendetiles()

            elif 'about me' in query or 'do you know me'in query:
                speak("what is your name")
                s = takecommend().lower()
                if 'harsha' in s:
                    my()
                else:
                    speak("i dont have your data {gender}")

            elif 'exit' in query:
                speak("Thanks for giving me your time")
                exit()

            elif "who made you" in query or "who created you" in query:
                speak("I have been created by haarshaa reddy.")

            elif 'joke' in query or 'jokes' in query:
                s = pyjokes.get_joke(language='en', category='all')
                speak(s)

            elif "where is" in query:
                query = query.replace("where is", "")
                location = query
                speak("locating ")
                speak(location)
                speak("{gender}")
                webbrowser.open("https://www.google.com/maps/place/" + location + "")

            elif "open outlook" in query:
                speak(f"opening outlook ")
                webbrowser.open("https://outlook.office.com/mail/" )
            
            elif "open mail" in query:
                speak(f"opening outlook ")
                webbrowser.open("https://mail.google.com/mail/u/0/?q=course+hero#inbox/" )

            elif "news" in query:
                news(gender)
                
            elif 'shutdown' in query:
                speak(f"souting down {gender}")
                os.system("shutdown /h")

            elif "restart" in query or "reboot" in query:
                os.system('shutdown /r')

            elif 'help me' in query:
                speak(f"ofcourse {gender}! how can i help you {gender}")
                speak(f'question {gender}!')
                s = takecommend()
                print(s)
                speak(
                    "There are 3 thing that i can do for you sir i can search for it on google or youtube or wikipedia")
                speak(f"where i want you to search {gender}")
                s1 = takecommend().lower()
                if s1 == 'google':
                    speak(f"opening  google {gender}!")
                    webbrowser.open(
                        "www.bing.com/search?q=" + s + "=9d02b0a92caa4bc895c28ea9269d27e6&FORM=ANAB01&PC=ASTS")

                elif s1 == 'youtube' in query:
                    speak(f"opening youtube{gender}!")
                    webbrowser.open("www.youtube.com/results?search_query=" + s + "")

                elif s1 == 'wikipedia' in query:
       
                    speak("Accroding to wikipedia")
                    result = wikipedia.summary(s, sentences=2)

            elif 'play music' in query or "play song" in query or "music" in query:
                speak("Here you go with music")
                speak("you open another programe would you like to sleep mor exit from the program")
                music_dir = "H:\Harsha\music"
                songs = os.listdir(music_dir)
                print(songs)
                random = os.startfile(os.path.join(music_dir, songs[1]))

            elif 'work' in query:
                speak(f"sorry {gender} because of me you face some problem "
                       "sir some time i dont work properly there are some few resone that are low internet connection or some noiese "
                       "that i anble to understand im working on that i will take care you will not face this problem again")

            elif "meet" in query:
                speak(f"hello {gender} !what is your friends name ")
                s = takecommend().lower()
                speak(f"nice to meet you {s} ! have a good day!")

            elif "about harsha" in query:
                speak(
                    f"yes{gender} i know him because of him im able to talk to you he is a very nice person would you like to know more about mister haarshaa")
                s = takecommend().lower()
                if s == "yes" or s=="yeah" or s=="yaa":
                    me1()
                    
                else:
                    speak(f"ok !{gender} thank you for asking about my boss {gender}")


            elif 'open calculator'in query:
                speak("open the calculator")
                subprocess.Popen("C:\\Windows\\System32\\calc")
            elif "write a note"in query or " make a note"in query:
              dd()

            elif 'close'in query:
                speak("closing the window")
                pyautogui.hotkey('alt','f4')

            elif 'minimise the windows 'in query or'minimise the window'in query :
                speak("minimize the window")
                pyautogui.hotkey('Win','d')

            elif 'maximize the windows'in query or'maximize the window'in query :

                speak("maximizing windows")
                pyautogui.hotkey('Win', 'up','up','up')

            elif 'new tab'in query:
                pyautogui.hotkey('ctrl','t')
            
            elif 'open xl'in query or 'open excel'in query:
                pyautogui.press('win')
                pyautogui.press('e')
                pyautogui.press('enter')
            
            elif 'open word'in query:
                pyautogui.press('win')
                pyautogui.press('w')
                pyautogui.press('enter')
            
            elif 'open notepad'in query:
                pyautogui.press('win')
                pyautogui.press('n')
                pyautogui.press('enter')
            
            elif 'open powerpoint'in query:
                pyautogui.press('win')
                pyautogui.write('po')
                pyautogui.press('enter')
            
            elif 'open buddy'in query:
                pyautogui.press('win')
                pyautogui.write('bu')
                pyautogui.press('enter')

            elif 'open snip'in query:
                pyautogui.press('win')
                pyautogui.press('s')
                pyautogui.press('enter')
            
            #elif 'take shot'in query or 'take screenshot'in query:
                #speak('taking the screenshot')
                #pyautogui.hotkey('win','f10')

            elif 'new file'in query:
                speak('opening the new file')
                pyautogui.hotkey('ctrl','n')

            elif 'switch windows'in query or 'change windows' in query:
                speak('switching the windows{gender}')
                pyautogui.hotkey('alt','tab')
                
            elif 'switch tab'in query or 'change tab' in query:
                speak('switching the tab{gender}')
                pyautogui.hotkey('ctrl','tab')

            elif 'new tab'in query:
                speak('opening new tab{gender}')
                pyautogui.hotkey('ctrl','t')


            elif 'volume up' in query:
                speak('volume up {gender}')
                pyautogui.hotkey('volumeup')
            
            elif 'volume down' in query:
                speak('volume down {gender}')
                pyautogui.hotkey('volumedown')

            elif 'pause' in query or 'play'in query:
                speak('ok')
                pyautogui.press('Space')

            elif 'open chrome' in query:
                    speak("opening browser {gender}")                   
                    pyautogui.hotkey('win','1')
                    
            elif 'lock screen' in query or 'lock the screen' in query:
                    speak("locking screen {gender}")                   
                    winpath = os.environ["windir"]
                    os.system(winpath + r'\system32\rundll32 user32.dll, LockWorkStation')
                    quit()
                    

            elif 'open visual code' in query:
                    speak("opening visual code {gender}")
                    pyautogui.hotkey('win','2')
                    

            elif 'open pycharm' in query:
                    speak("opening pycharm {gender}")
                    pyautogui.hotkey('win','4')

            elif 'open python' in query:
                    speak("opening pycharm {gender}")
                    pyautogui.hotkey('win','5')
                    

            elif 'open teams' in query:
                    speak("opening teams {gender}")
                    pyautogui.hotkey('win','3')
                    

            elif 'split left' in query or 'flip left'in query:
                speak("splitting left")
                pyautogui.hotkey('win','left')
                
            elif 'split right'in query or 'flip right'in query:
                speak("splitting right")
                pyautogui.hotkey('win','right')

            elif 'i want to search' in query or 'write'in query:
                speak("ok {gender} please say what you want to write or search {gender}")
                s=takecommend()
                pyautogui.write(s)
                time.sleep(3)
                pyautogui.press('enter')
                
            elif 'up'in query:
                pyautogui.press('up')
                
            elif 'down' in query:
                pyautogui.press('down')
                
            elif 'left' in query:
                pyautogui.press('left')
                
            elif 'right' in query:
                pyautogui.press('right')
                
            elif 'enter'in query:
                pyautogui.press('enter')
                
                
            elif 'click'in query:
                pyautogui.click()
                
            elif 'jenny' in query or 'jenne' in query or 'jenni' in query or 'janny' in query or 'jhonny' in query:
                speak(f"jenny is at your service {gender}")
                
           
        except Exception as s:
            print(s)
            speak(f" i dont understand sir please give repeat the command again {gender}")


def dd():
 while True:
  try:
    speak("what you want to write in a note")
    s = takecommend().lower()
    app = Application().start("notepad.exe")
    app.UntitledNotepad.menu_select("Help->About Notepad")
    app.aboutNotepad.OK.click()
    app.UntitledNotepad.Edit.type_keys(s, with_spaces=True)
    speak("would you like to write more or want to save the file")
    s2=takecommend().lower()
    if 'yes'in s2:
        s3=takecommend()
        app.UntitledNotepad.Edit.type_keys(s3,pyautogui.hotkey('enter') ,with_spaces=True)
        speak("would you like to save this")
        se=takecommend().lower()

        if 'yes'in se:
            app.UntitledNotepad.menu_select("File->save->save")
            speak("please give a name to file")
            time.sleep(5)
            pyautogui.hotkey('ctrl', 's')
            speak("file has been saved")
            break
    elif 'save' in s2:
        app.UntitledNotepad.menu_select("File->save->save")
        speak("please give a name to file")
        time.sleep(5)
        pyautogui.hotkey('ctrl', 's')
        speak("file has been saved")
        break
    speak("would you like to close the windows")
    s1 = takecommend().lowwer()
    if 'yes' in s1:
        speak("ok sir")
        app.UntitledNotepad.menu_select("File->Exit")
        app.Exit.OK.click()
        pyautogui.hotkey('alt','f4')
    elif 'no'in s1:
        break

  except Exception as e:
      speak("i could not understand sir please speak again")
if __name__ == "__main__":

    # jenny()
    main()
