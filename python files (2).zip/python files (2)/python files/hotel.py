def inp():
    print("Main Menu-please select an option:")
    print("1.)Add guest")
    print("2.)Add room")
    print("3.)Add booking")
    print("4.)View bookings")
    print("5.)Quit")
    arg=int(input())
    operations(arg)

def operations(arg):
    
    match arg:
        case 1:
            Addguest()
        case 2:
            Addroom()
        case 3:
            Addbookings()
        case 4:
            viewbookings()
        case 5:
            Quit()
        case default:
            print("invalid choice")
            inp()
guests=[]
def Addguest():
    print("Please enter guest ID")
    g=int(input())
    guests.append(g)
    print("guest added successuly")
    inp()
rooms=[]
def Addroom():
    print("please enter room number")
    r=int(input())
    rooms.append(r)
    print("room added successfully")
    inp()
g=[]

def addgu():
    gu=int(input())
    if gu in guests:
        g.append(gu)
    else:
        print("Guest does not exists.Please enter guest ID")
        addgu()
ro=[]
def addru():
    ru=int(input())
    if ru in rooms:
        ro.append(ru)
    else:
        print("Room does not exists.Please enter guest ID")
        addru()
ngu=[]
def addngu():
    ngus=int(input())
    ngu.append(ngus)
    print("your booking successfully")
    inp()
    
    
def Addbookings():
    print("Please enter guest ID")
    addgu()
    print("Please enter room number:")
    addru()
    print("Please enter number of guests:")
    addngu()
    
def viewbookings():
    print("guest ID",end="  ")
    print("room no",end="  ")
    print("no of guests")
    for i in range(len(g)):
        print(g[i],ro[i],ngu[i])
    inp()
def Quit():
    print("exiting the portal")
if __name__=="__main__":
    inp()
