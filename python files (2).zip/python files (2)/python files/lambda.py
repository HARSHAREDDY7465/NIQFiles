a= lambda a: x*x
print(a(5))
