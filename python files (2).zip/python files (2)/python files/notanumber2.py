n=10
for i in range(n):
    if i==2:
        print("is 2")
        break
    print("is not 2")
        
    
print("not a number 2")
