f=open('sample.txt','r')
f.seek(2)
print(f.readline())

f.close()
