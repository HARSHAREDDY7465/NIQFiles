def ip(s):
    dip=""
    for i in s:
        if(i=='.'):
            dip+="[.]"
        else:
            dip+=i
    return dip
s=input()
print(ip(s))