import re
a=input()
b=input()
if(re.search(a,b)):
    print("present")
else:
    print("not present")
