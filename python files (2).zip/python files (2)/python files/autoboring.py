
import pyautogui
pyautogui.sleep(3)
for i in range(50):
    pyautogui.write('fof')

    pyautogui.sleep(0.8)
    pyautogui.press('enter')

