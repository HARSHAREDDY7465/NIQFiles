﻿using System;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

namespace Customworkflow
{
    public class customwfaction : CodeActivity
    {
        [RequiredArgument]
        [Input("String input")]
        public InArgument<string> CityInput { get; set; }

        [Output("String output")]
        public OutArgument<string> StateOutput { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            ITracingService tracingService = context.GetExtension<ITracingService>();

            if (context == null)
            {
                tracingService.Trace("Error: CodeActivityContext is null.");
                throw new InvalidPluginExecutionException("CodeActivityContext cannot be null.");
            }

            
            string city = CityInput.Get(context);
            tracingService.Trace("Received CityInput: " + (city ?? "NULL"));

        
            if (string.IsNullOrWhiteSpace(city))
            {
                tracingService.Trace("Error: CityInput is null or empty.");
                throw new InvalidPluginExecutionException("CityInput cannot be null or empty.");
            }

            if (city.Equals("NYC", StringComparison.OrdinalIgnoreCase))
            {
                tracingService.Trace("City matched NYC. Setting StateOutput to 'New York'.");
                StateOutput.Set(context, "New York");
            }
            else
            {
                tracingService.Trace("City did not match NYC. Setting StateOutput to empty.");
                StateOutput.Set(context, string.Empty);
            }

            tracingService.Trace("Execution completed successfully.");
        }
    }
}

