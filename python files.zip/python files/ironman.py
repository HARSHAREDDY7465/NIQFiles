import turtle

t=turtle.Turtle()

t.fd(100)
t.lt(80)
t.fd(250)
t.lt(90)
t.circle(90,-60)
t.rt(20)
t.bk(280)
t.lt(60)
t.bk(50)
t.circle(20,-90)
t.bk(100)
t.rt(180)
t.circle(50,60)
t.fd(10)
t.rt(90)
t.fd(40)
t.rt(120)
t.circle(90,180)


