s=input()
a,e,I,o,u=0,0,0,0,0
for i in s:
    if(i=='a' or i=='A'):
        a+=1
    elif(i=='e' or i=='E'):
        e+=1
    elif(i=='i' or i=='I'):
        I+=1
    elif(i=='o' or i=='O'):
        o+=1
    elif(i=='u' or i=='U'):
        u+=1
print("a:",a)
print("e:",e)
print("I:",I)
print("o:",o)
print("u:",u)
