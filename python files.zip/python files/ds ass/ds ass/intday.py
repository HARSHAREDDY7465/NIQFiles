import pandas as pd
d1=pd.date_range('2021-01-01 00:00:00', periods=20, freq='1h10min')
print("Time series with frequency 1h10min:")
print(d1)
