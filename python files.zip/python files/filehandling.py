f=open('C:\\Users\HV7\Desktop\python files\sample1.txt','a+')
f.seek(3)
for i in f.readlines():
    print(i)


f.close()
