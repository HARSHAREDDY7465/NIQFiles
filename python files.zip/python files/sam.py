
def suml(n):
    
    l=[]
    for i in n:
        l.append(int(i))
    s=sum(l)
    if s>9:
        s=str(s)
        suml(s)
        
    else:
        print(s)
n=int(input())
n=str(n)
suml(n)
    