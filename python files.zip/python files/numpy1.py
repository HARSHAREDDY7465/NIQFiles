import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
sns.set()




x = np.arange(-5.0, 5.0, 0.1)

y=x-x
y_noise =  np.random.normal(size=x.size)
ydata = y_noise
plt.plot(x, ydata,  'bo')
plt.plot(x,y, 'r') 
plt.ylabel('Dependent Variable')
plt.xlabel('Indepdendent Variable')
plt.show()