def find(s1,s2):
    m=len(s1)
    n=len(s2)
    j=0
    for i in range((n-m)+1):
        
        for k in range(m):
            
            if(s2[i+j]!=s1[j]):
                j=j+1
                
                
                
                break
        if(j==m):
            return i
    return -1
s1="hard"
s2="harshareddy"
r=find(s1,s2)
if(r==-1):
    print("not present")
else:
    print("present")
        
