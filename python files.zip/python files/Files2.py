from itertools import count


fname=input('Enter file name :')
fhand=open(fname)
count=0
sum=0
for line in fhand:
    if not line.startswith("X-DSPAM-Confidence:"):
        continue
    else:
        count=count+1
        pos=line.find(':')
        value=line[pos+2:]
        value=float(value)
        sum=sum+value
avg=sum/count
print('Average spam confidence:',avg)