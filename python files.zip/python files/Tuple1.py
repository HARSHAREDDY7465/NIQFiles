from itertools import count
from logging import FileHandler


fname=input('Enter file name :')
fhand=open(fname)
hours=[]
for line in fhand:
    if line.startswith('From'):
        if line.startswith('From:'):
            continue
        #pos=line.find(':')
        #hr=line[pos-2:pos]
        #hr=int(hr)
        #hours.append(hr)
        words=line.split()
        time=words[5]
        x=time.split(':')
        hr=x[0]
        hours.append(hr)
counts=dict()
for hour in hours:
    counts[hour]=counts.get(hour,0)+1
print(counts)
newlist=[]
for k,v in counts.items():
    tup=(k,v)
    newlist.append(tup)
newlist=sorted(newlist)
for k,v in newlist:
    print(k,v)