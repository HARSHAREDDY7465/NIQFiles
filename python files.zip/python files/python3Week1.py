print('Hello world')
print('Welcome to python')