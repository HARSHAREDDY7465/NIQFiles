import math
def area(r):
    a=math.pi*r*r
    print("{:.2f}".format(a),end=" ")
    
def c(r):
    c=2*math.pi*r
    print("{:.2f}".format(c),end=" ")

l=list(map(float,input().split()))
print("1:",end="")
for i in l:
    area(i)
print("")
print("2:",end="")
for i in l:
    c(i)
    
