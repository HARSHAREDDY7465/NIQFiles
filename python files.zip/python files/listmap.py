l=list(map(int,input("enter number").split()))
print(l)
