import tkinter as tk
import random

root = tk.Tk()

def key_press(num):
    text.insert(tk.END, num)

keys = [str(num) for num in range(10)]
random.shuffle(keys)

for i in range(10):
    key = keys[i]
    btn = tk.Button(root, text=key, command=lambda num=key: key_press(num))
    btn.grid(row=(i//3)+1, column=i%3)

text = tk.Text(root, height=1)
text.grid(row=0, columnspan=3)

root.mainloop()
