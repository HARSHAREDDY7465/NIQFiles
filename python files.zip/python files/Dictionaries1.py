from itertools import count


fname=input('Enter file name :')
fhand=open(fname)
persons=[]
for line in fhand:
    if line.startswith('From'):
        if line.startswith('From:'):
            continue
        words=line.split()
        persons.append(words[1])
counts={}
for person in persons:
    counts[person]=counts.get(person,0)+1
bigcount=None
bigperson=None
for person,count in counts.items():
    if bigcount is None or count>bigcount:
        bigcount=count
        bigperson=person    
print(bigperson,bigcount)


