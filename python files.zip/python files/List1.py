fname=input('Enter file name :')
fhand=open(fname)
l=[]
for line in fhand:
    line=line.rstrip()
    words=line.split()
    for word in words:
        if word not in l:
            l.append(word)
l.sort()
print(l)