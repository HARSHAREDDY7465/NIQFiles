l=[5,7,11]
m=[]
for i in range(max(l),100000):
    for j in l:
        if i%j!=0:
            break
        else:
            m.append(1)
    if len(m)==len(l):
        print(i)
        break
    else:
        m=[]