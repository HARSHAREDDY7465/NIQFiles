l=[1,2,3,1,2,3,4,5,6,6,7,7]
print(l)

s=set(l)
print(s)