l=[1,2,3,4,5,6]
print(l[2])
print(l[-4])
l[4]=10
print(l)

l.pop()
print(l)

l.append(99)

print(l)


ar=[[1,2,3,4],
    [5,6,7,8],
    [9,10,11,12]]

print(ar[1][1])

print(ar[-1][-1])