a="harsha"
b="reddy"
print(a,b)