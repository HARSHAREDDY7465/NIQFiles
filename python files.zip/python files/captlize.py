a="harSha vardHan reDdy"
print(a.title())
print(a.capitalize() )