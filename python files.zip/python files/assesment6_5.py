text = "X-DSPAM-Confidence:    0.8475"
spos=text.find('.')
str=text[spos-1:]
str=float(str)
print(str)