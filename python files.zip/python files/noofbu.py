



def operations(arg,k):
    
    match arg:
        case 1:
            for i in range(len(k)):
                k[i]=1
        case 2:
            for i in range(len(k)):
                if(i%2==0):
                    k[i]=0
        case 3:
            for i in range(len(k)):
                if(i%2!=0):
                    k[i]=0
        case 4:
            for i in range(len(k)):
                k[i]=0
    return k
        
if __name__=="__main__":
    n=int(input())
    m=int(input())
    l=[]
    for i in range(m):
        j=int(input())
        l.append(j)
    
    res=0
    k=[]
    for i in range(n):
        k.append(1)
            
        
        
    for i in l:
        c=0          
        for i in (operations(i,k)):
            if(i==1):
                c+=1
        print(c)
                   
    
    

    
