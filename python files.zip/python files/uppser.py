l=["USA", "Japan", "France", "Germany", "Italy", "U.K.","Canada"]
k=""
for i in l:
    if l.index(i)!=len(l)-1:
        k+=i.upper()+', '
    else:
        k+=i.upper()
print(k)
    

