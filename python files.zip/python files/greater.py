def findLarger(arr, n):
	
	mid = (n + 1) // 2

	mx = max(arr)


	count = [0]*(mx + 1)

	for i in range(n):
		count[arr[i]] += 1


	for i in range(mx,-1, -1):
		while (count[i] > 0):

			
			count[i] -= 1
			mid -= 1

			print(i, end = " ")
			if (mid == 0):
				break
		if (mid == 0):
			break

n=int(input())
arr=[]
for i in range(n):
    k=int(input())
    arr.append(k)
findLarger(arr, n)

