a= lambda x,y,z: x+y+z
print(a(5,6,7))
