
import re

fhand = open('ActualData.txt')
numlist=[]
for line in fhand:
    line=line.rstrip()
    y=re.findall('[0-9]+',line)
    res = [eval(i) for i in y]
    for i in res:
        numlist.append(i)
#print(len(numlist))
print(sum(numlist))



# alist=[1,2,3]
# blist=[1]
# for i in alist:
#     blist.append(i)

# print(blist)
# print(sum(blist))