class parent:
    def drinker(self):
        print("he is an alcholic")

    def smoking(self):
        print("he is not a smoker")
class child(parent):
    def drinker(self):
        print("he is not an alcholic")

'''obj_parent=parent()
obj_child=child()

obj_child.drinker()
obj_child.smoking()

obj_parent.drinker()
obj_parent.smoking()'''
#kjdskfjbk

class grandfather:
    def grandassets(self):
        a=5000
        print(a)
class father(grandfather):
    def fatherassets(self):
        b=10000
        print(b)
class you(father):
    def assets(self):
        c=20000
        print(c)

'''obj_you=you()
obj_father=father()
obj_grandfather=grandfather()
print("child assets")
obj_you.assets()
obj_you.fatherassets()
obj_you.grandassets()
print("father assets")
obj_father.fatherassets()
obj_father.grandassets()
obj_father.assets()'''



class os:
    def main(self):
        print("I'm an operating system")
    def features(self):
        print("I'm available in many forms")
class windows(os):
    def features(self):
        print("I'm very user friendly")
class macos(os):
    def features(self):
        print("I provide more security")

obj_os=os()
obj_windows=windows()
obj_mac=macos()
print("im os")
obj_os.main()
obj_os.features()
print("im windows")
obj_windows.main()
obj_windows.features()
print("im mac")
obj_mac.main()
obj_mac.features()




