class add:
    def sum(self,i,j):
        print(i+j)
class sub:
    def diff(self,i,j):
        print(i-j)

class divide(add,sub):
    def div(self,i,j):
        print(i/j)


obj_add=add()
obj_sub=sub()
obj_div=divide()

obj_div.sum(5,4)
obj_div.diff(5,4)
obj_div.div(5,4)

obj_sub.div(6,4)
