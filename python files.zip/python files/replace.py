s= "Capgemini"

s=s[::-1]
s=s.replace('a','@')
print(s)
# a=""
# for i in s:
#     if i=='a':
#         a+="@"
#     else:
#         a+=i

# print(a)