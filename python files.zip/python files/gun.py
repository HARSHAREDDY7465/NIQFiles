def gen(a):
    l=[1,2,3,4,5,6,7,8,9]
    for i in l:
        i=i+a
        yield i

def gun():
    a=10
    for i in gen(a):
        print(i*20)
gun()


