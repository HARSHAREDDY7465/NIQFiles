import sys
sys.stdout.write('Hello\n')
sys.stdout.write('Hello\n')