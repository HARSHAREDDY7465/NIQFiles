import tkinter as tk
import random

root = tk.Tk()

# def key_press(num):
#     print(f"You pressed key {num}")
text_box = tk.Text(width=10,height=1)
text_box.grid(column=1,row=0)

keys = [str(num) for num in range(10)]
random.shuffle(keys)

for i in range(10):
    key = keys[i]
    btn = tk.Button(root, text=key, command=lambda num=key: key_press(num))
    btn.grid(row=i//3, column=i%3)

root.mainloop()