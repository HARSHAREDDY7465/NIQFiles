def add():
    a=300
    b=200
    print(a+b)
    def sub():
        x,y=20,10
        print(a-b)
        print(x+y)
    sub()   
add()

