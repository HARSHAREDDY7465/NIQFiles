def decorator(fun):
   def wrapper():
      for i in range(1,11):
         if i==2:
            fun()
         else:
            print(i)

      
   return wrapper
@decorator
def sample():
   print("2")

sample()

