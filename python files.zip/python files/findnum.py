a={0,1,2,3,4,5,6,7,8,9}

n=input()
l=[]

for i in n:
    try:
        i=int(i)
        l.append(i)
    except:
        pass
l.sort()
l=set(l)

if l==a:
    print("yes")
else:
    print("no")
    
        
