a="harsha"
l=[]
for i in a:
    l.append(i)
res=set(l)
r=""
for i in res:
    r+=i
print(r)


using System;
using System.Linq;

class Program {
    static void Main(string[] args) {
        string a = "harsha";
        string r = new string(a.Distinct().ToArray());
        Console.WriteLine(r);
    }
}



using System;
using System.Collections.Generic;

class Program {
    static void Main(string[] args) {
        string a = "harsha";
        List<char> l = new List<char>();
        foreach (char c in a) {
            l.Add(c);
        }
        HashSet<char> res = new HashSet<char>(l);
        string r = "";
        foreach (char c in res) {
            r += c;
        }
        Console.WriteLine(r);
    }
}


using System;

namespace HelloWorld
{
  class Program
  {
    static void Main(string[] args)
    {
     	string a= "harsha";
        string b= "reddy";
        string res = string.Concat(a," ", b);
        Console.Write(res);
       
    }
  }
}

using System;

namespace HelloWorld
{
  class Program
  {
    static void Main(string[] args)
    {
      string a= "harsha";
      string b="reddy";
      string c="harsha";
      bool r= a.Equals(b);
      bool res= a.Equals(c);
      Console.Write(r);
      Console.Write(res);
      
    }
  }
}



using System;

namespace HelloWorld
{
  class Program
  {
    static void Main(string[] args)
    {
      string a= "harsha reddy";
      string[] res= a.Split();
      foreach(var i in res){
       	Console.WriteLine(i);
        }
      
    }
  }
}


using System;

namespace HelloWorld
{
  class Program
  {
    static void Main(string[] args)
    {
      string a= "harsha reddy";
      string r= a.Substring(0,6);
      string res= a.Substring(7,5);
      Console.WriteLine(r);
      Console.WriteLine(res);   
    }
  }
}



using System;
using System.Collections.Generic;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            string a = "ha@#$rsh^&*a@@__re@dd@y";
            string res = "";
            var l = new List<char>()
            {
                '@',
                '#',
                '$',
                '^',
                '_',
                '&',
                '*'
            };
            foreach (var i in a)
            {
                if (l.Contains(i))
                {
                    continue;
                }
                else
                {
                    res += i;
                }
            }

            Console.Write(res);
        }
    }
}



using System;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            string a = "ha57rs4ha1241red7962dy6354625 ";
            string res = "";

            foreach (var i in a)
            {
                if (!Char.IsDigit(i)) 
                {
                    res += i;
                }
            }

            Console.Write(res);
        }
    }
}


using System;

namespace HelloWorld
{
  class Program
  {
    static void Main(string[] args)
    {
      string a="harsha reddy";
      string res = a.ToUpper();
      Console.WriteLine(res);
      string b= "Harsha Reddy";
      string r= a.ToLower();
      Console.WriteLine(r);
      
      string c= a.Substring(0, 1).ToUpper() + a.Substring(1).ToLower();
      Console.WriteLine(c);
      
      string t=System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(a);
      Console.WriteLine(t);
    }
  }
}


using System;

namespace HelloWorld
{
  class Program
  {
    static void Main(string[] args)
    {
      string a= "hrsha redy";
      string res,res1;
      res= a.Insert(1, "a");
      res1=res.Insert(9, "d");
      Console.WriteLine(res1);
    }
  }
}


using System;

namespace HelloWorld
{
  class Program
  {
    static void Main(string[] args)
    {
      string a= "      harsha reddy        ";
      String res= a.Trim();
      Console.WriteLine(res);
    }
  }
}