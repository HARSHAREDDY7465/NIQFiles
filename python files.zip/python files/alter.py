def alter(str1):
    l=[]
    for i in str1:
        l.append(i)
    l=set(l)
    l=list(l)
    
    if len(l)==2:
        i=ord(l[0])
        j=ord(l[1])
        if j==i+1 or j==i-1:
            print('yes')
        else:
            print('no')
    else:
        print('no')
alter(input())
