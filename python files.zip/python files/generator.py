def generator():
    l=[]
    for i in range(100):
        l.append(i)
    for i in l:
        yield i
n=10
for i in generator():
    print('%.2f' % i,end=" \t")
    print(" \t")
    print("{:.2f}".format(i),end="")

