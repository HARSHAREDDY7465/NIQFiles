import turtle
t=turtle.Turtle()
t.speed(2)
t.up()
t.goto(-200,0)
t.down()
t.fd(400)
t.lt(90)
for i in range(1,8):
    if i%2!=0:
        for i in range(8):
            t.fd(50)
            t.lt(90)
            t.fd(50)
            t.lt(90)
            t.fd(50)
            t.lt(180)
    else:
        t.fd(100)
        t.rt(90)
        for i in range(8):
            t.fd(50)
            t.rt(90)
            t.fd(50)
            t.bk(50)
            t.lt(90)
        t.lt(90)
'''for i in range(8):
    t.fd(50)
    t.lt(90)
    t.fd(50)
    t.lt(90)
    t.fd(50)
    t.lt(180)'''
