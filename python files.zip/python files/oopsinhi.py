class dad:
    def smoker(self):
        print("yes he is a chain smoker")
    def drinker(self):
        print("no he is non alcholic")

class child1(dad):
    
    def drinker(self):
        
        print("yes he is alcholic")
        
class child2(dad):
    def smoker(self):
        print("no he is non smoker")


obj_dad=dad()
obj_child=child1()
obj_child2=child2()


obj_child.smoker()
obj_child.drinker()


obj_child2.smoker()
obj_child2.drinker()
