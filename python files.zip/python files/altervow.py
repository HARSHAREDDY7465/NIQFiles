def calspaces(s):
    l=[]
    c=0
    for i in range(len(s)):
        if s[i]==" ":
            c+=1
        try:
            if s[i+1]!=" ":
                l.append(c)
                c=0
        except:
            break
    l=set(l)
    if len(l)==1:
        return True
    else:
        return False

def altervow(s,vow):
    a=""
    for i in s:
        if i!=" ":
            a+=i
    s=a
    if s[0] in vow or s[-1] in vow:
        return False
    else:
        for i in range(1,len(s)):
            if i%2!=0:
                if s[i] in vow:
                    pass
                else:
                    return False
        return True

s=input()
vow=['a','e','i','o','u']
space=calspaces(s)
altervo=altervow(s,vow)

if space== True and altervo==True:
    print("True")
else:
    print("False")
