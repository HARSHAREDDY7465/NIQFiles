import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm
import seaborn as sns
sns.set()

df= pd.read_csv('C:\\Users\HV7\Downloads\real_estate_price_size_year.csv')

y=df['price']
x1=df[['size','year']]
x=sm.add_constant(x1)
res=sm.OLS(y,x).fit()
res.summary()