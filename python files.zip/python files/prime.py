n=int(input('Enter a number : '))
for i in range(2,int(n/2)):
    if n%i==0:
        print('Not Prime number')
        quit()
print('Prime')


