import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
import seaborn as sns
sns.set()


df=pd.read_csv('C:\\Users\HV7\Downloads\real_estate_price_size.csv')

y=df['price']
x1=df['size']
x=sm.add_constant(x1)
res=sm.OLS(y,x).fit()
res.summary()
