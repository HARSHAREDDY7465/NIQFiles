
import pyautogui
pyautogui.sleep(3)
for i in range(5):
    pyautogui.write('hi')

    pyautogui.sleep(0.8)
    pyautogui.press('enter')

