email='pavan.kalyan-cs@capgemini.com'
spos=email.find('@')
print(spos)
lpos=email.find('.com')
print(lpos)
org=email[spos+1:lpos]
print(org)