"""queriespy URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from queries import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('main/', views.main, name='main'),
    path('home/', views.home, name='home'),
    path('login1/', views.login1, name='login1'),
    path('register1/', views.register1, name='register1'),
    path('loginform/', views.loginform, name='loginform'),
    path('registerform/', views.registerform, name='registerform'),
    path('coding/', views.coding, name='coding'),
    path('topics/', views.topics, name='topics'),
    path('postq_co/', views.postq_co, name='postq_co'),
    path('posta_co/', views.posta_co, name='posta_co'),
    path('postq_top/', views.postq_top, name='postq_top'),
    path('posta_top/', views.posta_top, name='posta_top'),
    path('ans_top/', views.ans_top, name='ans_top'),
    path('ans_co/', views.ans_co, name='ans_co'),
    path('about/', views.about, name='about'),
    path('feedback/', views.feedback, name='feedback'),
    path('logout1', views.logout1, name='logout1'),
]
