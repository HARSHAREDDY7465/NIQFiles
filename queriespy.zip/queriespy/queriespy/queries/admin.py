from django.contrib import admin
from .models import postque_co, postans_co, postque_top, postans_top

# Register your models here.
admin.site.register(postans_top)
admin.site.register(postans_co)
admin.site.register(postque_top)
admin.site.register(postque_co)
