from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login, logout, authenticate
from django.contrib import messages
from .models import postque_co, postans_top, postans_co, postque_top
from .forms import postqu_top, postqu_co, postan_top, postan_co
from django.core.paginator import Paginator


def login1(request):

    un = request.POST['un']
    p1 = request.POST['p1']
    temp1 = authenticate(username=un, password=p1)
    if temp1 is None:
        messages.warning(request, "@-- Username or Password is Wrong.   Please Try Again --@")
        return render(request, 'loginform.html')
    else:
        login(request, temp1)
        return render(request, 'home.html')


def register1(request):
    un1 = request.POST['un1']
    p1 = request.POST['p1']
    p2 = request.POST['p2']
    if p1 == p2:
        if User.objects.filter(username=un1).exists():
            messages.warning(request, "@-- User Already Exist. Please Try Again with New Username --@")
            return render(request, 'registerform.html')
        else:
            User.objects.create_user(username=un1, password=p1)
            messages.warning(request, "@--User Created--@")
            return render(request, 'loginform.html')
    else:
        messages.warning(request, "@-- Both Passwords dosen't Match.   Please Try Again --@")
        return render(request, 'registerform.html')


def loginform(request):
    if request.user.is_authenticated:
        return render(request, 'home.html')
    else:
        return render(request, 'loginform.html')


def registerform(request):
    if request.user.is_authenticated:
        messages.warning(request, "@--You Are Already Registered<--@")
        return render(request, 'loginform.html')
    else:
        return render(request, 'registerform.html')


def main(request):
    return render(request, 'main.html')


def home(request):
    return render(request, 'home.html')


def coding(request):
    if 'q' in request.GET:
        q = request.GET['q']
        queco = postque_co.objects.filter(language__icontains=q)
        posts_obj=queco
    else:
        queco = postque_co.objects.all()[::-1]
        paginator = Paginator(queco, 3)
        page_number = request.GET.get('page')
        posts_obj = paginator.get_page(page_number)


    return render(request, 'coding.html', {'Details': posts_obj})


def topics(request):

    if 'q' in request.GET:
        q = request.GET['q']
        quetop = postque_top.objects.filter(topic__icontains=q)

        posts_obj=quetop
    else:
        quetop = postque_top.objects.all()[::-1]
        paginator = Paginator(quetop,3)
        page_number = request.GET.get('page')
        posts_obj = paginator.get_page(page_number)

    return render(request, 'topics.html', {'Details': posts_obj})


def postq_co(request):

    if request.method == "POST":
        form1 = postqu_co(request.POST)
        if form1.is_valid():
            form1.save()
            messages.warning(request, "@-- POSTED SUCCESFULLY --@")
            return redirect('coding')
    else:
        return render(request, 'postque_co.html', {'f1': postqu_co})


def posta_co(request):

    if request.method == "POST":
        form2 = postan_co(request.POST)
        if form2.is_valid():
            form2.save()
            messages.warning(request, "@-- POSTED SUCCESFULLY --@")
            return redirect('coding')
    else:
        return render(request, 'postans_co.html', {'f2': postan_co})


def postq_top(request):

    if request.method == "POST":
        form3 = postqu_top(request.POST)

        if form3.is_valid():
            form3.save()
            messages.warning(request, "@-- POSTED SUCCESFULLY --@")
            return redirect('topics')
    else:
        return render(request, 'postque_top.html', {'f3': postqu_top})


def posta_top(request):

    if request.method == "POST":
        form4 = postan_top(request.POST)
        if form4.is_valid():
            form4.save()
            messages.warning(request, "@-- POSTED SUCCESFULLY --@")
            return redirect('topics')
    else:
        return render(request, 'postans_top.html', {'f4': postan_top})


def ans_co(request):

    if 'q' in request.GET:
        q = request.GET['q']
        ansco = postans_co.objects.filter(language__icontains=q)
        posts_obj = ansco
    else:
        ansco = postans_co.objects.all()[::-1]
        paginator = Paginator(ansco, 3)
        page_number= request.GET.get('page')
        posts_obj = paginator.get_page(page_number)

    return render(request, 'ans_co.html', {'Details': posts_obj})


def ans_top(request):

    if 'q' in request.GET:
        q = request.GET['q']
        anstop = postans_top.objects.filter(topic__icontains=q)

        posts_obj = anstop
    else:
        anstop = postans_top.objects.all()[::-1]

        paginator = Paginator(anstop,3)
        page_number = request.GET.get('page')
        posts_obj = paginator.get_page(page_number)
    return render(request, 'ans_top.html', {'Details': posts_obj})


def about(request):
    return render(request, 'about.html')


def feedback(request):
    return render(request, 'feedback.html')


def logout1(request):
    logout(request)
    messages.warning(request, "@-- Loggedout Successfully --@")
    return render(request, 'main.html')




