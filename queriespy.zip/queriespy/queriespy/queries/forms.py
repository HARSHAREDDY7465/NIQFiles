from django.forms import ModelForm
from .models import postque_top, postans_top, postque_co, postans_co


class postqu_top(ModelForm):
    class Meta:
        model = postque_top
        fields = '__all__'


class postan_top(ModelForm):
    class Meta:
        model = postans_top
        fields = '__all__'


class postqu_co(ModelForm):
    class Meta:
        model = postque_co
        fields = '__all__'


class postan_co(ModelForm):
    class Meta:
        model = postans_co
        fields = '__all__'
