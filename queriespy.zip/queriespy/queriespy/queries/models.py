from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth import login, logout, authenticate



# Create your models here.

class postque_co(models.Model):
    userid = models.CharField(max_length=20, blank=False)
    language = models.CharField(max_length=500, blank=False)
    Error = models.CharField(max_length=500, blank=False)
    Code = models.TextField(max_length=200000, blank=False)
    Other_hints = models.CharField(max_length=500)

    def __str__(self):
        return self.Error


class postans_co(models.Model):
    userid = models.CharField(max_length=20, blank=False)
    language = models.CharField(max_length=500, blank=False)
    Question = models.CharField(max_length=500, blank=False)
    your_code = models.TextField(max_length=200000, blank=False)
    suggestions = models.CharField(max_length=500)

    def __str__(self):
        return self.Question


class postque_top(models.Model):
    userid = models.CharField(max_length=20, blank=False)
    topic = models.CharField(max_length=100, blank=False)
    Question = models.TextField(max_length=500, blank=False)
    hints = models.CharField(max_length=500, blank=False)

    def __str__(self):
        return self.Question


class postans_top(models.Model):
    userid = models.CharField(max_length=20, blank=False)
    topic = models.CharField(max_length=100, blank=False)
    Question = models.CharField(max_length=500, blank=False)
    Answer = models.TextField(max_length=1000, blank=False)
    suggestions = models.CharField(max_length=1000, blank=False)

    def __str__(self):
        return self.Question



