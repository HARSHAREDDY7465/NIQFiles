using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace NielsenIQ.CRM.Plugins
{
    public class OnCreate_ProductRequestPriceListItems : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            try
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity entity &&
                    entity.LogicalName == "niq_productrequestpricelistitems")
                {
                    tracing.Trace("Triggered on niq_productrequestpricelistitems Create");

                    EntityReference priceListRef = entity.GetAttributeValue<EntityReference>("niq_pricelist");
                    EntityReference productRequestRef = entity.GetAttributeValue<EntityReference>("niq_productrequest");

                    if (priceListRef == null || productRequestRef == null)
                        return;

                    Guid priceListId = priceListRef.Id;

                    // Get Price List Name
                    Entity priceListEntity = service.Retrieve("pricelevel", priceListId, new ColumnSet("name"));
                    string priceListName = priceListEntity.GetAttributeValue<string>("name");

                    // Get Referenced Product and Request Type from Product Request
                    Entity productRequest = service.Retrieve("niq_productrequest", productRequestRef.Id, new ColumnSet("niq_referencedproduct", "niq_requesttype", "niq_name"));
                    OptionSetValue requestType = productRequest.GetAttributeValue<OptionSetValue>("niq_requesttype");
                    if (requestType == null || requestType.Value != 610570002)
                    {
                        tracing.Trace($"Request Type is not 610570002 (actual: {requestType?.Value}). Skipping validations.");
                        return;
                    }

                    EntityReference productRef = productRequest.GetAttributeValue<EntityReference>("niq_referencedproduct");
                    string requestName = productRequest.GetAttributeValue<string>("niq_name");
                    if (productRef == null)
                        return;

                    Guid productId = productRef.Id;

                    // --- Condition 1: Check in productpricelevel (Include Product Name) ---
                    string fetchXmlProductPriceLevel = $@"
                        <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                          <entity name='productpricelevel'>
                            <attribute name='productid' />
                            <attribute name='productpricelevelid' />
                            <filter type='and'>
                              <condition attribute='productid' operator='eq' value='{productId}' />
                              <condition attribute='pricelevelid' operator='eq' value='{priceListId}' />
                            </filter>
                            <link-entity name='product' from='productid' to='productid' link-type='inner' alias='prod'>
                              <attribute name='name' />
                            </link-entity>
                          </entity>
                        </fetch>";

                    EntityCollection productLevelResult = service.RetrieveMultiple(new FetchExpression(fetchXmlProductPriceLevel));
                    tracing.Trace($"Count productLevelResult :  {productLevelResult.Entities.Count}");
                    if (productLevelResult.Entities.Count > 0)
                    {
                        string productName = productLevelResult[0].GetAttributeValue<AliasedValue>("prod.name")?.Value?.ToString();
                        tracing.Trace($"Match found in product: {productName}");
                        throw new InvalidPluginExecutionException($"Sales org '{priceListName ?? "Unknown"}' already associated with existing Product: {productName ?? "Unknown"}.");
                    }

                    // --- Condition 2: Check other Product Requests with same product and status ---
                    string fetchXmlProductRequests = $@"
                            <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                              <entity name='niq_productrequest'>
                                <attribute name='niq_productrequestid' />
                                <attribute name='niq_name' />
                                <attribute name='createdon' />
                                <order attribute='niq_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='niq_approvalstatus' operator='in'>
                                    <value>610570000</value>
                                    <value>610570001</value>
                                  </condition>
                                  <condition attribute='niq_referencedproduct' operator='eq' value='{productId}' />
                                </filter>
                                <link-entity name='niq_productrequestpricelistitems' from='niq_productrequest' to='niq_productrequestid' link-type='inner' alias='aq'>
                                  <filter type='and'>
                                    <condition attribute='niq_pricelist' operator='eq'  value='{priceListId}' />
                                  </filter>
                                </link-entity>
                              </entity>
                            </fetch>";

                    tracing.Trace($"Fetch XML: {fetchXmlProductRequests}");

                    EntityCollection reqResult = service.RetrieveMultiple(new FetchExpression(fetchXmlProductRequests));
                    tracing.Trace($"Count reqResult :  {reqResult.Entities.Count}");
                    if (reqResult.Entities.Count > 0)
                    {
                        string matchedRequestName = reqResult[0].GetAttributeValue<string>("niq_name");
                        tracing.Trace($"Match found in product request: {matchedRequestName}");
                        throw new InvalidPluginExecutionException($"Sales org '{priceListName ?? "Unknown"}' already associated with existing Product Request: {matchedRequestName ?? "Unknown"}.");
                    }

                    tracing.Trace("Both validations passed. Record can be created.");
                }
            }
            catch (Exception ex)
            {
                tracing.Trace("Plugin Error: {0}", ex.ToString());
                throw new InvalidPluginExecutionException($"Plugin Exception: {ex.Message}", ex);
            }
        }
    }
}
