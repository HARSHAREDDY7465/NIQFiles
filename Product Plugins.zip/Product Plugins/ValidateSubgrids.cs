using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;
using System.Collections.Generic;

namespace NielsenIQ.CRM.Plugins
{
    public class OnUpdate_ProductRequest : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            try
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity entity = (Entity)context.InputParameters["Target"];
                    if (entity.LogicalName == "niq_productrequest")
                    {
                        int requestType = -1;
                        int associatedConfigurableCharacteristicsCount = -1;
                        int associatedTaxClassificationCount = -1;
                        int associatedPriceListItemCount = -1;
                        int approvalStatus = -1;

                        // Fetch niq_approvalstatus along with other columns
                        Entity productrequestEntity = service.Retrieve(entity.LogicalName, entity.Id, new ColumnSet("niq_requesttype", "niq_defaultpricelist", "niq_approvalstatus"));
                        if (productrequestEntity.Contains("niq_requesttype") && productrequestEntity["niq_requesttype"] is OptionSetValue)
                        {
                            tracingService.Trace("Configurable Material");
                            requestType = ((OptionSetValue)productrequestEntity["niq_requesttype"]).Value;

                            // Fetch approval status as OptionSetValue
                            if (entity.Contains("niq_approvalstatus") && entity["niq_approvalstatus"] is OptionSetValue)
                            {
                                approvalStatus = ((OptionSetValue)entity["niq_approvalstatus"]).Value;
                            }else if (productrequestEntity.Contains("niq_approvalstatus") && productrequestEntity["niq_approvalstatus"] is OptionSetValue)
                            {
                                approvalStatus = ((OptionSetValue)productrequestEntity["niq_approvalstatus"]).Value;
                            }
                            tracingService.Trace("Approval Status "+ approvalStatus);

                            var configurableCharacteristicsEntities = GetAssociatedRecords("niq_productrequestconfigurablecharacteristi", new ColumnSet("niq_productrequestconfigurablecharacteristiid"), "niq_productrequest", entity, service);
                            associatedConfigurableCharacteristicsCount = configurableCharacteristicsEntities.Entities.Count;

                            if (associatedConfigurableCharacteristicsCount <= 0 && requestType == 610570000)
                            {
                                throw new InvalidPluginExecutionException("Please Create atleast one Configurable Characteristics record for New Product Request Type.");
                            }

                            var taxClassificationEntities = GetAssociatedRecords("niq_productrequestmaterialtaxcategory", new ColumnSet("niq_productrequestmaterialtaxcategoryid"), "niq_productrequest", entity, service);
                            associatedTaxClassificationCount = taxClassificationEntities.Entities.Count;
                            var priceListItemEntities = GetAssociatedRecords("niq_productrequestpricelistitems", new ColumnSet("niq_productrequestpricelistitemsid", "niq_pricelist", "niq_discontinuereason", "niq_profitcenter", "niq_glaccount_aagcode", "niq_itemcategorygroups"), "niq_productrequest", entity, service);
                            associatedPriceListItemCount = priceListItemEntities.Entities.Count;
                            tracingService.Trace("Configurable Material");
                            tracingService.Trace("requestType " + requestType);
                            tracingService.Trace("associatedPriceListItemCount " + associatedPriceListItemCount);
                            
                            // New approval status and request type condition before Price List Item check
                            if (
                                requestType == 610570000
                                && (approvalStatus == 610570001 || approvalStatus == 610570002)
                            )
                            {
                                tracingService.Trace("inside First IF and Count"+ associatedPriceListItemCount);
                                if (associatedPriceListItemCount > 0)
                                {
                                    tracingService.Trace("inside First 2nd IF");
                                    // Fetch the GUID of niq_defaultpricelist (lookup field) from the form
                                    Guid? defaultPriceListId = null;
                                     if (entity.Contains("niq_defaultpricelist") && entity["niq_defaultpricelist"] is EntityReference)
                                        defaultPriceListId = ((EntityReference)entity["niq_defaultpricelist"]).Id;
                                    else if (productrequestEntity.Contains("niq_defaultpricelist") && productrequestEntity["niq_defaultpricelist"] is EntityReference)
                                        defaultPriceListId = ((EntityReference)productrequestEntity["niq_defaultpricelist"]).Id;

                                    tracingService.Trace($"Default Price List GUID: {defaultPriceListId}");
                                    // Now check if defaultPriceListId exists in priceListItemEntities (niq_pricelist field)
                                    bool defaultPriceListExistsInItems = false;
                                    if (defaultPriceListId.HasValue)
                                    {
                                        foreach (var item in priceListItemEntities.Entities)
                                        {
                                            if (item.Contains("niq_pricelist") && item["niq_pricelist"] is EntityReference)
                                            {
                                                var priceListRef = (EntityReference)item["niq_pricelist"];
                                                if (priceListRef.Id == defaultPriceListId.Value)
                                                {
                                                    defaultPriceListExistsInItems = true;
                                                    break;
                                                }
                                            }
                                        }
                                    }

                                    if (!defaultPriceListExistsInItems)
                                    {
                                        throw new InvalidPluginExecutionException("Please add the related record of the Default Price List in the Price List Item grid to continue processing this request.");
                                    }
                                }
                                else
                                {
                                    throw new InvalidPluginExecutionException("You must add at least one Price List Item before saving.");
                                }
                            }
                            foreach (var item in priceListItemEntities.Entities)
                            {
                                if (requestType == 610570003)
                                {
                                    if (!item.Contains("niq_discontinuereason") || !(item["niq_discontinuereason"] is EntityReference))
                                    {
                                        throw new InvalidPluginExecutionException("Please add the block code in the pricelist item to continue.");
                                    }
                                }

                                if ((requestType == 610570001 || requestType == 610570000 || requestType == 610570002) &&
                                    (approvalStatus == 610570001 || approvalStatus == 610570002))
                                {
                                    if (!item.Contains("niq_profitcenter") || !(item["niq_profitcenter"] is EntityReference) ||
                                        !item.Contains("niq_glaccount_aagcode") || !(item["niq_glaccount_aagcode"] is EntityReference) ||
                                        !item.Contains("niq_itemcategorygroups") || !(item["niq_itemcategorygroups"] is EntityReference))
                                    {
                                        throw new InvalidPluginExecutionException("Please enter values for all mandatory fields in pricelist item to continue.");
                                    }
                                }
                            }


                            if (associatedTaxClassificationCount < associatedPriceListItemCount && (requestType == 610570000 || requestType == 610570001 || requestType == 610570002))
                            {
                                throw new InvalidPluginExecutionException("Tax Classification records are not added for all required Price List Items. Please add all required Tax classification records before saving the record.");
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }

        }

        private EntityCollection GetAssociatedRecords(String associatedEntityName, ColumnSet columnSetFields, String fieldLogicalName, Entity productEntity, IOrganizationService service)
        {
            QueryExpression productQuery = new QueryExpression(associatedEntityName);
            productQuery.ColumnSet = columnSetFields;
            productQuery.Criteria.AddCondition(fieldLogicalName, ConditionOperator.Equal, productEntity.Id);
            EntityCollection entityColletion = service.RetrieveMultiple(productQuery);
            return entityColletion;
        }
    }
}