using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
namespace NielsenIQ.CRM.Plugins
{
    public class OnCreate_ProductRequest_ProductSearch : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            try
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity entity = (Entity)context.InputParameters["Target"];
                    if (entity.LogicalName == "niq_productrequest")
                    {
                        string productid = entity.Contains("niq_productid") ? entity.GetAttributeValue<string>("niq_productid") : null;
                        // var priceListRef = entity.GetAttributeValue<EntityReference>("niq_defaultpricelist");
                        OptionSetValue requestType = null;
                        if (entity.Contains("niq_requesttype"))
                        {
                            requestType = entity.GetAttributeValue<OptionSetValue>("niq_requesttype");
                        }
                        else if (context.PreEntityImages.Contains("PreImage") &&
                                 context.PreEntityImages["PreImage"].Contains("niq_requesttype"))
                        {
                            requestType = context.PreEntityImages["PreImage"].GetAttributeValue<OptionSetValue>("niq_requesttype");
                        }
                        
                       // Guid pricelist = priceListRef != null ? priceListRef.Id : Guid.Empty; // or handle appropriately if null
                        if (!string.IsNullOrEmpty(productid) && requestType.Value == 610570000)
                        {
                            tracingService.Trace(productid);
                            QueryExpression query = new QueryExpression("product");
                            query.ColumnSet = new ColumnSet(true);
                            query.Criteria = new FilterExpression(LogicalOperator.And);
                            //query.Criteria.AddCondition(new ConditionExpression("pricelevelid", ConditionOperator.Equal, pricelist));
                            query.Criteria.AddCondition(new ConditionExpression("productnumber", ConditionOperator.Equal, productid));
                            EntityCollection ec = service.RetrieveMultiple(query);
                            if (ec.Entities.Count > 0)
                            {
                                throw new InvalidPluginExecutionException("Product ID already exists. Please use a unique Product ID");
                            }
                        }
                           
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Exception: {ex.Message}", ex);
            }

        }
    }
}