﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Metadata;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;

namespace sampleplugin
{
    public class plugincs : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            ITracingService tracingservice = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            tracingservice.Trace("Stage 1");
            if (!context.InputParameters.ContainsKey("Target")) {
                throw new InvalidPluginExecutionException("The target is not here");
            }
            try
            {
                var entity = (Entity)context.InputParameters["Target"];

                string entityName = entity.LogicalName;
                Guid recordId = entity.Id;
                
                // Construct the record URL
                string orgUrl = "https://org3042b9f0.crm8.dynamics.com/main.aspx";
                string recordUrl = $"{orgUrl}?etn={entityName}&id={recordId}&pagetype=entityrecord";

                // Update the entity with the URL (assuming "new_recordurl" is the field)
                entity["websiteurl"] = recordUrl;


                tracingservice.Trace("Stage 2");
                if (entity.Attributes.ContainsKey("fax"))
                {
                    string strAddress1Line3 = (string)entity["fax"];
                    tracingservice.Trace("Stage 3");
                    entity["address1_line3"] = "The Data was" + strAddress1Line3;
                    tracingservice.Trace("Stage 4");
                }
                else
                {
                    
                    tracingservice.Trace("stage 5");
                    entity["address1_line3"] = "there is no data here";
                    tracingservice.Trace("stage 6");

                }
            }
            catch
            {
                tracingservice.Trace("catch!");
            }



        }
    }
}
  