if (typeof RequestForm === "undefined") {
    RequestForm = {
        __namespace: true,
    };
}
var subtopic = [
    610570000, 610570001, 610570002, 610570003, 610570004, 610570005, 610570006,
    610570007, 610570008, 610570009, 610570010, 610570011, 610570012, 610570013,
    610570014, 610570015, 610570016,
];
var currentTicketNumber = null;
var formContext = null;
var isdisabledform = false;
var initialSubStatusvalues = null;
var initialprogressSubStatusvalues = null;
var initialLangOptions = null;
var statictextIon = null;
var opsRecordTypes =
    "Client Inquiry Buy - Data Validity,Client Inquiry Buy - Information,Client Inquiry Global,Client Order Buy,Client Order Global,RDDS Support,GO Enabling,Reporting Solution,H&S Requests";
var csRecordTypes =
    "Analytics,Client Response,Delegate,NielsenIQ Global Helpline,NGH Account Management,H&S Requests";
var showHideNGHRoles =
    "System Administrator,NIQ Global Helpline Agent,NIQ Global Helpline Manager";
var nghAgentManagerRoles =
    "NIQ Global Helpline Agent,NIQ Global Helpline Manager";
var userDept = "";
var adminRole = "System Administrator";
var delegateSubmitterRole = "NIQ Delegate Submitter";
var activitytrackerRoles =
    "NIQ Global Helpline Manager,NIQ Global Helpline Agent,NIQ Analytics Agent,NIQ Analytics Manager," +
    "NIQ Delegate Agent,NIQ Delegate Manager,NIQ Client Response Agent,NIQ Client Response Manager";
var delegateAgentAndManagerRole = "NIQ Delegate Agent,NIQ Delegate Manager";
var createpost = false;
var PreviousPriority;
var recordTypeText;
var validBaseUrl = null;
RequestForm.Events = {
    //Method for onload functions
    FormOnload: function (executionContext) {
        "use strict";
        statictextIon = ["niq_statictext"];
        formContext = executionContext.getFormContext();
        // get initial values from subactivitytypes,substatus during on load - GCD & NGH
        initialSubStatusvalues = formContext.getControl("niq_substatus").getOptions();
        if (formContext.getControl("niq_inprogresssubstatus") !== null)
            initialprogressSubStatusvalues = formContext.getControl("niq_inprogresssubstatus").getOptions();
        initialLangOptions = formContext.getControl("niq_language").getOptions();
        // if (formContext.ui.tabs.getLength() !== 1) {

        recordTypeText = CommonForm.Events.GetFieldText(formContext, "niq_recordtype",);

        // Get the current form being loaded
        var currentFormName = formContext.ui.formSelector.getCurrentItem().getLabel();

        if (recordTypeText !== null && currentFormName.toLowerCase() !== recordTypeText.toLowerCase()) {

            // Get all available forms
            var availableForms = formContext.ui.formSelector.items.get();

            // Filter out the one to be navigated to based on record type
            var navigateTo = availableForms.find((x) => x._label.toLowerCase() === recordTypeText.toLowerCase(),);

            if (navigateTo !== undefined) {
                navigateTo.navigate();
            }
            return true;
        }

        else {
            // this.GetFormRecordType(formContext); // Get the record type

            //on chnage event bind
            this.RegisterMethodsOnChangeEvents(formContext);

            //BPF process stage change event
            this.RegisterMethodsOnBpfStageChange(formContext);

            // methods for Form Manupulation					
            this.ShowHideTabNghFlow(formContext);
            this.DelegateFieldsRequired(formContext); //DYNMCS-2830, if delegate, make extra fields required on load
            this.SetMultiOptionsetVisibility(executionContext, "onload");
            this.SetEntityTypeLookup(formContext.getControl("customerid")); // call method to filter account lookup
            this.RestrictActivityTracker(executionContext); // sprint 12 US : Activity tracker visibility
            this.RemoveRequestOriginOptions(formContext.getControl("caseorigincode")); // Remove Chatbot and community options in the Request origin dropdowns
            this.FilterAccount(executionContext);
            this.FilterParentCase(formContext);
            this.RemovePriorityOptionSetValue(executionContext);
            this.SetDefaultAgentTierForNGH(executionContext);
            this.MethodToLockFormDetailsField(executionContext);
            this.ShowEscalationComment(executionContext, "onload");
            this.ShowHideWorkTypeFieldValue(executionContext);
            this.MethodToRemoveValuesfromSubstatusForNGHAMNewStatus(executionContext);
            this.CaseStatusActions(executionContext);
            this.GetTicketNumberMainForm(formContext); //call the function only for Main form
            this.ValidateFormTypePerformOperations(executionContext); // check the formtype and perform the operations
            this.onStageChangeknowledgesection(executionContext);
            this.ShowResolutionTypeField(executionContext);
            this.GetPreviousPriority(executionContext);
            this.ShowHideSLASection(executionContext);
            this.filterActivitySubtypeOnActivityTypeChange(executionContext);
            this.ShowHideNSSKALinksOnLoad(executionContext);
            this.hideSectionAndField(executionContext);
            this.SetClientEscalationDatetime(executionContext);
            this.SetNSSTopicRequestOrginforNGHAM(executionContext);
            this.ShowNSSTopicField(executionContext);
            this.setTopicMandatoryforDelegate(executionContext);
        }
        //}
        if (recordTypeText != null && (recordTypeText == "Analytics" || recordTypeText == "Client Response" || recordTypeText == "NielsenIQ Global Helpline")) {
            this.ShowHideFieldsSectionsforNSS(executionContext);
            this.filterNiqDataTypeField(executionContext);
            this.filterNSSSubtopic(executionContext);
            this.filterNiqProductLookup(executionContext);
            this.filterNiqNsstopicLookup(executionContext);
            this.filterNSSCountry(executionContext);
            this.FilterSubStatusBasedOnBpf(executionContext);
            this.showHideJiraTab(executionContext);
            this.OnChangeOfIsTechAndDurables(executionContext);
            this.ControlPriorityBasedOnOwnershipAndTopic(executionContext);

        }

        // US - 24976
        if (recordTypeText != null && (recordTypeText == "Analytics" || recordTypeText == "Client Response")) {

            this.tdpageLayout(executionContext);
            formContext.data.process.addOnStageChange(this.tdpageLayout);

        }

        if (recordTypeText == "NielsenIQ Global Helpline") {
            this.HideShowJiraDetailsQuickView(executionContext);
            //DYNCRM-24976
            this.tdpageLayoutNGH(executionContext);
            formContext.data.process.addOnStageChange(this.tdpageLayoutNGH);
        }

        formContext.getAttribute("niq_istechdurables")?.addOnChange(RequestForm.Events.ManageNSSTopicRequiredLevel);
        formContext.getAttribute("caseorigincode")?.addOnChange(RequestForm.Events.ManageNSSTopicRequiredLevel);
        formContext.getAttribute("niq_nsstopic")?.addOnChange(RequestForm.Events.ManageNSSTopicRequiredLevel);
        formContext.getAttribute("niq_clientescalation")?.addOnChange(function (executionContext) {
            RequestForm.Events.SetClientEscalationDatetime(executionContext);
        });

        RequestForm.Events.ManageNSSTopicRequiredLevel(executionContext);
    },

    ManageNSSTopicRequiredLevel: async function (executionContext) {
        const formContext = executionContext.getFormContext();
        const isTechDurables = formContext.getAttribute("niq_istechdurables");
        const requestOrigin = formContext.getAttribute("caseorigincode");
        const nssTopic = formContext.getAttribute("niq_nsstopic");
        const nssSubTopic = formContext.getAttribute("niq_nsssubtopic");

        if (!isTechDurables || !requestOrigin || !nssTopic || !nssSubTopic) return;

        const isTechDurablesValue = isTechDurables.getValue();
        const requestOriginValue = requestOrigin.getValue();
        const nssTopicValue = nssTopic.getValue();

        if (isTechDurablesValue || requestOriginValue === 100000172) {
            if (nssTopicValue && nssTopicValue.length > 0) {
                const topicId = nssTopicValue[0].id.replace("{", "").replace("}", "");
                try {
                    const result = await Xrm.WebApi.retrieveMultipleRecords("niq_nsssubtopic", `?$filter=_niq_nsstopic_value eq ${topicId}`);
                    if (result.entities.length > 0) {
                        nssSubTopic.setRequiredLevel("required");
                    }
                } catch (error) {
                    console.error("Error retrieving NSS Subtopics:", error);
                }
            }
        }
    },


    SetClientEscalationDatetime: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var escalationField = formContext.getAttribute("niq_clientescalation");
        var escalationDateTimeField = formContext.getAttribute("niq_clientescalationdatetime");

        if (escalationField && escalationDateTimeField) {
            if (escalationField.getValue() === true) {
                // Set current date and time
                if (escalationDateTimeField.getValue() == null)
                    escalationDateTimeField.setValue(new Date());
            } else {
                // Clear the field
                escalationDateTimeField.setValue(null);
            }
        }
    },

    GetFormRecordType: function (formContext) {
        if (formContext.ui.tabs.getLength() !== 1) {

            var recordTypeText = CommonForm.Events.GetFieldText(formContext, "niq_recordtype",);

            // Get the current form being loaded
            var currentFormName = formContext.ui.formSelector.getCurrentItem().getLabel();

            if (recordTypeText !== null && currentFormName.toLowerCase() !== recordTypeText.toLowerCase()) {

                // Get all available forms
                var availableForms = formContext.ui.formSelector.items.get();

                // Filter out the one to be navigated to based on record type
                var navigateTo = availableForms.find((x) => x._label.toLowerCase() === recordTypeText.toLowerCase(),);

                if (navigateTo !== undefined) {
                    navigateTo.navigate();
                }
                return true;
            }
        }
    }, // Get the Form record type
    GetTicketNumberMainForm: function (formContext) {
        if (formContext.ui.tabs.getLength() !== 1) {
            currentTicketNumber = CommonForm.Events.GetFieldValue(formContext, "ticketnumber",);
            localStorage.setItem("requestNumber", currentTicketNumber);
            //Onchange of niq_respondedsubstatus Method call To make multiselect non required for no solution,cancelled and out of scope in in-progress
            formContext.getAttribute("niq_respondedsubstatus").addOnChange(this.RespondedSubStatusOnchangeNonRequiredMultiOpt);
            formContext.data.process.addOnStageChange(this.SubActivityTypeOnChangeMultipleOptionset);
            if (formContext.getControl("header_process_ownerid") !== null) {
                formContext.getControl("header_process_ownerid").setVisible(false);
            }
        }
    },
    ShowHideTabNghFlow: function (formContext) {
        var rectype11 = CommonForm.Events.GetFieldValue(formContext, "niq_recordtype",);
        if (rectype11 !== null && rectype11 === 100000003 && CommonForm.Events.CheckIfLoggedInUserRoles(showHideNGHRoles) && formContext.ui.getFormType() !== 1) {
            CommonForm.Events.ShowHideTabs(formContext, "tab_nghflow", true);
        }
    },


    showHideJiraTab: function (executionContext) {
        var formContext = executionContext.getFormContext();

        // Existing values
        var isTechDurables = CommonForm.Events.GetFieldValue(formContext, "niq_istechdurables");
        var recordtype = CommonForm.Events.GetFieldValue(formContext, "niq_recordtype");

        // Topic/Subtopic lookups
        var nsstopicValue = formContext.getAttribute("niq_nsstopic") ? formContext.getAttribute("niq_nsstopic").getValue() : null;
        var nsssubtopicValue = formContext.getAttribute("niq_nsssubtopic") ? formContext.getAttribute("niq_nsssubtopic").getValue() : null;

        var nsstopicName = (nsstopicValue && nsstopicValue.length > 0 && nsstopicValue[0] && nsstopicValue[0].name) ? nsstopicValue[0].name : null;
        var nsssubtopicName = (nsssubtopicValue && nsssubtopicValue.length > 0 && nsssubtopicValue[0] && nsssubtopicValue[0].name) ? nsssubtopicValue[0].name : null;

        if (formContext.ui.getFormType() !== 1) { // not Create
            // CASE 1: Tech Durable is true AND (Analytics OR Client Response OR NielsenIQ Global Helpline Support)
            if (isTechDurables && (recordtype === 100000000 || recordtype === 100000001 || recordtype === 100000003)) {
                formContext.ui.tabs.get("tab_jira").setVisible(true);
            }
            // CASE 2: Record Type = 100000001 AND Topic/Subtopic match => show tab + switch subgrid view (on another tab)
            else if (recordtype === 100000001 && nsstopicName === "Data Inquiry" && nsssubtopicName === "Coding query") {
                // Show the Jira tab (if youÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬ ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬ ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬ ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬ ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢re toggling that tab)
                var jiraTab = formContext.ui.tabs.get("tab_jira");
                if (jiraTab) jiraTab.setVisible(true);

                // --- Your subgrid and view details ---
                var OTHER_TAB_SUBGRID_NAME = "jirarequests";
                var TARGET_VIEW_ID = "22a2bcde-4df0-f011-8406-6045bd94cab2"; // no {}
                var TARGET_VIEW_NAME = "NPI Jira Request";
                var VIEW_ENTITYTYPE = 1039; // 1039 = SavedQuery (Public/System View), 4230 = UserQuery (Personal)
                // -------------------------------------

                try {
                    var subgridCtrl = formContext.getControl(OTHER_TAB_SUBGRID_NAME);
                    if (subgridCtrl) {
                        // Handler to run when the subgrid is (re)loaded
                        var switchView = function () {
                            try {
                                var viewSelector = subgridCtrl.getViewSelector();
                                if (viewSelector) {
                                    var targetView = {
                                        entityType: VIEW_ENTITYTYPE,
                                        id: TARGET_VIEW_ID,
                                        name: TARGET_VIEW_NAME
                                    };
                                    viewSelector.setCurrentView(targetView);
                                }
                            } catch (e) {
                                console.warn("Failed to switch subgrid view:", e);
                            } finally {
                                // Ensure the handler runs only once per load
                                subgridCtrl.removeOnLoad(switchView);
                            }
                        };

                        // Attach the handler so it runs when the grid is ready
                        subgridCtrl.addOnLoad(switchView);

                        // Optional: if you want to attempt immediately as well
                        // switchView();
                    } else {
                        console.warn("Subgrid control not found: " + OTHER_TAB_SUBGRID_NAME);
                    }
                } catch (err) {
                    console.warn("Error while switching subgrid view:", err);
                }
            }
            // CASE 3: If record type is NOT 100000003, hide the tab
            else if (recordtype !== 100000003) {
                var jiraTab2 = formContext.ui.tabs.get("tab_jira");
                if (jiraTab2) jiraTab2.setVisible(false);
            }
        }
    }
    ,

    ShowHideFieldsSectionsforNSS: function (executionContext) {
        // Get selected values
        formContext = executionContext.getFormContext();
        var NSSTopicLookUp = formContext.getAttribute("niq_nsstopic")?.getValue();
        var NSSTopic = NSSTopicLookUp ? NSSTopicLookUp[0]?.name : "";
        var ReqOrigin = CommonForm.Events.GetFieldValue(formContext, "caseorigincode");
        var NiqSolutionLookUp = formContext.getAttribute("niq_niqnghsolution")?.getValue();
        var NiqSolution = NiqSolutionLookUp ? NiqSolutionLookUp[0]?.name : "";
        var NSSSubTopicLookUp = formContext.getAttribute("niq_nsssubtopic")?.getValue();
        var NSSSubTopic = NSSSubTopicLookUp ? NSSSubTopicLookUp[0]?.name : "";
        var niqTopicIdLookup = formContext.getControl("niq_topicid")?.getAttribute()?.getValue();
        var niqTopicId = niqTopicIdLookup ? niqTopicIdLookup[0]?.name : "";
        var rectype = CommonForm.Events.GetFieldValue(formContext, "niq_recordtype",);
        var isTechDurable = formContext.getAttribute("niq_istechdurables")?.getValue();


        // Field mapping for each Topic & Sub Topic
        var fieldMapping = {
            "Data & methodology": {
                "Methodology & Facts": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_reportnameurl", "niq_attachments", "niq_dimensioninfo", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"],
                "Advisory (Coaching)": ["niq_niqnghsolution", "niq_ticketcreatortype", "niq_country", "niq_datasetname", "niq_nssrequestcreator", "niq_attachments"],
                "Marketing claim letter": ["niq_niqnghsolution", "niq_attachments", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator", "niq_nssrequestcreator"],
            },
            "Data Inquiry": {
                "Coding query": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_attachments", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator", "niq_eanbarcodeupc"],
                "Missing product": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_attachments", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator", "niq_eanbarcodeupc"],
                "Discontinued product": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_period", "niq_attachments", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"],
                "Product information": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_eanbarcodeupc", "niq_attachments", "niq_nameofthecategorysegment", "niq_ticketcreatortype", "niq_country", "niq_industry", "niq_nssrequestcreator"],
                "Market Dimension": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_attachments", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"],
                "Period Dimension": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_attachments", "niq_nameoftheperiod", "niq_ticketcreatortype", "niq_country", "niq_industry", "niq_nssrequestcreator"],
                "Fact Dimension": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_attachments", "niq_ticketcreatortype", "niq_country", "niq_industry", "niq_nssrequestcreator"],

            },
            "Dataset Changes": {
                "Add new product details": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_productavailabilityperiod", "niq_attachments", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"],
                "Product classification change": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_segmentationname", "niq_attachments", "niq_changeexpectationperiod", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"],
                "Product segmentation change": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_changeexpectationperiod", "niq_attachments", "niq_segmentationsandtheirdefinition", "niq_ticketcreatortype", "niq_country", , "niq_industry", "niq_nssrequestcreator"],
                "Market Dimension": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_changeexpectationperiod", "niq_attachments", "niq_action", "niq_impacteddimensions", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"],
                "Fact Dimension": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_changeexpectationperiod", "niq_attachments", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"],
                "Period Dimension": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_attachments", "niq_action", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"],
                "Multiple Dimension": ["niq_niqnghsolution", "niq_industry", "niq_datasetname", "niq_niqdatatype", "niq_changeexpectationperiod", "niq_attachments", "niq_impacteddimensions", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"]
            },
            "New dataset set-up": {
                "All": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_productavailabilityperiod", "niq_attachments", "niq_categoriesinscope", "niq_segmentationsandtheirdefinition", "niq_factsinscope", "niq_backdatascopefirstperiodandperiodicity", "niq_marketsinscope", "niq_ticketcreatortype", "niq_country", "niq_industry", "niq_nssrequestcreator"]
            },
            "Reporting": {
                "Build a new report": ["niq_niqnghsolution", "niq_typeofdata", "niq_niqdatatype", "niq_typeofrequirement", "niq_typeofdelivery", "niq_attachments", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"],
                "Change an existing report": ["niq_niqnghsolution", "niq_niqdatatype", "niq_attachments", "niq_reportownership", "niq_changetype", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"],
                "Issue with existing report": ["niq_niqnghsolution", "niq_niqdatatype", "niq_attachments", "niq_userid", "niq_dataseturl", "niq_issuetype", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"],
                "BAU Request": ["niq_niqnghsolution", "niq_niqdatatype", "niq_attachments", "niq_reportownership", "niq_querydetails", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"],
                "Report query": ["niq_niqnghsolution", "niq_niqdatatype", "niq_attachments", "niq_reportownership", "niq_querydetails", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"]
            },
            "Access": {
                "All": ["niq_niqnghsolution", "niq_accesstickettype", "niq_attachments", "niq_nsstype", "niq_issuetype", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"]
            },
            "System Issues": {
                "All": ["niq_niqnghsolution", "niq_userid", "niq_niqdatatype", "niq_dataseturl", "niq_attachments", "niq_issuetype", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"]
            },
            "Data Extraction": {
                "All": ["niq_niqnghsolution", "niq_niqdatatype", "niq_attachments", "niq_typeofdata", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"]
            },
            "TD": {
                "All": ["niq_niqnghsolution", "niq_country", "niq_ticketcreatortype", "niq_industry"],
                "Alldefault": ["niq_niqnghsolution", "niq_country", "niq_ticketcreatortype", "niq_nssrequestcreator"]
            },
            "Data Quality Issues": {
                "Data coverage": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_attachments", "niq_dimensioninfo", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"],
                "Unusual data/trend": ["niq_niqnghsolution", "niq_datasetname", "niq_niqdatatype", "niq_reportnameurl", "niq_attachments", "niq_dimensioninfo", "niq_ticketcreatortype", "niq_country", "niq_nssrequestcreator"],
            }
        };

        if (isTechDurable === true) {
            NSSTopic = "TD"
            NSSSubTopic = "All"
        } else if (isTechDurable === false && NSSTopic === "" && NSSSubTopic === "") {
            NSSTopic = "TD"
            NSSSubTopic = "Alldefault"

        }

        // Get all unique field names from the mapping
        var allFields = new Set();
        var fieldsToShow;
        Object.values(fieldMapping).forEach(subtopics => {
            Object.values(subtopics).forEach(fields => {
                fields.forEach(field => allFields.add(field));
            });
        });

        // Hide all fields first
        allFields.forEach(field => {
            var control = formContext.getControl(field);
            if (control) control.setVisible(false);
        });

        // Show only relevant fields
        if (NSSTopic && fieldMapping[NSSTopic]) {
            fieldsToShow = fieldMapping[NSSTopic][NSSSubTopic] || fieldMapping[NSSTopic]["All"];
            console.log('fields to show', fieldsToShow);
            if (fieldsToShow) {
                fieldsToShow.forEach(field => {
                    var control = formContext.getControl(field);
                    if (control) control.setVisible(true);
                });
            }
        }


        // Logic to show/hide Topic/NSS Topic for Analytics 
        if (rectype == 100000000 && isTechDurable == true) {

            formContext.ui.tabs.get("tab_details").sections.get("Additionalinformationsection")?.setVisible(true);
            console.log('Additionalinformationsection as visible true')

        }
        else {

            formContext.ui.tabs.get("tab_details").sections.get("Additionalinformationsection")?.setVisible(false);
        }

        if (NSSTopic === "Dataset Changes" || NSSTopic === "Data & methodology" || NSSTopic === "Data Inquiry" || NSSTopic === "Data Extraction" || NSSTopic === "Data Quality Issues") {
            formContext.ui.tabs.get("tab_details").sections.get("Product_List")?.setVisible(true);
        }

        // Logic to show/hide Topic/NSS Topic for Analytics 
        if (((rectype === 100000001 || rectype === 100000003))) {
            console.log('in cr')
            formContext.ui.tabs.get("tab_details").sections.get("Additionalinformationsection")?.setVisible(true);
            formContext.ui.tabs.get("tab_details").sections.get("Userlistsection")?.setVisible(true);
            formContext.getAttribute("niq_niqnghsolution")?.setRequiredLevel("required");
            formContext.getAttribute("niq_country")?.setRequiredLevel("required");
            formContext.getAttribute("niq_ticketcreatortype")?.setRequiredLevel("required");
            formContext.getAttribute("niq_nsssubtopic")?.setRequiredLevel("required");

            if (ReqOrigin === 100000172) {
                formContext.getControl("niq_nghproductid")?.setVisible(false);
            }
        }

        // Additional logic for NSSTopic "Access"
        if (NSSTopic === "Access" && NiqSolution === "Discover") {
            formContext.ui.tabs.get("tab_details").sections.get("Additionalinformationsection2")?.setVisible(true);
        }


        // Additional logic for NSSTopic "System Issues"
        if (NSSTopic === "System Issues") {

            if (NSSSubTopic === "Speed and performance") {
                formContext.getControl("niq_niqdatatype")?.setVisible(false);
            }
            if (NSSSubTopic === "Problem Sharing") {
                formContext.getControl("niq_niqdatatype")?.setVisible(false);
                formContext.getControl("niq_issuetype")?.setVisible(false);
            }
        }
        var requirement = formContext.getAttribute("niq_typeofrequirement")?.getValue();

        // Check if the value is 610570001 (Consultation)
        if (requirement === 610570001 && (NSSTopic == "Reporting" && NSSSubTopic == "Build a new report")) {
            // Hide fields
            formContext.getControl("niq_typeofdata").setVisible(false);
            formContext.getControl("niq_typeofdelivery").setVisible(false);
        }

        var accessValue = formContext.getAttribute("niq_accesstickettype")?.getValue();
        var typeValue = formContext.getAttribute("niq_nsstype")?.getValue();
        var orgControl = formContext.getControl("niq_organizationname");
        var rectype = CommonForm.Events.GetFieldValue(formContext, "niq_recordtype",);
        // Default: hide the field
        orgControl?.setVisible(false);

        if (rectype === 100000001 && ReqOrigin === 100000172 && NSSTopic === "Access" && (accessValue === 100000000 && typeValue === 100000000)) {
            orgControl?.setVisible(true);
        }
    },
    ShowEscalationComment: function (executionContext) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var lookupField = Xrm.Page.getAttribute("parentcaseid").getValue(); // Replace with actual field schema name
        if (lookupField != null && lookupField.length > 0) {
            var requestId = lookupField[0].id;
        }

        if (requestId != null) {

            var fetchXml = "<fetch version='1.0' output-format='xml - platform' mapping='logical' distinct='false'>" +
                "<entity name='incident'>" +
                "<attribute name='title' />" +
                "<attribute name='ticketnumber' />" +
                "<attribute name='createdon' />" +
                "<attribute name='caseorigincode' />" +
                "<attribute name='incidentid' />" +
                "<attribute name='niq_escalationcomment' />" +
                "<attribute name='niq_clientescalation' />" +
                "<order attribute='title' descending='false' />" +
                "<filter type='and'>" +
                "<condition attribute='incidentid' operator='eq' uitype='incident' value='" + requestId + "' />" +
                //    "<condition attribute='incidentid' operator='eq' uiname=',mnd' uitype='incident' value='{A7FE951C-738E-481D-8904-A16795B86694}' />"+
                "</filter>" +
                "</entity>" +
                "</fetch > ";


            //fetchXml = "?fetchXml=" + encodeURIComponent(fetchXml);
            var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
            var result = GetCRMWebAPI.Methods.GetFetchRecords(clienturl, fetchXml, "incidents");
            var clientEscalation = result.value[0]["niq_clientescalation"];
            var field = ["niq_escalationcomment"];
            if (clientEscalation === true) {
                CommonForm.Events.ShowHideFields(formContext, field, true);
            } else {
                CommonForm.Events.ShowHideFields(formContext, field, false);
            }
            // return result;
        }
    },

    //DYNCRM-22774,DYNCRM-25401
    OnChangeOfIsTechAndDurables(executionContext) {
        var formContext = executionContext.getFormContext();
        var isTechDurables = CommonForm.Events.GetFieldValue(formContext, "niq_istechdurables");
        var requestOrigin = CommonForm.Events.GetFieldValue(formContext, "caseorigincode");

        if (requestOrigin == 100000172 || isTechDurables) {
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_niqnghsolution") &&
                CommonForm.Events.CheckFieldExists(formContext, "niq_nsstopic") &&
                CommonForm.Events.CheckFieldExists(formContext, "niq_nsssubtopic")) {
                formContext.ui.tabs.get("tab_details").sections.get("Additionalinformationsection")?.setVisible(true);
                formContext.getControl("niq_niqnghsolution")?.setVisible(true);
                formContext.getControl("niq_nsstopic")?.setVisible(true);
                formContext.getControl("niq_nsssubtopic")?.setVisible(true);
                formContext.getControl("niq_niqnghsolution").addPreSearch(RequestForm.Events.filterNiqProductLookup);


            }
        }
        else {
            //formContext.ui.tabs.get("tab_details").sections.get("Additionalinformationsection")?.setVisible(false);
            // formContext.getAttribute("niq_niqnghsolution").setRequiredLevel("none");
        }
    },
    //27909
    hideAnalyticsSurveySection: function (executionContext) {
        var formContext = executionContext.getFormContext();
        // Get values of the "tech and durable" fields
        var tech_durable = formContext.getAttribute("niq_istechdurables")?.getValue();
        // Check if both fields are true
        if (tech_durable === true) {
            // Delay hiding the section slightly to ensure save is complete
            setTimeout(function () {
                try {
                    formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_analyticssurvey")?.setVisible(false);
                    formContext.data.refresh(true); // Refresh the form to apply changes
                } catch (e) {
                    console.error("Error hiding section: ", e.message);
                }
            }, 2000); // Adjust delay if needed
        }
    },



    //DYNCRM-24976 - Tech&Durable Page Layout
    tdpageLayout: function (executionContext) {

        formContext = executionContext.getFormContext();
        var isTechDurables = CommonForm.Events.GetFieldValue(formContext, "niq_istechdurables");
        var sectionA = formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_requestinformation");
        var sectionB = formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_requestdetails");
        var sectionC = formContext.ui.tabs.get("tab_Summary").sections.get("tab_summary_section_requestdetails");
        var sectionD = formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_contactdetails1");

        if (isTechDurables) {
            console.log('in td page layout for tnd', isTechDurables)
            // Hide the tab and sections
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_clientbrief")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_targetaudience&deliverymode")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_analyticssurvey&deliverymode")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_actualtimetracked")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_slas")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("tab_Client_Escalation")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("Userlistsection")?.setVisible(false);
            formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summary_section_slas")?.setVisible(false);
            formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summary_section_parentcontact")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("tab_gcdnghdetails_section_parentcontact")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_contactdetails")?.setVisible(false);
            formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summary_section_4")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("tab_Details_section_contactdetails")?.setVisible(true);
            formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summery_section_contactdetails")?.setVisible(true);
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_analyticssurvey")?.setVisible(false);
            formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summary_section_Knowledgefeedback")?.setVisible(false);

            sectionD.setLabel("Request Details");

            //-------------------------------------------

            formContext.getAttribute("niq_numberofperformanceoverview")?.setRequiredLevel("none");
            formContext.getAttribute("niq_numberofbusinessissueanalysis")?.setRequiredLevel("none");

            // Hide the fields
            formContext.getControl("niq_softclose").setVisible(false);
            formContext.getControl("niq_reviewforkb").setVisible(false);
            formContext.getControl("niq_webemail").setVisible(false);
            formContext.getControl("niq_language").setVisible(false);
            formContext.getControl("niq_totalplannedefforts").setVisible(false);
            formContext.getControl("niq_frequency").setVisible(false);
            formContext.getControl("niq_reasonfordelay").setVisible(false);
            formContext.getControl("niq_lastreopeneddate").setVisible(false);
            formContext.getControl("niq_closeddate").setVisible(false);
            formContext.getControl("niq_attachments").setVisible(false);
            formContext.getControl("niq_accesstickettype").setVisible(false);
            formContext.getControl("niq_issuetype").setVisible(false);
            formContext.getControl("niq_nsstype").setVisible(false);
            formContext.getControl("ticketnumber").setVisible(false);
            formContext.getControl("ticketnumber1").setVisible(false);
            formContext.getControl("ticketnumber2").setVisible(false);
            formContext.getControl("ownerid2").setVisible(false);
            formContext.getControl("statuscode1").setVisible(false);
            formContext.getControl("niq_substatus1").setVisible(false);
            formContext.getControl("prioritycode1").setVisible(false);
            formContext.getControl("adx_modifiedbyusername").setVisible(true);
            formContext.getControl("niq_niqdatatype").setVisible(false);
            formContext.getControl("niq_userid").setVisible(false);
            formContext.getControl("niq_dataseturl").setVisible(false);
            formContext.getControl("niq_recordtype").setVisible(false);
            formContext.getControl("niq_recordtype1").setVisible(false);
            formContext.getControl("niq_recordtype2").setVisible(false);
            formContext.getControl("niq_dimensioninfo")?.setVisible(false);
            formContext.getControl("niq_reportnameurl")?.setVisible(false);
            formContext.getControl("niq_datasetname")?.setVisible(false);
            formContext.getControl("niq_eanbarcodeupc")?.setVisible(false);
            formContext.getControl("niq_nameofthecategorysegment")?.setVisible(false);
            console.log('here it is')
            formContext.getControl("niq_niqnghsolution")?.setVisible(true);
            formContext.getControl("niq_country")?.setVisible(true);
            formContext.getControl("niq_ticketcreatortype")?.setVisible(true);
            formContext.getControl("niq_industry")?.setVisible(true);






            formContext.getControl("niq_revertinprogressdatetime").setVisible(false);
            if (recordTypeText == "Analytics") {
                formContext.getControl("niq_isautoclosed").setVisible(false);
            }
            //   debugger;
            formContext.getControl("niq_revertinprogressdatetime").setVisible(false);
            if (recordTypeText == "Client Response") {
                formContext.getControl("niq_extractionrequirementparams").setVisible(false);
                formContext.getControl("niq_additionalinformationnss").setVisible(false);
                formContext.getControl("niq_changetype").setVisible(false);
                formContext.getControl("niq_reportownership").setVisible(false);
            }



        }
        else {
            // Show the tab and sections
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_clientbrief")?.setVisible(true);
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_targetaudience&deliverymode")?.setVisible(true);
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_analyticssurvey&deliverymode")?.setVisible(true);
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_actualtimetracked")?.setVisible(true);
            //formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_slas")?.setVisible(true);
            formContext.ui.tabs.get("tab_details").sections.get("tab_Client_Escalation")?.setVisible(true);
            formContext.ui.tabs.get("tab_details").sections.get("tab_gcdnghdetails_section_parentcontact")?.setVisible(true);
            formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summary_section_parentcontact")?.setVisible(true);
            var ReqOrigin = CommonForm.Events.GetFieldValue(formContext, "caseorigincode");
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_contactdetails")?.setVisible(true);
            formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summary_section_4")?.setVisible(true);
            formContext.ui.tabs.get("tab_details").sections.get("tab_Details_section_contactdetails")?.setVisible(false);
            formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summery_section_contactdetails")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_analyticssurvey")?.setVisible(true);
            sectionD.setLabel("Contact Details");

            if (formContext.ui.getFormType() !== 1) { // 1 = Create form
                var ReqOrigin = CommonForm.Events.GetFieldValue(formContext, "caseorigincode");
                if (ReqOrigin == 100000172) {
                    formContext.ui.tabs.get("tab_details").sections.get("Userlistsection")?.setVisible(true);
                }
            }

            // Show the fields
            formContext.getControl("niq_softclose").setVisible(true);
            formContext.getControl("niq_reviewforkb").setVisible(true);
            formContext.getControl("niq_webemail").setVisible(true);
            formContext.getControl("niq_language").setVisible(true);
            formContext.getControl("niq_totalplannedefforts").setVisible(true);
            formContext.getControl("niq_frequency").setVisible(true);
            formContext.getControl("niq_reasonfordelay").setVisible(true);
            formContext.getControl("niq_lastreopeneddate").setVisible(true);
            formContext.getControl("niq_closeddate").setVisible(true);
            formContext.getControl("ticketnumber").setVisible(true);
            formContext.getControl("ticketnumber1").setVisible(true);
            formContext.getControl("ticketnumber2").setVisible(true);
            formContext.getControl("ownerid2").setVisible(true);
            formContext.getControl("statuscode1").setVisible(true);
            formContext.getControl("niq_substatus1").setVisible(true);
            formContext.getControl("prioritycode1").setVisible(true);
            formContext.getControl("adx_modifiedbyusername").setVisible(false);
            formContext.getControl("niq_recordtype").setVisible(true);
            formContext.getControl("niq_recordtype1").setVisible(true);
            formContext.getControl("niq_recordtype2").setVisible(true);
            formContext.getControl("niq_extractionrequirementparams")?.setVisible(false);
            formContext.getControl("niq_additionalinformationnss")?.setVisible(false);

            formContext.getControl("niq_revertinprogressdatetime").setVisible(true);
            if (recordTypeText == "Analytics") {
                formContext.getControl("niq_isautoclosed").setVisible(true);
            }

            var topiclookup = formContext.getAttribute("niq_topicid").getValue();

            if (recordTypeText == "Client Response" && topiclookup != null) {
                formContext.getControl("niq_subtopic").setVisible(true);
            }

            //-----------------------

            if (sectionA) {
                var controls = sectionA.controls.get();
                for (var i = 0; i < controls.length; i++) {
                    var control = controls[i];
                    if (control.getName() === "caseorigincode") {
                        control.setVisible(true);
                    }

                }
            }
        }

    },
    //DYNCRM-24976 - Tech&Durable Page Layout for NGH 
    tdpageLayoutNGH: function (executionContext) {
        formContext = executionContext.getFormContext();
        var isTechDurables = CommonForm.Events.GetFieldValue(formContext, "niq_istechdurables");
        var sectionA = formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_requestinformation");
        var sectionB = formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_requestdetails");
        var sectionC = formContext.ui.tabs.get("tab_Summary").sections.get("tab_summary_section_requestdetails");
        var sectionD = formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_contactdetails1");


        if (isTechDurables) {
            // Hide the tab and sections
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_actualtimetracked")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("tab_Client_Escalation")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("technologydetails")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("JiraDetailsWithoutQuickView")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_forms")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("Userlistsection")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_contactdetails")?.setVisible(false);
            formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summary_section_4")?.setVisible(false);
            formContext.ui.tabs.get("tab_details").sections.get("tab_Details_section_contactdetails")?.setVisible(true);
            formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summery_section_contactdetails")?.setVisible(true);
            formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summary_section_Knowledgefeedback")?.setVisible(false);

            sectionD.setLabel("Request Details");

            formContext.getAttribute("niq_numberofperformanceoverview")?.setRequiredLevel("none");
            formContext.getAttribute("niq_numberofbusinessissueanalysis")?.setRequiredLevel("none");

            // Hide the fields
            formContext.getControl("niq_internaltechnicalrca").setVisible(false);
            formContext.getControl("niq_jiradatetime").setVisible(false);
            formContext.getControl("niq_countryofwork").setVisible(false);
            formContext.getControl("niq_servicenowdatetime").setVisible(false);
            formContext.getControl("niq_metering").setVisible(false);
            formContext.getControl("niq_escalationdatetime").setVisible(false);
            formContext.getControl("niq_worktype").setVisible(false);
            formContext.getControl("niq_dataquality").setVisible(false);
            formContext.getControl("niq_businessline").setVisible(false);
            formContext.getControl("niq_nghagenttierid").setVisible(false);
            formContext.getControl("niq_impactbysev1").setVisible(false);
            formContext.getControl("niq_sev1ticket").setVisible(false);
            formContext.getControl("niq_softclose").setVisible(false);
            formContext.getControl("niq_reviewforkb").setVisible(false);
            formContext.getControl("niq_webemail").setVisible(false);
            formContext.getControl("niq_lastreopeneddate").setVisible(false);
            formContext.getControl("niq_closeddate").setVisible(false);
            formContext.getControl("niq_language").setVisible(false);
            formContext.getControl("niq_attachments").setVisible(false);
            formContext.getControl("niq_accesstickettype").setVisible(false);
            formContext.getControl("niq_issuetype").setVisible(false);
            formContext.getControl("niq_nsstype").setVisible(false);
            formContext.getControl("niq_inprogresssubstatus").setVisible(false);
            formContext.getControl("ticketnumber").setVisible(false);
            formContext.getControl("ticketnumber1").setVisible(false);
            formContext.getControl("ticketnumber2").setVisible(false);
            formContext.getControl("ownerid2").setVisible(false);
            formContext.getControl("statuscode1").setVisible(false);
            formContext.getControl("niq_substatus1").setVisible(false);
            formContext.getControl("niq_recordtype1").setVisible(false);
            formContext.getControl("niq_recordtype").setVisible(false);
            formContext.getControl("niq_recordtype2").setVisible(false);
            formContext.getControl("prioritycode1").setVisible(false);
            formContext.getControl("niq_formname").setVisible(false);
            formContext.getControl("niq_plannedstartdate").setVisible(true);
            formContext.getControl("niq_plannedenddate").setVisible(true);
            formContext.getControl("niq_multiclient").setVisible(true);
            formContext.getControl("niq_numberofclients").setVisible(true);
            formContext.getControl("adx_modifiedbyusername").setVisible(true);
            formContext.getControl("niq_revertinprogressdatetime").setVisible(false);
            formContext.getControl("niq_industry")?.setVisible(true);
            formContext.getControl("niq_niqdatatype")?.setVisible(false);
            formContext.getControl("niq_userid")?.setVisible(false);
            formContext.getControl("niq_dataseturl")?.setVisible(false);
            formContext.getControl("niq_jiranumber")?.setVisible(true);
            formContext.getControl("niq_dimensioninfo")?.setVisible(false);
            formContext.getControl("niq_reportnameurl")?.setVisible(false);
            formContext.getControl("niq_datasetname")?.setVisible(false);
            formContext.getControl("niq_eanbarcodeupc")?.setVisible(false);
            formContext.getControl("niq_nameofthecategorysegment")?.setVisible(false);
            formContext.getControl("niq_niqnghsolution")?.setVisible(true);
            formContext.getControl("niq_country")?.setVisible(true);
            formContext.getControl("niq_ticketcreatortype")?.setVisible(true);
            formContext.getControl("niq_industry")?.setVisible(true);

            formContext.getControl("niq_additionalinformationnss")?.setVisible(false);

        }
        else {
            // Show the tab and sections
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_actualtimetracked")?.setVisible(true);
            formContext.ui.tabs.get("tab_details").sections.get("tab_Client_Escalation")?.setVisible(true);
            formContext.ui.tabs.get("tab_details").sections.get("technologydetails")?.setVisible(true);
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_forms")?.setVisible(true);
            var ReqOrigin = CommonForm.Events.GetFieldValue(formContext, "caseorigincode");
            formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_contactdetails")?.setVisible(true);
            formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summary_section_4")?.setVisible(true);
            formContext.ui.tabs.get("tab_details").sections.get("tab_Details_section_contactdetails")?.setVisible(false);
            formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summery_section_contactdetails")?.setVisible(false);

            sectionD.setLabel("Contact Details");

            if (formContext.ui.getFormType() !== 1) { // 1 = Create form
                var ReqOrigin = CommonForm.Events.GetFieldValue(formContext, "caseorigincode");
                if (ReqOrigin == 100000172) {
                    formContext.ui.tabs.get("tab_details").sections.get("Userlistsection")?.setVisible(true);
                }
            }

            // Hide the fields
            formContext.getControl("niq_internaltechnicalrca").setVisible(true);
            formContext.getControl("niq_jiradatetime").setVisible(true);
            formContext.getControl("niq_countryofwork").setVisible(true);
            formContext.getControl("niq_servicenowdatetime").setVisible(true);
            formContext.getControl("niq_metering").setVisible(true);
            formContext.getControl("niq_escalationdatetime").setVisible(true);
            formContext.getControl("niq_worktype").setVisible(true);
            formContext.getControl("niq_dataquality").setVisible(true);
            formContext.getControl("niq_businessline").setVisible(true);
            formContext.getControl("niq_nghagenttierid").setVisible(true);
            formContext.getControl("niq_impactbysev1").setVisible(true);
            formContext.getControl("niq_sev1ticket").setVisible(true);
            formContext.getControl("niq_softclose").setVisible(true);
            formContext.getControl("niq_reviewforkb").setVisible(true);
            formContext.getControl("niq_webemail").setVisible(true);
            formContext.getControl("niq_lastreopeneddate").setVisible(true);
            formContext.getControl("niq_closeddate").setVisible(true);
            formContext.getControl("niq_language").setVisible(true);
            formContext.getControl("ticketnumber").setVisible(true);
            formContext.getControl("ticketnumber1").setVisible(true);
            formContext.getControl("ticketnumber2").setVisible(true);
            formContext.getControl("ownerid2").setVisible(true);
            formContext.getControl("statuscode1").setVisible(true);
            formContext.getControl("niq_substatus1").setVisible(true);
            formContext.getControl("niq_recordtype1").setVisible(true);
            formContext.getControl("niq_recordtype").setVisible(true);
            formContext.getControl("niq_recordtype2").setVisible(true);
            formContext.getControl("prioritycode1").setVisible(true);
            formContext.getControl("niq_formname").setVisible(true);
            formContext.getControl("niq_plannedstartdate").setVisible(false);
            formContext.getControl("niq_plannedenddate").setVisible(false);
            formContext.getControl("niq_multiclient").setVisible(false);
            formContext.getControl("niq_numberofclients").setVisible(false);
            formContext.getControl("adx_modifiedbyusername").setVisible(false);
            formContext.getControl("niq_revertinprogressdatetime").setVisible(true);
            formContext.getControl("niq_jiranumber").setVisible(false);
            formContext.getControl("niq_additionalinformationnss").setVisible(false);

            var topiclookup = formContext.getAttribute("niq_topicid").getValue();

            if (topiclookup != null) {
                formContext.getControl("niq_subtopic").setVisible(true);
            }

            //----------------------------------------

            if (sectionA) {
                var controls = sectionA.controls.get();
                for (var i = 0; i < controls.length; i++) {
                    var control = controls[i];
                    if (control.getName() === "caseorigincode") {
                        control.setVisible(true);
                    }

                }
            }
        }
    },


    GetDDMValuesOptionSet: function (executionContext) {
        formContext = executionContext.getFormContext();
        var rectype11 = CommonForm.Events.GetFieldValue(formContext, "niq_recordtype",);
        var ddmIssueCategory = formContext.getAttribute("niq_ddmissuecategory").getText();
        var businessline = CommonForm.Events.GetFieldValue(formContext, "niq_businessline",);
        if (rectype11 !== null && rectype11 === 100000003 && ddmIssueCategory !== null && businessline == 100000001) {
            if (ddmIssueCategory == "Data Discrepancy: Issue with Data") {
                // Show the target field if the value matches
                formContext.getAttribute("niq_ddmsupercategory").setValue(100000000);
            }
            else if (ddmIssueCategory == "Extract Completion: Email Notification Issue") {
                formContext.getAttribute("niq_ddmsupercategory").setValue(100000001);
            }
            else if (ddmIssueCategory == "Extract Failure: Invalid Selections" ||
                ddmIssueCategory == "Extract Failure: Component Failure" ||
                ddmIssueCategory == "Extract Failure: Pending Review" ||
                ddmIssueCategory == "Extract Failure: On Demand Issue" ||
                ddmIssueCategory == "Extract Failure: Snowflake Issue") {
                formContext.getAttribute("niq_ddmsupercategory").setValue(100000002);
            }
            else if (ddmIssueCategory == "Extract Failure: Suspended ID" ||
                ddmIssueCategory == "MFT: Access Issue" ||
                ddmIssueCategory == "User Interface: Dataset access issue") {
                formContext.getAttribute("niq_ddmsupercategory").setValue(100000003);

            }
            else if (ddmIssueCategory == "MFT: Delivery Set Up Issue" ||
                ddmIssueCategory == "Scheduled Extracts: Incorrect Scheduling" ||
                ddmIssueCategory == "User Interface: Extract Set Up Issue") {
                formContext.getAttribute("niq_ddmsupercategory").setValue(100000005);
            }
            else if (ddmIssueCategory == "MFT: Delivery Failure") {
                formContext.getAttribute("niq_ddmsupercategory").setValue(100000004);
            }
            else if (ddmIssueCategory == "Performance: Long Running Extract") {
                formContext.getAttribute("niq_ddmsupercategory").setValue(100000006);
            }
            else if (ddmIssueCategory == "Scheduled Extracts: Missed Trigger" ||
                ddmIssueCategory == "Scheduled Extracts: DB not signed off" ||
                ddmIssueCategory == "Scheduled Extracts: Component Issue") {
                formContext.getAttribute("niq_ddmsupercategory").setValue(100000007);
            }
        }

    },
    filterNiqDataTypeField: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var NSSTopicLookUp = formContext.getAttribute("niq_nsstopic")?.getValue();
        var NSSTopic = NSSTopicLookUp ? NSSTopicLookUp[0].name : "";

        if (["Data & methodology", "Data Inquiry", "Dataset Changes", "New dataset set-up"].includes(NSSTopic)) {
            RequestForm.Events.filterDataNiqDataTypeField(executionContext);
            return;
        }

        if (NSSTopic === "System Issues") {
            RequestForm.Events.updateDataTypeOptions(executionContext);
        }
    },

    filterNiqDataTypeField: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var NSSTopicLookUp = formContext.getAttribute("niq_nsstopic")?.getValue();
        var NSSTopic = NSSTopicLookUp ? NSSTopicLookUp[0].name : "";

        if (["Data & methodology", "Data Inquiry", "Dataset Changes", "New dataset set-up", "Data Quality Issues", "Reporting", "Data Extraction"].includes(NSSTopic)) {
            RequestForm.Events.filterDataNiqDataTypeField(executionContext);
            return;
        }

        if (NSSTopic === "System Issues") {
            RequestForm.Events.updateDataTypeOptions(executionContext);
        }
    },

    updateDataTypeOptions: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var nghSolution = formContext.getAttribute("niq_niqnghsolution").getValue();
        var dataTypeControl = formContext.getControl("niq_niqdatatype");
        var selectedSolutionName = nghSolution && nghSolution.length > 0 ? nghSolution[0].name : "All";

        var solutionToDataTypeMapping = {
            "Data Delivery Manager (DDM)": [
                { text: "Retail Measurement", value: 610570006 },
                { text: "On Shelf Availability (OSA)", value: 610570004 },
                { text: "Omnisales", value: 610570002 }
            ],
            "Discover": [
                { text: "ACView", value: 610570008 },
                { text: "Business Drivers", value: 610570000 },
                { text: "CGA On-Premise Measurement", value: 610570009 },
                { text: "Omnisales", value: 610570002 },
                { text: "On Shelf Availability (OSA)", value: 610570004 },
                { text: "Panel on Demand (PoD) Homescan", value: 610570005 },
                { text: "Panel on Demand (PoD) Omnishopper", value: 610570011 },
                { text: "Global Snapshot", value: 610570012 },
                { text: "Global Track Complete (GTC)", value: 610570013 },
                { text: "Retail Measurement Services (RMS)", value: 610570006 },
                { text: "Retailer Direct Data", value: 610570014 },
                { text: "Store Level", value: 610570015 }
            ],
            "All": [
                { text: "Business Drivers", value: 610570000 },
                { text: "Omnisales", value: 610570002 },
                { text: "On Shelf Availability (OSA)", value: 610570004 },
                { text: "Panel On Demand (PoD) Homescan", value: 610570005 },
                { text: "Retail Measurement Services (RMS)", value: 610570006 },
                { text: "Other", value: 610570007 },
                { text: "ACView", value: 610570008 },
                { text: "CGA On-Premise Measurement", value: 610570009 },
                { text: "Panel on Demand (PoD) Omnishopper", value: 610570011 },
                { text: "Global Snapshot", value: 610570012 },
                { text: "Global Track Complete (GTC)", value: 610570013 },
                { text: "Retailer Direct Data", value: 610570014 },
                { text: "Store Level", value: 610570015 }
            ]
        };

        if (selectedSolutionName === "Discover Excel Add-In") {
            selectedSolutionName = "Discover";
        }

        var allowedOptions = solutionToDataTypeMapping[selectedSolutionName] || solutionToDataTypeMapping["All"];

        dataTypeControl.clearOptions();
        allowedOptions.forEach(option => dataTypeControl.addOption(option));
    },

    filterDataNiqDataTypeField: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var NSSTopicLookUp = formContext.getAttribute("niq_nsstopic")?.getValue();
        var NSSTopic = NSSTopicLookUp ? NSSTopicLookUp[0].name : "";

        if (["Data & methodology", "Data Inquiry", "Dataset Changes", "New dataset set-up", "Data Quality Issues"].includes(NSSTopic)) {
            var solutionToDataTypeMapping = {
                "Data": [
                    { text: "Retail Measurement Services (RMS)", value: 610570006 },
                    { text: "Business Drivers", value: 610570000 },
                    { text: "Omnisales", value: 610570002 },
                    { text: "Omnishopper Panel", value: 610570003 },
                    { text: "On Shelf Availability (OSA)", value: 610570004 },
                    { text: "Panel on Demand (PoD) Homescan", value: 610570005 },
                    { text: "Other", value: 610570007 }
                ]
            };
        }
        if (["Reporting", "Data Extraction"].includes(NSSTopic)) {
            var solutionToDataTypeMapping = {
                "Data": [
                    { text: "Retail Measurement Services (RMS)", value: 610570006 },
                    { text: "Omnisales", value: 610570002 },
                    { text: "Panel on Demand (PoD) Homescan", value: 610570005 },
                    { text: "Other", value: 610570007 }
                ]
            };
        };

        var dataTypeControl = formContext.getControl("niq_niqdatatype");
        dataTypeControl.clearOptions();

        solutionToDataTypeMapping["Data"].forEach(option => dataTypeControl.addOption(option));

    },

    filterNiqNsstopicLookup: function (executionContext) {
        var lookupField = "niq_nsstopic"; // Schema name of the lookup field
        var formContext = executionContext.getFormContext();
        var rectype = CommonForm.Events.GetFieldValue(formContext, "niq_recordtype",);
        // Add Pre-Search filter on the lookup field
        Xrm.Page.getControl(lookupField).addPreSearch(function () {
            // Define the FetchXML filter
            var fetchXmlFilter = `
            <filter type="and">
            <filter type="or">
                <condition attribute="niq_nsstype" operator="eq" value="1" />
                <condition attribute="niq_nsstype" operator="null"/>
                 </filter>
                <condition attribute="niq_recordtype" operator="like" value="%${rectype}%" />
            </filter>`;

            // Apply the custom filter
            Xrm.Page.getControl(lookupField).addCustomFilter(fetchXmlFilter, "niq_topic");
        });

    },

    filterNiqProductLookup: function (executionContext) {
        // Get the form context
        var formContext = executionContext.getFormContext();
        var productControl = formContext.getControl("niq_niqnghsolution");

        // Define the handler for the pre-search event
        var addFilterHandler = function () {
            var NSSTopicLookUp = formContext.getAttribute("niq_nsstopic").getValue();
            var NSSTopic = NSSTopicLookUp != null ? NSSTopicLookUp[0].name : "";
            var NSSSubTopicLookUp = formContext.getAttribute("niq_nsssubtopic").getValue();
            var NSSSubTopic = NSSSubTopicLookUp != null ? NSSSubTopicLookUp[0].name : "";
            var isTechDurables = CommonForm.Events.GetFieldValue(formContext, "niq_istechdurables");
            var NSSTopicid;
            var fetchXmlFilter;

            // Determine the NSSTopicid based on the topic and subtopic
            if (NSSTopic === "Access") {
                NSSTopicid = "610570000";
            } else if (NSSTopic === "System Issues") {
                NSSTopicid = NSSSubTopic === "Problem Exporting" ? "610570002" : "610570001";
            }
            else if (NSSTopic === "Data & methodology" || NSSTopic === "Data Inquiry" || NSSTopic === "Dataset Changes" || NSSTopic === "Data Quality Issues" || NSSTopic === "New dataset set-up") {
                NSSTopicid = "610570003";
            }
            else if (NSSTopic === "Reporting") {
                NSSTopicid = "610570004";
            }
            else if (NSSTopic === "Data Extraction") {
                NSSTopicid = "610570005";
            }

            if (NSSTopicid) {
                // Define the filter FetchXML query
                fetchXmlFilter = `
				<filter type="and">
					<condition attribute="niq_nsstopictype" operator="contain-values">
						<value>${NSSTopicid}</value>
					</condition>
				</filter>
			`;
            }
            if (isTechDurables) {
                fetchXmlFilter = `
			<filter type="and">
				<filter type="or">
					<condition attribute="niq_name" operator="eq" value="gfknewron" />
					<condition attribute="niq_name" operator="eq" value="StarTrack" />
				</filter>
			</filter>
			`;
            }
            if (fetchXmlFilter) {
                // Add the custom filter
                productControl.addCustomFilter(fetchXmlFilter, "niq_nghproduct");
            }
        };
        // Remove any previously registered handler
        productControl.removePreSearch(addFilterHandler);

        // Add the new pre-search handler
        productControl.addPreSearch(addFilterHandler);
    },

    filterNSSSubtopic: function (executionContext) {
        var formContext = executionContext.getFormContext();

        // Get the control
        var nssSubtopicControl = formContext.getControl("niq_nsssubtopic");


        // Define the handler for the pre-search event
        var addFilterHandler = function () {
            var nsstopicValue = formContext.getAttribute("niq_nsstopic")?.getValue();

            if (nsstopicValue && nsstopicValue[0].name === "System Issues") {
                var fetchXML = `
                <fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
                    <entity name="niq_nsssubtopic">
                        <attribute name="niq_nsssubtopicid" />
                        <attribute name="niq_name" />
                        <attribute name="createdon" />
                        <order attribute="niq_name" descending="false" />
                    </entity>
                </fetch>
            `;
                nssSubtopicControl.addCustomFilter(fetchXML, "niq_nsssubtopic");
            } else {
                var fetchXMLall = `
                <fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">
				<entity name="niq_nsssubtopic">
					<attribute name="niq_nsssubtopicid" />
					<attribute name="niq_name" />
					<attribute name="createdon" />
					<order attribute="niq_name" descending="false" />
					<filter type="and">
					<condition attribute="niq_name"  operator="ne" value="Access issues" />
					<condition attribute="niq_name" operator="ne" value="Login issues" />
					</filter>
				</entity>
				</fetch>
            `;
                nssSubtopicControl.addCustomFilter(fetchXMLall, "niq_nsssubtopic");
            }
        };

        // Remove any previously registered handler
        nssSubtopicControl.removePreSearch(addFilterHandler); // Use the specific handler reference

        // Add the new pre-search handler
        nssSubtopicControl.addPreSearch(addFilterHandler);
    },

    filterNSSCountry: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var caseOriginCode = formContext.getAttribute("caseorigincode")?.getValue();

        // Apply filter only if origin is 100000172
        if (caseOriginCode === 100000172) {
            formContext.getControl("niq_country").addPreSearch(function () {
                var fetchFilter =
                    "<filter type='and'>" +
                    "<condition attribute='niq_isnss' operator='eq' value='1' />" +
                    "</filter>";
                formContext.getControl("niq_country").addCustomFilter(fetchFilter, "niq_country"); // entity logical name
            });
        } else {
            // Optional: Clear filter if needed
            formContext.getControl("niq_country").addPreSearch(function () {
                formContext.getControl("niq_country").addCustomFilter("<filter></filter>", "niq_country");
            });
        }
    },

    DelegateFieldsRequired: function (formContext) {
        var sourceFieldValue = null;
        var delegateSourceFieldNames = ["niq_datatype", "niq_informationsources", "niq_deliveryformat_delegate",];
        var delegateOtherFieldNames = ["niq_datatypeother", "niq_informationsourcesother", "niq_deliveryformatother",];
        var requiredFieldNames = ["niq_periods", "niq_facts", "niq_analysisframeworkscopesuggestion", "niq_objective", "niq_analysistobespecified", "niq_categorysetdatabasenames", "niq_market", "niq_product", "niq_datatype", "niq_informationsources", "niq_deliveryformat_delegate",];
        var rectype11 = CommonForm.Events.GetFieldValue(formContext, "niq_recordtype",);

        if (formContext.ui.getFormType() != 1) {
            var date = CommonForm.Events.GetFieldValue(formContext, "createdon");
            var date1 = new Date("July 15, 2022");
            if (date.getTime() > date1.getTime() || date.getTime() == date1.getTime()) {
                if (rectype11 !== null && rectype11 === 100000002) {
                    //DYNMCS-2830
                    formContext.getAttribute("niq_datatype").addOnChange(this.delegateDataTypeControl);
                    formContext.getAttribute("niq_deliveryformat_delegate").addOnChange(this.delegateDeliveryFormatControl);
                    formContext.getAttribute("niq_informationsources").addOnChange(this.delegateInformationSourcesControl);
                    CommonForm.Events.SetRequiredFieldLevels(formContext, requiredFieldNames, "required",);
                    for (var x = 0; x <= 2; x++) {
                        sourceFieldValue = formContext.getAttribute(delegateSourceFieldNames[x]).getText();
                        if (sourceFieldValue !== null && sourceFieldValue.includes("Other")) {
                            CommonForm.Events.SetRequiredFieldLevels(formContext, [delegateOtherFieldNames[x]], "required",);
                            CommonForm.Events.ShowHideFields(formContext, [delegateOtherFieldNames[x]], true,);
                        }
                    }
                }
            }
        } else {
            if (rectype11 !== null && rectype11 === 100000002) {
                //DYNMCS-2830
                formContext.getAttribute("niq_datatype").addOnChange(this.delegateDataTypeControl);
                formContext.getAttribute("niq_deliveryformat_delegate").addOnChange(this.delegateDeliveryFormatControl);
                formContext.getAttribute("niq_informationsources").addOnChange(this.delegateInformationSourcesControl);
                CommonForm.Events.SetRequiredFieldLevels(formContext, requiredFieldNames, "required",);
                for (var y = 0; y <= 2; y++) {
                    sourceFieldValue = formContext.getAttribute(delegateSourceFieldNames[y]).getText();
                    if (sourceFieldValue !== null && sourceFieldValue.includes("Other")) {
                        CommonForm.Events.SetRequiredFieldLevels(formContext, [delegateOtherFieldNames[y]], "required",);
                        CommonForm.Events.ShowHideFields(formContext, [delegateOtherFieldNames[y]], true,);
                    }
                }
            }
        }

    },
    CaseStatusActions: function (executionContext) {
        formContext = executionContext.getFormContext();
        //Get case status
        var casestatus = CommonForm.Events.GetFieldValue(formContext, "statuscode");
        // check if it disabled form or  case status != responded
        if (casestatus !== null && casestatus !== undefined && casestatus == 5) {
            RequestForm.Events.SetMultiOptionsetVisibility(executionContext, "onload",);
        }
    },
    ValidateFormTypePerformOperations: function (executionContext) {
        formContext = executionContext.getFormContext();
        var rectype11 = CommonForm.Events.GetFieldValue(formContext, "niq_recordtype",);
        //update form
        if (formContext.ui.getFormType() === 2) {

            CommonForm.Events.ShowHideFields(formContext, statictextIon, true);
            this.DisablePlannedDatehours(executionContext, "onload"); // function to perform few actions based on the record type
            this.ShowHideSubTopicSetAdditionalInformation(executionContext, "onload",);
            this.LoadRecordTypes(formContext, "update");
            this.UpdateRoutingWidget(executionContext); //to update routing widget
            this.FilterStatusRelatedOptionsets(executionContext); // filter the dependent optionsets and set the values
            this.SetMultiOptionsetVisibility(executionContext, "onload");
            this.QuickCreateOnload(executionContext, "onload");
            this.setDefaultValuetoNGHProductforMetering(executionContext);

            if (rectype11 !== null &&
                (rectype11 === 100000000 || rectype11 === 100000001 || rectype11 === 100000002 || rectype11 === 100000003 || rectype11 === 100000004)) {

                CommonForm.Events.ShowHideTabs(formContext, "tab_Summary", true);
                CommonForm.Events.ShowHideTabs(formContext, "tab_followers", true);
                CommonForm.Events.ShowHideTabs(formContext, "tab_related", true);
                CommonForm.Events.ShowHideTabs(formContext, "tab_requestdatabase", true,);
                CommonForm.Events.ShowHideTabs(formContext, "tab_fieldhistory", true);
                CommonForm.Events.ShowHideTabs(formContext, "tab_sla", true);
                CommonForm.Events.ShowHideTabs(formContext, "tab_6", true);
                CommonForm.Events.ShowHideTabs(formContext, "tab_jira", true);
                CommonForm.Events.ShowHideTabs(formContext, "tab_documents", true);

                formContext.ui.tabs.get("tab_Summary").setFocus();
            }
        } else if (formContext.ui.getFormType() === 1) {
            //  create form check
            CommonForm.Events.ShowHideTabs(formContext, "tab_6", false);
            //Load record types, topics based on logged in user role
            this.LoadRecordTypes(formContext, "create");
            //call the function only for quick create to filter record type
            if (formContext.ui.tabs.getLength() === 1) {
                this.RemoveRecordTypeOptionsForQuickCreate(
                    formContext.getControl("niq_recordtype"),
                );
                var accountId = CommonForm.Events.GetFieldValue(
                    formContext,
                    "customerid",
                );
                if (accountId !== null) {
                    var accLookupControl = formContext.getControl("customerid");
                    if (accLookupControl != null) {
                        Xrm.WebApi.online
                            .retrieveMultipleRecords(
                                "account",
                                "?$select=_parentaccountid_value,_niq_ultimateparentid_value&$filter=accountid eq '" +
                                accountId[0].id +
                                "'",
                            )
                            .then(
                                function success(results) {
                                    if (results !== null && results.entities.length === 1) {
                                        var hierarchyId =
                                            results.entities[0]["_niq_ultimateparentid_value"] !==
                                                null ?
                                                results.entities[0]["_niq_ultimateparentid_value"] :
                                                results.entities[0]["_parentaccountid_value"];
                                        //var parentId = results.entities[0]["_parentaccountid_value"];
                                        if (hierarchyId !== null) {
                                            var fetchXml =
                                                "<fetch distinct='false' no-lock='false' mapping='logical'>" +
                                                "<entity name='account' >" +
                                                "<filter type='and' >" +
                                                "<condition attribute='accountid' operator='eq-or-under' value='" +
                                                hierarchyId +
                                                "' />" +
                                                "</filter>" +
                                                "</entity>" +
                                                "</fetch>";
                                            accLookupControl.addPreSearch(function () {
                                                accLookupControl.addCustomFilter(fetchXml);
                                            });
                                        } else {
                                            formContext.getControl("customerid").setDisabled(true);
                                        }
                                    }
                                },

                                function (error) {
                                    //Xrm.Utility.alertDialog(error.message);
                                },
                            );
                    }
                }
            }

            if (
                (rectype11 !== null && rectype11 === 100000001) ||
                rectype11 === 100000003
            )
                formContext.getControl("niq_subtopic").setVisible(false);
            CommonForm.Events.ShowHideFields(formContext, statictextIon, false);
            this.setDefaultValuetoNGHProductforMetering(executionContext);
        } else if (formContext.ui.getFormType() !== 1) {
            if (rectype11 !== null && (rectype11 === 100000000 || rectype11 === 100000001 || rectype11 === 100000002 || rectype11 === 100000003 || rectype11 === 100000004)) {
                CommonForm.Events.ShowHideTabs(formContext, "tab_Summary", true);
                CommonForm.Events.ShowHideTabs(formContext, "tab_followers", true);
                CommonForm.Events.ShowHideTabs(formContext, "tab_related", true);
                CommonForm.Events.ShowHideTabs(formContext, "tab_requestdatabase", true,);
                CommonForm.Events.ShowHideTabs(formContext, "tab_fieldhistory", true);
                CommonForm.Events.ShowHideTabs(formContext, "tab_6", true);
                formContext.ui.tabs.get("tab_Summary").setFocus();
            }
            CommonForm.Events.ShowHideFields(formContext, statictextIon, false);
            this.setDefaultValuetoNGHProductforMetering(executionContext);
        } else {
            CommonForm.Events.ShowHideFields(formContext, statictextIon, false);
            this.setDefaultValuetoNGHProductforMetering(executionContext);
        }
    },
    RegisterMethodsOnChangeEvents: function (formContext) {
        var rectype11 = CommonForm.Events.GetFieldValue(formContext, "niq_recordtype",);
        var currentFormName = formContext.ui.formSelector.getCurrentItem().getLabel();
        recordTypeText = CommonForm.Events.GetFieldText(formContext, "niq_recordtype",);
        var subTopic = formContext.getAttribute("niq_subtopic");
        formContext.getAttribute("niq_recordtype").addOnChange(this.SetMultiOptionsetVisibility); //onchange function for record type and record origin                                                                                              fields ,
        formContext.getAttribute("caseorigincode").addOnChange(this.ValidateRequestOriginMessage);
        formContext.getAttribute("statuscode").addOnChange(this.DisablePlannedDatehours);
        formContext.getAttribute("customerid").addOnChange(this.ShowErrorForNielsenGlobal); // onchange of account lookup
        formContext.getAttribute("customerid").addOnChange(this.ClearNotificationOnNielsenAccount);
        formContext.getAttribute("customerid").addOnChange(this.CheckAccountTypeSelected);
        formContext.getAttribute("primarycontactid").addOnChange(this.GetParentAccountForContact); // onchange of contact lookup and activitytype lookup
        formContext.getAttribute("niq_activitysubtypeid").addOnChange(this.SubActivityTypeOnChangeMultipleOptionset);
        formContext.getAttribute("niq_activitytypeid").addOnChange(this.filterActivitySubtypeOnActivityTypeChange);
        formContext.getAttribute("niq_topicid").addOnChange(this.clearValuetoNGHProduct);

        if (formContext.getAttribute("niq_recordtype").getValue() !== 100000004) {
            formContext.getAttribute("niq_kahelptosolveticket").addOnChange(this.KnowledgeFeedbackSectionFieldsShowHide);
            formContext.getAttribute("niq_reviewforka").addOnChange(this.KnowledgeFeedbackSectionFieldsShowHide);
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_nssknowledgearticle")) {
                formContext.getAttribute("niq_nssknowledgearticle").addOnChange(this.AutoPopulateKAFeedbackFields);
            }
            if (CommonForm.Events.CheckFieldExists(formContext, "niq_nsslinkknowledgearticle")) {
                formContext.getAttribute("niq_nsslinkknowledgearticle").addOnChange(this.OnChangeNSSLinkField);
            }
        }
        if (rectype11 !== null && rectype11 === 100000003) {
            formContext.getAttribute("niq_businessline").addOnChange(this.clearValuetoNGHProduct);
            formContext.getAttribute("niq_subtopic").addOnChange(this.SetAdditionalInformation);
            formContext.getAttribute("niq_topicid").addOnChange(this.ShowHideSubTopicSetAdditionalInformation);
        }
        else if (rectype11 !== null && rectype11 !== 100000003) {
            formContext.getAttribute("niq_plannedenddate").addOnChange(this.ValidationOnPlannedEndDate);
        }
        if (rectype11 !== null && rectype11 === 100000001) {
            formContext.getAttribute("niq_topicid").addOnChange(this.ShowHideSubTopicSetAdditionalInformation);
            formContext.getAttribute("niq_subtopic").addOnChange(this.SetAdditionalInformation);
            formContext.getAttribute("niq_topicid").addOnChange(this.ControlPriorityBasedOnOwnershipAndTopic);
            formContext.getAttribute("niq_nsstopic").addOnChange(this.ControlPriorityBasedOnOwnershipAndTopic);
            formContext.getAttribute("ownerid").addOnChange(this.ControlPriorityBasedOnOwnershipAndTopic);
        } else {
            CommonForm.Events.ShowHideTabs(formContext, "tab_nghflow", false);
        }
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_respondedsubstatus")) {
            formContext.getAttribute("niq_respondedsubstatus").addOnChange(this.onStageChangeknowledgesection);
        }
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_respondedsubstatus")) {
            formContext.getAttribute("niq_respondedsubstatus").addOnChange(this.ShowResolutionTypeField);
        }
        formContext.getAttribute("niq_recordtype").addOnChange(this.ShowResolutionTypeField);
        formContext.getAttribute("statuscode").addOnChange(this.ShowResolutionTypeField);

        if (rectype11 !== null && (rectype11 === 100000001 || rectype11 === 100000003) && subTopic !== null) {
            formContext.getAttribute("niq_nsstopic").addOnChange(this.clearSubtopic);
            formContext.getAttribute("niq_nsstopic").addOnChange(this.ShowHideFieldsSectionsforNSS);
            formContext.getAttribute("niq_nsssubtopic").addOnChange(this.ShowHideFieldsSectionsforNSS);
        }

        if (rectype11 !== null && rectype11 === 100000004) {
            formContext.getAttribute("niq_ngham_req_origin").addOnChange(this.SetNSSTopicRequestOrginforNGHAM);
        }

        var isTechDurables = CommonForm.Events.GetFieldValue(formContext, "niq_istechdurables");
        if (rectype11 !== null && (rectype11 === 100000000 || rectype11 === 100000001 || rectype11 === 100000003)) {
            formContext.getAttribute("niq_niqnghsolution").addOnChange(this.filterNiqDataTypeField);
            formContext.getAttribute("niq_nsstopic").addOnChange(this.filterNSSSubtopic);
            formContext.getAttribute("niq_nsstopic").addOnChange(this.filterNiqProductLookup);
            formContext.getAttribute("niq_nsssubtopic").addOnChange(this.filterNiqProductLookup);
            formContext.getAttribute("niq_nsstopic").addOnChange(this.ShowHideFieldsSectionsforNSS);
        }
        //US - 24615,24597,24598
        if (recordTypeText != null && (recordTypeText == "Analytics" || recordTypeText == "Client Response" || recordTypeText == "NielsenIQ Global Helpline")) {
            formContext.getAttribute("niq_istechdurables").addOnChange(this.ShowHideIndustryValues);
            formContext.getAttribute("niq_istechdurables").addOnChange(this.showHideJiraTab);
            formContext.getAttribute("niq_istechdurables").addOnChange(this.ShowHideFieldsSectionsforNSS);
            formContext.getAttribute("niq_niqnghsolution").addOnChange(this.ShowHideIndustryValues);
            formContext.getAttribute("statuscode").addOnChange(this.FilterSubStatusBasedOnBpf);
            formContext.getAttribute("niq_istechdurables").addOnChange(this.OnChangeOfIsTechAndDurables);
            formContext.getAttribute("caseorigincode").addOnChange(this.OnChangeOfIsTechAndDurables);




        }
        // US - 24976
        if (recordTypeText != null && (recordTypeText == "Analytics" || recordTypeText == "Client Response")) {

            formContext.getAttribute("niq_istechdurables").addOnChange(this.hideSectionAndField);
            formContext.getAttribute("niq_istechdurables").addOnChange(this.tdpageLayout);
        }

        //US - 21831
        if (recordTypeText != null && recordTypeText == "NielsenIQ Global Helpline") {
            formContext.getAttribute("niq_istechdurables").addOnChange(this.HideShowJiraDetailsQuickView);
            //DYNCRM-24976
            formContext.getAttribute("niq_istechdurables").addOnChange(this.tdpageLayoutNGH);
            formContext.getAttribute("niq_istechdurables").addOnChange(this.hideSectionAndField);

        }



    },



    hideSectionAndField: function (executionContext) {
        var formContext = executionContext.getFormContext();

        function applyVisibility() {
            var isTechDurables = CommonForm.Events.GetFieldValue(formContext, "niq_istechdurables");
            var recordtype = CommonForm.Events.GetFieldValue(formContext, "niq_recordtype");
            var isCRorAnalytics = (recordtype === 100000000 || recordtype === 100000001 || recordtype === 100000002);
            var section = formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_analyticssurvey");

            if (!section) return;

            if (isCRorAnalytics && isTechDurables !== true) {
                section.setVisible(true);
                formContext.getControl("niq_recordtype")?.setVisible(true);
                formContext.getControl("niq_recordtype1")?.setVisible(true);
                formContext.getControl("niq_recordtype2")?.setVisible(true);
            } else {
                section.setVisible(false);
                formContext.getControl("niq_recordtype")?.setVisible(false);
                formContext.getControl("niq_recordtype1")?.setVisible(false);
                formContext.getControl("niq_recordtype2")?.setVisible(false);
            }
        }

        // Apply visibility immediately
        applyVisibility();

        // Attach onChange listeners (only once)
        formContext.getAttribute("niq_istechdurables")?.removeOnChange(applyVisibility);
        formContext.getAttribute("niq_istechdurables")?.addOnChange(applyVisibility);
        formContext.getAttribute("niq_recordtype")?.removeOnChange(applyVisibility);
        formContext.getAttribute("niq_recordtype")?.addOnChange(applyVisibility);

        // Delay and reapply after save handles new record UI reload issue
        setTimeout(() => {
            applyVisibility();
        }, 2000);
    },



    FilterParentCase: function (formContext) {
        //Add search and Remove Search for Pre filter lookup
        formContext.getControl("parentcaseid").removePreSearch(RequestForm.Events.SetFilterParentRequest); //To topic field to show only topics for this record type
        formContext.getControl("parentcaseid").addPreSearch(RequestForm.Events.SetFilterParentRequest); //To topic field to show only topics for this record type  
    },
    RegisterMethodsOnBpfStageChange: function (formContext) {
        //BPF process stage change event
        formContext.data.process.addOnPreStageChange(this.ValidateEmailToCase);
        formContext.data.process.addOnPreStageChange(this.ValidateProgressionBasedOnPriority);
        formContext.data.process.addOnStageChange(this.MethodToRemoveValuesfromSubstatusForNGHAMNewStatus,);
        formContext.data.process.addOnPreStageChange(this.preStageChange);
        formContext.data.process.addOnStageChange(this.onStageChangeknowledgesection);
        formContext.data.process.addOnStageChange(this.ShowResolutionTypeField);
        formContext.data.process.addOnPreStageChange(this.blockStageNavigationOnChildOpen);
        formContext.data.process.addOnPreProcessStatusChange(function (e) {
            e.getEventArgs().preventDefault();

            var alertStrings = {
                confirmButtonLabel: "OK",
                text: "This request is now completed",
                title: "Status Change!",
            };

            var alertOptions = {
                height: 120,
                width: 260
            };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        });
    },
    ShowHideSubtopic: function (executionContext, options, IsShow) {
        if (!IsShow) {
            options.forEach(function (item) {
                formContext.getControl("niq_subtopic").removeOption(item);
            });
        }
    },
    WelcomePackageFieldVisibility: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var type = CommonForm.Events.GetFieldValue(formContext, "niq_recordtype");
        if (
            type === 100000004 &&
            (CommonForm.Events.CheckIfLoggedInUserRole("NIQ Global Helpline Agent") ||
                CommonForm.Events.CheckIfLoggedInUserRole(
                    "NIQ Global Helpline Manager",
                ))
        ) {
            formContext.getControl("niq_welcomepackagesent").setVisible(true);
        } else {
            formContext.getControl("niq_welcomepackagesent").setVisible(false);
        }
    },
    SetAdditionalInformation: function (executionContext) {
        //Set Additional Information Field based on subtopic values using JSON stored in Configuration Setting entity.
        "use strict";
        try {
            formContext = executionContext.getFormContext();
            var additionalinfo = "";
            var SubTopic = formContext.getAttribute("niq_subtopic").getText();
            if (SubTopic == null || SubTopic == "Other") {
                formContext.getAttribute("niq_additionalinformation").setValue(null);
                return;
            }
            var niq_subtopicjson = "";
            Xrm.WebApi.online
                .retrieveMultipleRecords(
                    "niq_configurationsetting",
                    "?$filter=niq_name eq 'Sub-Topic'",
                )
                .then(
                    function success(results) {
                        for (var i = 0; i < results.entities.length; i++) {
                            niq_subtopicjson = results.entities[i]["niq_to"];
                        }
                        var obj = JSON.parse(niq_subtopicjson);
                        var jsonSubtopics = obj["SubTopic"][SubTopic];
                        Object.keys(jsonSubtopics).forEach(function (key) {
                            additionalinfo = additionalinfo + jsonSubtopics[key] + "\n";
                        });
                        formContext
                            .getAttribute("niq_additionalinformation")
                            .setValue(additionalinfo.slice(0, -1));
                    },
                    function (error) {
                        Xrm.Utility.alertDialog(error.message);
                    },
                );

            var topiclookup = formContext.getAttribute("niq_topicid").getValue();
            var topic = topiclookup != null ? topiclookup[0].name : "";
            if (
                topic == "Software Questions & Issues") {
                var SubTopic = formContext.getAttribute("niq_subtopic").getText();
                if (SubTopic == "Speed and performance" || SubTopic == "Error, Unexpected Result" || SubTopic == "Problem Sharing" || SubTopic == "Problem exporting" || SubTopic == "Login Issue") {
                    formContext.getControl("niq_additionalinformation").setVisible(true);
                }
            }

        } catch (ex) {
            console.log(ex.message);
        }
    },
    ShowHideSubTopicSetAdditionalInformation: function (executionContext) {
        "use strict";
        try {
            formContext = executionContext.getFormContext();
            var origin = CommonForm.Events.GetFieldValue(formContext, "caseorigincode");
            var topiclookup = formContext.getAttribute("niq_topicid").getValue();
            RequestForm.Events.ShowHideSubtopic(executionContext, subtopic, false);
            formContext.getControl("niq_subtopic").setVisible(false);
            var topic = topiclookup != null ? topiclookup[0].name : "";
            var recordtypeval = CommonForm.Events.GetFieldValue(formContext, "niq_recordtype");
            formContext.getAttribute("niq_subtopic").setRequiredLevel("none");
            var additionalInfo = CommonForm.Events.GetFieldValue(formContext, "niq_additionalinformation");

            if (recordtypeval == 100000001) {
                if (topic == "Access Request" && additionalInfo === null) {
                    formContext
                        .getAttribute("niq_additionalinformation")
                        .setValue(
                            "Indicate if Add/Remove/Modify" +
                            "\n" +
                            "User details. Email and country" +
                            "\n" +
                            "If multiple users please attach a file with full list of users"
                        );
                } else if (topic == "Product Coding Information" && additionalInfo === null) {
                    formContext
                        .getAttribute("niq_additionalinformation")
                        .setValue(
                            "If it is an Image request- please provide the name of the SKU, EAN number" +
                            "\n" +
                            "If it is questions, please provide the EAN or attach an image if available."
                        );
                } else if (topic == "Cross-Country Data" && additionalInfo === null) {
                    formContext
                        .getAttribute("niq_additionalinformation")
                        .setValue("Country" + "\n" + "Category" + "\n" + "Period");
                } else if (
                    topic == "Data Quality Issues" ||
                    topic == "Database Services" ||
                    topic == "Reports"
                ) {
                    formContext.getControl("niq_subtopic").setVisible(true);
                    formContext.getAttribute("niq_subtopic").setRequiredLevel("required");

                    //Clear Existing Options Before Adding New Ones
                    var subtopicControl = formContext.getControl("niq_subtopic");
                    subtopicControl.clearOptions();

                    if (topic == "Data Quality Issues") {
                        subtopicControl.addOption({ text: "Coverage/trend misalignment", value: 610570005 });
                        subtopicControl.addOption({ text: "Unusual data/trend", value: 610570006 });
                        subtopicControl.addOption({ text: "Product classification/segmentation", value: 610570007 });
                        subtopicControl.addOption({ text: "Missing product", value: 610570008 });
                        subtopicControl.addOption({ text: "Other", value: 610570009 });
                    }
                    if (topic == "Database Services") {
                        subtopicControl.addOption({ text: "Product Dimension", value: 610570010 });
                        subtopicControl.addOption({ text: "Fact Dimension", value: 610570011 });
                        subtopicControl.addOption({ text: "Market Dimension", value: 610570012 });
                        subtopicControl.addOption({ text: "Period Dimension", value: 610570013 });
                        subtopicControl.addOption({ text: "Multiple", value: 610570014 });
                    }
                    if (topic == "Reports") {
                        subtopicControl.addOption({ text: "New Report", value: 610570015 });
                        subtopicControl.addOption({ text: "Change Existing", value: 610570016 });
                    }
                }
            } else if (
                topic == "Software Questions & Issues" &&
                recordtypeval == 100000003 &&
                origin != 100000172
            ) {
                formContext.getControl("niq_subtopic").setVisible(true);
                formContext.getAttribute("niq_subtopic").setRequiredLevel("required");

                //Clear Existing Options Before Adding New Ones
                var subtopicControl = formContext.getControl("niq_subtopic");
                subtopicControl.clearOptions();

                subtopicControl.addOption({ text: "Speed and performance", value: 610570000 });
                subtopicControl.addOption({ text: "Error, Unexpected Result", value: 610570001 });
                subtopicControl.addOption({ text: "Problem Sharing", value: 610570002 });
                subtopicControl.addOption({ text: "Problem exporting", value: 610570003 });
                subtopicControl.addOption({ text: "Login Issue", value: 610570004 });
                subtopicControl.addOption({ text: "Other", value: 610570009 });
            } else {
                formContext.getControl("niq_subtopic").setVisible(false);
                formContext.getAttribute("niq_subtopic").setValue(null);
                formContext.getControl("niq_additionalinformation").setVisible(false);
            }
            //Fix for "BAU Request" Not Persisting
            var subtopicControl = formContext.getControl("niq_subtopic");
            var existingOptions = subtopicControl.getOptions();
            var bauOptionExists = existingOptions.some(option => option.value === 610570017);

            if (recordtypeval === 100000001 && topic === "Reports") {
                if (!bauOptionExists) {
                    subtopicControl.addOption({ text: "BAU Request", value: 610570017 });
                }
            } else {
                if (bauOptionExists) {
                    subtopicControl.removeOption(610570017);
                }
            }
            //Ensure Topic Change Triggers the Logic
            formContext.getAttribute("niq_topicid").addOnChange(RequestForm.Events.ShowHideSubTopicSetAdditionalInformation);

        } catch (ex) {
            console.log(ex.message);
        }
    },
    ShowHideWorkTypeFieldValue: function (executionContext) {
        "use strict";
        var rectype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        let _fieldName;
        _fieldName = "niq_worktype";
        if (rectype === 100000003) {
            RequestForm.Events.ShowHideOptionSetValues(executionContext, _fieldName, [610570007], true);

        }
        else if (rectype != 100000003) {
            // CommonForm.Events.ShowHideOptionSetValues(formContext,"niq_worktype",[610570007],false);
            RequestForm.Events.ShowHideOptionSetValues(executionContext, _fieldName, [610570007], false);
            return;
        }
        formContext = executionContext.getFormContext();
        var worktype = formContext.getAttribute("niq_worktype").getValue();
        var Cur_date = CommonForm.Events.GetFieldValue(formContext, "createdon");
        var Req_date = new Date("October 26, 2023");
        if (Cur_date !== undefined && Cur_date === null) {
            formContext.getControl("niq_worktype").removeOption(100000007);
        }
        if (Cur_date != null && Cur_date.getTime() > Req_date.getTime()) {
            formContext.getControl("niq_worktype").removeOption(100000007);
        } else {
            if (worktype != 100000007 || worktype === null) {
                formContext.getControl("niq_worktype").removeOption(100000007);
            }
        }
    },
    FilterAccount: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var accLookupControl = formContext.getControl("customerid");
        if (accLookupControl != null) {
            var fetchXml =
                "<fetch distinct='false' no-lock='false' mapping='logical'>" +
                "<entity name='account' >" +
                "<filter type='and' >" +
                "<condition attribute='niq_accounttype' value='1' operator='eq'/>" +
                "</filter>" +
                "</entity>" +
                "</fetch>";
            accLookupControl.addPreSearch(function () {
                accLookupControl.addCustomFilter(fetchXml);
            });
        }
    },

    //niq_clientalias
    CreatenewActivityTracker: function (executionContext) {
        "use strict";
        if (isdisabledform) return;
        var accountid = CommonForm.Events.GetFieldValue(formContext, "customerid");
        var accname = accountid[0].name;
        var contact = CommonForm.Events.GetFieldValue(
            formContext,
            "primarycontactid",
        );
        var contactid = contact[0].id;
        var contactname = contact[0].name;
        var requestid = formContext.data.entity.getId();
        var requestname = CommonForm.Events.GetFieldValue(formContext, "title");
        var parameters = {};
        if (
            formContext.data.entity.getId() == null &&
            formContext.data.entity.getId() == ""
        )
            return;
        parameters["niq_ataccount"] = accname;
        parameters["niq_ataccountrelated"] = accname;
        parameters["niq_ataccountcontact"] = contactid;
        parameters["niq_ataccountcontact"] = contactname;
        parameters["niq_relatedcontactidtype"] = "contact";
        parameters["niq_atrequest"] = requestid;
        parameters["niq_name"] = requestname;
        parameters["niq_atrequest"] = requestname;
        var formid = "CB7685B9-F442-49D4-8F10-3546424AEB09";
        CommonForm.Events.SetFieldValue(formContext, "niq_clientalias", "");
        var pageInput = {
            pageType: "entityrecord",
            entityName: "niq_activitytracker",
            formId: formid,
            data: parameters,
        };
        var navigationOptions = {
            target: 2,
            height: {
                value: 90,
                unit: "%",
            },
            width: {
                value: 40,
                unit: "%",
            },
            position: 1,
        };
        Xrm.Navigation.navigateTo(pageInput, navigationOptions);
        CommonForm.Events.SetFieldValue(formContext, "niq_clientalias", "*");
        formContext.data.entity.save("success");
    },
    UpdateRoutingWidget: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var ownerid = CommonForm.Events.GetFieldValue(formContext, "ownerid");
        var origin = CommonForm.Events.GetFieldValue(formContext, "caseorigincode");
        var createdby = CommonForm.Events.GetFieldValue(formContext, "createdby");
        // Check if field contains any data before removal of options
        if (
            (origin !== null &&
                origin !== undefined &&
                origin === 100000087 &&
                createdby[0].name === "SYSTEM") ||
            (origin !== null && origin !== undefined && origin === 100000001)
        ) {
            var stageName = formContext.data.process.getActiveStage().getName();
            if (stageName === "New") {
                CommonForm.Events.SetFieldValue(
                    formContext,
                    "niq_routingstatusvalue",
                    100000001,
                );
                formContext.data.entity.save("success");
            } else if (stageName === "Assigned") {
                CommonForm.Events.SetFieldValue(
                    formContext,
                    "niq_routingstatusvalue",
                    100000002,
                );
                formContext.data.entity.save("success");
            }
        }
    },
    // Method to show error if chatbot and community options are selected from request origin when origin is empty
    // only when it is empty, the field is editable, if it has data it is readonly to all users
    RemoveRequestOriginOptions: function (originctrl) {
        "use strict"; //   these options are not visible during record creation in the form
        // check if origin does not contain data
        var origin = CommonForm.Events.GetFieldValue(formContext, "caseorigincode");
        // Check if field contains any data before removal of options
        if (origin === null || origin === undefined) {
            // remove chatbot and community
            var optionstoremove = [100000001, 100000087, 100000135];
            for (var i = 0; i < optionstoremove.length; i++)
                originctrl.removeOption(optionstoremove[i]); // remove options in the array from the UI
        }
        if (origin === null || origin === undefined) {
            // remove chatbot and community
            var optionSetValues = originctrl.getOptions();
            originctrl.clearOptions();
            //var option = { value : 100000087, text : "Chat" };
            for (var i = 1; i <= 10; i++) originctrl.addOption(optionSetValues[i]);
            originctrl.addOption(optionSetValues[65]);
            for (var i = 82; i <= 89; i++) originctrl.addOption(optionSetValues[i]);
            originctrl.addOption(optionSetValues[136]);
        }
    },
    //NGH Acct mgmt - Only admin, NGH Agent,  manager can change the priority of NGH AM record
    CheckNGHAccountManagementPriority: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var rectype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        // if  rec type  is  NGH ACC mgmt
        if (rectype !== null && rectype !== undefined && rectype === 100000004) {
            // check if  logged in user role  is  system admin  or  NGH related  or  integration then editable
            if (
                CommonForm.Events.CheckIfLoggedInUserRole("System Administrator") ||
                CommonForm.Events.CheckIfLoggedInUserRole(
                    "NIQ Global Helpline Agent",
                ) ||
                CommonForm.Events.CheckIfLoggedInUserRole(
                    "NIQ Global Helpline Manager",
                ) ||
                CommonForm.Events.CheckIfLoggedInUserRole("Integration")
            ) {
                // enable the priority field
                formContext.getControl("prioritycode").setDisabled(false);
            } else formContext.getControl("prioritycode").setDisabled(true); // otherwise disable the priority field
        }
    },
    // show only Analytics, CR, NGH  record types in quickcreate form
    RemoveRecordTypeOptionsForQuickCreate: function (recordtypectrl) {
        "use strict"; //   these options are not visible during record creation in the form
        // hiding the other record types for  quick create
        if (
            CommonForm.Events.CheckIfLoggedInUserRoles(
                "System Administrator,NIQ Delegate Agent,NIQ Delegate Submitter,NIQ Delegate Manager",
            )
        ) {
            var optionstoremove = [
                100000004, 100000005, 100000006, 100000007, 100000008, 100000009,
                100000010, 100000011, 100000012, 100000013,
            ];
            for (var i = 0; i < optionstoremove.length; i++)
                recordtypectrl.removeOption(optionstoremove[i]); // remove options in the array from the UI
        } else {
            var optionstoremove = [
                100000002, 100000004, 100000005, 100000006, 100000007, 100000008,
                100000009, 100000010, 100000011, 100000012, 100000013,
            ];
            for (var i = 0; i < optionstoremove.length; i++)
                recordtypectrl.removeOption(optionstoremove[i]); // remove options in the array from the UI
        }
    },
    // hide fields after save of quick create in quickcreate form
    HideFieldsonSaveOfQuickCreate: function (executionContext) {
        "use strict"; //   these options are not visible during record creation in the form
        formContext = executionContext.getFormContext();
        // fields to be hided after saving form from quick create
        var hidefieldsaftersaveforquickcreate = [
            "niq_plannedstartdate",
            "niq_plannedenddate",
            "niq_frequency",
            "niq_totalplannedefforts",
            "niq_serviceproduct",
            "niq_businesstopicsincluded",
            "niq_guidedanalyticsused",
            "niq_guidedanalyticscontent",
            "niq_clientoutcomeorclientbusinessopportunity",
            "niq_analyticscomments",
            "niq_multiclient",
            "niq_numberofclients",
            "niq_deliverymode",
            "niq_targetaudience",
            "niq_numberofcountries",
            "niq_numberofdatabases",
            "niq_numberofcategories",
            "niq_numberofperformanceoverview",
            "niq_numberofbusinessissueanalysis",
            "niq_numberofslidespagestabs",
            "niq_worktype",
            "niq_countryofwork",
            "niq_businessline",
            "niq_nghagenttierid",
            "niq_nghproductid",
            "niq_oftotalusers",
            "niq_formdetails",
        ];
        CommonForm.Events.SetRequiredFieldLevels(
            formContext,
            hidefieldsaftersaveforquickcreate,
            "none",
        );
        CommonForm.Events.ShowHideFields(
            formContext,
            hidefieldsaftersaveforquickcreate,
            false,
        );
    },
    // when the  chatbot or community are selected in request main form, then show this error message
    ValidateRequestOriginMessage: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        formContext.ui.clearFormNotification("requestoriginvalidation");
        var originval = CommonForm.Events.GetFieldValue(
            formContext,
            "caseorigincode",
        );
        // check if selected value of request origin is chatbot or community
        if (
            originval !== null &&
            originval !== undefined &&
            (originval === 100000001 || originval === 100000087)
        ) {
            //throw an error message
            formContext.ui.setFormNotification(
                "Cannot select Chatbot or Community",
                "ERROR",
                "requestoriginvalidation",
            );
        }
    },
    //Method to set entity type for customer lookup
    SetEntityTypeLookup: function (formctrl) {
        "use strict";
        formctrl.setEntityTypes(["account"]);
        // set the custom search -
        formctrl.addPreSearch(RequestForm.Events.FilterAccountlookup);
    },
    //Method to filter topics lookup
    FilterTopicslistForRecordType: function (executionContext, operation) {
        "use strict";
        formContext = executionContext.getFormContext();
        var recordtypeval = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        // on change of record type in the form, clear the value selected in topic
        if (operation === null || operation === undefined) {
            if (recordtypeval !== null && recordtypeval !== 100000003)
                //  clear  topic if it is not NGH
                CommonForm.Events.SetFieldValue(formContext, "niq_topicid", null);
        }
        // check if the topic field value exists
        if (
            CommonForm.Events.CheckFieldExists(formContext, "niq_topicid") &&
            recordtypeval !== null
        ) {
            // remove presearch to topic field
            formContext
                .getControl("niq_topicid")
                .removePreSearch(RequestForm.Events.Filtertopiclookup);
            // add presearch to topic field to show only topics for this record type
            formContext
                .getControl("niq_topicid")
                .addPreSearch(RequestForm.Events.Filtertopiclookup);
        }
    },
    clearValuetoNGHProduct: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        CommonForm.Events.SetFieldValue(formContext, "niq_nghproductid", null);
        RequestForm.Events.setDefaultValuetoNGHProductforMetering(executionContext);
    },
    //Method to filter NGH Product lookup
    FilterNGHProductForBusinessline: function (executionContext, operation) {
        "use strict";
        formContext = executionContext.getFormContext();
        var businessline = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_businessline",
        );
        // on change of Businesslinetype in the form, clear the value selected in product
        if (operation === null || operation === undefined) {
            CommonForm.Events.SetFieldValue(formContext, "niq_nghproductid", null);
        }
        // check if  product and businessline exists
        if (
            CommonForm.Events.CheckFieldExists(formContext, "niq_nghproductid") &&
            businessline !== null
        ) {
            // remove presearch to Product field
            formContext
                .getControl("niq_nghproductid")
                .removePreSearch(RequestForm.Events.FilterNGHProductlookup);
            // add presearch to Product field to show only product for this Businessline
            formContext
                .getControl("niq_nghproductid")
                .addPreSearch(RequestForm.Events.FilterNGHProductlookup);
        }
    },

    // set Software Question for NGH record type - onchange of  record type
    setDefaultValuetoNGHProductforMetering: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var recordtypeval = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        var topiclookup = formContext.getAttribute("niq_topicid").getValue();
        var topic = topiclookup != null ? topiclookup[0].name : "";
        var businessline = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_businessline",
        );
        if (
            recordtypeval !== null &&
            recordtypeval === 100000003 &&
            businessline != null &&
            (businessline == 100000000 || businessline == 100000001) &&
            (topic == "Data Plans Support (Questions & Issues)" ||
                topic == "Data Plans Sales (Data Point Limits/ Tier Changes)")
        ) {
            // NGH Record type
            var fetchxml =
                "?fetchXml=<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                "<entity name='niq_nghproduct'>" +
                "<attribute name='niq_name' />" +
                "<attribute name='niq_nghproductid' />" +
                "<filter type='and'>" +
                "<condition attribute='niq_businessline' operator='eq' value='" +
                businessline +
                "'/>" +
                "<condition attribute='niq_name' operator='eq' value='Discover' />" +
                "<condition attribute='statecode' operator='eq' value='0' />" +
                "</filter>" +
                "</entity>" +
                "</fetch>";
            Xrm.WebApi.online
                .retrieveMultipleRecords("niq_nghproduct", fetchxml)
                .then(function success(result) {
                    if (result.entities.length > 0 && result.entities.length == 1) {
                        var nghproductid = result.entities[0].niq_nghproductid;
                        if (nghproductid !== null && nghproductid !== undefined) {
                            var lkupproduct = [];
                            lkupproduct[0] = {};
                            lkupproduct[0].id = nghproductid;
                            lkupproduct[0].entityType = "niq_nghproduct";
                            lkupproduct[0].name = result.entities[0].niq_name;
                            // set topic as lookup value
                            CommonForm.Events.SetFieldValue(
                                formContext,
                                "niq_nghproductid",
                                lkupproduct,
                            );
                        }
                    } else if (result.entities.length > 1) {
                        CommonForm.Events.SetFieldValue(
                            formContext,
                            "niq_nghproductid",
                            null,
                        );
                    } else {
                        CommonForm.Events.SetFieldValue(
                            formContext,
                            "niq_nghproductid",
                            null,
                        );
                    }
                });
        }
    },

    // set Software Question for NGH record type - onchange of  record type
    SetDefaultTopicSoftwareQuestion: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var recordtypeval = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        if (recordtypeval !== null && recordtypeval === 100000003) {
            // NGH Record type
            var fetchxml =
                "?fetchXml=<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                "<entity name='niq_topic'>" +
                "<attribute name='niq_topicid' />" +
                "<attribute name='niq_name' />" +
                "<filter type='and'>" +
                "<condition attribute='niq_name' operator='like' value='%Software Question%' />" +
                "</filter>" +
                "</entity>" +
                "</fetch>";
            Xrm.WebApi.online
                .retrieveMultipleRecords("niq_topic", fetchxml)
                .then(function success(result) {
                    if (result.entities.length > 0) {
                        var topicid = result.entities[0].niq_topicid;
                        if (topicid !== null && topicid !== undefined) {
                            var lkuptopic = [];
                            lkuptopic[0] = {};
                            lkuptopic[0].id = topicid;
                            lkuptopic[0].entityType = "niq_topic";
                            lkuptopic[0].name = result.entities[0].niq_name;
                            // set topic as lookup value
                            CommonForm.Events.SetFieldValue(
                                formContext,
                                "niq_topicid",
                                lkuptopic,
                            );
                        }
                    }
                });
        }
    },

    // set Agent Tier for NGH record type
    SetDefaultAgentTierForNGH: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var recordtypeval = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        if (
            recordtypeval !== null &&
            recordtypeval === 100000003 &&
            formContext.ui.getFormType() === 1
        ) {
            // NGH Record type
            var fetchxml =
                "?fetchXml=<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                "<entity name='niq_nghtier'>" +
                "<attribute name='niq_nghtierid' />" +
                "<attribute name='niq_name' />" +
                "<filter type='and'>" +
                "<condition attribute='niq_name' operator='like' value='%L1%' />" +
                "</filter>" +
                "</entity>" +
                "</fetch>";
            Xrm.WebApi.online
                .retrieveMultipleRecords("niq_nghtier", fetchxml)
                .then(function success(result) {
                    if (result.entities.length > 0) {
                        var agentid = result.entities[0].niq_nghtierid;
                        if (agentid !== null && agentid !== undefined) {
                            var lkupagent = [];
                            lkupagent[0] = {};
                            lkupagent[0].id = agentid;
                            lkupagent[0].entityType = "niq_nghtier";
                            lkupagent[0].name = result.entities[0].niq_name;
                            // set topic as lookup value
                            CommonForm.Events.SetFieldValue(
                                formContext,
                                "niq_nghagenttierid",
                                lkupagent,
                            );
                        }
                    }
                });
        }
    },

    //Method to filter NGHProduct lookup based on the filter value
    FilterNGHProductlookup: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var topiclookup = formContext.getAttribute("niq_topicid").getValue();
        var topic = topiclookup != null ? topiclookup[0].name : "";
        var businessline = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_businessline",
        );
        CommonForm.Events.SetFieldValue(formContext, "niq_nghproductid", null);
        // construct fetchxml based on the businessline value
        var fetchXml =
            "<filter type='and'>  <condition attribute='statecode' operator='eq' value='0' /> <condition attribute='niq_businessline' operator='eq' value='" +
            businessline +
            "' />";
        if (
            (topic == "Data Plans Support (Questions & Issues)" ||
                topic == "Data Plans Sales (Data Point Limits/ Tier Changes)") &&
            (businessline == 100000000 || businessline == 100000001)
        ) {
            fetchXml =
                fetchXml +
                "<condition attribute='niq_name' operator='eq' value='Discover' />";
        }
        fetchXml = fetchXml + "</filter>";
        formContext
            .getControl("niq_nghproductid")
            .addCustomFilter(fetchXml, "niq_nghproduct");
    },
    //Method to filter topic lookup based on the filter value
    Filtertopiclookup: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var rectypevalue = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        // construct fetchxml based on the record type value
        var fetchXml =
            "<filter type='and'>  <condition attribute='statecode' operator='eq' value='0' /> <condition attribute='niq_recordtype' operator='like' value='%" +
            rectypevalue +
            "%' /> <condition attribute='niq_nsstype' operator='ne' value='1' /> </filter>";
        formContext
            .getControl("niq_topicid")
            .addCustomFilter(fetchXml, "niq_topic");
    },
    // filter customerid lookup
    FilterAccountlookup: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var customeraccount = 1;
        // construct fetchxml based on the record type value
        var fetchXml =
            "<filter type='and'>  <condition attribute='statecode' operator='eq' value='0' /> <condition attribute='niq_accounttype' operator='eq' value='" +
            customeraccount +
            "' /> </filter>";
        formContext.getControl("customerid").addCustomFilter(fetchXml, "account");
    },
    // Method to filter related optionsets and set value during onload
    FilterStatusRelatedOptionsets: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        //filter the substatus lookup and set the value of the lookup
        var substatusvalue = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_substatus",
        );
        RequestForm.Events.FilterSubStatusValues(
            executionContext,
            "statuscode",
            "niq_substatus",
        );
        if (substatusvalue !== null && substatusvalue !== undefined)
            CommonForm.Events.SetFieldValue(
                formContext,
                "niq_substatus",
                substatusvalue,
            );
    },
    // Method to filter inprogress substatus optionsets and set value during onload
    FilterinprogressStatusRelatedOptionsets: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        //filter the inprogresssubstatus lookup and set the value of the lookup
        var inprogressSubstatusvalue = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_inprogresssubstatus",
        );
        RequestForm.Events.FilterInprogressSubStatusValues(
            executionContext,
            "statuscode",
            "niq_inprogresssubstatus",
        );
        if (
            inprogressSubstatusvalue !== null &&
            inprogressSubstatusvalue !== undefined
        )
            CommonForm.Events.SetFieldValue(
                formContext,
                "niq_inprogresssubstatus",
                inprogressSubstatusvalue,
            );
    },
    // method to filter substatus lookup values based on the status change
    FilterSubStatusValues: function (
        executionContext,
        parentfieldname,
        childfieldname,
    ) {
        "use strict";
        var statusvalue = CommonForm.Events.GetFieldValue(
            formContext,
            parentfieldname,
        );
        var substatusvalue = CommonForm.Events.GetFieldValue(
            formContext,
            childfieldname,
        );
        var rectypevalue = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        var origin = CommonForm.Events.GetFieldText(formContext, "caseorigincode");
        if (
            statusvalue !== null &&
            statusvalue !== 100000000 &&
            statusvalue !== 100000001 &&
            statusvalue !== 6
        ) {
            //Inprogress, responded, closed, reopened
            var filteroptionarray = [
                [
                    100000002, 100000004, 100000005, 100000006, 100000007, 100000021,
                    100000023, 100000022, 100000024, 100000025, 100000026,
                ],
                [100000003, 100000001, 100000003, 100000000],
                [
                    5, 100000004, 100000005, 100000006, 100000007, 100000021, 100000023,
                    100000022, 100000027,
                ],
                [100000004, 100000008, 100000009, 100000006],
            ];
            switch (rectypevalue) {
                case 100000001:
                // CR - working- on time, working- delayed, hold- internal, hold-external, awaiting, On Hold - Software Issue
                case 100000000:
                    // Analytics
                    filteroptionarray.push([
                        1, 100000001, 100000003, 100000002, 100000024, 100000025, 100000026,
                    ]);
                    break;
                case 100000002:
                    // delegate - working- on time, working- delayed , quality , ready for delivery, On Hold - Software Issue
                    filteroptionarray.push([
                        1, 100000011, 100000012, 100000024, 100000025, 100000026,
                    ]);
                    break;
                case 100000003:
                    // NGH
                    if (origin === "NGH Forms") {//DYNCRM-23717
                        filteroptionarray.push([
                            //working, hold- internal, hold-external, hold-internal long, On Hold - Software Issue, Error, Portal, Ready for Agent Action
                            1, 100000001, 100000003, 100000000, 100000010, 100000026, 100000016, 100000020,
                        ]);
                    }
                    else {
                        filteroptionarray.push([
                            //working, hold- internal, hold-external, hold-internal long, On Hold - Software Issue
                            1, 100000001, 100000003, 100000000, 100000010, 100000026,
                        ]);
                    }
                    break;
                case 100000004:
                    // NGH- working, hold- internal, hold-external, hold-internal long, On Hold - Software Issue
                    filteroptionarray.push([
                        1, 100000001, 100000003, 100000000, 100000010, 100000013, 100000014,
                        100000015, 100000016, 100000017, 100000018, 100000019, 100000020,
                        100000026, 100000006, 100000024,
                    ]);
                    break;
                default:
                    filteroptionarray.push([
                        1, 100000001, 100000003, 100000000, 100000002,
                    ]);
                    break;
            }
            if (
                rectypevalue == 100000003 ||
                rectypevalue == 100000004 ||
                rectypevalue == 100000000 ||
                rectypevalue == 100000001 ||
                rectypevalue == 100000002
            ) {
                if (
                    statusvalue !== 6 &&
                    statusvalue !== 100000008 &&
                    statusvalue !== 1000 &&
                    substatusvalue !== 100000006 &&
                    substatusvalue !== null
                )
                    CommonForm.Events.filteroptions(
                        executionContext,
                        parentfieldname,
                        childfieldname,
                        initialSubStatusvalues,
                        filteroptionarray,
                    );
            } else {
                // call commonFormEvents - method
                CommonForm.Events.filteroptions(
                    executionContext,
                    parentfieldname,
                    childfieldname,
                    initialSubStatusvalues,
                    filteroptionarray,
                );
            }
        }
    },
    //BPF- method to Inprogressfilter substatus lookup values based on the status change
    FilterInprogressSubStatusValues: function (
        executionContext,
        parentfieldname,
        childfieldname,
    ) {
        "use strict";
        var statusvalue = CommonForm.Events.GetFieldValue(
            formContext,
            parentfieldname,
        );
        var optionSetControl = formContext.getControl("niq_inprogresssubstatus"); // inprogress options
        var optionValues = optionSetControl.getOptions();
        var rectypevalue = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        var origin = CommonForm.Events.GetFieldText(formContext, "caseorigincode");
        if (
            rectypevalue !== null &&
            rectypevalue !== undefined &&
            statusvalue !== null &&
            statusvalue !== 6
        ) {
            //Inprogress option values
            var filterinprogressoptions = "";
            switch (rectypevalue) {
                case 100000001:
                // CR - working- on time, working- delayed , hold- internal, hold-external, awaiting, On Hold - Software Issue
                case 100000000:
                    // Analytics
                    filterinprogressoptions =
                        "100000001,100000003,100000002,100000024,100000025, 100000026";
                    break;
                case 100000002:
                    // delegate - working- on time, working- delayed , quality , ready for delivery , On Hold - Software Issue
                    filterinprogressoptions =
                        "100000011,100000012,100000024,100000025, 100000026";
                    break;
                case 100000003:
                    if (origin === "NGH Forms") {//DYNCRM-23717
                        // NGH-working, hold- internal, hold-external, hold-internal long, On Hold - Software Issue, Error, Portal, Ready for Agent Action
                        filterinprogressoptions =
                            "100000001,100000003,100000000,100000010,100000026,100000016, 100000020";
                    }
                    else {//working, hold- internal, hold-external, hold-internal long, On Hold - Software Issue
                        filterinprogressoptions =
                            "100000001,100000003,100000000,100000010,100000026";
                    }
                    break;
                case 100000004:
                    // NGH- working, hold- internal, hold-external, hold-internal long, On Hold - Software Issue
                    filterinprogressoptions =
                        "100000001,100000003,100000000,100000010,100000013,100000014,100000015, 100000016,100000017, 100000018,100000019, 100000020,100000024,100000026,100000006";
                    break;
                default:
                    filterinprogressoptions = "100000001,100000003,100000000,100000002";
                    break;
            }
            // clear the options
            optionSetControl.clearOptions();
            // check if the inprogress sub status values
            for (var k = 0; k < initialprogressSubStatusvalues.length; k++) {
                if (
                    initialprogressSubStatusvalues[k].text !== "" &&
                    filterinprogressoptions.indexOf(
                        initialprogressSubStatusvalues[k].value,
                    ) < 0
                ) {
                    //optionSetControl.removeOption(initialprogressSubStatusvalues[k].value);
                } else {
                    optionSetControl.addOption(initialprogressSubStatusvalues[k]);
                }
            }
        }
    },
    //method to filter language details based on the GCD /NGH record types
    FilterLanguageDetails: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var optionSetControl = formContext.getControl("niq_language");
        var statusvalue = CommonForm.Events.GetFieldValue(
            formContext,
            "statuscode",
        );
        var optionValues = optionSetControl.getOptions();
        // get record type and check if it is equal to NGH or NGH acc mgmt
        var rectypevalue = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        if (
            rectypevalue !== null &&
            (rectypevalue === 100000003 || rectypevalue === 100000004) &&
            statusvalue !== 6
        ) {
            var filteroptions =
                "100000008,100000014,100000015,100000019,100000028,100000033,100000046,100000047";
            // remove the options from the dropdown if it is not available in above list
            optionSetControl.clearOptions();
            for (var k = 0; k < initialLangOptions.length; k++) {
                if (filteroptions.indexOf(initialLangOptions[k].value) > -1)
                    optionSetControl.addOption(initialLangOptions[k]);
            }
        } else {
            if (optionValues.length < initialLangOptions.length) {
                optionSetControl.clearOptions();
                for (var k = 0; k < initialLangOptions.length; k++) {
                    optionSetControl.addOption(initialLangOptions[k]);
                }
            }
            optionSetControl.removeOption(100000046);
            optionSetControl.removeOption(100000047);
        }
    },
    //Method to load recordtype dropdown based on user role
    LoadRecordTypes: function (formContext, operation) {
        "use strict";
        try {
            var recordtypes = ""; // empty
            var fieldname = "niq_recordtypeoption";
            if (operation === "update") fieldname = "niq_readonlyrecordtypes";
            var optionSetControl = formContext.getControl("niq_recordtype");
            CommonForm.Events.GetUserRoleNames();
            // roles based options are retrieved
            if (gsCurrentUserRoles.length > 0) {
                var fetchXml =
                    "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'> <entity name='niq_recordtyperolemapping'> <attribute name='niq_readonlyrecordtypes' /> <attribute name='niq_recordtypeoption' /> <filter type='and'> <filter type='or'> ";
                for (var counter = 0; counter < gsCurrentUserRoles.length; counter++) {
                    fetchXml +=
                        "<condition attribute='niq_name' operator='eq' value='" +
                        gsCurrentUserRoles[counter] +
                        "' />";
                }
                fetchXml += "</filter> </filter> </entity> </fetch>";
                // get the record types from recordtype role mapping entity
                // changed  this from async to sync function since it is determining if a form is enabled or disabled
                var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
                var result = GetCRMWebAPI.Methods.GetFetchRecords(
                    clienturl,
                    fetchXml,
                    "niq_recordtyperolemappings",
                );
                // perform additional operations on retrieved records
                if (
                    result !== null &&
                    result.value !== null &&
                    result.value.length > 0
                ) {
                    for (var i = 0; i < result.value.length; i++) {
                        var rec = result.value[i][fieldname];
                        var createOptions = result.value[i]["niq_recordtypeoption"];
                        if (rec !== null && rec !== undefined && rec !== "") {
                            var spltarry = rec.split(",");
                            for (var j = 0; j < spltarry.length; j++) {
                                if (
                                    spltarry[j] !== "" &&
                                    recordtypes.indexOf(spltarry[j]) < 0
                                ) {
                                    recordtypes += "," + spltarry[j];
                                }
                            }
                        }
                    }
                }
                if (operation === "update") {
                    var thisrectype = CommonForm.Events.GetFieldValue(
                        formContext,
                        "niq_recordtype",
                    );
                    var createdon = CommonForm.Events.GetFieldValue(
                        formContext,
                        "createdon",
                    );
                    var ownerid = CommonForm.Events.GetFieldValue(formContext, "ownerid");
                    var curuserid = Xrm.Utility.getGlobalContext().userSettings.userId;

                    if (thisrectype !== null && thisrectype !== undefined) {
                        switch (thisrectype) {
                            case 100000001:
                                // CR
                                var canEditRequestRole =
                                    "System Administrator,NIQ Client Response Agent,NIQ Client Response Manager,NIQ Analytics Agent,NIQ Analytics Manager,NIQ Global Helpline Manager,NIQ Global Helpline Agent,NIQ Customer Service";
                                if (
                                    !CommonForm.Events.CheckIfLoggedInUserRoles(
                                        canEditRequestRole,
                                    )
                                ) {
                                    //check if the owner is not equal to current user
                                    //if (ownerid[0].id === curuserid && CommonForm.Events.CheckIfLoggedInUserRole("NIQ Ops Solution Provider"))
                                    // {
                                    // }
                                    // else
                                    // {
                                    CommonForm.Events.disableFormFields(true, formContext);
                                    isdisabledform = true;
                                    //  }
                                }
                                break;
                            case 100000000:
                                // Analytic
                                var canEditRequestRole =
                                    "System Administrator,NIQ Client Response Agent,NIQ Client Response Manager,NIQ Analytics Agent,NIQ Analytics Manager,NIQ Global Helpline Manager,NIQ Global Helpline Agent,NIQ Customer Service";
                                if (
                                    !CommonForm.Events.CheckIfLoggedInUserRoles(
                                        canEditRequestRole,
                                    )
                                ) {
                                    CommonForm.Events.disableFormFields(true, formContext);
                                    isdisabledform = true;
                                }
                                break;
                            case 100000002:
                                // Delegate
                                var canEditRequestRole =
                                    "System Administrator,NIQ Delegate Agent,NIQ Delegate Manager";
                                if (
                                    !CommonForm.Events.CheckIfLoggedInUserRoles(
                                        canEditRequestRole,
                                    )
                                ) {
                                    CommonForm.Events.disableFormFields(true, formContext);
                                    isdisabledform = true;
                                }
                                break;
                            case 100000003:
                                // NGH
                                var canEditRequestRole =
                                    "System Administrator,NIQ Client Response Agent,NIQ Client Response Manager,NIQ Analytics Agent,NIQ Analytics Manager,NIQ Global Helpline Manager,NIQ Global Helpline Agent";
                                if (
                                    !CommonForm.Events.CheckIfLoggedInUserRoles(
                                        canEditRequestRole,
                                    )
                                ) {
                                    CommonForm.Events.disableFormFields(true, formContext);
                                    isdisabledform = true;
                                }
                                break;
                            case 100000004:
                                // NGH - AM
                                var canEditRequestRole =
                                    "System Administrator,NIQ Global Helpline Manager,NIQ Global Helpline Agent";
                                if (
                                    !CommonForm.Events.CheckIfLoggedInUserRoles(
                                        canEditRequestRole,
                                    )
                                ) {
                                    CommonForm.Events.disableFormFields(true, formContext);
                                    isdisabledform = true;
                                }
                                break;
                        }
                    }
                    // for update option ,  if the current record type is equal to the available types
                    if (
                        thisrectype !== null &&
                        createdon !== null &&
                        recordtypes.indexOf(thisrectype) > -1
                    ) {
                        //CommonForm.Events.disableFormFields(true, formContext);
                        //isdisabledform = true;
                    } else {
                        // remove options
                        var optionValues = optionSetControl.getOptions();
                        for (var m = 0; m < optionValues.length; m++) {
                            if (
                                optionValues[m].text !== "" &&
                                createOptions !== undefined &&
                                createOptions.indexOf(optionValues[m].value) < 0
                            ) {
                                optionSetControl.removeOption(optionValues[m].value);
                            }
                        }
                    }
                } else {
                    // for create option
                    // remove options
                    var optionValues = optionSetControl.getOptions();
                    for (var k = 0; k < optionValues.length; k++) {
                        if (
                            optionValues[k].text !== "" &&
                            recordtypes.indexOf(optionValues[k].value) < 0
                        ) {
                            optionSetControl.removeOption(optionValues[k].value);
                        }
                    }
                    if (
                        CommonForm.Events.CheckIfLoggedInUserRoles(nghAgentManagerRoles)
                    ) {
                        // remove options
                        var optionValues = optionSetControl.getOptions();
                        for (var k = 0; k < optionValues.length; k++) {
                            if (
                                optionValues[k].text !== "" &&
                                optionValues[k].text === "NGH Account Management"
                            ) {
                                optionSetControl.removeOption(optionValues[k].value);
                            }
                        }
                    }
                }
            }
        } catch (Err) { }
    },
    // to restrict based on record type and owner
    CheckRecordTypeBasedAccess: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var rectype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        //to check record type analytics,cr,ngh
        if (
            rectype !== null &&
            (rectype === 100000003 || rectype === 100000000 || rectype === 100000001)
        ) {
            this.CheckNGHOpsSubmitterEdit(executionContext);
        }
    },
    CheckNGHOpsSubmitterEdit: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        if (
            CommonForm.Events.CheckIfLoggedInUserRole("NIQ Ops Submitter") ||
            CommonForm.Events.CheckIfLoggedInUserRole("NIQ Ops Solution Provider")
        ) {
            var ownerid = CommonForm.Events.GetFieldValue(formContext, "ownerid");
            var curuserid = Xrm.Utility.getGlobalContext().userSettings.userId;
            //check if the owner is not equal to current user
            if (ownerid[0].id !== curuserid) {
                CommonForm.Events.disableFormFields(true, formContext);
                isdisabledform = true;
            }
        }
    },
    SetMultiOptionsetVisibility: function (executionContext, operation) {
        "use strict";
        formContext = executionContext.getFormContext();
        var isquickcreate = false;
        var multiselectsurveyfields = [
            "niq_serviceproduct",
            "niq_businesstopicsincluded",
        ];
        if (formContext.ui.tabs.getLength() === 1) isquickcreate = true;
        var rectype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        if (rectype !== null && rectype !== undefined) {
            var multiselectnghfields = ["niq_countryofwork"];
            var qcselectnghfields = [
                "niq_nghproductid",
                "niq_worktype",
                "niq_oftotalusers",
                "niq_nghagenttierid",
                "niq_businessline",
                "niq_formdetails",
                "niq_formname",
            ];
            // analytics
            if (
                rectype !== null &&
                (rectype === 100000000 ||
                    rectype === 100000001 ||
                    rectype === 100000002)
            ) {
                CommonForm.Events.ShowHideFields(
                    formContext,
                    multiselectnghfields,
                    false,
                );
                CommonForm.Events.ShowHideFields(
                    formContext,
                    multiselectsurveyfields,
                    true,
                );
                //  RequestForm.Events.ActivityTypeOnChangeMultipleOptionset(executionContext);
                //call the function only for Main form
                if (formContext.ui.tabs.getLength() !== 1) {
                    RequestForm.Events.SubActivityTypeOnChangeMultipleOptionset(
                        executionContext,
                    );
                }
            } else {
                CommonForm.Events.ShowHideFields(
                    formContext,
                    multiselectsurveyfields,
                    false,
                );
            }
            RequestForm.Events.ShowErrorForNielsenGlobal(executionContext);
            if (isquickcreate) {
                var showquickfields = [
                    "niq_plannedstartdate",
                    "niq_plannedenddate",
                    "niq_frequency",
                    "niq_totalplannedefforts",
                    "niq_serviceproduct",
                    "niq_businesstopicsincluded",
                    "niq_guidedanalyticsused",
                    "niq_guidedanalyticscontent",
                    "niq_clientoutcomeorclientbusinessopportunity",
                    "niq_analyticscomments",
                    "niq_multiclient",
                    "niq_numberofclients",
                    "niq_deliverymode",
                    "niq_targetaudience",
                ];
                var numberoffieldstohideforngh = [
                    "niq_numberofcountries",
                    "niq_numberofdatabases",
                    "niq_numberofcategories",
                    "niq_numberofperformanceoverview",
                    "niq_numberofbusinessissueanalysis",
                    "niq_numberofslidespagestabs",
                ];
                if (rectype !== null && rectype !== undefined) {
                    switch (rectype) {
                        case 100000000:
                            //  analytics
                            CommonForm.Events.ShowHideFields(
                                formContext,
                                showquickfields,
                                true,
                            );
                            CommonForm.Events.ShowHideFields(
                                formContext,
                                qcselectnghfields,
                                false,
                            );
                            break;
                        case 100000001:
                            // CR
                            CommonForm.Events.ShowHideFields(
                                formContext,
                                showquickfields,
                                true,
                            );
                            CommonForm.Events.ShowHideFields(
                                formContext,
                                qcselectnghfields,
                                false,
                            );
                            break;
                        case 100000003:
                            // Delegate
                            CommonForm.Events.ShowHideFields(
                                formContext,
                                qcselectnghfields,
                                true,
                            );
                            CommonForm.Events.ShowHideFields(
                                formContext,
                                showquickfields,
                                false,
                            );
                            CommonForm.Events.ShowHideFields(
                                formContext,
                                numberoffieldstohideforngh,
                                false,
                            );
                            break;
                    }
                }
            }
            //common for both main and quick create
            if (rectype === 100000003 || rectype === 100000004) {
                // NGH & NGH AM
                var nghadminrolevisiblefields = ["niq_language"];
                var nghadminrolenotvisiblefields = ["niq_worktype"];
                var nghadminrolenotreqdfields = ["niq_worktype"];
                // if logged in user is not having admin or NIQ agent or NIQ manager - Add
                if (
                    CommonForm.Events.CheckIfLoggedInUserRole("System Administrator") ||
                    CommonForm.Events.CheckIfLoggedInUserRole(
                        "NIQ Global Helpline Agent",
                    ) ||
                    CommonForm.Events.CheckIfLoggedInUserRole(
                        "NIQ Global Helpline Manager",
                    )
                ) {
                    CommonForm.Events.ShowHideFields(
                        formContext,
                        multiselectnghfields,
                        true,
                    );
                    CommonForm.Events.SetRequiredFieldLevels(
                        formContext,
                        multiselectnghfields,
                        "required",
                    );
                    CommonForm.Events.ShowHideFields(
                        formContext,
                        nghadminrolenotvisiblefields,
                        true,
                    );
                    CommonForm.Events.SetRequiredFieldLevels(
                        formContext,
                        nghadminrolevisiblefields,
                        "required",
                    );
                    CommonForm.Events.SetRequiredFieldLevels(
                        formContext,
                        nghadminrolenotreqdfields,
                        "required",
                    );
                    formContext.getControl("niq_nghagenttierid").setDisabled(false);
                } else {
                    // show these fields
                    CommonForm.Events.ShowHideFields(
                        formContext,
                        nghadminrolevisiblefields,
                        true,
                    );
                    CommonForm.Events.SetRequiredFieldLevels(
                        formContext,
                        nghadminrolevisiblefields,
                        "none",
                    );
                    CommonForm.Events.SetRequiredFieldLevels(
                        formContext,
                        nghadminrolenotreqdfields,
                        "none",
                    );
                    // hide these fields
                    CommonForm.Events.ShowHideFields(
                        formContext,
                        nghadminrolenotvisiblefields,
                        false,
                    );
                    CommonForm.Events.SetRequiredFieldLevels(
                        formContext,
                        nghadminrolenotvisiblefields,
                        "none",
                    );
                    //To disable for all other roles
                    formContext.getControl("niq_nghagenttierid").setDisabled(true);
                }
                // common for all roles  - show  these fields & required
            } else {
                // hide for all other rec types
                CommonForm.Events.ShowHideFields(
                    formContext,
                    multiselectnghfields,
                    false,
                );
                CommonForm.Events.SetRequiredFieldLevels(
                    formContext,
                    multiselectnghfields,
                    "none",
                );
            }
        }
        RequestForm.Events.FilterTopicslistForRecordType(
            executionContext,
            operation,
        );
        RequestForm.Events.FilterNGHProductForBusinessline(
            executionContext,
            operation,
        );
        RequestForm.Events.FilterLanguageDetails(executionContext);
        // call this function only during onchange of record type , not onload
        if (operation === null || operation === undefined) {
            RequestForm.Events.SetDefaultAgentTierForNGH(executionContext);
        }
        // check and invoke only for main form
        if (formContext.ui.tabs.getLength() > 1)
            RequestForm.Events.FilterinprogressStatusRelatedOptionsets(
                executionContext,
            );
        RequestForm.Events.SubActivityTypeOnChangeMultipleOptionset(
            executionContext,
        );
        // Check and disable  priority  field  for NGH Account management
        RequestForm.Events.CheckNGHAccountManagementPriority(executionContext);
    },
    // if  record type is CR, analytics and delegate then display error for nielsen consumer (Global)
    ShowErrorForNielsenGlobal: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var accountid = CommonForm.Events.GetFieldValue(formContext, "customerid");
        var rectype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        var reqorigin = CommonForm.Events.GetFieldValue(formContext, "caseorigincode");
        if (accountid !== null && accountid !== undefined && reqorigin !== 100000172) {
            var accname = accountid[0].name;
            if (
                rectype !== null &&
                accname !== null &&
                (rectype === 100000000 ||
                    rectype === 100000001 ||
                    rectype === 100000002 ||
                    rectype === 100000003 ||
                    rectype === 100000004) &&
                accname !== undefined &&
                accname.indexOf("Nielsen Consumer (Global)") > -1
            ) {
                var niqconserror =
                    "Please choose the specific market account for this request.";
                formContext.ui.setFormNotification(
                    niqconserror,
                    "ERROR",
                    "chinaretailer1001",
                );
            }
        }
    },
    SetFilterParentRequest: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var reqaccid = CommonForm.Events.GetFieldValue(formContext, "customerid");
        if (reqaccid !== null && reqaccid !== undefined) {
            //var accountsdata = RequestForm.Events.GetAllParentAccounts(executionContext, reqaccid);
            var accountsdata =
                RequestForm.Events.GetAllParentAccounts(executionContext);
            if (accountsdata.length > 0) {
                // construct fetchxml based on the record type value
                var fetchXml =
                    "<filter type='and'> <condition attribute='customerid' operator='in'>";
                for (var i = 0; i < accountsdata.length; i++) {
                    fetchXml +=
                        "<value uiname='' uitype='account'>" + accountsdata[i] + "</value>";
                }
                fetchXml += "</condition>";
                if (
                    formContext.data.entity.getId() !== null &&
                    formContext.data.entity.getId() !== ""
                )
                    fetchXml +=
                        "<condition attribute='incidentid' operator='ne' uiname='' uitype='incident' value='" +
                        formContext.data.entity.getId() +
                        "' />";
                fetchXml += "</filter> ";
                formContext
                    .getControl("parentcaseid")
                    .addCustomFilter(fetchXml, "incident");
            }
        } else {
            var emptyfetchXml =
                "<filter type='and'>  <condition attribute='incidentid' operator= 'null' /> </filter>";
            formContext
                .getControl("parentcaseid")
                .addCustomFilter(emptyfetchXml, "incident");
        }
    },
    GetAllParentAccounts: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var accountsdata = [];
        var accountId = CommonForm.Events.GetFieldValue(formContext, "customerid");
        if (accountId !== null) {
            var accLookupControl = formContext.getControl("customerid");
            if (accLookupControl != null) {
                accountsdata.push(accountId[0].id.replace("{", "").replace("}", ""));
                var fetchxml =
                    "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                    "<entity name='account'>" +
                    "<attribute name='name' />" +
                    "<attribute name='accountid' />" +
                    "<attribute name='niq_ultimateparentid' />" +
                    "<attribute name='parentaccountid' />" +
                    "<order attribute='name' descending='false' />" +
                    "<filter type='and'>" +
                    "<condition attribute = 'accountid' operator='eq' uitype='account' value='" +
                    accountId[0].id.replace("{", "").replace("}", "") +
                    "' />" +
                    "</filter>" +
                    "</entity>" +
                    "</fetch>";
                var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
                var result = GetCRMWebAPI.Methods.GetFetchRecords(
                    clienturl,
                    fetchxml,
                    "accounts",
                );
                if (result !== null && result.value.length === 1) {
                    var hierarchyId =
                        result.value[0]["_niq_ultimateparentid_value"] !== null ?
                            result.value[0]["_niq_ultimateparentid_value"] :
                            result.value[0]["_parentaccountid_value"];
                    if (hierarchyId !== null) {
                        var fetchXml =
                            "<fetch distinct='false' no-lock='false' mapping='logical'>" +
                            "<entity name='account' >" +
                            "<filter type='and' >" +
                            "<condition attribute='accountid' operator='eq-or-under' value='" +
                            hierarchyId +
                            "' />" +
                            "</filter>" +
                            "</entity>" +
                            "</fetch>";
                        var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
                        var accresults = GetCRMWebAPI.Methods.GetFetchRecords(
                            clienturl,
                            fetchXml,
                            "accounts",
                        );
                        if (accresults !== null && accresults.value.length > 0) {
                            for (var j = 0; j < accresults.value.length; j++) {
                                accountsdata.push(accresults.value[j].accountid);
                            }
                        }
                    }
                }
            }
        }
        return accountsdata;
    },
    GetUltimateParentAccountInfo: function (accountid) {
        "use strict";
        var fetchxml =
            "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
            "<entity name='account'>" +
            "<attribute name='name' />" +
            "<filter type='and'>" +
            "<condition attribute='accountid' operator='eq' uiname='' uitype='account' value='" +
            accountid +
            "' />" +
            "</filter>" +
            "<link-entity name='account' from='accountid' to='niq_ultimate_parent__c' link-type='inner' alias='parentacc'>" +
            "<attribute name='accountid' />" +
            "</link-entity>" +
            "</entity>" +
            "</fetch>";
        var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
        var result = GetCRMWebAPI.Methods.GetFetchRecords(
            clienturl,
            fetchxml,
            "accounts",
        );
        return result;
    },
    GetAllChildAccountInfo: function (accountsdata) {
        "use strict";
        var fetchxml =
            "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
            "<entity name='account'>" +
            "<attribute name='accountid' />" +
            "<filter type='and'>" +
            "<filter type='or'>" +
            "<condition attribute='accountid' operator='in'>";
        for (var i = 0; i < accountsdata.length; i++)
            fetchxml +=
                "<value uiname='' uitype='account'>" + accountsdata[i] + "</value>";
        fetchxml +=
            "</condition>" +
            "<condition attribute='niq_ultimate_parent__c' operator='in'>";
        for (var j = 0; j < accountsdata.length; j++)
            fetchxml +=
                "<value uiname='' uitype='account'>" + accountsdata[j] + "</value>";
        fetchxml +=
            "</condition>" + "</filter>" + "</filter>" + "</entity>" + "</fetch>";
        var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
        var result = GetCRMWebAPI.Methods.GetFetchRecords(
            clienturl,
            fetchxml,
            "accounts",
        );
        return result;
    },
    //To make multiselect non required for no solution,cancelled and out of scope in in-progress
    RespondedSubStatusOnchangeNonRequiredMultiOpt: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var acttype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_activitytypeid",
        );
        var subacttype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_activitysubtypeid",
        );
        var recordtype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        var statusval = CommonForm.Events.GetFieldValue(formContext, "statuscode");
        var multiselectsurveyfields = [
            "niq_serviceproduct",
            "niq_businesstopicsincluded",
        ];
        var respondedsubstatus = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_respondedsubstatus",
        );
        if (respondedsubstatus === null) {
            if (
                recordtype !== null &&
                (recordtype === 100000000 ||
                    recordtype === 100000001 ||
                    recordtype === 100000002)
            ) {
                if (
                    acttype !== null &&
                    acttype[0] !== null &&
                    subacttype !== null &&
                    subacttype[0] !== null
                ) {
                    CommonForm.Events.SetRequiredFieldLevels(
                        formContext,
                        multiselectsurveyfields,
                        "required",
                    );
                }
            }
        } else if (
            acttype !== null &&
            acttype[0] !== null &&
            subacttype !== null &&
            subacttype[0] !== null
        ) {
            // check if status is inprogress
            if (
                recordtype !== null &&
                (recordtype === 100000000 ||
                    recordtype === 100000001 ||
                    recordtype === 100000002) &&
                statusval !== null &&
                statusval[0] !== null &&
                (statusval === 1 || statusval === 5 || statusval === 100000003) &&
                respondedsubstatus !== null &&
                respondedsubstatus[0] !== null &&
                respondedsubstatus !== 100000005 &&
                respondedsubstatus !== 100000006 &&
                respondedsubstatus !== 100000021 &&
                respondedsubstatus !== 100000022 &&
                respondedsubstatus !== 100000023 &&
                acttype[0].name === "Analysis" &&
                subacttype[0].name === "Analysis"
            ) {
                // make it mandatory for responded sub-status is solution provided only
                if (
                    statusval !== null &&
                    statusval[0] !== null &&
                    (statusval === 1 || statusval === 5 || statusval === 100000003) &&
                    subacttype !== null &&
                    subacttype[0] !== null
                ) {
                    // make it mandatory for activity type = Analysis
                    CommonForm.Events.SetRequiredFieldLevels(
                        formContext,
                        multiselectsurveyfields,
                        "required",
                    );
                }
            } else {
                CommonForm.Events.SetRequiredFieldLevels(
                    formContext,
                    multiselectsurveyfields,
                    "none",
                );
            }
        }
    },
    SubActivityTypeOnChangeMultipleOptionset: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        //call the function only for Main form
        if (formContext.ui.tabs.getLength() !== 1) {
            var respondedsubstatus = CommonForm.Events.GetFieldValue(
                formContext,
                "niq_respondedsubstatus",
            );
            var multiselectsurveyfields = [
                "niq_serviceproduct",
                "niq_businesstopicsincluded",
            ];
            var stageName = formContext.data.process.getActiveStage().getName();
            if (stageName === "In Progress" || stageName === "Responded") {
                var acttype = CommonForm.Events.GetFieldValue(
                    formContext,
                    "niq_activitytypeid",
                );
                var subacttype = CommonForm.Events.GetFieldValue(
                    formContext,
                    "niq_activitysubtypeid",
                );
                var recordtype = CommonForm.Events.GetFieldValue(
                    formContext,
                    "niq_recordtype",
                );
                var statusval = CommonForm.Events.GetFieldValue(
                    formContext,
                    "statuscode",
                );
                var substatusvalue = CommonForm.Events.GetFieldValue(
                    formContext,
                    "niq_substatus",
                );
                // check if the activity type is  Analytics or CR or Delegate
                if (
                    recordtype !== null &&
                    (recordtype === 100000000 ||
                        recordtype === 100000001 ||
                        recordtype === 100000002)
                ) {
                    // if activity type is not equal to Analysis or datapull or  Report
                    if (
                        acttype !== null &&
                        subacttype !== null &&
                        subacttype[0] !== null &&
                        acttype[0] !== null &&
                        acttype[0].name !== "Analysis" &&
                        subacttype[0].name !== "Analysis"
                    ) {
                        // check if status is inprogress
                        // make it mandatory for activity type = Analysis
                        CommonForm.Events.SetRequiredFieldLevels(
                            formContext,
                            multiselectsurveyfields,
                            "none",
                        );
                    }
                    // For analysis / data pull /report make it visible
                    else {
                        // check if status is inprogress
                        if (respondedsubstatus === null) {
                            if (
                                recordtype !== null &&
                                (recordtype === 100000000 ||
                                    recordtype === 100000001 ||
                                    recordtype === 100000002)
                            ) {
                                if (
                                    acttype !== null &&
                                    acttype[0] !== null &&
                                    subacttype !== null &&
                                    subacttype[0] !== null
                                ) {
                                    CommonForm.Events.SetRequiredFieldLevels(
                                        formContext,
                                        multiselectsurveyfields,
                                        "required",
                                    );
                                }
                            }
                        } else if (
                            acttype !== null &&
                            statusval !== null &&
                            statusval[0] !== null &&
                            subacttype !== null &&
                            subacttype[0] !== null &&
                            respondedsubstatus !== null &&
                            respondedsubstatus[0] !== null &&
                            respondedsubstatus !== 100000005 &&
                            respondedsubstatus !== 100000006 &&
                            respondedsubstatus !== 100000021 &&
                            respondedsubstatus !== 100000022 &&
                            respondedsubstatus !== 100000023
                        ) {
                            // make it mandatory for activity type = Analysis
                            CommonForm.Events.SetRequiredFieldLevels(
                                formContext,
                                multiselectsurveyfields,
                                "required",
                            );
                        } else {
                            CommonForm.Events.SetRequiredFieldLevels(
                                formContext,
                                multiselectsurveyfields,
                                "none",
                            );
                        }
                    }
                } else {
                    CommonForm.Events.SetRequiredFieldLevels(
                        formContext,
                        multiselectsurveyfields,
                        "none",
                    );
                }
            } else if (stageName === "Assigned") {
                CommonForm.Events.SetRequiredFieldLevels(
                    formContext,
                    multiselectsurveyfields,
                    "none",
                );
            }
            //else {
            //  CommonForm.Events.SetRequiredFieldLevels(formContext, multiselectsurveyfields, "none");
            // clear subactivity type field
            // CommonForm.Events.SetFieldValue(formContext, "niq_activitysubtypeid", null);
            // }
        }
    },
    ActivityTypeOnChangeMultipleOptionset: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var acttype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_activitytypeid",
        );
        var subacttype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_activitysubtypeid",
        );
        var recordtype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        var statusval = CommonForm.Events.GetFieldValue(formContext, "statuscode");
        var multiselectsurveyfields = [
            "niq_serviceproduct",
            "niq_businesstopicsincluded",
        ];
        if (acttype !== null && acttype[0] !== null) {
            // check if the activity type is  Analytics or CR or Delegate
            if (
                recordtype !== null &&
                (recordtype === 100000000 ||
                    recordtype === 100000001 ||
                    recordtype === 100000002)
            ) {
                // if activity type is not equal to Analysis or datapull or  Report
                if (
                    acttype !== null &&
                    subacttype !== null &&
                    subacttype[0] !== null &&
                    acttype[0] !== null &&
                    acttype[0].name !== "Analysis" &&
                    subacttype[0].name !== "Analysis"
                ) {
                    CommonForm.Events.SetRequiredFieldLevels(
                        formContext,
                        multiselectsurveyfields,
                        "none",
                    );
                }
                // For analysis / data pull /report make it visible
                else {
                    // check if status is inprogress
                    if (statusval === 1) {
                        // make it mandatory for activity type = Analysis
                        CommonForm.Events.SetRequiredFieldLevels(
                            formContext,
                            multiselectsurveyfields,
                            "required",
                        );
                    }
                }
            } else {
                CommonForm.Events.SetRequiredFieldLevels(
                    formContext,
                    multiselectsurveyfields,
                    "none",
                );
            }
        } else {
            CommonForm.Events.SetRequiredFieldLevels(
                formContext,
                multiselectsurveyfields,
                "none",
            );
            // clear subactivity type field
            CommonForm.Events.SetFieldValue(
                formContext,
                "niq_activitysubtypeid",
                null,
            );
        }
    },
    filterActivitySubtypeOnActivityTypeChange: function (executionContext) {
        "use strict";
        debugger;
        var formContext = executionContext.getFormContext();
        var subtypeControl = formContext.getControl("niq_activitysubtypeid");

        if (!subtypeControl) {
            console.error("Activity Subtype lookup not found.");
            return;
        }

        var activityType = formContext.getAttribute("niq_activitytypeid").getValue();
        var recordType = formContext.getAttribute("niq_recordtype").getValue();
        var restrictedOptions = ["Consultation", "Renewal", "BAU Request", "Quality Escape"];

        // Ensure "Activity Type" is "Report" before filtering
        if (!activityType || !activityType[0] || activityType[0].name !== "Report") {
            console.log("Activity Type is not 'Report'. No filtering applied.");
            return;
        }

        console.log("Activity Type is 'Report'. Checking Record Type...");

        function addFilterHandler() {
            var filterXML = `
				<filter type="and">
					<condition attribute="niq_name" operator="ne" value="Consultation" />
					<condition attribute="niq_name" operator="ne" value="Renewal" />
					<condition attribute="niq_name" operator="ne" value="BAU Request" />
					<condition attribute="niq_name" operator="ne" value="Quality Escape" />
				</filter>
			`;

            // Apply the filter on the correct entity
            subtypeControl.addCustomFilter(filterXML, "niq_requestactivitytypes");
            console.log("Custom filter applied to 'niq_activitysubtypeid' (entity: niq_requestactivitytypes).");
        }

        // Remove previous filters (important to avoid duplicates)
        try {
            subtypeControl.removePreSearch(addFilterHandler);
        } catch (error) {
            console.warn("No existing filter handler found, continuing...");
        }

        // If Record Type  Client Response (100000001), apply filtering
        if (recordType !== 100000001) {
            console.log("Record Type is NOT 'Client Response'. Removing options...");

            // Apply filter immediately (removes options in lookup)
            addFilterHandler();

            // Apply filter again whenever lookup opens
            subtypeControl.addPreSearch(addFilterHandler);

            //Remove Pre-Selected Value if it Restricted**
            var selectedSubtype = formContext.getAttribute("niq_activitysubtypeid").getValue();
            if (selectedSubtype && selectedSubtype.length > 0) {
                var selectedSubtypeName = selectedSubtype[0].name;
                if (restrictedOptions.includes(selectedSubtypeName)) {
                    console.log(`Removing pre-selected value: ${selectedSubtypeName}`);
                    formContext.getAttribute("niq_activitysubtypeid").setValue(null);
                }
            }
            formContext.getAttribute("niq_activitysubtypeid").fireOnChange();
        } else {
            console.log("Record Type is 'Client Response'. No filtering needed.");
        }
    },
    // prestage on change event
    preStageChange: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        //setting the bpf to collapsed - DYNCRM-20707
        formContext.ui.process.setDisplayState("collapsed");
        //Get case status
        var casestatus = CommonForm.Events.GetFieldValue(formContext, "statuscode");
        // check if it disabled form or  case status != responded
        if (isdisabledform || casestatus === 5) {
            Xrm.Utility.alertDialog("Stage movement is not allowed for this record");
            executionContext.getEventArgs().preventDefault();
        }
    },
    //Method to check Account is not chinese retailer account if logged in user does not have China Retailer role
    CheckAccountTypeSelected: function (executionContext) {
        "use strict";
        // get the account value and its related properties to find the relavancy
        formContext = executionContext.getFormContext();
        // get the record type
        var rectype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        var mapaccount = true;
        var accountid = CommonForm.Events.GetFieldValue(formContext, "customerid");
        if (accountid !== null) {
            //clear formNotification - chinaretailer1001
            formContext.ui.clearFormNotification("chinaretailer1001");
            var fetchxml =
                "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'> <entity name='account'>" +
                "<attribute name='name' /> <attribute name='niq_industry' /> <attribute name='niq_accountmarketid' />" +
                "<filter type='and'> <condition attribute='accountid' operator='eq' uiname='' uitype='account' value='" +
                accountid[0].id +
                "' /> </filter> </entity> </fetch>";
            // get the client url
            var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
            var result = GetCRMWebAPI.Methods.GetFetchRecords(
                clienturl,
                fetchxml,
                "accounts",
            );
            // get account's operated market and type - to check if it is china Retailer account
            if (result !== null && result.value !== null && result.value.length > 0) {
                //get the first row /only row retrieved
                var rec = result.value[0];
                // check if the name != nielson global consumer
                var accname = rec.name;
                var countryname =
                    rec[
                    "_niq_accountmarketid_value@OData.Community.Display.V1.FormattedValue"
                    ];
                var industry = rec.niq_industry; // get the industry value for Retail
                // check the account related data validations
                mapaccount = RequestForm.Events.CheckAccountDataMapping(
                    rectype,
                    accname,
                    countryname,
                    industry,
                );
                // Check if mapaccount is false, then remove this account & contact
                if (!mapaccount) {
                    CommonForm.Events.SetFieldValue(
                        formContext,
                        "primarycontactid",
                        null,
                    );
                    CommonForm.Events.SetFieldValue(formContext, "customerid", null);
                    CommonForm.Events.SetFieldValue(formContext, "parentcase", null);
                }
            }
        }
    },
    //Method to get parent account name of the contact
    GetParentAccountForContact: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var mapaccount = true;
        var rectype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        //clear formNotification - chinaretailer1001
        formContext.ui.clearFormNotification("chinaretailer1001");
        var contactid = CommonForm.Events.GetFieldValue(
            formContext,
            "primarycontactid",
        );
        if (contactid !== null) {
            // get parent customer long with account type
            var fetchXml =
                "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'> <entity name='contact'> <attribute name='department' /><attribute name='parentcustomerid' />";
            fetchXml +=
                "<filter type='and'>  <condition attribute='contactid' operator='eq' uiname='' uitype='contact' value='" +
                contactid[0].id +
                "' />";
            fetchXml +=
                "</filter> <link-entity name='account' from='accountid' to='parentcustomerid' visible='false' link-type='outer' alias='acc'> <attribute name='niq_industry' />";
            fetchXml +=
                "<attribute name='niq_accounttype' /><attribute name='name' /> <attribute name='niq_accountmarketid' /> </link-entity>";
            fetchXml += "</entity> </fetch>";
            var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
            var result = GetCRMWebAPI.Methods.GetFetchRecords(
                clienturl,
                fetchXml,
                "contacts",
            );
            //check if data is retrieved & Companyname has data
            if (
                result !== null &&
                result.value.length > 0 &&
                result.value[0] !== null &&
                result.value[0]._parentcustomerid_value !== null
            ) {
                //get the first row /only row retrieved
                var rec = result.value[0];
                // check if account name is not nielsen consumer global
                var accname = rec["acc.name"];
                var department = rec.department;
                var countryname =
                    rec[
                    "acc.niq_accountmarketid@OData.Community.Display.V1.FormattedValue"
                    ];
                var industry = rec["acc.niq_industry"]; // get the industry value for Retail
                // check the account related data validations
                mapaccount = RequestForm.Events.CheckAccountDataMapping(
                    rectype,
                    accname,
                    countryname,
                    industry,
                );
                if (mapaccount) {
                    // perform operations on record retrieval
                    var lkupaccount = new Array();
                    lkupaccount[0] = new Object();
                    lkupaccount[0].id = rec._parentcustomerid_value;
                    lkupaccount[0].name =
                        rec[
                        "_parentcustomerid_value@OData.Community.Display.V1.FormattedValue"
                        ];
                    lkupaccount[0].entityType = "account"; // account or contact
                    // set value to customerid lookup
                    CommonForm.Events.SetFieldValue(
                        formContext,
                        "customerid",
                        lkupaccount,
                    );
                    CommonForm.Events.SetFieldValue(formContext, "parentcase", null);
                }
                if (department !== undefined && department !== null) {
                    var contactFieldControlll =
                        formContext.getControl("primarycontactid");
                    //niq_contactsphone
                    var contactFieldControll = formContext.getControl("customerid");
                    if (department.indexOf("Test Contact") > -1) {
                        if (!CommonForm.Events.CheckIfLoggedInUserRoles(adminRole)) {
                            formContext.ui.setFormNotification(
                                "You cannot use a test user and contact.",
                                "ERROR",
                                "contactFieldControlError",
                            );
                            contactFieldControlll.setNotification(
                                "You cannot use a test user and contact.",
                                "contactFieldError",
                            );
                            // contactFieldControll.setNotification("You cannot use a test user and contact.", "contactFieldError");
                        }
                    } else {
                        //  var contactFieldControl = formContext.getControl("primarycontactid");
                        //for null value in the contact, clear account lookup also
                        //CommonForm.Events.SetFieldValue(formContext, "customerid", null);
                        var contactFieldControl =
                            formContext.getControl("primarycontactid");
                        contactFieldControl.clearNotification("contactFieldError");
                        formContext.ui.clearFormNotification("contactFieldControlError");
                    }
                }
            } else {
                CommonForm.Events.SetFieldValue(formContext, "primarycontactid", null);
                CommonForm.Events.SetFieldValue(formContext, "parentcase", null);
                formContext.ui.clearFormNotification("contactFieldControlError");
            }
        } else {
            //for null value in the contact, clear account lookup also
            CommonForm.Events.SetFieldValue(formContext, "customerid", null);
            formContext.ui.clearFormNotification("contactFieldControlError");
        }
    },
    CheckAccountDataMapping: function (rectype, accname, countryname, industry) {
        "use strict";
        var mapaccount = true;
        // check if record type is CR or analytics and newlsen consumer global is selected
        if (
            rectype !== null &&
            (rectype === 100000000 ||
                rectype === 100000001 ||
                rectype === 100000002 ||
                rectype === 100000003 ||
                rectype === 100000004) &&
            accname.indexOf("Nielsen Consumer (Global)") > -1
        ) {
            var niqconserror =
                "Please choose the specific market account for this request.";
            formContext.ui.setFormNotification(
                niqconserror,
                "ERROR",
                "chinaretailer1001",
            );
            mapaccount = false;
        }
        if (
            countryname !== null &&
            countryname !== undefined &&
            industry !== null &&
            industry !== undefined
        ) {
            //Check if it is china retailer
            if (countryname === "China" && industry === 100) {
                // Check if logged in user has china retailer role
                if (!CommonForm.Events.CheckIfLoggedInUserRole("China Retailer")) {
                    // if not, then display a message and clear account & contact lookup
                    formContext.ui.setFormNotification(
                        "Please select Non China Retailer account",
                        "ERROR",
                        "chinaretailer1001",
                    );
                    mapaccount = false;
                }
            }
        }
        return mapaccount;
    },
    DisablePlannedDatehours: function (executionContext) {
        ("use strict");
        formContext = executionContext.getFormContext();
        //Get case status
        var casestatus = CommonForm.Events.GetFieldValue(formContext, "statuscode");
        var rectype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        var plannedstartdate = CommonForm.Events.GetFieldValue(formContext, "niq_plannedstartdate");
        // check if it disabled form or  case status != responded
        if (
            casestatus == 5 &&
            (rectype === 100000000 || rectype === 100000001 || rectype === 100000002)
        ) {
            if (formContext.getControl("niq_plannedstartdate") !== null)
                formContext.getControl("niq_plannedstartdate").setDisabled(true);
            if (formContext.getControl("niq_plannedenddate") !== null)
                formContext.getControl("niq_plannedenddate").setDisabled(true);
            if (formContext.getControl("niq_totalplannedefforts") !== null)
                formContext.getControl("niq_totalplannedefforts").setDisabled(true);
        } else if (
            CommonForm.Events.CheckIfLoggedInUserRoles(
                "System Administrator,NIQ Client Response Manager,NIQ Analytics Manager",
            )
        ) {
            if (
                rectype !== null &&
                (rectype === 100000000 || rectype === 100000001)
            ) {
                if (formContext.getControl("niq_plannedstartdate") !== null)
                    formContext.getControl("niq_plannedstartdate").setDisabled(false);
                if (formContext.getControl("niq_plannedenddate") !== null)
                    formContext.getControl("niq_plannedenddate").setDisabled(false);
                if (formContext.getControl("niq_totalplannedefforts") !== null)
                    formContext.getControl("niq_totalplannedefforts").setDisabled(false);
            }
        } else if (
            CommonForm.Events.CheckIfLoggedInUserRoles(
                "System Administrator,NIQ Delegate Manager",
            )
        ) {
            if (rectype !== null && rectype === 100000002) {
                if (formContext.getControl("niq_plannedstartdate") !== null)
                    formContext.getControl("niq_plannedstartdate").setDisabled(false);
                if (formContext.getControl("niq_plannedenddate") !== null)
                    formContext.getControl("niq_plannedenddate").setDisabled(false);
                if (formContext.getControl("niq_totalplannedefforts") !== null)
                    formContext.getControl("niq_totalplannedefforts").setDisabled(false);
            }
        } else if (
            CommonForm.Events.CheckIfLoggedInUserRoles(
                "System Administrator,NIQ Analytics Agent,NIQ Client Response Agent,NIQ Global Helpline Agent,NIQ Global Helpline Manager",
            )
        ) {
            if (
                rectype !== null &&
                (rectype === 100000000 || rectype === 100000001)
            ) {
                if (formContext.getControl("niq_plannedstartdate") !== null) {
                    var plannedstartdate = CommonForm.Events.GetFieldValue(
                        formContext,
                        "niq_plannedstartdate",
                    );
                    if (plannedstartdate === null) {
                        formContext.getControl("niq_plannedstartdate").setDisabled(false);
                    } else {
                        formContext.getControl("niq_plannedstartdate").setDisabled(true);
                    }
                }
                if (formContext.getControl("niq_plannedenddate") !== null) {
                    var plannedenddate = CommonForm.Events.GetFieldValue(
                        formContext,
                        "niq_plannedenddate",
                    );
                    if (plannedenddate === null) {
                        formContext.getControl("niq_plannedenddate").setDisabled(false);
                    } else {
                        formContext.getControl("niq_plannedenddate").setDisabled(true);
                    }
                }
                if (formContext.getControl("niq_totalplannedefforts") !== null) {
                    var totaleffort = CommonForm.Events.GetFieldValue(
                        formContext,
                        "niq_totalplannedefforts",
                    );
                    if (totaleffort === null) {
                        formContext
                            .getControl("niq_totalplannedefforts")
                            .setDisabled(false);
                    } else {
                        formContext.getControl("niq_totalplannedefforts").setDisabled(true);
                    }
                }
            }
        } else if (
            CommonForm.Events.CheckIfLoggedInUserRoles(
                "System Administrator,NIQ Delegate Agent,NIQ Delegate Submitter",
            )
        ) {
            if (rectype !== null && rectype === 100000002) {
                if (formContext.getControl("niq_plannedstartdate") !== null) {
                    var plannedstartdate = CommonForm.Events.GetFieldValue(
                        formContext,
                        "niq_plannedstartdate",
                    );
                    if (plannedstartdate === null) {
                        formContext.getControl("niq_plannedstartdate").setDisabled(false);
                    } else {
                        formContext.getControl("niq_plannedstartdate").setDisabled(true);
                    }
                }
                if (formContext.getControl("niq_plannedenddate") !== null) {
                    var plannedenddate = CommonForm.Events.GetFieldValue(
                        formContext,
                        "niq_plannedenddate",
                    );
                    if (plannedenddate === null) {
                        formContext.getControl("niq_plannedenddate").setDisabled(false);
                    } else {
                        formContext.getControl("niq_plannedenddate").setDisabled(true);
                    }
                }

                if (formContext.getControl("niq_totalplannedefforts") !== null) {
                    var totaleffort = CommonForm.Events.GetFieldValue(
                        formContext,
                        "niq_totalplannedefforts",
                    );
                    if (totaleffort === null) {
                        formContext
                            .getControl("niq_totalplannedefforts")
                            .setDisabled(false);
                    } else {
                        formContext.getControl("niq_totalplannedefforts").setDisabled(true);
                    }
                }
            }
        } else {
            if (plannedstartdate !== null)
                formContext.getControl("niq_plannedstartdate").setDisabled(true);
            if (formContext.getControl("niq_plannedenddate") != null)
                formContext.getControl("niq_plannedenddate").setDisabled(true);
            if (formContext.getControl("niq_totalplannedefforts") != null)
                formContext.getControl("niq_totalplannedefforts").setDisabled(true);
        }
    },
    //sprint 8: US-243
    //Check for test dept for user
    CheckUserDeptContainsTest: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var Ownerid = CommonForm.Events.GetFieldValue(formContext, "ownerid");
        if (Ownerid !== null) {
            // get responsible department  long with ownerid
            var fetchXml =
                "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'> <entity name='systemuser'> <attribute name='niq_responsibledepartmentoptionset' /><attribute name='niq_department' /> <attribute name='internalemailaddress' />";
            fetchXml +=
                "<filter type='and'> <condition attribute='systemuserid' operator='eq' uiname='' uitype='systemuser' value='" +
                Ownerid[0].id +
                "' />";
            fetchXml += "</filter></entity> </fetch>";
            var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
            var result = GetCRMWebAPI.Methods.GetFetchRecords(
                clienturl,
                fetchXml,
                "systemusers",
            );
            //check if data is retrieved & Companyname has data
            if (
                result !== null &&
                result.value.length > 0 &&
                result.value[0] !== null
            ) {
                //get the first row /only row retrieved
                var rec = result.value[0];
                // check if account name is not nielsen consumer global
                var Webemail = rec.internalemailaddress;
                var Deptname = rec.niq_responsibledepartmentoptionset;
                userDept = rec.niq_department;
            }
        }
        var contactFieldControll = formContext.getControl("ownerid");
        if (userDept !== undefined && userDept !== null) {
            var contactFieldControlll = formContext.getControl("primarycontactid");
            //niq_contactsphone
            if (userDept.indexOf("Test User") > -1) {
                if (!CommonForm.Events.CheckIfLoggedInUserRoles(adminRole)) {
                    formContext.ui.setFormNotification(
                        "You cannot use a test user and contact.",
                        "ERROR",
                        "contactFieldControlError",
                    );
                    // contactFieldControlll.setNotification("You cannot use a test user and contact.", "contactFieldError");
                    //	contactFieldControll.setNotification("You cannot use a test user and contact.", "contactFieldError");
                    //	executionContext.getEventArgs().preventDefault();
                }
            } else {
                //  var contactFieldControl = formContext.getControl("primarycontactid");
                contactFieldControll.clearNotification("contactFieldError");
                formContext.ui.clearFormNotification("contactFieldControlError");
            }
        } else {
            //  var contactFieldControl = formContext.getControl("primarycontactid");
            contactFieldControll.clearNotification("contactFieldError");
            formContext.ui.clearFormNotification("contactFieldControlError");
        }
    },
    CreatePostOnPlannedDateChange: function (executionContext) {
        ("use strict");
        var formContext = executionContext.getFormContext();
        var Xrm = parent.Xrm;
        var timeZoneOffsetMinutes =
            Xrm.Utility.getGlobalContext().userSettings.getTimeZoneOffsetMinutes;
        if (
            CommonForm.Events.CheckIfLoggedInUserRoles(delegateAgentAndManagerRole) ||
            CommonForm.Events.CheckIfLoggedInUserRoles(adminRole)
        ) {
            var rectype = CommonForm.Events.GetFieldValue(
                formContext,
                "niq_recordtype",
            );
            var plannedstartdate = formContext.data.entity.attributes.get(
                "niq_plannedstartdate",
            );
            var plannedenddate =
                formContext.data.entity.attributes.get("niq_plannedenddate");
            var plannedstartdateData = CommonForm.Events.GetFieldValue(
                formContext,
                "niq_plannedstartdate",
            );
            var plannedenddateData = CommonForm.Events.GetFieldValue(
                formContext,
                "niq_plannedenddate",
            );
            if (rectype != null && rectype != undefined && rectype === 100000002) {
                if (plannedstartdateData !== null && plannedenddateData !== null) {
                    if (
                        plannedstartdate.getIsDirty() ||
                        plannedenddate.getIsDirty() ||
                        createpost
                    ) {
                        //plannedstartdate = CommonForm.Events.GetFieldValue(formContext, "niq_plannedstartdate");
                        //plannedenddate = CommonForm.Events.GetFieldValue(formContext, "niq_plannedenddate");
                        var previousplannedEndDate = CommonForm.Events.GetFieldValue(
                            formContext,
                            "niq_previousplannedenddate",
                        );
                        var previousplannedStartDate = CommonForm.Events.GetFieldValue(
                            formContext,
                            "niq_previousplannedstartdate",
                        );
                        var postText = "";
                        if (createpost) {
                            postText =
                                "Planned Dates has been changed.\n" +
                                "Planned Start Date : " +
                                "null" +
                                " to " +
                                plannedstartdateData.toLocaleDateString() +
                                "\nPlanned End Date : " +
                                "null to " +
                                plannedenddateData.toLocaleDateString();
                        } else if (
                            (previousplannedEndDate === null ||
                                previousplannedStartDate === undefined) &&
                            (previousplannedStartDate === null ||
                                previousplannedStartDate === undefined)
                        ) {
                            postText =
                                "Planned Dates has been changed.\n" +
                                "Planned Start Date : " +
                                "null" +
                                " to " +
                                plannedstartdateData.toLocaleDateString() +
                                "\nPlanned End Date : " +
                                "null to " +
                                plannedenddateData.toLocaleDateString();
                        } else if (
                            previousplannedStartDate === null ||
                            previousplannedStartDate === undefined
                        ) {
                            postText =
                                "Planned Dates has been changed.\n" +
                                "Planned Start Date : " +
                                "null" +
                                " to " +
                                plannedstartdateData.toLocaleDateString() +
                                "\nPlanned End Date : " +
                                previousplannedEndDate.toLocaleDateString() +
                                " to " +
                                plannedenddateData.toLocaleDateString();
                        } else if (
                            previousplannedEndDate === null ||
                            previousplannedEndDate === undefined
                        ) {
                            postText =
                                "Planned Dates has been changed.\n" +
                                "Planned Start Date : " +
                                previousplannedStartDate.toLocaleDateString() +
                                " to " +
                                plannedstartdateData.toLocaleDateString() +
                                "\nPlanned End Date : " +
                                "null" +
                                " to " +
                                plannedenddateData.toLocaleDateString();
                        } else {
                            postText =
                                "Planned Dates has been changed.\n" +
                                "Planned Start Date : " +
                                previousplannedStartDate.toLocaleDateString() +
                                " to " +
                                plannedstartdateData.toLocaleDateString() +
                                "\nPlanned End Date : " +
                                previousplannedEndDate.toLocaleDateString() +
                                " to " +
                                plannedenddateData.toLocaleDateString();
                        }
                        var entity = {};
                        entity.source = 1;
                        entity.text = postText;
                        entity["regardingobjectid_incident@odata.bind"] =
                            "/incidents(" +
                            formContext.data.entity
                                .getId()
                                .replace("{", "")
                                .replace("}", "") +
                            ")";
                        Xrm.WebApi.online.createRecord("post", entity).then(
                            function success(result) {
                                var newEntityId = result.id;
                                createpost = false;
                            },

                            function (error) {
                                //Xrm.Utility.alertDialog(error.message);
                                createpost = true;
                            },
                        );
                    }
                    if (plannedstartdateData != null && plannedenddateData != null) {
                        CommonForm.Events.SetFieldValue(
                            formContext,
                            "niq_previousplannedstartdate",
                            plannedstartdateData,
                        );
                        CommonForm.Events.SetFieldValue(
                            formContext,
                            "niq_previousplannedenddate",
                            plannedenddateData,
                        );
                    }
                }
            }
        }
    },
    ConvertDateFromOffset: function (date, offset) {
        // offset: should be in minutes
        // date: should be Date Object
        // create Date object for current location
        var d = new Date(date);
        // convert to msec
        // add local time zone offset
        // get UTC time in msec
        var utc = d.getTime() + d.getTimezoneOffset() * 60000;
        // create new Date object for specific offset
        // using supplied offset
        return new Date(utc + 60000 * -offset);
    },
    HideOrShowRequestStatusOptionSetValue: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        formContext.getControl("statuscode").removeOption(100000004);
        formContext.getControl("statuscode").removeOption(100000005);
        formContext.getControl("statuscode").removeOption(100000006);
        formContext.getControl("statuscode").removeOption(100000007);
        formContext.getControl("statuscode").removeOption(100000008);
    },
    PreventSaveReadonlyForms: function (executionContext) {
        ("use strict");
        this.DisablePlannedDatehours(executionContext);
        formContext.ui.clearFormNotification("preventsave001");
        if (isdisabledform) {
            executionContext.getEventArgs().preventDefault();
            formContext.ui.setFormNotification(
                "This form cannot be saved",
                "ERROR",
                "preventsave001",
            );
            return;
        }
        formContext.ui.clearFormNotification("multiclientacc001");
    },
    ClearNotificationOnNielsenAccount: function (execution) {
        "use strict";
        formContext.ui.clearFormNotification("multiclientacc001");
    },
    // Sprint 12 - 143 US
    RestrictActivityTracker: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        if (formContext.ui.tabs.getLength() !== 1) {
            var summarySection = formContext.ui.tabs
                .get("tab_Summary")
                .sections.get("tab_Summary_section_activitytracking");
            if (summarySection !== null) {
                var commonissues = CommonForm.Events.GetFieldValue(
                    formContext,
                    "niq_faqcommonissues",
                );
                var status = CommonForm.Events.GetFieldValue(formContext, "statecode");
                if (
                    ((CommonForm.Events.CheckIfLoggedInUserRoles(
                        "Activity Tracker Add-on Role",
                    ) &&
                        CommonForm.Events.CheckIfLoggedInUserRoles(activitytrackerRoles)) ||
                        CommonForm.Events.CheckIfLoggedInUserRoles(adminRole)) &&
                    status === 0
                ) {
                    summarySection.setVisible(true);
                    formContext.getControl("niq_faqcommonissues").setVisible(true);
                } else {
                    summarySection.setVisible(false);
                    formContext.getControl("niq_faqcommonissues").setVisible(false);
                }
            }
        }
    },
    PopulateContact: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var recordType = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        if (
            recordType === 100000002 &&
            CommonForm.Events.CheckIfLoggedInUserRoles(delegateSubmitterRole)
        ) {
            var userId = formContext.context
                .getUserId()
                .replace("{", "")
                .replace("}", "");
            // Get logged in User's details
            Xrm.WebApi.retrieveRecord(
                "systemuser",
                userId,
                "?$select=fullname,domainname,firstname,lastname,address2_country",
            ).then(
                function success(result) {
                    Xrm.WebApi.online
                        .retrieveMultipleRecords(
                            "contact",
                            "?$select=contactid,firstname,fullname,lastname&$filter=fullname eq '" +
                            result.fullname +
                            "' and  emailaddress1 eq '" +
                            result.domainname +
                            "'",
                        )
                        .then(
                            function success(results) {
                                if (results.entities.length > 0) {
                                    var lkupContact = [];
                                    lkupContact[0] = {};
                                    lkupContact[0].id = results.entities[0]["contactid"];
                                    lkupContact[0].entityType = "contact";
                                    lkupContact[0].name = results.entities[0]["fullname"];
                                    formContext.data.entity.attributes
                                        .get("primarycontactid")
                                        .setValue(lkupContact);
                                } else {
                                    var globalContext = Xrm.Utility.getGlobalContext();
                                    var serverURL = globalContext.getClientUrl();
                                    var actionName = "niq_CustomActionToCreateContact";
                                    var InputParamValue = globalContext.userSettings.userId;
                                    var userid;
                                    var fetchXml =
                                        "<?xml version='1.0'?><fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
                                    fetchXml +=
                                        "<entity name='systemuser'><attribute name='fullname'/><attribute name='businessunitid'/><attribute name='title'/><attribute name='systemuserid'/>";
                                    fetchXml +=
                                        "<order descending='false' attribute='fullname'/><filter type='and'><condition attribute='internalemailaddress' value='d365automation@nha.nielseniq.com' operator='eq'/>";
                                    fetchXml +=
                                        "<condition attribute='domainname' value='d365automation@nha.nielseniq.com' operator='eq'/></filter></entity></fetch>";
                                    var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
                                    var results = GetCRMWebAPI.Methods.GetFetchRecords(
                                        clienturl,
                                        fetchXml,
                                        "systemusers",
                                    );
                                    //check if data is retrieved & Companyname has data
                                    if (
                                        results !== null &&
                                        results.value.length > 0 &&
                                        results.value[0] !== null
                                    ) {
                                        userid = results.value[0].systemuserid;
                                    }
                                    var data = {
                                        lastname: result.lastname,
                                        firstname: result.firstname,
                                        email: result.domainname,
                                        userid: userid,
                                        //"MyInputParam": InputParamValue,
                                    };
                                    //Create the HttpRequestObject to send WEB API Request
                                    var req = new XMLHttpRequest();
                                    req.open(
                                        "POST",
                                        serverURL + "/api/data/v9.2/" + actionName,
                                        true,
                                    );
                                    req.setRequestHeader("Accept", "application/json");
                                    req.setRequestHeader(
                                        "Content-Type",
                                        "application/json; charset=utf-8",
                                    );
                                    req.setRequestHeader("OData-MaxVersion", "4.0");
                                    req.setRequestHeader("OData-Version", "4.0");
                                    req.onreadystatechange = function () {
                                        if (this.readyState == 4 /* complete */) {
                                            req.onreadystatechange = null;
                                            if (this.status == 200 || this.status == 204) {
                                                //alert("Action Called Successfully..." + result.output);
                                                var resu = JSON.parse(this.response);
                                                //alert(resu.output);
                                                var lkupContact = [];
                                                lkupContact[0] = {};
                                                lkupContact[0].id = resu.output;
                                                lkupContact[0].entityType = "contact";
                                                lkupContact[0].name =
                                                    globalContext.userSettings.userName;
                                                formContext.data.entity.attributes
                                                    .get("primarycontactid")
                                                    .setValue(lkupContact);
                                            } else {
                                                var error = JSON.parse(this.response).error;
                                                alert("Error in Action: " + error.message);
                                            }
                                        }
                                    };
                                    req.send(window.JSON.stringify(data));

                                }

                            },

                            function (error) {
                                console.log(error.message);
                                // handle error conditions
                            },
                        );
                },

                function (error) {
                    console.log(error.message);
                    // handle error conditions
                },
            );
        }
    },
    RemovePriorityOptionSetValue: function (executionContext) {
        "use strict";
        formContext = executionContext.getFormContext();
        var rectype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        var pricode = CommonForm.Events.GetFieldValue(formContext, "prioritycode");
        if (rectype === 100000012) {
            formContext.getControl("prioritycode").removeOption(100000005);
            formContext.getControl("prioritycode").removeOption(100000006);
            formContext.getControl("prioritycode").removeOption(100000007);
            formContext.getControl("prioritycode").removeOption(100000008);
            formContext.getControl("prioritycode").removeOption(100000009);
            formContext.getControl("prioritycode").removeOption(100000010);
            formContext.getControl("prioritycode").removeOption(100000011);
            formContext.getControl("prioritycode").removeOption(100000012);
            formContext.getControl("prioritycode").removeOption(100000013);
            formContext.getControl("prioritycode").removeOption(1);
            formContext.getControl("prioritycode").removeOption(2);
            formContext.getControl("prioritycode").removeOption(3);
        }
        else if (
            rectype === 100000001 ||
            rectype === 100000003
        ) {
            var created_date = CommonForm.Events.GetFieldValue(formContext, "createdon");
            var date1 = new Date("January 10, 2026");
            //For New requests, remove P5 - none priority
            if (created_date === null || (created_date.getTime() >= date1.getTime())) {
                formContext.getControl("prioritycode").removeOption(100000013);
            }

            //setting priority field value to P4 - Low for new & future requests and P5 - None for existing requests
            if ((pricode === null || pricode === 100000007 || pricode === 100000013)) {
                if (created_date === null || (created_date.getTime() >= date1.getTime())) {
                    CommonForm.Events.SetFieldValue(formContext, "prioritycode", 100000012);
                }
                else {
                    CommonForm.Events.SetFieldValue(formContext, "prioritycode", 100000013);
                }
            }

            formContext.getControl("prioritycode").removeOption(100000001);
            formContext.getControl("prioritycode").removeOption(100000002);
            formContext.getControl("prioritycode").removeOption(100000003);
            formContext.getControl("prioritycode").removeOption(100000004);
            formContext.getControl("prioritycode").removeOption(100000005);
            formContext.getControl("prioritycode").removeOption(100000006);
            formContext.getControl("prioritycode").removeOption(100000007);
            formContext.getControl("prioritycode").removeOption(100000008);
            formContext.getControl("prioritycode").removeOption(1);
            formContext.getControl("prioritycode").removeOption(2);
            formContext.getControl("prioritycode").removeOption(3);
        }
        else if (
            rectype === 100000000 ||
            rectype === 100000002 ||
            rectype === 100000004
        ) {
            //setting priority field value to P5 - None
            if (pricode === null || pricode === 100000007) {
                CommonForm.Events.SetFieldValue(formContext, "prioritycode", 100000013);
            }
            formContext.getControl("prioritycode").removeOption(100000001);
            formContext.getControl("prioritycode").removeOption(100000002);
            formContext.getControl("prioritycode").removeOption(100000003);
            formContext.getControl("prioritycode").removeOption(100000004);
            formContext.getControl("prioritycode").removeOption(100000005);
            formContext.getControl("prioritycode").removeOption(100000006);
            formContext.getControl("prioritycode").removeOption(100000007);
            formContext.getControl("prioritycode").removeOption(100000008);
            formContext.getControl("prioritycode").removeOption(1);
            formContext.getControl("prioritycode").removeOption(2);
            formContext.getControl("prioritycode").removeOption(3);
        } else {
            formContext.getControl("prioritycode").removeOption(100000001);
            formContext.getControl("prioritycode").removeOption(100000002);
            formContext.getControl("prioritycode").removeOption(100000003);
            formContext.getControl("prioritycode").removeOption(100000004);
            formContext.getControl("prioritycode").removeOption(100000009);
            formContext.getControl("prioritycode").removeOption(100000010);
            formContext.getControl("prioritycode").removeOption(100000011);
            formContext.getControl("prioritycode").removeOption(100000012);
            formContext.getControl("prioritycode").removeOption(100000013);
        }
    },

    ControlPriorityBasedOnOwnershipAndTopic: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var rectype = CommonForm.Events.GetFieldValue(formContext, "niq_recordtype");

        // Only apply logic if rectype is 100000001
        if (rectype !== 100000001) return;

        var topicLookup = formContext.getAttribute("niq_topicid")?.getValue();
        var nsstopicLookup = formContext.getAttribute("niq_nsstopic")?.getValue();

        // Helper to enable/disable all prioritycode controls
        function setPriorityCodeDisabled(formContext, shouldDisable) {
            var attr = formContext.getAttribute("prioritycode");
            if (!attr) return;

            var controls = attr.controls;
            if (!controls) return;

            for (var i = 0; i < controls.getLength(); i++) {
                controls.get(i).setDisabled(shouldDisable);
            }
        }

        // Allowed topics and NSS topics
        var allowedTopics = [
            "Data Quality Issues",
            "Database Services"
        ];

        var allowedNSSTopics = [
            "Dataset Changes",
            "Data Inquiry",
            "New dataset set-up"
        ];

        var topicName = topicLookup?.[0]?.name?.trim() || "";
        var nsstopicName = nsstopicLookup?.[0]?.name?.trim() || "";

        var isTopicRestricted = allowedTopics.includes(topicName);
        var isNSSTopicRestricted = allowedNSSTopics.includes(nsstopicName);

        if (isTopicRestricted || isNSSTopicRestricted) {
            var currentUserId = Xrm.Utility.getGlobalContext().userSettings.userId.toLowerCase().replace(/[{}]/g, "");
            var ownerAttr = formContext.getAttribute("ownerid");

            if (!ownerAttr || !ownerAttr.getValue()) {
                // No owner found - disable all prioritycode controls
                setPriorityCodeDisabled(formContext, true);
                return;
            }

            var ownerLookup = ownerAttr.getValue()[0];
            var ownerId = ownerLookup.id.toLowerCase().replace(/[{}]/g, "");
            var ownerType = ownerLookup.entityType;

            if (ownerType === "systemuser" && ownerId === currentUserId) {
                // Owned by current user: unlock all prioritycode controls
                setPriorityCodeDisabled(formContext, false);
            } else {
                // Owner is a team or another user: lock all prioritycode controls
                setPriorityCodeDisabled(formContext, true);
            }
        } else {
            // Not restricted topic: unlock all prioritycode controls
            setPriorityCodeDisabled(formContext, false);
        }
    },

    MethodToHideNewButtonInLookUp: function (lookupctrl) {
        //var lookupControl = Sys.Application.findComponent("some_lookupid");
        if (lookupctrl) {
            lookupctrl.addPreSearch(function () {
                setTimeout(function () {
                    document.getElementById(
                        "Dialog_" + lookupName + "_i_IMenu",
                    ).childNodes[1].childNodes[1].style.display = "none";
                }, 100);
            });
        }
        if (lookupctrl != null) {
            //  lookupctrl._element._behaviors[0].AddParam("ShowNewButton", 0);
        }
    },
    ValidateEmailToCase: function (executionContext) {
        formContext = executionContext.getFormContext();
        var origin = CommonForm.Events.GetFieldText(formContext, "caseorigincode");
        if (formContext.ui.tabs.getLength() !== 1 && origin.indexOf("@") !== -1) {
            var stageName = formContext.data.process.getActiveStage().getName();
            //var direction = executionContext.getEventArgs().getDirection();
            if (stageName == "Assigned") {
                //&& direction === "Next")
                var contactid = CommonForm.Events.GetFieldValue(
                    formContext,
                    "primarycontactid",
                );
                if (contactid !== null) {
                    if (contactid[0].name !== null) {
                        // get parent customer long with account type
                        var fetchXml =
                            "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'> <entity name='contact'> <attribute name='department' /><attribute name='parentcustomerid' />";
                        fetchXml +=
                            "<filter type='and'>  <condition attribute='contactid' operator='eq' uiname='' uitype='contact' value='" +
                            contactid[0].id +
                            "' />";
                        fetchXml +=
                            "</filter> <link-entity name='account' from='accountid' to='parentcustomerid' visible='false' link-type='outer' alias='acc'> <attribute name='niq_industry' />";
                        fetchXml +=
                            "<attribute name='niq_accounttype' /><attribute name='name' /> <attribute name='niq_accountmarketid' /> </link-entity>";
                        fetchXml += "</entity> </fetch>";
                        var clienturl = Xrm.Utility.getGlobalContext().getClientUrl();
                        var result = GetCRMWebAPI.Methods.GetFetchRecords(
                            clienturl,
                            fetchXml,
                            "contacts",
                        );
                        //check if data is retrieved & Companyname has data
                        if (
                            result !== null &&
                            result.value.length > 0 &&
                            result.value[0] !== null &&
                            result.value[0]._parentcustomerid_value !== null
                        ) {
                            if (result.value[0]._parentcustomerid_value === undefined) {
                                Xrm.Utility.alertDialog(
                                    "Kindly update contact/ account details before proceeding further",
                                );
                                executionContext.getEventArgs().preventDefault();
                            }
                        }
                    } else {
                        Xrm.Utility.alertDialog(
                            "Kindly update contact/ account details before proceeding further",
                        );
                        executionContext.getEventArgs().preventDefault();
                    }
                }
            }
        }
    },
    // DYNCRM-28740
    ValidateProgressionBasedOnPriority: function (executionContext) {
        formContext = executionContext.getFormContext();
        var priority = CommonForm.Events.GetFieldValue(formContext, "prioritycode");
        var crRecordType = CommonForm.Events.GetFieldValue(formContext, "niq_recordtype");

        //If Record type is Client Response
        if (crRecordType === 100000001) {
            var stageName = formContext.data.process.getActiveStage().getName();
            var direction = executionContext.getEventArgs().getDirection();
            //If Priority is P5 None, Dont allow request to move after In Progress stage for certain topics
            if (stageName === "In Progress" && direction === "Next" && priority === 100000013) {
                var NSSTopicLookUp = formContext.getAttribute("niq_nsstopic")?.getValue();
                var NSSTopic = NSSTopicLookUp ? NSSTopicLookUp[0].name : "";
                if (["Data Inquiry", "Dataset Changes", "New dataset set-up"].includes(NSSTopic)) {
                    Xrm.Navigation.openAlertDialog(
                        { text: "Priority field must be updated to a valid level (P1-P4) before proceeding", title: "Status Change" },
                        { height: 200, width: 260 }
                    )
                    executionContext.getEventArgs().preventDefault();
                }
            }
        }
    },
    //DYNMCS-2830
    delegateDataTypeControl: function (executionContext) {
        formContext = executionContext.getFormContext();
        var sourceFieldValue = formContext.getAttribute("niq_datatype").getText();
        if (sourceFieldValue !== null && sourceFieldValue.includes("Other")) {
            CommonForm.Events.SetRequiredFieldLevels(
                formContext,
                ["niq_datatypeother"],
                "required",
            );
            CommonForm.Events.ShowHideFields(
                formContext,
                ["niq_datatypeother"],
                true,
            );
        } else {
            CommonForm.Events.SetRequiredFieldLevels(
                formContext,
                ["niq_datatypeother"],
                "none",
            );
            CommonForm.Events.ShowHideFields(
                formContext,
                ["niq_datatypeother"],
                false,
            );
            formContext.getAttribute("niq_datatypeother").setValue(null);
        }
    },
    //DYNMCS-2830
    delegateInformationSourcesControl: function (executionContext) {
        formContext = executionContext.getFormContext();
        var sourceFieldValue = formContext
            .getAttribute("niq_informationsources")
            .getText();
        if (sourceFieldValue !== null && sourceFieldValue.includes("Other")) {
            CommonForm.Events.SetRequiredFieldLevels(
                formContext,
                ["niq_informationsourcesother"],
                "required",
            );
            CommonForm.Events.ShowHideFields(
                formContext,
                ["niq_informationsourcesother"],
                true,
            );
        } else {
            CommonForm.Events.SetRequiredFieldLevels(
                formContext,
                ["niq_informationsourcesother"],
                "none",
            );
            CommonForm.Events.ShowHideFields(
                formContext,
                ["niq_informationsourcesother"],
                false,
            );
            formContext.getAttribute("niq_informationsourcesother").setValue(null);
        }
    },
    //DYNMCS-2830
    delegateDeliveryFormatControl: function (executionContext) {
        formContext = executionContext.getFormContext();
        var sourceFieldValue = formContext
            .getAttribute("niq_deliveryformat_delegate")
            .getText();
        if (sourceFieldValue !== null && sourceFieldValue.includes("Other")) {
            CommonForm.Events.SetRequiredFieldLevels(
                formContext,
                ["niq_deliveryformatother"],
                "required",
            );
            CommonForm.Events.ShowHideFields(
                formContext,
                ["niq_deliveryformatother"],
                true,
            );
        } else {
            CommonForm.Events.SetRequiredFieldLevels(
                formContext,
                ["niq_deliveryformatother"],
                "none",
            );
            CommonForm.Events.ShowHideFields(
                formContext,
                ["niq_deliveryformatother"],
                false,
            );
            formContext.getAttribute("niq_deliveryformatother").setValue(null);
        }
    },
    MethodToLockFormDetailsField: function (executionContext) {
        formContext = executionContext.getFormContext();
        var recordtype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        if (
            formContext.getControl("niq_formdetails") !== null &&
            recordtype !== null &&
            (recordtype === 100000003 || recordtype === 100000004)
        ) {
            if (!CommonForm.Events.CheckIfLoggedInUserRoles(adminRole)) {
                formContext.getControl("niq_formdetails").setDisabled(true);
            }
        }
    },
    MethodToLockFormDetailsField: function (executionContext) {
        formContext = executionContext.getFormContext();
        var recordtype = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        if (
            formContext.getControl("niq_formdetails") !== null &&
            recordtype !== null &&
            (recordtype === 100000003 || recordtype === 100000004)
        ) {
            if (!CommonForm.Events.CheckIfLoggedInUserRoles(adminRole)) {
                formContext.getControl("niq_formdetails").setDisabled(true);
            }
        }
    },
    MethodToRemoveValuesfromSubstatusForNGHAMNewStatus: function (executionContext,) {
        "use strict";
        formContext = executionContext.getFormContext();
        var recordType = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        var status = CommonForm.Events.GetFieldValue(formContext, "statuscode");
        var substatus1 = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_substatus",
        );
        var substatus = formContext.getControl("niq_substatus");
        //NGHAM
        if (recordType === 100000004 && status === 100000000) {
            substatus.removeOption(100000001);
            substatus.removeOption(100000003);
            substatus.removeOption(100000000);
            substatus.removeOption(100000010);
            substatus.removeOption(100000011);
            substatus.removeOption(100000012);
            substatus.removeOption(100000002);
            substatus.removeOption(100000004);
            substatus.removeOption(100000005);
            substatus.removeOption(100000006);
            substatus.removeOption(100000007);
            substatus.removeOption(100000008);
            substatus.removeOption(100000009);
            substatus.removeOption(100000013);
            substatus.removeOption(100000014);
            substatus.removeOption(100000018);
            substatus.removeOption(100000019);
            substatus.removeOption(100000021);
            substatus.removeOption(100000022);
            substatus.removeOption(100000024);
            substatus.removeOption(100000025);
            substatus.removeOption(100000026);
            substatus.removeOption(100000027);
        } else if (recordType === 100000004 && status === 1) {
            substatus.removeOption(100000000);
            substatus.addOption({
                value: 100000000,
                text: "Working",
            });
            substatus.removeOption(100000001);
            substatus.addOption({
                value: 100000001,
                text: "Hold - Internal",
            });
            substatus.removeOption(100000003);
            substatus.addOption({
                value: 100000003,
                text: "Hold - External",
            });
            substatus.removeOption(100000010);
            substatus.addOption({
                value: 100000010,
                text: "Hold - Internal Long Term Escalation",
            });
            substatus.removeOption(100000013);
            substatus.addOption({
                value: 100000013,
                text: "Portal Provisioning",
            });
            substatus.removeOption(100000014);
            substatus.addOption({
                value: 100000014,
                text: "Product Provisioning",
            });
            substatus.removeOption(100000018);
            substatus.addOption({
                value: 100000018,
                text: "Error, Product",
            });
            substatus.removeOption(100000019);
            substatus.addOption({
                value: 100000019,
                text: "Fulfilled",
            });
            substatus.removeOption(100000023); //remove autoprocessed
            substatus.removeOption(100000026);
            substatus.addOption({
                value: 100000026,
                text: "On Hold - Software Issue",
            });
        }
    },

    ValidationOnPlannedEndDate: function (executionContext) {
        "use strict";
        // Get the value of the niq_plannedenddate field
        var plannedEndDate = formContext.getAttribute("niq_plannedenddate").getValue();
        // Clear any previous notifications
        formContext.ui.clearFormNotification();

        if (plannedEndDate) {
            var today = new Date();
            today.setHours(0, 0, 0, 0);

            // Compare the planned end date with today's date
            if (plannedEndDate.getTime() < today.getTime()) {
                // Set a warning notification
                formContext.ui.setFormNotification(
                    "Planned End date can be today or future but not past date.",
                    "WARNING",  // Notification level
                    "plannedEndDateWarning"  // Unique ID for the notification
                );

                // Clear the field if it's invalid
                formContext.getAttribute("niq_plannedenddate").setValue(null);
            }
        }
    },
    OnChangeofSubstatus: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var subStatusValue = formContext.getAttribute("niq_respondedsubstatus").getValue();
        var isTechDurables = CommonForm.Events.GetFieldValue(formContext, "niq_istechdurables");
        if (!isTechDurables) {
                // Show the Knowledge Feedback section
                formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summary_section_Knowledgefeedback").setVisible(true);
        }
    },
    onStageChangeknowledgesection: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var stageName = formContext.data.process.getActiveStage().getName();
        var subStatusValue = formContext.getAttribute("niq_respondedsubstatus").getValue();
        var recordType = formContext.getAttribute("niq_recordtype").getValue();
        var isTechDurables = CommonForm.Events.GetFieldValue(formContext, "niq_istechdurables");
    
        if (!isTechDurables) {
            if (
                !formContext.getAttribute("niq_kahelptosolveticket") ||
                !formContext.getAttribute("niq_nsslinkknowledgearticle") ||
                !formContext.getAttribute("niq_reviewforka") ||
                !formContext.getAttribute("niq_why") ||
                (recordType !== 100000002 && !formContext.getAttribute("niq_articleheadingtitle"))
            ) {
                return;
            }
    
            // Always visible
            formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summary_section_Knowledgefeedback").setVisible(true);
    
            // Mandatory only when moving into Responded with Solution Provided
            if ((stageName === "Responded" || stageName === "In Progress") && subStatusValue === 100000004) {
                formContext.getAttribute("niq_kahelptosolveticket").setRequiredLevel("required");
            } else {
                formContext.getAttribute("niq_kahelptosolveticket").setRequiredLevel("none");
            }
    
            RequestForm.Events.AutoPopulateKAFeedbackFields(executionContext);
            RequestForm.Events.KnowledgeFeedbackSectionFieldsShowHide(executionContext);
        }
    },    
    
    KnowledgeFeedbackSectionFieldsShowHide: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var stageName = formContext.data.process.getActiveStage().getName();
        var subStatusValue = formContext.getAttribute("niq_respondedsubstatus").getValue();
        var KAHelpedToSolve = formContext.getAttribute("niq_kahelptosolveticket");
        var NSSLinkField = formContext.getAttribute("niq_nsslinkknowledgearticle");
        var KAhelptosolveticket = KAHelpedToSolve?.getValue();
    
        formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summary_section_Knowledgefeedback").setVisible(true);
    
        // Flag for checking mandatory mode
        var isMandatoryMode = (stageName === "Responded" || stageName === "In Progress") && subStatusValue === 100000004;
    
        if (KAhelptosolveticket === 100000000) { // Yes
            formContext._linkManuallyUpdated = false;
            RequestForm.Events.AutoPopulateKAFeedbackFields(executionContext);
    
            formContext.getControl("niq_nsslinkknowledgearticle")?.setVisible(true);
            NSSLinkField.setRequiredLevel(isMandatoryMode ? "required" : "none"); //flag updated
    
            var KALink1 = formContext.getAttribute("niq_nssknowledgearticle")?.getValue();
            if ((!KALink1 || KALink1.length === 0) && CommonForm.Events.CheckFieldExists(formContext, "niq_articleheadingtitle")) {
                formContext.getControl("niq_articleheadingtitle")?.setVisible(true);
                formContext.getAttribute("niq_articleheadingtitle")?.setRequiredLevel("none"); // stays optional
            } else {
                var articleLinkVal = NSSLinkField?.getValue();
                if (articleLinkVal && CommonForm.Events.CheckFieldExists(formContext, "niq_articleheadingtitle")) {
                    formContext.getControl("niq_articleheadingtitle")?.setVisible(true);
                    formContext.getAttribute("niq_articleheadingtitle")?.setRequiredLevel("none"); // stays optional
                }
            }
    
            formContext.getControl("niq_reviewforka")?.setVisible(false);
            formContext.getControl("niq_why")?.setVisible(false);
    
        } else if (KAhelptosolveticket === 100000001) { // No
            formContext.getControl("niq_nsslinkknowledgearticle")?.setVisible(false);
            NSSLinkField.setValue(null);
            NSSLinkField.setRequiredLevel("none");
    
            formContext.getControl("niq_articleheadingtitle")?.setVisible(false);
            formContext.getAttribute("niq_articleheadingtitle")?.setValue(null);
            formContext.getAttribute("niq_articleheadingtitle")?.setRequiredLevel("none");
    
            formContext.getControl("niq_reviewforka")?.setVisible(true);
            formContext.getAttribute("niq_reviewforka")?.setRequiredLevel(isMandatoryMode ? "required" : "none"); //flag updated
    
            var reviewforKA = formContext.getAttribute("niq_reviewforka")?.getValue();
            if (reviewforKA) {
                formContext.getControl("niq_why")?.setVisible(true);
                formContext.getAttribute("niq_why")?.setRequiredLevel(isMandatoryMode ? "required" : "none"); //flag updated
            } else {
                formContext.getControl("niq_why")?.setVisible(false);
                formContext.getAttribute("niq_why")?.setRequiredLevel("none");
            }
        } else {
            formContext.getControl("niq_reviewforka")?.setVisible(false);
            formContext.getControl("niq_nsslinkknowledgearticle")?.setVisible(false);
            formContext.getControl("niq_articleheadingtitle")?.setVisible(false);
            formContext.getControl("niq_why")?.setVisible(false);
        }
    },       
      
    AutoPopulateKAFeedbackFields: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var KAHelpedToSolve = formContext.getAttribute("niq_kahelptosolveticket");
        var NSSLinkField = formContext.getAttribute("niq_nsslinkknowledgearticle");
        var KALink1 = formContext.getAttribute("niq_nssknowledgearticle")?.getValue();
    
        formContext.ui.tabs.get("tab_Summary").sections.get("tab_Summary_section_Knowledgefeedback").setVisible(true);
    
        var manuallyUpdated = formContext._linkManuallyUpdated === true;
        var currentNSSValue = NSSLinkField?.getValue();
    
        //if user has manually updated, skip auto-populate entirely
        if (manuallyUpdated) {
            return; // keep the userâ€™s manual value
        }
    
        // If KA link is missing, clear values
        if (!KALink1) {
            NSSLinkField.setValue(null);
            KAHelpedToSolve.setValue(null);
            formContext._linkManuallyUpdated = false; // reset flag
            return;
        }
    
        // Auto-populate only when KA link exists and user has not overridden
        KAHelpedToSolve.setValue(100000000); // Yes
        NSSLinkField.setValue(KALink1);
        formContext._linkManuallyUpdated = false;
    
        if (CommonForm.Events.CheckFieldExists(formContext, "niq_articleheadingtitle")) {
            formContext.getControl("niq_articleheadingtitle").setVisible(true);
        }
    },         
    
    OnChangeNSSLinkField: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var NSSLinkField = formContext.getAttribute("niq_nsslinkknowledgearticle");
        var KALink1 = formContext.getAttribute("niq_nssknowledgearticle")?.getValue();
        var currentValue = NSSLinkField?.getValue();
    
        if (!currentValue) {
            formContext._linkManuallyUpdated = false;
            return;
        }
    
        // If NSS link matches KA link, auto-populated link
        if (KALink1 && currentValue[0].id === KALink1[0].id) {
            formContext._linkManuallyUpdated = false;
        } else {
            // Otherwise user manually updated
            formContext._linkManuallyUpdated = true;
        }
    },
      
    //DYNCRM-28025
    ShowResolutionTypeField: function (executionContext) {
        var formContext = executionContext.getFormContext();

        if (
            !formContext.getAttribute("niq_resolutiontype") ||
            !formContext.getControl("niq_resolutiontype")
        ) {
            return;
        }

        var stageName = formContext.data.process.getActiveStage().getName();
        var subStatusValue = formContext.getAttribute("niq_respondedsubstatus").getValue();
        var recordType = formContext.getAttribute("niq_recordtype").getValue();

        var shouldShow =
            (recordType === 100000001 || recordType === 100000003) &&
            (stageName === "Responded" || stageName === "In Progress") &&
            subStatusValue === 100000004;

        var resolutionControl = formContext.getControl("niq_resolutiontype");
        var resolutionAttr = formContext.getAttribute("niq_resolutiontype");

        resolutionControl.setVisible(shouldShow);
        resolutionAttr.setRequiredLevel(shouldShow ? "required" : "none");

        if (!shouldShow) {
            resolutionAttr.setValue(null);
        }
    },

    QuickCreateOnload: function (executionContext) {
        //this variable contains entity reference to the parent record
        var parentRecordReference =
            Xrm.Utility.getPageContext().input.createFromEntity;
        formContext = executionContext.getFormContext();
        var subject = CommonForm.Events.GetFieldValue(formContext, "title");
        if (subject !== null && formContext.ui.tabs.getLength() === 1) {
            var lkupparentcase = [];
            lkupparentcase[0] = {};
            lkupparentcase[0].id =
                Xrm.Utility.getPageContext().input.data.parentcase.id;
            lkupparentcase[0].entityType =
                Xrm.Utility.getPageContext().input.data.parentcase.entityType;
            lkupparentcase[0].name =
                Xrm.Utility.getPageContext().input.data.parentcase.name;
            formContext.data.entity.attributes
                .get("parentcaseid")
                .setValue(lkupparentcase);
        }
        //if this variable is null then Quick Create Form was called from the Global Menu
        //or from some other code without setting the parent record context
        if (parentRecordReference == null) {
            return;
        }
        //you can use value of parentRecordReference in your code
        console.log(parentRecordReference.id);
        console.log(parentRecordReference.entityType);
        console.log(parentRecordReference.name);
    },
    CreatenewRequests: function (executionContext) {
        "use strict";
        //if (isdisabledform) return;
        formContext = executionContext.getFormContext();
        var crRecordType = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        var priority = CommonForm.Events.GetFieldValue(formContext, "prioritycode");
        var accountid = CommonForm.Events.GetFieldValue(formContext, "customerid");
        var contactid = CommonForm.Events.GetFieldValue(
            formContext,
            "primarycontactid",
        );
        var requestid = formContext.data.entity.getId();
        var title = CommonForm.Events.GetFieldValue(formContext, "title");
        var description = CommonForm.Events.GetFieldValue(
            formContext,
            "description",
        );
        if (accountid != null) var accname = accountid[0].name;
        var parameters = {};
        if (
            formContext.data.entity.getId() == null &&
            formContext.data.entity.getId() == ""
        )
            return;
        var lkupaccount = new Array();
        lkupaccount[0] = new Object();
        lkupaccount[0].id = accountid[0].id;
        lkupaccount[0].name = accountid[0].name;
        lkupaccount[0].entityType = "account";
        var lkupcontact = new Array();
        lkupcontact[0] = new Object();
        lkupcontact[0].id = contactid[0].id;
        lkupcontact[0].name = contactid[0].name;
        lkupcontact[0].entityType = "contact";
        if (accountid != undefined || accountid != null)
            parameters["customerid"] = lkupaccount;
        if (contactid != undefined || contactid != null)
            parameters["primarycontactid"] = lkupcontact;
        parameters["niq_internalrequest"] = 100000001;
        if (description != undefined || description != null)
            parameters["description"] = description;
        if (title != undefined || title != null)
            parameters["title"] = "ION Created - " + "" + title;
        parameters["niq_internalrequest"] = 100000001;
        if (requestid != null) {
            var lkuprequest = new Array();
            lkuprequest[0] = new Object();
            lkuprequest[0].id = requestid;
            lkuprequest[0].name = title;
            lkuprequest[0].entityType = "incident";
            //#region
            //var lkupparentcase = [];
            //lkupparentcase [0] = {};
            //lkupparentcase [0].id = Xrm.Utility.getPageContext().input.data.parentcase.id;
            //lkupparentcase [0].entityType = Xrm.Utility.getPageContext().input.data.parentcase.entityType;
            //lkupparentcase [0].name = Xrm.Utility.getPageContext().input.data.parentcase.name;
            //#endregion
            parameters["parentcaseid"] = lkuprequest;
            //
        }
        var formid = "";
        formid = CommonForm.Events.GetFieldValue(formContext, "niq_statictext");
        var createdOn_date = CommonForm.Events.GetFieldValue(
            formContext,
            "createdon",
        );
        var Required_date = new Date("May 03, 2024");
        if (
            createdOn_date != null &&
            createdOn_date.getTime() > Required_date.getTime()
        ) {
            if (crRecordType === 100000001) {
                // Client Response
                if (formid == "D8659076-E1DC-47ED-91D5-5DF15B0B0CE6") {
                    //data validity
                    if (priority == 100000009) {
                        // set priority critical on ion ticket
                        parameters["prioritycode"] = 100000009;
                    } else if (priority == 100000010) {
                        // set priority high on ion ticket
                        parameters["prioritycode"] = 100000010;
                    } else if (priority == 100000011) {
                        // set priority medium on ion ticket
                        parameters["prioritycode"] = 100000011;
                    } else if (priority == 100000012 || priority == 100000013) {
                        // set priority low on ion ticket
                        parameters["prioritycode"] = 100000012;
                    }
                } else if (formid == "BA491C58-73CA-478D-AB3A-FF19BACDC230") {
                    //information
                    if (priority == 100000009) {
                        // set priority critical on ion ticket
                        parameters["prioritycode"] = 100000009;
                    } else if (priority == 100000010) {
                        // set priority high on ion ticket
                        parameters["prioritycode"] = 100000010;
                    } else if (priority == 100000011) {
                        // set priority medium on ion ticket
                        parameters["prioritycode"] = 100000011;
                    } else if (priority == 100000012 || priority == 100000013) {
                        // set priority low on ion ticket
                        parameters["prioritycode"] = 100000012;
                    }
                } else if (formid == "182CD6D6-5B8B-41A6-AAB3-B341776F01F8") {
                    // order buy
                    if (priority == 100000009) {
                        // set priority critical on ion ticket
                        parameters["prioritycode"] = 100000009;
                    } else if (priority == 100000010) {
                        // set priority high on ion ticket
                        parameters["prioritycode"] = 100000010;
                    } else if (priority == 100000011) {
                        // set priority medium on ion ticket
                        parameters["prioritycode"] = 100000011;
                    } else if (priority == 100000012 || priority == 100000013) {
                        // set priority low on ion ticket
                        parameters["prioritycode"] = 100000012;
                    }
                }
                parameters["niq_ionfromcr"] = 1; //1 for Yes
                //else { }
            }
        }
        var pageInput = {
            pageType: "entityrecord",
            entityName: "incident",
            formId: formid,
            data: parameters,
        };
        var navigationOptions = {
            target: 1,
            height: {
                value: 90,
                unit: "%",
            },
            width: {
                value: 80,
                unit: "%",
            },
            position: 1,
        };
        Xrm.Navigation.navigateTo(pageInput, navigationOptions);
        CommonForm.Events.SetFieldValue(formContext, "niq_statictext", "");
        formContext.data.entity.save("success");
    },
    SetSLAForAccountMarket: function (context) {
        var _formContext = context.getFormContext();
        if (_formContext.getAttribute("customerid").getValue() !== null) {
            var accountId = _formContext.getAttribute("customerid").getValue()[0].id;

            getAccountMarket(_formContext, accountId)
                .then(function (value) {
                    var regionName = getSLARegionBasedOnCountry(value.name);

                    var formType = getFormType(_formContext);
                    getSLARecord(_formContext, regionName, formType)
                        .then(function (value) {
                            if (value !== null) {
                                var slaLookup = [{
                                    entityType: "sla",
                                    id: "{" + value.id + "}",
                                    name: value.name,
                                },];
                                _formContext.getAttribute("slaid").setValue(slaLookup);
                            }
                        })
                        .catch((error) => console.log(error));
                })
                .catch((error) => console.log(error));
        }
    },
    setJiraRequestIdFilter: function (executionContext) {
        try {
            // get the form context
            formContext = executionContext.getFormContext();
            formContext
                .getControl("niq_mainjirarequest")
                .addPreSearch(this.filterJiraRequest);
        } catch (ex) {
            console.log(ex.message);
        }
    },
    filterJiraRequest: function () {
        // Only show JIRA Request linked to main Request
        try {
            currentTicketNumber = CommonForm.Events.GetFieldValue(
                formContext,
                "ticketnumber",
            );
            var JiraRequestFilter =
                "<filter type='and'><condition attribute='niq_parentrequestnumber' operator='eq' value='" +
                currentTicketNumber +
                "'/></filter>";
            formContext
                .getControl("niq_mainjirarequest")
                .addCustomFilter(JiraRequestFilter, "niq_jiraequest");
        } catch (ex) {
            console.log(ex.message);
        }
    },
    setProductIdFilter: function (executionContext) {
        // get the form context
        formContext = executionContext.getFormContext();
        formContext.getControl("niq_nghproductid").addPreSearch(this.filterCustomerProducts);

    },
    filterCustomerProducts: function () {
        var recordtypeval = CommonForm.Events.GetFieldValue(
            formContext,
            "niq_recordtype",
        );
        var topiclookup = formContext.getAttribute("niq_topicid").getValue();
        var topic = topiclookup != null ? topiclookup[0].name : "";
        if (
            CommonForm.Events.CheckFieldExists(formContext, "niq_nghproductid") &&
            ((recordtypeval === 100000000 && topic === "Data Extraction") ||
                (recordtypeval === 100000001 &&
                    (topic === "Data & Methodology Questions" ||
                        topic === "Access Request" ||
                        topic === "Training")))
        ) {
            var fetchXml =
                "<filter type='and'>  <condition attribute='statecode' operator='eq' value='0' /> <condition attribute='niq_businessline' operator='eq' value='100000001' /></filter>";
            formContext
                .getControl("niq_nghproductid")
                .addCustomFilter(fetchXml, "niq_nghproduct");
        } else {
            var services = [100000000, 100000001, 100000002, 100000003, 100000004];
            services[100000000] = [
                "Discover",
                "Connect Express",
                "Answers on Demand",
                "CASE",
                "Spectra",
                "Not Sure",
            ];
            services[100000001] = [
                "Discover",
                "Connect Express",
                "Answers on Demand",
                "Excel Add-In",
                "Not Sure",
            ];
            services[100000002] = [
                "Discover",
                "Connect Express",
                "Answers on Demand",
                "CASE",
                "Spectra",
                "Not Sure",
            ];
            services[100000003] = [
                "Discover",
                "Connect Express",
                "Answers on Demand",
                "CASE",
                "Spectra",
                "Not Sure",
            ];
            services[100000003] = [
                "Discover",
                "Connect Express",
                "Answers on Demand",
                "CASE",
                "Spectra",
                "Not Sure",
            ];
            services[100000004] = [
                "Discover",
                "Connect Express",
                "Answers on Demand",
                "CASE",
                "Spectra",
                "Not Sure",
            ];
            services.forEach(function (service) {
                if (
                    formContext.getAttribute("niq_serviceproduct").getValue() === service
                ) {
                    var condition = "";
                    services[service].forEach(function (name) {
                        condition +=
                            "<condition attribute='niq_name' operator='eq' value='" +
                            name +
                            "' />";
                    });
                    // Only show PRoducts filtered by name'
                    var customerAccountFilter =
                        "<filter type='and'><filter type='and'><condition attribute='niq_businessline' operator='null' /><filter type='or'>" +
                        condition +
                        "</filter></filter></filter>";
                    formContext
                        .getControl("niq_nghproductid")
                        .addCustomFilter(customerAccountFilter, "niq_nghproduct");
                }
            });
        }
    },

    ShowHideOptionSetValues: function (executionContext, fieldName, valuesToHideORShow, bool) {
        "use strict";
        var formContext = executionContext.getFormContext();
        var options = formContext.getControl(fieldName);
        try {
            valuesToHideORShow.forEach(function (option) {
                if (bool === true) {
                    // show options that are in the valuesToHideORShow array
                    options.addOption(option);
                }
                else if (bool === false) {
                    // hide options that are in the valuesToHideORShow array
                    options.removeOption(option);
                }
                else;
            });
        } catch (error) {
            console.log(error);
        }
    },
    GetPreviousPriority: function (executionContext) {
        formContext = executionContext.getFormContext();
        if (formContext.getAttribute("prioritycode") !== null) {
            PreviousPriority = formContext.getAttribute("prioritycode").getValue();
        } else {
            PreviousPriority = null;
        }
    },
    //function on change of priority and Planned End Date
    ThrowErroronPlannedEndDate: function (executionContext) {
        let priority;
        let subtopic;
        var TopicLookupName;
        var AlertId = "Alert";
        let errorText = "";
        formContext = executionContext.getFormContext();
        try {
            priority = formContext.getAttribute("prioritycode").getValue();
            subtopic = formContext.getAttribute("niq_subtopic").getValue();
            //?formContext.getAttribute().getValue("niq_subtopic"):null;
            TopicLookupName = formContext.getAttribute("niq_topicid").getValue()[0].name;
            if (formContext.getAttribute("niq_recordtype").getValue() === 100000001 &&
                subtopic === 610570007 || subtopic === 610570008 || subtopic === null &&
                TopicLookupName === "Data quality issues" || TopicLookupName === "Product Coding Information") {

                switch (priority) {
                    //p1
                    case 100000009:
                        errorText = "Planned End Date (expected Resolution date) communicated to client should not exceed 5 days for majority of cases (for remaining - no longer than 8 days), starting from the ticket opening day.";
                        break;
                    //p2
                    case 100000010:
                        errorText = "Planned End Date (expected Resolution date) communicated to client should not exceed 10 days for majority of cases (for remaining - no longer than 15 days), starting from the ticket opening day.";
                        break;
                    //p3
                    case 100000011:
                    case 100000012:
                    case 100000013:
                        errorText = "Planned End Date (expected Resolution date) communicated to client should not exceed 15 days for majority of cases (for remaining - no longer than 20 days), starting from the ticket opening day.";
                        break;

                }
                if (formContext.getAttribute("niq_plannedenddate").getValue() === null && errorText) {
                    formContext.ui.setFormNotification(errorText, "WARNING", AlertId);
                }
                else if (formContext.getAttribute("niq_plannedenddate").getValue() && priority !== PreviousPriority && errorText) {
                    formContext.ui.setFormNotification(errorText, "WARNING", AlertId);
                } else if (formContext.getAttribute("niq_plannedenddate").getValue() && priority === PreviousPriority && errorText) {
                    //formContext.ui.clearFormNotification(AlertId);
                    formContext.ui.setFormNotification(errorText, "WARNING", AlertId);

                }
            }
            else {
                formContext.ui.clearFormNotification(AlertId);
            }

            PreviousPriority = priority;
        } catch (error) {
            console.log(error);
        }
    },
    clearSubtopic: function (executionContext) {
        var formContext = executionContext.getFormContext();
        CommonForm.Events.SetFieldValue(formContext, "niq_nsssubtopic", null)
    },
    // function to show hide SLA section  /DYNCRM-22991
    ShowHideSLASection: function (executionContext) {
        let formContext = executionContext.getFormContext();
        let RespondedDate = null;
        try {
            if (recordTypeText === "Analytics" || recordTypeText === "Client Response" || recordTypeText === "Delegate") {
                RespondedDate = formContext.getAttribute("niq_respondeddatetime").getValue();
                ClosedDate = formContext.getAttribute("niq_closeddate").getValue();
                if (RespondedDate || ClosedDate) {
                    CommonForm.Events.ShowHideSections(formContext, "tab_details", "tab_details_section_slas", false);
                    CommonForm.Events.ShowHideSections(formContext, "tab_Summary", "tab_Summary_section_slas", false);
                }
                else {
                    CommonForm.Events.ShowHideSections(formContext, "tab_details", "tab_details_section_slas", true);
                    CommonForm.Events.ShowHideSections(formContext, "tab_Summary", "tab_Summary_section_slas", true);
                }
            }
        } catch (error) {
            console.log(error);
        }
    },

    ShowHideNSSKALinksOnLoad: function (executionContext) {
        const formContext = executionContext.getFormContext();
        const recordTypeAttr = formContext.getAttribute("niq_recordtype");
        if (!recordTypeAttr) return;

        const recordType = recordTypeAttr.getValue();
        const validTypes = [100000000, 100000001, 100000003];
        if (!validTypes.includes(recordType)) return;

        const fieldNames = [
            "niq_nssknowledgearticle",
            "niq_nssknowledgearticle2",
            "niq_nssknowledgearticle3",
            "niq_nssknowledgearticle4",
            "niq_nssknowledgearticle5"
        ];

        // Always show the first field
        const firstControl = formContext.getControl(fieldNames[0]);
        if (firstControl) firstControl.setVisible(true);

        let showNext = false;
        for (let i = 1; i < fieldNames.length; i++) {
            const prevAttr = formContext.getAttribute(fieldNames[i - 1]);
            const attr = formContext.getAttribute(fieldNames[i]);
            const ctrl = formContext.getControl(fieldNames[i]);

            if (!ctrl || !prevAttr) continue;

            if (prevAttr.getValue()) {
                ctrl.setVisible(true); // show this field if previous has value
                showNext = attr.getValue() ? true : false;
            } else {
                ctrl.setVisible(false);
                if (attr) attr.setValue(null);
                showNext = false;
            }

            // Clear and hide remaining fields if the chain breaks
            if (!showNext) {
                for (let j = i + 1; j < fieldNames.length; j++) {
                    const attrToClear = formContext.getAttribute(fieldNames[j]);
                    const ctrlToHide = formContext.getControl(fieldNames[j]);
                    if (ctrlToHide) ctrlToHide.setVisible(false);
                    if (attrToClear) attrToClear.setValue(null);
                }
                break;
            }
        }

        // Setup onChange handlers safely (avoid duplicates)
        fieldNames.forEach(fieldName => {
            const attribute = formContext.getAttribute(fieldName);
            if (attribute) {
                attribute.removeOnChange(RequestForm.Events.ValidateNSSKALinksOnChange);
                attribute.addOnChange(RequestForm.Events.ValidateNSSKALinksOnChange);
            }
        });

        // Fetch base URL (for onChange validation use)
        const fetchXml = `
			<fetch top="1">
				<entity name="niq_keyvalueconfiguration">
					<attribute name="niq_value" />
					<filter>
						<condition attribute="niq_name" operator="eq" value="NSSKALink" />
					</filter>
				</entity>
			</fetch>`;

        Xrm.WebApi.retrieveMultipleRecords("niq_keyvalueconfiguration", "?fetchXml=" + encodeURIComponent(fetchXml))
            .then(function (result) {
                if (result.entities.length > 0) {
                    window.validBaseUrl = result.entities[0].niq_value;
                }
            })
            .catch(function (error) {
                console.error("Error fetching base URL:", error.message);
            });
    },

    ValidateNSSKALinksOnChange: function (executionContext) {
        const attribute = executionContext.getEventSource();
        const formContext = executionContext.getFormContext();
        const control = formContext.getControl(attribute.getName());

        if (!attribute || !control) return;

        control.clearNotification();
        const value = attribute.getValue();

        const fieldNames = [
            "niq_nssknowledgearticle",
            "niq_nssknowledgearticle2",
            "niq_nssknowledgearticle3",
            "niq_nssknowledgearticle4",
            "niq_nssknowledgearticle5"
        ];

        const currentFieldIndex = fieldNames.indexOf(attribute.getName());

        if (value && validBaseUrl) {
            if (!value.startsWith(validBaseUrl)) {
                control.setNotification("Invalid link. Please use a valid NSS domain link.");
            } else {
                control.clearNotification();

                // Show all following fields if they already have values
                for (let i = currentFieldIndex + 1; i < fieldNames.length; i++) {
                    const attr = formContext.getAttribute(fieldNames[i]);
                    const ctrl = formContext.getControl(fieldNames[i]);

                    if (attr && ctrl && attr.getValue()) {
                        ctrl.setVisible(true);
                    } else {
                        break; // stop showing if any one is empty
                    }
                }

                // Always show immediate next field if available
                if (currentFieldIndex < fieldNames.length - 1) {
                    const nextControl = formContext.getControl(fieldNames[currentFieldIndex + 1]);
                    if (nextControl) nextControl.setVisible(true);
                }
            }
        } else {
            // If cleared or invalid, hide and clear all fields after current
            for (let i = currentFieldIndex + 1; i < fieldNames.length; i++) {
                const attr = formContext.getAttribute(fieldNames[i]);
                const ctrl = formContext.getControl(fieldNames[i]);
                if (ctrl) ctrl.setVisible(false);
                if (attr) attr.setValue(null);
            }
        }
    },

    SetNSSTopicRequestOrginforNGHAM: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var recordType = formContext.getAttribute("niq_recordtype")?.getValue();
        var reqOriginAttr = formContext.getAttribute("niq_ngham_req_origin");
        var nghreqOrigin = reqOriginAttr ? reqOriginAttr.getValue() : null;
        var nssTopicAttr = formContext.getAttribute("niq_nsstopic");
        var nssTopicControl = formContext.getControl("niq_nsstopic");
        var caseOriginAttr = formContext.getAttribute("caseorigincode");
        var topicControl = formContext.getControl("niq_topicid");

        // Check Record Type = NGH AM 
        if (recordType !== 100000004) {
            return;
        }

        // If Request Origin present
        if (nghreqOrigin !== null && nghreqOrigin === 100000000) {
            // Hide all Topic controls
            var topicAttribute = formContext.getAttribute("niq_topicid");
            if (topicAttribute) {
                topicAttribute.controls.forEach(function (ctrl) {
                    ctrl.setVisible(false);
                });
            }
        }
        // Call visibility logic
        RequestForm.Events.ShowNSSTopicField(executionContext);
    },

    ShowNSSTopicField: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var recordType = formContext.getAttribute("niq_recordtype")?.getValue();
        var reqOrigin = formContext.getAttribute("caseorigincode")?.getValue();
        var topicAttr = formContext.getAttribute("niq_topicid");
        var nssTopicAttr = formContext.getAttribute("niq_nsstopic");

        // Check Record Type = NGH AM 
        if (recordType !== 100000004) {
            return;
        }

        if (reqOrigin === 100000172) {
            // Show NSS Topic, hide Topic
            if (nssTopicAttr) {
                nssTopicAttr.controls.forEach(function (ctrl) {
                    ctrl.setVisible(true);
                });
                formContext.ui.tabs.get("tab_details").sections.get("AdditionalInformationNGHAM")?.setVisible(true);
                formContext.ui.tabs.get("tab_details").sections.get("AdditionalInformationNGHAM2")?.setVisible(true);
                formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_20")?.setVisible(true);
                formContext.getControl("niq_nsssubtopic")?.setVisible(true);
                formContext.getAttribute("niq_niqnghsolution")?.setRequiredLevel("required");
                formContext.getAttribute("niq_country")?.setRequiredLevel("required");
                formContext.getAttribute("niq_ticketcreatortype")?.setRequiredLevel("required");
                formContext.getAttribute("niq_nsstopic")?.setRequiredLevel("required");
                formContext.getAttribute("niq_nsssubtopic")?.setRequiredLevel("required");

            }
            if (topicAttr) {
                topicAttr.controls.forEach(function (ctrl) {
                    ctrl.setVisible(false);
                });
            }
        } else {
            // Show Topic, hide NSS Topic
            if (nssTopicAttr) {
                nssTopicAttr.controls.forEach(function (ctrl) {
                    ctrl.setVisible(false);
                });
                formContext.ui.tabs.get("tab_details").sections.get("AdditionalInformationNGHAM")?.setVisible(false);
                formContext.ui.tabs.get("tab_details").sections.get("AdditionalInformationNGHAM2")?.setVisible(false);
                formContext.ui.tabs.get("tab_details").sections.get("tab_details_section_20")?.setVisible(false);
                formContext.getControl("niq_nsssubtopic")?.setVisible(false);
                formContext.getAttribute("niq_niqnghsolution")?.setRequiredLevel("none");
                formContext.getAttribute("niq_country")?.setRequiredLevel("none");
                formContext.getAttribute("niq_ticketcreatortype")?.setRequiredLevel("none");
                formContext.getAttribute("niq_nsstopic")?.setRequiredLevel("none");
                formContext.getAttribute("niq_nsssubtopic")?.setRequiredLevel("none");
            }
            if (topicAttr) {
                topicAttr.controls.forEach(function (ctrl) {
                    ctrl.setVisible(true);
                });
            }
        }
    },

    setTopicMandatoryforDelegate: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var recordType = formContext.getAttribute("niq_recordtype").getValue();
        // Early return if not delegate
        if (recordType !== 100000002) {
            return;
        }
        // Only runs when recordType is delegate
        formContext.getAttribute("niq_topicid").setRequiredLevel("required");
    },

    //function to show hide option set values in "Industry" field(DYNCRM-24615)
    ShowHideIndustryValues: function (executionContext) {
        var formContext = executionContext.getFormContext();
        //New values
        var arrHideOptions = [
            { text: "Automotive Aftermarket", value: 610570001 },
            { text: "Consumer Electronics", value: 610570002 },
            { text: "Entertainment", value: 610570003 },
            { text: "Fashion", value: 610570004 },
            { text: "Forecasting for Equity", value: 610570005 },
            { text: "Supply Chain / Distribution", value: 610570006 },
            { text: "Insurance Services", value: 610570007 },
            { text: "Total Store Reporting", value: 610570008 },
            { text: "H&L - Deco/Reno", value: 610570009 },
            { text: "H&L - Furniture", value: 610570010 },
            { text: "H&L - Gardening", value: 610570011 },
            { text: "H&L - Houseware", value: 610570012 },
            { text: "H&L - Light and Building", value: 610570013 },
            { text: "H&L - Sanitary/Solar/Heating", value: 610570014 },
            { text: "H&L - Tools/Machines", value: 610570015 },
            { text: "IT", value: 610570016 },
            { text: "MDA", value: 610570017 },
            { text: "Office", value: 610570018 },
            { text: "Optics & Acoustics", value: 610570019 },
            { text: "Photo", value: 610570020 },
            { text: "SDA", value: 610570021 },
            { text: "Stationery", value: 610570022 },
            { text: "Telecom", value: 610570023 },
            { text: "Toys and Games", value: 610570024 }
        ];
        //Old values
        var arrOldValues = [
            { text: "All Categories / Total FMCG", value: 100000000 },
            { text: "Alcohol", value: 100000001 },
            { text: "Beauty and Personal Care", value: 100000002 },
            { text: "Beverages", value: 100000003 },
            { text: "Dairy", value: 100000004 },
            { text: "Food", value: 100000005 },
            { text: "Health Care", value: 100000006 },
            { text: "Household Care", value: 100000007 },
            { text: "Pet Care", value: 100000008 },
            { text: "Tobacco", value: 100000009 },
            { text: "Other", value: 100000010 }
        ];
        var TechDurable = formContext.getAttribute("niq_istechdurables")?.getValue();
        var NiqSolution = formContext.getAttribute("niq_niqnghsolution")?.getValue();
        //arrRecordType contains "Analytics, Client Response & NielsenIQ Global Helpline."
        var arrRecordType = [100000000, 100000001, 100000003];
        var recordType = formContext.getAttribute("niq_recordtype")?.getValue();
        var industryField = formContext.getControl("niq_industry");
        if (NiqSolution !== null) {
            var NiqSolutionGuid = NiqSolution[0].id.replace("{", "").replace("}", "");
            //Check if record type is in arrRecordType
            var checkRecordType = arrRecordType.includes(recordType);
            if (TechDurable == true && (NiqSolutionGuid.toLowerCase() == "e60062d2-5a05-f011-bae3-6045bda1abcd" || NiqSolutionGuid.toLowerCase() == "9258f5d8-5a05-f011-bae3-6045bda1abcd") && checkRecordType == true) {
                industryField.clearOptions();
                arrHideOptions.forEach(option => {
                    industryField.addOption({ value: option.value, text: option.text }); // Add using text & value
                });
            }
            else {
                industryField.clearOptions();
                arrOldValues.forEach(option => {
                    industryField.addOption({ value: option.value, text: option.text }); // Add using text & value
                });
            }
            if (TechDurable == false) {
                formContext.getAttribute("niq_industry").setValue(null);
            }
        }
    },
    //function to filter values in "niq_inprogresssubstatus" and "niq_substatus" field(DYNCRM-24597)
    FilterSubStatusBasedOnBpf: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var NiqSolutionGuid = null;
        var checkRecordType = null;
        var NiqSolution = formContext.getAttribute("niq_niqnghsolution")?.getValue();
        var TechDurable = formContext.getAttribute("niq_istechdurables")?.getValue();
        var statusCode = formContext.getAttribute("statuscode")?.getValue();
        var arrHideOptions = [{ text: "Working - On Time", value: 100000024 },
        { text: "Working - Delayed", value: 100000025 },
        { text: "Hold - External", value: 100000003 },
        { text: "Hold - Internal", value: 100000001 },
        { text: "On Hold - Software Issue", value: 100000026 }
        ];
        //arrRecordType contains "Analytics, Client Response & NielsenIQ Global Helpline."
        var arrRecordType = [100000000, 100000001, 100000003];
        //Below array store "gfknewron' or 'StarTrack" NIQ Solution records guid
        var arrNiqSolution = ["e60062d2-5a05-f011-bae3-6045bda1abcd", "9258f5d8-5a05-f011-bae3-6045bda1abcd"];
        var recordType = formContext.getAttribute("niq_recordtype")?.getValue();
        var BpfSubStatus = formContext.getControl("niq_inprogresssubstatus");
        var FormSubstatus = formContext.getControl("niq_substatus");
        if (NiqSolution != null) {
            //Check if record type is in arrRecordType
            checkRecordType = arrRecordType.includes(recordType);
            //If Bpf Stage is in Assinged
            if (statusCode == 100000001 && NiqSolution != null && TechDurable) {
                NiqSolutionGuid = NiqSolution[0].id.replace("{", "").replace("}", "");
                //NIQ Solution equals "gfknewron' or 'StarTrack"
                if (arrNiqSolution.includes(NiqSolutionGuid.toLowerCase()) && checkRecordType) {
                    BpfSubStatus.clearOptions();
                    arrHideOptions.forEach(option => BpfSubStatus.addOption(option));
                }
            }
            //If Bpf stage is in Inprogress
            else if (statusCode == 1 && NiqSolution !== null && TechDurable) {
                NiqSolutionGuid = NiqSolution[0].id.replace("{", "").replace("}", "");
                //NIQ Solution equals "gfknewron' or 'StarTrack"
                if (arrNiqSolution.includes(NiqSolutionGuid.toLowerCase()) && checkRecordType) {
                    FormSubstatus.clearOptions();
                    arrHideOptions.forEach(option => FormSubstatus.addOption(option));
                }
            }
        }
    },

    //DYNCRM-21831
    HideShowJiraDetailsQuickView: function (executionContext) {
        var formContext = executionContext.getFormContext();
        recordTypeText = CommonForm.Events.GetFieldText(formContext, "niq_recordtype",);
        if (recordTypeText == "NielsenIQ Global Helpline") {
            var isTechDurablesAttribute = formContext.getAttribute("niq_istechdurables");
            var jiraDetailsSectionWithQuickViewControl = formContext.ui.tabs.get("tab_details").sections.get("Jira Details");
            var jiraDetailsSectionWithoutQuickViewControl = formContext.ui.tabs.get("tab_details").sections.get("JiraDetailsWithoutQuickView");
            if (isTechDurablesAttribute && jiraDetailsSectionWithQuickViewControl && jiraDetailsSectionWithoutQuickViewControl) {
                var isTechDurablesValue = isTechDurablesAttribute.getValue();
                if (isTechDurablesValue) {
                    jiraDetailsSectionWithoutQuickViewControl.setVisible(true);
                    jiraDetailsSectionWithQuickViewControl.setVisible(false);
                }
                else {
                    jiraDetailsSectionWithoutQuickViewControl.setVisible(false);
                    jiraDetailsSectionWithQuickViewControl.setVisible(true);
                }
            }
        }
    },

    updatePEDInclusionDate: function (executionContext) {
        var formContext = executionContext.getFormContext();
        var plannedEndDate = formContext.getAttribute('niq_plannedenddate')?.getValue();
        var pedInclusiondate = formContext.getAttribute('niq_pedinclusiondate')?.getValue();
        if (plannedEndDate && !pedInclusiondate) {
            formContext.getAttribute("niq_pedinclusiondate").setValue(new Date());
        }
    },


    CustomDeleteInvoker: function (gridControl, records, formContext) {
        if (records && records.length > 0) {
            for (var i = 0; i < records.length; i++) {
                var record = records[i];

                // --- Document details ---
                var docName = record.Name;

                // --- Request details (lookup only) ---
                var requestId = formContext.data.entity.getId().replace("{", "").replace("}", "");

                // --- User details (who clicked delete) ---
                var userId = Xrm.Utility.getGlobalContext().userSettings.userId.replace("{", "").replace("}", "");
                var userName = Xrm.Utility.getGlobalContext().userSettings.userName;

                // --- Action type & timestamp ---
                var actionType = 610570000; // Choice value for "Delete"
                var timestamp = new Date();

                // --- Build Audit Log record ---
                var auditLog = {
                    "niq_filename": docName,
                    "niq_request@odata.bind": "/incidents(" + requestId + ")", // lookup to Request
                    "niq_user@odata.bind": "/systemusers(" + userName + ")",     // lookup to User
                    "niq_actiontype": actionType,
                    "niq_performon": timestamp
                };

                // --- Save Audit Log record ---
                Xrm.WebApi.createRecord("niq_documentauditlogs", auditLog).then(
                    function success(result) {
                        console.log("Audit Log created with ID: " + result.id);
                        var subgrid = formContext.getControl("Document_Audit_Log");
                        if (subgrid) subgrid.refresh();
                    },
                    function (error) {
                        console.error("Error creating Audit Log: " + error.message);
                    }
                );
            }
        }
    },

    //Service-Ops #31227_B
    otherTabOnChange: function (executionContext) {
        var formContext = executionContext.getFormContext();

        var parentCase = formContext.getAttribute("parentcaseid");
        var ChildCase = formContext.getControl("ChildCasesGrid");
        var ChildSubCase = formContext.getControl("ChildSubCasesGrid");

        if (!ChildCase || !ChildSubCase)
            return;

        if (parentCase && parentCase.getValue() != null) {
            ChildCase.setVisible(false);
            ChildSubCase.setVisible(true);
        } else {
            ChildCase.setVisible(true);
            ChildSubCase.setVisible(false);
        }
    },
    //Service-Ops #31227_E

    //US - 30151 - Prevent CR ticket closure
    blockStageNavigationOnChildOpen: async function (executionContext) {
        var formContext = executionContext.getFormContext();
        var recordType = formContext.getAttribute("niq_recordtype")?.getValue();
        var ClientResponseId = formContext.data.entity.getId().slice(1, -1); // Remove curly braces
        var activeStage = formContext.data.process.getActiveStage();
        var eventArgs = executionContext.getEventArgs();
        var status_ = [100000009, 100000012, 100000013, 100000014, 100000016, 100000018];
        var IONrecordTypes = [100000014, 100000005, 100000006, 100000007, 100000008, 100000009, 100000011, 100000010, 100000013];
        var status = "";
        var recordType_ = "";
        var _error = false;
        try {
            // Check Record Type =  Client Response
            if (recordType == 100000001 && (activeStage && activeStage.getName().toLowerCase() === "in progress")) {
                var req = new XMLHttpRequest();
                req.open("GET", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/incidents?$filter=_parentcaseid_value eq " + ClientResponseId, false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Prefer", "odata.include-annotations=*");
                req.onreadystatechange = function () {
                    if (this.readyState === 4) {
                        req.onreadystatechange = null;
                        if (this.status === 200) {
                            var results = JSON.parse(this.response);
                            console.log(results);
                            if (results.value.length > 0) {
                                for (var i = 0; i < results.value.length; i++) {
                                    var result = results.value[i];
                                    status = result["statuscode"];
                                    recordType_ = result["niq_recordtype"];
                                    // Check status != closed and record type in IONrecordTypes
                                    if (status_.includes(status) && IONrecordTypes.includes(recordType_)) {
                                        _error = true;
                                    }
                                }
                            }
                        } else {
                            console.log(this.responseText);
                        }
                    }
                };
                req.send();
                if (_error) {
                    if (eventArgs && typeof eventArgs.getDirection === "function") {
                        var direction = eventArgs.getDirection();
                        // prevent stage move on 'Next' navigation and show alert
                        if (direction && direction.toLowerCase() === "next") {
                            eventArgs.preventDefault();
                            var alertStrings = {
                                confirmButtonLabel: "OK",
                                text: "This request has open dependencies (IONs/Child IONs). All linked items must be closed.",
                                title: "Dependencies found!"
                            };
                            var alertOptions = { height: 120, width: 260 };
                            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                        }
                    }
                }
            }
        } catch (error) { console.log(error); }
    }


}
var getFormType = function (_formContext) {
    "use strict";
    const FORMTYPE = {
        Analytics: "Analytics",
        "Client Response": "Client Response",
        "NielsenIQ Global Helpline": "NGH",
    };

    var form = _formContext.ui.formSelector.getCurrentItem();
    var formName = form._label;
    return FORMTYPE[formName];
};


var getSLARegionBasedOnCountry = function (country) {
    "use strict";

    const SLAPERCOUNTRY = {
        "Sri Lanka": "India/West Asia",
        Americas: "Americas",
        Australia: "India/West Asia",
        Bangladesh: "India/West Asia",
        India: "India/West Asia",
        Indonesia: "India/West Asia",
        Kazakhstan: "India/West Asia",
        Malaysia: "India/West Asia",
        Myanmar: "India/West Asia",
        Nepal: "India/West Asia",
        Pakistan: "India/West Asia",
        Thailand: "India/West Asia",
        "United Arab Emirates": "India/West Asia",
        Vietnam: "India/West Asia",
        "Hong Kong": "Pacific",
        China: "Pacific",
        Taiwan: "Pacific",
        Singapore: "Pacific",
        Philippines: "Pacific",
        "New Zealand": "Pacific",
        Japan: "Pacific",
        Korea: "Pacific",
        Tunisia: "Europe",
        Greece: "Europe",
        Hungary: "Europe",
        Ireland: "Europe",
        Israel: "Europe",
        Italy: "Europe",
        "Ivory Coast": "Europe",
        Jordan: "Europe",
        Kenya: "Europe",
        Latvia: "Europe",
        Lebanon: "Europe",
        Lithuania: "Europe",
        Maghreb: "Europe",
        Morocco: "Europe",
        Turkey: "Europe",
        Uganda: "Europe",
        Ukraine: "Europe",
        "United Kingdom": "Europe",
        Sweden: "Europe",
        Switzerland: "Europe",
        Tanzania: "Europe",
        Poland: "Europe",
        Portugal: "Europe",
        Romania: "Europe",
        Russia: "Europe",
        "Saudi Arabia": "Europe",
        Serbia: "Europe",
        Slovakia: "Europe",
        Slovenia: "Europe",
        "South Africa": "Europe",
        Spain: "Europe",
        Nigeria: "Europe",
        Norway: "Europe",
        Netherlands: "Europe",
        Algeria: "Europe",
        Austria: "Europe",
        Belarus: "Europe",
        Belgium: "Europe",
        Bulgaria: "Europe",
        Cameroon: "Europe",
        Croatia: "Europe",
        Cyprus: "Europe",
        "Czech Republic": "Europe",
        Brazil: "Americas",
        Denmark: "Europe",
        Egypt: "Europe",
        Estonia: "Europe",
        Finland: "Europe",
        France: "Europe",
        Germany: "Europe",
        Ghana: "Europe",
        "Dominican Republic": "Americas",
        "Global Above Market": "Americas",
        Ecuador: "Americas",
        "Costa Rica": "Americas",
        Colombia: "Americas",
        Canada: "Americas",
        Chile: "Americas",
        "El Salvador": "Americas",
        Guatemala: "Americas",
        Honduras: "Americas",
        "United States": "Americas",
        Uruguay: "Americas",
        Venezuela: "Americas",
        Argentina: "Americas",
        "Puerto Rico": "Americas",
        Nicaragua: "Americas",
        Panama: "Americas",
        Others: "Americas",
        Peru: "Americas",
        Mexico: "Americas",
    };

    return SLAPERCOUNTRY[country];
};

var SetSLAForAccountMarket = function (context) {
    "use strict";

    var _formContext = context.getFormContext();
    if (_formContext.getAttribute("customerid").getValue() !== null) {
        var accountId = _formContext.getAttribute("customerid").getValue()[0].id;

        getAccountMarket(_formContext, accountId)
            .then(function (value) {
                var regionName = getSLARegionBasedOnCountry(value.name);

                var formType = getFormType(_formContext);
                getSLARecord(_formContext, regionName, formType)
                    .then(function (value) {
                        if (value !== null) {
                            var slaLookup = [{
                                entityType: "sla",
                                id: "{" + value.id + "}",
                                name: value.name,
                            },];
                            _formContext.getAttribute("slaid").setValue(slaLookup);
                        }
                    })
                    .catch((error) => console.log(error));
            })
            .catch((error) => console.log(error));
    }
};

var returnAccountSla = function (context) {
    "use strict";

    var _formContext = context.getFormContext();

    if (_formContext.getAttribute("customerid").getValue() !== null) {
        var accountId = _formContext.getAttribute("customerid").getValue()[0].id;

        getAccountMarket(_formContext, accountId)
            .then(function (value) {
                var regionName = getSLARegionBasedOnCountry(value.name);

                var formType = getFormType(_formContext);
                getSLARecord(_formContext, regionName, formType)
                    .then(function (value) {
                        if (value !== null) {
                            var slaLookup = [{
                                entityType: "sla",
                                id: "{" + value.id + "}",
                                name: value.name,
                            },];
                            //  _formContext.getAttribute("slaid").setValue(slaLookup);
                            return slaLookup;
                        }
                    })
                    .catch((error) => console.log(error));
            })
            .catch((error) => console.log(error));
    }
};
var getAccountMarket = function (_formContext, accountId) {
    "use strict";
    return new Promise((Resolve, Reject) => {
        var uri =
            _formContext.context.getClientUrl() +
            "/api/data/v9.0/accounts?$filter=accountid eq '" +
            accountId +
            "'&$select=_niq_serviceroutingmarketid_value";
        var request = new XMLHttpRequest();
        request.open("GET", encodeURI(uri), false);
        request.setRequestHeader("OData-MaxVersion", "4.0");
        request.setRequestHeader("OData-Version", "4.0");
        request.setRequestHeader("Accept", "application/json");
        request.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        request.setRequestHeader(
            "Prefer",
            "odata.include-annotations=OData.Community.Display.V1.FormattedValue",
        );
        request.onreadystatechange = function () {
            if (this.readyState === 4) {
                request.onreadystatechange = null;
                if (this.status === 200) {
                    var data = JSON.parse(this.response);
                    if (data["value"].length > 0) {
                        Resolve({
                            name: data["value"][0][
                                "_niq_serviceroutingmarketid_value@OData.Community.Display.V1.FormattedValue"
                            ] === undefined ||
                                data["value"][0][
                                "_niq_serviceroutingmarketid_value@OData.Community.Display.V1.FormattedValue"
                                ] === "" ?
                                "Americas" :
                                data["value"][0][
                                "_niq_serviceroutingmarketid_value@OData.Community.Display.V1.FormattedValue"
                                ],
                        });
                    } else {
                        Resolve({
                            id: null,
                        });
                    }
                } else {
                    Reject(this.response);
                }
            }
        };
        request.send();
    });
};

var getSLARecord = function (_formContext, regionName, formType) {
    "use strict";
    return new Promise((Resolve, Reject) => {
        var uri =
            _formContext.context.getClientUrl() +
            "/api/data/v9.0/slas?$filter=statecode eq 1 and contains(name,'" +
            regionName +
            "') and contains(name,'" +
            formType +
            "')&$select=slaid,name";
        var request = new XMLHttpRequest();
        request.open("GET", encodeURI(uri), false);
        request.setRequestHeader("OData-MaxVersion", "4.0");
        request.setRequestHeader("OData-Version", "4.0");
        request.setRequestHeader("Accept", "application/json");
        request.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        request.onreadystatechange = function () {
            if (this.readyState === 4) {
                request.onreadystatechange = null;
                if (this.status === 200) {
                    var data = JSON.parse(this.response);
                    if (data["value"].length > 0) {
                        Resolve({
                            id: data["value"][0]["slaid"],
                            name: data["value"][0]["name"],
                        });
                    } else {
                        Resolve({
                            id: null,
                        });
                    }
                } else {
                    Reject(this.response);
                }
            }
        };
        request.send();
    });
};
var enableRoutingAfterClone = function (executionContext) {
    var formContext = executionContext.getFormContext();

    // MUST for onLoad / Create scenarios
    var recordId = formContext.data.entity.getId();
    if (!recordId) return;

    recordId = recordId.replace("{", "").replace("}", "");

    Xrm.WebApi.retrieveRecord("incident", recordId, "?$select=niq_cloned")
        .then(function (result) {

            // Treat true as cloned
            if (result.niq_cloned === true) {

                var routingFields = [
                    "niq_niqghsolution",
                    "niq_nsstopic",
                    "niq_nsssubtopic",
                    "niq_country"
                ];

                for (var i = 0; i < routingFields.length; i++) {
                    var attr = formContext.getAttribute(routingFields[i]);

                    // getIsDirty() will be false onLoad 
                    if (attr && attr.getIsDirty()) {

                        Xrm.WebApi.updateRecord("incident", recordId, {
                            niq_cloned: false
                        });
                    }
                }
            }
        })
        .catch(function (error) {
            console.error("Clone routing JS error:", error.message);
        });
};