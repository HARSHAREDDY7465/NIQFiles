if (typeof (RequestRibbon) === "undefined") {
    RequestRibbon = {
        __namespace: true
    };
}
var opsRecordTypes = "Client Inquiry Buy - Data Validity,Client Inquiry Buy - Information,Client Inquiry Global,Client Order Buy,Client Order Global,RDDS Support,GO Enabling,Reporting Solution,Analytics Support";
var hnSRecordTypes = "H&S Requests";
var showopsbuttonRoles = ['NIQ Global Helpline Agent', 'NIQ Global Helpline Manager', 'NIQ Analytics Agent', 'NIQ Client Response Agent', 'NIQ Client Response Manager', 'NIQ Analytics Manager',
    "NIQ Ops Solution Provider", "System Administrator", "NIQ Ops Submitter", "NIQ Customer Service"];
var serviceReqCreateRolesWithKnowledgeRoles = "System Administrator,NIQ Global Helpline Manager,NIQ Ops Solution Provider,NIQ Analytics Agent,NIQ Analytics Manager,NIQ Global Helpline Agent,NIQ Ops Submitter,"
    + "NIQ Knowledge Contributor,NIQ Knowledge Publisher,NIQ Delegate Agent,NIQ Delegate Manager,NIQ Delegate Submitter,NIQ Client Response Agent,NIQ Client Response Manager,NIQ Customer Service";
var csRoles = ['NIQ Analytics Agent','NIQ Analytics Manager','NIQ Client Response Agent','NIQ Client Response Manager','NIQ Global Helpline Agent','NIQ Global Helpline Manager','NIQ Customer Service','System Administrator'];
var analyticsFormId = "e3fb2a7e-9e95-4ebb-b7a2-15ee1ee2fe8b";
var clientResponseFormId = "85993270-4594-4467-8709-5e5536a093f5";
var delegateFormId = "1a049993-4c66-456a-9284-5d8db9efe6bf";
var NGHFormId = "a81bb3b2-5ed2-4f16-9acf-e1fc7579b95c";
var NGHAMFormId = "b05c1e9c-94d0-46c1-8968-df49b8f33ec7";
var clientInquiryBuyDataValidityFormId = "d8659076-e1dc-47ed-91d5-5df15b0b0ce6";
var clientInquiryBuyInformationFormId = "ba491c58-73ca-478d-ab3a-FF19bacdc230";
var clientInquiryGlobalFormId = "43468296-375f-4200-b08b-94c6b27714ff";
var clientOrderBuyFormId = "182cd6d6-5b8b-41a6-aab3-b341776f01f8";
var clientOrderGlobalFormId = "5866c70e-8582-4adf-9302-0d894d87bdc6";
var RDDSSupportFormId = "c50f0d0e-dcbb-4ee5-9abc-fdb766906632";
var goEnablingFormId = "d85e4dfb-6926-49ed-B2ce-dccb8133b0a6";
var HnSRequestsFormId = "b715b3bf-3ca7-4de1-9cbc-bbf84cf858b4";
var reportingSolutionFormId = "d912da3d-11ce-475e-82f5-398478756665"
var anlyticsSupportFormId = "2de2ffbe-96d8-ef11-a72f-7c1e5273f840"
RequestRibbon.Events = {
    ShowHideBulkDelgateRouteButton: function (primaryctrl) {
        "use strict";
        var query = primaryctrl.getViewSelector().getCurrentView().name;
        if (query == 'Delegate Routing') {

            if (CommonForm.Events.CheckIfLoggedInUserRole("System Administrator") || CommonForm.Events.CheckIfLoggedInUserRole("NIQ Delegate Submitter")) {
                return true;
            }
            else return false;
        }
        else return false;
    },

    // function to show or hide close button 
    ShowHideCloseButton: function (primaryctrl) {
        "use strict";

        var recordType = CommonForm.Events.GetFieldText(primaryctrl, "niq_recordtype");
        if (recordType !== null && recordType !== "Analytics" && opsRecordTypes.indexOf(recordType) !== -1) {
            return false;
        }
        else {
            //check if status is resolved & logged in user role is system administrator
            if (CommonForm.Events.CheckIfLoggedInUserRole("System Administrator") || CommonForm.Events.CheckIfLoggedInUserRole("NIQ Business Admin")) return true;
            else return false;
        }
    },

     //Service-Ops #27044_B
    ShowHideChildIONButton: function (primaryctrl) {
    "use strict";
        var formContext = primaryctrl;
        var formType = formContext.ui.getFormType();

        // Hide button during create mode (formType === 1)
        if (formType === 1) {
            return false;
        }
        //If Child ION  is 4 then hide the button
        var noofChildION = CommonForm.Events.GetFieldValue(primaryctrl, "niq_noofchildion");
        if (noofChildION == 4) {
            return false;
        }
        
        var parentRequest = CommonForm.Events.GetFieldValue(primaryctrl, "parentcaseid");
        var subParentRequest = CommonForm.Events.GetFieldValue(primaryctrl, "niq_subparentrequest");
        var parentRequestRecordTypeValue = CommonForm.Events.GetFieldValue(primaryctrl, "niq_recordtype");
        var disallowedValues = [100000000, 100000001, 100000004]; // OptionSet values for Analytics, Client Response, NGH Account Management

        // Show the button only if the record type is one of the allowed values
        if ((parentRequest != null || subParentRequest != null) && !disallowedValues.includes(parentRequestRecordTypeValue)) {
            return true; // Show button
        }

        return false; // Hide button if none of the conditions match
    },
    //Service-Ops #27044_E


    //Service-Ops #27045_B
    BulkCreateChildION: async function (primaryctrl) {
        var requestId = primaryctrl.data.entity.getId();
        requestId = requestId.replace('{', '').replace('}', '');
        // Fetch environment variable value
        var result = await Xrm.WebApi.retrieveMultipleRecords("environmentvariabledefinition", "?$filter=schemaname eq 'niq_BulkChildIONCreationCanvasAppID'");

        if (result.entities.length > 0) {
            var appId = result.entities[0].defaultvalue;

            var canvasAppUrl = "https://apps.powerapps.com/play/" + appId + "?requestId=" + encodeURIComponent(requestId);

            // Open the Canvas app in a popup window
            var windowFeatures = "width=1100,height=900,resizable=yes,scrollbars=yes,status=yes";
            var popupWindow = window.open(canvasAppUrl, "CanvasAppPopup", windowFeatures);

            if (popupWindow) {
                popupWindow.focus();
            } else {
                alert("Popup blocked. Please allow popups for this site.");
            }
        } else {
            alert("Canvas App ID environment variable not found.");
        }
    },
    //Service-Ops #27045_E
    
    Showhidecreatenewbuttonforniqcustomerservice: function (primaryctrl) {
        "use strict";
        var recordtype = CommonForm.Events.GetFieldValue(primaryctrl, "niq_recordtype");
        if ((CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Customer Service")) && (recordtype === 100000000 || recordtype === 100000001)) {
            return true;
        }
        else {
            if (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Customer Service")) {
                return false;
            }
        }
    },
    ShowHideOpsCreateNewbtn: function (primaryctrl) {
        "use strict";
        if (CommonForm.Events.CheckIfLoggedInUserRoles(showopsbuttonRoles)) {

            return true;
        }
        else return false;
    },
    ShowHideHomeAddNewHnsbtn: function (primaryctrl) {
        "use strict";
        var query = primaryctrl.getViewSelector().getCurrentView().name;
        if (query == 'Help & Support Request') {

            return true;
        }
        else return false;
    },
    ShowHideSubGridAddNewHnS: function (primaryctrl) {
        "use strict";

        var recordType = CommonForm.Events.GetFieldText(primaryctrl, "niq_recordtype");
        if (recordType !== null && hnSRecordTypes.indexOf(recordType) !== -1) {
            return true;
        }
        else {
            //check if status is resolved & logged in user role is system administrator
            return false;
        }
    },
    ShowHideSubGridAddNew: function (primaryctrl) {
        "use strict";

        var recordType = CommonForm.Events.GetFieldText(primaryctrl, "niq_recordtype");
        if (recordType !== null && hnSRecordTypes.indexOf(recordType) !== -1) {
            return false;
        }
        else {
            //check if status is resolved & logged in user role is system administrator
            return true;
        }
    },
    ShowHideCancelButton: function (primaryctrl) {
        "use strict";

        var recordType = CommonForm.Events.GetFieldText(primaryctrl, "niq_recordtype");
        var ticketnumber = CommonForm.Events.GetFieldValue(primaryctrl, "ticketnumber");
        var statusofform = CommonForm.Events.GetFieldValue(primaryctrl, "statuscode");
        if(statusofform == 6)
        {
            return false;
        }
        else
        {
            if (recordType !== null && recordType !== "Analytics" && opsRecordTypes.indexOf(recordType) !== -1) {
                return false;
            }
            else {
                //check if status is resolved & logged in user role is system administrator
                if (ticketnumber === null) return false;
                if (opsRecordTypes.indexOf(recordType) == -1 && recordType !== "Analytics" && statusofform == 5) return false;
                else return true;
                //return true;
            }
        }
    },
    Isformdirty: function (primaryControl) {
        var attributes = primaryControl.getAttribute();
        for (let index = 0; index < attributes.length; index++) {
            if (attributes[index].getIsDirty()) {
                return true;
            };

        }
    },
    ShowHideRejectButton: function (primaryctrl) {
        "use strict";
        if (this.Isformdirty(primaryctrl)) {
            return false;
        }
        else {
            var recordType = CommonForm.Events.GetFieldText(primaryctrl, "niq_recordtype");
            var ticketnumber = CommonForm.Events.GetFieldValue(primaryctrl, "ticketnumber");
            var statusofform = CommonForm.Events.GetFieldValue(primaryctrl, "statuscode");
            if(statusofform == 6)
            {
                return false;
            }
            else
            {
                if (recordType !== null) {
                    if (recordType !== null && recordType !== "Analytics" && opsRecordTypes.indexOf(recordType) !== -1) return false;
                    if (opsRecordTypes.indexOf(recordType) == -1 && recordType !== "Analytics" && statusofform == 5) return false;
                    if (recordType == "H&S Requests") return false;
                    if (primaryctrl.ui.getFormType() !== 1) {
                        if ((CommonForm.Events.CheckIfLoggedInUserRole("System Administrator"))) {
                            return true;
                        }
                        if (recordType == "Delegate") {
                            if (CommonForm.Events.CheckIfLoggedInUserRole("NIQ Delegate Agent") || CommonForm.Events.CheckIfLoggedInUserRole("NIQ Delegate Manager")) {
                                return true;
                            }
                            else
                                return false;
                        }
                        if (recordType == "NGH Account Management") {
                            if (CommonForm.Events.CheckIfLoggedInUserRole("NIQ Global Helpline Agent") || CommonForm.Events.CheckIfLoggedInUserRole("NIQ Global Helpline Manager")) {
                                return true;
                            }
                            else
                                return false;
                        }
                        if (recordType == "Analytics", "Client Response", "NielsenIQ Global Helpline") {
                            if (CommonForm.Events.CheckIfLoggedInUserRole("NIQ Delegate Agent") || CommonForm.Events.CheckIfLoggedInUserRole("NIQ Delegate Manager")) {
                                return false;
                            }
                            else
                                return true;
                        }
                        else {
                            //check if status is resolved & logged in user role is system administrator
                            if (ticketnumber == null) return false;

                            else return true;
                            //return true;
                        }
                    }
                    else return false;
                }
            }
        }
    },
    ShowCustomRouteButton: function (primaryctrl) {
        "use strict";
        // check for case status and multiclient  not checked 
        var casestate = CommonForm.Events.GetFieldValue(primaryctrl, "statecode");
        if (casestate === 0 || casestate === 1) return true;
        else return false;
    },
    ShowCustomRouteButton: function (primaryctrl) {
        "use strict";
        // check for case status and multiclient  not checked 
        var casestatus = CommonForm.Events.GetFieldValue(primaryctrl, "statuscode");
        var ismulticlient = CommonForm.Events.GetFieldValue(primaryctrl, "niq_multiclient");
        var recordtype = CommonForm.Events.GetFieldValue(primaryctrl, "niq_recordtype");
        //check if status is not resolved and not disabled form  - CR, Analytics, NGH 
        if ((recordtype === 100000000 || recordtype === 100000001 || recordtype === 100000003) && casestatus !== 5 && !isdisabledform && (ismulticlient !== true)) return true;
        else return false;
    },
    PerformRecordRouting: function (primaryctrl) {
        "use strict";
        var formContext = primaryctrl;
        var parameters = {};
        var target = {};
        target.incidentid = formContext.data.entity.getId();
        target["@odata.type"] = "Microsoft.Dynamics.CRM.incident";
        parameters.Target = target;
        var applyRoutingRuleRequest = {
            Target: parameters.Target,
            getMetadata: function () {
                return {
                    boundParameter: null,
                    parameterTypes: {
                        "Target": {
                            "typeName": "mscrm.crmbaseentity",
                            "structuralProperty": 5
                        }
                    },
                    operationType: 0,
                    operationName: "ApplyRoutingRule"
                };
            }
        };
        var id = formContext.data.entity.getId().replace("{", "").replace("}", "");
        var data = {
            "niq_routingstatusvalue": 100000001,
            "niq_refreshskilldata": "skill-" + crypto.randomUUID()
        };
        Xrm.WebApi.updateRecord("incident", id, data).then(

            function success(result) {
                // apply unified routing after refreshing the skills 
                Xrm.WebApi.online.execute(applyRoutingRuleRequest).then(

                    function success(result) {
                        if (result.ok) {
                            var alertStrings = {
                                confirmButtonLabel: "Yes",
                                text: "Routing has been started",
                                title: "Routing Started"
                            };
                            var alertOptions = {
                                height: 120,
                                width: 260
                            };
                            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                            //Success - No Return Data - Do Something
                            formContext.data.refresh(true);
                        }
                    });
            });
    },
    PerformRecordRoutingEnhancements: function (executionContext) {
        "use strict";

        var formContext = executionContext;
        var formParameters = {};
        var targetData = new Array();
        targetData[0] = new Object();
        targetData[0].id = formContext.data.entity.getEntityReference().id.replace("{", "").replace("}", "");
        targetData[0].name = formContext.data.entity.getEntityReference().name;
        targetData[0].entityType = "incident";
        formParameters["niq_incident"] = targetData;
        var entityFormOptions = {};
        entityFormOptions["entityName"] = "niq_routinghistory";
        entityFormOptions["useQuickCreateForm"] = true;
        if (CommonForm.Events.CheckValueExists(formContext, "niq_skiproutingfore2crecord")) {

            formContext.getAttribute("niq_skiproutingfore2crecord").setValue(false);
            formContext.data.save();

        }

        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(function (success) {

            conslole.log("Success");

        },

            function () {

                console.log(error.message);

            }

        );

    },
    PerformCancelRequest: async function (primaryctrl) {

        "use strict";
        var formContext = primaryctrl;
        var recid = formContext.data.entity.getId();
        formContext.data.entity.save();
        var dirtyAccountCheck = formContext.getAttribute("customerid").getIsDirty();
        if ((dirtyAccountCheck == true)) {
            return;
        }
        else {
            var message = "Do you want to Cancel this request";
            var confirmStrings = { text: "On canceling this request, a closure email will not be sent to the contact on the request.", title: "Do you want to Cancel this request" };
            Xrm.Navigation.openConfirmDialog(confirmStrings, null).then(
                async function (success) {
                    if (success.confirmed) {
                        var attributes = formContext.data.entity.attributes.get();
                        for (var i in attributes) {
                            attributes[i].setRequiredLevel("none");
                            var priorityValue = formContext.getAttribute("prioritycode").getValue();
                            var recordType = formContext.getAttribute("niq_recordtype").getValue();

                            if (recordType === 100000001 && priorityValue === 100000013) {
                                var NSSTopicLookUp = formContext.getAttribute("niq_nsstopic")?.getValue();
                                var NSSTopic = NSSTopicLookUp ? NSSTopicLookUp[0].name : "";
                                if (["Data Inquiry", "Dataset Changes", "New dataset set-up"].includes(NSSTopic)) {
                                    formContext.getAttribute("prioritycode").setValue(100000012);
                                    formContext.data.entity.save();
                                }
                            }
                        }
                        Xrm.Utility.showProgressIndicator("Cancelling request, please wait...");
                        RequestRibbon.Events.moveAdvanceBPF(formContext, recid);
                        formContext.data.entity.save();
                        await new Promise(resolve => setTimeout(resolve, 3000));
                        Xrm.WebApi.updateRecord("incident", recid, {
                            statuscode:6,
                            statecode:2,
                            niq_substatus:100000006

                        }).then(
                            function success(result) {
                                formContext.data.refresh(true);
                                Xrm.Utility.closeProgressIndicator();
                            });
                    
                    }
                    else
                    {
                        console.log("Dialog closed using Cancel button or X.");
                    }
                });
                
        }
        
    },
    // change the status of the request to closed - Resolved
    PerformCloseRequest: function (primaryctrl) {
        "use strict";
        var formContext = primaryctrl;
        var recid = formContext.data.entity.getId();
        var substatus = CommonForm.Events.GetFieldValue(primaryctrl, "niq_substatus");
        if (substatus !== 100000006) substatus = null;
        // change status to closed
        this.setStatusStatusReason(formContext, "incident", recid, 2, 6, substatus);
    },
    CalculateCycleTime: function (formContext) {

        "use strict";
        //formContext = executionContext.getFormContext();
        var closeddon = CommonForm.Events.GetFieldValue(formContext, "niq_closeddate");
        if (formContext.ui.getFormType() !== 1 && closeddon !== null) {
            var createdon = CommonForm.Events.GetFieldValue(formContext, "createdon");
            //Closed Date/Time
            var closeddon = CommonForm.Events.GetFieldValue(formContext, "niq_closeddate");
            var createdontime = createdon.getTime();
            var today = new Date();
            var cycledays = 0;
            var tothours = 0.0;
            var startDateTime = createdon;
            var endDateTime = today;
            var nextday = new Date();
            nextday = createdon;
            if ((startDateTime.getDate() == endDateTime.getDate()) && (startDateTime.getMonth() == endDateTime.getMonth()) && (startDateTime.getYear() == endDateTime.getYear())) {
                tothours = endDateTime.getHours() - startDateTime.getHours();
                minutes = endDateTime.getMinutes() - startDateTime.getMinutes();
                tothours += minutes / 60;
            }
            else {
                tothours = startDateTime.getHours();
                tothours = 24.00 - tothours;
                var minutes = startDateTime.getMinutes();
                tothours -= minutes / 60;
                nextday.setDate(nextday.getDate() + 1);
                while (nextday.toLocaleDateString() < endDateTime.toLocaleDateString()) {
                    if (nextday.getDay() !== 0 && nextday.getDay() !== 6) {
                        if (nextday !== endDateTime) {
                            tothours = tothours + 24.00;
                            // add the number of days
                            cycledays++;
                        }
                    }
                    nextday.setDate(nextday.getDate() + 1);
                }
                // if we have on the same day 
                if ((nextday.getDate() === endDateTime.getDate()) && (nextday.getMonth() === endDateTime.getMonth()) && (nextday.getYear() === endDateTime.getYear())) {
                    cycledays++; // add days  and  calculate  remaining  hours on last day . 
                    //var startofday = new DateTime(endDateTime.Year, endDateTime.Month, endDateTime.Day, 0, 0, 0);
                    tothours += endDateTime.getHours();
                    var min = endDateTime.getMinutes();
                    tothours += min / 60.00;
                }
            }
            //tothours = tothours.toFixed(2);
            return tothours;
        }
    },
    showHideDefaultBehaviorBtn: function (primaryctrl) {
        "use strict";
        if ((CommonForm.Events.CheckIfLoggedInUserRole("System Administrator"))) {
            return false;
        }
        else {
            return false;
        }
    },

    canShowNewButton: function (formcontext) {

        var statusAttr = formContext.getAttribute("statuscode");
        var recordTypeAttr = formContext.getAttribute("niq_recordtype");

        if (!statusAttr || !recordTypeAttr) return true;

        var status = statusAttr.getValue();
        var recordType = recordTypeAttr.getValue();

        var isTargetRecordType = (
            recordType === 100000000 ||
            recordType === 100000001 ||
            recordType === 100000003
        );

        var isClosedOrResponded = (status === 5 || status === 6);

        // Hide "+ New" if both conditions are true ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬ ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ return false
        return !(isTargetRecordType && isClosedOrResponded);


    },
    ChangeBehavior: function (selectedItems) {

        try {
            let selectedItem = selectedItems[0];
            if (selectedItem) {
                recordId = selectedItem.Id;
                Xrm.WebApi.online.retrieveRecord("incident", recordId, "?$select=niq_recordtype").then(
                    function success(result) {
                        var recordType = result["niq_recordtype"];
                        if (recordType !== null && recordType !== undefined) {
                            var entityFormOptions = {};
                            entityFormOptions["entityName"] = "incident";
                            entityFormOptions["entityId"] = recordId;
                            switch (recordType) {
                                case 100000000:
                                    //analytics
                                    entityFormOptions["formId"] = analyticsFormId;
                                    CommonForm.Events.navigateToEditForm(entityFormOptions);
                                    break;
                                case 100000001:
                                    //client response
                                    entityFormOptions["formId"] = clientResponseFormId;
                                    CommonForm.Events.navigateToEditForm(entityFormOptions);
                                    break;
                                case 100000002:
                                    //delegate
                                    entityFormOptions["formId"] = delegateFormId;
                                    CommonForm.Events.navigateToEditForm(entityFormOptions);
                                    break;
                                case 100000003:
                                    //NGH
                                    entityFormOptions["formId"] = NGHFormId;
                                    CommonForm.Events.navigateToEditForm(entityFormOptions);
                                    break;
                                case 100000004:
                                    //NGH AM
                                    entityFormOptions["formId"] = NGHAMFormId;
                                    CommonForm.Events.navigateToEditForm(entityFormOptions);
                                    break;
                                case 100000005:
                                    //CIB - data validity
                                    entityFormOptions["formId"] = clientInquiryBuyDataValidityFormId;
                                    CommonForm.Events.navigateToEditForm(entityFormOptions);
                                    break;
                                case 100000006:
                                    //CIB - information
                                    entityFormOptions["formId"] = clientInquiryBuyInformationFormId;
                                    CommonForm.Events.navigateToEditForm(entityFormOptions);
                                    break;
                                case 100000007:
                                    //client inquiry global
                                    entityFormOptions["formId"] = clientInquiryGlobalFormId;
                                    CommonForm.Events.navigateToEditForm(entityFormOptions);
                                    break;
                                case 100000008:
                                    //COB
                                    entityFormOptions["formId"] = clientOrderBuyFormId;
                                    CommonForm.Events.navigateToEditForm(entityFormOptions);
                                    break;
                                case 100000009:
                                    //COG
                                    entityFormOptions["formId"] = clientOrderGlobalFormId;
                                    CommonForm.Events.navigateToEditForm(entityFormOptions);
                                    break;
                                case 100000010:
                                    //rdds support
                                    entityFormOptions["formId"] = RDDSSupportFormId;
                                    CommonForm.Events.navigateToEditForm(entityFormOptions);
                                    break;
                                case 100000011:
                                    //go enabling
                                    entityFormOptions["formId"] = goEnablingFormId;
                                    CommonForm.Events.navigateToEditForm(entityFormOptions);
                                    break;
                                case 100000012:
                                    //H&S
                                    entityFormOptions["formId"] = HnSRequestsFormId;
                                    CommonForm.Events.navigateToEditForm(entityFormOptions);
                                    break;
                                case 100000013:
                                    //reporting solution
                                    entityFormOptions["formId"] = reportingSolutionFormId;
                                    CommonForm.Events.navigateToEditForm(entityFormOptions);
                                    break;
                                case 100000014:
                                    //Analytics support
                                    entityFormOptions["formId"] = anlyticsSupportFormId;
                                    CommonForm.Events.navigateToEditForm(entityFormOptions);
                                    break;

                            }
                        }
                    },
                    function (error) {
                        console.log(error.message);
                        //handle error conditions
                    }
                );
            }
        }
        catch (error) {
            console.error(error);
        }
    },

    setStatusStatusReason: function (formContext, entityLogicalName, recordId, statecode, statuscode, substatusval) {
        "use strict";
        var id = recordId.replace("{", "").replace("}", "");
        var data = {
            "statecode": statecode,
            "statuscode": statuscode,
            "niq_substatus": substatusval
        };
        if (statuscode === 100000003) {
            data.niq_lastreopeneddate = new Date();
        }
        else { // update closed date as current date 
            data.niq_closeddate = new Date();
            var cycletimeInHours = this.CalculateCycleTime(formContext);
            data.niq_cycletimehours = cycletimeInHours;
        }
        Xrm.WebApi.updateRecord(entityLogicalName, id, data).then(

            function success(result) {
                formContext.data.refresh(true);
            });
    },
    // not used  - just for reference - method to update the BPF  to closed stage 
    moveAdvanceBPF: function (formContext, recordId) {
        "use strict";
        var incident = recordId.replace("{", "").replace("}", "");
        var stage1 = "";
        var entity = {};
        var bpfId = "";
        var processStagesid = "";
        Xrm.WebApi.retrieveMultipleRecords("phonetocaseprocess", "?$select=businessprocessflowinstanceid,_processid_value&$filter=_incidentid_value eq " + incident).then(

            function success(result) {
                //check the data and get bpf id and process stage 
                if (result.entities.length > 0) {
                    bpfId = result.entities[0].businessprocessflowinstanceid;
                    processStagesid = result.entities[0]._processid_value;
                    Xrm.WebApi.retrieveMultipleRecords("processstage", "?$select=stagename,processstageid,stagecategory&$filter=processid/workflowid eq " + processStagesid).then(

                        function success(result) {
                            var newstage = "",
                                assignstage = "",
                                inprstage = "",
                                responded = "";
                            if (result.entities.length > 0) {
                                for (var k = 0; k < result.entities.length; k++) {
                                    switch (result.entities[k].stagename.toLowerCase()) {
                                        case 'new':
                                            newstage = result.entities[k].processstageid;
                                            break;
                                        case 'assigned':
                                            assignstage = result.entities[k].processstageid;
                                            break;
                                        case 'in progress':
                                            inprstage = result.entities[k].processstageid;
                                            break;
                                        case 'responded':
                                            responded = result.entities[k].processstageid;
                                            break;
                                    }
                                }
                                stage1 = newstage + "," + assignstage + "," + inprstage;
                            }
                            entity["activestageid@odata.bind"] = "/processstages(" + responded + ")";
                            entity["traversedpath"] = stage1 + "," + responded;
                            var req = new XMLHttpRequest();
                            req.open("PATCH", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/phonetocaseprocesses(" + bpfId + ")", true);
                            req.setRequestHeader("OData-MaxVersion", "4.0");
                            req.setRequestHeader("OData-Version", "4.0");
                            req.setRequestHeader("Accept", "application/json");
                            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                            req.onreadystatechange = function () {
                                if (this.readyState === 4) {
                                    req.onreadystatechange = null;
                                    if (this.status === 204) {
                                        formContext.data.refresh(false);
                                    }
                                }
                            };
                            req.send(JSON.stringify(entity));
                        });
                }
                // perform additional operations on retrieved records
            });
    },
    //Rerun Automation 
    changeNGHautomationRunningToTrue: function (primaryCtrl) {
        primaryCtrl.getAttribute("niq_nghautomationrunning").setValue(true);
        primaryCtrl.data.save();
    },
    ShowHideAssignedTobtnForSelected: function (items) {
        var isVisible = true;
        return isVisible;
    },
    ShowHideCopyLinkBtn: function (primaryctrl) {
        "use strict";

        if (primaryctrl.ui.getFormType() !== 1 && CommonForm.Events.CheckIfLoggedInUserRoles(serviceReqCreateRolesWithKnowledgeRoles)) {
            return true;
        }
        else {
            return false;
        }
    },
    copyRecordUrl: function (primaryCtrl) {
        var url = primaryCtrl.getUrl();
        var tempTag = document.createElement('textarea');
        tempTag.value = url;
        tempTag.setAttribute('readonly', '');
        tempTag.style = {
            position: 'absolute',
            left: '-9999px'
        };
        document.body.appendChild(tempTag);
        tempTag.select();
        document.execCommand('copy');
        document.body.removeChild(tempTag);
        //Xrm.Utility.alertDialog("Link copied to clipboard");
        if (url !== null || url !== undefined) {
            alert("Link copied to clipboard");
        }
    },
    ToPopulateNtoNGrid: function (primaryctrl) {
        "use strict";
        var recordtype = CommonForm.Events.GetFieldValue(primaryctrl, "niq_recordtype");
        if (recordtype == 100000000 || recordtype == 100000001 || recordtype == 100000002 || recordtype == 100000003 || recordtype == 100000004) {
            return true;
        }
        else {
            return false;
        }
    },
    VisibilityOfSaveandCloseButton: function (executionContext) {
        "use strict";
        var formContext = executionContext;
        var formItem = formContext.ui.formSelector.getCurrentItem();
        if ((formItem.getId() === '60ac74e8-6909-4974-9071-a7bd154c6a72') && (CommonForm.Events.CheckIfLoggedInUserRoles("NIQ Sales User, NIQ Marketing User, NIQ Finance User"))) {
            return false;
        } else {
            return true;
        }
    },
    ShowHidechangetopictButton: function (primaryctrl) {
        "use strict";

        var recordType = CommonForm.Events.GetFieldText(primaryctrl, "niq_recordtype");
        var statusofform = CommonForm.Events.GetFieldValue(primaryctrl, "statuscode");
        var isTechDurables = CommonForm.Events.GetFieldValue(primaryctrl, "niq_istechdurables");
		
		if (recordType !== null && (primaryctrl.ui.getFormType() !== 1) && statusofform !== 5 && recordType === "Analytics" && isTechDurables === false && CommonForm.Events.CheckIfLoggedInUserRoles(csRoles)){
		return true;
		}
		else if(recordType !== null && primaryctrl.ui.getFormType() === 1 && statusofform === 5 && (recordType === "H&S Requests" || recordType !== "Analytics" || opsRecordTypes.indexOf(recordType) !== -1)) {
		return false;
		}
		else
		return false;
        },
		
       ShowHidechangeNSStopictButton: function (primaryctrl) {
        "use strict";

        var recordType = CommonForm.Events.GetFieldText(primaryctrl, "niq_recordtype");
        var statusofform = CommonForm.Events.GetFieldValue(primaryctrl, "statuscode");
        		
		if (recordType !== null && (primaryctrl.ui.getFormType() !== 1) && statusofform !== 5 &&(recordType === "Client Response" || recordType === "NielsenIQ Global Helpline") && CommonForm.Events.CheckIfLoggedInUserRoles(csRoles)){
		return true;
		}
		else if(recordType !== null && primaryctrl.ui.getFormType() === 1 && statusofform === 5 && (recordType === "H&S Requests" || opsRecordTypes.indexOf(recordType) !== -1)) {
		return false;
		}
		else
		return false;
    },
    SendWelcomeButtonVisibility: async function (executionContext) {
        'use strict';
        var formContext = executionContext;
        if ((CommonForm.Events.CheckValueExists(formContext, "niq_discoverproductaccess")) && (CommonForm.Events.CheckValueExists(formContext, "niq_welcomepackagesent")) && (CommonForm.Events.CheckValueExists(formContext, "niq_recordtype"))) {
            var AccountId = formContext.getAttribute("customerid").getValue()[0].id;
            var enable = await Xrm.WebApi.retrieveRecord("account", AccountId.slice(1, -1), "?$select=niq_ngh_discoveraccess_isemailon").then(
                function success(result) {
                    var Enablemail = result["niq_ngh_discoveraccess_isemailon"]; // Boolean
                    if ((formContext.getAttribute("niq_discoverproductaccess").getValue() !== null) && (formContext.getAttribute("niq_welcomepackagesent").getValue() === false) && (formContext.getAttribute("niq_recordtype").getValue() === 100000004) && (Enablemail === true)) {
                        return true;
                    }
                    else {
                        return false;
                    }

                },
                function (error) {
                    return true;
                }
            );
            if (enable === true) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }


    },


    CallDiscoverFlow: function (executionContext) {
        formContext = executionContext;
        var requestId = formContext.data.entity.getId();
        Xrm.WebApi.retrieveRecord("niq_keyvalueconfiguration", "6b559774-84ae-ed11-aad0-000d3a248fa0", "?$select=niq_value").then(
            function success(result) {
                console.log(result.niq_value);
                var url1 = result.niq_value;
                var req = new XMLHttpRequest();
                //var url = "https://prod-116.westeurope.logic.azure.com:443/workflows/d1f57f14cfda44eab990ff93784f330a/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=JXW5JWxoMb89NYniRM-Q-tRubhGrTRH5X8qmy47FBpI";
                req.open("POST", url1, true);
                req.setRequestHeader('Content-Type', 'application/json');
                req.send(JSON.stringify({
                    "RequestId": requestId
                })

                );
            }

        );
    },

    showHideCloneRequestBtn: function (primaryctrl) {
        "use strict";
        var recordtype = CommonForm.Events.GetFieldValue(primaryctrl, "niq_recordtype");

        if (primaryctrl.ui.getFormType() !== 1) {
            if ((CommonForm.Events.CheckIfLoggedInUserRole("System Administrator"))) {
                return true;
            }
            else if ((CommonForm.Events.CheckIfLoggedInUserRole("NIQ Delegate Agent") || CommonForm.Events.CheckIfLoggedInUserRole("NIQ Delegate Manager")) && recordtype === 100000002) {
                return true;
            }
            else if ((CommonForm.Events.CheckIfLoggedInUserRoles(showopsbuttonRoles))
                && (recordtype === 100000000 || recordtype === 100000001 || recordtype === 100000003 || recordtype === 100000005 || recordtype === 100000006 || recordtype === 100000007 || recordtype === 100000008 || recordtype === 100000009 || recordtype === 100000010 || recordtype === 100000011 || recordtype === 100000013 || recordtype === 100000014)) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    },
    // Create Child case function
    CreatenewChildRequests: function (executionContext) {
        "use strict";
        //debugger;

        var fields = [
            "niq_recordtype", "prioritycode", "customerid", "niq_frequency",
            "niq_numberofcountries", "niq_guidedanalyticscontent", "niq_serviceproduct",
            "niq_numberofslidespagestabs", "niq_numberofclients", "niq_numberofperformanceoverview",
            "niq_numberofcategories", "niq_guidedanalyticsused", "niq_numberofdatabases",
            "niq_yourhypothesis", "niq_businessquestion", "niq_multiclient",
            "niq_sourceofrequest", "niq_expecteddecisions", "niq_analyticscomments",
            "niq_supportareahs", "niq_businesstopicsincluded", "niq_categoryhs",
            "niq_totalplannedefforts", "title", "description", "niq_clientescalation",
            "niq_reasonforescalationoptionset", "niq_additionalinformationtext"
        ];

        var parameters = fields.reduce((acc, field) => {
            var value = CommonForm.Events.GetFieldValue(executionContext, field);
            if (value !== undefined && value !== null) {
                acc[field] = value;
            }
            return acc;
        }, {});

        var requestid = executionContext.data.entity.getId();
        if (!requestid) return;

        var accountid = parameters["customerid"];
        if (accountid) {
            parameters["customerid"] = [{
                id: accountid[0].id,
                name: accountid[0].name,
                entityType: "account"
            }];
        }

        // carry forward request origin & NSS fields only for NSS
        var caseOriginCode = CommonForm.Events.GetFieldValue(executionContext, "caseorigincode");

        if (caseOriginCode === 100000172) {
            parameters["caseorigincode"] = caseOriginCode;

            // NSS Topic
            var nsstopic = CommonForm.Events.GetFieldValue(executionContext, "niq_nsstopic");
            if (nsstopic && nsstopic[0]) {
                parameters["niq_nsstopic"] = [{
                    id: nsstopic[0].id,
                    name: nsstopic[0].name,
                    entityType: "niq_topic"
                }];
            }
            //NSS Subtopic
            var nsssubtopic = CommonForm.Events.GetFieldValue(executionContext, "niq_nsssubtopic");
            if (nsssubtopic && nsssubtopic[0]) {
                parameters["niq_nsssubtopic"] = [{
                    id: nsssubtopic[0].id,
                    name: nsssubtopic[0].name,
                    entityType: "niq_nsssubtopic"
                }];
            }
        }

        parameters["parentcaseid"] = [{
            id: requestid,
            name: parameters["title"],
            entityType: "incident"
        }];

        // Carry forward Escalated related fields to child request
        parameters["niq_additionalinformationtext"] = CommonForm.Events.GetFieldValue(executionContext, "niq_additionalinformationtext");
        parameters["niq_clientescalation"] = CommonForm.Events.GetFieldValue(executionContext, "niq_clientescalation");
        parameters["niq_reasonforescalationoptionset"] = CommonForm.Events.GetFieldValue(executionContext, "niq_reasonforescalationoptionset");


        var availableForms = executionContext.ui.formSelector.items.get();
        var recordTypeText = CommonForm.Events.GetFieldText(executionContext, "niq_recordtype");
        var navigateTo = availableForms.find(form => form.getLabel().toLowerCase() === recordTypeText.toLowerCase());

        var formid = navigateTo ? navigateTo.getId() : "";

        var pageInput = {
            pageType: "entityrecord",
            entityName: "incident",
            formId: formid,
            data: parameters
        };

        var navigationOptions = {
            target: 1,
            height: { value: 90, unit: "%" },
            width: { value: 80, unit: "%" },
            position: 1
        };

        Xrm.Navigation.navigateTo(pageInput, navigationOptions);
        executionContext.data.entity.save("success");
    },
    // Show Hide Create Child case button
    ShowHideChildRequestsbtn: function (executionContext) {
        "use strict";
        //debugger;
        var statuscode = CommonForm.Events.GetFieldText(executionContext, "statuscode",);
        var parentcaseid = CommonForm.Events.GetFieldValue(executionContext, "parentcaseid");
        if ((statuscode == "Closed") || (parentcaseid != undefined || parentcaseid != null) || executionContext.ui.getFormType() == 1) {
            return false;
        }
        else {
            return true;
        }

    },

    changeCloneRecordtoTrue: function (executionContext) {
        "use strict";
        formContext = executionContext;

        var confirmStrings = { text: "Do You Want to Clone the Request? Once record is cloned, bell notification will appear", title: "" };
        Xrm.Navigation.openConfirmDialog(confirmStrings, null).then(
            function (success) {
                if (success.confirmed) {
                    var curuserid = Xrm.Utility.getGlobalContext().userSettings.userId.replace("{", "").replace("}", "");
                    formContext.getAttribute("niq_storecloneuserid").setValue(curuserid);
                    formContext.getAttribute("niq_clonerecord").setValue(true);
                    formContext.data.entity.save();
                }
                else
                    console.log("Dialog closed using Cancel button or X.");
            }
        );

        RequestRibbon.Events.moveCopyAttachments(executionContext);

    },

      moveCopyAttachments:async function(primaryControl) {
            const incidentId = primaryControl.data.entity.getId().replace(/[{}]/g, "").toLowerCase();
            const targetIncidentId = prompt("Enter cloned Incident ID"); // Replace with your clone ID logic

const response = await RequestRibbon.Events.getFilesFromFlow(incidentId);

// First parse the outer object
const outer = response.filesjson;

// Parse the JSON string inside filesjson
const parsed = JSON.parse(outer);

// Access the array
const files = parsed.body || [];

        const encodedData = encodeURIComponent(JSON.stringify(files));

            // 2. Open popup with file list
            const pageInput = {
                pageType: "webresource",
                webresourceName: "niq_new_attachmentSelector",
                data: encodedData
            };
            const navOptions = { target: 2, width: {value: 50, unit: "%"}, height: {value: 60, unit: "%"}, position: 1 };
            await Xrm.Navigation.navigateTo(pageInput, navOptions);

            // 3. Retrieve selected files
            const result = JSON.parse(sessionStorage.getItem("selectedFiles") || "{}");
            if (!result.selectedFiles || !result.selectedFiles.length) {
                Xrm.Navigation.openAlertDialog({ text: "No files selected." });
                return;
            }

            // 4. Trigger Move/Copy Flow
            await RequestRibbon.Events.triggerMoveCopyFlow(incidentId, targetIncidentId, result.selectedFiles, result.move);
            Xrm.Navigation.openAlertDialog({ text: "Files processed successfully." });
            },
            
            getAttachments:async function(ticketId) {
            const id = ticketId.replace(/[{}]/g, "").toLowerCase();
        const options = `?$select=sharepointdocumentid,fullname,absoluteurl
                        &$filter=_regardingobjectid_value eq ${id}`;

        const res = await Xrm.WebApi.retrieveMultipleRecords("sharepointdocument", options);
        return res.entities;
    },
    
      getFilesFromFlow:async function(incidentId) {
        const flowUrl = "https://2f9b6b4d7431ea91b050d96b083ae9.56.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/6afbedf028004c718bb232ee85f62a96/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=lHrtT3C2W5IQyYla4PbG9wXPxtj0-rFTDKxEv_9KEUM"; // Flow URL for listing
        const res = await fetch(flowUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ incidentId })
        });
        if (!res.ok) throw new Error("Failed to get files");
        return await res.json();
    },
    
      triggerMoveCopyFlow:async function(attachments) {
        return new Promise(async (resolve) => {
        let checkboxes = attachments.map(att =>
            `<label><input type="checkbox" value="${att.annotationid}"> ${att.filename || att.subject || "Untitled"}</label><br/>`
        ).join("");

        let dialogHtml = `
            <div style="font-family:Segoe UI; font-size:14px;">
                <h3>Select Attachments</h3>
                ${checkboxes}
                <br/><label><input type="checkbox" id="moveOrCopy"> Move instead of Copy</label>
            </div>
        `;
        const safeHtml = sanitizeHtml(dialogHtml);

        const dialogOptions = { title: "Move/Copy Attachments", height: 400, width: 400 };
     
        const confirmResult = await Xrm.Navigation.openConfirmDialog({ text: dialogHtml, title: "Move/Copy Attachments" }, dialogOptions);

        if (confirmResult.confirmed) {
            const tempDiv = document.createElement("div");
            tempDiv.innerHTML = safeHtml;

            const selectedIds = [];
            tempDiv.querySelectorAll("input[type=checkbox]:not(#moveOrCopy)").forEach(cb => {
                if (cb.checked) selectedIds.push(cb.value);
            });
        
            const isMove = tempDiv.querySelector("#moveOrCopy").checked;
            resolve({ ids: selectedIds, isMove });
        } else {
            resolve(null);
        }
    });
    },
    
    //hide assign button for H&S Request for Non-admin users
    HideAssignButtonForHnsNonAdmin: function (primaryctrl) {
        "use strict";

        var recordType = CommonForm.Events.GetFieldValue(primaryctrl, "niq_recordtype");
        if ((recordType == 100000012 || recordtype == "H&S Requests") && (CommonForm.Events.CheckIfLoggedInUserRole("System Administrator") || CommonForm.Events.CheckIfLoggedInUserRole("NIQ Business Admin"))) {
            return true;
        }
        else {
            return false;
        }

    },

}
function rejectRequest(primaryControl) {
    var formContext = primaryControl;

    //var isrejected = formContext.getAttribute("niq_isrejected").value;
    var recordId = formContext.data.entity.getId();
    formContext.data.entity.save();
    var dirtyAccountCheck = formContext.getAttribute("customerid").getIsDirty();
    if ((dirtyAccountCheck == true)) {
        return;
    }
    else {
        //formContext.getAttribute("niq_isRejected").setValue(1);
        var confirmStrings = { text: "On rejecting this request, a closure email that doesn't contain a CSAT survey will be sent to the contact on the request.", title: "Do you want to Reject the Request" };
        Xrm.Navigation.openConfirmDialog(confirmStrings, null).then(
            function (success) {
                if (success.confirmed) {
                    //setting the isrejected flag to true
                    formContext.getAttribute("niq_isrejected").setValue(true);
                    // Setting required fields to not required
                    var attributes = formContext.data.entity.attributes.get();
                    for (var i in attributes) {
                        attributes[i].setRequiredLevel("none");
                    }
                    formContext.data.entity.save();

                    if (formContext.getAttribute("statuscode") != null) {

                        //formContext.getAttribute("statuscode").setValue(100000028);
                        //formContext.getAttribute("niq_substatus").setValue(100000027);					
                        //formContext.data.entity.save();
                        var recid = formContext.data.entity.getId();

                        RequestRibbon.Events.moveAdvanceBPF(formContext, recid);

                        //formContext.getAttribute("niq_substatus").setValue(100000027);
                        // formContext.data.entity.save();
                    }
                }
                else
                    console.log("Not OK");
            }
        );
    }
}
function ChangeRecordTypeOnTopicChange(primaryControl, formGuid, topicText, topicValue) {
    if (primaryControl.ui.getFormType() === 1) return;
    var formContext = primaryControl;
    var accountid = primaryControl.getAttribute("customerid").getValue()[0].id;

    var confirmStrings = { text: "This is a confirmation.", title: "Do you want to change the topic?" };
    var confirmOptions = { height: 200, width: 450 };
    Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
        function (success) {
            if (success.confirmed) {

                var topic = topicText.CommandValueId.replace('&', '%26');
                var formType = null;
                var slaid = null;
                recordId = primaryControl.data.entity.getId();
                if (topic.toLowerCase() == "analysis %26 insights" || topic.toLowerCase() == "data extraction" || topic.toLowerCase() == "analytics - others") {
                    formType = "Analytics";

                }
                else if (topic.toLowerCase() == "software questions & issues" || topic.toLowerCase() == "Data Plans Support (Questions & Issues)"
                    || topic.toLowerCase() == "Data Plans Sales (Data Point Limits/ Tier Changes)") {
                    formType = "NGH"
                }
                else {
                    formType = "Client Response"

                }

                var accountname = "";
                if (accountid != null && accountid != "") {


                    Xrm.WebApi.online.retrieveRecord("account", accountid, "?$select=name").then(
                        function success(result) {

                            if (result["name"] != null) {

                                accountname = result["name"];
                                var rectype = CommonForm.Events.GetFieldValue(formContext, "niq_recordtype");

                                if (rectype !== null && rectype === 100000003 && accountid !== null && accountid !== undefined && (accountname.indexOf("Nielsen Consumer") > -1 || accountname.indexOf("NielsenIQ") > -1)) {

                                    formContext.ui.setFormNotification("Nielsen Consumer account should not be selected when changing/selecting topics related to 'Analytics' and 'client response'.", "ERROR", "multiclientacc001");
                                    primaryControl.getEventArgs().preventDefault();
                                    return;
                                }
                                else {
                                    formContext.ui.clearFormNotification("multiclientacc001");
                                    getAccountMarket(primaryControl, accountid).then(function (value) {
                                        var regionName = getSLARegionBasedOnCountry(value.name);
                                        getSLARecord(primaryControl, regionName, formType).then(function (value) {
                                            //if (value !== null)
                                            //{
                                            slaid = value.id;
                                            getTopicByName(primaryControl, topic).then(function (topicData) {
                                                var data = {};
                                                data.niq_recordtype = topicValue;
                                                data['niq_TopicId@odata.bind'] = "/niq_topics(" + topicData.id + ")";
                                                data['niq_subtopic'] = null;
                                                if (topicValue == 100000001 || topicValue == 100000003) {
                                                    data['niq_nsstopic'] = null;
                                                    data['niq_nsssubtopic'] = null;
                                                }
                                                if (slaid !== null)
                                                    data['slaid_sla@odata.bind'] = "/slas(" + slaid + ")";
                                                // }
                                                // update the record
                                                Xrm.WebApi.updateRecord("incident", recordId, data).then(
                                                    function success(result) {
                                                        console.log("incident updated");
                                                        var items = primaryControl.ui.formSelector.items.get();
                                                        for (var i in items) {
                                                            var item = items[i];
                                                            var itemId = item.getId();
                                                            if (itemId.toLowerCase() === formGuid.toLowerCase()) {
                                                                item.navigate();
                                                                primaryControl.data.refresh(true);
                                                            }
                                                        }
                                                    },
                                                    function (error) {
                                                        console.log(error.message);
                                                        // handle error conditions
                                                    })
                                            })
                                            //primaryControl.getAttribute("slaid").setValue(slaLookup);
                                            //}

                                        }).catch(error => console.log(error));

                                    }).catch(error => console.log(error));
                                }
                            }
                        },
                        function (error) {
                            Xrm.Utility.alertDialog(error.message);
                        });
                }
            }
            else
                console.log("Dialog closed using Cancel button or X.");
        });

}
function ChangeRecordTypeOnNSSTopicChange(primaryControl, formGuid, topicText, topicValue) {
    if (primaryControl.ui.getFormType() === 1) return;
    var formContext = primaryControl;
    var accountid = primaryControl.getAttribute("customerid").getValue()[0].id;

    var confirmStrings = { text: "This is a confirmation.", title: "Do you want to change the topic?" };
    var confirmOptions = { height: 200, width: 450 };
    Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
        function (success) {
            if (success.confirmed) {

                var topic = topicText.CommandValueId.replace('&', '%26');
                var formType = null;
                var slaid = null;
                recordId = primaryControl.data.entity.getId();
                if (topic.toLowerCase() == "system issues") {
                    formType = "NGH"

                }
                else {
                    formType = "Client Response"
                }

                var accountname = "";
                if (accountid != null && accountid != "") {


                    Xrm.WebApi.online.retrieveRecord("account", accountid, "?$select=name").then(
                        function success(result) {

                            if (result["name"] != null) {

                                accountname = result["name"];
                                var rectype = CommonForm.Events.GetFieldValue(formContext, "niq_recordtype");

                                if (rectype !== null && rectype === 100000003 && accountid !== null && accountid !== undefined && (accountname.indexOf("Nielsen Consumer") > -1 || accountname.indexOf("NielsenIQ") > -1)) {

                                    formContext.ui.setFormNotification("Nielsen Consumer account should not be selected when changing/selecting topics related to 'Analytics' and 'client response'.", "ERROR", "multiclientacc001");
                                    primaryControl.getEventArgs().preventDefault();
                                    return;
                                }
                                else {
                                    formContext.ui.clearFormNotification("multiclientacc001");
                                    getAccountMarket(primaryControl, accountid).then(function (value) {
                                        var regionName = getSLARegionBasedOnCountry(value.name);
                                        getSLARecord(primaryControl, regionName, formType).then(function (value) {
                                            //if (value !== null)
                                            //{
                                            slaid = value.id;
                                            getTopicByName(primaryControl, topic).then(function (topicData) {
                                                var data = {};
                                                data.niq_recordtype = topicValue;
                                                data['niq_nsstopic@odata.bind'] = "/niq_topics(" + topicData.id + ")";
                                                data['niq_nsssubtopic'] = null;

                                                if (slaid !== null)
                                                    data['slaid_sla@odata.bind'] = "/slas(" + slaid + ")";
                                                // }
                                                // update the record
                                                Xrm.WebApi.updateRecord("incident", recordId, data).then(
                                                    function success(result) {
                                                        console.log("incident updated");
                                                        var items = primaryControl.ui.formSelector.items.get();
                                                        for (var i in items) {
                                                            var item = items[i];
                                                            var itemId = item.getId();
                                                            if (itemId.toLowerCase() === formGuid.toLowerCase()) {
                                                                item.navigate();
                                                                primaryControl.data.refresh(true);
                                                            }
                                                        }
                                                    },
                                                    function (error) {
                                                        console.log(error.message);
                                                        // handle error conditions
                                                    })
                                            })
                                            //primaryControl.getAttribute("slaid").setValue(slaLookup);
                                            //}

                                        }).catch(error => console.log(error));

                                    }).catch(error => console.log(error));
                                }
                            }
                        },
                        function (error) {
                            Xrm.Utility.alertDialog(error.message);
                        });
                }
            }
            else
                console.log("Dialog closed using Cancel button or X.");
        });

}
function getTopicByName(_formContext, topicName) {
    return new Promise((Resolve, Reject) => {
        console.log("inside gettopicbyname");
        var caseorigincode = _formContext.getAttribute("caseorigincode").getValue();
        if (caseorigincode == 100000172) {
            var uri = _formContext.context.getClientUrl() + "/api/data/v9.0/niq_topics?$filter=(niq_name eq '" + topicName + "'and niq_nsstype eq true)&$select=niq_topicid";
        }
        else {
            var uri = _formContext.context.getClientUrl() + "/api/data/v9.0/niq_topics?$filter=niq_name eq '" + topicName + "'&$select=niq_topicid";
        }
        var request = new XMLHttpRequest();
        request.open('GET', uri, true);
        request.setRequestHeader("OData-MaxVersion", "4.0");
        request.setRequestHeader("OData-Version", "4.0");
        request.setRequestHeader("Accept", "application/json");
        request.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        request.onreadystatechange = function () {
            if (this.readyState === 4) {
                request.onreadystatechange = null;
                if (this.status === 200) {
                    var data = JSON.parse(this.response);
                    if (data['value'].length > 0) {
                        Resolve({ 'id': data['value'][0]['niq_topicid'] });
                    }
                    else {
                        Resolve({ 'id': null });
                    }
                }
                else {
                    Reject(this.response);
                }
            }
        };
        request.send();
    });
}
var getAccountMarket = function (_formContext, accountId) {
    'use strict';
    return new Promise((Resolve, Reject) => {
        var uri = _formContext.context.getClientUrl() + "/api/data/v9.0/accounts?$filter=accountid eq '" + accountId + "'&$select=_niq_serviceroutingmarketid_value";
        var request = new XMLHttpRequest();
        request.open('GET', encodeURI(uri), false);
        request.setRequestHeader("OData-MaxVersion", "4.0");
        request.setRequestHeader("OData-Version", "4.0");
        request.setRequestHeader("Accept", "application/json");
        request.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        request.setRequestHeader("Prefer", "odata.include-annotations=OData.Community.Display.V1.FormattedValue");
        request.onreadystatechange = function () {
            if (this.readyState === 4) {
                request.onreadystatechange = null;
                if (this.status === 200) {
                    var data = JSON.parse(this.response);
                    if (data['value'].length > 0) {
                        Resolve(
                            {
                                'name': data['value'][0]['_niq_serviceroutingmarketid_value@OData.Community.Display.V1.FormattedValue'] === undefined || data['value'][0]['_niq_serviceroutingmarketid_value@OData.Community.Display.V1.FormattedValue'] === '' ? 'Americas' : data['value'][0]['_niq_serviceroutingmarketid_value@OData.Community.Display.V1.FormattedValue']
                            });
                    }
                    else {
                        Resolve(
                            {
                                'id': null
                            });
                    }
                }
                else {
                    Reject(this.response);
                }
            }
        };
        request.send();
    }
    );
}
var getSLARecord = function (_formContext, regionName, formType) {
    'use strict';
    return new Promise((Resolve, Reject) => {
        var uri = _formContext.context.getClientUrl() + "/api/data/v9.0/slas?$filter=statecode eq 1 and contains(name,'" + regionName + "') and contains(name,'" + formType + "')&$select=slaid,name";
        var request = new XMLHttpRequest();
        request.open('GET', encodeURI(uri), false);
        request.setRequestHeader("OData-MaxVersion", "4.0");
        request.setRequestHeader("OData-Version", "4.0");
        request.setRequestHeader("Accept", "application/json");
        request.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        request.onreadystatechange = function () {
            if (this.readyState === 4) {
                request.onreadystatechange = null;
                if (this.status === 200) {
                    var data = JSON.parse(this.response);
                    if (data['value'].length > 0) {
                        Resolve(
                            {
                                'id': data['value'][0]['slaid'],
                                'name': data['value'][0]['name']
                            });
                    }
                    else {
                        Resolve(
                            {
                                'id': null
                            });
                    }
                }
                else {
                    Reject(this.response);
                }
            }
        };
        request.send();
    });
}
var getSLARegionBasedOnCountry = function (country) {
    'use strict';

    const SLAPERCOUNTRY = {
        "Sri Lanka": "India/West Asia",
        "Americas": "Americas",
        "Australia": "India/West Asia",
        "Bangladesh": "India/West Asia",
        "India": "India/West Asia",
        "Indonesia": "India/West Asia",
        "Kazakhstan": "India/West Asia",
        "Malaysia": "India/West Asia",
        "Myanmar": "India/West Asia",
        "Nepal": "India/West Asia",
        "Pakistan": "India/West Asia",
        "Thailand": "India/West Asia",
        "United Arab Emirates": "India/West Asia",
        "Vietnam": "India/West Asia",
        "Hong Kong": "Pacific",
        "China": "Pacific",
        "Taiwan": "Pacific",
        "Singapore": "Pacific",
        "Philippines": "Pacific",
        "New Zealand": "Pacific",
        "Japan": "Pacific",
        "Korea": "Pacific",
        "Tunisia": "Europe",
        "Greece": "Europe",
        "Hungary": "Europe",
        "Ireland": "Europe",
        "Israel": "Europe",
        "Italy": "Europe",
        "Ivory Coast": "Europe",
        "Jordan": "Europe",
        "Kenya": "Europe",
        "Latvia": "Europe",
        "Lebanon": "Europe",
        "Lithuania": "Europe",
        "Maghreb": "Europe",
        "Morocco": "Europe",
        "Turkey": "Europe",
        "Uganda": "Europe",
        "Ukraine": "Europe",
        "United Kingdom": "Europe",
        "Sweden": "Europe",
        "Switzerland": "Europe",
        "Tanzania": "Europe",
        "Poland": "Europe",
        "Portugal": "Europe",
        "Romania": "Europe",
        "Russia": "Europe",
        "Saudi Arabia": "Europe",
        "Serbia": "Europe",
        "Slovakia": "Europe",
        "Slovenia": "Europe",
        "South Africa": "Europe",
        "Spain": "Europe",
        "Nigeria": "Europe",
        "Norway": "Europe",
        "Netherlands": "Europe",
        "Algeria": "Europe",
        "Austria": "Europe",
        "Belarus": "Europe",
        "Belgium": "Europe",
        "Bulgaria": "Europe",
        "Cameroon": "Europe",
        "Croatia": "Europe",
        "Cyprus": "Europe",
        "Czech Republic": "Europe",
        "Brazil": "Americas",
        "Denmark": "Europe",
        "Egypt": "Europe",
        "Estonia": "Europe",
        "Finland": "Europe",
        "France": "Europe",
        "Germany": "Europe",
        "Ghana": "Europe",
        "Dominican Republic": "Americas",
        "Global Above Market": "Americas",
        "Ecuador": "Americas",
        "Costa Rica": "Americas",
        "Colombia": "Americas",
        "Canada": "Americas",
        "Chile": "Americas",
        "El Salvador": "Americas",
        "Guatemala": "Americas",
        "Honduras": "Americas",
        "United States": "Americas",
        "Uruguay": "Americas",
        "Venezuela": "Americas",
        "Argentina": "Americas",
        "Puerto Rico": "Americas",
        "Nicaragua": "Americas",
        "Panama": "Americas",
        "Others": "Americas",
        "Peru": "Americas",
        "Mexico": "Americas",

    };

    return SLAPERCOUNTRY[country];
}
function isBulkButtonVisible(primaryControl) {
    if (!primaryControl) return false;

    // Check selected records
    var selectedRecords = primaryControl.getSelectedRecords();
    if (!selectedRecords || selectedRecords.length < 2) {
        return false; // fewer than 2 records selected
    }

    // Check current view
    var view = primaryControl.getViewSelector().getCurrentView();
    if (!view) return false;

    var currentViewId = view.id.replace("{", "").replace("}", "").toLowerCase();
    var targetViewId = "ce0f43e1-8981-f011-b4cc-7c1e5273f840".toLowerCase();

    return currentViewId === targetViewId;
}