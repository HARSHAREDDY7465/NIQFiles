﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace RollUpFunctionalityCheck 
{
    public class RecalcRollupOnChildChange : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference parentRef = null;

            if (context.InputParameters.Contains("Target"))
            {
                if (context.MessageName == "Create" || context.MessageName == "Update")
                {
                    var target = (Entity)context.InputParameters["Target"];
                    if (target.Contains("ts_childrollup"))
                    {
                        parentRef = target.GetAttributeValue<EntityReference>("ts_parentrollup");
                    }
                    else if (context.MessageName == "Update" && !target.Contains("ts_parentrollup"))
                    { 
                        var pre = (Entity)context.PreEntityImages["PreImage"];
                        parentRef = pre.GetAttributeValue<EntityReference>("ts_parentrollup");
                    }
                }
                else if (context.MessageName == "Delete")
                {
                    var pre = (Entity)context.PreEntityImages["PreImage"];
                    parentRef = pre.GetAttributeValue<EntityReference>("ts_parentrollup");
                }
            }

            if (parentRef == null) return;
            var req = new OrganizationRequest("CalculateRollupField");
            req["Target"] = parentRef;              
            req["FieldName"] = "ts_aggregaterollup";   
            service.Execute(req);
        }
    }
}
