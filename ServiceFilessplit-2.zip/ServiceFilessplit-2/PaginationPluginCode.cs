using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;

public static List<Entity> GetAllContactsForAccount(IOrganizationService service, Guid accountId)
{
    var columns = new ColumnSet("fullname", "emailaddress1", "telephone1", "contactid", "parentcustomerid");
    var query = new QueryExpression("contact")
    {
        ColumnSet = columns,
        Criteria = new FilterExpression(LogicalOperator.And)
        {
            Conditions =
            {
                new ConditionExpression("parentcustomerid", ConditionOperator.Equal, accountId)
            }
        },
        Orders =
        {
            new OrderExpression("createdon", OrderType.Ascending)
        },
        NoLock = true
    };

    var pageNumber = 1;
    var pagingCookie = string.Empty;
    var pageSize = 5000;
    var results = new List<Entity>();

    while (true)
    {
        query.PageInfo = new PagingInfo
        {
            PageNumber = pageNumber,
            Count = pageSize,
            PagingCookie = pagingCookie
        };

        var resp = service.RetrieveMultiple(query);
        results.AddRange(resp.Entities);

        if (resp.MoreRecords)
        {
            pageNumber++;
            pagingCookie = resp.PagingCookie; // use server-provided cookie for next page
        }
        else
        {
            break;
        }
    }

    return results;
}
